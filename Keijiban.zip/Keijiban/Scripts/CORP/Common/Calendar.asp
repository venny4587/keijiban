<!-- #include file="Header.asp" -->
<!-- #include file="Header_Error.asp" -->
<%
	Dim blnTerm
	Dim intType
	Dim dtmDefault(1)
	
	intType = Request.QueryString ("type")'Opener �̐ݒ�^�C�v
	
	dtmDefault(0) = CDate(Request.QueryString ("d1"))

	Select Case intType
	Case 1, 4
		blnTerm = False
		strTitle = "���t�ݒ�"
	Case 2, 3
		blnTerm = True
		strTitle = "���Ԑݒ�"
'		dtmDefault(1) = CDate(Request.QueryString ("d2"))
	End Select
%>
<HTML>
	<HEAD>
		<TITLE><%=strTitle%></TITLE>
		<!-- #include file="Header_Html.asp" -->
		<SCRIPT LANGUAGE="VBScript">
			<!--
			Dim m_intSelectedYear(1), m_intSelectedMonth(1), m_intSelectedDay(1)
			Dim m_intLoop
			
			Sub SetDate(intClickedDay)
				cmdDate(m_intSelectedDay(m_intLoop) - 1).style.BackGroundColor = &HE0E0E0&
				cmdDate(intClickedDay - 1).style.BackGroundColor = &HFF8000&
				m_intSelectedDay(m_intLoop) = intClickedDay
				<%If blnTerm Then%>
					If m_intLoop = 0 Then
						If Question("�J�n���� " & m_intSelectedYear(m_intLoop) & "�N" & m_intSelectedMonth(m_intLoop) & "��" & m_intSelectedDay(m_intLoop) & "�� �ɐݒ肵�܂����H") Then
							m_intLoop = m_intLoop + 1
							Call InitCalendar(m_intLoop)
						End If
					Else
						If Question("�I������ " & m_intSelectedYear(m_intLoop) & "�N" & m_intSelectedMonth(m_intLoop) & "��" & m_intSelectedDay(m_intLoop) & "�� �ɐݒ肵�܂����H") Then
							'Call ShowMsg(m_intSelectedDay(0))
							<%If intType = 2 Then%>
								window.opener.cboFromYear.Value = m_intSelectedYear(0)
								window.opener.cboFromMonth.SelectedIndex = m_intSelectedMonth(0) - 1
								window.opener.cboFromDay.SelectedIndex = m_intSelectedDay(0) - 1
								window.opener.cboToYear.Value = m_intSelectedYear(1)
								window.opener.cboToMonth.SelectedIndex = m_intSelectedMonth(1) - 1
								window.opener.cboToDay.SelectedIndex = m_intSelectedDay(1) - 1
							<%ElseIf intType = 3 Then%>
								window.opener.cboFromYear2.Value = m_intSelectedYear(0)
								window.opener.cboFromMonth2.SelectedIndex = m_intSelectedMonth(0) - 1
								window.opener.cboFromDay2.SelectedIndex = m_intSelectedDay(0) - 1
								window.opener.cboToYear2.Value = m_intSelectedYear(1)
								window.opener.cboToMonth2.SelectedIndex = m_intSelectedMonth(1) - 1
								window.opener.cboToDay2.SelectedIndex = m_intSelectedDay(1) - 1
							<%Else%>
								Call ShowMsg("�����^�I�[�v�i�[�̐ݒ肪�s���ł�!!")
							<%End If%>
							window.close()
						End If
					End If
				<%Else%>
					If Question(m_intSelectedYear(m_intLoop) & "�N" & m_intSelectedMonth(m_intLoop) & "��" & m_intSelectedDay(m_intLoop) & "�� �ɐݒ肵�܂����H") Then
						<%If intType = 1 Then%>
							window.opener.cboFromYear.Value = m_intSelectedYear(m_intLoop)
							window.opener.cboFromMonth.SelectedIndex = m_intSelectedMonth(m_intLoop) - 1
							window.opener.cboFromDay.SelectedIndex = m_intSelectedDay(m_intLoop) - 1
						<%ElseIf intType = 4 Then%>
							window.opener.frmMain.cboFromYear.Value = m_intSelectedYear(m_intLoop)
							window.opener.frmMain.cboFromMonth.SelectedIndex = m_intSelectedMonth(m_intLoop) - 1
							window.opener.frmMain.cboFromDay.SelectedIndex = m_intSelectedDay(m_intLoop) - 1
						<%Else%>
							Call ShowMsg("�����^�I�[�v�i�[�̐ݒ肪�s���ł�!!")
						<%End If%>
						window.close()
					End If
				<%End If%>
			End Sub
			
			Sub InitCalendar(intLoop)
				m_intLoop = intLoop'0...�J�n���t 1...�I�����t
				If m_intLoop = 0 Then
					m_intSelectedYear(0) = <%=Year(dtmDefault(0))%>
					m_intSelectedMonth(0) = <%=Month(dtmDefault(0))%>
					m_intSelectedDay(0) = <%=Day(dtmDefault(0))%>
					<%If blnTerm Then%>
						spanTitle.innerHTML = "�J�n���ݒ�"
						spanMarquee.innerHTML = "�J�n����I�����ĉ�����"
					<%Else%>
						spanTitle.innerHTML = "���t�ݒ�"
						spanMarquee.innerHTML = "���t��I�����ĉ�����"
					<%End If%>
				Else
'					m_intSelectedYear(1) = <%=Year(dtmDefault(1))%>
'					m_intSelectedMonth(1) = <%=Month(dtmDefault(1))%>
'					m_intSelectedDay(1) = <%=Day(dtmDefault(1))%>
					m_intSelectedYear(1) = m_intSelectedYear(0)
					m_intSelectedMonth(1) = m_intSelectedMonth(0)
					m_intSelectedDay(1) = m_intSelectedDay(0)
					spanTitle.innerHTML = "�I�����ݒ�"
					spanMarquee.innerHTML = "�I������I�����ĉ������i�J�n��=" & m_intSelectedYear(0) & "�N" & m_intSelectedMonth(0) & "��" & m_intSelectedDay(0) & "���j"
				End If
				Call ShowCalendar()
			End Sub
			
			Sub MoveMonth(intAdd)
				m_intSelectedMonth(m_intLoop) = m_intSelectedMonth(m_intLoop) + intAdd
				Call ShowCalendar()
			End Sub
			
			Sub ShowCalendar()
			
				Dim blnExist
				Dim dtmDate
				Dim i, j
				Dim strHTML
				
				dtmDate = DateSerial(m_intSelectedYear(m_intLoop), m_intSelectedMonth(m_intLoop), 1)
				dtmToDate = DateSerial(m_intSelectedYear(m_intLoop), m_intSelectedMonth(m_intLoop) + 1, 1) - 1
				
				strHTML = "<TABLE BGCOLOR=#606060 BORDER=1 BORDERCOLORLIGHT=0 BORDERCOLORDARK=#E0E0E0 CELLSPACING=0 CELLPADDING=3>"
				strHTML = strHTML & "<TR>"
				strHTML = strHTML & "<TD BGCOLOR=#FF4040 ALIGN=CENTER><FONT COLOR=#FFFFFF SIZE=-2>��</FONT></TD>"
				strHTML = strHTML & "<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>"
				strHTML = strHTML & "<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>"
				strHTML = strHTML & "<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>"
				strHTML = strHTML & "<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>"
				strHTML = strHTML & "<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>"
				strHTML = strHTML & "<TD BGCOLOR=#4040FF ALIGN=CENTER><FONT COLOR=#FFFFFF SIZE=-2>�y</FONT></TD>"
				strHTML = strHTML & "</TR>"
				
				For i = 1 To 6
					strHTML = strHTML & "<TR>"
					For j = 1 To 7
						If dtmDate <= dtmToDate Then
							If j = Weekday(dtmDate) Then
								If Day(dtmDate) = m_intSelectedDay(m_intLoop) Then
									blnExist = True
									strHTML = strHTML & "<TD><FONT COLOR=#FFFFFF><INPUT TYPE=BUTTON VALUE=" & Chr(34) & Day(dtmDate) & Chr(34) & " STYLE='border-width:1px;background-color:#FF8000;width=25pt;height=20pt;font-weight:bold;font-size:11pt' ID=cmdDate NAME=cmdDate OnClick='SetDate(" & Day(dtmDate) & ")'></FONT></TD>"
								Else
									strHTML = strHTML & "<TD><FONT COLOR=#FFFFFF><INPUT TYPE=BUTTON VALUE=" & Chr(34) & Day(dtmDate) & Chr(34) & " STYLE='border-width:1px;background-color:#E0E0E0;width=25pt;height=20pt;font-weight:bold;font-size:11pt' ID=cmdDate NAME=cmdDate OnClick='SetDate(" & Day(dtmDate) & ")'></FONT></TD>"
								End If
								dtmDate = DateSerial(Year(dtmDate), Month(dtmDate), Day(dtmDate) + 1)
							Else
								strHTML = strHTML & "<TD><BR></TD>"
							End If
						Else
							strHTML = strHTML & "<TD HEIGHT=35px><BR></TD>"
						End If
					Next
					strHTML = strHTML & "</TR>" & vbCrLf
				Next
				strHTML = strHTML & "</TABLE>"
				
				spanCalendar.innerHTML = strHTML

				'�Y��������t���Ȃ��ꍇ
				If Not blnExist Then 
					m_intSelectedDay(m_intLoop) = Day(dtmToDate)
					cmdDate(m_intSelectedDay(m_intLoop) - 1).style.BackGroundColor = &HFF8000&
				End If
				
				'�N���̃��Z�b�g
				dtmDate = DateSerial(m_intSelectedYear(m_intLoop), m_intSelectedMonth(m_intLoop), m_intSelectedDay(m_intLoop))
				m_intSelectedYear(m_intLoop) = Year(dtmDate)
				m_intSelectedMonth(m_intLoop) = Month(dtmDate)
				m_intSelectedDay(m_intLoop) = Day(dtmDate)
				
				spanMonth.innerHTML = m_intSelectedYear(m_intLoop) & "�N" & m_intSelectedMonth(m_intLoop) & "��"
				
			End Sub
			-->
		</SCRIPT>
	</HEAD>
	<BODY OnLoad="InitCalendar(0)" LEFTMARGIN=0 TOPMARGIN=10 BGCOLOR=#E0E0E0 BACKGROUND="/images/webLiveon/backgrounds/<%=Session("BackGround")%>" LINK=#000000 ALINK=#000000 VLINK=#0000FF>
		<FONT SIZE=-1>
			<CENTER>
				<TABLE BORDER=0>
					<TR>
						<TD>
							<TABLE BGCOLOR=#<%=Session("BackColor")%> BORDER=1 BORDERCOLORLIGHT=0 BORDERCOLORDARK=#E0E0E0 CELLSPACING=0 CELLPADDING=5>
								<TR>
									<TD BGCOLOR=#808080 WIDTH=120pt ALIGN=CENTER><FONT COLOR=#FFFFFF SIZE=-1><SPAN ID=spanTitle NAME=spanTitle></SPAN></FONT></TD>
								</TR>
							</TABLE>
						</TD>
						<TD WIDTH=10pt><BR></TD>
						<TD>
							<TABLE BGCOLOR=#<%=Session("BackColor")%> BORDER=1 BORDERCOLORLIGHT=0 BORDERCOLORDARK=#E0E0E0 CELLSPACING=0 CELLPADDING=5>
								<TR>
									<TD BGCOLOR=#808080 WIDTH=120pt ALIGN=CENTER><FONT COLOR=#FFFFFF SIZE=-1><SPAN ID=spanMonth NAME=spanMonth></SPAN></FONT></TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
				<BR>
				<SPAN ID=spanCalendar NAME=spanCalendar>
					<TABLE BGCOLOR=#606060 BORDER=1 BORDERCOLORLIGHT=0 BORDERCOLORDARK=#E0E0E0 CELLSPACING=0 CELLPADDING=3>
						<TR>
							<TD BGCOLOR=#FF4040 ALIGN=CENTER><FONT COLOR=#FFFFFF SIZE=-2>��</FONT></TD>
							<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>
							<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>
							<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>
							<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>
							<TD BGCOLOR=#FFFFFF ALIGN=CENTER><FONT COLOR=#000000 SIZE=-2>��</FONT></TD>
							<TD BGCOLOR=#4040FF ALIGN=CENTER><FONT COLOR=#FFFFFF SIZE=-2>�y</FONT></TD>
						</TR>
					</TABLE>
				</SPAN>
				<BR>
				<TABLE BGCOLOR=#606060 BORDER=1 BORDERCOLORLIGHT=0 BORDERCOLORDARK=#E0E0E0 CELLSPACING=0 CELLPADDING=3>
					<TR>
						<TD BGCOLOR=#808080>
							<INPUT TYPE=BUTTON VALUE="�O���̕\��" STYLE="border-width:1px;background-color:#E0E0E0" OnClick="MoveMonth(-1)">
							<INPUT TYPE=BUTTON VALUE="�L�����Z��" STYLE="border-width:1px;background-color:#E0E0E0" OnClick="window.close()">
							<INPUT TYPE=BUTTON VALUE="�����̕\��" STYLE="border-width:1px;background-color:#E0E0E0" OnClick="MoveMonth(1)">
						</TR>
					</TR>
					<TR>
						<TD BGCOLOR=#404040 ALIGN=CENTER><MARQUEE><FONT COLOR=#FFFFFF SIZE=-1><SPAN ID=spanMarquee NAME=spanMarquee></SPAN></FONT></MARQUEE></TD>
					</TR>
				</TABLE>
			</CENTER>
		</FONT>
	</BODY>
</HTML>