				<TABLE BGCOLOR=#404040 CELLPADDING=5 CELLSPACING=0 WIDTH=100% STYLE="font-family:'MS UI GOTHIC';font-size:14;color:#FFFFFF;background-image:url('/images/CORP/body/HeaderBack.gif');background-repeat:repeat-x">
					<TR HEIGHT=40>
						<TD ALIGN=LEFT WIDTH=160 STYLE="filter:dropshadow(color=#404040, offx=1, offy=1);font-size:12"><FONT COLOR=#FFFFFF FACE="Arial">IP:<%=Request.ServerVariables("REMOTE_HOST")%><BR>�o�^�ҁF<%=Session("UserName")%> </TD>
						<TD ALIGN=CENTER STYLE="filter:glow(color=#E0C040, strength=3, offx=1, offy=1);font-size:16"><B><%=strTitle%></B>�@<FONT FACE="Arial" COLOR=#FFFFFF SIZE=-2>Ver<%=strVersion%></FONT></TD>
						<TD ALIGN=RIGHT WIDTH=160 STYLE="filter:dropshadow(color=#404040, offx=1, offy=1);font-size:12"><FONT COLOR=#FFFFFF FACE="Arial"><%=FormatDateTime(Now, 1)%></TD>
					</TR>
					<TR>
						<TD BGCOLOR=#000000 HEIGHT=2 COLSPAN=3></TD>
					</TR>
					<TR>
						<TD BGCOLOR=#808080 HEIGHT=1 COLSPAN=3></TD>
					</TR>
					<TR>
						<TD BGCOLOR=#C0C0C0 HEIGHT=1 COLSPAN=3></TD>
					</TR>
				</TABLE>