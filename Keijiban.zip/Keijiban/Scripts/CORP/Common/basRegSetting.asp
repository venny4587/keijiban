<%
	Function GetSetting(lngShopCode, strAppName, strRegSection, strRegKey, strDefault)

		Dim Conn
		Dim Recset

		OpenSQL Conn, Session("SQLServerName"), Session("CorpCode") & "-Corp"
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		With Recset
			.Open "SELECT * FROM RegSetting WHERE ShopCode = " & lngShopCode & " AND AppName = '" & strAppName & "' AND RegSection = '" & strRegSection & "' AND RegKey = '" & strRegKey & "' AND DeleteFlag = 0;", Conn, adOpenForwardOnly, adLockReadOnly
			If .EOF Then
				GetSetting = strDefault
			Else
				GetSetting = .Fields ("RegValue")
			End If
			.Close 
		End With
		Set Recset = Nothing
		CloseDB Conn
		
	End Function

	Function SaveSetting(lngShopCode, strAppName, strRegSection, strRegKey, strRegValue)

		Dim Conn
		Dim Recset

		OpenSQL Conn, Session("SQLServerName"), Session("CorpCode") & "-Corp"
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		With Recset
			.Open "SELECT * FROM RegSetting WHERE ShopCode = " & lngShopCode & " AND AppName = '" & strAppName & "' AND RegSection = '" & strRegSection & "' AND RegKey = '" & strRegKey & "' AND DeleteFlag = 0;", Conn, adOpenKeyset, adLockOptimistic
			If .EOF Then
				.AddNew
				.Fields("ShopCode") = lngShopCode
				.Fields("AppName") = strAppName
				.Fields("RegSection") = strRegSection
				.Fields("RegKey") = strRegKey
				.Fields("CreateTime") = Now
				.Fields("DeleteFlag") = 0
				.Fields("SendFlag") = 1
			End If
			.Fields("RegValue") = strRegValue
			.Fields("UpdateTime") = Now
			.Update
			.Close 
		End With
		Set Recset = Nothing
		CloseDB Conn

	End Function
%>
