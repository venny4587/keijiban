<%
	Dim intBackType, strTitle, strVersion
	ReDim ErrNumber(0)
	ReDim ErrDescription(0)
	ReDim ErrSection(0)
	

	If Session("UserID_CORP") = "" Then
		Response.Write "<HTML><BODY OnLoad=""parent.location.href = '/scripts/CORP/Common/LogOff.asp?TimeOut=1';""></BODY></HTML>"
		Response.End
	ElseIf Session("CorpCode") = "" Then
		ShowErrorMsg "�f�[�^���{�������Ёi���C�Z���X�j��I�����ĉ�����"
	End If

	Sub AddError(lngErrNumber, strErrDescription, strErrSection)
		
		ReDim Preserve ErrNumber(UBound(ErrNumber) + 1)
		ReDim Preserve ErrDescription(UBound(ErrDescription) + 1)
		ReDim Preserve ErrSection(UBound(ErrSection) + 1)
		
		ErrNumber(UBound(ErrNumber)) = lngErrNumber
		ErrDescription(UBound(ErrDescription)) = strErrDescription
		ErrSection(UBound(ErrSection)) = strErrSection
		
		If IsNumeric(lngErrNumber) Then
			Err.Raise lngErrNumber, strErrDescription, strErrSection
		Else
			Err.Raise 0, strErrDescription, strErrSection
		End If

	End Sub
	
	Sub ShowError(lngErrNumber, strErrDescription, strErrSection)
		
		Dim i
		Dim strModuleName
		Dim strObjectName
		
		i = InStr(strErrSection, "_")
		If i = 0 Then
			strObjectName = ""
			strModuleName = strErrSection
		Else
			strObjectName = Left(strErrSection, i - 1)
		    strModuleName = Right(strErrSection, Len(strErrSection) - i)
		End If

		Response.Write "<HTML>"
		Response.Write "<SCRIPT LANGUAGE=JavaScript>alert(" & Chr(34) & "<" & strObjectName & ">  " & strModuleName & "\n\n���s���G���['" & lngErrNumber & "':\n\n" & strErrDescription & Chr(34) & ");"
		Response.Write "window.history.back();"
		Response.Write "</SCRIPT></HTML>"
		Response.End 
	End Sub

	Sub ShowErrorMsg(strMsg)
		Response.Write ("<HTML><SCRIPT LANGUAGE=JavaScript>alert(" & Chr(34) & strMsg & Chr(34) & ");window.history.back();</SCRIPT></HTML>")
		Response.End 
	End Sub

	Sub ResponseError(strMsg)
		Response.Write ("<HTML><SCRIPT LANGUAGE=JavaScript>alert(" & Chr(34) & strMsg & Chr(34) & ");window.history.back();</SCRIPT></HTML>")
		Response.End 
	End Sub

	intBackType = -1
%>
