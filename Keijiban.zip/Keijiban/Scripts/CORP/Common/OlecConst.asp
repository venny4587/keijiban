<%
	Private Const oc2dTypePlot = 1
	Private Const oc2dTypeBar = 2
%>
