<%
dim myURL			  		  
	myURL = request("URL")
%>

<HTML>
<HEAD>
<TITLE>Now Loading!!...���΂炭���҂�������</TITLE>
<!-- #include file="../scripts/Header_Html.asp" -->
<SCRIPT LANGUAGE="VBScript">
<!--
	Dim m_lngCount
	Function ShowTime()
		'Dim l, lngColor
		'Dim s
		'lngColor = 0
		m_lngCount = m_lngCount + 1
		'For l = 1 To m_lngCount
		'	s = s & "<FONT COLOR=" & lngColor & ">��</FONT>"
		'	lngColor = lngColor + 1
		'Next
		'spanTime.innerHTML = s & "</FONT>"
		spanCount.innerHTML = "Now Loading!!�@<FONT COLOR=#FFFF00>" & m_lngCount & "</FONT>"
	End Function
-->
</SCRIPT>
</HEAD>

<BODY OnContextmenu="return false" OnLoad="window.setInterval('ShowTime()', 1000);window.location.href='<%=myURL%>'" STYLE="cursor:wait">
<FONT SIZE=-1 FACE="MS UI GOTHIC">
<TABLE HEIGHT=100% WIDTH=100% BORDER=0>
	<TR><TD HEIGHT=40%>�@</TD></TR>
	<TR>
		<TD ALIGN=CENTER HEIGHT=10% STYLE="filter:glow(color=0,strength=10">
		<FONT FACE="Impact" COLOR=#8080FF SIZE=+2><B><SPAN ID=spanCount NAME=spanCount>Now Loading!!</SPAN></B></FONT>
		</TD>
	</TR>
	<TR>
		<TD HEIGHT=10% STYLE="filter:dropshadow(color=#000000,offx=1,offy=1"><MARQUEE><B><FONT COLOR=#E0E0E0>���΂炭���̂܂܂ł��҂������� ...</FONT></B></MARQUEE></TD>
	</TR>
	<TR><TD HEIGHT=40%>�@</TD></TR>
	<!--<TR><TD><SPAN ID=spanTime NAME=spanTime></SPAN></TD></TR>-->
</TABLE>
</FONT>
</BODY>
</HTML>