<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/common.asp" -->
<%
	dim myMode
	myMode = trim(cstr("" & Request("Mode")))
	if myMode = "1" then
		strSql = GetString(cstr("" & Request("strSql")))		
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		OpenSQL Conn, Session("SQLServerName"), Session("DatabaseName")
	else
		strSql = "SELECT jgbh, COUNT(jgbh) AS cnt"
		strSql = strSql & " FROM code_gs"
		strSql = strSql & " WHERE (jgbh IS NOT NULL)"
		strSql = strSql & " GROUP BY jgbh"
		strSql = strSql & " HAVING (COUNT(jgbh) > 1)"
	end if
%>
<html>
<head>
<TITLE>SQL VIEW</TITLE>
	<script language=vbscript>
	<!--
	sub doSearch()
		frmInput.Mode.value = 1
		frmInput.submit()
	end sub

	sub clearPage()
		window.location.href = "select.asp"
	end sub
	'-->
	</script>
</HEAD>
<BODY>

<table width="100%" border="0" cellpadding=0 cellspacing=0>
  <tr>
    <td valign="top">
      <form name="frmInput" method="post" action="select.asp">
         <table width="850" BORDER=1 CELLPADDING=2 CELLSPACING=0 STYLE="font-family:'Arial';font-size:12px">
          <tr bgcolor="<%=bgColor_Title%>" align="center">
            <td align="left"><textarea NAME="strSql" style="width:600px;height:30px"><%=strSql%></textarea></td>
            <td align=right>
				<input name="storeInSel" type=button onclick="doSearch()" style="width:80px;height:25px;" value="Run">
				<input name="storeInRes" type=button onclick="clearPage()" style="width:80px;height:25px;"  value="Clear"></td>
		  </tr>
		  <input type=hidden name="Mode" value='<%=myMode%>'>

		</table>
	  </form>
<%
if myMode = "1" then
	Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
	if not recset.EOF then
		no=0
	%>
	 <table BORDER=1 CELLPADDING=2 CELLSPACING=0 STYLE="font-family:'Arial';font-size:12px">
		<tr bgcolor="<%=bgColor_Title%>" align="center">
			<TD nowrap>No.</TD>	
<%	for each fld in Recset.Fields	
		cnt = cnt + 1%>				
			<TD nowrap><%=fld.name%></TD>
<%	next%>
		</TR>
<%		Do Until recset.EOF %>	
<%		no=no+1 %>		
		<TR>		
			<TD nowrap><%=no%><br></TD>
<%	for i = 0 to cnt-1%>
			<TD nowrap><%=recset.Fields(i)%><br></TD>
<%	next%>
		</TR>
<%
			recset.MoveNext
		Loop
%>				
	</TABLE>
<%					
	else
		Response.Write "<br><div align=center>No record founded.</div>"	
	end if
	recset.Close 
end if
%>
    </td>
  </tr>
</table>

</BODY>
</HTML>
<%
	Set Recset = Nothing
	CloseDB Conn
%>
