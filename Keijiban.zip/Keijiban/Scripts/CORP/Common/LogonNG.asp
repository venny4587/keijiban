<HTML>
	<HEAD>
		<TITLE>�F�؊m�F</TITLE>  
		<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<SCRIPT LANGUAGE="JavaScript">
			function popUp(url) {
				sealWin=window.open(url,"win",'toolbar=0,location=1,directories=0,status=1,menubar=1, scrollbars=1,resizable=1,width=500,height=450');
				self.name = "mainWin"; }
		</SCRIPT>
	</HEAD>
	<BODY OnContextmenu="return false">
		<CENTER>
			<TABLE>
				<TR><TD Height=20></TD></TR>
				<TR><TD align=center><B>���[�U�[�F��</B>
					<HR WIDTH=400>
					<FORM METHOD="POST" ACTION="/scripts/webLiveon/Common/Permission.asp" AUTOCOMPLETE="OFF" NAME="frmLogon">
						<TABLE BORDER=0 align=center>
							<TR><TD height=50 align=center valign=top><FONT SIZE=4 COLOR=#FF0000><%=Session("LogonErrMessage")%></FONT></TD></TR>
								<%Select case Session("LogonErrType")%>
									<%Case 0%>
										<TR><TD height=50 align=center valign=middle><FONT SIZE=3>�����p�L��������܂����B</FONT></TD></TR>
										<TR><TD height=50 align=center valign=middle></TD></TR>
									<%Case 1%>
										<TR><TD height=50 align=center valign=middle><Input Type="button" Name="btnReturn" Value="�߂�" Style="width:100px;height:30px" onclick=window.history.go(-1)></TD></TR>
										<TR><TD height=50 align=center valign=middle><FONT SIZE=2>���w�߂�x�{�^���������Ă�蒼���ĉ������B</FONT></TD></TR>
								<%End Select%>
							</TD></TR>				
						</TABLE>
					</FORM>
					<HR WIDTH=400>
				</TD></TR>
			</TABLE>	
			
		</CENTER>
	</BODY>
</HTML>
