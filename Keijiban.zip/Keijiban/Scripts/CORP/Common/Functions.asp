<%
	Function GetHex(strVBHex)
		strVBHex = Right("00000" & strVBHex, 6)
		GetHex = Right(strVBHex, 2) & Mid(strVBHex, 3, 2) & Left(strVBHex, 2)
	End Function

	'------------------------------------------------
	'�t�H�[�}�b�g�`��
	'------------------------------------------------	
	Function Format(varData, strFormat)
		Select Case LCase(strFormat)
		Case "yyyy/mm/dd"
			Format = Year(varData) & "/" & Right("0" & Month(varData), 2) & "/" & Right("0" & Day(varData), 2)
		Case "yyyy/mm/dd hh:nn"
			Format = Year(varData) & "/" & Right("0" & Month(varData), 2) & "/" & Right("0" & Day(varData), 2) & " " & Right("0" & Hour(varData), 2) & ":" & Right("0" & Minute(varData), 2)
		Case "yyyy/mm/dd hh:nn:ss"
			Format = Year(varData) & "/" & Right("0" & Month(varData), 2) & "/" & Right("0" & Day(varData), 2) & " " & Right("0" & Hour(varData), 2) & ":" & Right("0" & Minute(varData), 2) & ":" & Right("0" & Second(varData), 2)
		Case "yyyy�Nm��d��"
			Format = Year(varData) & "�N" & Month(varData) & "��" & Day(varData) & "��"
		Case "mm��dd��"
			Format = Right("0" & Month(varData),2) & "��" & Right("0" & Day(varData),2) & "��"
		Case "yyyymmddhhnnss"
			Format = Year(varData) & Right("0" & Month(varData), 2) & Right("0" & Day(varData), 2) & Right("0" & Hour(varData), 2) & Right("0" & Minute(varData), 2) & Right("0" & Second(varData), 2)
		Case "yyyymmddhhnn"
			Format = Year(varData) & Right("0" & Month(varData), 2) & Right("0" & Day(varData), 2) & Right("0" & Hour(varData), 2) & Right("0" & Minute(varData), 2)
		Case "hh:nn:ss"
			Format = Right("0" & Hour(varData), 2) & ":" & Right("0" & Minute(varData), 2) & ":" & Right("0" & Second(varData), 2)
		Case "hh:nn"
			Format = Right("0" & Hour(varData), 2) & ":" & Right("0" & Minute(varData), 2)
		Case "mm/dd"
			Format = Right("0" & Month(varData), 2) & "/" & Right("0" & Day(varData), 2)
		Case "mm/dd(aaa)"
			Format = Right("0" & Month(varData), 2) & "/" & Right("0" & Day(varData), 2) & "(" & left(weekDayName(WeekDay(varData)),1) & ")"
		Case "mm/d"
			Format = Right("0" & Month(varData), 2) & "/" & eval(Right("0" & Day(varData), 2))
		Case Else
			Format = varData
		End Select
	End Function
	
	
	
	'------------------------------------------------
	'�p�X���[�h�̍쐬�Ǝ擾
	'------------------------------------------------
	Function GetPassword(intLength)
		Dim i
		Dim r
		Dim s
		
		
		Randomize
		
'		For i = 1 To intLength
'			r = Int(Rnd * 60)
'			If r <= 9 Then
'				GetPassword = GetPassword & Chr(Asc("0") + r)
'			ElseIf r <= 23 Then
'				GetPassword = GetPassword & Chr(Asc("a") + r - 10)
'			ElseIf r <= 34 Then
'				GetPassword = GetPassword & Chr(Asc("p") + r - 24)
'			ElseIf r <= 48 Then
'				GetPassword = GetPassword & Chr(Asc("A") + r - 35)
'			Else
'				GetPassword = GetPassword & Chr(Asc("P") + r - 49)
'			End If
'		Next
		Do
			GetPassword = ""
			For i = 1 To intLength
				Do
					r = Int(Rnd * 62)
					If r <= 9 Then
						s = Chr(Asc("0") + r)
					ElseIf r <= 35 Then
						s = Chr(Asc("a") + r - 10)
					Else
						s = Chr(Asc("A") + r - 36)
					End If
					Select Case s
					Case "o", "O", "l", "I", "i", "j", "J", "u", "v"
					Case Else
						GetPassword = GetPassword & s
						Exit Do
					End Select
				Loop
			Next
			If Not IsNumeric(GetPassword) Then Exit Do
		Loop
		
	End Function
	
	
	
	Function SendMail(strMailTo, strTitle, strBody)
		Dim bobj
		'�t�b�^�[��t����
		strBody = strBody & vbCrLf & vbCrLf & "https://www.liveon-web.net/"
		Set bobj = Server.CreateObject ("basp21")
		SendMail = bobj.SendMail ("liveon.co.jp:25:30", strMailTo, "LiveOn-WEB<server@liveon.co.jp>", strTitle, strBody, "")
		Set bobj = Nothing
	End Function
	
	
	'------------------------------------------------
	'�����^���Ǘ��@���C�Z���X�𔭍s���Ă悢���`�F�b�N
	'------------------------------------------------
	Function CheckLicenseHakkou(Status,StartDate,EndDate)
		CheckLicenseHakkou = True
		If Status = 1 then
			if StartDate <> "" then
				if Format(Now,"yyyy/mm/dd") < Format(StartDate,"yyyy/mm/dd") then
					CheckLicenseHakkou = False
				End if
			End if
			if EndDate <> "" then
				if Format(Now,"yyyy/mm/dd") > Format(EndDate,"yyyy/mm/dd") then
					CheckLicenseHakkou = False
				End if
			End if	
		Else
			CheckLicenseHakkou = False
		end if
	End Function
	
	'------------------------------------------------
	'WEB�V�X�e�����̂�Ԃ�
	'------------------------------------------------
	function GetSystemName(SystemType)
		Select case clng(SystemType)
			case 1
				GetSystemName = "�f��"
			case else
				GetSystemName = "�s��"
		end select
	end function
	
%>
