<!--#include file="Header.asp"-->
<!--#include file="../DBClass/DBConst.asp"-->
<!--#include file="../DBClass/clsDBLogAccess.asp"-->
<%
	Dim blnTimeOut
	Dim objDBLogAccess
	Dim dtmTotalTime
	Dim strTitle
	Dim myDefaultASP
	
	If Request.QueryString ("TimeOut") = 1 Then
		blnTimeOut = True
		strTitle = "�^�C���A�E�g"
	Else
		blnTimeOut = False
		strTitle = "���O�I�t"
	End If
	If Not blnTimeOut Then
		'LogAccess �� LogOffTime ����������
		Set objDBLogAccess = New clsDBLogAccess
		With objDBLogAccess
			.UpdateLogOffTimeByAccessID Session("LogAccessID_CORP")
			dtmTotalTime = CDate(.LogOffTime - .Added)
		End With
		Set objDBLogAccess = Nothing
	End If
	
	myDefaultASP = Session("DefaultAsp")
	if cstr(Request("DefaultASP")) <> "" then myDefaultASP = Request("DefaultASP")
	
%>
<HTML>
	<HEAD>
		<TITLE><%=strTitle%></TITLE>
		<STYLE TYPE="text/css">
			a:hover{
				color:#FFFF00;
			}
			.CircleButton{background-image:url('/images/CORP/Shapes/CircleButton.gif');background-position:50% 50%;background-repeat:no-repeat}
			.MouseOut{cursor:hand;background-image:url('/images/CORP/Words/Menu_LogOn.gif');background-position:50% 90%;background-repeat:no-repeat}
			.MouseOver{cursor:hand;background-image:url('/images/CORP/Words/Menu_LogOn_Active.gif');background-position:50% 90%;background-repeat:no-repeat}
			.Selected{cursor:hand;background-image:url('/images/CORP/Words/Menu_LogOn_Selected.gif');background-position:50% 90%;background-repeat:no-repeat}
		</STYLE>
		<SCRIPT LANGUAGE="JavaScript">
			<!--
			-->
		</SCRIPT>
		<SCRIPT LANGUAGE="VBScript">
			<!--
			Function SetOverClass(objButton)
				objButton.className = "MouseOver"
			End Function
			Function SetOutClass(objButton)
				objButton.className = "MouseOut"
			End Function
			-->
		</SCRIPT>
	</HEAD>
	<BODY OnContextmenu="return false">
		<FONT>
			<CENTER>
				<BR>
				<%If blnTimeOut Then%>
				�^�C���A�E�g�̂��߁A�ēx���O�I���������Ă�������!!
				<%Else%>				
				���O�I�t���܂���!!
				<%End If%>
				<BR><BR><BR>
				<IMG SRC="/images/CORP/icons/LogOff.gif" ALT="LogOff">
				<%If Not blnTimeOut Then%>
				<BR><BR><BR>
				<FONT SIZE=-1>�����p���Ԃ́A<%=Hour(dtmTotalTime) & "����" & Minute(dtmTotalTime) & "��" & Second(dtmTotalTime) & "�b �ł���"%></FONT>
				<BR><BR>
				�܂��̂����p�A���҂����Ă���܂��B
				<%End If%>
				<BR><BR><BR>
				<TABLE BORDER=0 CELLPADDING=0 CELLSPACING=0>
					<TR ALIGN=CENTER HEIGHT=68px VALIGN=TOP>
						<TD CLASS=CircleButton>
							<TABLE BORDER=0 CELLPADDING=15 CELLSPACING=0 HEIGHT=71 WIDTH=72>
								<TR>
									<TD NAME=10 CLASS=MouseOut OnMouseOver="SetOverClass(this)" OnMouseOut="SetOutClass(this)" OnClick="parent.location.href='<%=myDefaultASP%>';" ALIGN=CENTER VALIGN=TOP>
										<IMG SRC="/images/CORP/icons/LogOn.gif">
									</TD>
								</TR>
							</TABLE>
						</TD>
					</TR>
				</TABLE>
			</CENTER>
		</FONT>
	</BODY>
</HTML>
<%
	Session.Abandon ()
%>