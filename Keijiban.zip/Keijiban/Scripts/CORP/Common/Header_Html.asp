		<META HTTP-EQUIV="Pragma" CONTENT="no-cache">
		<META HTTP-EQUIV="Expires" CONTENT="-1">
		<SCRIPT LANGUAGE="JavaScript">
			<!--
			function ShowMsg(strMsg){
				alert(strMsg);
			}
			function Question(strMsg){
				if (confirm(strMsg)) {
					return true;
				} else {
					return false;
				}
			}
			-->
		</SCRIPT>
		<SCRIPT LANGUAGE="VBScript">
			<!--
			Function OpenHelp(intType)
				Dim strURL, win1
				If intType = 0 Then'Users
					strURL = "/scripts/CORP/help/Users.asp"
				Else'WebMaster
					strURL = "/scripts/CORP/help/WebMaster.asp"
				End If
				win1 = window.open(strURL, "Help", "toolbar=no, location=no, status=yes, menubar=no, scrollbars=yes, resizable=yes")
			End Function
			-->
		</SCRIPT>
		<META HTTP-EQUIV="Content-Type" Content="text/html; charset=x-sjis">
		<STYLE>
			a:hover{
				color:#<%=Session("ForeColor")%>;
			}
		</STYLE>
		<STYLE TYPE="text/css">
			.cmdMenu{width:240px;height:40px;padding-left:20px;border-width:1px;background-color:#E0E0E0;color:#000000;background-repeat:no-repeat;background-position:3% 50%;font-size:12px;font-family:'MS UI GOTHIC'}
			.backButton{width:80px;height:40px;background-color:#E0E0E0;font-family:'MS UI GOTHIC';font-size:12px;border-width:1px;background-repeat:no-repeat;background-position:5% 50%;padding-left:15px;background-image:url('/images/CORP/back.gif')}
			.closeButton{width:80px;height:40px;background-color:#E0E0E0;font-family:'MS UI GOTHIC';font-size:12px;border-width:1px;background-repeat:no-repeat;background-position:5% 50%;padding-left:15px;background-image:url('/images/CORP/close.gif')}
			.cmdPrint12{width:120px;height:30px;border-width:1px;font-size:12px;background-color:#E0E0E0;padding-left:10px;background-repeat:no-repeat;background-position:5% 50%;background-image:url('/images/CORP/print.gif')}
			.cmdSave14{width:120px;height:30px;border-width:1px;font-size:14px;background-color:#E0E0E0;padding-left:10px;background-repeat:no-repeat;background-position:5% 50%;background-image:url('/images/CORP/save.gif')}
			.cmdbutton12{border-width:1px;background-color:#E0E0E0;font-family:'�l�r �o�S�V�b�N';font-size:12px}
			.cmdbutton14{border-width:1px;background-color:#E0E0E0;font-family:'�l�r �o�S�V�b�N';font-size:14px}
			.combo14{font-size:14px}	
			.combo14_Arial{font-size:14px;font-family:'Arial'}	
			.textbox14{border-style:solid;border-width:1;border-color:#E0E0E0;ime-mode:disabled;font-size:14px}
			.textbox14_Arial{border-style:solid;border-width:1;border-color:#E0E0E0;ime-mode:disabled;font-size:14px;font-family:'Arial'}
			.textbox14_ime{border-style:solid;border-width:1;border-color:#E0E0E0;ime-mode:active;font-size:14px}
		</STYLE>
