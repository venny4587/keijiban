<%@ LANGUAGE="VBScript" %>
<%
	Option Explicit
	''���̃t�@�C���̓T�[�o�[�֍X�V���Ă͂����Ȃ��B
'	Response.CacheControl = "no-cache"
	Response.AddHeader "Pragma", "no-cache"
	Response.Expires = -1
	
	Session.Timeout = 120
	Server.ScriptTimeout = 900
    Session("DefaultAsp") = "/index.asp"
    
'------------------------------------------------
	Session("SQLWMServerName") = "127.0.0.1"
'------------------------------------------------
%>
