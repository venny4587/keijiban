<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	JobCode = GetPost(request("JobCode"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 	
%>
<HTML>
<HEAD>
	<TITLE>���ޏ��ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=javaScript>
		function ShowDetail(myNo) {
			var win = window.open("DocumentDetail.asp?JobCode=<%=JobCode%>&seq="+myNo,"Document","scrollbars=1,width=600,height=400");
			win.focus();
		}	
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsFilesBackColor%>" topmargin=0 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<td width=50%>�����ފǗ�&nbsp;
	  	<td width=50% align=right>
	  		<img style="cursor:hand" src=img/new.gif alt="�V�K�ǉ�" onmousedown="ShowDetail('');">
	</table>
	<hr width=100% size=1 color=blue>
<%
	with recset
		strSql = "SELECT SeqNo, DocumentType, ObtainDate, ObtainTime, SendDate, SendTime," 
		strSql = strSql & " DocumentTitle, FetchDate, FetchTime, ReturnDate, ReturnTime, Remarks"
		strSql = strSql & " FROM TBL_CTM_DOCUMENT WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
		strSql = strSql & " ORDER BY DocumentType, SeqNo"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>����
		<TD class=line nowrap>�擾����
		<TD class=line nowrap>���t����
		<TD class=line nowrap>�������
		<TD class=line nowrap>�ԋp����
<%
			cnt = 0
			ShortCut = ""
			do while not .eof
				cnt = cnt + 1
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='<%=gsFilesForeColor%>';" onmouseout="this.bgColor='<%=gsFilesBackColor%>';" onclick="ShowDetail('<%=.Fields("SeqNo")%>');">
					<TD class=line nowrap><%=cnt%><BR>
					<TD class=line nowrap><%=GetString(.Fields("DocumentType"))%><BR>
					<TD class=line nowrap><%=Str2MD(.Fields("ObtainDate"))%>&nbsp;<%=GetString(.Fields("ObtainTime"))%><BR>
					<TD class=line nowrap><%=Str2MD(.Fields("SendDate"))%>&nbsp;<%=GetString(.Fields("SendTime"))%><BR>
					<TD class=line nowrap><%=Str2MD(.Fields("FetchDate"))%>&nbsp;<%=GetString(.Fields("FetchTime"))%><BR>
					<TD class=line nowrap><%=Str2MD(.Fields("ReturnDate"))%>&nbsp;<%=GetString(.Fields("ReturnTime"))%><BR>
<%
				.movenext
			loop
%>
	</TABLE>
<%
		end if
	end with
%>  
</BODY>
</HTML>
<% 
set recset = nothing
CloseDB Conn
%>
