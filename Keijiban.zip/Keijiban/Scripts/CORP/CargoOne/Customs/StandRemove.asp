<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	JobCode = GetPost(request("JobCode"))
	ChargeNo = GetPost(request("ChargeNo"))
	SeqNo = GetLong(request("seq"))
	
	OpenSql Conn, SqlServerName, DataBaseName
		
	if JobCode <> "" and ChargeNo <> "" then
		if CheckBillFinished(Conn, JobCode, ChargeNo) then
			JobCode = ""
			ShowMessage "�Y�����鐿�����͊��ɏ�������܂����B"
		end if
	end if
	
	if JobCode <> "" then
		
		strSql = "UPDATE TBL_CTM_EXPENSE SET ExpenseBill = ''"
		strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
		Conn.Execute strSql
		
		if ChargeNo <> "" then 
			'�������X�V
			ChargeTax = 0
			ChargeAmount = 0
			set Recset = Server.CreateObject("adodb.recordset")	
			with Recset
				strSql = "SELECT SUM(ExpenseAmount) AS ChargeAmount, SUM(ExpenseTax) AS ChargeTax FROM TBL_CTM_EXPENSE"
				strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
				strSql = strSql & " AND ExpenseType IN (" & gsCharge & "," & gsStand & ")"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					ChargeTax = GetLong(.fields("ChargeTax"))
					ChargeAmount = GetLong(.fields("ChargeAmount"))
				end if
				.close
			end with
			set Recset = nothing
		
			strSql = "UPDATE TBL_CTM_CHARGE SET ChargeAmount = " &  GetLong(ChargeAmount) & ", ChargeTax = " &  GetLong(ChargeTax)
			strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			Conn.Execute strSql
		end if
		
%>
<html>
<script language=javascript>
	window.parent.parent.info.balance.location.href = "BalanceCheck.asp?JobCode=<%=JobCode%>";
	window.parent.list.location.href = "ChargeBill.asp?JobCode=<%=JobCode%>";
	window.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>";
</script>
</html>
<%
	end if
	
	CloseDB Conn
%>