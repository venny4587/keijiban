<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�Ɩ����ь��ʐ��ڕ\
'----------------------------------------------
	
dim myStandAmnt(6)
dim myStandIn(6)
dim mySalesAmnt(6)
dim mySalesTax(6)
dim myCostsAmnt(6)
dim myCostsTax(6)
dim myBenefit(6)
dim myCount(6)
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobBelong = ""
	myLevel = CheckUserLevel(UserShop, "")
	if CheckTopLevel() = 0 and myLevel < 4 then
		select case WebUserID
		case 24, 46, 73
		case else
			 JobBelong = UserShop
		end select
	end if
	
	SelYear = GetLong(request("SelYear"))
	SelMonth = GetLong(request("SelMonth"))
	if SelYear = 0 or SelMonth = 0 then
		SelDate = date
		if day(SelDate) <= 31 then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
	end if	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
%>

<HTML>
<HEAD>
	<TITLE>�Ɩ����ь��x�ꗗ�\</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<script language=vbscript>
		function ShowReport(myMode)
		dim myYear, myMonth
			myYear = frmInput.SelYear.options(frmInput.SelYear.selectedIndex).value
			myMonth = frmInput.SelMonth.options(frmInput.SelMonth.selectedIndex).value
			set win = window.open("ReportSoko" & myMode & ".asp?SelYear=" & myYear & "&SelMonth=" & myMonth,"ReportSoko" & myMode,"resizable=1,scrollbars=1,width=800,height=420")
			win.focus()
		end function
	</script>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ReportMonthly.asp" ID=frmInput NAME=frmInput>
		<table class=pt9>
			<TR><TD nowrap>�Ώ۔N�x
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>��&nbsp;
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
<%if CheckTopLevel() > 0 then%>
					<INPUT class=pt9b style="width:80px;height:30px;" TYPE=button name=btnSoko VALUE="�����" onclick="ShowReport(0)">
<%end if%>
<%select case WebUserID%>
<%case 24, 46, 73%>
					<INPUT class=pt9b style="width:80px;height:30px;" TYPE=button name=btnSoko VALUE="�����" onclick="ShowReport(0)">
<%end select%>
				<TD width=30>
				<TD nowrap>
<%if CheckTopLevel() > 0 or myLevel > 2 then%>
					<INPUT class=pt9n style="width:180px;height:30px;" TYPE=BUTTON name=btnView1 VALUE="��ƌ`�ԕʁE�戵���ѕ\" onclick="ShowReport(1)">
					<INPUT class=pt9n style="width:180px;height:30px;" TYPE=BUTTON name=btnView2 VALUE="�_�ˑq�ɕʁE�戵���ѕ\" onclick="ShowReport(2)">
<%end if%>
		</table>
	</form>
<div id=list>
�Ώ۔N���F<%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��<br>
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100% >
		<colgroup align=center>
		<colgroup span=2 align=right>
		<colgroup span=2 bgcolor="#FFF0F0" align=right>
		<colgroup span=2 align=right>
		<colgroup span=2 bgcolor="#FFF0F0" align=right>
		<colgroup span=2 align=right>
<%
	call FetchData(gsExport)
	response.write "<tr><td colspan=11><br>"
	call FetchData(gsImport)
	response.write "<tr><td colspan=11><br>"
	if AccountMonth = "200611" then
		call FetchData("M")
	else
		call FetchData(gsOther)
	end if
	response.write "<tr><td colspan=11><br>"
	call FetchData("")
%>
	</table>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function FetchData(myType)
	for i = 0 to 6
		myStandAmnt(i) = 0:		myStandIn(i) = 0
		mySalesAmnt(i) = 0:		mySalesTax(i) = 0
		myCostsAmnt(i) = 0:		myCostsTax(i) = 0
		myBenefit(i) = 0:		myCount(i) = 0
	next
	with recset
		'�����E�����E�e��
		strSql = "SELECT JobBelong, COUNT(JobCode) AS CNT, SUM(StandSum) AS TT, SUM(SalesSum) AS SA, SUM(SalesTax) AS ST"
		strSql = strSql & ", SUM(CostsSum) AS CA, SUM(CostsTax) AS CT, SUM(Interests) AS BT FROM TBL_CTM_JOB WHERE Deleted = 0"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if myType <> "" then strSql = strSql & " AND SUBSTRING(JobCode, 2, 1) = '" & myType & "'"
		strSql = strSql & " GROUP BY JobBelong"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		do while not .EOF
			myIdx = 0
			select case GetString(.fields("JobBelong"))
			case "C"	myIdx = 0
			case "K"	myIdx = 1
			case "O"	myIdx = 2
			case "T"	myIdx = 3
			case "M"	myIdx = 4
			end select
			myStandAmnt(myIdx) = myStandAmnt(myIdx) + GetLong(.fields("TT"))
			mySalesAmnt(myIdx) = mySalesAmnt(myIdx) + GetLong(.fields("SA"))
			mySalesTax(myIdx) = mySalesTax(myIdx) + GetLong(.fields("ST"))
			myCostsAmnt(myIdx) = myCostsAmnt(myIdx) + GetLong(.fields("CA"))
			myCostsTax(myIdx) = myCostsTax(myIdx) + GetLong(.fields("CT"))
			myBenefit(myIdx) = myBenefit(myIdx) + GetLong(.fields("SA")) - GetLong(.fields("CA"))
			myCount(myIdx) = myCount(myIdx) + GetLong(.fields("CNT"))
			.movenext
		loop
		.Close
		
		'�����������֕�
		strSql = "SELECT JobBelong, SUM(ExpenseAmount+ExpenseTax) AS TTL FROM TBL_CTM_JOB AS J"
		strSql = strSql & " INNER JOIN TBL_CTM_EXPENSE AS E ON J.JobCode = E.JobCode"
		strSql = strSql & " WHERE J.Deleted = 0 AND E.Deleted = 0 AND ExpenseType = " & gsStand
		strSql = strSql & " AND SUBSTRING(ExpenseBill, 3, 1) = 'C'"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if myType <> "" then strSql = strSql & " AND SUBSTRING(J.JobCode, 2, 1) = '" & myType & "'"
		strSql = strSql & " GROUP BY JobBelong"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		do while not .EOF
			myIdx = 0
			select case GetString(.fields("JobBelong"))
			case "C"	myIdx = 0
			case "K"	myIdx = 1
			case "O"	myIdx = 2
			case "T"	myIdx = 3
			case "M"	myIdx = 4
			end select
			myStandIn(myIdx) = myStandIn(myIdx) + GetLong(.fields("TTL"))
			.movenext
		loop
		.Close
		
		'�Г�������
		strSql = "SELECT ExpenseClient, SUM(ExpenseAmount) AS EA, SUM(ExpenseTax) AS ET FROM TBL_CTM_JOB AS J"
		strSql = strSql & " INNER JOIN TBL_CTM_EXPENSE AS E ON J.JobCode = E.JobCode"
		strSql = strSql & " WHERE J.Deleted = 0 AND E.Deleted = 0 AND ExpenseType = " & gsPayment
		strSql = strSql & " AND ExpenseClient IN ('" & gsCorpCode & "','" & gsCorpSoko & "')"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if myType <> "" then strSql = strSql & " AND SUBSTRING(J.JobCode, 2, 1) = '" & myType & "'"
		strSql = strSql & " GROUP BY ExpenseClient"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		do while not .EOF
			myIdx = 0
			select case GetString(.fields("ExpenseClient"))
			case gsCorpSoko:	myIdx = 4
			case gsCorpCode:	myIdx = 5
			end select
			myStandAmnt(myIdx) = myStandAmnt(myIdx) + GetLong(.fields("EA"))
			myStandIn(myIdx) = myStandIn(myIdx) + GetLong(.fields("ET"))
			myBenefit(myIdx) = myBenefit(myIdx) + GetLong(.fields("EA"))

			myCostsAmnt(6) = myCostsAmnt(6) - GetLong(.fields("EA"))
			myCostsTax(6) = myCostsTax(6) - GetLong(.fields("ET"))
			.movenext
		loop
		.Close
	end with
	
	'�S�Ѝ��v
	for i = 0 to 5
		if i < 4 then
			myStandAmnt(6) = myStandAmnt(6) + myStandAmnt(i)
			myStandIn(6) = myStandIn(6) + myStandIn(i)
		end if
		mySalesAmnt(6) = mySalesAmnt(6) + mySalesAmnt(i)
		mySalesTax(6) = mySalesTax(6) + mySalesTax(i)
		myCostsAmnt(6) = myCostsAmnt(6) + myCostsAmnt(i)
		myCostsTax(6) = myCostsTax(6) + myCostsTax(i)
		myBenefit(6) = myBenefit(6) + myBenefit(i)
		myCount(6) = myCount(6) + myCount(i)
	next
	
	myView = "1,2,3,4,5,6"
	response.write "<TR><TD rowspan=2 nowrap>"
	select case myType
	case gsExport
		response.write "�A�o����"
	case gsImport
		response.write "�A������"
	case "M", gsOther
		response.write "�ق�����"
		if AccountMonth >= "200701" then myView = "0," & myView
	case else
		response.write "�S�̎���"
		if AccountMonth >= "200701" then myView = "0," & myView
	end select
	response.write "<TD colspan=2 align=center>����"
	response.write "<TD colspan=2 align=center>����"
	response.write "<TD colspan=2 align=center>����"
	response.write "<TD colspan=2 align=center>�e��"
	response.write "<TD colspan=2 align=center>�⑫"
	response.write "<TR><TD nowrap>�����z"
	response.write "<TD nowrap>������"
	response.write "<TD nowrap>�Ŕ����z"
	response.write "<TD nowrap>�����"
	response.write "<TD nowrap>�Ŕ����z"
	response.write "<TD nowrap>�����"
	response.write "<TD nowrap>�Ŕ��e��"
	response.write "<TD nowrap>�e����"
	response.write "<TD nowrap>���������v"
	response.write "<TD nowrap>����ō��z"
	
	for i = 0 to 6
		select case JobBelong 
		case "K":	myView = "1,4,5"
		case "O":	myView = "2"
		case "T":	myView = "3"
		case "M":	myView = "4"
		end select 
		if instr(myView, i) <> 0 then
			myCharge = 0
			myRate = 0
			myTax = 0
			myFlag = true
			myColor = "black"
			if i = 4 or i = 5 then 
				myFlag = false
				myColor = "green"
				if myStandAmnt(i) + mySalesAmnt(i) <> 0 then myRate = myBenefit(i) / (myStandAmnt(i) + mySalesAmnt(i)) * 100
				myCharge = myStandAmnt(i) + myStandIn(i) + mySalesAmnt(i) + mySalesTax(i)
				myTax =myStandIn(i) - myCostsTax(i)
			else
				if mySalesAmnt(i) <> 0 then myRate = myBenefit(i) / mySalesAmnt(i) * 100
				myCharge = myStandIn(i) + mySalesAmnt(i) + mySalesTax(i)
				myTax = mySalesTax(i) - myCostsTax(i)
			end if
			
			response.write "<TR style=""color:" & myColor & """><TD nowrap>" & ShowShopName(i)
			response.write "<TD nowrap>" & formatnumber(myStandAmnt(i), 0, myFlag) & "<br>"
			response.write "<TD nowrap>" & formatnumber(myStandIn(i), 0, myFlag) & "<br>"
			response.write "<TD nowrap>" & formatnumber(mySalesAmnt(i), 0, myFlag) & "<br>"
			response.write "<TD nowrap>" & formatnumber(mySalesTax(i), 0, myFlag) & "<br>"
			response.write "<TD nowrap>" & formatnumber(myCostsAmnt(i), 0, myFlag) & "<br>"
			response.write "<TD nowrap>" & formatnumber(myCostsTax(i), 0, myFlag) & "<br>"
			response.write "<TD nowrap>" & formatnumber(myBenefit(i), 0, myFlag) & "<br>"
			response.write "<TD nowrap>" & formatnumber(myRate, 2, true) & "%<br>"
			response.write "<TD nowrap>" & formatnumber(myCharge, 0, true) & "<br>"
			response.write "<TD nowrap>" & formatnumber(myTax, 0, true) & "<br>"
		end if
	next
end function

function ShowShopName(myIdx)
	select case myIdx
	case 0:		ShowShopName = "��Г���"
	case 1:		ShowShopName = "�_�ˉc��"
	case 2:		ShowShopName = "���x�X"
	case 3:		ShowShopName = "�����x�X"
	case 4:		ShowShopName = "�ېőq��"
	case 5:		ShowShopName = "�{�ЋƖ�"
	case 6:		ShowShopName = "�S�Ѝ��v"
	end select
end function
%>