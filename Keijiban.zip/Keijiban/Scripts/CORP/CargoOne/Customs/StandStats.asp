<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/Function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����߃`�F�b�N���
'----------------------------------------------

'on error resume next
		
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 3 then
		if CheckTopLevel() > 0 then myLevel = 4
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�a����ꗗ</TITLE>	
</HEAD>

<BODY class=pt9 <%=gsBodyControl%>>
  <center>
  	<br>
	<table width=98% class=pt9n cellspacing=3>
	  <tr><td align=center>�a����c���ꗗ (<b><%=ShowDateTimeShort(now)%></b>����)
	</table>
	<br>
	<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>
	  <colgroup span=2 align=center>
	  <colgroup align=right>
	  <colgroup align=center>
	  <tr height=24 align=center bgcolor="#FFFFE0">
	  	<td nowrap>�׎�
	  	<td nowrap>�X�V��
	  	<td nowrap>�a����c��
	  	<td nowrap>�c��
<%
	'���֐��������
	with Recset
		strSql = "SELECT * FROM "
		strSql = strSql & "(SELECT FIN_NO, FIN_DATE, FIN_CLIENT_CD AS CD, FIN_CLIENT_NAME, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT "
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_CURRENT = 0 AND (FIN_DEBIT = 33 OR FIN_CREDIT = 33))"
		strSql = strSql & " AS F INNER JOIN (SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_SALESMNGR FROM CUSTOMER WHERE CTM_DELETED = 0"
		if myLevel < 4 then
			if myLevel = 3 or CheckAccountLevel() > 0 then
				strSql = strSql & " AND CTM_BELONG = '" & UserShop & "'"
			else
				strSql = strSql & " AND CTM_SALESMNGR = " & WebUserID
			end if
		end if
		strSql = strSql & ") AS C ON F.CD = C.CTM_CD ORDER BY CTM_SALESMNGR, CTM_REF, FIN_DATE, FIN_NO"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<tr height=30><td colspan=8>�a���c���Ȃ�</font>"
		else
			sum = 0:		total = 0
			CTM_CD = "":	CTM_NAME = "":	CTM_REF = "":	Salesman = ""
			do while not .eof
				if CTM_CD <> GetString(.fields("CTM_CD")) then
					if sum <> 0 then
						response.write "<tr height=24><TD style=""cursor:help"" title='" & CTM_NAME & "'>" & CTM_REF
						response.write "<td>" & Str2YMD(myDate) & "<td>" & formatnumber(sum, 0, true)
						response.write "<td>" & GetEmployName(Salesman, "F")
						total = total + sum
						sum = 0
					end if
					CTM_CD = GetString(.fields("CTM_CD"))
					CTM_REF = GetString(.fields("CTM_REF"))
					if CTM_CD = gsDummy then
						CTM_NAME = GetString(.fields("FIN_CLIENT_NAME"))
					else
						CTM_NAME = GetString(.fields("CTM_NAME"))
					end if
					Salesman = GetLong(.fields("CTM_SALESMNGR"))
				end if
				myDate = GetString(.fields("FIN_DATE"))
				if GetLong(.fields("FIN_DEBIT")) = 33 then
					sum = sum - GetLong(.Fields("FIN_AMOUNT"))
				elseif GetLong(.fields("FIN_CREDIT")) = 33 then
					sum = sum + GetLong(.Fields("FIN_AMOUNT"))
				end if
				.movenext
			loop
			if CTM_CD <> "" and sum <> 0 then
				total = total + sum
				response.write "<tr height=24><TD style=""cursor:help"" title='" & CTM_NAME & "'>" & CTM_REF
				response.write "<td>" & Str2YMD(myDate) & "<td>" & formatnumber(sum, 0, true)
				response.write "<td>" & GetEmployName(Salesman, "F")
			end if
			if total <> 0 then
				response.write "<tr height=24 bgcolor=#FFFFE0><TD colspan=2>���v���z"
				response.write "<td>" & formatnumber(total, 0, true) & "<td><br>"
			end if
		end if
		.close
	end with
%>
	</table>
  </center>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>