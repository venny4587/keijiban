<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�q�ʎc�����ڏƉ���
'----------------------------------------------
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
		
	JobBelong = GetPost(request("JobBelong"))
	JobSalesman = GetLong(request("JobSalesman"))
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 4  then JobBelong = UserShop
	
	mode = GetLong(request("mode"))
	if mode > 0 then
		Salesman = GetLong(request("Salesman"))	
		ClientRef = GetPost(request("ClientRef"))
		ClientCode = GetCtmCode(ClientRef, 0)
		Continued = GetLong(request("Continued"))
	else
		Continued = 0
		if myLevel < 4  then JobSalesman = WebUserID
	end if
%>

<HTML>
<HEAD>
	<TITLE>�q�ʎc���ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		sub InitForm()
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ReportMonthlyShift.asp" ID=frmInput NAME=frmInput>
		<table class=pt9>
			<TR><TD nowrap>�Ɩ�����
<%if myLevel > 3 then%>
	  			<select name=JobBelong onkeydown="ResetEnter()"><option value="">�S��<%=ShowShopList(JobBelong)%></select>&nbsp;
<%else%>
					<input type=hidden name="JobBelong" value="<%=JobBelong%>">
					<u>&nbsp;<font color=green><%=GetShopName(JobBelong)%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�敪&nbsp;
					<SELECT name="mode" onkeydown="ResetEnter()">
						<option value="1" <%if mode = 1 then response.write "selected"%>>��
						<option value="2" <%if mode = 2 then response.write "selected"%>>�x
					</select>
				���Ӑ�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�c�ƒS��&nbsp;
<%if myLevel > 2 then%>
					<select name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
						<%=ShowEmployList(DepartSales, JobSalesman)%>
					</select>&nbsp;
<%else%>
					<input type=hidden name="JobSalesman" value="<%=JobSalesman%>">
					<u>&nbsp;<font color=green><%=GetEmployName(JobSalesman, "F")%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				�c������̂�<input type=checkbox name="Continued" value=1 <%if Continued <> 0 then response.write "checked"%>>
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
	
<%if mode > 0 then%>
<div id=list>
<%if ClientCode <> "" then response.write "<font color=gray>���Ӑ�F</font>" & getFullName(ClientCode)%>
<%if Salesman <> 0 then response.write "<font color=gray>�c�ƒS���F</font>" & getEmployName(JobSalesman, "F")%>
	<table cellpadding=2 cellspacing=0 border=1 class=pt9n width=800>
		<colgroup align=left>
		<colgroup align=center>
<%if mode = 1 then%>
		<colgroup span=3 align=right bgcolor="#FFF0F0">
		<colgroup span=3 align=right>
<%end if%>
<%if mode = 2 then%>
		<colgroup span=3 align=right bgcolor="#F0FFF0">
		<colgroup span=3 align=right>
<%end if%>
		<TR bgcolor="#E0E0E0">
			<TD rowspan=2 align=center>�׎喼
			<TD rowspan=2 align=center>���x
<%if mode = 1 then%>
			<TD colspan=3 align=center>���@�|
			<TD colspan=3 align=center>���ւq
<%end if%>
<%if mode = 2 then%>
			<TD colspan=3 align=center>���@�|
			<TD colspan=3 align=center>���ւo
<%end if%>
		<TR>
<%if mode = 1 then%>
			<TD nowrap>����
			<TD nowrap>����
			<TD nowrap>�c��
			<TD nowrap>����
			<TD nowrap>����
			<TD nowrap>�c��
<%end if%>
<%if mode = 2 then%>
			<TD nowrap>����
			<TD nowrap>�x��
			<TD nowrap>�c��
			<TD nowrap>����
			<TD nowrap>�x��
			<TD nowrap>�c��
<%end if%>

<%
	cnt = 0
	CTM_CD = ""
	with recset
		strSql = "SELECT * FROM CTM_ACCOUNT AS A INNER JOIN (SELECT CTM_CD AS CTM_CODE, CTM_NAME, CTM_SALESMNGR, CTM_BELONG FROM CUSTOMER"
		strSql = strSql & ") AS C ON A.CTM_CD = C.CTM_CODE WHERE ACCOUNT_MONTH <= '" & CheckAccountMonth() & "'" 
		if Continued = 1 then
			if mode = 1 then strSql = strSql & " AND (BALANCE_SALES <> 0 OR BALANCE_STANDR <> 0)"
			if mode = 2 then strSql = strSql & " AND (BALANCE_COSTS <> 0 OR BALANCE_STANDP <> 0)"
		end if
		if mode = 1 then strSql = strSql & " AND (AMOUNT_SALES+RECEIVE_SALES+BALANCE_SALES+AMOUNT_STANDR+RECEIVE_STANDR+BALANCE_STANDR) <> 0"
		if mode = 2 then strSql = strSql & " AND (AMOUNT_COSTS+PAYMENT_COSTS+BALANCE_COSTS+AMOUNT_STANDP+PAYMENT_STANDP+BALANCE_STANDP) <> 0"
		if ClientCode <> "" then 
			if ClientCode = "690" then	
				strSql = strSql & " AND CTM_CD LIKE '690%'"
			else
				strSql = strSql & " AND CTM_CD = '" & ClientCode & "'"
			end if
		end if
		if JobBelong <> "" then strSql = strSql & " AND C.CTM_BELONG = '" & JobBelong & "'"
		if JobSalesman <> 0 then strSql = strSql & " AND CTM_SALESMNGR = " & JobSalesman & ""
		strSql = strSql & " ORDER BY CTM_CD, ACCOUNT_MONTH"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		do while not .EOF
			if GetString(.fields("CTM_CD")) = gsDummy then
				ClientName = "RANDOM"
			else
				ClientName = ResetCorpName(.fields("CTM_NAME"))	
			end if
			if CTM_CD <> "" and CTM_CD <> GetString(.fields("CTM_CD")) then
				cnt = cnt + 1
				response.write "<TR><TD colspan=8 bgcolor=white align=center>��" & cnt & " -- �������F" & GetRefName(CTM_CD)
				'response.write "�@�c�ƒS���F" &  GetEmployName(GetSalesManager(CTM_CD), "F")				'���SQL���ߎ~�߂�
			end if
			CTM_CD = GetString(.fields("CTM_CD"))
			ACCOUNT_MONTH = GetString(.Fields("ACCOUNT_MONTH"))
			if ACCOUNT_MONTH = left(Date2Str(date), 6) then
				mycolor = "gray"
			else
				mycolor = "black"
			end if
%>
		<TR style="color:<%=mycolor%>" <%if GetString(.fields("CTM_CD")) = gsDummy then%>bgcolor=#E0E0E0<%end if%>>
			<TD nowrap><%=StringCut(ClientName, 20)%>
			<TD nowrap><%=GetString(.Fields("ACCOUNT_MONTH"))%>
<%if mode = 1 then%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_SALES")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("RECEIVE_SALES")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_SALES")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_STANDR")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("RECEIVE_STANDR")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_STANDR")), 0, true)%>
<%end if%>
<%if mode = 2 then%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_COSTS")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("PAYMENT_COSTS")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_COSTS")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_STANDP")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("PAYMENT_STANDP")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_STANDP")), 0, true)%>
<%end if%>
<%			
			.movenext
		loop
		.Close
	end with
%>
	</TABLE>
</div>
<%end if%>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>