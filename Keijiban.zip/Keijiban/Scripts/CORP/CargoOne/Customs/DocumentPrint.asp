<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
dim myPageSize
	myPageSize = 20

	strSel = GetString(session("Doc_Print_Sel"))

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

	JobCount = 0
	with recset
		strSQL = "SELECT JobClient, CustomBroker, COUNT(JobCode) AS JobCount FROM ("
		strSQL = strSQL & "SELECT JobCode, JobClient, ClientRef, CustomBroker, BrokerRef, ShipCorp, PermitDate, PermitNo"
		strSQL = strSQL & ", CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit & "' ELSE JobBelong END AS JobBelong"
		strSQL = strSQL & ", ObtainDate, ReturnDate, CASE ReturnDate WHEN '' THEN 1 ELSE 0 END AS FinisherID FROM TBL_CTM_JOB AS J"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON J.CustomBroker = B.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0) AS TMP"
		if CheckTopLevel() = 0 then 
			strSql = strSql & " WHERE JobBelong = '" & UserShop & "'" & strSel
		else
			if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel,5)
		end if
		strSQL = strSQL & " GROUP BY JobClient, CustomBroker"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
			JobClient = GetString(.fields("JobClient"))
			do while not .eof
				if JobClient <> GetString(.fields("JobClient")) then
					JobClient = GetString(.fields("CustomBroker"))
				end if
				.movenext
			loop
		end if
		.Close
		
		strSql = "SELECT CTM_NAME, CTM_REF, CTM_ZIP, CTM_ADDR1, CTM_ADDR2, CTM_SALESMNGR FROM CUSTOMER WHERE CTM_CD = '" & JobClient & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then 
			 CTM_REF = GetString(.fields("CTM_REF"))
			 CTM_NAME = GetString(.fields("CTM_NAME"))
			 CTM_SALESMNGR = GetString(.fields("CTM_SALESMNGR"))
			 CTM_ZIP = GetString(.fields("CTM_ZIP"))
			 CTM_ADDR1 = GetString(.fields("CTM_ADDR1"))
			 CTM_ADDR2 = GetString(.fields("CTM_ADDR2"))
		end if
		.close
	end with
%>
<HTML>
<HEAD>
	<TITLE>�[�t���ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r ����; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r ����; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 12pt; LINE-HEIGHT: 1.2em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 14pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>	
<!--�w�b�_-->
  <table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
  <tr><td height=880 valign=top align=center>
	<table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <tr><td width=150>
	 	<td width=320 class=pth align=center><u>&nbsp;&nbsp; �[ �t �� �� ��&nbsp;&nbsp;</u>
	  	<td width=150 align=right><%=formatDateJP(Date)%>
	</table>
	<br>
	<table width=640 cellspacing=0 cellpadding=0>
	  <tr>
		<td width=340 valign=top class=ptm>
			<table width=90% Cellspacing=0 CellPadding=0 class=ptm>
		  	  <tr height=20><td>�� <%=CTM_ZIP%><br><%=CTM_ADDR1%><br><%=CTM_ADDR2%><br><%=CTM_NAME%> �䒆<br>
		  	  <tr height=20><td><hr size=1 color=black>
 			</table>
 			(<%=CTM_REF%>)
		<td width=300 valign=top align=right>
		  <table Cellspacing=0 CellPadding=0 class=ptm>
			<tr align=right>
				<td width=130><img src=img/logo.jpg>
				<td nowrap><font class=pth><b><%=gsPrintHead%></b></font>
		  	<tr align=right>
		  		<td colspan=2 class=ptt nowrap align=right><%=gsPrintAddr%>
 		  </table>
	</table>
	
<%
	with Recset
		strSQL = "SELECT JobCode, JobClient, PermitDate, PermitNo, Vessel, Voy, Quantity, Package FROM ("
		strSQL = strSQL & "SELECT JobCode, JobClient, ClientRef, CustomBroker, BrokerRef, ShipCorp, Vessel, Voy, Quantity, Package, PermitNo"
		strSQL = strSQL & ", CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit & "' ELSE JobBelong END AS JobBelong"
		strSQL = strSQL & ", PermitDate, ObtainDate, ReturnDate, CASE ReturnDate WHEN '' THEN 1 ELSE 0 END AS FinisherID FROM TBL_CTM_JOB AS J"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON J.CustomBroker = B.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0) AS TMP"
		if CheckTopLevel() = 0 then 
			strSql = strSql & " WHERE JobBelong = '" & UserShop & "'" & strSel
		else
			if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel,5)
		end if
		strSQL = strSQL & " ORDER BY JobCode"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
			cnt = 0
			do while not .eof
				cnt = cnt + 1
				select case cnt 
				case 1, 29, 66, 103, 140, 177, 214, 251
					if cnt <> 1 then
%>
	  	<TR><td colspan=7><hr color=black size=1>
	</TABLE>
<%
					end if
%>

	<TABLE width=640 Cellspacing=3 CellPadding=3 class=pts>
		<colgroup span=2 align=center>
		<colgroup align=left>
		<colgroup align=right>
		<colgroup align=left>
		<colgroup span=2 align=center>
	  	<TR><td colspan=7><hr color=black size=1>
		<TR valign=bottom>
			<TD class=gline width=30>��
			<TD class=gline width=90>�䒠�ԍ�
			<TD class=gline width=200>�q�֖�
			<TD class=gline width=50>��
			<TD class=gline width=80>�׎p
			<TD class=gline width=80>����
			<TD class=gline width=100>������
<%
				end select
				JobCode = GetString(.Fields("JobCode"))	
				PermitDate = GetString(.Fields("PermitDate"))
				PermitNo = GetString(.Fields("PermitNo"))
%>
		<TR>
			<TD><%=cnt%>
			<TD nowrap><%=JobCode%><BR>
			<TD nowrap><%=GetString(.fields("Vessel")) & " V." & GetString(.fields("Voy"))%><BR>
			<TD nowrap><%=GetDouble(.fields("Quantity"))%><BR>
			<TD nowrap><%=GetString(.fields("Package"))%><BR>
			<TD nowrap><%=Str2Date(PermitDate)%><BR>
			<TD nowrap><%=PermitNo%><BR>
<%
				.movenext
			loop
			if cnt > 1 then
%>
	  	<TR><td colspan=7><hr color=black size=1>
		<TR><TD colspan=6 align=right>���v
			<TD><%=formatnumber(cnt, 0, true)%>��
	  	<TR><td colspan=7><hr color=black size=1>
<%
			end if
%>
	  	<TR><td colspan=6 align=left valign=top>���t��̌�A�������܂����AFAX�ɂĕԐM���肢�܂��B<br><br>FAX: <%=GetShopFax(UserShop)%>
	  		<td align=right><table cellspacing=2 cellpadding=2 width=100 height=50 class=pt9><tr><td class=bline align=center>�@�@�@��</table>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�������f�[�^�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>
