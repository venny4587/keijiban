<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
	
	JobType = ""				'�q�ɔ��p
	if instr(session("Depart"), "�A��") <> 0 then JobType = gsImport
	if instr(session("Depart"), "�A�o") <> 0 then JobType = gsExport
	
	ChargeSort = GetLong(request("sort"))
	SearchDate = GetDate(request("SearchDate"))
	if SearchDate = "" then SearchDate = formatDate(date)
	
	myType = GetLong(request("type"))
	myView = 0
	select case WebUserID
	case 51, 52
		myView = 1
	end select
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�������ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>	
		sub SearchDate_OnBlur()
			SearchDate.value = setdate(SearchDate.value)
		end sub
	
		function DoSelect()
			window.location.href = "ChargeResult.asp?type=<%=myType%>&SearchDate=" & cstr(SearchDate.value)
		end function
		
		function DoSort(myNo)
			window.location.href = "ChargeResult.asp?type=<%=myType%>&sort=" & myNo & "&SearchDate=" & cstr(SearchDate.value)
		end function
		
		function ShowJob(Job, No)
		dim win
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & Job & "&ChargeNo=" & No,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td nowrap width=40%>��<%
	  	  	select case myType 
	  	  	case 0:		response.write "�쐬��"
	  	  	case 1:		response.write "�m���"
	  	  	case 2:		response.write "������"
	  	  	end select%>�ꗗ&nbsp;
	  	  <td nowrap width=60%><%
	  	  	select case myType 
	  	  	case 0:		response.write "�쐬��"
	  	  	case 1:		response.write "�m���"
	  	  	case 2:		response.write "������"
	  	  	end select%>
			<input class=si name="SearchDate" size=10 maxlength=10 value="<%=SearchDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<img style="cursor:hand" src=img/search.jpg alt="���t�I��" onmousedown="DoSelect()">
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT JobCode, ChargeNo, ChargeType, ClientRef, ChargeClientName, ChargePic, ChargeCheck, ChargeBelong"
		strSql = strSql & ", ChargeAmount, ChargeTax, ChargeDate, ChargePayDay, ConfirmerID FROM TBL_CTM_CHARGE AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0"
		if CheckTopLevel() = 0 and myView = 0 then strSql = strSql & " AND SUBSTRING(JobCode,1,1) = '" & UserShop & "'"
		if JobType <> "" then strSql = strSql & " AND SUBSTRING(JobCode, 2, 1) = '" & JobType & "'"
		select case myType
		case 0:		strSql = strSql & " AND CONVERT(VARCHAR(10), Created, 111) = '" & SearchDate & "'"
		case 1:		strSql = strSql & " AND CONVERT(VARCHAR(10), ConfirmDate, 111) = '" & SearchDate & "'"
		case 2:		strSql = strSql & " AND CONVERT(VARCHAR(10), FinishDate, 111) = '" & SearchDate & "'"
		end select
		select case ChargeSort
		case 0:		strSql = strSql & " ORDER BY ChargeNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, ChargeNo"
		case 2:		strSql = strSql & " ORDER BY ClientRef, JobCode"
		end select
if WebUserID = gsAdmin then response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		<colgroup span=3 align=left>
		<colgroup align=center>
		<colgroup align=right>
		<colgroup align=left>
		<colgroup span=2 align=center>
	  <TR height=20 class=pt9>
		<TD class=line nowrap align=center colspan=2 style="cursor:hand;color:blue" onmousedown="DoSort(0)">�����ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap>������
		<TD class=line nowrap>�������z
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">������
<%if myType = 0 then%>
		<TD class=line nowrap>����
<%else%>
		<TD class=line nowrap>������
<%end if%>
		<TD class=line nowrap>�敪
<%
			cnt = 0:	SeqNo = 0
			ttlAmount = 0:	ttlTax = 0:	ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode"))
				ChargeNo = GetString(.Fields("ChargeNo"))				
				ClientRef = GetString(.Fields("ClientRef"))	
				ClientName = GetString(.Fields("ChargeClientName"))
				if GetLong(.Fields("ChargeCheck")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=red>��</font>"
				end if
%>
				<TR align=center height=20>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowJob('<%=JobCode%>','<%=ChargeNo%>')">
					<TD nowrap class=line><%=ShowVoucherNo(ChargeNo)%><BR>
					<TD nowrap class=line><%=ShowJobCode(JobCode)%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("ChargeDate"))%><BR>
					<TD nowrap class=line><%=formatnumber(GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax")), 0, true)%><BR>
					<TD nowrap class=line style="cursor:help" title="<%=ClientName%>"><%=StringCut(ClientRef,7)%><BR>
<%if myType = 0 then%>
					<TD nowrap class=line><%=status%><BR>
<%else%>
					<TD nowrap class=line><%=Str2MD(.Fields("ChargePayDay"))%><BR>
<%end if%>
					<TD nowrap class=line><%=ShowBillType(.Fields("ChargeType"))%><BR>
<%
				if GetLong(.Fields("ChargeTax")) = 0 then 
					ttlTaxFree = ttlTaxFree + GetLong(.Fields("ChargeAmount")) 
				else
					ttlTax = ttlTax + GetLong(.Fields("ChargeTax"))
					ttlAmount = ttlAmount + GetLong(.Fields("ChargeAmount"))
				end if
				.movenext
			loop
			if cnt > 1 then
%>
				<TR height=20>
					<TD colspan=3 align=right class=pt9>�������v
					<TD colspan=2 align=right class=line><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y���������͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
