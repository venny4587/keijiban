<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next	
dim ChargeNo

dim CloseSales
dim CloseStand
dim SalesCloseDate
dim StandCloseDate

dim CloseMode
dim CloseDateFrom
dim CloseDateTo

ChargeSort = GetLong(request("sort"))
ChargeNos = GetPost(request("nos"))
if ChargeNos <> "" then

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	set myRec = Server.CreateObject("adodb.recordset") 
	
	myChargeNos = ResetBizNos(ChargeNos)
	with recset
		sumCount = 0
		sumTotal = 0
		BatchDate = ""
		strSql = "SELECT COUNT(ChargeNo) AS CNT, SUM(ChargeAmount + ChargeTax) AS TTL, MAX(ChargeDate) AS DT"
		strSql = strSql & ",SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN '" & gsExport & "' THEN 1 ELSE 0 END) AS EX"
		strSql = strSql & ",SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN '" & gsExport & "' THEN 0 ELSE 1 END) AS IM"
		strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeNo IN (" & myChargeNos & ")"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then 
			JobCode = GetString(.Fields("JobCode"))
			sumCount = GetLong(.Fields("CNT"))
			sumTotal = GetLong(.Fields("TTL"))
			BatchDate = Str2Date(.Fields("DT"))
			if GetLong(.fields("EX")) = 0 then
				myTitle = "�A ��"
			elseif GetLong(.fields("IM")) = 0 then
				myTitle = "�A �o"
			else
				myTitle = ""
			end if
		end if
		.Close		
		
		strSql = "SELECT ChargeNo, JobCode, ChargeType, ChargeAmount, ChargeTax, ChargeClient, ChargeClientName, ChargePic"
		strSql = strSql & ", ChargeBatch, ChargeDate, ChargePayDay, Vessel, Voy, ReferNo, InvoiceNo FROM TBL_CTM_CHARGE AS C"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, Vessel, Voy, ReferNo, InvoiceNo FROM TBL_CTM_JOB) AS J ON C.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND ChargeNo IN (" & myChargeNos & ")"
		strSql = strSql & " ORDER BY JobCode"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			BatchNo = GetString(.Fields("ChargeBatch"))
			ChargePic = GetString(.Fields("ChargePic"))
			ChargeClient = GetString(.Fields("ChargeClient"))
			ClientName = GetString(.Fields("ChargeClientName"))
			
			strSql = "SELECT CTM_REF, CTM_ZIP, CTM_ADDR1, CTM_ADDR2, CTM_SALESMNGR FROM CUSTOMER WHERE CTM_CD = '" & ChargeClient & "'"
			myRec.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not myRec.eof then 
				 CTM_REF = GetString(myRec.fields("CTM_REF"))
				 CTM_SALESMNGR = GetString(myRec.fields("CTM_SALESMNGR"))
				 CTM_ZIP = GetString(myRec.fields("CTM_ZIP"))
				 CTM_ADDR1 = GetString(myRec.fields("CTM_ADDR1"))
				 CTM_ADDR2 = GetString(myRec.fields("CTM_ADDR2"))
			end if
			myRec.close
			
			'�ڋq�����ʏ���
			if ChargeClient = gsDummy then
				CTM_NAME = ChargeClientName
				CTM_ADDR1 = GetLeft(ChargeMemo, vbcrlf)
				CTM_ADDR2 = GetRight(ChargeMemo, vbcrlf)
				ChargeMemo = ""
			else
				
			end if
			
			if GetCtmClose(ChargeClient, CloseSales, CloseStand, CloseCosts) then
				SalesClose = ShowClose(CloseSales)
				StandClose = ShowClose(CloseStand)
				SalesCloseDate = Close2Date(CloseSales, BatchDate)
				StandCloseDate = Close2Date(CloseStand, BatchDate)
			end if
			
			if instr(myChargeNos, gsInitial & "C") = 0 then
				ChargeType = 2
				myTitle = myTitle & " �� ��"
				CloseMode = CloseStand
				CloseDateTo = cdate(StandCloseDate)
				CloseDateFrom = GetStartDate(CloseStand, CloseDateTo)
			else
				ChargeType = 1
				myTitle = myTitle & " �� ��"
				CloseMode = CloseSales
				CloseDateTo = cdate(SalesCloseDate)
				CloseDateFrom = GetStartDate(CloseSales, CloseDateTo)
			end if
%>
<HTML>
<HEAD>
	<TITLE>�������\��</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }
		
		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r ����; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r ����; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: �l�r ����; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 16pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
  <table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
  <tr><td height=880 valign=top align=center>
	<table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <tr><td width=150><%if BatchNo <> "" then response.write BatchNo%>�@(<%=ChargeClient%>)
	 	<td width=340 class=pth align=center><u>&nbsp;&nbsp;<%=myTitle%> �W �v �\&nbsp;&nbsp;</u>
	  	<td width=150 align=right><%=formatDateJP(CloseDateTo)%>
	</table>
	<br>
	<table width=640 cellspacing=0 cellpadding=0>
	  <tr>
		<td width=340 valign=top class=ptm>
		  <table width=96% Cellspacing=0 CellPadding=0 class=ptm>
		  	  <tr height=20><td>�� <%=CTM_ZIP%><br><%=CTM_ADDR1%><br><%=CTM_ADDR2%><br><br>
		  	  	<font class=ptl><%=ClientName%> �䒆</font>
		  	  <tr height=20><td><hr size=1 color=black>
 		  </table>
<%if CloseMode = 99 then%>
 		  ���L�̒ʂ� <%=month(BatchDate)%> �����������\���グ�܂��B
<%else%>
 		  ���L�̒ʂ� <%=month(CloseDateFrom) & "/" & day(CloseDateFrom)%>�`<%=month(CloseDateTo) & "/" & day(CloseDateTo)%> �������\���グ�܂��B
<%end if%>
 		  <br><br>
 		  <font class=ptx><u>���v���z�@�@\<%=formatnumber(sumTotal, 0 ,true)%> </u></font><br><br>
 		  �������� <%=sumCount%> ���i���וʎ��̒ʂ�j
		<td width=300 valign=top align=right>
		  <table Cellspacing=0 CellPadding=0 class=ptm>
			<tr align=right>
				<td width=130><img src=img/logo.jpg>
				<td nowrap><font class=pth><b><%=gsPrintHead%></b></font>
		  	<tr align=right>
		  		<td colspan=2 class=ptt nowrap align=right><%=gsPrintAddr%>
 		  </table><br>
		  <table width=100% class=pts>
			<colgroup align=right>
			<tr><td nowrap>�U����s�@�@<b>�f����s �f���x�X ������ 88888888</b>
		  </table>
	</table>
	<TABLE width=640 Cellspacing=3 CellPadding=3 class=ptm>
		<colgroup align=center>
		<colgroup span=3 align=left>
		<colgroup span=3 align=right>
  	  <TR><td colspan=7><hr color=black size=1>
	  <TR>
		<TD class=gline width=20>��
		<TD class=gline width=70>�䒠�ԍ�
		<TD class=gline width=180>�D�@�@��
		<TD class=gline width=100 nowrap>�C���{�C�X�ԍ�
		<TD class=gline width=90>�Ŕ����z
		<TD class=gline width=70>�����
		<TD class=gline width=100>�ō����z
<%
			cnt = 0:	SeqNo = 0
			ttlAmount = 0:	ttlTax = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode"))
				ChargeNo = GetString(.Fields("ChargeNo"))
				'Vessel = left(GetString(.Fields("Vessel")) & " V." & GetString(.Fields("Voy")), 24)
				Vessel = left(GetString(.Fields("Vessel")), 24)
				if left(ChargeClient, 3) = "690" and myDivision = gsImport or left(ChargeClient, 4) = "7013" then
					InvoiceNo = GetString(.Fields("ReferNo"))
				else
					InvoiceNo = GetString(.Fields("InvoiceNo"))
				end if
				ChargeBatch = GetString(.Fields("ChargeBatch"))
%>
		<TR><TD nowrap><%=cnt%>
			<TD nowrap><%=JobCode%><BR>
			<TD><%=Vessel%><BR>
			<TD><%=InvoiceNo%><BR>
			<TD nowrap>\<%=formatnumber(GetLong(.Fields("ChargeAmount")), 0, true)%><BR>
<%if GetLong(.Fields("ChargeTax")) <> 0 then%>
			<TD nowrap>\<%=formatnumber(GetLong(.Fields("ChargeTax")), 0, true)%><BR>
<%else%>
			<TD nowrap><BR>
<%end if%>
			<TD nowrap>\<%=formatnumber(GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax")), 0, true)%><BR>
<%
				ttlTax = ttlTax + GetLong(.Fields("ChargeTax"))
				ttlAmount = ttlAmount + GetLong(.Fields("ChargeAmount"))
				.movenext
			loop
			.Close
			if cnt > 1 then
				if left(ChargeClient, 3) = "690" and myDivision <> gsExport then
					myKensyu = 0
					strSql = "SELECT SUM(ExpenseAmount+ExpenseTax) AS TTL FROM TBL_CTM_EXPENSE AS E"
					strSql = strSql & " INNER JOIN TBL_CTM_CHARGE AS C ON E.ExpenseBill = C.ChargeNo "
					strSql = strSql & " WHERE E.Deleted = 0 AND C.Deleted = 0 AND E.ExpenseAttr = 0 "
					strSql = strSql & " AND ChargeNo IN (" & myChargeNos & ")"
					myRec.Open strSql, Conn, adOpenKeyset, adLockReadOnly
					if not myRec.eof then myKensyu = GetLong(myRec.fields("TTL"))
					myRec.close
				end if
%>
  		<TR><td colspan=7><hr color=black size=1>
<%if left(ChargeClient, 3) = "690" and myDivision <> gsExport then%>
		<TR><TD colspan=2>�i�d�������v
			<TD>\<%=formatnumber(myKensyu, 0, true)%>�j
			<TD align=right>���v���z
<%else%>
		<TR><TD colspan=4>���v���z
<%end if%>
			<TD class=line>\<%=formatnumber(ttlAmount, 0, true)%>
			<TD class=line>\<%=formatnumber(ttlTax, 0, true)%>
			<TD class=line>\<%=formatnumber(ttlAmount + ttlTax, 0, true)%>
<%
			end if
%>
		<TR><td colspan=7><hr color=black size=1>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�������f�[�^�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>
<%
		set recset = nothing
		CloseDB Conn
		
	end if
%>

<%
function GetStartDate(num, myDate)
dim buf
	if num < 31 then 
		buf = dateadd("m", -1, myDate)
	elseif num = 70 then 
		buf = dateadd("d", -7, myDate)
	elseif num = 100 then
	    select case day(myDate)
	    case 10, 20
			buf = dateadd("d", -10, myDate)
	    case else
		    buf = cdate(year(myDate) & "/" & month(myDate) & "/20")
	    end select
	elseif num = 150 then 
	    select case day(myDate)
	    case 15
			buf = dateadd("d", -15, myDate)
	    case else
		    buf = cdate(year(myDate) & "/" & month(myDate) & "/15")
	    end select
	end if
	GetStartDate = dateadd("d", 1, buf)
end function
%>