<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�x���`�[�ޯ��ꗗ�Ɖ���
'----------------------------------------------

'on error resume next
dim JobSeq
dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(15)
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		CostsFinish = 0
		if gsSysAccountDay = 99 then 
'			DateFrom = Str2Date(left(Date2Str(date),6) & "01")
		else
			myDate = dateadd("m", -1, date)
			DateFrom = cdate(year(myDate) & gsDateSign & month(myDate) & gsDateSign & (gsSysAccountDay + 1))
		end if
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		PayDayFrom = GetPost(request("PayDayFrom"))
		PayDayTo = GetPost(request("PayDayTo"))
		JobCode = GetPost(request("JobCode"))
		CostsNo = GetPost(request("CostsNo"))
		CostsBillNo = GetPost(request("CostsBillNo"))
		CostsBatch = GetPost(request("CostsBatch"))
		CostsFinish = GetLong(request("CostsFinish"))
	end if
	
	myLevel = CheckUserLevel(UserShop, "")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�x���`�[�o�b�`�Ǘ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "ClientRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myBatch, myNo, myType)
			window.parent.parent.result.location.href = "CostsBatchList.asp?mode=1&BatchNo=" & myBatch & "&Sel=" & myNo & "&Type=" & myType
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub PayDayFrom_OnBlur()
			frmInput.PayDayFrom.value = setdate(frmInput.PayDayFrom.value)
		end sub
		sub PayDayTo_OnBlur()
			frmInput.PayDayTo.value = setdate(frmInput.PayDayTo.value)
		end sub		
		sub CostsBatch_OnBlur()
			frmInput.CostsBatch.value = FitBatchNo(frmInput.CostsBatch.value)
		end sub
		sub CostsNo_OnBlur()
			frmInput.CostsNo.value = FitCostsNo(frmInput.CostsNo.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
			window.parent.parent.result.location.href = "../common/blank.htm"
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CostsBillBatch.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='<%=lngPageNumber%>'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�퐿����<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�x����<input class=si name="PayDayFrom" value="<%=PayDayFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="PayDayTo" value="<%=PayDayTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�x����<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
			<TR><TD nowrap>
				�ޯ��� <input class=sn name="CostsBatch" value="<%=CostsBatch%>" maxlength=6 size=6 onkeydown="ResetEnter()">
				�`�[�ԍ�<input class=si name="CostsNo" value="<%=CostsNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">	
				���臂<input class=si name="CostsBillNo" value="<%=CostsBillNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				<input type=checkbox name="CostsFinish" value="1" <%if CostsFinish then response.write " checked"%>>
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if ClientRef <> "" then	strSel = strSel & " AND ClientRef = '" & FitSel(ClientRef) & "'"
	if DateFrom <> "" then strSel = strSel & " AND CostsDate >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND CostsDate <= '" & Date2Str(DateTo) & "'"	
	if PayDayFrom <> "" then strSel = strSel & " AND CostsPayDay >= '" & Date2Str(PayDayFrom) & "'"
	if PayDayTo <> "" then strSel = strSel & " AND CostsPayDay <= '" & Date2Str(PayDayTo) & "'"	
	if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'"
	if CostsBillNo <> "" then strSel = strSel & " AND CostsBillNo LIKE '%" & FitSel(CostsBillNo) & "%'"	
	if CostsBatch <> "" then strSel = strSel & " AND CostsBatch = '" & FitSel(CostsBatch) & "'"
	if CostsNo <> "" then strSel = strSel & " AND CostsNo = '" & FitSel(CostsNo) & "'"	
	if CostsFinish = 0 then strSel = strSel & " AND FinisherID = 0"
	session("CostsBatch_Sel") = strSel	
	
	with recset
		strSql = "SELECT CostsType, CostsClient, CostsBatch, MIN(CostsPayDay) AS PayFrom, MAX(CostsPayDay) AS PayTo"
		strSql = strSql & ", MAX(CTM_NAME) AS CostsClientName, COUNT(CostsNo) AS CNT, SUM(CostsAmount+CostsTax) AS TTL FROM TBL_CTM_COSTS AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_NAME, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0"
		if myLevel < 4 then strSql = strSql & " AND CostsClient <> '" & gsDummy & "'"		'���폜�@�m���
		if strSel <> "" then strSQL = strSQL & strSel
		strSQL = strSQL & " GROUP BY CostsType, CostsBatch, CostsClient"
		select case mySort
		case 0:		strSql = strSql & " ORDER BY CostsType"
		case 1:		strSql = strSql & " ORDER BY CostsClient"
		case 2:		strSql = strSql & " ORDER BY CostsBatch"
		case 3:		strSql = strSql & " ORDER BY PayFrom"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			.PageSize = myPageSize
			lngPageCount = .PageCount

			'�y�[�W��\������
			If lngPageCount > 1 Then
				Response.Write ("<font class=pt9g><B>PAGE</B> ")
				For lngCount = 1 To lngPageCount
					If lngCount = lngPageNumber Then
						Response.Write (lngCount & " ")
					Else
						Response.Write ("<A HREF='javascript:doTurnPage(" & lngCount & ")'>" & lngCount & "</A> ")
					End If
				Next
				Response.Write ("</font> ")	
			else
				Response.Write ("<br> ")	
			end If
			
			if not .EOF then	
				lngCount = 0
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize		
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		  <TR align=center height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�敪
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�ޯ���
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x����
			<TD class=line nowrap>����
			<TD class=line nowrap>�x�����z
			<TD class=line nowrap>����
<%
				ttlAmount = 0
				Do Until .EOF
					lngCount = lngCount + 1			
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						CostsType = GetLong(.Fields("CostsType"))	
						CostsBatch = GetString(.Fields("CostsBatch"))	
						CostsClient = GetString(.Fields("CostsClient"))	
						ClientName = GetString(.Fields("CostsClientName"))
						CostsPayFrom = GetString(.Fields("PayFrom"))
						CostsPayTo = GetString(.Fields("PayTo"))
						if CostsPayFrom <> CostsPayTo then 
							CostsPayFrom = Str2MD(CostsPayFrom) & "-" & Str2MD(CostsPayTo)
						else
							CostsPayFrom = Str2MD(CostsPayFrom)
						end if
%>
		<TR align=center height=20>
			<TD class=line><%=lngCount%><BR>
			<TD class=line><%=ShowCostsType(CostsType)%><BR>
			<TD class=line nowrap align=left <%=ShowTitle(ClientName, 16)%>><%=StringCut(ClientName,16)%><BR>
			<TD class=line><%=ShowBatchNo(CostsBatch)%><BR>
			<TD class=line><%=CostsPayFrom%><BR>
			<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("CNT")), 0, true)%><BR>
			<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("TTL")), 0, true)%><BR>
			<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=CostsBatch%>', '<%=CostsClient%>', '<%=CostsType%>')">
<%
					ttlAmount = ttlAmount + GetLong(.Fields("TTL"))
					end if
					.movenext
				loop
			if lngCount > 1 then
%>			
		<TR align=right height=20>
			<TD colspan=4>
			<TD class=line>�� �v
			<TD class=line colspan=2><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
		</TABLE>
<%
			end if
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>