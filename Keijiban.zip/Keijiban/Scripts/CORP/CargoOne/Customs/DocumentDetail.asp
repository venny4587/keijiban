<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim JobBelong
dim JobBroker
dim JobClient
dim JobShipper
dim FinisherID
	
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 0)	
	myLevel = CheckUserLevel(JobBelong, JobBroker)
	
	SeqNo = GetLong(request("seq"))
	if JobCode <> "" then
		mode = 0
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset		
			if SeqNo <> 0 then
				strSql = "SELECT * FROM TBL_CTM_DOCUMENT WHERE Deleted = 0"
				strSql = strSql & " AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSql, Conn, adOpenStatic, adLockReadOnly 
				if not .eof then
					mode = 1		
					DocumentType = GetString(.fields("DocumentType"))
					DocumentTitle = GetString(.fields("DocumentTitle"))
					ObtainDate = Str2Date(.fields("ObtainDate"))
					ObtainTime = GetString(.fields("ObtainTime"))
					ObtainMemo = GetString(.fields("ObtainMemo"))
					SendDate = Str2Date(.fields("SendDate"))
					SendTime = GetString(.fields("SendTime"))
					SendMemo = GetString(.fields("SendMemo"))
					FetchDate = Str2Date(.fields("FetchDate"))
					FetchTime = GetString(.fields("FetchTime"))
					FetchMemo = GetString(.fields("FetchMemo"))
					ReturnDate = Str2Date(.fields("ReturnDate"))
					ReturnTime = GetString(.fields("ReturnTime"))
					ReturnMemo = GetString(.fields("ReturnMemo"))
					Remarks = GetString(.fields("Remarks"))
					
					Creater = GetLong(.fields("Creater"))
					Created = GetDate(.fields("Created"))
					Updater = GetLong(.fields("Updater"))
					Updated = GetDate(.fields("Updated"))
					FinisherID = GetLong(.fields("FinisherID"))
					FinishDate = GetDate(.fields("FinishDate"))
				end if
				.close
			else
				DocumentType = GetPost(request("DocumentType"))
			end if
		end with
		
%>
<html>
<HEAD>
	<TITLE>���ޏڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		sub DoPaper(mode)
			set win = window.open("PaperDetail.asp?JobCode=<%=JobCode%>&mode=" & mode, "PaperDetail","scrollbars=1,width=800,height=600") 
			win.focus()
		end sub
		
		sub DoPrint()		
			set win = window.open("GuaranteePrint.asp?JobCode=<%=JobCode%>&seq=<%=SeqNo%>","GuaranteePrint","scrollbars=1,width=800,height=600")
			win.focus()
		end sub	
		
		sub DataFinish()
			Call DataSave(2)
		end sub
		
		sub DataUnFinish()
			if msgbox ("�Y�����ނ̊������������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
		end sub
		
		sub DataSave(mode)
			if checkText("DocumentTitle","���ޓ��e",0) = false then exit sub
			if checkDate("ObtainDate","�擾���t",1) = false then exit sub
			if checkText("ObtainTime","�擾����",0) = false then exit sub
			if checkText("ObtainMemo","�擾����",0) = false then exit sub
			if checkDate("SendDate","���t���t",0) = false then exit sub
			if checkText("SendTime","���t����",0) = false then exit sub
			if checkText("SendMemo","���t����",0) = false then exit sub
			if checkDate("FetchDate","������t",0) = false then exit sub
			if checkText("FetchTime","�������",0) = false then exit sub
			if checkText("FetchMemo","�������",0) = false then exit sub
			if checkDate("ReturnDate","�ԋp���t",0) = false then exit sub
			if checkText("ReturnTime","�ԋp����",0) = false then exit sub
			if checkText("ReturnMemo","�ԋp����",0) = false then exit sub
			if checkText("Remarks","���ޔ��l", 0) = false then exit sub
			if checkLen("Remarks","���ޔ��l", 250) = false then exit sub
			if mode = 1 then
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			elseif mode = 2 then
				if checkDate("SendDate","���t���t",1) = false then exit sub
				if msgbox ("�Y�����ނ������������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
				frmInput.submit()
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
			
		sub ObtainDate_OnBlur()
			frmInput.ObtainDate.value = setdate(frmInput.ObtainDate.value)
		end sub		
		sub ObtainTime_OnBlur()
			if len(frmInput.ObtainTime.value) >=4 then
				frmInput.ObtainTime.value = setTime(frmInput.ObtainTime.value)
			end if
		end sub		
		sub SendDate_OnBlur()
			frmInput.SendDate.value = setdate(frmInput.SendDate.value)
		end sub		
		sub SendTime_OnBlur()
			if len(frmInput.SendTime.value) >=4 then
				frmInput.SendTime.value = setTime(frmInput.SendTime.value)
			end if
		end sub		
		sub FetchDate_OnBlur()
			frmInput.FetchDate.value = setdate(frmInput.FetchDate.value)
		end sub		
		sub FetchTime_OnBlur()
			if len(frmInput.FetchTime.value) >=4 then
				frmInput.FetchTime.value = setTime(frmInput.FetchTime.value)
			end if
		end sub			
		sub ReturnDate_OnBlur()
			frmInput.ReturnDate.value = setdate(frmInput.ReturnDate.value)
		end sub		
		sub ReturnTime_OnBlur()
			if len(frmInput.ReturnTime.value) >=4 then
				frmInput.ReturnTime.value = setTime(frmInput.ReturnTime.value)
			end if
		end sub		
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
<%if FinisherID = 0 then%>	
					call DataSave(<%=mode%>) 
<%end if%>
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
		
		sub InitForm()
<%	if JobFinisher <> 0 or myLevel < 1 then %>
			call LockAll()
<%	else %>
			frmInput.DocumentType.focus()
<%	end if %>
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsFilesBackColor%>" topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="DocumentUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="type" value="<%=request("type")%>">
  	<input type=hidden name="step" value="<%=request("step")%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=40%>�����ޏڍ�&nbsp;
<%if mode = 1 then%>
	<%if FinisherID = 0 and myLevel > 0 then%>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
	<%end if%>
<%end if%>
<%if CheckBill() then%>
	<%if DocumentType = gsGuarantee then%>
			<img style="cursor:hand" src=img/sheet.jpg alt="�k/�f���" onmousedown="DoPrint()">
	<%end if%>
<%else%>
	<%if myLevel > 0 and (DocumentType = gsGuarantee or DocumentType = gsBillOfLading) then%>
			<img style="cursor:hand" src=img/sheet.jpg alt="�a/�k�o�^" onmousedown="DoPaper(1)">
	<%end if%>
<%end if%>
		<td width=40%>�䒠�ԍ��F<%=JobCode%>
		<td width=20% align=right>
<%	if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="��������" <%if myLevel > 2 then %>onmousedown="DataUnFinish()"<%end if%>>
<%	else %>
		<%if myLevel > 1 then %><img style="cursor:hand" src=img/check.jpg alt="��������" onmousedown="DataFinish()">&nbsp;<%end if%>
	  	<%if myLevel > 0 then %><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave(<%=mode%>)"><%end if%>
<%	end if %>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n align=center>
	  <TR><TD><img src=img/spacer.gif height=10>			
	  <TR height=30 class=pt9n>
	    <TD nowrap>���ދ敪<TD>
<%if mode = 0 then%>
		<select name="DocumentType" onkeydown="ResetEnter()"><%
			for i = 1 to ubound(ctmFile)
				response.write "<option value=" & chr(34) & ctmFile(i) & chr(34)
				if DocumentType = ctmFile(i) then response.write " selected"
				response.write ">" & ctmFile(i)
			next%></SELECT>
<%else%>
		<input class=si name="DocumentType" size=5 maxlength=10 value="<%=DocumentType%>" onkeydown="ResetEnter()" readonly>
<%end if%>
			<TD>���ޓ��e<TD colspan=3><input class=sj name="DocumentTitle" size=56 maxlength=50 value="<%=DocumentTitle%>" onkeydown="ResetEnter()">			
	  <TR height=30>
		<TD nowrap>�擾���t<TD><input class=si name="ObtainDate" size=10 maxlength=10 value="<%=ObtainDate%>" onkeydown="ResetEnter()" 
						<%if FinisherID = 0 then%> onclick="setday(this)"<%end if%>>
		<TD nowrap>�擾����<TD><input class=si name="ObtainTime" size=5 maxlength=5 value="<%=ObtainTime%>" onkeydown="ResetEnter()">
		<TD nowrap>�擾����<TD><input class=sj name="ObtainMemo" size=40 maxlength=50 value="<%=ObtainMemo%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD nowrap>���t���t<TD><input class=si name="SendDate" size=10 maxlength=10 value="<%=SendDate%>" onkeydown="ResetEnter()" 
						<%if FinisherID = 0 then%> onclick="setday(this)"<%end if%>>
		<TD nowrap>���t����<TD><input class=si name="SendTime" size=5 maxlength=5 value="<%=SendTime%>" onkeydown="ResetEnter()">
		<TD nowrap>���t����<TD><input class=sj name="SendMemo" size=40 maxlength=50 value="<%=SendMemo%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD nowrap>������t<TD><input class=si name="FetchDate" size=10 maxlength=10 value="<%=FetchDate%>" onkeydown="ResetEnter()" 
						<%if FinisherID = 0 then%> onclick="setday(this)"<%end if%>>
		<TD nowrap>�������<TD><input class=si name="FetchTime" size=5 maxlength=5 value="<%=FetchTime%>" onkeydown="ResetEnter()">
		<TD nowrap>�������<TD><input class=sj name="FetchMemo" size=40 maxlength=50 value="<%=FetchMemo%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD nowrap>�ԋp���t<TD><input class=si name="ReturnDate" size=10 maxlength=10 value="<%=ReturnDate%>" onkeydown="ResetEnter()" 
						<%if FinisherID = 0 then%> onclick="setday(this)"<%end if%>>
		<TD nowrap>�ԋp����<TD><input class=si name="ReturnTime" size=5 maxlength=5 value="<%=ReturnTime%>" onkeydown="ResetEnter()">
		<TD nowrap>�ԋp����<TD><input class=sj name="ReturnMemo" size=40 maxlength=50 value="<%=ReturnMemo%>" onkeydown="ResetEnter()">
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=30>
		<TD valign=top>���ޔ��l<TD colspan=5>
			<table width=96% Border=0 Cellspacing=0 CellPadding=0><tr><td>
				<textarea name="Remarks" rows=5 style="width:360"><%=Remarks%></textarea>
			  <TD align=center>
<%if gsSaveButton = 1 and FinisherID = 0 and myLevel > 0 then%>
				<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave(<%=mode%>)">
<%else%>
				<input type=button style="width:90;height:30" name=btnClose value="����" onclick="window.close()">
<%end if%>
			</table>
	</TABLE>
<%if mode <> 0 then%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=24 align=center valign=bottom>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
<%end if%>
  </FORM>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function CheckBill()
dim myRec
dim mySql
	CheckBill = false
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT * FROM TBL_CTM_PAPER WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
		.Open mySql, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then CheckBill = true
		.Close
	end with
	set myRec = nothing
end function
%>