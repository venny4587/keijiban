<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	SeqNo = GetLong(request("SeqNo"))
	ClientCode = GetPost(request("JobShipper"))
	if ClientCode <> "" then
	
		OpenSql Conn, SqlServerName, DataBaseName
		
		mode = GetLong(request("mode"))
		select case mode
		
		case -1

			strSql = "UPDATE TBL_CTM_STOCK_GOODS SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID 
			strSql = strSql & ",Updated = GETDATE()" 
			strSql = strSql & " WHERE SeqNo = " & SeqNo
			Conn.Execute strSql
			
		case else
			
			CheckFlag = false
			set Recset = Server.CreateObject("adodb.recordset")	
			with Recset
				strSql = "SELECT * FROM TBL_CTM_STOCK_GOODS WHERE Deleted = 0 AND GoodsKey = '" & GetPost(request("GoodsKey")) & "'"
				.Open strSql, Conn, adOpenStatic, adLockReadOnly 
				CheckFlag = .eof
				.Close
			end with
			
			if CheckFlag then
				if SeqNo = 0 then 
					Set cmdSQL = Server.CreateObject("ADODB.Command")
					Set cmdSQL.ActiveConnection = Conn
					cmdSQL.CommandType = 4
					cmdSQL.CommandText = "DB_CTM_NEW_SUB"
					cmdSQL.Parameters.Refresh
					cmdSQL.Parameters("@SubCode").Value = "GoodsNo"
					cmdSQL.Execute
					SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
				end if
					
				with Recset
					strSql = "SELECT * FROM TBL_CTM_STOCK_GOODS WHERE SeqNo = " & SeqNo
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
					if .eof then
						.AddNew
						.fields("SeqNo") = SeqNo
						.fields("Creater") = WebUserID
						.fields("Created") = now
						.fields("Deleted") = 0
					end if
					.fields("ClientCode") = ClientCode
					.fields("GoodsKey") = GetPost(request("GoodsKey"))
					.fields("GoodsCode") = GetPost(request("GoodsCode"))
					.fields("GoodsName") = GetPost(request("GoodsName"))
					.fields("ReferNo") = GetPost(request("ReferNo"))
					.fields("Status") = GetPost(request("Status"))
					.fields("Remarks") = GetPost(request("Remarks"))
					
					.fields("Updater") = WebUserID
					.fields("Updated") = now
					.update
					.close
				end with
			end if
			set Recset = nothing
			
		end select
		
		if err.number = 0 then
			if CheckFlag then
%>
<html>
<script language=javascript>
	alert("�f�[�^�X�V���܂����I");
	window.close();
</script>
</html>
<%
			else
				ShowMessage "�Y������i�Ԃ͊����ł��B"
			end if
		else
			ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
			
		end if
		
		CloseDB Conn
	end if
	
%>