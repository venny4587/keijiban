<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
		
dim mode
dim myCode
dim Stand

dim CloseSales
dim CloseStand
dim CloseCosts
dim SalesCloseDate
dim StandCloseDate
dim CostsCloseDate

dim SightSales
dim SightStand
dim SightCosts
dim SalesSightDate
dim StandSightDate
dim CostsSightDate

	mode = GetLong(request("mode"))
	myType = GetLong(request("type"))
	myCode = GetPost(request("cd"))
	selCode = replace(myCode, "'", "''")
	
	Stand = GetDate(request("dt"))
	if Stand = "" then Stand = formatDate(date)
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	CTM_CD = ""
	if myCode <> "" then
		with Recset
			StrSql = "SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_TYPE FROM CUSTOMER WHERE CTM_DELETED = 0"
			StrSql = StrSql & " AND CTM_REF <> '' AND (CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "')"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				CTM_CD = GetString(.fields("CTM_CD"))
				CTM_REF = GetString(.fields("CTM_REF"))
				CTM_NAME = GetString(.fields("CTM_NAME"))
				CTM_TYPE = GetLong(.fields("CTM_TYPE"))
				.movenext
				if not .eof then CTM_CD = ""
			end if
			.close
			
			if CTM_CD <> "" then 
				StrSql = "SELECT PIC_NAME FROM CTM_PIC WHERE PIC_DFT = 1 AND CTM_CD = '" & CTM_CD & "'"
				.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
				if not .eof then PIC_NAME = GetString(.fields("PIC_NAME"))
				.close
				
				if GetCtmClose(CTM_CD, CloseSales, CloseStand, CloseCosts) then
					SalesClose = ShowClose(CloseSales)
					StandClose = ShowClose(CloseStand)
					CostsClose = ShowClose(CloseCosts)
					SalesCloseDate = Close2Date(CloseSales, Stand)
					StandCloseDate = Close2Date(CloseStand, Stand)
					CostsCloseDate = Close2Date(CloseCosts, Stand)
				end if
				
				if GetCtmSight(CTM_CD, SightSales, SightStand, SightCosts) then
					SalesSight = ctmCredit(SightSales \ 1000) & ShowPayDay(SightSales mod 1000)
					StandSight = ctmCredit(SightStand \ 1000) & ShowPayDay(SightStand mod 1000)
					CostsSight = ctmCredit(SightCosts \ 1000) & ShowPayDay(SightCosts mod 1000)
					
					SalesSightDate = Sight2Date(SightSales, SalesCloseDate)
					if Date2Str(SalesSightDate) <= Date2Str(SalesCloseDate) then SalesSightDate = dateadd("d", 7, SalesSightDate)
					StandSightDate = Sight2Date(SightStand, StandCloseDate)
					if Date2Str(StandSightDate) <= Date2Str(StandCloseDate) then StandSightDate = dateadd("d", 7, StandSightDate)
					
					StandPSightDate = Sight2Date(SightStand, StandCloseDate)
					CostsSightDate = Sight2Date(SightCosts, CostsCloseDate)
				end if
			end if
		end with
	end if

if WebUserID = gsAdmin then
response.write "myType:" & myType & "<BR>"

response.write "SalesClose:" & CloseSales & "<BR>"
response.write "StandClose:" & CloseStand & "<BR>"
response.write "CostsClose:" & CloseCosts & "<BR>"

response.write "ChargeSales:" & ChargeSales & "<BR>"
response.write "ChargeStand:" & ChargeStand & "<BR>"
response.write "ChargeCosts:" & ChargeCosts & "<BR>"

response.write "ChargeSight:" & ChargeSight & "<BR>"
response.write "StandSight:" & StandSight & "<BR>"
response.write "CostsSight:" & CostsSight & "<BR>"

response.write "SalesCloseDate:" & SalesCloseDate & "<BR>"
response.write "StandCloseDate:" & StandCloseDate & "<BR>"
response.write "CostsCloseDate:" & CostsCloseDate & "<BR>"

response.write "SalesSightDate:" & SalesSightDate & "<BR>"
response.write "StandSightDate:" & StandSightDate & "<BR>"
response.write "StandPSightDate:" & StandPSightDate & "<BR>"
response.write "CostsSightDate:" & CostsSightDate & "<BR>"
end if

	if CTM_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
	if (window.opener.frmInput.ChargeClient != null) window.opener.frmInput.ChargeClient.value = "<%=CTM_CD%>";
	if (window.opener.frmInput.ChargeRef != null) window.opener.frmInput.ChargeRef.value = "<%=CTM_REF%>";
	if (window.opener.frmInput.ChargeName != null) window.opener.frmInput.ChargeName.value = "<%=CTM_NAME%>";
	if (window.opener.frmInput.ChargePic != null) window.opener.frmInput.ChargePic.value = "<%=PIC_NAME%>";
	
	if (window.opener.frmInput.SalesClose != null) window.opener.frmInput.SalesClose.value = "<%=SalesClose%>";
	if (window.opener.frmInput.SalesSight != null) window.opener.frmInput.SalesSight.value = "<%=SalesSight%>";
	if (window.opener.frmInput.CloseSales != null) window.opener.frmInput.CloseSales.value = "<%=CloseSales%>";
	if (window.opener.frmInput.SightSales != null) window.opener.frmInput.SightSales.value = "<%=SightSales%>";
	
	if (window.opener.frmInput.StandClose != null) window.opener.frmInput.StandClose.value = "<%=StandClose%>";
	if (window.opener.frmInput.StandSight != null) window.opener.frmInput.StandSight.value = "<%=StandSight%>";
	if (window.opener.frmInput.CloseStand != null) window.opener.frmInput.CloseStand.value = "<%=CloseStand%>";
	if (window.opener.frmInput.SightStand != null) window.opener.frmInput.SightStand.value = "<%=SightStand%>";
	
	if (window.opener.frmInput.CostsClose != null) window.opener.frmInput.CostsClose.value = "<%=CostsClose%>";
	if (window.opener.frmInput.CostsSight != null) window.opener.frmInput.CostsSight.value = "<%=CostsSight%>";	
	if (window.opener.frmInput.CloseCosts != null) window.opener.frmInput.CloseCosts.value = "<%=CloseCosts%>";
	if (window.opener.frmInput.SightCosts != null) window.opener.frmInput.SightCosts.value = "<%=SightCosts%>";
	
<%if CTM_TYPE = 0 then%>
	if (window.opener.frmInput.ChargeType != null) window.opener.frmInput.ChargeType.selectedIndex = 0;
	if (window.opener.frmInput.ChargeCloseDay != null) window.opener.frmInput.ChargeCloseDay.value = "<%=SalesCloseDate%>";
	if (window.opener.frmInput.ChargePayDay != null) window.opener.frmInput.ChargePayDay.value = "<%=SalesSightDate%>";
<%else%>
	if (window.opener.frmInput.ChargeType != null) window.opener.frmInput.ChargeType.selectedIndex = 2;
	if (window.opener.frmInput.ChargeCloseDay != null) window.opener.frmInput.ChargeCloseDay.value = "<%=StandCloseDate%>";
	if (window.opener.frmInput.ChargePayDay != null) window.opener.frmInput.ChargePayDay.value = "<%=StandSightDate%>";
<%end if%>

<%if myType	= 3 then%>
	if (window.opener.frmInput.CostsCloseDay != null) window.opener.frmInput.CostsCloseDay.value = "<%=CostsCloseDate%>";
	if (window.opener.frmInput.CostsPayDay != null) window.opener.frmInput.CostsPayDay.value = "<%=CostsSightDate%>";
<%elseif myType = 4 then %>
	if (window.opener.frmInput.CostsCloseDay != null) window.opener.frmInput.CostsCloseDay.value = "<%=StandCloseDate%>";
	if (window.opener.frmInput.CostsPayDay != null) window.opener.frmInput.CostsPayDay.value = "<%=StandPSightDate%>";
<%end if %>

	if (window.opener.frmInput.BatchBillDay != null) window.opener.frmInput.BatchBillDay.value = "<%=CostsCloseDate%>";
	if (window.opener.frmInput.BatchPayDay != null) window.opener.frmInput.BatchPayDay.value = "<%=CostsSightDate%>";

	if (window.opener.frmInput.ChargeDate != null) { window.opener.frmInput.ChargeDate.focus(); }
	else if (window.opener.frmInput.CostsBillNo != null) { window.opener.frmInput.CostsBillNo.focus(); }
	else if (window.opener.frmInput.Remarks != null) { window.opener.frmInput.Remarks.focus(); }

<%if WebUserID <> gsAdmin then%>
	window.close();
<%end if%>
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����挟��</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "ChargerSearch.asp?mode=<%=mode%>&type=<%=myType%>&dt=<%=Stand%>&cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("������R�[�h�܂��͐����於�̈ꕔ����͂��Ă��������B")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="ChargerSearch.asp" NAME=frmInput>
		<input type=hidden name="mode" value="<%=mode%>">
		<input type=hidden name="type" value="<%=myType%>">
		<input type=hidden name="dt" value="<%=Stand%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD width=80>�����挟�� :</TD>
				<TD nowrap><input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=20 onkeydown="ResetEnter()"></TD>
				<TD width=80 align=right><INPUT TYPE=button style="cursor:hand; width:60; height:25" VALUE="����" onclick="DoSearch()"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then 
			With Recset
				StrSql = "SELECT COUNT(CTM_CD) AS CTM_CNT FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_REF <> '' AND ("
				StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF LIKE '" & selCode & "%' OR CTM_ABR = '" & selCode & "'"
				StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if GetLong(.fields("CTM_CNT")) = 0 then
					response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
				elseif GetLong(.fields("CTM_CNT")) > 30 then
					response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
				else
					.close
					
					StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_ABR, CTM_NAME FROM CUSTOMER WHERE CTM_DELETED = 0 AND ("
					StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF LIKE '" & selCode & "%' OR CTM_ABR = '" & selCode & "'"
					StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
					strSQL = strSQL + " ORDER BY CTM_ENAME"
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>�R�[�h
					<TD nowrap>��������
					<TD nowrap>�p������
					<TD nowrap>�a������
					<TD nowrap>�a������
<%
						myCnt = 0
						myShortCut = ""
						Do Until .EOF	
							myCnt = myCnt + 1		
							myEName = GetString(.Fields("CTM_ENAME"))	
							myJName = GetString(.Fields("CTM_NAME"))	
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("CTM_CD") & "');"
							if myCnt < 10 then myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("CTM_CD") & "');"
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("CTM_CD")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_CD"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_REF"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myEName, 40)%>><%=StringCut(myEName,40)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_ABR"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myJName, 20)%>><%=StringCut(myJName,20)%><BR>
<%							
							.MoveNext
						Loop
					end if				
%>
			</table>
<%
				end if	
				.Close 
			End With
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>