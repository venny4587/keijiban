<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
	
	SeqNo = GetLong(request("SeqNo"))
	mode = GetLong(request("mode"))
	if mode <> 0 then
	
		Conn.BeginTrans
		
		select case mode
		case -1
			
			if SeqNo = 0 then
				session("StockIn_Select") = ""
			else
				strSql = "UPDATE TBL_CTM_STOCK SET"
				strSql = strSql & " StockPkgZan = StockPkgZan + Packages"
				strSql = strSql & ",Updater = " & WebUserID
				strSql = strSql & ",Updated = GETDATE()"
				strSql = strSql & " FROM TBL_CTM_STOCK, TBL_CTM_STOCK_LINK"
				strSql = strSql & " WHERE TBL_CTM_STOCK.SeqNo = TBL_CTM_STOCK_LINK.ImportNo"
				strSql = strSql & " AND ExportNo = " & SeqNo
				Conn.Execute strSql
				
				strSql = "DELETE FROM TBL_CTM_STOCK_LINK WHERE ExportNo = " & SeqNo
				Conn.Execute strSql
				
				strSql = "UPDATE TBL_CTM_STOCK SET Deleted = 1"
				strSql = strSql & ",Updater = " & WebUserID
				strSql = strSql & ",Updated = GETDATE()"
				strSql = strSql & " WHERE SeqNo = " & SeqNo
				Conn.Execute strSql
			end if
			
		case 1				'�V�K�E�ۑ�
		
			if SeqNo = 0 then
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "StockNo"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
			else
				strSql = "UPDATE TBL_CTM_STOCK SET"
				strSql = strSql & " StockPkgZan = StockPkgZan + Packages"
				strSql = strSql & ",Updater = " & WebUserID
				strSql = strSql & ",Updated = GETDATE()"
				strSql = strSql & " FROM TBL_CTM_STOCK, TBL_CTM_STOCK_LINK"
				strSql = strSql & " WHERE TBL_CTM_STOCK.SeqNo = TBL_CTM_STOCK_LINK.ImportNo"
				strSql = strSql & " AND ExportNo = " & SeqNo
				Conn.Execute strSql
				
				strSql = "DELETE FROM TBL_CTM_STOCK_LINK WHERE ExportNo = " & SeqNo
				Conn.Execute strSql
			end if
			
			with Recset
				strSql = "SELECT * FROM TBL_CTM_STOCK WHERE SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("SeqNo") = SeqNo
					.fields("StockType") = 1
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				
				.fields("JobCode") = GetPost(request("JobCode"))
				.fields("StockClient") = GetPost(request("JobShipper"))
				.fields("StockNo") = GetPost(request("StockNo"))
				
				.fields("StockCode") = GetPost(request("StockCode"))
				.fields("StockName") = GetPost(request("StockName"))
				.fields("StockDate") = Date2Str(request("StockDate"))
				.fields("StockTime") = GetPost(request("StockTime"))
				
				.fields("StockPkgCnt") = GetLong(request("StockPKG"))
				.fields("StockPkgZan") = GetLong(request("StockCnt"))		'���Ɍ���
				.fields("StockPackage") = "C/T"		'	GetPost(request("StockPackage"))
				.fields("StockGW") = GetDouble(request("StockGW"))
				.fields("StockCBM") = GetDouble(request("StockCBM"))
				.fields("StockMark") = GetPost(request("StockMark"))
				.fields("StockReferNo") = GetPost(request("StockReferNo"))
				
				.fields("StockPlace") = GetPost(request("StockPlace"))
				.fields("StockDelivery") = GetPost(request("StockDelivery"))
				.fields("StockDivision") = GetPost(request("StockDivision"))
				.fields("StockStatus") = GetPost(request("StockStatus"))
				.fields("StockLot") = GetPost(request("StockLot"))
				.fields("StockMemo") = GetPost(request("StockMemo"))
				.fields("Remarks") = GetPost(request("Remarks"))
				
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			
			cnt = GetLong(request("StockCnt"))
			if cnt > 0 then
				for idx = 1 to cnt
					if GetLong(request("PKG" & idx)) <> 0 then
						strSql = "INSERT INTO TBL_CTM_STOCK_LINK (ImportNo, ExportNo, Packages, Creater)"
						strSql = strSql & " VALUES (" & GetLong(request("SeqNo" & idx)) & "," & GetLong(SeqNo)
						strSql = strSql & "," & GetLong(request("PKG" & idx)) & "," & WebUserID & ")"
						Conn.Execute strSql
					end if
				next
			end if
			
			strSql = "UPDATE TBL_CTM_STOCK SET"
			strSql = strSql & " StockPkgZan = StockPkgZan - Packages"
			strSql = strSql & ",Updater = " & WebUserID
			strSql = strSql & ",Updated = GETDATE()"
			strSql = strSql & " FROM TBL_CTM_STOCK, TBL_CTM_STOCK_LINK"
			strSql = strSql & " WHERE TBL_CTM_STOCK.SeqNo = TBL_CTM_STOCK_LINK.ImportNo"
			strSql = strSql & " AND ExportNo = " & SeqNo
			Conn.Execute strSql
			
		case 2				'�ǋL
			
			cnt = GetLong(request("StockCnt"))
			if cnt > 0 then
				sum = 0:	rec = 0
				for idx = 1 to cnt
					if GetLong(request("PKG" & idx)) <> 0 then
						rec = rec + 1
						sum = sum + GetLong(request("PKG" & idx))
						
						strSql = "INSERT INTO TBL_CTM_STOCK_LINK (ImportNo, ExportNo, Packages, Creater)"
						strSql = strSql & " VALUES (" & GetLong(request("SeqNo" & idx)) & "," & SeqNo
						strSql = strSql & "," & GetLong(request("PKG" & idx)) & "," & WebUserID & ")"
						Conn.Execute strSql
						
						strSql = "UPDATE TBL_CTM_STOCK SET"
						strSql = strSql & " StockPkgZan = StockPkgZan - " & GetLong(request("PKG" & idx))
						strSql = strSql & ",Updater = " & WebUserID
						strSql = strSql & ",Updated = GETDATE()"
						strSql = strSql & " WHERE TBL_CTM_STOCK.SeqNo = " & GetLong(request("SeqNo" & idx))
						Conn.Execute strSql
					end if
				next
				
				strSql = "UPDATE TBL_CTM_STOCK SET"
				strSql = strSql & " StockPkgCnt = StockPkgCnt + " & sum
				strSql = strSql & ",StockPkgZan = StockPkgZan + " & rec
				strSql = strSql & ",StockGW = StockGW + " & GetDouble(request("StockGW"))
				strSql = strSql & ",StockCBM = StockCBM + " & GetDouble(request("StockCBM"))
				strSql = strSql & ",Updater = " & WebUserID
				strSql = strSql & ",Updated = GETDATE()"
				strSql = strSql & " WHERE SeqNo = " & SeqNo
				Conn.Execute strSql
			end if
		end select
		
		if err.number = 0 then
			Conn.CommitTrans
			
			session("StockIn_Client") = ""
			session("StockIn_Select") = ""
%>
<html>
<script language=javascript>
	alert("�f�[�^���������܂����I");
	if (window.opener.frmInput != null) window.opener.frmInput.submit();
<%if mode > 0 then%>
	window.location.href = "StockOutDetail.asp?SeqNo=<%=SeqNo%>";
<%else%>
	window.close();
<%end if%>
</script>
</html>
<%
		else
			Conn.RollbackTrans
			ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
			
		end if
	end if
	
	set Recset = nothing
	CloseDB Conn
%>