<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next
		
dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
dim myPageSize

	myPageSize = GetUserPageSize(15)
	
	mySort = GetLong(Request("sort"))
	if mySort = "" then mySort = "cd"

	lngPageNumber = GetLong(request("page"))	
	if lngPageNumber = 0 then lngPageNumber = 1
	
	myCode = GetString(request("cd"))
	selCode = replace(myCode, "'", "''")
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<TITLE></TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowDetail(myCD)
			window.location.href = "EstimateDetail.asp?cd=" & myCD
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
				
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
		
		function doTurnPage(myPage)
			frmInput.page.value = myPage
			frmInput.submit()
		end function
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" <%=gsBodyControl%>>	
	<FORM NAME=frmInput ACTION="EstimatePattern.asp" METHOD="POST">
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9n>
			<TR height=30 align=center>
				<TD nowrap>�����挟�� :</TD>
				<TD nowrap><input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=20 onkeydown="ResetEnter()"></TD>
				<TD width=80 align=right><INPUT TYPE=submit style="cursor:hand; width:60; height:30" VALUE="����"></TD>
			</TR>
		</table>
<%
	With Recset				
		StrSql = "SELECT C.CTM_CD, CTM_REF, CTM_ENAME, CTM_ABR, CTM_NAME, ISNULL(total, 0) AS CNT FROM CUSTOMER AS C"
		StrSql = StrSql & " LEFT JOIN (SELECT EstimateClient AS code, COUNT(EstimateClient) AS total FROM TBL_CTM_ESTIMATE"
		StrSql = StrSql & " GROUP BY EstimateClient) AS E ON C.CTM_CD = E.code WHERE CTM_DELETED = 0 AND ("
		StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "' OR CTM_ABR = '" & selCode & "'"
		StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
		Select Case mySort
		Case 1
			strSQL = strSQL & " ORDER BY CTM_ENAME;"
		Case 2
			strSQL = strSQL & " ORDER BY CTM_ABR;"
		Case 3
			strSQL = strSQL & " ORDER BY CTM_NAME;"
		Case 4
			strSQL = strSQL & " ORDER BY ISNULL(total, 0);"
		Case Else
			strSQL = strSQL & " ORDER BY CTM_REF;"
		End Select
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .EOF then
			.PageSize = myPageSize
			lngPageCount = .PageCount 
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * myPageSize
%>
		<table width=96% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
			<TR>
				<TD class=line nowrap width=5%>No.</TD>					
				<TD class=line nowrap width=10% style="cursor:hand;color:blue" onmousedown="DoSort(0)">��������
				<TD class=line nowrap width=30% style="cursor:hand;color:blue" onmousedown="DoSort(1)">�p������
				<TD class=line nowrap width=10% style="cursor:hand;color:blue" onmousedown="DoSort(2)">�a������
				<TD class=line nowrap width=30% style="cursor:hand;color:blue" onmousedown="DoSort(3)">�a������
				<TD class=line nowrap width=10% style="cursor:hand;color:blue" onmousedown="DoSort(4)">����
				<TD class=line nowrap width=5%>����
<%
			Do Until .EOF
				lngCount = lngCount + 1
				If lngCount > lngPageNumber * myPageSize Then
					Exit Do
				else
					myEName = GetString(.Fields("CTM_ENAME"))
					myJName = GetString(.Fields("CTM_NAME"))
					myCount = GetLong(.Fields("CNT"))
%>
			<TR>
				<TD class=line nowrap><%=lngCount%>
				<TD class=line nowrap><%=GetString(.Fields("CTM_REF"))%>
				<TD class=line nowrap <%=ShowTitle(myEname,36)%>><%=stringCut(myEname,36)%>
				<TD class=line nowrap><%=GetString(.Fields("CTM_ABR"))%><BR>
				<TD class=line nowrap <%=ShowTitle(myJName,18)%>><%=stringCut(myJName,18)%>
				<TD class=line nowrap align=center><%=myCount%>
			<%if myCount > 0 then %>
				<TD class=line><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' onmousedown="ShowDetail('<%=.fields("CTM_CD")%>')">
			<%else%>
				<TD class=line><IMG SRC='img/new.gif' ALT='�V�K�쐬' STYLE='cursor:hand' onmousedown="ShowDetail('<%=.fields("CTM_CD")%>')">
			<%end if%>
<%			
					.MoveNext
				end if 
			Loop
		else
			Response.Write "<br><div align=center class=pt9n>�Y���f�[�^��������܂���ł����B</div>"	
		end if
		.Close 
	End With	
%>
		</TABLE>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>