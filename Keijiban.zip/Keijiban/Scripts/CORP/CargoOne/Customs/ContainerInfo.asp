<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim JobBelong
dim JobBroker

dim Count20
dim Count40
dim CountEtc
dim CountAll
	
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 0)	
	myLevel = CheckUserLevel(JobBelong, JobBroker)
	
	SeqNo = GetLong(request("SeqNo"))	
	if JobCode <> "" then
			
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		
		if CheckJobType(JobCode) = gsExport then
			myTitle = "Seal No." 
		else
			myTitle = "�\��ԍ�" 
		end if
%>
<html>
<HEAD>
	<TITLE>�R�����e�i�[�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		sub DataSave(myNo)
			if checkText("ContainerNo","�R���e�i�[��",1) = false then exit sub
			if checkText("BookingNo","<%=myTitle%>",0) = false then exit sub
			if checkText("Remarks","���l", 0) = false then exit sub
			if checkLen("Remarks","���l", 250) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.SeqNo.value = myNo
			frmInput.mode.value = 1
			frmInput.submit()
		end sub
		
		sub DataDel(myNo)
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.SeqNo.value = myNo
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DataEdit(myNo)
			window.location.href = "ContainerInfo.asp?JobCode=<%=JobCode%>&SeqNo=" & myNo
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
<%if FinisherID = 0 then%>	
				call DataSave() 
<%end if%>
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
		
		sub InitForm()
			frmInput.ContainerSize.focus()
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="ContainerSave.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=40%>���R���e�i�[���&nbsp;
		<td width=40%>�䒠�ԍ��F<%=JobCode%>
		<td width=20% align=right>
<%	if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="��������">
<%	else %>
	  	<%if myLevel > 0 then %><img style="cursor:hand" src=img/new.gif alt="�V�K" onmousedown="DataEdit('0')"><%end if%>
<%	end if %>
	</table>
	<hr width=96% size=1><%=JobHeader%><br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n align=center>
	  <colgroup span=3 align=center>
	  <colgroup span=3 align=left>
	  <colgroup align=center>
	  <TR height=30>
		<TD class=line nowrap>&nbsp;
		<TD class=line nowrap>��
		<TD class=line nowrap>�T�C�Y
		<TD class=line nowrap>�R���e�i�[��
		<TD class=line nowrap><%=myTitle%>
		<TD class=line nowrap>���l
		<TD class=line nowrap>�ҏW
<%
		cnt = 0:	 Buf = ""
		Count20 = 0:	Count40 = 0:	CountEtc = 0
		with Recset
			strSql = "SELECT * FROM TBL_CTM_CONTAINER WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			strSql = strSql & "ORDER BY SeqNo"
			.Open strSql, Conn, adOpenStatic, adLockReadOnly 
			do while not .eof
				cnt = cnt + 1
				mySeq = GetLong(.fields("SeqNo"))
				ContainerSize = GetString(.fields("ContainerSize"))
				ContainerNo = GetString(.fields("ContainerNo"))
				BookingNo = GetString(.fields("BookingNo"))
				Remarks = GetString(.fields("Remarks"))
				if mySeq = SeqNo then
%>
	  <TR height=30 bgcolor="#E0E0E0">
		<TD class=line><IMG SRC=img/waste.gif ALT=�폜 STYLE="cursor:hand" OnClick="DataDel('<%=mySeq%>')">
		<TD class=line><%=cnt%>
		<TD class=line><select class=si name="ContainerSize" onkeydown="ResetEnter()">
				<option value="20'" <%if ContainerSize="20'" then response.write "selected"%>>20'
				<option value="40'" <%if ContainerSize="40'" then response.write "selected"%>>40'</select>
		<TD class=line><input class=si name="ContainerNo" size=15 maxlength=20 value="<%=ContainerNo%>" onkeydown="ResetEnter()">
		<TD class=line><input class=si name="BookingNo" size=15 maxlength=20 value="<%=BookingNo%>" onkeydown="ResetEnter()">
		<TD class=line><input class=sj name="Remarks" size=30 maxlength=100 value="<%=Remarks%>" onkeydown="ResetEnter()">
		<TD class=line><a href="javascript:DataSave('<%=mySeq%>')"><IMG SRC=img/save.gif border=0 ALT=�ۑ�></a></TD>
<%
				else
%>
	  <TR height=30>
		<TD class=line><IMG SRC=img/waste.gif ALT=�폜 STYLE="cursor:hand" OnClick="DataDel('<%=mySeq%>')">
		<TD class=line><%=cnt%>
		<TD class=line><%=ContainerSize%><br>
		<TD class=line><%=ContainerNo%><br>
		<TD class=line><%=BookingNo%><br>
		<TD class=line <%=ShowTitle(Remarks, 12)%>><%=Stringcut(Remarks, 12)%><br>
		<TD class=line><IMG SRC=img/open.gif ALT=�ҏW STYLE="cursor:hand" OnClick="DataEdit('<%=mySeq%>')">
<%
				end if
				select case ContainerSize
				case "20'"
					Count20 = Count20 + 1
				case "40'"
					Count40 = Count40 + 1
				case else
					CountEtc = CountEtc + 1
				end select
				buf = buf & ContainerNo & "(" & ContainerSize & ")" & vbcrlf
				.movenext
			loop
			.Close
		end with
%>
<%if SeqNo = 0 then%>
	  <TR height=30 bgcolor="#E0E0E0">
		<TD class=line colspan=2 align=center>�V�K
		<TD class=line><select class=si name="ContainerSize" onkeydown="ResetEnter()"><option value="20'">20'<option value="40'">40'</select>
		<TD class=line><input class=sz name="ContainerNo" size=15 maxlength=20 value="����A��" onkeydown="ResetEnter()">
		<TD class=line><input class=sz name="BookingNo" size=15 maxlength=20 value="" onkeydown="ResetEnter()">
		<TD class=line><input class=sz name="Remarks" size=30 maxlength=100 value="" onkeydown="ResetEnter()">
		<TD class=line><a href="javascript:DataSave('0')"><IMG SRC=img/save.gif border=0 ALT=�ۑ�></a></TD>
<%end if%>
<%
myCnt = Count20 + Count40 + CountEtc
if myCnt > 0 then
	myStr = ""
	if Count20 > 0 then myStr = myStr & " + 20'x " & Count20
	if Count40 > 0 then myStr = myStr & " + 40'x " & Count40
	if CountEtc > 0 then myStr = myStr & " + �� x " & CountEtc
%>
	  <TR height=30><td colspan=7 class=pt9g align=left><%=mid(myStr, 4)%>
	  �@���v�F <%=myCnt%> CONTAINER<%if myCnt > 0 then response.write "S"%>
<%end if%>
	<input type=hidden name="Container" value="<%=buf%>">
	</TABLE>
	<br><br>
  </FORM>
<center>
<script language=javascript>
if (window.opener.frmInput.Container != null) window.opener.frmInput.Container.value = frmInput.Container.value
</script>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>
