<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
		
dim BatchNo

	BatchNo = GetPost(request("BatchNo"))

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 	
	with Recset
		strSql = "SELECT * FROM TBL_CTM_BATCH WHERE Deleted = 0 AND BatchNo = '" & BatchNo & "'"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			BatchClient = GetString(.Fields("BatchClient"))
			BatchPic = GetString(.Fields("BatchPic"))
			BatchCount = GetLong(.Fields("BatchCount"))
			BatchAmount = GetLong(.Fields("BatchAmount"))
			BatchBillDay = Str2Date(.Fields("BatchBillDay"))
			BatchPayDay = Str2Date(.Fields("BatchPayDay"))
			ConfirmerID = GetLong(.Fields("ConfirmerID"))
			FinisherID = GetLong(.Fields("FinisherID"))
		end if
		.close
		
		strSql = "SELECT CTM_NAME, CTM_REF, CTM_ZIP, CTM_ADDR1, CTM_ADDR2, CTM_FAX, CTM_SALESMNGR FROM CUSTOMER WHERE CTM_CD = '" & BatchClient & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then 
			ClientName = GetString(.fields("CTM_NAME"))
			CTM_REF = GetString(.fields("CTM_REF"))
			CTM_ZIP = GetString(.fields("CTM_ZIP"))
			CTM_ADDR1 = GetString(.fields("CTM_ADDR1"))
			CTM_ADDR2 = GetString(.fields("CTM_ADDR2"))
			CTM_FAX = GetString(.fields("CTM_FAX"))
			CTM_SALESMNGR = GetString(.fields("CTM_SALESMNGR"))
		end if
		.close
%>
<HTML>
<HEAD>
	<TITLE>�x���ꗗ�\��</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r ����; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r ����; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: �l�r ����; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 16pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
  <table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
  <tr><td height=880 valign=top align=center>
	<table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <tr><td width=150>��<%=BatchNo%>
	 	<td width=320 class=pth align=center><u>&nbsp;&nbsp; �x �� �� �� �� ��&nbsp;&nbsp;</u>
	  	<td width=150 align=right><%=formatDateJP(BatchPayDay)%>
	</table>
	<br>
	<table width=640 cellspacing=0 cellpadding=0>
	  <tr>
		<td width=340 valign=top class=ptm>
			<table width=90% Cellspacing=0 CellPadding=0 class=ptm>
		  	  <tr height=20><td>�� <%=CTM_ZIP%><br><%=CTM_ADDR1%><br><%=CTM_ADDR2%><br><%=ClientName%> �䒆<br>
		  	  <tr height=20><td><hr size=1 color=black>
		  	  <tr height=20><td class=ptm>FAX: <%=CTM_FAX%>
 			</table>
		<td width=300 valign=top align=right>
		  <table Cellspacing=0 CellPadding=0 class=ptm>
			<tr align=right>
				<td width=130><img src=img/logo.jpg>
				<td nowrap><font class=pth><b><%=gsPrintHead%></b></font>
		  	<tr align=right>
		  		<td colspan=2 class=ptt nowrap align=right><%=gsPrintAddr%>
 		  </table>
	</table>
	<TABLE width=640 Cellspacing=3 CellPadding=3 class=ptm>
  	  <TR><td colspan=7><hr color=black size=1>
	  <TR class=pt9>
		<TD class=gline width=40>��
		<TD class=gline width=120 nowrap>������
		<TD class=gline width=100 nowrap>�x���ԍ�
		<TD class=gline width=90 nowrap>�䒠�ԍ�
		<TD class=gline width=90 nowrap align=right>�Ŕ����z
		<TD class=gline width=80 nowrap align=right>�����
		<TD class=gline width=100 nowrap align=right>���v���z
<%
		cnt = 0
		ttlAmount = 0:	ttlTax = 0
		strSql = "SELECT CostsBillNo, CostsNo, JobCode, CostsAmount, CostsTax FROM TBL_CTM_COSTS"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0 AND CostsBatch = '" & BatchNo & "'"
		strSql = strSql & " ORDER BY CostsBillNo"
if webuserid = gsAdmin then response.write strSql
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly	
		do while not .eof
			cnt = cnt + 1
			ttlTax = ttlTax + GetLong(.Fields("CostsTax"))
			ttlAmount = ttlAmount + GetLong(.Fields("CostsAmount"))
%>
		<TR>
			<TD><%=cnt%>
			<TD nowrap><%=GetString(.Fields("CostsBillNo"))%><BR>
			<TD nowrap><%=GetString(.Fields("CostsNo"))%><BR>
			<TD nowrap><%=GetString(.Fields("JobCode"))%><BR>
			<TD nowrap align=right>\<%=formatnumber(GetLong(.Fields("CostsAmount")), 0, true)%><BR>
<%if GetLong(.Fields("CostsTax")) <> 0 then %>
			<TD nowrap align=right>\<%=formatnumber(GetLong(.Fields("CostsTax")), 0, true)%><BR>
<%else%>
			<TD nowrap align=right><BR>
<%end if%>
			<TD nowrap align=right>\<%=formatnumber(GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax")), 0, true)%><BR>
<%
			.movenext
		loop
		if cnt > 1 then
%>
  		<TR><td colspan=7><hr color=black size=1>
		<TR align=right class=ptm>
			<TD colspan=4>�x�����v
			<TD class=line>\<%=formatnumber(ttlAmount, 0, true)%>
			<TD class=line>\<%=formatnumber(ttlTax, 0, true)%>
			<TD class=line>\<%=formatnumber(ttlAmount + ttlTax, 0, true)%>
<%
		end if
%>
  	  <TR><td colspan=7><hr color=black size=1>
	</TABLE>
<%
	end with
%>  
  <tr><td>
  	<table width=640><tr><td>
		<table width=320 cellspacing=3>
			<tr align=center height=80>
				<td class=bline><br>
				<td class=bline><br>
				<td class=bline><br>
				<td class=bline><br>
		</table>
	  <td align=right>
		<table width=300 cellspacing=3font class=ptx>
		  <tr align=right>
		  	<td nowrap><b>�����v�F</b>
			<td nowrap class=gline><b>\<%=formatnumber(ttlAmount + ttlTax, 0, true)%></b>
		</table>
	</table>	  	
  </table>
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>
