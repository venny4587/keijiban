<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	JobCode = GetPost(request("JobCode"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	Finished = CheckJobFinished(JobCode)
%>
<HTML>
<HEAD>
	<TITLE>�[�i���ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=javaScript>
		function ShowDetail(myNo) {
			var win = window.open("DeliveryDetail.asp?JobCode=<%=JobCode%>&seq="+myNo,"Delivery","scrollbars=1,width=600,height=400");
			win.focus();
		}	
	</SCRIPT>
</HEAD>
<BODY topmargin=0 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<td width=50%>���[�i���&nbsp;
<!--		<img style="cursor:hand" src=img/delivery.jpg alt="�z�Ԉ˗��[" onmousedown="DoPrint()">	-->
	  	<td width=50% align=right>
<%	if Finished then %>
	  		<img style="cursor:help" src=img/security.gif alt="���b�N�ς�">
<%	else %>
	  		<img style="cursor:hand" src=img/new.gif alt="�V�K�ǉ�" onmousedown="ShowDetail('');">
<%	end if %>
	</table>
	<hr width=100% size=1 color=blue>
<%
	with recset
		strSql = "SELECT SeqNo, DeliveryDate, DeliveryTime, DeliveryBroker," 
		strSql = strSql & " DeliveryType, DeliveryFrom, DeliveryTo, Contents, Remarks"
		strSql = strSql & " FROM TBL_CTM_DELIVERY WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
		strSql = strSql & " ORDER BY DeliveryDate, DeliveryTime"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>�}��
		<TD class=line nowrap>�[�i����
		<TD class=line nowrap>�[�i���e
		<TD class=line nowrap>�[�i���@
		<TD class=line nowrap>�I�_
		<TD class=line nowrap>�˗���

<%
			cnt = 0
			ShortCut = ""
			do while not .eof
				cnt = cnt + 1
				DeliveryTo = GetLong(.Fields("DeliveryTo"))
				if DeliveryTo <> 0 then 
					DeliveryTo = GetDoorName(DeliveryTo)
				else
					DeliveryTo = GetString(.Fields("Remarks"))
				end if
				Broker = GetRefName(.Fields("DeliveryBroker"))
				Contents = GetString(.Fields("Contents"))
				ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(cnt)) & ") ShowDetail('" & .Fields("SeqNo") & "');"
				if cnt < 10 then ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + cnt) & ") ShowDetail('" & .Fields("SeqNo") & "');"
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("SeqNo")%>');">
					<TD class=line nowrap>[<%=Num2Code(cnt)%>]<BR>
					<TD class=line nowrap><%=GetLong(.Fields("SeqNo"))%><BR>
					<TD class=line nowrap><%=Str2MD(.Fields("DeliveryDate"))%>&nbsp;<%=GetString(.Fields("DeliveryTime"))%><BR>
					<TD class=line nowrap <%=ShowTitle(Contents, 12)%>><%=StringCut(Contents,12)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("DeliveryType"))%><BR>
					<TD class=line nowrap <%=ShowTitle(DeliveryTo, 12)%>><%=StringCut(DeliveryTo,12)%><BR>
					<TD class=line nowrap <%=ShowTitle(Broker, 8)%>><%=StringCut(Broker,8)%><BR>
<%
				.movenext
			loop
%>
	</TABLE>
<%
		end if
	end with
%>  
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==119) <%if ConfirmerID = 0 then%> ShowDetail(''); <%else%>return;<%end if%>
<%if cnt > 0 then response.write ShortCut%>
}

function DoPrint() {
<%if cnt = 0 then%>			
	alert("�[�i����o�^���Ă��������B");
<%else%>
	var win = window.open("DeliveryFrame.asp?JobCode=<%=JobCode%>","DeliveryPrint","scrollbars=1,width=800,height=600");
	win.focus();
<%end if%>
}
</script>
</BODY>
</HTML>
<% 
set recset = nothing
CloseDB Conn
%>

<%
function GetDoorName(myDoor)
dim myRec
dim mySql
	set myRec = Server.CreateObject("adodb.recordset") 
	with myRec
		mySql = "SELECT DOOR_NAME FROM CTM_DOOR WHERE DOOR_ID = " & myDoor
		.Open mySql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then GetDoorName = GetString(.fields("DOOR_NAME"))
		.close
	end with
	set myRec = nothing
		
end function
%>
