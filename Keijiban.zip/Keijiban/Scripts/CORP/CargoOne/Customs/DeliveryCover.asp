<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
	BrokerRef = GetPost(request("cd"))
	OrderFrom = GetPost(request("dt1"))
	OrderTo = GetPost(request("dt2"))
'	DateFrom = GetPost(request("dt1"))
'	DateTo = GetPost(request("dt2"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	with recset	
		strSql = "SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_ADDR1, CTM_ADDR2 FROM CUSTOMER WHERE CTM_REF = '" & BrokerRef & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
			CTM_CD = GetString(.fields("CTM_CD"))
			CTM_REF = GetString(.fields("CTM_REF"))
			CTM_NAME = GetString(.fields("CTM_NAME"))
			CTM_ADDR1 = GetString(.fields("CTM_ADDR1"))
			CTM_ADDR2 = GetString(.fields("CTM_ADDR2"))
		end if
		.close
		
		strSql = "SELECT PIC_NAME, PIC_DPT, PIC_POS, PIC_TEL, PIC_FAX FROM CTM_PIC WHERE CTM_CD = '" & CTM_CD & "' AND PIC_DELETED = 0 AND PIC_DFT <> 0"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then 
			PIC_NAME = GetString(.fields("PIC_DPT")) & " " & GetString(.fields("PIC_POS")) & " " & GetHornor(.fields("PIC_NAME"))
			PIC_TEL = GetString(.fields("PIC_TEL"))
			PIC_FAX = GetString(.fields("PIC_FAX"))
		end if
		.close
	end with
%>
<HTML>
<HEAD>
	<TITLE>�z�Ԉ˗��ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r ����; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r ����; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 12pt; LINE-HEIGHT: 1.2em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 14pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
	<table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <tr>
	  	<td width=180 valign=bottom>�@<b>�W�ד�: <%=formatDateJP(OrderFrom)%></b>
	 	<td width=300 class=pth align=center><u>&nbsp;&nbsp; �z �� �� �� �� ��&nbsp;&nbsp;</u>
	  	<td width=180 align=right>�o�͓��t: <u><%=formatdate(date)%></u>
	</table>
	<br>
	<table width=640 cellspacing=0 cellpadding=0>
	  <tr>
		<td width=340 valign=top class=ptm>
		  <table width=90% Cellspacing=0 CellPadding=0 class=ptm>
		  	  <tr height=20><td><hr size=1 color=black>
		  	  <tr height=40 valign=top><td><%=CTM_NAME%> �䒆<br> <%=PIC_NAME%><br>
		  	  <tr height=20><td>TEL: <%=PIC_TEL%>
		  	  <tr height=20><td>FAX: <%=PIC_FAX%>
 			</table>
 			
		<td width=300 valign=top align=right>
		  <table Cellspacing=0 CellPadding=0 class=ptm>
			<tr align=right>
				<td width=130><img src=img/logo.jpg>
				<td nowrap><font class=pth><b><%=gsPrintHead%></b></font>
		  	<tr align=right>
		  		<td colspan=2 class=ptt nowrap align=right><%=gsPrintAddr%>
 		  </table>
	</table>
	
<!--���׍s-->
<%
	with Recset
		strSel = ""
		if BrokerRef <> "" then	strSel = strSel & " AND BrokerRef = '" & FitSel(BrokerRef) & "'"
		if OrderFrom <> "" then strSel = strSel & " AND OrderDate >= '" & Date2Str(OrderFrom) & "'"
		if OrderTo <> "" then strSel = strSel & " AND OrderDate <= '" & Date2Str(OrderTo) & "'"
'		if DateFrom <> "" then strSel = strSel & " AND DeliveryDate >= '" & Date2Str(DateFrom) & "'"
'		if DateTo <> "" then strSel = strSel & " AND DeliveryDate <= '" & Date2Str(DateTo) & "'"
			
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT D.JobCode, SeqNo, ShipperRef, BrokerRef, DeliveryType, Contents, DeliveryFrom"
		strSQL = strSQL & ",OrderDate, D.DeliveryDate FROM TBL_CTM_DELIVERY AS D INNER JOIN TBL_CTM_JOB AS J ON D.JobCode = J.JobCode"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ShipperRef FROM CUSTOMER) AS C ON J.JobShipper = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON D.DeliveryBroker = B.CTM_CD"
		strSQL = strSQL & " WHERE D.Deleted = 0 AND J.Deleted = 0) AS TMP"
		if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel, 5)
		strSQL = strSQL & " ORDER BY DeliveryDate, DeliveryFrom, JobCode"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
%>
	<TABLE width=640 Cellspacing=3 CellPadding=3 class=pts>
		<colgroup align=center>
		<colgroup align=left>
		<colgroup span=2 align=center>
		<colgroup span=2 align=left>
	  	<TR><td colspan=6><hr color=black size=1>
		<TR valign=bottom>
			<TD class=gline width=20>��
			<TD class=gline width=90>�˗��ԍ�
			<TD class=gline width=40>�[�i��
			<TD class=gline width=60>�[�i���@
			<TD class=gline width=220>�[�i���e
			<TD class=gline width=200>�N�_
<%
			cnt = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode")) & "-" & GetString(.Fields("SeqNo"))	
				DeliveryType = GetString(.Fields("DeliveryType"))
				DeliveryFrom = GetString(.Fields("DeliveryFrom"))
				DeliveryDate = Str2Date(.Fields("DeliveryDate"))
%>
		<TR valign=top>
			<TD><%=cnt%><br><br>
			<TD nowrap><%=JobCode%>
			<TD><%=right(DeliveryDate, 5)%>
			<TD><%=DeliveryType%>
			<TD><%=replace(GetString(.fields("Contents")), vbcrlf, "<br>")%>
			<TD><%=DeliveryFrom%>
<%
				.movenext
			loop
			if cnt > 1 then
%>
	  	<TR><td colspan=6><hr color=black size=1>
		<TR><TD colspan=5 align=right>���v
			<TD><%=formatnumber(cnt, 0, true)%>��
<%
			end if
%>
	  	<TR><td colspan=6><hr color=black size=1>
	  	<TR><td colspan=5 align=left valign=top>���t��̌�A�������܂����AFAX�ɂĕԐM���肢�܂��B<br><br>FAX: <%=GetShopFax(UserShop)%>
	  		<td align=right><table cellspacing=2 cellpadding=2 width=100 height=50 class=pt9><tr><td class=bline align=right>��&nbsp;&nbsp;</table>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�������f�[�^�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>
