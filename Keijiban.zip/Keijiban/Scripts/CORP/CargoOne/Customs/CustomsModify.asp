<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim JobCode

	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myMode = GetLong(request("mode"))
	if myMode <> 0 then
		strSql = "UPDATE TBL_CTM_JOB SET"
		strSql = strSql & " DeliveryDate = '" & Date2Str(request("DeliveryDate")) & "'"
		strSql = strSql & ",SalesDate = '" & Date2Str(request("SalesDate")) & "'"
		strSql = strSql & ",ReferNo = '" & FitSel(request("ReferNo")) & "'"
		strSql = strSql & ",Commodity = '" & FitSel(request("Commodity")) & "'"
		strSql = strSql & ",PermitNo = '" & FitSel(request("PermitNo")) & "'"
		strSql = strSql & ",Marks = '" & FitSel(request("Marks")) & "'"
		strSql = strSql & ",Remarks = '" & FitSel(request("Remarks")) & "'"
		strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
		Conn.execute strSql
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
	window.opener.location.href = "CustomsEdit.asp?JobCode=<%=JobCode%>"
	window.close();
</SCRIPT>
</HTML>
<%
	else
		with Recset	
			StrSql = "SELECT * FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				JobClient = GetString(.fields("JobClient"))
				JobType = GetString(.fields("JobType"))
				Commodity = GetString(.fields("Commodity"))
				ReferNo = GetString(.fields("ReferNo"))
				PermitNo = GetString(.fields("PermitNo"))
				DeliveryDate = Str2Date(.fields("DeliveryDate"))
				SalesDate = Str2Date(.fields("SalesDate"))
				
				Marks = GetString(.fields("Marks"))
				Remarks = GetString(.fields("Remarks"))
				LockerID = GetLong(.fields("LockerID"))
				LockDate = GetDate(.fields("LockDate"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
				.movenext
			end if
			.close
		end with
		
		AccountMonth = CheckAccountMonth()
		AccountMonth = left(AccountMonth, 4) & "/" & right(AccountMonth, 2)
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>S/I���ύX</TITLE>
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub DeliveryDate_OnBlur()
			frmInput.DeliveryDate.value = setdate(frmInput.DeliveryDate.value)
		end sub
		
		sub SalesDate_OnBlur()
			frmInput.SalesDate.value = setdate(frmInput.SalesDate.value)
		end sub
		
		sub DataSave()
			if checkDate("DeliveryDate","��Ɗ�����", 0) = false then exit sub
			if checkDate("SalesDate","������", 0) = false then exit sub
			if trim(frmInput.SalesDate.value) <> "" then
				if left(frmInput.SalesDate.value, 7) <= "<%=AccountMonth%>" then
					frmInput.SalesDate.focus()
					msgbox "�Y�����x�͊��Ɍ����߂���Ă��܂��B", 48, "�m�F���b�Z�[�W"
					exit sub
				end if
			end if
			if checkText("ReferNo","�_��ԍ�",0) = false then exit sub
			if checkText("Commodity","�i��",0) = false then exit sub
			if checkText("PermitNo","�����ԍ�",0) = false then exit sub
			if checkText("Marks","�}�[�N���",0) = false then exit sub
			if checkLen("Marks","�}�[�N���",255) = false then exit sub
			if checkText("Remarks","���l", 0) = false then exit sub
			if checkLen("Remarks","���l",255) = false then exit sub
			if msgbox ("�Ɩ��f�[�^��ύX���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.submit()
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
			if window.event.keyCode=120 then call DataSave()
		end sub
	-->
	</SCRIPT>
</HEAD>

<body onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CustomsModify.asp" method="post">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>��S/I�ڍ׏��ύX&nbsp;
		<td width=50% align=right>
<%if LockerID <> 0 then %>
	  		<img style="cursor:hand" src=img/security.gif alt="�m�F�ҁF<%=GetEmployName(LockerID, "F") & " (" & ShowDateTimeShort(LockDate) & ")"%>">
<%else%>
	  	  	<img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
<%end if%>
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
		<TD width=60 align=center class=pt9g>������
		<TD width=520><input class=si name="ClientRef" size=10 maxlength=10 value=" <%=GetRefName(JobClient)%>" onkeydown="ResetEnter()" readonly>
			(<%=JobClient%>)�@<input class=si name="ClientName" size=56 value="<%=GetFullName(JobClient)%>" onkeydown="ResetEnter()" readonly>
	</table>
	<%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR>
	  	<TD width=80><TD width=100><TD width=80><TD width=100><TD width=60><TD width=180><br>
	  <TR height=25>
		<TD align=center nowrap>������
		<TD><input class=si name="DeliveryDate" size=10 maxlength=10 value="<%=DeliveryDate%>" onkeydown="ResetEnter()"  
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
		<TD align=center>������
		<TD><input class=si name="SalesDate" size=10 maxlength=10 value="<%=SalesDate%>" onkeydown="ResetEnter()"  
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
		<TD align=center>�}�[�N
		<TD rowspan=5><textarea class=sz name="Marks" rows=8 style="width:160"><%=Marks%></textarea>
	  <TR height=25>
		<TD align=center>�_��
		<TD colspan=4><input class=si name="ReferNo" size=50 maxlength=50 value="<%=ReferNo%>" onkeydown="ResetEnter()">
	  <TR height=25>
		<TD align=center>�i�@��
		<TD colspan=4><input class=sz name="Commodity" size=50 maxlength=100 value="<%=Commodity%>" onkeydown="ResetEnter()">
	  <TR height=25>
		<TD align=center>������
		<TD colspan=4><input class=sz name="PermitNo" size=50 maxlength=50 value="<%=PermitNo%>" onkeydown="ResetEnter()">
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=25>
		<TD class=pt9 align=center>����
		<TD colspan=4><textarea name="Remarks" rows=5 style="width:300"><%=Remarks%></textarea>
		<TD align=center>
<%if LockerID = 0 then %>
			<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" name=btnClose value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=24 align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>