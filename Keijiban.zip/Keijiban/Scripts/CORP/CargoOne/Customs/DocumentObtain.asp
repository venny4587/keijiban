<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
dim myMode
dim myPageSize
		
	myPageSize = GetUserPageSize(100)		

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then	
		JobType = ""				'�q�ɔ��p
		DocumentType = gsReceipt
		if instr(session("Depart"), "�A��") <> 0 then JobType = gsImQuantity
		if instr(session("Depart"), "�A�o") <> 0 then JobType = gsExQuantity
		JobCode = UserShop & JobType
		DocObtain = 0
	else
		DocumentType = GetPost(request("DocumentType"))
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		JobType = GetPost(request("JobType"))
		CustomBroker = GetPost(request("CustomBroker"))
		JobCode = GetPost(request("JobCode"))
		Quantity = GetPost(request("Quantity"))
		Vessel = GetPost(request("Vessel"))
		DocObtain = GetLong(request("DocObtain"))
		
		ObtainDate = GetPost(request("ObtainDate"))
		ObtainTime = GetPost(request("ObtainTime"))
		if ObtainDate = "" then ObtainDate = formatDate(date)
		ObtainMemo = GetPost(request("ObtainMemo"))
		if ObtainMemo = "" then ObtainMemo = "�ꊇ�擾"
		
		'�ꊇ�擾����
		if myMode = 2 then
			msg = ""
			Conn.BeginTrans
					
			JobSeq = split(GetPost(request("JobSeq")), ",")
			if DocumentType = gsReceipt then
				for i = 0 to ubound(JobSeq)
					JobSeq(i) = "'" & trim(JobSeq(i)) & "'"
				next
				
				strSql = "UPDATE TBL_CTM_JOB SET ObtainDate = '" & Date2Str(ObtainDate) & "'"
				strSql = strSql & "  WHERE JobCode IN (" & join(JobSeq, ",") & ")"
				Conn.Execute strSql
				
			else			
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Document"
			
				for i = 0 to ubound(JobSeq)
					cmdSQL.Execute
					SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
					
					strSql = "INSERT INTO TBL_CTM_DOCUMENT (SeqNo, JobCode, DocumentType, ObtainDate, ObtainTime, ObtainMemo, Creater, Updater)"
					strSql = strSql & " VALUES (" & SeqNo & ",'" & GetString(JobSeq(i)) & "','" & DocumentType & "','" & Date2Str(ObtainDate) & "','"
					strSql = strSql & FitSel(ObtainTime) & "','" & FitSel(ObtainMemo) & "'," & WebUserID & "," & WebUserID & ")"
					Conn.Execute strSql
					
					if err.number <> 0 then exit for
				next
			end if
			
			if err.number = 0 then
				Conn.CommitTrans
				msg = "�Y�����ނ��ꊇ�擾���܂����B"
			else
				Conn.RollbackTrans
				msg = "�ꊇ�擾���������L�̃G���[���N����܂����B(" & vbcrlf & err.number & ":" & err.description & ")"
			end if
		end if
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>���ގ擾����</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		function DoCheck()
			Call CheckAll("JobSeq", frmInput.CheckAll.Checked)
		end function 
	
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "JobSeq" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�擾���鏑�ނ�I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			else
				if checkDate("ObtainDate","�擾���t",1) = false then exit function
				if checkText("ObtainTime","�擾����",0) = false then exit function
			end if
			if msgbox ("�Y�����ނ��擾���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(cd, no)
		dim win
			set win = window.open("DocumentDetail.asp?DocumentType=<%=DocumentType%>&step=1&JobCode=" & cd & "&seq=" & no,"DocumentDetail","resizable=1,scrollbars=1,width=600,height=400")
			win.focus()
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub		
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
<%if myMode = 2 then%>
	<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
	<%end if%>
			window.parent.parent.result.location.href = "DocumentResult.asp?type=1"
<%else%>
			frmInput.ClientRef.focus()
<%end if%>
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="DocumentObtain.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
	    		����&nbsp;<select name="DocumentType" onkeydown="ResetEnter()"><%
					for i = 0 to ubound(ctmFile)
						response.write "<option value=" & ctmFile(i)
						if DocumentType = ctmFile(i) then response.write " selected"
						response.write ">" & ctmFile(i)
					next%></SELECT>
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�Ɩ�&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>
				<font color=green>���o�`��</font>
					<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
			<TR><TD nowrap>
				�ʊ֋Ǝ�&nbsp;<select name="CustomBroker" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowBrokerList(CustomBroker)%></select>
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�D��<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=12 onkeydown="ResetEnter()">
				��<input class=sn name="Quantity" value="<%=Quantity%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="DocObtain" value="1" onkeydown="ResetEnter()" <%if DocObtain then response.write " checked"%>>
		</table>
	<!----------��������--------->
<%
	if myMode > 0 then
		CustomBroker = GetPost(request("CustomBroker"))
		ShipCorp = GetPost(request("ShipCorp"))
		
		strSel = ""
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)	
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if CustomBroker <> "" then strSel = strSel & " AND CustomBroker = '" & CustomBroker & "'"
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'"
		if Vessel <> "" then strSel = strSel & " AND Vessel LIKE '%" & FitSel(Vessel) & "%'"
		if Quantity <> "" then strSel = strSel & " AND Quantity = " & GetDouble(Quantity)
		if DocumentType = gsBillOfLading or DocumentType = gsGuarantee then strSel = strSel & " AND Surrendered = 0"
		if DocObtain = 0 then strSel = strSel & " AND ISNULL(ObtainDate, '') = ''"
		
		strSQL = "SELECT * FROM ("
		if DocumentType = gsReceipt then
			strSQL = strSQL & "SELECT 0 AS SeqNo, JobCode, C.CTM_CD, ClientRef, Vessel, CustomBroker, BrokerRef, MBL+' '+HBL AS BLNO, Vessel+' '+Voy AS VesselVoy, POL, POD"
			strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImQuantity & "' THEN ETA ELSE ETD END AS ETAETD, Surrendered, ObtainDate, Quantity, Package"
			strSQL = strSQL & ", CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit & "' ELSE JobBelong END AS JobBelong FROM TBL_CTM_JOB AS J"
			strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
			strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON J.CustomBroker = B.CTM_CD"
		else
			strSQL = strSQL & "SELECT SeqNo, JobCode, C.CTM_CD, ClientRef, Vessel, CustomBroker, BrokerRef, MBL+' '+HBL AS BLNO, Vessel+' '+Voy AS VesselVoy, POL, POD"
			strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImQuantity & "' THEN ETA ELSE ETD END AS ETAETD, Surrendered, D.ObtainDate, Quantity, Package"
			strSQL = strSQL & ", CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit & "' ELSE JobBelong END AS JobBelong FROM TBL_CTM_JOB AS J"
			strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
			strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON J.CustomBroker = B.CTM_CD"
			strSQL = strSQL & " LEFT JOIN (SELECT SeqNo, JobCode AS CD, ObtainDate FROM TBL_CTM_DOCUMENT WHERE Deleted = 0"
			strSQL = strSQL & " AND FinisherID = 0 AND DocumentType = '" & DocumentType & "') AS D ON J.JobCode = D.CD"
		end if
		strSQL = strSQL & " WHERE Deleted = 0) AS TMP"
		if CheckTopLevel() = 0 then 
			strSql = strSql & " WHERE JobBelong = '" & UserShop & "'" & strSel
		else
			if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel,5)
		end if
		select case mySort
		case 0:		strSql = strSql & " ORDER BY JobCode"
		case 1:		strSql = strSql & " ORDER BY ETAETD, JobCode"
		case 2:		strSql = strSql & " ORDER BY ClientRef, JobCode"
		case 3:		strSql = strSql & " ORDER BY BrokerRef, JobCode"
		case 4:		strSql = strSql & " ORDER BY Vessel, JobCode"
		case 5:		strSql = strSql & " ORDER BY Quantity, JobCode"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		  <TR align=center height=20>
			<TD nowrap class=line width=4%>��
			<TD nowrap class=line width=12% style="cursor:hand;color:blue" onmousedown="DoSort(0)">�䒠�ԍ�
			<TD nowrap class=line width=12% style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����׎�
			<TD nowrap class=line width=12% style="cursor:hand;color:blue" onmousedown="DoSort(3)">�ʊ֋Ǝ�
			<TD nowrap class=line width=14% style="cursor:hand;color:blue" onmousedown="DoSort(4)">�D��
			<TD nowrap class=line width=6% style="cursor:hand;color:blue" onmousedown="DoSort(5)">��
			<TD nowrap class=line width=10%>POL
			<TD nowrap class=line width=10%>POD
			<TD nowrap class=line width=10% style="cursor:hand;color:blue" onmousedown="DoSort(1)">���o�`
			<TD class=line nowrap colspan=2><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S��
<%
				Do while not .EOF
					lngCount = lngCount + 1
					If lngCount > myPageSize Then
						Exit Do
					Else
						SeqNo = GetLong(.Fields("SeqNo"))
						JobCode = GetString(.Fields("JobCode"))
						ClientRef = GetString(.Fields("ClientRef"))
						BrokerRef = GetString(.Fields("BrokerRef"))
						Vessel = GetString(.Fields("Vessel"))
						Quantity = GetDouble(.Fields("Quantity"))		' & GetString(.Fields("Package"))
						POL = GetString(.Fields("POL"))
						POD = GetString(.Fields("POD"))
%>
		  <TR>
			<TD nowrap class=line><%=lngCount%><BR>
			<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%><BR>
			<TD nowrap class=line><%=ClientRef%><BR>
			<TD nowrap class=line><%=BrokerRef%><BR>
			<TD nowrap class=line <%=ShowTitle(Vessel, 12)%>><%=stringCut(Vessel, 12)%><BR>
			<TD nowrap class=line align=right><%=Quantity%><BR>
			<TD nowrap class=line <%=ShowTitle(POL, 8)%>><%=stringCut(POL, 8)%><BR>
			<TD nowrap class=line <%=ShowTitle(POD, 8)%>><%=stringCut(POD, 8)%><BR>
			<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("ETAETD"))%><BR>
<%if DocumentType = gsReceipt then%>
			<TD nowrap class=line><%if GetString(.fields("ObtainDate")) = "" then %><input type=checkbox name="JobSeq" value="<%=JobCode%>"><%else%>��<%end if%>
<%else%>
			<TD nowrap class=line><%if GetString(.fields("ObtainDate")) = "" then %><input type=checkbox name="JobSeq" value="<%=JobCode%>"><%else%>
				<IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=JobCode%>', <%=SeqNo%>)"><%end if%>
			<TD nowrap class=line><IMG SRC='img/new.gif' STYLE='cursor:hand' onclick="ShowDetail('<%=JobCode%>', 0)">
<%end if%>
<%
						.MoveNext
					End If
				Loop
				if lngCount > myPageSize then
%>
		  <TR>
			<TD nowrap colspan=10><font color=red>��������܂��D�D�D</font>
<%
				end if
%>
		</TABLE><br>
		<div align=right>
			�擾���t&nbsp;<input class=si name="ObtainDate" size=10 maxlength=10 value="<%=ObtainDate%>" onkeydown="ResetEnter()" onclick="setday(this)">
<%if DocumentType <> gsReceipt then%>
			�擾����&nbsp;<input class=si name="ObtainTime" size=5 maxlength=5 value="<%=ObtainTime%>" onkeydown="ResetEnter()">
			�擾����&nbsp;<input class=sj name="ObtainMemo" size=20 maxlength=50 value="<%=ObtainMemo%>" onkeydown="ResetEnter()">
<%end if%>
		�@<INPUT style="width:60px;height:25px;" TYPE=button VALUE="�擾" onclick="DoConfirm()">
		</div>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
		
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>


<%
function ShowBrokerList(myDft)
dim mySql
dim myRec
dim buf
	
	set myRec = Server.CreateObject ("ADODB.Recordset")	
	mySql = "SELECT CTM_CD, CTM_REF FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_CUSTOM = 1 ORDER BY CTM_REF"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CTM_CD")
		if myDft = myRec.fields("CTM_CD") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("CTM_REF")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowBrokerList = buf	
end function
%>