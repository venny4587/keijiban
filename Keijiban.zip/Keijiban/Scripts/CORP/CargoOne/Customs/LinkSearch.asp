<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
		
dim CTM_CD
dim myCode
dim myType

	CTM_CD = GetPost(request("CTM_CD"))
	myCode = GetPost(request("cd"))
	if myCode <> "" then selCode = replace(myCode, "'", "''")
	myType = GetPost(request("type"))
	select case myType
	case 1:		myText = "Shipper"
	case 2:		myText = "Consignee"
	case 3:		myText = "Notify"
	case 4:		myText = "Agent"
	end select
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	LINK_CD = ""
	if myCode <> "" then
		with Recset
			StrSql = "SELECT LINK_ID, LINK_REF, LINK_NAME, LINK_INFO1, LINK_INFO2, LINK_INFO3, LINK_INFO4"
			StrSql = StrSql & " FROM CTM_LINK WHERE CTM_CD = '" & CTM_CD & "' AND LINK_TYPE = '" & myType & "'"
			StrSql = StrSql & " AND (LINK_ID = " & GetLong(selCode)  & " OR LINK_CD = '" & selCode & "' OR LINK_REF = '" & selCode & "')"
if WebUserID = gsAdmin then response.write StrSql
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				LINK_ID = GetLong(.fields("LINK_ID"))
				LINK_REF = GetString(.fields("LINK_REF"))
				LINK_NAME = GetString(.fields("LINK_NAME"))
				LINK_INFO1 = GetString(.fields("LINK_INFO1"))
				LINK_INFO2 = GetString(.fields("LINK_INFO2"))
				LINK_INFO3 = GetString(.fields("LINK_INFO3"))
				LINK_INFO4 = GetString(.fields("LINK_INFO4"))
			end if
			.close
		end with
	end if

	if LINK_ID <> 0 then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
	if (window.opener.frmInput.<%=myText%> != null) window.opener.frmInput.<%=myText%>.value = "<%=LINK_NAME%>";
	if (window.opener.frmInput.<%=myText%>1 != null) window.opener.frmInput.<%=myText%>1.value = "<%=LINK_INFO1%>";
	if (window.opener.frmInput.<%=myText%>2 != null) window.opener.frmInput.<%=myText%>2.value = "<%=LINK_INFO2%>";
	if (window.opener.frmInput.<%=myText%>3 != null) window.opener.frmInput.<%=myText%>3.value = "<%=LINK_INFO3%>";
	if (window.opener.frmInput.<%=myText%>4 != null) window.opener.frmInput.<%=myText%>4.value = "<%=LINK_INFO4%>";
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE><%=ctmLink(myType)%>����</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "LinkSearch.asp?CTM_CD=<%=CTM_CD%>&type=<%=myType%>&cd=" + cd;
		}
				
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="LinkSearch.asp" NAME=frmInput>
		<input type=hidden name="CTM_CD" value="<%=CTM_CD%>">
		<input type=hidden name="type" value="<%=myType%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD>�@<%=ctmLink(myType)%>�����@<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=16 onkeydown="ResetEnter()">
				<TD>�@<INPUT TYPE=submit style="cursor:hand; width:60; height:25" VALUE="����"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		With Recset
			StrSql = "SELECT COUNT(LINK_CD) AS LINK_CNT FROM CTM_LINK WHERE CTM_CD = '" & CTM_CD & "' AND LINK_TYPE = '" & myType & "'"
			if myCode <> "" then 
				StrSql = StrSql & " AND (LINK_CD = '" & selCode & "' OR LINK_REF = '" & selCode & "'"
				StrSql = StrSql & " OR LINK_NAME LIKE '%" & selCode & "%' OR LINK_INFO1 LIKE '%" & selCode & "%')"
			end if
if WebUserID = gsAdmin then response.write StrSql
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if GetLong(.fields("LINK_CNT")) = 0 then
				response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
			elseif GetLong(.fields("LINK_CNT")) > 30 then
				response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
			else
				.close
				
				StrSql = "SELECT LINK_ID, LINK_CD, LINK_REF, LINK_NAME FROM CTM_LINK WHERE CTM_CD = '" & CTM_CD & "' AND LINK_TYPE = '" & myType & "'"
				if myCode <> "" then 
					StrSql = StrSql & " AND (LINK_CD = '" & selCode & "' OR LINK_REF = '" & selCode & "'"
					StrSql = StrSql & " OR LINK_NAME LIKE '%" & selCode & "%' OR LINK_INFO1 LIKE '%" & selCode & "%')"
				end if
				strSQL = strSQL + " ORDER BY LINK_REF"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>�R�[�h
					<TD nowrap>��������
					<TD nowrap>�a������
<%
					myCnt = 0
					myShortCut = ""
					Do Until .EOF	
						myCnt = myCnt + 1		
						myCorpName = GetString(.Fields("LINK_NAME"))		
						myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("LINK_ID") & "');"
						if myCnt < 10 then
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("LINK_ID") & "');"
						end if			
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("LINK_REF")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("LINK_CD"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("LINK_REF"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myCorpName, 20)%>><%=StringCut(myCorpName,20)%><BR>
<%							
						.MoveNext
					Loop
				end if				
%>
			</table>
<%
			end if	
			.Close 
		End With
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>