<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber

dim JobSel
	
	myPageSize = GetUserPageSize(15)
	mySort = GetLong(request("sort"))
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Locked = 0	
		JobBelong = UserShop
		SalesDate = left(Date2Str(dateadd("m",-1,Date)), 6)
	else
		JobBelong = GetPost(request("JobBelong"))
		JobType = GetPost(request("JobType"))
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		BrokerRef = GetPost(request("BrokerRef"))
		Port = GetPost(request("Port"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		ChargeFrom = GetPost(request("ChargeFrom"))
		ChargeTo = GetPost(request("ChargeTo"))
		Vessel = GetPost(request("Vessel"))
		JobOperator = GetLong(request("JobOperator"))
		JobSalesman = GetLong(request("JobSalesman"))
		Locked = GetLong(request("Locked"))
		SalesDate = GetPost(request("SalesDate"))
				
		'�ꊇ���b�N����
		if myMode = 2 then	
			msg = ""
			JobSel = split(GetPost(request("JobSel")), ",")
			for i = 0 to ubound(JobSel)
				myJob = GetString(JobSel(i))
				
				msg = CheckJobBillConfirmed(Conn, myJob)
				if myMsg <> "" then exit for
				JobSel(i) = "'" & myJob & "'"
			next
			
			if msg = "" then
				
'				strSql = "UPDATE TBL_CTM_JOB SET LockDate = GETDATE()"
'				strSql = strSql & ",LockerID = " & WebUserID
'				strSql = strSql & " WHERE JobCode IN (" & join(JobSel, ",") & ")"
'				Conn.Execute strSql

				Conn.BeginTrans
				
				for i = 0 to ubound(JobSel)
					SalesSum = 0
					SalesTax = 0
					CostsSum = 0
					CostsTax = 0
					StandSum = 0
					myJob = GetString(JobSel(i))
				
					with Recset
						strSql = "SELECT ExpenseType, Sum(ExpenseAmount) AS AMNT, Sum(ExpenseTax) AS TAX"
						strSql = strSql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND JobCode = " & myJob
						strSql = strSql & " GROUP BY ExpenseType"
'if WebUserID = gsAdmin then response.write strSql
						.Open strSql,conn,adOpenStatic,adLockReadOnly 
						do while not .eof
							select case GetLong(.fields("ExpenseType"))
							case gsCharge					'����
								SalesSum = GetLong(.fields("AMNT"))
								SalesTax = GetLong(.fields("TAX"))
							case gsStand					'����
								StandSum = GetLong(.fields("AMNT")) + GetLong(.fields("TAX"))
							case gsPayment					'�x��
								CostsSum = GetLong(.fields("AMNT"))
								CostsTax = GetLong(.fields("TAX"))
							end select
							.movenext
						Loop
						.close	
					end With		
					Interests = (SalesSum + SalesTax) - (CostsSum + CostsTax)
								
					strSql = "UPDATE TBL_CTM_JOB SET LockDate = GETDATE()"
					strSql = strSql & ",LockerID = " & WebUserID
					strSql = strSql & ",SalesSum = " & SalesSum
					strSql = strSql & ",SalesTax = " & SalesTax
					strSql = strSql & ",CostsSum = " & CostsSum
					strSql = strSql & ",CostsTax = " & CostsTax
					strSql = strSql & ",StandSum = " & StandSum
					strSql = strSql & ",Interests = " & Interests
					strSql = strSql & " WHERE JobCode = " & myJob
					Conn.Execute strSql
if WebUserID = gsAdmin then response.write strSQL

					if err.number <> 0 then exit for
				next
				
				if err.number = 0 then
					conn.CommitTrans
					msg = "���b�N�����͖����������܂����B"
				else
					conn.RollBackTrans
					msg = "���b�N���������L�̃G���[���N����܂����B(" & vbcrlf & err.number & ":" & err.description & ")"
				end if
			end if
		end if
	end if

%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ����b�N����</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
	
		function DoCheck()
			Call CheckAll("JobSel", frmInput.CheckAll.Checked)
		end function 
		
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "JobSel" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "���b�N����Ɩ��f�[�^��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			
			if msgbox("�f�[�^�����b�N���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub ChargeFrom_OnBlur()
			frmInput.ChargeFrom.value = setdate(frmInput.ChargeFrom.value)
		end sub
		sub ChargeTo_OnBlur()
			frmInput.ChargeTo.value = setdate(frmInput.ChargeTo.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub		
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
		
		sub InitForm()
<%if myMode = 2 then%>
	<%if gsMsgBatch = 1 then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
	<%end if%>
<%else%>
			frmInput.JobCode.focus()
<%end if%>
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="BalanceView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�戵&nbsp;<SELECT name="JobBelong" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowShopList(JobBelong)%></select>
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�ʊ֋Ǝ�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="BrokerRef" value="<%=BrokerRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�������x&nbsp;<SELECT name="SalesDate" onkeydown="ResetEnter()"><%for i = -2 to 0%><%myDate=dateadd("m",i,date)%>
					<option value="<%=left(Date2Str(myDate), 6)%>" <%if SalesDate = left(Date2Str(myDate), 6) then response.write "selected"%>>
					<%=left(formatDate(myDate), 7)%><%next%></select>
				�Ɩ�&nbsp;<SELECT name="JobOperator" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartCustoms, JobOperator)%></select>
				�c��&nbsp;<SELECT name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartSales, JobSalesman)%></select>
			<TR><TD nowrap>
				�֖�<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=16 onkeydown="ResetEnter()">
				�`��<input class=si name="Port" value="<%=Port%>" maxlength=16 size=10 onkeydown="ResetEnter()">
				���o�`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>
				&nbsp;ۯ��ϕ\��<input type=checkbox name="Locked" value="1" onkeydown="ResetEnter()" <%if Locked then response.write " checked"%>>
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
<!--				<INPUT style="width:60px;height:25px;" TYPE=BUTTON VALUE="�N���A" onclick="window.location.href='BalanceView.asp'">	-->
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobBelong <> "" then strSel = strSel & " AND JobBelong = '" & FitSel(JobBelong) & "'"
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)		
		if BrokerRef <> "" then	strSel = strSel & " AND BrokerRef = '" & FitSel(BrokerRef) & "'"
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'" 					
		if Port <> "" then strSel = strSel & " AND (POL LIKE '%" & FitSel(Port) & "%' OR POD LIKE '%" & FitSel(Port) & "%')"
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if Vessel <> "" then strSel = strSel & " AND VesselVoy LIKE '%" & FitSel(Vessel) & "%'"	
		if ChargeFrom <> "" then strSel = strSel & " AND SalesDate >= '" & Date2Str(ChargeFrom) & "'"
		if ChargeTo <> "" then strSel = strSel & " AND SalesDate <= '" & Date2Str(ChargeTo) & "'"
		if JobOperator <> 0 then strSel = strSel & " AND JobOperator = " & JobOperator
		if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman
		if Locked = 0 then strSel = strSel & " AND LockerID = 0"
		if SalesDate <> "" then 
			strSel = strSel & " AND (SalesDate Between '" & SalesDate & "00' AND '" & SalesDate & "99'"
			if SalesDate = left(Date2Str(date), 6) then strSel = strSel & " OR SalesDate = ''"
			strSel = strSel & ")"
		end if
		
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT JobCode, JobBelong, C.CTM_CD, ClientRef, ClientName, BrokerRef, BrokerName, SalesDate, Sales, Costs, FinisherID, POL, POD, LockerID"
		strSQL = strSQL & ", Vessel+' '+Voy AS VesselVoy, CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD, JobSalesman, JobOperator"
		strSQL = strSQL & ", CASE Sales WHEN 0 THEN 0 ELSE (CAST(Sales AS float) - CAST(Costs AS float)) / Sales END AS ARARI FROM TBL_CTM_JOB AS T "
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME AS ClientName FROM CUSTOMER) AS C ON T.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef, CTM_NAME AS BrokerName FROM CUSTOMER) AS B ON T.CustomBroker = B.CTM_CD"
		strSQL = strSQL & " LEFT JOIN (SELECT JobCode AS JobExpense, SUM(CASE ExpenseType WHEN " & gsCharge & " THEN ExpenseAmount + ExpenseTax ELSE 0 END) AS Sales,"
		strSQL = strSQL & " SUM(CASE ExpenseType WHEN " & gsPayment & " THEN ExpenseAmount + ExpenseTax ELSE 0 END) AS Costs FROM TBL_CTM_EXPENSE WHERE Deleted = 0"
		strSQL = strSQL & " GROUP BY JobCode) AS E ON T.JobCode = E.JobExpense WHERE Deleted = 0) AS TMP"
		strSQL = strSQL & " WHERE SalesDate <> '' AND " & mid(strSel,5)
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY JobCode"
		case 1:		strSQL = strSQL & " ORDER BY ETAETD"
		case 2:		strSQL = strSQL & " ORDER BY Sales"
		case 3:		strSQL = strSQL & " ORDER BY Costs"
		case 4:		strSQL = strSQL & " ORDER BY (Sales - Costs)"
		case 5:		strSQL = strSQL & " ORDER BY ARARI"
		case 6:		strSQL = strSQL & " ORDER BY SalesDate"
		end select
if WebUserID = gsAdmmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then 
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup align=center>
			<colgroup span=3 align=left>
			<colgroup span=3 align=center>
			<colgroup align=left>
			<colgroup align=center>
			<colgroup span=4 align=right>
			<colgroup span=2 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�䒠�ԍ�
			<TD width=8% nowrap>�����׎�
			<TD width=16% nowrap>�֖�
			<TD width=8% nowrap>�o���`
			<TD width=8% nowrap>�ړI�`
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">���o�`
			<TD width=8% nowrap>�ʊ֋Ǝ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">������
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�������v
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�������v
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�e���v
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�e����
			<TD colspan=2 nowrap><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�I��
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						myLock = GetLong(.Fields("LockerID"))					
						if myLock = 0 then
							rowcolor = "#000000"
						else
							rowcolor = "#606060"
						end if	
						JobCode = GetString(.Fields("JobCode"))
						ClientRef = GetString(.Fields("ClientRef"))
						BrokerRef = GetString(.Fields("BrokerRef"))
						VesselVoy = GetString(.Fields("VesselVoy"))
						POL = GetString(.Fields("POL"))
						POD = GetString(.Fields("POD"))
						Sales = GetLong(.Fields("Sales"))
						Costs = GetLong(.Fields("Costs"))
						Balance = Sales - Costs
						Rate = "-"
						if Sales <> 0 then Rate = formatnumber(Balance / Sales * 100, 2, true) & "%"
						if Balance < 0 then
							mycolor = "red"
						else
							mycolor = rowcolor
						end if
%>
		<TR style="color:<%=rowcolor%>">
			<TD nowrap class=line><%=lngCount%><BR>
			<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%><BR>
			<TD nowrap class=line style="cursor:help" title="<%=GetString(.Fields("ClientName"))%>"><%=stringCut(ClientRef, 8)%><BR>
			<TD nowrap class=line <%=ShowTitle(VesselVoy, 20)%>><%=stringCut(VesselVoy, 20)%><BR>
			<TD nowrap class=line <%=ShowTitle(POL, 8)%>><%=stringCut(POL, 8)%><BR>
			<TD nowrap class=line <%=ShowTitle(POD, 8)%>><%=stringCut(POD, 8)%><BR>
			<TD nowrap class=line><%=Str2YMD(.Fields("ETAETD"))%><BR>
			<TD nowrap class=line style="cursor:help" title="<%=GetString(.Fields("BrokerName"))%>"><%=stringCut(BrokerRef, 8)%><BR>
			<TD nowrap class=line><%=Str2YMD(.Fields("SalesDate"))%><BR>
			<TD nowrap class=line><%=formatnumber(Sales, 0, true)%><BR>
			<TD nowrap class=line><%=formatnumber(Costs, 0, true)%><BR>
			<TD nowrap class=line style="color:<%=mycolor%>"><%=formatnumber(Balance, 0, true)%><BR>
			<TD nowrap class=line style="color:<%=mycolor%>"><%=Rate%><BR>
			<TD nowrap class=line><%if GetLong(.Fields("FinisherID")) = 0 then%><font class=pt9>��</font><%else%>
				<%if myLock = 0 then%><input type=checkbox name="JobSel" value="<%=JobCode%>"><%else%>��<%end if%><%end if%>
			<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=JobCode%>')">
<%
						.MoveNext
					End If
				Loop
%>
				
	</TABLE>
<%
				if JobBelong <> "" AND CheckUserLevel(JobBelong, "") > 2 then
%>
	<div align=right>
		<%if lngCount > 0 then%><INPUT style="width:60px;height:25px;" TYPE=button VALUE="���b�N" onclick="DoConfirm()"><%end if%>
	</div>
<%
				end if
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>