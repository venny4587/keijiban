<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next
dim JobSeq
dim myMode
dim myPageSize
dim lngPageNumber
	
	JobType = ""				'�q�ɔ��p
	if instr(session("Depart"), "�A��") <> 0 then JobType = gsImport
	if instr(session("Depart"), "�A�o") <> 0 then JobType = gsExport
	myView = 0
	select case WebUserID
	case 33, 34, 46, 47, 51, 52
		myView = 1
	end select
	
	myPageSize = GetUserPageSize(15)
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		mySort = 4
		ChargeFinish = 0
		JobSalesman = WebUserID
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		PayDayFrom = GetPost(request("PayDayFrom"))
		PayDayTo = GetPost(request("PayDayTo"))
		JobCode = GetPost(request("JobCode"))
		ChargeNo = GetPost(request("ChargeNo"))
		ChargeBatch = GetPost(request("ChargeBatch"))
		AmntFrom = GetPost(request("AmntFrom"))
		AmntTo = GetPost(request("AmntTo"))
		if AmntFrom <> "" then AmntFrom = GetDouble(AmntFrom)
		if AmntTo <> "" then AmntTo = GetDouble(AmntTo)
		ChargeFinish = GetLong(request("ChargeFinish"))	
		JobSalesman = GetLong(request("JobSalesman"))	
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>������������Ɖ��</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		function ShowList(mode)
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
			
		function ShowDetail(myJob, myNo)
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & myJob & "&ChargeNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
			
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub PayDayFrom_OnBlur()
			frmInput.PayDayFrom.value = setdate(frmInput.PayDayFrom.value)
		end sub
		sub PayDayTo_OnBlur()
			frmInput.PayDayTo.value = setdate(frmInput.PayDayTo.value)
		end sub
		sub AmntFrom_OnBlur()
			if frmInput.AmntFrom.value = "" then exit sub
			frmInput.AmntFrom.value = GetDouble(frmInput.AmntFrom.value)
		end sub
		sub AmntTo_OnBlur()
			if frmInput.AmntTo.value = "" then exit sub
			frmInput.AmntTo.value = GetDouble(frmInput.AmntTo.value)
		end sub
		sub ChargeNo_OnBlur()
			frmInput.ChargeNo.value = UCASE(frmInput.ChargeNo.value)
		end sub
		sub ChargeBatch_OnBlur()
			frmInput.ChargeBatch.value = FitPrintNo(frmInput.ChargeBatch.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="ChargeBillView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				������<input class=si name="PayDayFrom" value="<%=PayDayFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="PayDayTo" value="<%=PayDayTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				������<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">				
				�������z<input class=sn name="AmntFrom" value="<%=AmntFrom%>" maxlength=8 size=7 onkeydown="ResetEnter()">
					�`<input class=sn name="AmntTo" value="<%=AmntTo%>" maxlength=8 size=7 onkeydown="ResetEnter()">					
			<TR><TD nowrap>
				�c��&nbsp;<SELECT name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartSales, JobSalesman)%></select>
<!--				�ޯ���<input class=si name="ChargeBatch" value="<%=ChargeBatch%>" maxlength=6 size=6 onkeydown="ResetEnter()">-->
				�����ԍ�<input class=si name="ChargeNo" value="<%=ChargeNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">	
				������<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="ChargeFinish" value="1" <%if ChargeFinish then response.write " checked"%>>
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 1)
	if DateFrom <> "" then strSel = strSel & " AND ChargeDate >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND ChargeDate <= '" & Date2Str(DateTo) & "'"	
	if PayDayFrom <> "" then strSel = strSel & " AND ChargePayDay >= '" & Date2Str(PayDayFrom) & "'"
	if PayDayTo <> "" then strSel = strSel & " AND ChargePayDay <= '" & Date2Str(PayDayTo) & "'"	
	if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'"
	if ChargeNo <> "" then strSel = strSel & " AND ChargeNo LIKE '%" & FitSel(ChargeNo) & "%'"	
	if ChargeBatch <> "" then strSel = strSel & " AND ChargeBatch = '" & FitSel(ChargeBatch) & "'"
	if AmntFrom <> "" then strSel = strSel & " AND (ChargeAmount + ChargeTax) >= " & AmntFrom
	if AmntTo <> "" then strSel = strSel & " AND (ChargeAmount + ChargeTax) <= " & AmntTo
	if ChargeFinish = 0 then strSel = strSel & " AND FinisherID = 0"
	if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman

	ttlAmount = 0	
	with recset
		strSql = "SELECT SUM(CAST(ChargeAmount + ChargeTax AS float)) AS ChargeTotal FROM TBL_CTM_Charge AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobSalesman FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0" & strSel		'���폜�@�m���
		if CheckTopLevel() = 0 and myView = 0 then strSql = strSql & " AND SUBSTRING(JobCode,1,1) = '" & UserShop & "'"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then ttlAmount = GetDouble(.Fields("ChargeTotal"))
		.close
		
		strSql = "SELECT JobCode, ChargeBatch, ChargeNo, ChargeType, ChargeClientName, ChargeDate, ChargeAmount, ChargeTax"
		strSql = strSql & " , ChargePayDay, FinisherID, FinishDate, ClientRef, JobSalesman, Remarks FROM TBL_CTM_Charge AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobSalesman FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0" & strSel		'���폜�@�m���
		if CheckTopLevel() = 0 then strSql = strSql & " AND SUBSTRING(JobCode,1,1) = '" & UserShop & "'"
		select case mySort
		case 0:		strSql = strSql & " ORDER BY ChargeType DESC, ChargePayDay, ChargeNo"
		case 1:		strSql = strSql & " ORDER BY ChargeNo"
		case 2:		strSql = strSql & " ORDER BY JobCode, ChargeNo"
		case 3:		strSql = strSql & " ORDER BY ChargeDate, ChargeNo"
		case 4:		strSql = strSql & " ORDER BY ChargePayDay, ChargeNo"
		case 5:		strSql = strSql & " ORDER BY ChargeBatch, ChargeNo"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			.PageSize = myPageSize
			lngPageCount = .PageCount
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * myPageSize	
%>	
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup span=4 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=3 align=center>
		  <TR align=center height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�敪
<!--			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�����	-->
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�����ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�䒠�ԍ�
			<TD class=line nowrap>����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">������
			<TD class=line nowrap>�������z
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">������
			<TD class=line nowrap>�c��
			<TD class=line colspan=2 align=left>����
<%
			cnt = 0
			Do Until .EOF
				lngCount = lngCount + 1
				BatchNo = GetString(.Fields("ChargeBatch"))	
				JobCode = GetString(.Fields("JobCode"))	
				ChargeNo = GetString(.Fields("ChargeNo"))			
				If lngCount > lngPageNumber * myPageSize Then
					Exit Do
				Else
					Remarks = GetString(.Fields("Remarks"))
					if GetLong(.Fields("FinisherID")) <> 0 then
						status = "<font color=green>��</font>"
					elseif Remarks <> "" then
						status = "<font color=blue>��</font>"
					else
						status = "<font color=red>��</font>"
					end if
						
%>
		<TR align=center height=20>
			<TD class=line><%=lngCount%><BR>
			<TD class=line><%=ShowBillType(.Fields("ChargeType"))%><BR>
<%if false then%>
			<TD class=line nowrap align=left><%=ShowBatchNo(BatchNo)%><BR>
<%end if%>
			<TD class=line nowrap align=left><%=ShowVoucherNo(ChargeNo)%><BR>
			<TD class=line nowrap align=left><%=ShowJobCode(JobCode)%><BR>
			<TD class=line nowrap align=left title="<%=GetString(.Fields("ChargeClientName"))%>"><%=GetString(.Fields("ClientRef"))%><BR>
			<TD class=line style="color:green"><%=Str2MD(.Fields("ChargeDate"))%><BR>
			<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax")), 0, true)%><BR>
			<TD class=line><%=Str2MD(.Fields("ChargePayDay"))%><BR>
			<TD class=line nowrap align=left><%=GetEmployName(.Fields("JobSalesman"), "F")%><BR>
			<TD class=line style="cursor:help" title="<%=Remarks%>"><%=status%><BR>
			<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=JobCode%>', '<%=ChargeNo%>')">
<%
				end if
				.movenext
			loop
			if lngCount > 1 then
%>			
		<TR height=20>
			<TD colspan=4 class=pt9r align=left><%if lngCount > lngPageNumber * myPageSize then response.write "��������܂�..."%>
			<TD class=line align=right>�����v
			<TD class=line align=right colspan=2><%=formatnumber(ttlAmount, 0, true)%>
		
<%
			end if
%>
		</TABLE>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>