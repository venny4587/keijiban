<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
'	Response.Buffer = True

dim JobCode
dim mySeq()

	JobCode = GetPost(request("JobCode"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	with Recset
		cnt = 0
		strSql = "SELECT SeqNo, DeliveryDate, DeliveryTime FROM TBL_CTM_DELIVERY WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
		strSql = strSql & " ORDER BY DeliveryDate, DeliveryTime"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .eof 
			cnt = cnt + 1
			redim preserve mySeq(cnt)
			mySeq(cnt) = GetLong(.fields("SeqNo"))
			.movenext
		loop
		.close
	end with
	
	if cnt = 0 then
		ShowMessage "�Y���Ɩ��̔z�Ԉ˗��\�͌�����܂���ł����B" 
	elseif cnt = 1 Then
		Response.Redirect "DeliveryPrint.asp?print=1&JobCode=" & JobCode & "&seq=" & mySeq(1)
	Else
		For i = 1 To cnt
			If i = 1 Then
				strDivider = "100%"
			Else
				strDivider = strDivider & ",0"
			End If
		Next
	
		If Err.number = 0 Then
		%>
		<HTML>
			<HEAD>
				<TITLE>�z�Ԉ˗��\�@����v���r���[</TITLE>
				<META http-equiv=Content-Type content="text/html; charset=shift-jis">
			</HEAD>
			<FRAMESET ROWS=*,50>
				<FRAMESET COLS="<%=strDivider%>" FRAMEBORDER=0 ID="fraCalc" NAME="fraCalc">
					<%
					For i = 1 To cnt
						Response.Write "<FRAME name='" & i & "' SRC='DeliveryPrint.asp?print=1&JobCode=" & JobCode & "&seq=" & mySeq(i) & "'>"
					Next
					%>
				</FRAMESET>
				<FRAME SRC="../common/blank.htm" noresize>
			</FRAMESET>
		</HTML>
		<%
		End If
	End If	
	
'	Response.Flush 
'	Response.End 	
%>
