<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�������ꊇ�������
'----------------------------------------------

'on error resume next
'	Response.Buffer = True

dim JobCode
dim strSeq

	OpenSql Conn, SqlServerName, DataBaseName			
	set Recset = Server.CreateObject("adodb.recordset") 	
	With RecSet
		strSQL = "SELECT ChargeClient, ChargeClientName, ChargePic, ChargeDate, ChargePayDay, ChargeBatch, JobCode FROM TBL_CTM_CHARGE AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobSalesman FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0" & session("ChargeBatch_Sel")
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then
			BatchBelong = Mid(GetString(.Fields("JobCode")), 1, 1)
			BatchType = Mid(GetString(.Fields("JobCode")), 2, 1)
			BatchClient = GetString(.Fields("ChargeClient"))
			BatchPic = GetString(.Fields("ChargePic"))
			BatchBillDay = GetString(.Fields("ChargeDate"))
			BatchPayDay = GetString(.Fields("ChargePayDay"))
		end if
		.Close	
		
		strSql = "SELECT COUNT(ChargeNo) AS BatchCount, SUM(ChargeAmount+ChargeTax) AS BatchAmount FROM TBL_CTM_CHARGE AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobSalesman FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0" & session("ChargeBatch_Sel")
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then
			BatchCount = GetLong(.fields("BatchCount"))
			BatchAmount = GetLong(.fields("BatchAmount"))
		end if
		.Close
	end with
			
	mode = GetLong(request("mode"))
	if mode = 0 then
		if left(BatchClient, 3) = "690" then 
			ChargeClient = "690"
		end if
%>
<html>	
<html>
<HEAD>
	<TITLE>�����ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
			if msgbox ("�ꊇ����������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsSalesBackColor%>" topmargin=10 class=pt12 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="ChargePrintBatch.asp" method="post">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR><td width=100%>������ԍ��������s&nbsp;
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=40>
		<TD align=center>������
		<TD colspan=3><input class=mi name="ChargeRef" size=30 maxlength=30 value="<%=GetFullName(ChargeClient)%>" onkeydown="ResetEnter()">
	  <TR height=40>
		<TD width=80 align=center class=pt12g nowrap>���ߓ�
		<TD><input class=mi name="BatchBillDay" size=10 maxlength=10 value="<%=Str2Date(BatchBillDay)%>" onkeydown="ResetEnter()" readonly>
		<TD width=80 align=center class=pt12g nowrap>������
		<TD><input class=mi name="BatchPayDay" size=10 maxlength=10 value="<%=Str2Date(BatchPayDay)%>" onkeydown="ResetEnter()" readonly>
	  <TR height=40>
		<TD width=80 align=center class=pt12g nowrap>������
		<TD><input class=mn name="BatchCount" size=10 maxlength=10 value="<%=BatchCount%>" onkeydown="ResetEnter()" readonly>
		<TD width=80 align=center class=pt12g nowrap>�����z
		<TD><input class=mn name="BatchAmount" size=12 maxlength=12 value="<%=formatnumber(BatchAmount, 0, true)%>" onkeydown="ResetEnter()" readonly>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=40>
		<TD colspan=4 align=center>	  	
			<input class=pt12n type=button style="width:120;height:40" name=btnSave value="F9:���s" onclick="DataSave()">�@�@
			<input class=pt12n type=button style="width:120;height:40" name=btnClose value="����" onclick="window.close()">
	</table>
  </FORM>
<center>
</body></html>
<%
	else
		Conn.BeginTrans	
						
		With RecSet			
			BatchID = GetNewBatchNo(Conn, gsBatchPrint)
			BatchNo = GetBatchNo(BatchID, gsBatchPrint)	
			
			strSQL = "SELECT * FROM TBL_CTM_BATCH"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			.addnew				
			
			.fields("BatchBelong") = BatchBelong
			.fields("BatchType") = BatchType
			.fields("BatchNo") = BatchNo
			.fields("BatchPic") = BatchPic
			.fields("BatchClient") = BatchClient
			.fields("BatchCount") = BatchCount
			.fields("BatchAmount") = BatchAmount
			.fields("BatchBillDay") = BatchBillDay
			.fields("BatchPayDay") = BatchPayDay
			
			.fields("Remarks") = "�ꊇ�������"
			.fields("Updater") = WebUserID
			.fields("Updated") = now
			
			.fields("Creater") = WebUserID
			.fields("Created") = now
			.fields("Deleted") = 0
			.update
			.close
				
			strSQL = "SELECT T.ChargeNo FROM TBL_CTM_CHARGE AS T"
			strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
			strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobSalesman FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
			strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0" & session("ChargeBatch_Sel")
			.Open strSQL, Conn, adOpenKeyset , adLockReadOnly 
			do while not .eof
				ChargeNo = GetString(.fields("ChargeNo"))
			
				strSql = "UPDATE TBL_CTM_CHARGE SET ChargeBatch = '" & BatchNo & "' WHERE Deleted = 0 AND ChargeNo = '" & ChargeNo & "'"
				Conn.Execute strSql
				
				strSql = "UPDATE TBL_CTM_BIZ SET BIZ_BATCH = '" & BatchNo & "' WHERE BIZ_DELETED = 0 AND BIZ_NO = '" & ChargeNo & "'"
				Conn.Execute strSql
				
				.movenext
			loop
		end with
			
		if err.number = 0 then
			Conn.CommitTrans
		else
			ShowMessage "������ꊇ�쐬���G���[���N����܂����B"
			Conn.RollbackTrans
		end if
	end if	
	
	Set Recset = nothing
	CloseDB Conn
%>
