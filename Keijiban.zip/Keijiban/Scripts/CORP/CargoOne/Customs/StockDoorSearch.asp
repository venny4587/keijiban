<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
		
dim CTM_CD
dim myCode

	CTM_CD = GetPost(request("CTM_CD"))
	myCode = GetPost(request("cd"))
	if myCode <> "" then selCode = replace(myCode, "'", "''")
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	DOOR_CD = ""
	if myCode <> "" then
		with Recset
			StrSql = "SELECT DOOR_ID, DOOR_PIC, DOOR_NAME, DOOR_ADDR1, DOOR_ADDR2, DOOR_TEL"
			StrSql = StrSql & " FROM CTM_DOOR WHERE DOOR_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
			StrSql = StrSql & " AND (DOOR_ID = " & GetLong(selCode)  & " OR DOOR_CD = '" & selCode & "')"
if WebUserID = gsAdmin then response.write StrSql
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				DOOR_ID = GetLong(.fields("DOOR_ID"))
				DOOR_PIC = GetString(.fields("DOOR_PIC"))
				DOOR_NAME = GetString(.fields("DOOR_NAME"))
				DOOR_ADDR = GetString(.fields("DOOR_ADDR1")) & " " & GetString(.fields("DOOR_ADDR2"))
				DOOR_TEL = GetString(.fields("DOOR_TEL"))
			end if
			.close
		end with
	end if

	if DOOR_ID <> 0 then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
//	if (window.opener.frmInput.StockCode != null) window.opener.frmInput.StockCode.value = "<%=DOOR_PIC%>";
	if (window.opener.frmInput.StockName != null) window.opener.frmInput.StockName.value = "<%=DOOR_NAME%>";
	if (window.opener.frmInput.StockMark != null) window.opener.frmInput.StockMark.value = "<%=DOOR_ADDR%>";
	if (window.opener.frmInput.StockReferNo != null) window.opener.frmInput.StockReferNo.value = "<%=DOOR_TEL%>";
	if (window.opener.frmInput.StockDelivery != null) window.opener.frmInput.StockDelivery.focus();
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE><%=ctmLink(myType)%>����</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "StockDoorSearch.asp?CTM_CD=<%=CTM_CD%>&cd=" + cd;
		}
				
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="StockDoorSearch.asp" NAME=frmInput>
		<input type=hidden name="CTM_CD" value="<%=CTM_CD%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD>�@�[�i�挟���@<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=16 onkeydown="ResetEnter()">
				<TD>�@<INPUT TYPE=submit style="cursor:hand; width:60; height:25" VALUE="����"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		With Recset
			StrSql = "SELECT COUNT(DOOR_ID) AS DOOR_CNT FROM CTM_DOOR WHERE DOOR_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
			if myCode <> "" then 
				StrSql = StrSql & " AND (DOOR_CD = '" & selCode & "' OR DOOR_NAME LIKE '%" & selCode & "%'"
				StrSql = StrSql & " OR DOOR_ADDR1 LIKE '%" & selCode & "%' OR DOOR_TEL LIKE '%" & selCode & "%')"
			end if
if WebUserID = gsAdmin then response.write StrSql
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if GetLong(.fields("DOOR_CNT")) = 0 then
				response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
			elseif GetLong(.fields("DOOR_CNT")) > 30 then
				response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
			else
				.close
				
				StrSql = "SELECT DOOR_ID, DOOR_CD, DOOR_NAME, DOOR_ADDR1 + ' ' + DOOR_ADDR2 AS DOOR_ADDR, DOOR_TEL"
				StrSql = StrSql & " FROM CTM_DOOR WHERE DOOR_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
				if myCode <> "" then 
				StrSql = StrSql & " AND (DOOR_CD = '" & selCode & "' OR DOOR_NAME LIKE '%" & selCode & "%'"
				StrSql = StrSql & " OR DOOR_ADDR1 LIKE '%" & selCode & "%' OR DOOR_TEL LIKE '%" & selCode & "%')"
				end if
				strSQL = strSQL + " ORDER BY DOOR_CD"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>�R�[�h
					<TD nowrap>�[�i��
					<TD nowrap>�Z��
					<TD nowrap>TEL
<%
					myCnt = 0
					myShortCut = ""
					Do Until .EOF	
						myCnt = myCnt + 1		
						DOOR_ADDR = GetString(.Fields("DOOR_ADDR"))		
						myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("DOOR_ID") & "');"
						if myCnt < 10 then
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("DOOR_ID") & "');"
						end if			
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("DOOR_ID")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("DOOR_CD"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("DOOR_NAME"))%><BR>
					<TD class=line nowrap <%=ShowTitle(DOOR_ADDR, 20)%>><%=StringCut(DOOR_ADDR,20)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("DOOR_TEL"))%><BR>
<%							
						.MoveNext
					Loop
				end if				
%>
			</table>
<%
			end if	
			.Close 
		End With
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>