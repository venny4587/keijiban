<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next
dim JobSeq
dim myMode	
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(50)
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		ChargePrint = 0
		JobSalesman = WebUserID
		'ConfirmFrom = formatDate(dateadd("m", -1, date))
	else
		JobType = GetPost(request("JobType"))	
		JobSalesman = GetLong(request("JobSalesman"))
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		ConfirmFrom = GetPost(request("ConfirmFrom"))
		ConfirmTo = GetPost(request("ConfirmTo"))
		JobCode = GetPost(request("JobCode"))
		ChargeNo = GetPost(request("ChargeNo"))
		AmntFrom = GetPost(request("AmntFrom"))
		AmntTo = GetPost(request("AmntTo"))
		if AmntFrom <> "" then AmntFrom = GetDouble(AmntFrom)
		if AmntTo <> "" then AmntTo = GetDouble(AmntTo)
		ChargePrint = GetLong(request("ChargePrint"))
	end if
	
	myLevel = CheckUserLevel(UserShop, "")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�������������</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		function ShowList(mode)
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myBatch, myNos)
			window.parent.parent.result.location.href = "ChargePrintList.asp?batch=" & myBatch & "&nos=" & myNos
		end function
				
		function DoBatch()
		dim win
			set win = window.open("ChargePrintBatch.asp","ChargeBatchProc","resizable=1,scrollbars=1,width=400,height=300")
			win.focus()
		end function
		
		function DoPrint(myBatch, myNos)
		dim mode
			mode = 0
			if myBatch = "" then
				mode = msgbox("�������ɕ\���t���o�b�`�ԍ��𔭍s���Ă�낵���ł����H", 35, "�m�F���b�Z�[�W")
				if mode = 2 then exit function
				mode = mode - 5
			end if
			set win = window.open("ChargePrintMain.asp?mode=" & mode & "&nos=" & myNos,"ChargeExcel","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub ConfirmFrom_OnBlur()
			frmInput.ConfirmFrom.value = setdate(frmInput.ConfirmFrom.value)
		end sub
		sub ConfirmTo_OnBlur()
			frmInput.ConfirmTo.value = setdate(frmInput.ConfirmTo.value)
		end sub
		sub AmntFrom_OnBlur()
			if frmInput.AmntFrom.value = "" then exit sub
			frmInput.AmntFrom.value = GetDouble(frmInput.AmntFrom.value)
		end sub
		sub AmntTo_OnBlur()
			if frmInput.AmntTo.value = "" then exit sub
			frmInput.AmntTo.value = GetDouble(frmInput.AmntTo.value)
		end sub
		sub ChargeNo_OnBlur()
			frmInput.ChargeNo.value = UCASE(frmInput.ChargeNo.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
			frmInput.ConfirmTo.focus()
			window.parent.parent.result.location.href = "../common/blank.htm"
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="ChargeBillPrint.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<table class=pt9>
			<TR><TD nowrap>
				������<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">					
				������<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�Ɩ�&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>	
				�c��&nbsp;<SELECT name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartSales, JobSalesman)%></select>
				�����
			<TR><TD nowrap>
				�����ԍ�<input class=si name="ChargeNo" value="<%=ChargeNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�m���<input class=si name="ConfirmFrom" value="<%=ConfirmFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="ConfirmTo" value="<%=ConfirmTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="ChargePrint" value="1" <%if ChargePrint then response.write " checked"%>>
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
	if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman
	if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 1)
	if DateFrom <> "" then strSel = strSel & " AND ChargeDate >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND ChargeDate <= '" & Date2Str(DateTo) & "'"	
	if AmntFrom <> "" then strSel = strSel & " AND (ChargeAmount + ChargeTax) >= " & AmntFrom
	if AmntTo <> "" then strSel = strSel & " AND (ChargeAmount + ChargeTax) <= " & AmntTo
	if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & JobCode & "%'"
	if ChargeNo <> "" then strSel = strSel & " AND ChargeNo LIKE '%" & ChargeNo & "%'"	
	if ConfirmFrom <> "" then strSel = strSel & " AND CONVERT(VARCHAR(10), ConfirmDate, 111) >= '" & ConfirmFrom & "'"
	if ConfirmTo <> "" then strSel = strSel & " AND CONVERT(VARCHAR(10), ConfirmDate, 111) <= '" & ConfirmTo & "'"
	if ChargePrint = 0 then strSel = strSel & " AND ChargePrinted = 0"
		
	with recset
		strSql = "SELECT CASE ChargeType WHEN 2 THEN 2 ELSE 1 END AS CType, ChargeClientName, ChargeBatch, ChargeNo, ClientCode"
		strSql = strSql & " ,JobCode, ChargeDate, ChargeAmount, ChargeTax, ClientRef, JobSalesman FROM TBL_CTM_CHARGE AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_FINANCE_CD AS ClientCode FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobSalesman FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0"		'���폜 ������ �m���
		if CheckTopLevel() = 0 and myLevel <= 3 then strSql = strSql & " AND SUBSTRING(JobCode,1,1) = '" & UserShop & "'"
		if strSel <> "" then strSQL = strSQL & strSel
		strSql = strSql & " ORDER BY ClientCode, CTYPE DESC, ChargeBatch, ChargeNo"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .EOF then
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		else
			session("ChargeBatch_Sel") = strSel
%>
			<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
				<colgroup span=2 align=center>
				<colgroup span=2 align=left>
				<colgroup align=center>
				<colgroup span=2 align=right>
				<colgroup span=2 align=center>
			  <TR align=center height=20 class=pt9>
				<TD class=line nowrap>��
				<TD class=line nowrap>�敪
				<TD class=line align=left>������
				<TD class=line nowrap>�����
				<TD class=line nowrap>������
				<TD class=line nowrap>����
				<TD class=line nowrap>���v���z
				<TD class=line colspan=2>����
<%
			myConfirm = ""
			ChargeSum = 0
			ChargeTotal = 0
			
			ChargeCnt = 0
			ChargeNos = ""
			ChargeTax = 0	
			ChargeAmount = 0
			ChargeType = GetLong(.fields("CType"))
			ChargeNo = GetString(.fields("ChargeNo"))
			ChargeDate = GetString(.fields("ChargeDate"))
			ChargeBatch = GetString(.fields("ChargeBatch"))
			ChargeClient = GetString(.fields("ClientCode"))
			ClientName = GetFullName(ChargeClient)
			ChargeDiv = mid(GetString(.fields("JobCode")), 2, 1)
			lngCount = 0
			if myConfirm <> ChargeBatch then myConfirm = ChargeBatch
			Do Until .EOF
				if ChargeClient <> GetString(.Fields("ClientCode"))	OR _
				   (ChargeType = 2 AND GetLong(.fields("CType")) <> 2)	OR _
				   (ChargeBatch <> GetString(.fields("ChargeBatch"))) then
					if lngCount = myPageSize then exit do					
					lngCount = lngCount + 1
	%>
				<TR height=20>
					<TD class=line><%=lngCount%><BR>
					<TD class=line><%=ShowBillType(ChargeType)%><BR>
					<TD class=line nowrap <%=ShowTitle(ClientName, 12)%>><%=StringCut(ClientName,12)%><BR>
				<%if ChargeBatch = "" and ChargeCnt = 1 then%>
					<TD class=line><%=ShowVoucherNo(ChargeNo)%><BR>
				<%else%>
					<TD class=line><%=ShowBatchNo(ChargeBatch)%><BR>
				<%end if%>					
					<TD class=line nowrap><%=Str2YMD(ChargeDate)%><BR>
					<TD class=line nowrap><%=ChargeCnt%><BR>
					<TD class=line nowrap><%=formatnumber(ChargeAmount + ChargeTax, 0, true)%><BR>
<%if ChargeDiv <> "" or myLevel > 3 then %>
					<TD class=line><IMG SRC=img/printer.jpg STYLE="cursor:hand" onclick="DoPrint('<%=ChargeBatch%>', '<%=ChargeNos%>')">
<%else%>
					<TD class=line>����<BR>
<%end if%>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=ChargeBatch%>', '<%=ChargeNos%>')">
<%
					ChargeCnt = 0
					ChargeNos = ""
					ChargeTax = 0	
					ChargeAmount = 0	
					ChargeType = GetLong(.fields("CType"))
					ChargeNo = GetString(.fields("ChargeNo"))
					ChargeDate = GetString(.fields("ChargeDate"))
					ChargeBatch = GetString(.fields("ChargeBatch"))
					ChargeClient = GetString(.fields("ClientCode"))
					ClientName = GetFullName(ChargeClient)
					ChargeDiv = mid(GetString(.fields("JobCode")), 2, 1)
					if myConfirm <> ChargeBatch then myConfirm = ChargeBatch
				end if
					
				ChargeCnt = ChargeCnt + 1
				ChargeTax = ChargeTax + GetLong(.Fields("ChargeTax"))
				ChargeAmount = ChargeAmount + GetLong(.Fields("ChargeAmount"))
				if ChargeNos <> "" then ChargeNos = ChargeNos & ","
				ChargeNos = ChargeNos & ResetBizNo(.Fields("ChargeNo"))
				if ChargeDate <> GetString(.fields("ChargeDate")) then ChargeDate = ""
								
				ChargeTotal = ChargeTotal + 1
				ChargeSum = ChargeSum + GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax"))
				if ChargeDiv <> "" then
					if ChargeDiv <> mid(GetString(.fields("JobCode")), 2, 1) then ChargeDiv = ""
				end if
				
				.movenext
			loop				
			lngCount = lngCount + 1
%>
				<TR height=20>
					<TD class=line><%=lngCount%><BR>
					<TD class=line><%=ShowBillType(ChargeType)%><BR>
					<TD class=line nowrap <%=ShowTitle(ClientName, 12)%>><%=StringCut(ClientName,12)%><BR>
				<%if ChargeBatch = "" and ChargeCnt = 1 then%>
					<TD class=line><%=ShowVoucherNo(ChargeNo)%><BR>
				<%else%>
					<TD class=line><%=ShowBatchNo(ChargeBatch)%><BR>
				<%end if%>					
					<TD class=line nowrap><%=Str2YMD(ChargeDate)%><BR>
					<TD class=line nowrap><%=ChargeCnt%><BR>
					<TD class=line nowrap><%=formatnumber(ChargeAmount + ChargeTax, 0, true)%><BR>
<%if ChargeDiv <> "" or myLevel > 3 then %>
					<TD class=line><IMG SRC=img/printer.jpg STYLE="cursor:hand" onclick="DoPrint('<%=ChargeBatch%>', '<%=ChargeNos%>')">
<%else %>
					<TD class=line>����<BR>
<%end if%>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=ChargeBatch%>', '<%=ChargeNos%>')">
<%if lngCount > 1 then%>					
				<TR height=20 align=right>
					<TD colspan=3 align=left><%if lngCount > myPageSize then response.write "<font color=red>�@>> ��������܂�...</font>"%>
					<TD colspan=2 class=pt9>���y�[�W���v<BR>
					<TD class=line><%=ChargeTotal%><BR>
					<TD class=line nowrap><%=formatnumber(ChargeSum, 0, true)%><BR>				
<%end if%>
			</TABLE>			
<%if DateFrom <> "" and DateTo <> "" and myConfirm = "" then%>
	<%if ClientRef = "690" and JobType <> "" then%>
		<div align=right>
			<INPUT style="width:60px;height:25px;" TYPE=button VALUE="�ꊇ" onclick="DoBatch()">
		</div>
	<%end if
  end if
%>
<%
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>
