<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim SeqNo
dim JobClient
		
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	
	ChargeNo = GetPost(request("ChargeNo"))
	myMode = GetLong(request("mode"))
	if JobCode <> "" then
		
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset")
		with Recset
			strSql = "SELECT * FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				ChargeType = GetLong(.fields("ChargeType"))
				ChargeDate = Str2Date(.fields("ChargeDate"))
				
				ChargeClient = GetString(.fields("ChargeClient"))
				ChargeClientName = GetString(.fields("ChargeClientName"))
				ChargePic = GetString(.fields("ChargePic"))
				ChargeAmount = GetLong(.fields("ChargeAmount"))
				ChargeTax = GetLong(.fields("ChargeTax"))
				ChargePayDay = Str2Date(.fields("ChargePayDay"))
				ChargeBatch = GetString(.fields("ChargeBatch"))
				
				ChargeMemo = GetString(.fields("ChargeMemo"))
				ChargeCheck = GetLong(.fields("ChargeCheck"))
				Remarks = GetString(.fields("Remarks"))
			else
				myMode = 0
			end if
			.close
		end with
		
		if myMode <> 0 then
			strSql = "UPDATE TBL_CTM_CHARGE SET Remarks = '" & FitSel(request("Remarks")) & "'"
			if CheckExtendLevel() > 0 then 
				strSql = strSql & ", ChargePayDay = '" & Date2Str(request("ChargePayDay")) & "'" 
			end if
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			Conn.Execute strSql
%>
<html><script language=javascript>
window.opener.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>";
window.close();
</script></html>
<%
		else
			if GetCtmClose(ChargeClient, CloseSales, CloseStand, CloseCosts) then
				SalesCloseDate = Close2Date(CloseSales, Stand)
				StandCloseDate = Close2Date(CloseStand, Stand)
				SalesClose = ShowClose(CloseSales)
				StandClose = ShowClose(CloseStand)
			end if
			if GetCtmSight(ChargeClient, ChargeSales, ChargeStand, ChargeCosts) then
				SalesSightDate = FitDatePlus(Sight2Date(ChargeSales, SalesCloseDate))
				if Date2Str(SalesSightDate) = Date2Str(SalesCloseDate) then SalesSightDate = FitDatePlus(dateadd("d", 7, SalesSightDate))
				StandSightDate = FitDatePlus(Sight2Date(ChargeStand, StandCloseDate))
				if Date2Str(StandSightDate) = Date2Str(StandCloseDate) then StandSightDate = FitDatePlus(dateadd("d", 7, StandSightDate))
				SalesSight = ctmCredit(ChargeSales \ 1000) & ShowPayDay(ChargeSales mod 1000)
				StandSight = ctmCredit(ChargeStand \ 1000) & ShowPayDay(ChargeStand mod 1000)
			end if

%>
<html>
<HEAD>
	<TITLE>�����Г����l</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
<%if WebUserID <> 1 then%>
			if frmInput.ChargePayDay.value <> "<%=FormatDate(ChargePayDay)%>" then
				if checkText("Remarks","��������", 1) = false then exit sub
			else
				if checkText("Remarks","��������", 0) = false then exit sub
			end if
<%end if%>
			if checkLen("Remarks","��������", 250) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
				
		sub DoShortCut()
			if window.event.keyCode=120 then call DataSave()
			if window.event.keyCode=27 then window.close()
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsSalesBackColor%>" topmargin=10 class=pt9 onload="SetEndFocus(frmInput.Remarks)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="ChargeRemarks.asp" method="post">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		<TR><td width=50%>�������ڍ׏��&nbsp;
			<td width=50% align=right><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=28>
		<TD align=center>������
		<TD colspan=5>(<input class=si name="Shipper" size=8 maxlength=10 value="<%=GetRefName(ChargeClient)%>" readonly>)
			<input class=si name="ShipperName" size=45 value="<%=ChargeClientName%>" readonly>
		<TD align=center>�����敪
		<TD><input class=si name="ChargeType" size=10 maxlength=10 value="<%=billType(ChargeType)%>" readonly>
	  <TR height=28>
		<TD align=center>�S����
		<TD colspan=3><input class=sj name="ChargePic" size=30 maxlength=50 value="<%=ChargePic%>" readonly>
		<TD width=60 align=center nowrap>������
		<TD><input class=si name="ChargeClose" size=10 maxlength=10 value="<%=SalesClose%>" readonly>
		<TD width=60 align=center nowrap>�����x��
		<TD><input class=si name="ChargeSight" size=10 maxlength=10 value="<%=SalesSight%>" readonly>
	  <TR height=28>
		<TD width=60 align=center nowrap>������</TD>
		<TD><input class=si name="ChargeDate" size=10 maxlength=10 value="<%=ChargeDate%>" readonly>
<%if CheckExtendLevel() > 0 then %>
		<TD width=60 align=center class=pt9g>������</TD>
		<TD><input class=si name="ChargePayDay" size=10 maxlength=10 value="<%=ChargePayDay%>" onclick="setday(this)">
<%else%>
		<TD width=60 align=center nowrap>������</TD>
		<TD><input class=si name="ChargePayDay" size=10 maxlength=10 value="<%=ChargePayDay%>" readonly>
<%end if%>
		<TD width=60 align=center nowrap>���֒�
		<TD><input class=si name="StandClose" size=10 maxlength=10 value="<%=StandClose%>" readonly>
		<TD width=60 align=center nowrap>���֎x��
		<TD><input class=si name="StandSight" size=10 maxlength=10 value="<%=StandSight%>" readonly>
	  <TR height=24>
		<TD nowrap width=60 align=center>�����ԍ�
		<TD><input class=si name="ChargeNo" size=10 maxlength=10 value="<%=ChargeNo%>" readonly>
		<TD nowrap width=60 align=center>����ԍ�
		<TD><input class=si name="ChargeBatch" size=10 maxlength=10 value="<%=ChargeBatch%>" readonly>
		<TD nowrap width=60 align=center>�Ŕ����z
		<TD><input class=sn name="ChargeAmount" size=10 maxlength=10 value="<%=formatnumber(ChargeAmount, 0, true)%>" readonly>
		<TD nowrap width=60 align=center>�����
		<TD><input class=sn name="ChargeTax" size=10 maxlength=10 value="<%=formatnumber(ChargeTax, 0, true)%>" readonly>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=28>
		<TD class=pt9 align=center>����
		<TD colspan=5><textarea name="Remarks" rows=8 style="width:350"><%=Remarks%></textarea>
		<TD colspan=2 align=center>
			<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave()">
	</TABLE>
  </FORM>
<center>
</body></html>
<%
		end if
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function CheckExtendLevel()
	CheckExtendLevel = 0
	select case left(JobCode, 1)
	case "O":	if WebUserID = 24 then CheckExtendLevel = 1
	case "K":	if WebUserID = 46 then CheckExtendLevel = 1
	case "M":	if WebUserID = 60 then CheckExtendLevel = 1
	case "T":	if WebUserID = 73 then CheckExtendLevel = 1
	end select
	select case WebUserID
	case 1, 2, 30, 32
		CheckExtendLevel = 1
	end select
end function
%>