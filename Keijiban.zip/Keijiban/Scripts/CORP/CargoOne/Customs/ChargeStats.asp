<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/Function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����߃`�F�b�N���
'----------------------------------------------

'on error resume next
		
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")	
	
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 3 then
		if CheckTopLevel() > 0 then myLevel = 3
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����󋵈ꗗ</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowDetail(myJob)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & myJob,"","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		function ShowList(myMode, mySel)
		dim url
			select case myMode 
			case 1:		url = "ChargeBillExec.asp?mode=1&JobFinish=1&JobSalesman=" & mySel
			case 2:		url = "ChargeBillProc.asp?mode=1&ChargeCheck=1&JobSalesman=" & mySel
			case 3:		url = "ChargeBillPrint.asp?mode=1&DateTo=" & date() & "&JobSalesman=" & mySel
			case 4:		url = "ChargeBillView.asp?mode=1&PayDayTo=" & dateadd("d", -1, date()) & "&JobSalesman=" & mySel
			case 5:		url = "ChargeBillView.asp?mode=1&ChargeNo=CHS&ClientRef=" & mySel
			end select
			window.location.href = url
		end function
	</SCRIPT>
</HEAD>

<BODY class=pt9 <%=gsBodyControl%>>
  <center>
	<table width=98% class=pt9n cellspacing=3>
	  <tr><td align=center>������Ɩ������ꗗ (<b><%=ShowDateTimeShort(now)%></b>����)
	</table>
	<br>
	<table width=98% class=pt9n cellspacing=3>
	  <tr height=24 align=center>
	  	<td width=25% bgcolor="#E0E0E0">���쐬
	  	<td width=25% bgcolor="#E0FFE0">���m��
	  	<td width=25% bgcolor="#E0FFFF">�����
	  	<td width=25% bgcolor="#FFE0E0">���������؂�
	  <tr valign=top align=center>
	  	<td>
<%
	'���������쐬
	with Recset
		strSql = "SELECT JobSalesman, COUNT(JobCode) AS CNT FROM TBL_CTM_JOB"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID <> 0 AND SalesDate = ''"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " GROUP BY JobSalesman ORDER BY CNT DESC"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9n>���쐬�Ȃ�</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>"
			response.write "<colgroup align=center><colgroup align=right>"
			do while not .eof
				cnt = cnt + 1
				myColor = ""
				if WebUserID = GetLong(.Fields("JobSalesman")) then myColor = ";color:red"
				response.write "<tr height=24 style=""cursor:hand" & myColor & """"
				response.write " onmousedown=""ShowList(1, " & GetLong(.Fields("JobSalesman")) & ")"">"
				response.write "<td>" & GetEmployName(.Fields("JobSalesman"), "F") & "<td>" & .fields("CNT") & "��"
				total = total + .fields("CNT")
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24 style=""cursor:hand"" onmousedown=""ShowList(1, 0)""><td>���v<td>" & total & "��"
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
		<td>
<%
	'���������m��
	with Recset
		strSql = "SELECT JobSalesman, COUNT(ChargeNo) AS CNT FROM TBL_CTM_CHARGE AS C INNER JOIN TBL_CTM_JOB AS J"
		strSql = strSql & " ON C.JobCode = J.JobCode WHERE C.Deleted  = 0 AND J.Deleted = 0 AND ChargeCheck = 1 AND ConfirmerID = 0"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " GROUP BY JobSalesman ORDER BY CNT DESC"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9n>���m��Ȃ�</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>"
			response.write "<colgroup align=center><colgroup align=right>"
			do while not .eof
				cnt = cnt + 1
				myColor = ""
				if WebUserID = GetLong(.Fields("JobSalesman")) then myColor = ";color:red"
				response.write "<tr height=24 style=""cursor:hand" & myColor & """"
				response.write " onmousedown=""ShowList(2, " & GetLong(.Fields("JobSalesman")) & ")"">"
				response.write "<td>" & GetEmployName(.Fields("JobSalesman"), "F") & "<td>" & .fields("CNT") & "��"
				total = total + .fields("CNT")
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24 style=""cursor:hand"" onmousedown=""ShowList(2, 0)""><td>���v<td>" & total & "��"
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
		<td>
<%
	'�����������
	with Recset
		strSql = "SELECT JobSalesman, COUNT(ChargeNo) AS CNT FROM TBL_CTM_CHARGE AS C INNER JOIN TBL_CTM_JOB AS J"
		strSql = strSql & " ON C.JobCode = J.JobCode WHERE C.Deleted  = 0 AND J.Deleted = 0 AND ConfirmerID <> 0"
		strSql = strSql & " AND ChargePrinted = 0 AND C.FinisherID = 0 AND ChargeDate <= '" & Date2Str(date) & "'"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " GROUP BY JobSalesman ORDER BY CNT DESC"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9n>������Ȃ�</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>"
			response.write "<colgroup align=center><colgroup align=right>"
			do while not .eof
				cnt = cnt + 1
				myColor = ""
				if WebUserID = GetLong(.Fields("JobSalesman")) then myColor = ";color:red"
				response.write "<tr height=24 style=""cursor:hand" & myColor & """"
				response.write " onmousedown=""ShowList(3, " & GetLong(.Fields("JobSalesman")) & ")"">"
				response.write "<td>" & GetEmployName(.Fields("JobSalesman"), "F") & "<td>" & .fields("CNT") & "��"
				total = total + .fields("CNT")
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24 style=""cursor:hand"" onmousedown=""ShowList(3, 0)""><td>���v<td>" & total & "��"
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
		<td>
<%
	'�����������
	with Recset
		strSql = "SELECT JobSalesman, SUM(ChargeAmount+ChargeTax) AS TTL FROM TBL_CTM_CHARGE AS C INNER JOIN TBL_CTM_JOB AS J"
		strSql = strSql & " ON C.JobCode = J.JobCode WHERE C.Deleted  = 0 AND J.Deleted = 0 AND ConfirmerID <> 0"
		strSql = strSql & " AND C.FinisherID = 0 AND ChargePayDay < '" & Date2Str(date) & "'"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " GROUP BY JobSalesman ORDER BY TTL DESC"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9n>������Ȃ�</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>"
			response.write "<colgroup align=center><colgroup align=right>"
			do while not .eof
				cnt = cnt + 1
				myColor = ""
				if WebUserID = GetLong(.Fields("JobSalesman")) then myColor = ";color:red"
				response.write "<tr height=24 style=""cursor:hand" & myColor & """"
				response.write " onmousedown=""ShowList(4, " & GetLong(.Fields("JobSalesman")) & ")"">"
				response.write "<td>" & GetEmployName(.Fields("JobSalesman"), "F") & "<td>" & formatnumber(.fields("TTL"), 0, true)
				total = total + .fields("TTL")
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24 style=""cursor:hand"" onmousedown=""ShowList(4, 0)""><td>���v<td>" & formatnumber(total,0,true) 
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
	</table>
	<br>
	
	
	
	<table width=96% class=pt9n cellspacing=3>
	  <tr><td align=center>���֐������߈ꗗ (<b><%=ShowDateTimeShort(now)%></b>����)
	</table>
	<br>
	<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>
	  <colgroup span=5 align=center>
	  <colgroup align=right>
	  <colgroup align=center>
	  <tr height=24 align=center bgcolor="#E0E0FF">
	  	<td width=5%>��
	  	<td width=15%>�׎喼
	  	<td width=15%>���֒�
	  	<td width=15%>�T�C�g
	  	<td width=15%>���֐���
	  	<td width=20%>�������֋�
	  	<td width=10%>�c��
<!--	  	<td width=5%>����	-->
<%
	'���֐��������
	with Recset
		strSql = "SELECT * FROM (SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_SALESMNGR FROM CUSTOMER) AS C INNER JOIN"
		strSql = strSql & " (SELECT CTM_CD, CTM_STAND_CLOSE, CTM_STAND_CREDIT, CTM_STAND_PAYDAY, CTM_STAND_LIMIT"
		strSql = strSql & " FROM CTM_CONTACT WHERE CONTACT_PAST = 0) AS T ON C.CTM_CD = T.CTM_CD INNER JOIN ("				
		strSql = strSql & " SELECT BIZ_BROKER_CD AS CTM_CD, SUM(BIZ_AMOUNT+BIZ_TAX) AS TTL FROM TBL_CTM_BIZ "
		strSql = strSql & " WHERE BIZ_DELETED = 0 AND SUBSTRING(BIZ_NO, 3, 1) = 'S' AND ERASE_ID = 0 "
		if myLevel < 3 then strSql = strSql & " AND BIZ_BELONG = '" & UserShop & "'"
		strSql = strSql & " GROUP BY BIZ_BROKER_CD) AS J ON C.CTM_CD = J.CTM_CD WHERE TTL > CTM_STAND_LIMIT * 10000"
		strSql = strSql & " ORDER BY CTM_SALESMNGR, TTL DESC"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<tr height=30><td colspan=8>�������߂Ȃ�</font>"
		else
			cnt = 0:	total = 0
			do while not .eof
				cnt = cnt + 1
				response.write "<tr height=24 style=""cursor:hand"""
				if GetLong(.Fields("TTL")) > 5000000 then response.write " color=red "
				response.write " onmousedown=""ShowList(5, '" & GetString(.Fields("CTM_REF")) & "')"">"
				response.write "<td>" & cnt & "<td>" & GetString(.Fields("CTM_REF")) & "<td>" & ShowClose(GetLong(.Fields("CTM_STAND_CLOSE")))
				response.write "<td>" & ctmCredit(GetLong(.Fields("CTM_STAND_CREDIT"))) & ShowPayDay(GetLong(.Fields("CTM_STAND_PAYDAY")))
				response.write "<td>" & GetLong(.Fields("CTM_STAND_LIMIT")) & "��<td>" & formatnumber(GetLong(.Fields("TTL")), 0, true)
				response.write "<td>" & GetEmployName(.Fields("CTM_SALESMNGR"), "F")	' & "<td onmousedown=""DoMail()"">���M<br>"
				total = total + .fields("TTL")
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24><td colspan=5 align=center>���v<td>" & formatnumber(total, 0, true) & "<td colspan=2><br>"
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
	</table>
	<br>
	
	
	
	<table width=90% class=pt9n cellspacing=3>
	  <tr><td align=center>�������񌏈ȏ㔭�s (<b><%=ShowDateTimeShort(now)%></b>����)
	</table>
	<br>
	<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>
	  <colgroup align=center>
	  <colgroup align=left>
	  <colgroup align=center>
	  <colgroup span=2 align=right>
	  <colgroup align=center>
	  <tr height=24 align=center bgcolor="#C0C0C0">
	  	<td width=5%>��
	  	<td width=40%>�׎喼
	  	<td width=15%>�䒠�ԍ�
	  	<td width=10%>����
	  	<td width=20%>�������z
	  	<td width=10%>�c��
<%
	'�����񖇂��蕪
	with Recset
		strSql = "SELECT * FROM (SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_SALESMNGR FROM CUSTOMER) AS C INNER JOIN"
		strSql = strSql & " (SELECT JobCode, JobClient, SalesDate FROM TBL_CTM_JOB WHERE Deleted = 0"
		strSql = strSql & " AND AccountDate = '' AND SUBSTRING(JobCode, 1, 1) <> '" & gsSokoInit & "'"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & ") AS J ON C.CTM_CD = J.JobClient INNER JOIN"
		strSql = strSql & " (SELECT JobCode AS CD, COUNT(ChargeNo) AS CNT, SUM(ChargeAmount+ChargeTax) AS TTL"
		strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeType <> " & gsStand
		strSql = strSql & " GROUP BY JobCode HAVING COUNT(ChargeNo) > 1) AS T ON J.JobCode = T.CD"
		strSql = strSql & " ORDER BY CTM_SALESMNGR, CTM_NAME, JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<tr height=30><td colspan=8>�����񌏈ȏ�Ȃ�</font>"
		else
			cnt = 0:	total = 0
			do while not .eof
				cnt = cnt + 1
				response.write "<tr height=24 style=""cursor:hand"" onmousedown=""ShowDetail('" & GetString(.Fields("JobCode")) & "')"">"
				response.write "<td>" & cnt & "<td>" & GetString(.Fields("CTM_NAME")) & "<td>" & GetString(.Fields("JobCode"))
				response.write "<td>" & GetLong(.Fields("CNT")) & "<td>" & formatnumber(GetLong(.Fields("TTL")), 0, true)
				response.write "<td>" & GetEmployName(.Fields("CTM_SALESMNGR"), "F")	' & "<td onmousedown=""DoMail()"">���M<br>"
				total = total + .fields("TTL")
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24><td colspan=4 align=center>���v<td>" & formatnumber(total, 0, true) & "<td><br>"
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
	</table>
	<br>



  </center>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>