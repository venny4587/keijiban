<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
dim JobCode

	JobCode = GetPost(request("JobCode"))
	mode = GetLong(request("mode"))

	OpenSQL Conn, SqlServerName, DataBaseName
	
	msg = ""
	select case mode
	case 1, 2				'�ۑ� ���b�N
		if CheckJobFinished(JobCode) then
			msg = "�Y���������͊��Ɋm�肳��܂����I"
		end if
		
		if msg = "" then
			Set Recset = Server.CreateObject ("ADODB.Recordset")
			with Recset		
				StrSql = "SELECT * FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if not .eof then
					.fields("POLN") = GetPost(Request("POLN"))
					.fields("POL") = GetPortName(GetPost(Request("POL")))
					.fields("PODN") = GetPost(Request("PODN"))
					.fields("POD") = GetPortName(GetPost(Request("POD")))
					
					.fields("JobType") = GetPost(Request("JobType"))
					.fields("JobService") = GetPost(Request("JobService"))
					.fields("JobShipper") = GetPost(Request("JobShipper"))
					.fields("JobManager") = GetLong(Request("JobManager"))
					.fields("Vessel") = GetPost(Request("Vessel"))
					.fields("Voy") = GetPost(Request("Voy"))
					.fields("ETD") = Date2Str(Request("ETD"))
					.fields("ETA") = Date2Str(Request("ETA"))
					.fields("MBL") = GetPost(Request("MBL"))
					.fields("HBL") = GetPost(Request("HBL"))
					.fields("Commodity") = GetPost(Request("Commodity"))
					.fields("Quantity") = GetDouble(Request("Quantity"))
					.fields("Package") = GetPost(Request("Package"))
					.fields("GW") = GetDouble(Request("GW"))
					.fields("CBM") = GetDouble(Request("CBM"))
					if GetDouble(Request("GW")) > GetDouble(Request("CBM")) * 1000 then
						.fields("RTON") = GetDouble(Request("GW")) / 1000
					else
						.fields("RTON") = GetDouble(Request("CBM"))
					end if
					.fields("Marks") = GetPost(Request("Marks"))
					.fields("JobNo") = GetPost(Request("JobNo"))
					.fields("EdaNo") = GetPost(Request("EdaNo"))
					.fields("ReferNo") = GetPost(Request("ReferNo"))
					.fields("Container") = GetPost(Request("Container"))
					.fields("InvoiceNo") = GetPost(Request("InvoiceNo"))
					
					for i = 1 to ubound(ctmInspect)
						myInspect = myInspect & GetLong(Request("Inspection" & i))
					next
					.fields("Inspection") = left(myInspect & "000000000", 9)
					.fields("Insurance") = GetLong(Request("Insurance"))
					.fields("Surrendered") = GetLong(Request("Surrendered"))
					
					.fields("CustomType") = GetLong(Request("CustomType"))
					.fields("CustomSheet") = GetPost(Request("CustomSheet"))
					
'���ފǗ���			.fields("Delivered") = GetLong(Request("Delivered"))
					.fields("RequireDate") = Date2Str(Request("RequireDate"))
					.fields("DeliveryDate") = Date2Str(Request("DeliveryDate"))
					.fields("ShipCorp") = GetPost(Request("ShipCorp"))
					.fields("ShipPic") = GetPost(Request("ShipPic"))
					if GetPost(Request("CustomBroker")) <> gsCorpCode then
						.fields("CustomType") = GetLong(Request("CustomType"))
						.fields("CustomSheet") = right("00" & GetLong(request("Sheet1")), 2) & "/" & right("00" & GetLong(request("Sheet2")), 2)
					end if
					.fields("CustomBroker") = GetPost(Request("CustomBroker"))
					.fields("CustomRemark") = GetPost(Request("CustomRemark"))
					.fields("CarryPlace") = GetPost(Request("CarryPlace"))
					.fields("CarryDate") = Date2Str(Request("CarryDate"))
					.fields("PermitNo") = GetPost(Request("PermitNo"))
					.fields("PermitDate") = Date2Str(Request("PermitDate"))
					.fields("FreeTime") = Date2Str(Request("FreeTime"))
					.fields("ViaPlace") = GetPost(Request("ViaPlace"))
					.fields("ReturnDate") = Date2Str(Request("ReturnDate"))
					.fields("Remarks") = GetPost(Request("Remarks"))
					if GetPost(Request("CustomBroker")) = gsCorpCode and left(JobCode, 1) <> gsCorpInit and UserShop <> gsCorpInit then
						if GetLong(.fields("JobOperator")) = WebUserID then .fields("JobOperator") = 0			'�x�Ђ͖{�ЂɔC����ꍇ
					elseif .fields("JobOperator") = 0 then
						.fields("JobOperator") = WebUserID
					end if
					if isDate(Request("SalesDate")) then
					 	.fields("SalesDate") = Date2Str(Request("SalesDate"))
					end if
					
					.fields("Updater") = WebUserID
					.fields("Updated") = now()
					.update
					.close
				else
					msg = "�Y���f�[�^��������܂���ł����B"
				end if
			end with
			set Recset = nothing
			
		end if
		
		if msg <> "" then 
			ShowMessage msg
		elseif mode = 1 then
%>
	<html>
		<script language=javascript>
			alert("�Y���ʊփf�[�^�͍X�V����܂����I");
			window.location.href = "CustomsEdit.asp?JobCode=<%=JobCode%>";
		</script>
	</html>
<%
		elseif mode = 2 then 		'�Ɩ����b�N
		
			strSql = "UPDATE TBL_CTM_JOB SET FinishDate = GETDATE()"
			strSql = strSql & ", FinisherID = " & WebUserID
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			Conn.execute strSql			
%>
	<html>
		<script language=javascript>
			alert("�Y���Ɩ��f�[�^�̓��b�N����܂����I");
			window.location.href = "CustomsEdit.asp?JobCode=<%=JobCode%>";
		</script>
	</html>
<%
		end if
		
	case 3		'���b�N����
		
		if CheckJobLocked(JobCode) then			'��p���b�N���Ă������\
		
			msg = "�Y���Ɩ��͔�p���b�N����܂����B"
		
		else
		
			Conn.execute "UPDATE TBL_CTM_JOB SET FinishDate = NULL, FinisherID = 0 WHERE JobCode = '" & JobCode & "'"
			
			msg = "�Y���Ɩ����b�N�͉�������܂����I"
			
		end if
%>
	<html>
		<script language=javascript>
			alert("<%=msg%>");
			window.location.href = "CustomsEdit.asp?JobCode=<%=JobCode%>";
		</script>
	</html>
<%
		
	case 0		'�L�����Z��
	
		if CheckJobFinished(JobCode) then
		
			msg = "�Y���������͊��Ɋm�肳��܂����I"
			
		else
		
			strSql = "UPDATE TBL_CTM_JOB SET Canceled = 1"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			Conn.execute strSql
			
			msg = "�Y���Ɩ��f�[�^�͎������܂����I"
			
		end if
%>
	<html>
		<script language=javascript>
			alert("<%=msg%>");
			window.location.href = "CustomsNew.asp";
		</script>
	</html>
<%
	case -1			'�폜
		
		if CheckJobFinished(JobCode) then
		
			msg = "�Y���������͊��Ɋm�肳��܂����I"
			
		else
		
			'�������`�F�b�N
			Set Recset = Server.CreateObject ("ADODB.Recordset")
			with Recset		
				StrSql = "SELECT ChargeNo FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if not .eof then msg = "�Y���䒠�ԍ��͐������������ł��B" & GetString(.fields("ChargeNo"))
				.Close
				
				if msg = "" then
					StrSql = "SELECT CostsNo FROM TBL_CTM_COSTS WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
					if not .eof then msg = "�Y���䒠�ԍ��͎x���`�[�������ł��B" & GetString(.fields("CostsNo"))
					.Close
				end if
			end with
											
		end if
		
		if msg <> "" then
			ShowMessage msg
		else
		
			strSql = "UPDATE TBL_CTM_JOB SET Deleted = 1"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			Conn.execute strSql
		
%>
	<html>
		<script language=javascript>
			alert("�Y���Ɩ��f�[�^�͍폜����܂����I");
//			window.location.href = "CustomsNew.asp";
			window.close();
		</script>
	</html>
<%
		end if

	end select
	CloseDB Conn
%>

