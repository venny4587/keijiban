<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim mode
dim JobCode
dim JobBelong
dim JobBroker
dim JobClient
dim ChargeClient
	
	mode = GetLong(request("mode"))
	JobCode = GetPost(request("JobCode"))
	if JobCode <> "" then 
		if len(JobCode) < 10 then 
			if instr(JobCode, "-") <> 0 then
				JobCode = ucase(left(JobCode,5)) & right("0000" & mid(JobCode,6),5)
			else
				JobCode = ucase(left(JobCode,4)) & "-" & right("0000" & mid(JobCode,5),5)
			end if
		end if
		JobCode = ucase(JobCode)
		JobHeader = ShowCstmJobHead(JobCode, 1)
		if JobBroker = gsCorpCode then			'�{�Јϑ�
			myLevel = CheckUserLevel(gsCorpInit, JobBroker)
			if UserShop <> gsCorpInit and UserShop = left(JobCode, 1) then 
				myLevel = CheckUserLevel(JobBelong, JobBroker)
			end if
		else
			myLevel = CheckUserLevel(JobBelong, JobBroker)
			if UserShop = gsCorpInit then 
				myLevel = CheckUserLevel(gsCorpInit, "")
			end if
		end if
		if trim(JobHeader) <> "" then 
			if CheckJobLocked(JobCode) then
				ShowMessage "�Y������Ɩ��͊��Ƀ��b�N����܂����B"
			elseif myLevel > 0 then
				session("JobCode_CostsInput") = left(JobCode, 5)
				response.redirect "CostsHead.asp?JobCode=" & JobCode
				response.end
			else
				mode = 2
			end if
		end if
	else
		JobCode = GetString(session("JobCode_CostsInput"))
	end if
%>
<html>
<HEAD>
	<TITLE>�x���ڍד���</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
	</SCRIPT>
</Head>
<body leftmargin=0 topmargin=3 class=pt9 onload="SetEndFocus(frmInput.JobCode)" <%=gsBodyControl%>>
<center>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td width=50%>����������&nbsp;
		<td width=50% align=right>
	</table>
	<hr width=96% size=1>
  <FORM NAME="frmInput" action="CostsInput.asp" method="post">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td>&nbsp;�䒠�ԍ�&nbsp;
	  	<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10>
		<%if mode = 1 then%><font color=red>�Y���䒠�ԍ��͌�����܂���ł����B</font><%end if%>
		<%if mode = 2 then%><font color=red>�Y���䒠�ԍ���<%=GetShopName(UserShop)%>�̏����ΏۊO�ł��B</font><%end if%>
	</table>
  </FORM>
<center>
<script language=vbscript>
	window.parent.parent.result.location.href = "CostsResult.asp?type=0"
</script>
</body></html>