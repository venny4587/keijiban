<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/function.asp" -->
<%
if UserShop = gsCorpInit then
	url = "CustomsCheck.asp"
elseif instr(GetString(Session("Depart")), "�c") > 0 then
	url = "CustomsStand.asp"
else
	url = "CustomsView.asp"
end if
%>
<HTML>
<HEAD>
<TITLE>�ʊ֋Ɩ��������C�����j���[</TITLE>
</HEAD>
	<FRAMESET rows="50,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="CustomsMenu.asp" NAME="cmenu" MARGINWIDTH="0" MARGINHEIGHT="0" noresize scrolling=no>
		<FRAME SRC="<%=url%>" NAME="cbody" MARGINWIDTH="10" MARGINHEIGHT="0" noresize>
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>