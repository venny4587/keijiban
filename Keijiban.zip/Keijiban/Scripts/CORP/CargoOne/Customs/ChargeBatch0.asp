<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�o�b�`�폜����
'----------------------------------------------
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim BatchID
	
	blnDelete = True
	BatchNo = GetPost(Request("BatchNo"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT BatchNo FROM TBL_CTM_BATCH WHERE Deleted = 0 AND FinisherID <> 0 AND BatchNo = '" & BatchNo & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y���o�b�`�ԍ��ɂ͊��ɏo������܂����B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then
		
		'�����d��o�b�`�ԍ�����
		strSQL = "UPDATE TBL_CTM_BIZ SET BIZ_BATCH = ''"
		strSQL = strSQL & ",BIZ_UPDATED = GETDATE()"
		strSQL = strSQL & ",BIZ_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE BIZ_BATCH = '" & BatchNo & "'"
		Conn.Execute strSQL	
		
		'�������o�b�`�ԍ�����
		strSQL = "UPDATE TBL_CTM_CHARGE SET ChargeBatch = ''"
		strSQL = strSQL & ",Updated = GETDATE()"
		strSQL = strSQL & ",Updater = " & WebUserID
		strSQL = strSQL & " WHERE ChargeBatch = '" & BatchNo & "'"
		Conn.Execute strSQL	

		'�o�b�`�ԍ��폜
		strSQL = "UPDATE TBL_CTM_BATCH SET Deleted = 1"
		strSQL = strSQL & ",Updated = GETDATE()"
		strSQL = strSQL & ",Updater = " & WebUserID
		strSQL = strSQL & " WHERE BatchNo = '" & BatchNo & "'"
		Conn.Execute strSQL	

		strURL = "ChargeBatch.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>