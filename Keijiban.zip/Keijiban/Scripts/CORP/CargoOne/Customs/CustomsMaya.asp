<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
JobCode = GetPost(request("JobCode"))
if JobCode <> "" then

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			JobClient = GetString(.fields("JobClient"))
			JobBelong = GetString(.fields("JobBelong"))
			JobManager = GetLong(.fields("JobManager"))
			JobSalesman = GetLong(.fields("JobSalesman"))
			JobOperator = GetLong(.fields("JobOperator"))
			
			ReferNo = GetString(.fields("ReferNo"))
			JobNo = GetString(.fields("JobNo"))
			EdaNo = GetString(.fields("EdaNo"))	
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POL = GetString(.fields("POL"))
			POD = GetString(.fields("POD"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			MBL = GetString(.fields("MBL"))
			HBL = GetString(.fields("HBL"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Container = GetString(.fields("Container"))
			InvoiceNo = GetString(.fields("InvoiceNo"))
			
			JobShipper = GetString(.fields("JobShipper"))
			RequireDate = Str2Date(.fields("RequireDate"))
			Insurance = GetLong(.fields("Insurance"))
			Inspection = GetString(.fields("Inspection"))
			Surrendered = GetLong(.fields("Surrendered"))
			ShipCorp = GetString(.fields("ShipCorp"))
			ShipPic = GetString(.fields("ShipPic"))
			CustomBroker = GetString(.fields("CustomBroker"))
			CarryPlace = GetString(.fields("CarryPlace"))
			CarryDate = Str2Date(.fields("CarryDate"))
			FreeTime = Str2Date(.fields("FreeTime"))
			PermitNo = GetString(.fields("PermitNo"))
			PermitDate = Str2Date(.fields("PermitDate"))
			ObtainDate = GetLong(.fields("ObtainDate"))
			ReturnDate = Str2Date(.fields("ReturnDate"))
			DeliveryDate = Str2Date(.fields("DeliveryDate"))
			
			Remarks = GetString(.fields("Remarks"))
			FinisherID = GetLong(.fields("FinisherID"))
			FinishDate = GetDate(.fields("FinishDate"))
			LockerID = GetLong(.fields("LockerID"))
			LockDate = GetDate(.fields("LockDate"))
			Canceled = GetLong(.fields("Canceled"))	
				
		end if
		.close
		
		StrSql = "SELECT CTM_NACCS_CD, CTM_ETC_CODE, CTM_ETC_DATA FROM CUSTOMER WHERE CTM_CD = '" & JobClient & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			CTM_NACCS_CD = GetString(.fields("CTM_NACCS_CD"))
			CTM_ETC_CODE = GetString(.fields("CTM_ETC_CODE"))
			CTM_ETC_DATA = GetString(.fields("CTM_ETC_DATA"))
		end if 
		.close
	end with	
		
  	if FinisherID <> 0 then 
  		Status = "<font color=black>��Ɗ���</font>"
  	elseif Canceled then 
  		Status = "<font color=red>�Ɩ����~</font>"
  	elseif Quantity = 0 OR Package = "" then
  		Status = "<font color=red>�o�^��</font>"
  	else
  		Status = "<font color=blue>������</font>"
  	end if  
%>

<html>
<HEAD>
	<TITLE>�Ɩ��o�^</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</Head>
<body bgcolor="#FFFFF0" onload="LockAll()" topmargin=3 class=pt9 <%=gsBodyControl%>>
<form name=frmInput>
  <div align=right>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	    <td width=50%>���׎���&nbsp;
	  	<td width=50% align=right>
<%	if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif  alt="�m�F�ҁF<%=GetEmployName(FinisherID, "F") & " (" & ShowDateTimeShort(FinishDate) & ")"%>">
<%	end if %>
	</table>
	<hr width=98% size=1 color=blue>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=22>
		<TD>�䒠�ԍ�&nbsp;<input class=si name="JobCode" size=10 maxlength=10 value="<%=JobCode%>">
			NACCS����&nbsp;<input class=si name="CTM_NACCS_CD" size=12 maxlength=10 value="<%=CTM_NACCS_CD%>">
	  <TR height=22>
		<TD>�����׎�&nbsp;<input class=si name="ClientName" size=36 maxlength=100 value="<%=GetCtmName(JobClient)%>">
	  <TR height=22>
		<TD>�S �� ��&nbsp;<input class=si name="CTM_PIC_NAME" size=16 maxlength=20 value="<%=GetClientManager(JobManager)%>">
	  <TR height=22>
		<TD>B/L��׎�&nbsp;<input class=si name="ShipperName" size=36 maxlength=100 value="<%=GetCtmName(JobShipper)%>">
	  <TR height=22>
		<TD>��ی�&nbsp;<input class=si name="CTM_ETC_CODE" size=12 maxlength=10 value="<%=CTM_ETC_CODE%>">
			���[�ԍ�&nbsp;<input class=si name="CTM_ETC_DATA" size=12 maxlength=20 value="<%=CTM_ETC_DATA%>">	
			
	</table>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0>
	�@<tr><td width=100% valign=top>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  <TR><td width=50% class=pt9n>���Ɩ����&nbsp;
		 	  <td width=50% class=pt9n align=center>�Ɩ��S���F<%=GetEmployName(JobOperator, "F")%>
		  <TR><td colspan=2><hr width=98% size=1 color=blue>
		</table>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  <TR height=22><TD colspan=2>
		  	POL�@<input class=si name="POL" size=14 maxlength=50 value="<%=POL%>">
		  	POD�@<input class=si name="POD" size=14 maxlength=50 value="<%=POD%>">
		  <TR height=22>
		  	<TD>VESSEL<TD><input class=si name="Vessel" size=16 maxlength=50 value="<%=Vessel%>">
		    �@VOY <input class=si name="Voy" size=6 maxlength=20 value="<%=Voy%>">
		  <TR height=22>
		  	<TD>�_��<TD><input class=si name="ReferNo" size=16 maxlength=20 value="<%=ReferNo%>">
		    �@ETD <input class=si name="ETD" size=10 maxlength=10 value="<%=ETD%>">
		  <TR height=22>
		  	<TD>INV ��<TD><input class=si name="InvoiceNo" size=16 maxlength=20 value="<%=InvoiceNo%>">
		    �@ETA <input class=si name="ETA" size=10 maxlength=10 value="<%=ETA%>">
		  <TR height=22><TD>M B/L<TD><input class=si name="MBL" size=13 maxlength=50 value="<%=MBL%>">
		    �@H B/L <input class=si name="HBL" size=13 maxlength=50 value="<%=HBL%>">
		  <TR height=22><TD>�i��<TD>
			<input class=si name="Commodity" size=36 maxlength=100 value="<%=Commodity%>">
		  <TR height=22 class=pt9n><TD>��<TD><input class=sn name="Quantity" value="<%=formatnumber(Quantity,3,true)%>" size=8 maxlength=8 OnKeyDown="ResetEnter()">
			�@�׎p <input class=si name="Package" value="<%=Package%>" size=10 maxlength=10 OnKeyDown="ResetEnter()">
		  <TR height=22><TD class=pt9n>WEIGHT<TD><input class=sn name="GW" value="<%=formatnumber(GW,3,true)%>" size=8 maxlength=8 OnKeyDown="ResetEnter()">&nbsp;KGS
			�@�@KGS���Z
		  <TR height=22><TD>MEASURE<TD><input class=sn name="CBM" value="<%=formatnumber(CBM,3,true)%>" size=8 maxlength=8 OnKeyDown="ResetEnter()">&nbsp;M<sup>3</sup>
			�@(<label ID="WT" name="WT" style="width:40;text-align:right;color:black"><%=GetKGS(GW, CBM)%></label> KGS )
		  <TR height=22><TD>���Ň�<BR><BR><TD><textarea class=sz name="Container" rows=5 style="width:200"><%=Container%></textarea>
		  <TR height=22><TD width=60>�D���<TD><input class=si name="ShipCorp" size=16 maxlength=50 value="<%=ShipCorp%>">
				������<input class=si name="CarryDate" size=10 maxlength=10 value="<%=CarryDate%>">
		  <TR height=22><TD>�A����<TD><input class=si name="ShipPic" size=14 maxlength=50 value="<%=ShipPic%>">
		  		FreeTime&nbsp;<input class=si name="FreeTime" size=10 maxlength=10 value="<%=FreeTime%>">
		  <TR height=22><TD>�[�i��<TD nowrap><input class=si name="RequireDate" size=10 maxlength=10 value="<%=RequireDate%>">
		  	�@&nbsp;<%for i = 1 to 3%><%=ctmInspect(i)%><input type=checkbox name="Inspection<%=i%>" value="1" 
		  		<%if mid(Inspection, i, 1) = "1" then response.write "checked"%>> <%next%>
		  <TR height=22><TD colspan=2 nowrap><%for i = 4 to ubound(ctmInspect)%><%=right(ctmInspect(i), 2)%><input type=checkbox name="Inspection<%=i%>" value="1"
		  	 	<%if mid(Inspection, i, 1) = "1" then response.write "checked"%>> <%next%>
		  <TR height=22 valign=top><TD><BR>���l<TD colspan=2><BR><textarea class=sz name="Remarks" rows=5 style="width:200"><%=Remarks%></textarea>
		</table>
	</table>
  </div>
</form>	
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
end if
%>

<%
function GetClientManager(myID)
dim mySql
dim myRec

	GetClientManager = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT PIC_ID, PIC_NAME, PIC_DFT FROM CTM_PIC WHERE PIC_ID = " & myID
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetClientManager = GetString(myRec.fields("PIC_NAME"))
	myRec.close
	set myRec = nothing	
end function
%>

