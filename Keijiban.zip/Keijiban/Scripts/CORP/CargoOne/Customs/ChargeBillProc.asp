<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<!-- #include file="SokoExport.asp" -->
<%
'on error resume next
dim JobSeq
dim myMode
	
	JobType = ""				'�q�ɔ��p
	if instr(session("Depart"), "�A��") <> 0 then JobType = gsImport
	if instr(session("Depart"), "�A�o") <> 0 then JobType = gsExport
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	myLevel = CheckUserLevel(UserShop, JobBroker)
	myView = 0
	select case WebUserID
	case 33, 34, 46, 47, 51, 52
		myView = 1
	end select
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		ChargeCheck = 1
		JobSalesman = WebUserID
	else
		JobType = GetPost(request("JobType"))
		JobSalesman = GetLong(request("JobSalesman"))
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		PayDayFrom = GetPost(request("PayDayFrom"))
		PayDayTo = GetPost(request("PayDayTo"))
		JobCode = GetPost(request("JobCode"))
		ChargeNo = GetPost(request("ChargeNo"))
		AmntFrom = GetPost(request("AmntFrom"))
		AmntTo = GetPost(request("AmntTo"))
		if AmntFrom <> "" then AmntFrom = GetDouble(AmntFrom)
		if AmntTo <> "" then AmntTo = GetDouble(AmntTo)
		ChargeCheck = GetLong(request("ChargeCheck"))
		
		'�ꊇ�m�菈��
		if myMode = 2 then	
			msg = ""
			JobSeq = split(GetPost(request("JobSeq")), ",")
			
			for i = 0 to ubound(JobSeq)
				myJob = trim(GetLeft(JobSeq(i), "."))
				myNo = trim(GetRight(JobSeq(i), "."))
				
				if CheckBillMatched(Conn, myJob, myNo) = false then
					msg = "�Y���������̍��v���z�͖��׋��z�ƈ�v�ł͂���܂���I(�����ԍ��F" & myNo & "�䒠�ԍ��F" & myJob & ")"
					exit for
				end if
			next
		
			if msg = "" then
				Conn.BeginTrans
				
				for i = 0 to ubound(JobSeq)
					myJob = trim(GetLeft(JobSeq(i), "."))
					myNo = trim(GetRight(JobSeq(i), "."))
					
					'�e���ڊm��
					strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = GETDATE()"
					strSql = strSql & ", ConfirmerID = " & WebUserID
					strSql = strSql & " WHERE JobCode = '" & myJob & "'"
					strSql = strSql & " AND ExpenseBill = '" & myNo & "'"
					Conn.execute strSql
					
					'�������m��
					strSql = "UPDATE TBL_CTM_CHARGE SET ChargeCheck = 1, ConfirmDate = GETDATE()"
					strSql = strSql & ", ConfirmerID = " & WebUserID
					if CheckJobType(myJob) = gsExport then strSql = strSql & ", ChargePrinted = 1"	'�A�o�̂�DOT���
					strSql = strSql & " WHERE JobCode = '" & myJob & "'"
					strSql = strSql & " AND ChargeNo = '" & myNo & "'"
					Conn.execute strSql
					
					call Sales2Biz(1, Conn, myNo, myJob)		'�d��쐬
					
					if err.number <> 0 then exit for
				next
				
				if err.number = 0 then
					Conn.CommitTrans
					msg = "�m�菈���͖����������܂����B"
				else
					Conn.RollbackTrans
					msg = "�m�菈�������L�̃G���[���N����܂����B(" & err.number & ":" & err.description & ")"
				end if
			end if
		end if
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�������m�菈��</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function DoCheck()
			Call CheckAll("JobSeq", frmInput.CheckAll.Checked)
		end function 
	
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "JobSeq" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�m�肷�鐿������I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("�f�[�^���m�肵�Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myJob, myNo)
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & myJob & "&ChargeNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
		end function
				
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
				
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub PayDayFrom_OnBlur()
			frmInput.PayDayFrom.value = setdate(frmInput.PayDayFrom.value)
		end sub
		sub PayDayTo_OnBlur()
			frmInput.PayDayTo.value = setdate(frmInput.PayDayTo.value)
		end sub
		sub AmntFrom_OnBlur()
			if frmInput.AmntFrom.value = "" then exit sub
			frmInput.AmntFrom.value = GetDouble(frmInput.AmntFrom.value)
		end sub
		sub AmntTo_OnBlur()
			if frmInput.AmntTo.value = "" then exit sub
			frmInput.AmntTo.value = GetDouble(frmInput.AmntTo.value)
		end sub
		sub ChargeNo_OnBlur()
			frmInput.ChargeNo.value = UCASE(frmInput.ChargeNo.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
<%if myMode = 2 then%>
	<%if gsMsgBatch = 1 then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
	<%end if%>
			window.parent.parent.result.location.href = "ChargeResult.asp?type=1"
<%else%>
			frmInput.ClientRef.focus()
<%end if%>
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="ChargeBillProc.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				������<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">					
				������<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�Ɩ�&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>	
				�c��&nbsp;<SELECT name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartSales, JobSalesman)%></select>
				�m���
			<TR><TD nowrap>
				�����ԍ�<input class=si name="ChargeNo" value="<%=ChargeNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				������<input class=si name="PayDayFrom" value="<%=PayDayFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="PayDayTo" value="<%=PayDayTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="ChargeCheck" value="1" <%if ChargeCheck then response.write " checked"%>>
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
	if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman
	if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 1)
	if DateFrom <> "" then strSel = strSel & " AND ChargeDate >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND ChargeDate <= '" & Date2Str(DateTo) & "'"	
	if PayDayFrom <> "" then strSel = strSel & " AND ChargePayDay >= '" & Date2Str(PayDayFrom) & "'"
	if PayDayTo <> "" then strSel = strSel & " AND ChargePayDay <= '" & Date2Str(PayDayTo) & "'"	
	if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'"
	if ChargeNo <> "" then strSel = strSel & " AND ChargeNo LIKE '%" & FitSel(ChargeNo) & "%'"	
	if AmntFrom <> "" then strSel = strSel & " AND (ChargeAmount + ChargeTax) >= " & AmntFrom
	if AmntTo <> "" then strSel = strSel & " AND (ChargeAmount + ChargeTax) <= " & AmntTo
	if ChargeCheck <> 0 then strSel = strSel & " AND ChargeCheck = 1"
		
	with recset
		strSql = "SELECT JobCode, ChargeNo, ChargeType, CTM_CD, ClientRef, ChargeClientName, ChargeAmount, ChargeTax"
		strSql = strSql & ", ChargeDate, ChargePayDay, JobSalesman, ChargeCheck FROM TBL_CTM_CHARGE AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobSalesman FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID = 0" & strSel		'���폜�@�������@���m��
		if CheckTopLevel() = 0 and myView = 0 then strSql = strSql & " AND SUBSTRING(JobCode,1,1) = '" & UserShop & "'"
		select case mySort
		case 2:		strSql = strSql & " ORDER BY ChargeNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, ChargeNo"
		case 0:		strSql = strSql & " ORDER BY ChargeDate, ChargeNo"
		case 3:		strSql = strSql & " ORDER BY ChargePayDay, ChargeNo"
		case 4:		strSql = strSql & " ORDER BY ClientRef, ChargeDate, ChargeNo"
		case 5:		strSql = strSql & " ORDER BY ChargeAmount+ChargeTax, ChargeNo"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			myConfirm = 1
			lngCount = 0
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup span=3 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=3 align=center>
		  <TR height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>�敪
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">������
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">������
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�������z
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">������
			<TD class=line nowrap colspan=2><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S�I��
<%
			cnt = 0
			ttlTax = 0
			ttlAmount = 0
			Do while not .EOF
				lngCount = lngCount + 1
				JobCode = GetString(.Fields("JobCode"))	
				ChargeNo = GetString(.Fields("ChargeNo"))		
%>
		<TR height=20>
			<TD class=line><%=lngCount%><BR>
			<TD class=line><%=ShowBillType(.Fields("ChargeType"))%><BR>
			<TD class=line><%=ShowVoucherNo(ChargeNo)%><BR>
			<TD class=line><%=ShowJobCode(JobCode)%><BR>
			<TD class=line nowrap title="<%=GetString(.Fields("ChargeClientName"))%>"><%=StringCut(GetString(.Fields("ClientRef")),7)%><BR>
			<TD class=line nowrap style="color:green"><%=Str2MD(.Fields("ChargeDate"))%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax")), 0, true)%><BR>
			<TD class=line style="color:blue"><%=Str2MD(.Fields("ChargePayDay"))%><BR>
			<TD class=line style="color:gray"><%if .Fields("ChargeCheck") then%>
				<input type=checkbox name="JobSeq" value="<%=JobCode%>.<%=ChargeNo%>"><%else%>��<%end if%>
			<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=JobCode%>', '<%=ChargeNo%>')">
<%
				if .Fields("ChargeType") <> gsStand then
					if CheckJobType(JobCode) = gsExport then myConfirm = 0
				end if
				if .Fields("ChargeCheck") then cnt = cnt + 1
				ttlTax = ttlTax + GetLong(.Fields("ChargeTax"))
				ttlAmount = ttlAmount + GetLong(.Fields("ChargeAmount"))
				.movenext
			loop
			if lngCount > 1 then
%>			
		<TR height=20>
			<TD colspan=4>
			<TD class=line align=right>�� �v
			<TD class=line align=right colspan=2><%=formatnumber(ttlAmount + ttlTax, 0, true)%>
		
<%
			end if
%>
		</TABLE>
<%if myLevel > 1 and myConfirm then%>
		<div align=right>
			<%if cnt > 0 then%><INPUT style="width:60px;height:25px;" TYPE=button VALUE="�m��" onclick="DoConfirm()"><%end if%>
		</div>
<%end if
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>