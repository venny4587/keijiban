<HTML>
<HEAD>
<TITLE>�ʊփc�[�������e�i���X</TITLE>
</HEAD>
	<FRAMESET rows="50,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="toolmenu.asp" NAME="toolmenu" MARGINWIDTH="0" MARGINHEIGHT="0" noresize scrolling=no>
		<FRAME SRC="" NAME="tool" MARGINWIDTH="10" MARGINHEIGHT="0" noresize>
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>