<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim mode
dim JobCode
dim JobBelong
dim JobBroker
dim JobClient
dim JobShipper
dim JobFinisher
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
				
	mode = GetLong(request("mode"))
	JobCode = GetPost(request("JobCode"))
	if JobCode <> "" then 
		if len(JobCode) < 10 then JobCode = ucase(left(JobCode,5)) & right("0000" & mid(JobCode,6),5)
		JobCode = ucase(JobCode)
		JobHeader = ShowCstmJobHead(JobCode, 1)
		if trim(JobHeader) <> "" then 
			session("JobCode_CostsInput") = left(JobCode, 5)
			if CheckJobLocked(JobCode) then
				ShowMessage "�Y������Ɩ��͊��Ƀ��b�N����܂����B"
			elseif JobBroker <> gsCorpCode then			'�{�Јϑ�
				ShowMessage "�Y������Ɩ��͖{�Вʊ֑Ώۂł͂���܂���B"
			else
				mode = 2
				CustomNo = "":	CostsNo = "":	PermitDate = ""
				Kanzei = 0:		Tax = 0:	AreaTax = 0
				with Recset
					strSql = "SELECT CustomDate, CustomTime, CustomType, PermitNo, PermitDate, CustomSheet"
					strSql = strSql & " FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
					.Open strSql,conn,adOpenStatic,adLockReadOnly 
					if not .eof then
						CustomDate = Str2Date(.fields("CustomDate"))
						CustomTime = GetString(.fields("CustomTime"))
						CustomType = GetLong(.fields("CustomType"))
						CustomNo = GetString(.fields("PermitNo"))
						PermitDate = GetString(.fields("PermitDate"))
						CustomSheet = GetString(.fields("CustomSheet"))
					end if
					.Close
					
					strSql = "SELECT ExpenseCost, ExpenseAmount, ExpenseBill, ExpensePay "
					strSql = strSql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND ExpenseType = 2"
					strSql = strSql & " AND ExpenseCost IN (72,73,74) AND JobCode = '" & JobCode & "'"
					.Open strSql,conn,adOpenStatic,adLockReadOnly 
					if not .eof then
						CostsNo = GetString(.fields("ExpensePay"))
						do while not .eof
							select case GetLong(.fields("ExpenseCost"))
							case 72:	Kanzei = GetLong(.fields("ExpenseAmount"))
							case 73:	Tax = GetLong(.fields("ExpenseAmount"))
							case 74:	AreaTax = GetLong(.fields("ExpenseAmount"))
							end select
							.movenext
						loop
					end if
					.Close
				end with
				
				if CustomDate = "" then
					CustomDate = formatDate(date())
					CustomTime = right(ShowDateTimeShort(now), 5)
				end if
				Total = Kanzei + Tax + AreaTax
			end if
		end if
	else
		JobCode = GetString(session("JobCode_CostsInput"))
	end if
%>
<html>
<HEAD>
	<TITLE>�{�Вʊ֓o�^</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub CustomDate_Onblur()
			frmInput.CustomDate.value = setdate(frmInput.CustomDate.value)
		end sub	
				
		sub Kanzei_Onblur()
			frmInput.Kanzei.value = GetLong(frmInput.Kanzei.value)
			Call Calculate()
		end sub		
		sub Tax_Onblur()
			frmInput.Tax.value = GetLong(frmInput.Tax.value)
			Call Calculate()
		end sub		
		sub AreaTax_Onblur()
			frmInput.AreaTax.value = GetLong(frmInput.AreaTax.value)
			Call Calculate()
		end sub	
		sub Sheet1_Onblur()
			frmInput.Sheet1.value = GetLong(frmInput.Sheet1.value)
		end sub		
		sub Sheet2_Onblur()
			frmInput.Sheet2.value = GetLong(frmInput.Sheet2.value)
		end sub		
		sub Calculate()
		dim kan, tax, area
			kan = GetLong(frmInput.Kanzei.value)
			tax = GetLong(frmInput.Tax.value)
			area = GetLong(frmInput.AreaTax.value)
			frmInput.Total.value = formatnumber(kan+tax+area, 0, true)
		end sub		
		
		sub DoSave(mode)
			if checkDate("CustomDate","�\����", 1) = false then exit sub
			if checkText("CustomTime","�\������",0) = false then exit sub
			if checkText("CustomNo","�\���ԍ�",1) = false then exit sub
			if checkNum("Kanzei","�֐�",1) = false then exit sub
			if checkNum("Tax","�����",1) = false then exit sub
			if checkNum("AreaTax","�n�������",1) = false then exit sub
			if checkNum("Sheet1","�\������",1) = false then exit sub
			if checkNum("Sheet2","�\������",1) = false then exit sub
			if mode = 1 then
				if msgbox ("�o�^���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			elseif mode = 2 then
				if msgbox ("�����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub InitForm()
<%if mode = 0 then%>
			SetEndFocus(frmInput.JobCode)
<%else%>
			frmInput.CustomDate.focus()
<%end if%>
		end sub
	</SCRIPT>
</Head>
<body leftmargin=0 topmargin=3 class=pt9 onload="InitForm()" <%=gsBodyControl%>>
<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
<tr><td width=60% valign=top>
<%if mode < 2 then%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td width=50%>���ʊ֓o�^&nbsp;
		<td width=50% align=right>
	</table>
	<hr width=96% size=1>
  <FORM NAME="frmInput" action="CustomsInput.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td>&nbsp;�䒠�ԍ�&nbsp;
	  	<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10>
		<%if mode = 1 then%><font color=red>�Y���䒠�ԍ��͌�����܂���ł����B</font><%end if%>
	</table>
  </FORM>
<%else%>
  <p><br>
  <FORM NAME="frmInput" action="CustomsUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="CostsNo" value="<%=CostsNo%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
	  <TR height=28>
	  	<TD nowrap class=pt9g>�䒠�ԍ�&nbsp;<input class=sn name="JobCode" size=10 maxlength=10 value="<%=JobCode%>" readonly onkeydown="ResetEnter()">
	  	�@�@B/L��׎�&nbsp;<input class=si name="Client" size=45 maxlength=100 value="<%=GetCtmName(JobShipper)%>" readonly onkeydown="ResetEnter()">
	</table>
	<p><br><%=JobHeader%><p><br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=28>
		<TD nowrap>�@�\�����t&nbsp;<input class=si name="CustomDate" size=9 maxlength=10 value="<%=CustomDate%>" onkeydown="ResetEnter()" 
						<%if JobFinisher = 0 then%> onclick="setday(this)"<%end if%>>			
			<font class=pt9>����</font>&nbsp;<input class=sz name="CustomTime" size=5 maxlength=5 value="<%=CustomTime%>" onkeydown="ResetEnter()">
		�@�@�\���ԍ�&nbsp;<input class=si name="CustomNo" size=12 maxlength=16 value="<%=CustomNo%>" onkeydown="ResetEnter()">
		�@�@�\���敪&nbsp;<select name="CustomType" onkeydown="ResetEnter()"><option value="0">�s��
				<%for i = 1 to 5%><option value="<%=i%>" <%if CustomType = i then response.write "selected"%>><%=i%><%next%></select>
	  <TR height=28>
		<TD nowrap>�@�֐�&nbsp;<input class=sn name="Kanzei" size=8 maxlength=10 value="<%=Kanzei%>" onkeydown="ResetEnter()">
		�@�@�����&nbsp;<input class=sn name="Tax" size=8 maxlength=10 value="<%=Tax%>" onkeydown="ResetEnter()">
		�@�@�n�������&nbsp;<input class=sn name="AreaTax" size=8 maxlength=10 value="<%=AreaTax%>" onkeydown="ResetEnter()">
		�@�@<font class=pt9g>���v</font>&nbsp;<input class=sn name="Total" size=8 maxlength=10 value="<%=Total%>" readonly onkeydown="ResetEnter()">
	  <TR height=28>
		<TD nowrap>�@�����\��&nbsp;<input class=sn name="Sheet1" size=4 maxlength=2 value="<%=GetLong(left(CustomSheet, 2))%>" onkeydown="ResetEnter()">
			��&nbsp;<input class=sn name="Sheet2" size=4 maxlength=2 value="<%=GetLong(right(CustomSheet, 2))%>" onkeydown="ResetEnter()">
			��&nbsp;<font class=pt9>�i���z�̏ꍇ�́u�����v�Ƀ[������͂��Ă��������B�j</font>
	  <TR height=28>
	  	<td><br>
	  <TR height=28>
	  	<td align=center>
<%if PermitDate = "" then %>
	  		<input type=button style="width:90;height:30" name=btnSave value="�o�^" onclick="DoSave(1)">�@
	  	�@�@<input type=button style="width:90;height:30" name=btnOK value="����" onclick="DoSave(2)">
<%else%>
	<font class=pt12g>�����F<%=Str2Date(PermitDate)%></font>
<%end if%>
	</table>
  </FORM>
<%end if%>
<td width=40% valign=top align=center>
	<table width=90% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td>���������ꗗ&nbsp;�@�@<b><%=formatDateTime(now)%> ����</b>
	</table>
	<hr width=96% size=1>
<%
	with Recset
		strSql = "SELECT JobCode, CustomDate, CustomTime, CustomType, PermitNo FROM TBL_CTM_JOB"
		strSql = strSql & " WHERE CustomBroker = '" & gsCorpCode & "' AND PermitDate = '" & Date2Str(date()) & "' ORDER BY JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if .eof then
			response.write "�@�@<font class=pt9r>�Y������f�[�^�͌�����܂���ł����B</font>"
		else
			cnt = 0
%>
	<table width=90% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		<colgroup span=4 align=left>
		<colgroup align=center>
		<tr height=20 class=pt9><td class=line>��<td class=line>�䒠�ԍ�<td class=line>�\����<td class=line>�\������<td class=line>��
<%
			do while not .eof
				cnt = cnt + 1
				response.write "<tr height=20><td class=line>" & cnt & "<td class=line>" & GetString(.fields("JobCode")) & "<td class=line>" & GetString(.fields("PermitNo")) & "<br>"
				response.write "<td class=line>" & Str2MD(.fields("CustomDate")) & " " & GetString(.fields("CustomTime")) & "<br><td class=line>" & GetLong(.fields("CustomType"))
				.movenext
			loop
%>
	</table>
<%
		end if
		.Close
	end with
	set Recset = nothing
	CloseDB Conn
%>
</table>
</body></html>