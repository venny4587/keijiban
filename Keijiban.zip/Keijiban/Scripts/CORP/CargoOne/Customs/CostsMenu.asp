<html>
<head>
	<title>�x���������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)			
		btnCosts.style.color = "black"
		btnClose.style.color = "black"
		btnProc.style.color = "black"
		btnBatch.style.color = "black"
		btnView.style.color = "black"
		select case mySel 
		case 1
			url = "CostsInput.asp"
			rst = "CostsResult.asp?type=0"
			btnCosts.style.color = "red"
		case 2
			url = "CostsBatch.asp"
			rst = "CostsBatchDetail.asp"
			btnClose.style.color = "red"
		case 3
			url = "CostsBillProc.asp"
			rst = "CostsBatchList.asp"
			btnProc.style.color = "red"
		case 4
			url = "CostsBillBatch.asp"	
			rst = "../common/blank.htm"
			btnBatch.style.color = "red"
		case 5
			url = "CostsBillView.asp"	
			rst = "CostsResult.asp?type=2"
			btnView.style.color = "red"
		end select
		window.parent.cbody.location.href = url 
		window.parent.parent.result.location.href = rst
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0 class=pt9 <%=gsBodyControl%>>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnCosts value="��������" onclick="DoAct(1)"></TD>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnClose value="��������" onclick="DoAct(2)"></TD>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnProc value="�x���m��" onclick="DoAct(3)"></TD>
		    <TD width=110>
				<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnBatch value="�ޯ�����" onclick="DoAct(4)"></TD>
		    <TD width=110>
				<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnView value="�x���Ɖ�" onclick="DoAct(5)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
