<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
		
dim BatchNo

	BatchNo = GetPost(request("BatchNo"))

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 	
	with Recset
		strSql = "SELECT * FROM TBL_CTM_BATCH WHERE Deleted = 0 AND BatchNo = '" & BatchNo & "'"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			BatchClient = GetString(.Fields("BatchClient"))
			BatchPic = GetString(.Fields("BatchPic"))
			BatchCount = GetLong(.Fields("BatchCount"))
			BatchAmount = GetLong(.Fields("BatchAmount"))
			BatchBillDay = Str2Date(.Fields("BatchBillDay"))
			BatchPayDay = Str2Date(.Fields("BatchPayDay"))
			ConfirmerID = GetLong(.Fields("ConfirmerID"))
			FinisherID = GetLong(.Fields("FinisherID"))
		end if
		.close
		
		strSql = "SELECT CTM_NAME, CTM_REF, CTM_ZIP, CTM_ADDR1, CTM_ADDR2, CTM_FAX, CTM_SALESMNGR FROM CUSTOMER WHERE CTM_CD = '" & BatchClient & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then 
			ClientName = GetString(.fields("CTM_NAME"))
			CTM_REF = GetString(.fields("CTM_REF"))
			CTM_ZIP = GetString(.fields("CTM_ZIP"))
			CTM_ADDR1 = GetString(.fields("CTM_ADDR1"))
			CTM_ADDR2 = GetString(.fields("CTM_ADDR2"))
			CTM_FAX = GetString(.fields("CTM_FAX"))
			CTM_SALESMNGR = GetString(.fields("CTM_SALESMNGR"))
		end if
		.close
%>
<HTML>
<HEAD>
	<TITLE>�x�����׊m�F�ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r ����; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r ����; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: �l�r ����; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 16pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
  <table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
  <tr><td height=880 valign=top align=center>
	<table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <tr><td width=150>��<%=BatchNo%>
	 	<td width=320 class=pth align=center><u>&nbsp;&nbsp; �o �� �� �� �� ��&nbsp;&nbsp;</u>
	  	<td width=150 align=right><%=formatDateJP(BatchPayDay)%>
	</table>
	<br>
	<table width=640 cellspacing=0 cellpadding=0>
	  <tr>
		<td width=340 valign=top class=ptm>
			<table width=90% Cellspacing=0 CellPadding=0 class=ptm>
		  	  <tr height=20><td>�� <%=CTM_ZIP%><br><%=CTM_ADDR1%><br><%=CTM_ADDR2%><br><%=ClientName%> �䒆<br>
		  	  <tr height=20><td><hr size=1 color=black>
		  	  <tr height=20><td class=ptm>FAX: <%=CTM_FAX%>
 			</table>
		<td width=300 valign=top align=right>
		  <table Cellspacing=0 CellPadding=0 class=ptm>
			<tr align=right>
				<td width=130><img src=img/logo.jpg>
				<td nowrap><font class=pth><b><%=gsPrintHead%></b></font>
		  	<tr align=right>
		  		<td colspan=2 class=ptt nowrap align=right><%=gsPrintAddr%>
 		  </table>
	</table>
	<TABLE width=640 Cellspacing=3 CellPadding=3 class=pts>
		<colgroup span=4 align=left>
		<colgroup span=3 align=right>
  	  <TR><td colspan=7><hr color=black size=1>
	  <TR class=pt9>
		<TD class=gline width=40>��
		<TD class=gline width=80 nowrap>�䒠�ԍ�
		<TD class=gline width=120 nowrap>��p����
		<TD class=gline width=160 nowrap>���ڔ��l
		<TD class=gline width=80 nowrap>�Ŕ����z
		<TD class=gline width=60 nowrap>�����
		<TD class=gline width=90 nowrap>���v���z
<%
		cnt = 0
		ttlAmount = 0:	ttlTax = 0
		strSql = "SELECT COST_NAME, ExpenseMemo, ExpenseAmount, ExpenseTax, CostsBillNo, E.JobCode FROM TBL_CTM_EXPENSE AS E"
		strSql = strSql & " INNER JOIN (SELECT COST_ID, COST_NAME FROM MST_COST) AS C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " INNER JOIN TBL_CTM_COSTS AS B ON E.ExpensePay = B.CostsNo WHERE E.Deleted = 0 AND B.Deleted = 0"
		strSql = strSql & " AND CostsBatch = '" & BatchNo & "'"
		strSql = strSql & " ORDER BY ExpenseMemo"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .eof
			cnt = cnt + 1
%>
		<TR>
			<TD><%=cnt%>
			<TD nowrap><%=GetString(.Fields("JobCode"))%><BR>
			<TD nowrap><%=GetString(.Fields("COST_NAME"))%><BR>
			<TD nowrap><%=GetString(.Fields("ExpenseMemo"))%><BR>
			<TD nowrap align=right><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, false)%><BR>
			<TD nowrap align=right><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, false)%><BR>
			<TD nowrap align=right><%=formatnumber(GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax")), 0, false)%><BR>
<%
			ttlAmount = ttlAmount + GetLong(.Fields("ExpenseAmount"))
			ttlTax = ttlTax + GetLong(.Fields("ExpenseTax"))
			.movenext
		loop
		if cnt > 1 then
%>
  		<TR><td colspan=7><hr color=black size=1>
		<TR class=pt9>
			<TD colspan=4 align=right>�x�����v
			<TD class=line><%=formatnumber(ttlAmount, 0, true)%>
			<TD class=line><%=formatnumber(ttlTax, 0, true)%>
			<TD class=line><%=formatnumber(ttlAmount + ttlTax, 0, true)%>
<%
		end if
%>
  	  <TR><td colspan=8><hr color=black size=1>
	</TABLE>
<%
	end with
%>  	  	
  </table>
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>
