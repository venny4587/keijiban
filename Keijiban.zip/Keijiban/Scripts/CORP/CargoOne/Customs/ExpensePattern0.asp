<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim PATN_ID
	
	blnDelete = True
	CTM_CD = GetPost(Request("cd"))
	PATN_ID = GetLong(Request("PATN_ID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If false Then
		With Recset
			strsql = "SELECT PatternID FROM PTN_EXPENSE WHERE PatternID = " & PATN_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y���p�^�[���ɂ͔�p�f�[�^������܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_PATTERN SET PATN_DELETED = 1"
		strSQL = strSQL & ",PATN_UPDATED = GETDATE()"
		strSQL = strSQL & ",PATN_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE PATN_ID = " & PATN_ID
		Conn.Execute strSQL

		strURL = "ExpensePattern.asp?cd=" & CTM_CD & "&p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>