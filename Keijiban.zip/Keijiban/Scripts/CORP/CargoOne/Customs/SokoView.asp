<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Confirm = 0
		SalesDate = left(Date2Str(Date), 6)
	else
		JobType = GetPost(request("JobType"))
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		BLNO = GetPost(request("BLNO"))
		Port = GetPost(request("Port"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		QtyFrom = GetPost(request("QtyFrom"))
		QtyTo = GetPost(request("QtyTo"))
		AmountFrom = GetPost(request("AmountFrom"))
		AmountTo = GetPost(request("AmountTo"))
		Vessel = GetPost(request("Vessel"))
		Confirm = GetLong(request("Confirm"))
		JobOperator = GetLong(request("JobOperator"))
		JobSalesman = GetLong(request("JobSalesman"))
		BillNo = GetPost(request("BillNo"))
		SalesDate = GetPost(request("SalesDate"))
		
		if QtyFrom <> "" then QtyFrom = GetDouble(QtyFrom)
		if QtyTo <> "" then QtyTo = GetDouble(QtyTo)
		if AmountFrom <> "" then AmountFrom = GetLong(AmountFrom)
		if AmountTo <> "" then AmountTo = GetLong(AmountTo)
		
		'�ꊇ�m�菈��
		if myMode = 2 then	
			msg = ""
			JobSeq = split(GetPost(request("JobSeq")), ",")
			
			for i = 0 to ubound(JobSeq)
				myJob = trim(GetLeft(JobSeq(i), "."))
				myNo = trim(GetRight(JobSeq(i), "."))
				
				if CheckCostsMatched(Conn, myJob, myNo) = false then
					msg = "�Y���x���`�[���z�Ɩ��׍��v���z�͈�v�ł͂���܂���I(" & "�x���ԍ��F" & myNo & "�䒠�ԍ��F" & myJob & ")"
					exit for
				end if
			next
			
			if msg = "" then
				Conn.BeginTrans
				
				for i = 0 to ubound(JobSeq)
					myJob = trim(GetLeft(JobSeq(i), "."))
					myNo = trim(GetRight(JobSeq(i), "."))
					
					'��p���ڊm��
					strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = GETDATE()"
					strSql = strSql & ", ConfirmerID = " & WebUserID
					strSql = strSql & " WHERE JobCode = '" & myJob & "'"
					strSql = strSql & " AND ExpensePay = '" & myNo & "'"
					Conn.execute strSql
					
					'�x���`�[�m��
					strSql = "UPDATE TBL_CTM_COSTS SET ConfirmDate = GETDATE()"
					strSql = strSql & ", ConfirmerID = " & WebUserID
					strSql = strSql & " WHERE JobCode = '" & myJob & "'"
					strSql = strSql & " AND CostsNo = '" & myNo & "'"
					Conn.execute strSql
					
					call Payment2Biz(1, Conn, myNo, myJob)		'�d��쐬
					
					if err.number <> 0 then exit for
				next
				
				if err.number = 0 then
					Conn.CommitTrans
					msg = "�m�菈���͖����������܂����B"
				else
					Conn.RollbackTrans
					msg = "�m�菈�������L�̃G���[���N����܂����B(" & err.number & ":" & err.description & ")"
				end if
			end if
		end if
	end if

%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function DoSort(no)
			frmInput.page.value = 1
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function DoCheck()
			Call CheckAll("JobSeq", frmInput.CheckAll.Checked)
		end function 
		
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "JobSeq" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�m�肷��x���`�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd, no)
		dim win
			set win = window.open("../customs/SokoFrame.asp?JobCode=" & cd & "&CostsNo=" & no, "", "resizable=1,scrollbars=1,width=880,height=640")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub QtyFrom_OnBlur()
			if frmInput.QtyFrom.value = "" then exit sub
			frmInput.QtyFrom.value = GetDouble(frmInput.QtyFrom.value)
		end sub
		sub QtyTo_OnBlur()
			if frmInput.QtyTo.value = "" then exit sub
			frmInput.QtyTo.value = GetDouble(frmInput.QtyTo.value)
		end sub	
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub	
		sub AmountFrom_OnBlur()
			if frmInput.AmountFrom.value = "" then exit sub
			frmInput.AmountFrom.value = GetDouble(frmInput.AmountFrom.value)
		end sub
		sub AmountTo_OnBlur()
			if frmInput.AmountTo.value = "" then exit sub
			frmInput.AmountTo.value = GetDouble(frmInput.AmountTo.value)
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.JobCode)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="SokoView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='<%=lngPageNumber%>'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				���o�ɇ�<input class=sj name="BillNo" value="<%=BillNo%>" maxlength=30 size=16 onkeydown="ResetEnter()">
				�Ɩ��敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>
				�Ɩ��S��&nbsp;<SELECT name="JobOperator" onkeydown="ResetEnter()"><option value="">�S��<%=ShowEmployList(DepartCustoms, JobOperator)%></select>
				�������x&nbsp;<SELECT name="SalesDate" onkeydown="ResetEnter()"><%for i = -6 to 1%><%myDate=dateadd("m",i,date)%>
					<option value="<%=left(Date2Str(myDate), 6)%>" <%if SalesDate = left(Date2Str(myDate), 6) then response.write "selected"%>>
					<%=left(formatDate(myDate), 7)%><%next%></select>
			<TR><TD nowrap>
				���o�`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�֖�<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=16 onkeydown="ResetEnter()">
				�`<input class=si name="Port" value="<%=Port%>" maxlength=16 size=10 onkeydown="ResetEnter()">
				��<input class=sn name="QtyFrom" value="<%=QtyFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="QtyTo" value="<%=QtyTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				���z<input class=sn name="AmountFrom" value="<%=AmountFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="AmountTo" value="<%=AmountTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				�m�F��<input type=checkbox name="Confirm" value="1" onkeydown="ResetEnter()" <%if Confirm then response.write " checked"%>>
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'" 
		if ClientRef <> "" then	strSel = strSel & " AND ClientRef = '" & FitSel(ClientRef) & "'"	
		if BLNO <> "" then strSel = strSel & " AND BLNO LIKE '%" & FitSel(BLNO) & "%'"					
		if Port <> "" then strSel = strSel & " AND (POL LIKE '%" & FitSel(Port) & "%' OR POD LIKE '%" & FitSel(Port) & "%')"
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if Vessel <> "" then strSel = strSel & " AND VesselVoy LIKE '%" & FitSel(Vessel) & "%'"	
		if BillNo <> "" then strSel = strSel & " AND CostsBillNo LIKE '%" & FitSel(BillNo) & "%'"
		if QtyFrom <> "" then strSel = strSel & " AND Quantity >= " & QtyFrom
		if QtyTo <> "" then strSel = strSel & " AND Quantity <= " & QtyTo
		if AmountFrom <> "" then strSel = strSel & " AND Amount >= " & AmountFrom
		if AmountTo <> "" then strSel = strSel & " AND Amount <= " & AmountTo
		if JobOperator <> 0 then strSel = strSel & " AND JobOperator = " & JobOperator
		if Confirm = 0 then strSel = strSel & " AND ConfirmerID = 0"
		if SalesDate <> "" then 
			strSel = strSel & " AND (SalesDate Between '" & SalesDate & "00' AND '" & SalesDate & "99'"
			if SalesDate = left(Date2Str(date), 6) then strSel = strSel & " OR SalesDate = ''"
			strSel = strSel & ")"
		end if
		
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT JobCode, CTM_CD, CTM_NAME, ClientRef, JobOperator, ConfirmerID, MBL+' '+HBL AS BLNO, Vessel+' '+Voy AS VesselVoy,Quantity, Package, SalesDate"
		strSQL = strSQL & ", POL, POD, CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD, Amount, SokoDate, CostsNo, CostsBillNo, CostsCheck"
		strSQL = strSQL & " FROM TBL_CTM_JOB AS T INNER JOIN (SELECT JobCode AS CD, CostsAmount+CostsTax AS Amount, Created AS SokoDate, CostsNo, CostsBillNo"
		strSQL = strSQL & ", CostsCheck, ConfirmerID FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsClient = '" & gsCorpSoko & "') AS S ON T.Jobcode = S.CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME FROM CUSTOMER) AS C ON T.JobClient = C.CTM_CD WHERE Deleted = 0) AS TMP"
		if strSel <> "" then strSQL = strSQL & " WHERE " &  mid(strSel, 5)
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY SUBSTRING(JobCode,2,1), SokoDate"
		case 1:		strSQL = strSQL & " ORDER BY JobCode"
		case 2:		strSQL = strSQL & " ORDER BY ClientRef"
		case 3:		strSQL = strSQL & " ORDER BY VesselVoy"
		case 4:		strSQL = strSQL & " ORDER BY POL"
		case 5:		strSQL = strSQL & " ORDER BY POD"
		case 6:		strSQL = strSQL & " ORDER BY ETAETD"
		case 7:		strSQL = strSQL & " ORDER BY Quantity"
		case 8:		strSQL = strSQL & " ORDER BY CostsBillNo"
		case 9:		strSQL = strSQL & " ORDER BY Amount"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=2 align=center>
			<colgroup span=5 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=2 align=left>
			<colgroup align=right>
			<colgroup span=2 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=4% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�敪
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����׎�
			<TD width=15% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�֖�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�o���`
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�ړI�`
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">���o�`��
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">��
			<TD width=6% nowrap>�׎p
			<TD width=15% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">���o�ɇ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">�������z
			<TD width=5% nowrap>�Ɩ�
			<TD class=line nowrap colspan=2><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S
<%
				cnt = 0
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else						
						if GetLong(.Fields("ConfirmerID")) = 0 then
							mycolor = "#000000"
							if GetLong(.Fields("CostsCheck")) then cnt = cnt + 1
						else
							mycolor = "#606060"
						end if
						
						JobCode = GetString(.Fields("JobCode"))
						ClientRef = GetString(.Fields("ClientRef"))
						VesselVoy = GetString(.Fields("VesselVoy"))
						CostsNo = GetString(.Fields("CostsNo"))
						POL = GetString(.Fields("POL"))
						POD = GetString(.Fields("POD"))
						BillNo = GetString(.Fields("CostsBillNo"))
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
						 onclick="ShowDetail('<%=JobCode%>','<%=CostsNo%>');">
						<TD nowrap class=line><%=lngCount%>
						<TD nowrap class=line><%=GetJobDivision(mid(JobCode,2,1))%>
						<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%>
						<TD nowrap class=line title="<%=GetString(.Fields("CTM_NAME"))%>"><%=ClientRef%>
						<TD nowrap class=line <%=ShowTitle(VesselVoy, 16)%>><%=stringCut(VesselVoy, 16)%><BR>
						<TD nowrap class=line <%=ShowTitle(POL, 8)%>><%=stringCut(POL, 8)%><BR>
						<TD nowrap class=line <%=ShowTitle(POD, 8)%>><%=stringCut(POD, 8)%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("ETAETD"))%><BR>
						<TD nowrap class=line><%=GetDouble(.Fields("Quantity"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Package"))%><BR>
						<TD nowrap class=line <%=ShowTitle(BillNo, 16)%>><%=stringCut(BillNo, 16)%><BR>
						<TD nowrap class=line><%=formatnumber(.Fields("Amount"), 0, true)%><BR>
						<TD nowrap class=line><%=GetEmployName(.Fields("JobOperator"), "F")%><BR>
						<TD class=line style="color:gray"><%if GetLong(.Fields("ConfirmerID")) then%>��<%else%>
							<%if GetLong(.Fields("CostsCheck")) then%><input type=checkbox name="JobSeq" value="<%=JobCode%>.<%=CostsNo%>">
								<%else%>��<%end if%><%end if%>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
	</TABLE>
<%if CheckTopLevel() > 0 or UserShop = gsSokoInit then%>
		<div align=right>
			<%if cnt > 0 then%><INPUT style="width:60px;height:25px;" TYPE=button VALUE="�m��" onclick="DoConfirm()"><%end if%>
		</div>
<%end if
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>