<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�x���`�[���ה�p����
'----------------------------------------------

	mode = GetLong(request("mode"))
	CostsNo = GetPost(request("CostsNo"))
	JobCode = GetPost(request("JobCode"))
	CustomDate = Date2Str(request("CustomDate"))
	CustomTime = GetPost(request("CustomTime"))
	CustomType = GetLong(request("CustomType"))
	CustomNo = GetPost(request("CustomNo"))
	CustomSheet = right("00" & GetLong(request("Sheet1")), 2) & "/" & right("00" & GetLong(request("Sheet2")), 2)
	
	Kanzei = GetLong(request("Kanzei"))
	Tax = GetLong(request("tax"))
	AreaTax = GetLong(request("areatax"))
	total = Kanzei + Tax + AreaTax
	procDate = Date2Str(dateadd("d", 7, date))
	
	if JobCode <> "" then
		if CheckJobLocked(JobCode) then
			JobCode = ""
			ShowMessage "�Y������Ɩ��͊��Ƀ��b�N����܂����B"
		end if
	end if
	
	if JobCode <> "" then
	
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset")	
		
		myMsg = ""
		if CostsNo <> "" then
			'�ŋ��z�ύX�`�F�b�N
			if CheckCostsAmount(Conn, JobCode, CostsNo) <> total then
				if CheckCostsLocked(Conn, JobCode, CostsNo) then
					myMsg = "�Y���x���`�[�͊��Ɋm��ςł��B"
				elseif CheckChargeConfirm(Conn, JobCode, CostsNo) then
					myMsg = "�Y�����֕��̐����͊��Ɋm�肳��܂����I"
				end if
			end if
		end if
		
		if myMsg <> "" then
%>
<html>
	<script language=javascript>
		alert("<%=myMsg%>");
		window.location.href = "CustomsInput.asp";
	</script>
</html>
<%
		else
			Conn.BeginTrans
			
			if CostsNo = "" and total <> 0 then
				SeqNo = GetNewAcntNo(Conn, 2)	
				CostsNo = GetAccountNo(SeqNo, 2)
				
				with Recset
					strSql = "SELECT * FROM TBL_CTM_COSTS"
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
					.AddNew
					.fields("JobCode") = GetPost(request("JobCode"))
					.fields("CostsNo") = CostsNo
					.fields("CostsType") = 0		'����
					.fields("CostsBelong") = left(JobCode, 1)
					.fields("CostsClient") = gsCustoms
					.fields("CostsClientName") = "�_�ːŊ�"
					.fields("CostsPic") = ""
					.fields("CostsBillNo") = "TAX"
					.fields("CostsDate") = procDate
					.fields("CostsPayDay") = procDate
					.fields("CostsAmount") = total
					.fields("CostsTax") = 0
					.fields("CostsCheck") = 1
					.fields("CostsBatch") = ""
					.fields("CostsMemo") = ""
					.fields("Remarks") = "�ʊ֓o�^"
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Updater") = WebUserID
					.fields("Updated") = now()
					.fields("Deleted") = 0
					.update
					.close
				end with
			elseif CostsNo <> "" then
				'�ʊ֏��X�V
				strSql = "UPDATE TBL_CTM_COSTS SET CostsAmount = " & total & " WHERE CostsNo = '" & CostsNo & "'"
				Conn.Execute strSql
			end if
			
			if total <> 0 then
			
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Expense"
				
				with Recset
					if Kanzei = 0 then			'�֐�
						strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 1 "
						strSql = strSql & " WHERE ExpenseCost = 72 AND JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ExpenseClient = '" & gsCustoms & "' AND ExpensePay = '" & CostsNo & "'"
						Conn.Execute strSql
					else
						strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE ExpenseCost = 72 AND JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ExpenseClient = '" & gsCustoms & "' AND ExpensePay = '" & CostsNo & "'"
						.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
						if not .eof then
							.fields("ExpensePrice") = Kanzei
							.fields("ExpenseAmount") = Kanzei
							.Update
						else
							cmdSQL.Execute
							SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
							
							strSql = "INSERT TBL_CTM_EXPENSE (JobCode, SeqNo, ExpensePay, ExpenseClient, ExpenseCost, ExpenseType, ExpenseAttr, ExpenseDate"
							strSql = strSql & ",ExpensePrice,ExpenseQuantity,ExpenseUnit,ExpenseAmount,ExpenseTaxName,ExpenseTax,Creater,Updater) VALUES ("
							strSql = strSql & "'" & JobCode & "'," & SeqNo & ",'" & CostsNo & "','" & gsCustoms & "', 72, 2, 0,'" & procDate & "'"
							strSql = strSql & "," & Kanzei & ", 1, '��'," & Kanzei & ", '��ې�', 0," & WebUserID & "," & WebUserID & ")"
							Conn.Execute strSql
						end if 
						.Close
					end if
					
					if Tax = 0 then			'�����
						strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 1 "
						strSql = strSql & " WHERE ExpenseCost = 73 AND JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ExpenseClient = '" & gsCustoms & "' AND ExpensePay = '" & CostsNo & "'"
						Conn.Execute strSql
					else
						strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE ExpenseCost = 73 AND JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ExpenseClient = '" & gsCustoms & "' AND ExpensePay = '" & CostsNo & "'"
						.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
						if not .eof then
							.fields("ExpensePrice") = Tax
							.fields("ExpenseAmount") = Tax
							.Update
						else
							cmdSQL.Execute
							SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
							
							strSql = "INSERT TBL_CTM_EXPENSE (JobCode, SeqNo, ExpensePay, ExpenseClient, ExpenseCost, ExpenseType, ExpenseAttr, ExpenseDate"
							strSql = strSql & ",ExpensePrice,ExpenseQuantity,ExpenseUnit,ExpenseAmount,ExpenseTaxName,ExpenseTax,Creater,Updater) VALUES ("
							strSql = strSql & "'" & JobCode & "'," & SeqNo & ",'" & CostsNo & "','" & gsCustoms & "', 73, 2, 0,'" & procDate & "'"
							strSql = strSql & "," & Tax & ", 1, '��'," & Tax & ", '��ې�', 0," & WebUserID & "," & WebUserID & ")"
							Conn.Execute strSql
						end if
						.Close
					end if
					
					if AreaTax = 0 then		'�n�������
						strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 1 "
						strSql = strSql & " WHERE ExpenseCost = 74 AND JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ExpenseClient = '" & gsCustoms & "' AND ExpensePay = '" & CostsNo & "'"
						Conn.Execute strSql
					else
						strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE ExpenseCost = 74 AND JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ExpenseClient = '" & gsCustoms & "' AND ExpensePay = '" & CostsNo & "'"
						.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
						if not .eof then
							.fields("ExpensePrice") = AreaTax
							.fields("ExpenseAmount") = AreaTax
							.Update
						else
							cmdSQL.Execute
							SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
							
							strSql = "INSERT TBL_CTM_EXPENSE (JobCode, SeqNo, ExpensePay, ExpenseClient, ExpenseCost, ExpenseType, ExpenseAttr, ExpenseDate"
							strSql = strSql & ",ExpensePrice,ExpenseQuantity,ExpenseUnit,ExpenseAmount,ExpenseTaxName,ExpenseTax,Creater,Updater) VALUES ("
							strSql = strSql & "'" & JobCode & "'," & SeqNo & ",'" & CostsNo & "','" & gsCustoms & "', 74, 2, 0,'" & procDate & "'"
							strSql = strSql & "," & AreaTax & ", 1, '��'," & AreaTax & ", '��ې�', 0," & WebUserID & "," & WebUserID & ")"
							Conn.Execute strSql
						end if
						.Close
					end if
				end with
			end if
			
			'�ʊ֏��X�V
			strSql = "UPDATE TBL_CTM_JOB SET CustomType = " & CustomType
			strSql = strSql & ",CustomDate = '" & CustomDate & "'"
			strSql = strSql & ",CustomTime = '" & CustomTime & "'"
			strSql = strSql & ",CustomSheet = '" & CustomSheet & "'"
			strSql = strSql & ",PermitNo = '" & CustomNo & "'"
			if mode = 2 then strSql = strSql & ",PermitDate = '" & Date2Str(Date) & "'"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			Conn.Execute strSql
			
			if err.number = 0 then 
			
				Conn.CommitTrans
%>
<html>
	<script language=javascript>
		alert("�Y������ʊ֏��͓o�^����܂����I");
		window.location.href = "CustomsInput.asp";
	</script>
</html>
<%
			else
			
				Conn.RollbackTrans
				ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
				
			end if
		end if
	end if
	
	set Recset = nothing
	CloseDB Conn
%>