<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<!-- #include file="SokoExport.asp" -->
<%
'on error resume next

dim JobCode
dim ChargeNo
dim ChargeType
dim ChargeClient
dim ChargeDate
dim ChargePattern
dim ChargeAmount
dim ChargeTax
dim CustomerType

	mode = GetLong(request("mode"))
	JobCode = GetPost(request("JobCode"))
	JobType = GetPost(request("JobType"))
	ChargeNo = GetPost(request("ChargeNo"))
	BatchNo = GetString(request("ChargeBatch"))

	msg = ""
	if mode <> -1 and mode <> 3 then
		ChargeType = GetLong(Request("ChargeType"))
		ChargeDate = Date2Str(Request("ChargeDate"))
		ChargePattern = GetLong(Request("ChargePattern"))
			
		ChargeClient = GetPost(Request("ChargeClient"))
		ChargeClientName = GetPost(request("ChargeName"))
		if ChargeClient <> gsDummy then
			if GetFullName(ChargeClient) <> ChargeClientName then
				msg = "�Y���x����͑��݂��܂���B"
			else
				CustomerType = GetCtmType(ChargeClient)
			end if
		end if
		
		'�ʋƖ��Ŏx���f�[�^����͂����ꍇ�o�b�`�ԍ��̓��̓`�F�b�N
		if msg = "" and BatchNo <> "" then
			if CheckBatchNoExist(BatchNo, ChargeClient) = false then
				msg = "�Y���x������ԍ��͕s���ł��B"
			end if
		end if
	end if
	
if msg = "" then
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")	
	
	Conn.BeginTrans

	select case mode
	case 0, 1, 2					'�o�^
	
		if mode = 0 then						'�V�K�ԍ����s
		
			if ChargeType = gsStand then
				SeqNo = GetNewAcntNo(Conn, 0)
				ChargeNo = GetAccountNo(SeqNo, 0)		'���֐���
			else
				SeqNo = GetNewAcntNo(Conn, 1)
				ChargeNo = GetAccountNo(SeqNo, 1)		'��Đ���
			end if
			
		elseif CheckBillLocked(Conn, JobCode, CostsNo) then
		
			msg = "�Y���������͊��Ɋm�肳��܂����I"
				
		end if
		
		if msg = "" then 
			strSql = "UPDATE TBL_CTM_JOB SET JobType = '" & JobType & "' WHERE JobCode = '" & JobCode & "'"
			Conn.execute strSql
				
			with Recset
				strSql = "SELECT * FROM TBL_CTM_CHARGE WHERE JobCode = '" & JobCode & "' AND ChargeType = " & ChargeType & " AND ChargeNo = '" & ChargeNo & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = JobCode
					.fields("ChargeNo") = ChargeNo
					.fields("ChargeAmount") = 0
					.fields("ChargeTax") = 0
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
						
				.fields("ChargeType") = ChargeType
				.fields("ChargeBelong") = GetPost(request("JobBelong"))
				.fields("ChargeClient") = ChargeClient
				.fields("ChargeClientName") = ChargeClientName
				.fields("ChargePic") = GetPost(Request("ChargePic"))
				.fields("ChargeDate") = ChargeDate
				.fields("ChargeCloseDay") = Date2Str(Request("ChargeCloseDay"))
				.fields("ChargePayDay") = Date2Str(Request("ChargePayDay"))
				.fields("ChargeBatch") = BatchNo
				
				.fields("ChargeMemo") = GetPost(Request("ChargeMemo"))
				.fields("ChargeCheck") = GetLong(Request("ChargeCheck"))
				.fields("Remarks") = GetPost(Request("Remarks"))
				
				.fields("Updater") = WebUserID
				.fields("Updated") = now()
				.update
				.close
			end with

			if mode = 0	then 
				'���֕��捞��
				call GetStandList()
				
				if false and ChargeType <> gsStand then		'�p�^�[���I����ʂɕύX
					'������ڐݒ�
					if ChargePattern <> 0 then
						Call GetChargePattern()
					else
						Call GetCostsPattern()
					end if
				end if
				
				strSql = "UPDATE TBL_CTM_CHARGE SET ChargeAmount = " &  GetLong(ChargeAmount) & ", ChargeTax = " &  GetLong(ChargeTax)
				strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
				Conn.Execute strSql

				if mid(gsMsgConfirm,1,1) <> "0" then msg = "�Y���������͐V�K���s����܂����I"
				
			else
				'������E�������X�V
				strSql = "UPDATE TBL_CTM_EXPENSE SET ExpenseDate = '" & ChargeDate & "'"
				strSql = strSql & ", ExpenseClient = '" &  GetPost(Request("ChargeClient")) & "'"
				strSql = strSql & " WHERE ExpenseType = " & gsCharge & " AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
				Conn.Execute strSql
						
				if mode = 2 then			'�������m��
				
					if CheckBillMatched(Conn, JobCode, ChargeNo) = false then
					
						if mid(gsMsgConfirm,2,1) <> "0" then msg = "�Y���������̋��z�Ɩ��׍��v���z�͈�v�ł͂���܂���I"
						
					else
				
						'�e���ڊm��
						strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = GETDATE()"
						strSql = strSql & ", ConfirmerID = " & WebUserID
						strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ExpenseBill = '" & ChargeNo & "'"
						Conn.execute strSql
						
						'�������m��
						strSql = "UPDATE TBL_CTM_CHARGE SET ChargeCheck = 1, ConfirmDate = GETDATE()"
						if CheckJobType(JobCode) = gsExport and left(ChargeClient, 3) = "690" then 
							strSql = strSql & ", ChargePrinted = 1"				'�L�ʁE�A�o�̏ꍇDOT���
						end if
						strSql = strSql & ", ConfirmerID = " & WebUserID
						strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
						strSql = strSql & " AND ChargeNo = '" & ChargeNo & "'"
						Conn.execute strSql
						
						'�������L��
						if ChargeType <> gsStand then
							strSql = "UPDATE TBL_CTM_JOB SET SalesDate = '" & ChargeDate & "' WHERE JobCode = '" & JobCode & "'"
							Conn.execute strSql
						end if
						if ChargeType <> gsCharge then
							strSql = "UPDATE TBL_CTM_JOB SET StandDate = '" & ChargeDate & "' WHERE JobCode = '" & JobCode & "'"
							Conn.execute strSql
						end if						
						
						call Sales2Biz(1, Conn, ChargeNo, JobCode)		'�d��쐬
						
						if mid(gsMsgConfirm,3,1) <> "0" then msg = "�Y���������͊m�肳��܂����I"
						
					end if
						
				end if
				
			end if
			
		end if
				
	case 3		'�m�����
		
		if CheckBillFinished(Conn, JobCode, SeqNo) then
		
			msg = "�Y���������͊��ɏ�������܂����I"
			
		else
		
			call Sales2Biz(-1, Conn, ChargeNo, JobCode)		'�d��폜			�t�Ɍ���
			
			'�e���ڊm�����
			strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = NULL"
			strSql = strSql & ", ConfirmerID = 0"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			strSql = strSql & " AND ExpenseBill = '" & ChargeNo & "'"
			strSql = strSql & " AND ExpensePay NOT IN "					'�x���m��ςݗ��֍��ڂ͑ΏۊO
			strSql = strSql & " (SELECT DISTINCT CostsNo FROM TBL_CTM_COSTS WHERE Deleted = 0 AND ConfirmerID <> 0 AND JobCode = '" & JobCode & "')"
			Conn.execute strSql
			
			'�������m�����
			strSql = "UPDATE TBL_CTM_CHARGE SET ConfirmDate = NULL"
			strSql = strSql & ", ConfirmerID = 0"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			strSql = strSql & " AND ChargeNo = '" & ChargeNo & "'"
			Conn.execute strSql
			
			if mid(gsMsgConfirm,4,1) <> "0" then msg = "�Y���������̊m��͉�������܂����I"
			
		end if
		
	case -1			'�폜
		
		if CheckBillLocked(Conn, JobCode, SeqNo) then
		
			msg = "�Y���������͊��Ɋm�肳��܂����I"
			
		else
			call Sales2Biz(-1, Conn, ChargeNo, JobCode)			'�d��폜
			
			'���։��� (�ؑ�)
			strSql = "UPDATE TBL_CTM_EXPENSE SET ExpenseBill = ''"
			strSql = strSql & " WHERE ExpenseType = " & gsStand & " AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
			Conn.execute strSql
			
			'�����폜 (�_��)
			strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 1, Updated = GETDATE(), Updater = " & WebUserID
			strSql = strSql & " WHERE ExpenseType = " & gsCharge & " AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
			Conn.execute strSql
			
			'�������폜
			strSql = "UPDATE TBL_CTM_CHARGE SET Deleted = 1"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			strSql = strSql & " AND ChargeNo = '" & ChargeNo & "'"
			Conn.execute strSql
			
			if mid(gsMsgConfirm,5,1) <> "0" then msg = "�Y���������͍폜����܂����I"
			
		end if
		
	end select
		
	'�Ɩ��f�[�^�ɐ������̍X�V
	SalesDate = "":		SalesSum = 0:	SalesTax = 0
	StandDate = "":		StandSum = 0:	StandTax = 0
	with Recset
		strSql = "SELECT ChargeType, ChargeDate, ChargeAmount, ChargeTax FROM TBL_CTM_CHARGE"
		strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
		strSql = strSql & " ORDER BY ChargeDate"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		do while not .eof
			if GetLong(.fields("ChargeType")) = gsStand then
				'���֐�����
				if StandDate = "" then StandDate = GetString(.fields("ChargeDate"))
				StandSum = StandSum + GetLong(.fields("ChargeAmount"))
				StandTax = StandTax + GetLong(.fields("ChargeTax"))
			else
				'�ŏ�������
				if SalesDate = "" then SalesDate = GetString(.fields("ChargeDate"))
				if GetLong(.fields("ChargeType")) <> gsCharge then
					'�ꊇ������
					if StandDate = "" then StandDate = GetString(.fields("ChargeDate"))
				end if 
				SalesSum = SalesSum + GetLong(.fields("ChargeAmount"))
				SalesTax = SalesTax + GetLong(.fields("ChargeTax"))
			end if
			.MoveNext
		loop
		.Close
	end with
	
	strSql = "UPDATE TBL_CTM_JOB SET "
	strSql = strSql & " StandDate = '" & StandDate & "'"
	strSql = strSql & ",StandSum = " & StandSum + StandTax
'	strSql = strSql & ",StandTax = " & StandTax
	strSql = strSql & ",SalesDate = '" & SalesDate & "'"
	strSql = strSql & ",SalesSum = " & SalesSum
	strSql = strSql & ",SalesTax = " & SalesTax
	strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
	Conn.execute strSql
	
	if err.number = 0 then
		Conn.CommitTrans
		
		'�q�ɐ�����������(�������̂�)
		if mode = 2 and ChargeType <> gsStand then
			if CheckJobType(JobCode) = gsExport then call SokoExport(Conn, ChargeNo)
		end if

'if WebUserID <> gsAdmin then
%>

<html>
	<script language=javascript>
		window.parent.list.location.href = "ChargeBill.asp?JobCode=<%=JobCode%>";
		window.parent.parent.info.location.href = "ExpenseInfo.asp?JobCode=<%=JobCode%>";
<%if mode = -1 then%>
		window.location.href = "../common/blank.htm";
<%elseif mode = 0 then%>
		window.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>";
<%else%>
		window.location.href = "ChargeHead.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>";
<%end if%>
<%if msg <> "" then%>
		alert("<%=msg%>");
<%end if%>
	</script>
</html>
<%
'end if

	else
		Conn.RollbackTrans
		ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
	end if		
	
	set Recset = nothing
	CloseDB Conn
	
else
	ShowMessage msg
end if 
%>

<%
'���̉�ʂ̂݌Ăяo���A�p�����[�^�s�v�A�w�b�_��`�ς�
function GetChargePattern()
dim mySql
dim myRec
dim myRs
dim mySeq
dim myPrc
dim myTax
dim myAttr
dim myQty
dim myUnit
dim cbmQty

	'�����p�^�[���ǉ�
	Set cmdSQL = Server.CreateObject("ADODB.Command")
	Set cmdSQL.ActiveConnection = Conn
	cmdSQL.CommandType = 4
	cmdSQL.CommandText = "DB_CTM_NEW_SUB"
	cmdSQL.Parameters.Refresh
	cmdSQL.Parameters("@SubCode").Value = "Expense"
	
	set myRec = Server.CreateObject("adodb.recordset")
	mySql ="SELECT CBM FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if not myRec.eof then cbmQty = GetDouble(myRec.fields("CBM"))
	myRec.Close
	
	mySql ="SELECT * FROM TBL_CTM_EXPENSE"
	myRec.Open mySql, Conn, adOpenKeyset, adLockOptimistic 
						
	set myRs = Server.CreateObject("adodb.recordset")		
	mySql = "SELECT ExpenseCost, ExpenseType, ExpensePrice, ExpenseUnit, ExpenseTaxName, ExpenseMemo, Remarks"
	mySql = mySql & " FROM PTN_EXPENSE WHERE PatternID = " & ChargePattern
	mySql = mySql & " ORDER BY ExpenseType, ExpenseCost"
	myRs.Open mySql, Conn, adOpenStatic, adLockReadOnly 		
	do while not myRs.eof
		'SeqNo�擾
		cmdSQL.Execute
		mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
		myPrc = GetLong(myRs.fields("ExpensePrice")) 
		myUnit = GetString(myRs.fields("ExpenseUnit"))
		select case GetString(myRs.fields("ExpenseUnit")) 
		case "�l3":				myQty = cbmQty
		case else:				myQty = 1
		end select
		myRemarks = GetString(myRs.fields("Remarks"))
		if left(myRemarks, 4) = "����" and instr(myRemarks, "�~") > 5 then
			myMin = GetLong(mid(myRemarks, 5, instr(myRemarks, "�~") - 5))
			if myPrc * myQty < myMin then 
				myPrc = myMin
				myQty = 1
				myUnit = "M/M"
			end if
		end if
		myTax = ResetDigital(myPrc * myQty * GetTaxRate(myRs.fields("ExpenseTaxName")), 0, -1)
		with myRec
			.AddNew
			.fields("JobCode") = JobCode
			.fields("SeqNo") = mySeq
			.fields("ExpenseClient") = ChargeClient
			.fields("ExpenseDate") = ChargeDate
			.fields("ExpenseType") = GetLong(myRs.fields("ExpenseType"))
			.fields("ExpenseAttr") = 0
			
			.fields("ExpenseCost") = GetLong(myRs.fields("ExpenseCost"))
			.fields("ExpenseUnit") = myUnit
			if myUnit <> "M/M" then
				.fields("ExpensePrice") = myPrc
				.fields("ExpenseQuantity") = myQty
			end if
			.fields("ExpenseAmount") = myPrc * myQty
			.fields("ExpenseTaxName") = GetString(myRs.fields("ExpenseTaxName"))
			.fields("ExpenseTax") = GetLong(myTax)
			
			.fields("ExpenseBill") = ChargeNo
			.fields("ExpenseMemo") = GetString(myRs.fields("ExpenseMemo"))
			.fields("Remarks") = myRemarks
			
			.fields("Updater") = WebUserID
			.fields("Creater") = WebUserID
			.update
		end with
		
		ChargeAmount = ChargeAmount + myPrc
		ChargeTax = ChargeTax + myTax
		myRs.movenext
	loop
	myRs.close
	myRec.close
	
	set myRs = nothing
	set myRec = nothing
				
end function

function GetCostsPattern()
dim mySql
dim myRec
dim myRs
dim mySeq
dim myPrc
dim myTax
	
	'�������擾
	Set cmdSQL = Server.CreateObject("ADODB.Command")
	Set cmdSQL.ActiveConnection = Conn
	cmdSQL.CommandType = 4
	cmdSQL.CommandText = "DB_CTM_NEW_SUB"
	cmdSQL.Parameters.Refresh
	cmdSQL.Parameters("@SubCode").Value = "Expense"
	
	set myRec = Server.CreateObject("adodb.recordset")
	mySql ="SELECT * FROM TBL_CTM_EXPENSE"
	myRec.Open mySql, Conn, adOpenKeyset, adLockOptimistic 
	
	set myRs = Server.CreateObject("adodb.recordset")
	mySql = "SELECT ExpenseCost, ExpenseQuantity, ExpensePrice, ExpenseUnit, ExpenseAmount, ExpenseTaxName, ExpenseTax, ExpenseMemo, Remarks"
	mySql = mySql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND  JobCode = '" & JobCode & "'"
	mySql = mySql & " AND ExpenseBill = '' AND ExpenseType = " & gsPayment			'�������x��
	mySql = mySql & " ORDER BY ExpenseCost"
	myRs.Open mySql, Conn, adOpenStatic, adLockReadOnly 		
	do while not myRs.eof 
		'SeqNo�擾	
		cmdSQL.Execute
		mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
		
		with myRec
			.AddNew
			.fields("JobCode") = JobCode
			.fields("SeqNo") = mySeq
			.fields("ExpenseClient") = ChargeClient
			.fields("ExpenseDate") = ChargeDate
			.fields("ExpenseType") = gsCharge
			.fields("ExpenseAttr") = 0
			
			.fields("ExpenseCost") = myRs.fields("ExpenseCost")				
			.fields("ExpensePrice") = myRs.fields("ExpensePrice")
			.fields("ExpenseQuantity") = myRs.fields("ExpenseQuantity")
			.fields("ExpenseUnit") = myRs.fields("ExpenseUnit")
			.fields("ExpenseAmount") = myRs.fields("ExpenseAmount")
			.fields("ExpenseTaxName") = myRs.fields("ExpenseTaxName")
			.fields("ExpenseTax") = myRs.fields("ExpenseTax")
			
			.fields("ExpenseBill") = ChargeNo
			.fields("ExpenseMemo") = myRs.fields("ExpenseMemo")
			.fields("Remarks") = myRs.fields("Remarks")
			
			.fields("Updater") = WebUserID
			.fields("Creater") = WebUserID
			.update
		end with
		
		ChargeAmount = ChargeAmount + GetLong(myRs.fields("ExpenseAmount")) 
		ChargeTax = ChargeTax + GetLong(myRs.fields("ExpenseTax")) 
		myRs.movenext
	loop
	myRs.close
	myRec.close
	
	set myRs = nothing
	set myRec = nothing
				
end function


function GetStandList()
dim mySql
dim myRec
	
	'�������֐؂�ւ�
	mySql = "UPDATE TBL_CTM_EXPENSE SET ExpenseBill = '" & ChargeNo & "'"
	mySql = mySql & " WHERE Deleted = 0 AND ExpenseBill = ''"
	mySql = mySql & " AND JobCode = '" & JobCode & "' AND ExpenseType = " & gsStand
	if ChargeType = gsCharge then mySql = mySql & " AND ExpenseAttr = 1"	
	if ChargeType = gsStand then mySql = mySql & " AND ExpenseAttr = 0"
	Conn.Execute mySql

	ChargeAmount = 0
	ChargeTax = 0
	set myRec = Server.CreateObject("adodb.recordset")
	with myRec
		mySql = "SELECT SUM(ExpenseAmount) AS ChargeAmount, SUM(ExpenseTax) AS ChargeTax FROM TBL_CTM_EXPENSE"
		mySql = mySql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseType = " & gsStand & " AND ExpenseBill = '" & ChargeNo & "'"
		.Open mySql, Conn, adOpenStatic, adLockReadOnly 
		if not myRec.eof then
			ChargeAmount = GetLong(.fields("ChargeAmount"))
			ChargeTax = GetLong(.fields("ChargeTax"))
		end if
		.close
	end with
	set myRec = nothing
end function
%>