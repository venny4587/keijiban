<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next
dim JobCode
dim JobClient
dim cd()
dim no()
dim qty()
dim amnt()
dim tax()
dim memo()

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	check = 0
	JobNo = GetPost(request("Job"))
	SeqNo = GetLong(request("Seq"))
	if JobNo <> "" and SeqNo <> 0 then
		with Recset
			strSql = "SELECT COST_NAME, E.* FROM TBL_CTM_EXPENSE AS E"
			strSql = strSql & " INNER JOIN MST_COST AS C ON E.ExpenseCost = C.COST_ID"
			strSql = strSql & " WHERE JobCode = '" & JobNo & "' AND SeqNo = " & SeqNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				check = 1
				ExpenseClient = GetString(.fields("ExpenseClient"))
				ExpenseDate = GetString(.fields("ExpenseDate"))
				ExpenseType = GetLong(.fields("ExpenseType"))
				ExpenseCost = GetString(.fields("ExpenseCost"))
				ExpenseUnit = GetString(.fields("ExpenseUnit"))
				ExpenseCost = GetLong(.fields("ExpenseCost"))
				ExpenseName = GetString(.fields("COST_NAME"))
				ExpenseAmount = GetLong(.fields("ExpenseAmount"))
				ExpenseTax = GetLong(.fields("ExpenseTax"))
				ExpenseTaxName = GetString(.fields("ExpenseTaxName"))
				CostsNo = GetString(.fields("ExpensePay"))
				ExpenseMemo = GetString(.fields("ExpenseMemo"))
				
				TaxRate = GetTaxRate(ExpenseTaxName)
			end if
			.close
		end with
	end if

	if check <> 0 then
		
		sum = 0:		max = 1
		ttlSum = 0:		ttlTax = 0
		chkcd = 0:		chkqty = 0
		
		Digit = GetLong(request("Digit"))
		if Digit = 0 then Digit = 100
		
		myMode = GetLong(request("mode"))
		if myMode = 0 then
			cnt = 0
			with Recset
				strSql = "SELECT * FROM (SELECT CASE J.JobCode WHEN '" & JobNo & "' THEN 0 ELSE 1 END AS kb, J.JobCode, RTON, LockerID, "
				strSql = strSql & " ChargeNo, ConfirmerID FROM TBL_CTM_JOB AS J LEFT JOIN TBL_CTM_CHARGE AS C ON J.JobCode = C.JobCode"
				strSql = strSql & " WHERE J.Deleted = 0 AND C.Deleted = 0 AND ChargeType <> " & gsStand & " AND JobNo = '" & JobNo & "'"
				strSql = strSql & ") AS TMP ORDER BY kb, JobCode"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof
					cnt = cnt + 1
					redim preserve cd(cnt)
					redim preserve no(cnt)
					redim preserve qty(cnt)
					redim preserve memo(cnt)
					cd(cnt) = GetString(.fields("JobCode"))
					no(cnt) = GetString(.fields("ChargeNo"))
					qty(cnt) = GetDouble(.fields("RTON"))
					if cd(cnt) = cd(cnt-1) then
						memo(cnt) = "���������񖇖ځI��"
					elseif GetLong(.fields("LockerID")) <> 0 then
						memo(cnt) = "���e�����b�N�ρI��"
					elseif GetLong(.fields("ConfirmerID")) <> 0 then
						memo(cnt) = "���������b�N�ρI��"
					else
						memo(cnt) = ExpenseMemo
					end if
					.movenext
				loop
				.close
			end with
			redim amnt(cnt)
			redim tax(cnt)
		else
			cnt = GetLong(request("cnt"))
			redim cd(cnt)
			redim no(cnt)
			redim qty(cnt)
			redim amnt(cnt)
			redim tax(cnt)
			redim memo(cnt)
			for i = 1 to cnt
				cd(i) = GetPost(request("cd" & i))
				no(i) = GetPost(request("no" & i))
				qty(i) = GetDouble(request("qty" & i))
				amnt(i) = GetLong(request("amn" & i))
				tax(i) = GetLong(request("tax" & i))
				memo(i) = GetString(request("memo" & i))
				
				sum = sum + qty(i)
				ttl = ttl + amnt(i)
				if qty(max) < qty(i) then max = i
				
				if GetString(cd(i)) <> "" then
					for j = 1 to i - 1
						if cd(i) = cd(j) then exit for
					next
					if j = i then
						if CheckJobLocked(cd(i)) = true then 
							check = 0
							memo(i) = "���e�����b�N�ρI��"
						elseif CheckBillLocked(conn, cd(i), no(i))= true then
							check = 0
							memo(i) = "���������b�N�ρI��"
						else
							chkcd = chkcd + 1
						end if
					elseif i > 1 then
						check = 0
						memo(i) = "���䒠�ԍ������I��"
					end if
				end if
				if qty(i) <> 0 then chkqty = chkqty + 1
			next
			if chkcd < 2 or chkqty < 2 then myMode = 0
		end if

		if myMode <> 0 then		'���Z
			for i = 1 to cnt
				if qty(i) = 0 then
					amnt(i) = 0
					tax(i) = 0
				else
					amnt(i) = ExpenseAmount * qty(i) / sum
					if amnt(i) < Digit then
						amnt(i) = Digit
					else
						amnt(i) = fix(amnt(i)/Digit) * Digit
					end if
					if ExpenseTax <> 0 then tax(i) = ResetDigital(amnt(i) * TaxRate, 1, 0)
				end if
				ttlSum = ttlSum + GetLong(amnt(i))
				ttlTax = ttlTax + GetLong(tax(i))
			next
			if ttlSum <> ExpenseAmount then amnt(max) = amnt(max) + (ExpenseAmount - ttlSum)
			if ttlTax <> ExpenseTax then tax(max) = tax(max) + (ExpenseTax - ttlTax)
			
			if myMode = 2 then	'��
				conn.BeginTrans
				
				set Rec = Server.CreateObject("adodb.recordset") 
				mark1 = JobNo & " \" & formatnumber(ExpenseAmount+ExpenseTax,0,true) & " �� "
				mark2 = "/" & cnt & " (" & session("FamilyName") & ")"
				
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Expense"
				
				with Recset
					strSql ="SELECT * FROM TBL_CTM_EXPENSE"
					.Open strSql, Conn, adOpenKeyset, adLockOptimistic
					for i = 2 to cnt
						if amnt(i) <> 0 or tax(i) <> 0 then
						
							with Rec
								strSql = "SELECT * FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ConfirmerID = 0"
								strSql = strSql & " AND JobCode = '" & cd(i) & "' AND ChargeNo = '" & no(i) & "'"
								.Open strSql, Conn, adOpenKeyset, adLockOptimistic
								if not .eof then
									ChargeClient = GetString(.fields("ChargeClient"))
									ChargeDate = GetString(.fields("ChargeDate"))
									
									.fields("ChargeAmount") = .fields("ChargeAmount") + GetLong(amnt(i))
									.fields("ChargeTax") = .fields("ChargeTax") + GetLong(tax(i))
									.update
								end if
								.Close
							end with
							
							cmdSQL.Execute
							mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
							.AddNew
							.fields("JobCode") = cd(i)
							.fields("SeqNo") = mySeq
							.fields("ExpenseClient") = ChargeClient
							.fields("ExpenseDate") = ChargeDate
							.fields("ExpenseType") = gsCharge
							.fields("ExpenseAttr") = 0
							.fields("ExpenseCost") = ExpenseCost
							.fields("ExpenseUnit") = ExpenseUnit
							.fields("ExpenseTaxName") = ExpenseTaxName
							.fields("ExpenseBill") = no(i)
							.fields("ExpenseMemo") = memo(i)
							
							.fields("Remarks") = mark1 & i & mark2
							.fields("ExpenseQuantity") = 1
							.fields("ExpensePrice") = GetLong(amnt(i))
							.fields("ExpenseAmount") = GetLong(amnt(i))
							.fields("ExpenseTax") = GetLong(tax(i))
							
							.fields("Updater") = WebUserID
							.fields("Creater") = WebUserID
							.update
						end if
					next
					.Close
				end with
				
				strSql = "UPDATE TBL_CTM_EXPENSE SET ExpenseAttr = 2"
				strSql = strSql & ", ExpenseQuantity = 1"
				strSql = strSql & ", ExpensePrice = " & GetLong(amnt(1))
				strSql = strSql & ", ExpenseAmount = " & GetLong(amnt(1))
				strSql = strSql & ", ExpenseTax = " & GetLong(tax(1))
				strSql = strSql & ", Remarks = '" & mark1 & "1" & mark2 & "'"
				strSql = strSql & ", Updated = GETDATE(), Updater = " & WebUserID
				strSql = strSql & " WHERE SeqNo = " & SeqNo
				conn.execute strSql
				
				with Rec
					strSql = "SELECT SUM(ExpenseAmount) AS TTL, SUM(ExpenseTax) AS TAX FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE Deleted = 0 AND ExpenseBill = '" & no(1) & "'" 'AND JobCode = '" & cd(1) & "'
					.Open strSql,conn,adOpenStatic,adLockReadOnly
					if not .eof then
						ChargeAmount = GetLong(.fields("TTL"))
						ChargeTax = GetLong(.fields("TAX"))
					end if
					.Close
				end with
				
				strSql = "UPDATE TBL_CTM_CHARGE SET "
				strSql = strSql & " ChargeAmount = " & ChargeAmount
				strSql = strSql & ",ChargeTax = " & ChargeTax
				strSql = strSql & " FROM TBL_CTM_CHARGE"
				strSql = strSql & " WHERE JobCode = '" & cd(1) & "' AND ChargeNo = '" & no(1) & "'"
				conn.execute strSql
				
				if err.number = 0 then
					conn.CommitTrans
%>
<html><script language=javascript>
window.opener.parent.parent.location.href = "mainframe.asp?mode=1&JobCode=<%=cd(1)%>&ChargeNo=<%=no(1)%>";
window.close();
</script></html>
<%
					response.end
				else
					conn.RollbackTrans
					ShowMessage "�����������L�̃G���[���N����܂����B(" & err.number & ":" & err.description & ")"
				end if
			end if
		end if
%>
<html>
<HEAD>
	<TITLE>����������</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
		end sub
		
		function DoConfirm(no)
		dim qty
			if no > 1 then
				qty = 0
				for each obj in frmInput.elements
					if obj.type = "text" and left(obj.name, 3) = "qty" then
						if GetDouble(obj.value) <> 0 then
							qty = qty + 1
						end if
					end if
				next
				if qty < 2 then
					msgbox "���f�[�^����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
					exit function
				end if
				if msgbox ("�����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			end if
			frmInput.mode.value = no
			frmInput.submit()
		end function
	</script>
</Head>
<body bgcolor="<%=gsSalesBackColor%>" onkeydown="DoShortCut()"  topmargin=10 class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="ChargeDivide.asp" method="post">
  	<input type=hidden name="mode" value="0">
  	<input type=hidden name="cnt" value="<%=cnt%>">
  	<input type=hidden name="Seq" value="<%=SeqNo%>">
  	<input type=hidden name="Job" value="<%=JobNo%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=18>
	  	<td width=50%>������������
	  	<td width=50% align=right><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <colgroup align=left>
	  <colgroup span=4 align=center>
	  <colgroup span=3 align=right>
<%
		with Recset
			strSql = "SELECT Vessel, Voy, ETD, ETA, POL, POD FROM TBL_CTM_JOB WHERE JobCode = '" & JobNo & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				Vessel = GetString(.fields("Vessel"))
				if GetString(.fields("Voy")) <> "" then Vessel = Vessel & " V." & GetString(.fields("Voy"))
				Port = GetString(.fields("POL")) & " �� " & GetString(.fields("POD"))
				if CheckJobType(JobNo) = gsExport then
					EtdEta = "�o�`���F" & Str2Date(.fields("ETD"))
				else
					EtdEta = "���`���F" & Str2Date(.fields("ETA"))
				end if
			end if
			.Close
		end with
%>
	  <TR height=28 class=pt9g>
		<TD colspan=6>�D�ցF<%=Vessel%>�@<%=Port%>
		<TD colspan=2><%=EtdEta%>
	  <TR height=28 class=pt9g>
		<TD colspan=5>���ږ��F<%=ExpenseName%>
		<TD nowrap><u>�@\<%=formatnumber(ExpenseAmount, 0, true)%></u>
		<TD nowrap><u>�@\<%=formatnumber(ExpenseTax, 0, true)%></u>
		<TD nowrap><u>�@\<%=formatnumber(ExpenseAmount + ExpenseTax, 0, true)%></u>
	  <TR height=28>
		<TD width=4% class=line>��
		<TD width=12% class=line>�䒠�ԍ�
		<TD width=12% class=line>�����ԍ�
		<TD width=12% class=line>���
		<TD width=25% class=line>���ڔ��l
		<TD width=10% class=line>�Ŕ����z
		<TD width=10% class=line>�����
		<TD width=15% class=line>���v���z
<%for i = 1 to cnt%>
	  <TR height=28>
		<TD class=line nowrap><%=i%>
		<TD class=line nowrap><%=cd(i)%><input type=hidden name="cd<%=i%>" value="<%=cd(i)%>">
		<TD class=line nowrap><%=no(i)%><input type=hidden name="no<%=i%>" value="<%=no(i)%>">
		<TD class=line nowrap><input class=sn name="qty<%=i%>" size=9 maxlength=9 value="<%=formatnumber(qty(i),3,true)%>" onkeydown="ResetEnter()">
		<TD class=line nowrap><%if left(memo(i), 1) = "��" then %><font class=pt9r><%=memo(i)%></font><%else%>
			<input class=sj name="memo<%=i%>" size=20 maxlength=35 value="<%=memo(i)%>" onkeydown="ResetEnter()"><%end if%>
		<TD class=line nowrap><%=formatnumber(GetLong(amnt(i)), 0, true)%>
		<TD class=line nowrap><%=formatnumber(GetLong(tax(i)), 0, true)%>
		<TD class=line nowrap><%=formatnumber(GetLong(amnt(i)) + GetLong(tax(i)), 0, true)%>
<%next%>
	  <TR height=28><td><br>
	  <TR height=28><TD colspan=7 align=right>
	  	�[���F<select name="Digit" onkeydown="ResetEnter()">
	  			<option value="1" <%if Digit = 1 then response.write "selected"%>>1
	  			<option value="10" <%if Digit = 10 then response.write "selected"%>>10
	  			<option value="100" <%if Digit = 100 then response.write "selected"%>>100
	  		</select> �~�@
		<input type=button style="width:90;height:30" value="���Z" onclick="DoConfirm(1)">
<%if myMode <> 0 and check <> 0 then%>
		<input type=button style="width:90;height:30" value="���s" onclick="DoConfirm(2)">
<%end if%>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>