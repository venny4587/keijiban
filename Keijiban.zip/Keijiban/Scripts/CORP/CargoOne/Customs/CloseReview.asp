<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		JobType = "I"
		DateTo = GetMonthLastDay(dateadd("m", -1, date))
		DateFrom = dateAdd("m", -1, dateadd("d", 1, DateTo))
	else
		JobType = GetPost(request("JobType"))
		CarryPlace = GetPost(request("CarryPlace"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		PermitNo = GetPost(request("PermitNo"))
	end if

%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub	
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->
	<FORM METHOD="POST" ACTION="CloseReview.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�Ɩ��敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">���ׂ�
					<option value="I" <%if JobType = "I" then response.write "selected"%>>�A��
					<option value="E" <%if JobType = "E" then response.write "selected"%>>�A�o</select>
				���n�ꏊ<input class=sj name="CarryPlace" value="<%=CarryPlace%>" maxlength=50 size=20 onkeydown="ResetEnter()">
				���� <input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				����<input class=si name="PermitNo" value="<%=PermitNo%>" maxlength=30 size=10 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</FORM>
	<!----------��������--------->
<div id=list>
<%
	if myMode > 0 then
		strSQL = "SELECT J.JobCode, CarryPlace, PermitDate, PermitNo, COST_NAME, ExpenseMemo"
		strSQL = strSQL & ", ExpensePrice, ExpenseQuantity, ExpenseAmount, ExpenseTax FROM TBL_CTM_JOB AS J"
		strSQL = strSQL & " INNER JOIN TBL_CTM_EXPENSE AS E ON J.JobCode = E.JobCode INNER JOIN MST_COST AS C "
		strSQL = strSQL & " ON E.ExpenseCost = C.COST_ID WHERE J.Deleted = 0 AND E.Deleted = 0 AND ExpenseCost IN (67, 13)"
		strSQL = strSQL & " AND E.ExpenseType <> " & gsPayment & " AND J.CustomBroker = '" & gsCorpCode & "'"
		if JobType <> "" then strSQL = strSQL & " AND SUBSTRING(J.JobCode, 2, 1) = '" & JobType & "'"
		if CarryPlace <> "" then	strSQL = strSQL & " AND CarryPlace LIKE '%" & FitSel(CarryPlace) & "%'"
		if PermitNo <> "" then strSQL = strSQL & " AND PermitNo LIKE '%" & FitSel(PermitNo) & "%'"
		if DateFrom <> "" then strSQL = strSQL & " AND PermitDate >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSQL = strSQL & " AND PermitDate <= '" & Date2Str(DateTo) & "'"
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY PermitDate, PermitNo"
		case 1:		strSQL = strSQL & " ORDER BY PermitNo"
		case 2:		strSQL = strSQL & " ORDER BY J.JobCode"
		end select
		strSQL = strSQL & ", COST_NAME, ExpenseMemo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=5 align=left>
			<colgroup span=3 align=right>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�䒠�ԍ�
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">����
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">����
			<TD width=14% nowrap>���n�ꏊ
			<TD width=8% nowrap>�P��
			<TD width=4% nowrap>����
			<TD width=10% nowrap>���z
			<TD width=30% nowrap>����
<%
				JobCode = ""
				cnt = 0:	sum = 0
				Do Until .EOF
					if JobCode <> GetString(.Fields("JobCode")) then
						cnt = cnt + 1
						JobCode = GetString(.Fields("JobCode"))
%>
					<TR style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=JobCode%>');">
						<TD nowrap class=upline><%=cnt%>
						<TD nowrap class=upline><%=JobCode%>
						<TD nowrap class=upline><%=Str2Date(.Fields("PermitDate"))%>
						<TD nowrap class=upline><%=ResetPermitNo(.Fields("PermitNo"))%>
						<TD nowrap class=upline><%=FitPlace(.Fields("CarryPlace"))%>
						<TD nowrap class=upline><%=formatnumber(.Fields("ExpensePrice"), 0, true)%>
						<TD nowrap class=upline><%=GetDouble(.Fields("ExpenseQuantity"))%>
						<TD nowrap class=upline><%=formatnumber(.Fields("ExpenseAmount"), 0, true)%>
						<TD nowrap class=upline><%=GetString(.Fields("COST_NAME")) & " " & GetMemo(.Fields("ExpenseMemo"))%>
<%
					else
%>
					<TR>
						<TD colspan=5>
						<TD nowrap><%=formatnumber(.Fields("ExpensePrice"), 0, true)%>
						<TD nowrap><%=GetDouble(.Fields("ExpenseQuantity"))%>
						<TD nowrap><%=formatnumber(.Fields("ExpenseAmount"), 0, true)%>
						<TD nowrap><%=GetString(.Fields("COST_NAME")) & " " & GetMemo(.Fields("ExpenseMemo"))%>
<%
					end if
					sum = sum + GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax"))
					.MoveNext
				Loop
%>
					<TR>
						<TD colspan=6 class=upline align=right>���v���z
						<TD colspan=2 class=upline><%=formatnumber(sum, 0, true)%>
						<TD colspan=6 class=upline><br>
			
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%

function FitPlace(myDate)
dim buf
	buf = GetString(myDate)
	if buf <> "" then
		if right(buf, 1) = ")" then buf = left(buf, instrrev(buf, "(")-1)
	end if
	FitPlace = buf
end function

function ResetPermitNo(myNo)
dim buf
	buf = GetString(myNo)
	if buf <> "" then
		if instr(buf,".") <> 0 then
			buf = replace(buf, ".", "<br>")
		else
			buf = replace(buf, "/", "<br>")
			buf = replace(buf, ",", "<br>")
		end if
	end if
	ResetPermitNo = buf
end function

function GetMemo(myMemo)
dim buf
	buf = GetString(myMemo)
	if len(buf) <= 9 then GetMemo = buf
end function
%>