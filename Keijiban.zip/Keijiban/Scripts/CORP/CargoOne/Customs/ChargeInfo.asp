<%
'on error resume next
	mode = clng("0" & Request("mode"))
	JobCode = cstr(Request("JobCode") & "")
	if instr(JobCode, " ") <> 0 then JobCode = ""
	if JobCode <> "" then
	
		url = "../common/blank.htm"
		ChargeNo = cstr(Request("ChargeNo") & "")
		if ChargeNo <> "" then	
			if mode = 1 then
				url = "ChargeList.asp?JobCode=" & JobCode & "&ChargeNo=" & ChargeNo
			else
				url = "ChargeHead.asp?JobCode=" & JobCode & "&ChargeNo=" & ChargeNo
			end if
		end if
%>
<HTML>
<HEAD>
<TITLE>�������ꗗ���</TITLE>
</HEAD>
	<FRAMESET rows="130,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="ChargeBill.asp?JobCode=<%=JobCode%>" NAME="list" MARGINWIDTH="10" MARGINHEIGHT="0">
		<FRAME SRC="<%=url%>" NAME="data" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>
<%
	end if
%>