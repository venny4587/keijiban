<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim JobClient
dim JobBelong
dim JobBroker
dim JobSalesman

	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	myLevel = CheckUserLevel(JobBelong, JobBroker)
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�������ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript>
		function ShowHead(myNo)
			window.parent.data.location.href = "ChargeHead.asp?JobCode=<%=JobCode%>&ChargeNo=" & myNo
			window.parent.data.focus()
		end function
		
		function ShowDetail(myNo)
			window.parent.data.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=" & myNo
			window.parent.data.focus()
		end function
		
		function ShowJobInfo()
			window.parent.location.href = "CustomsEdit.asp?JobCode=<%=JobCode%>"
		end function
		
		function ShowErase(myNo)
			dim win
			set win = window.open("../Account/ReceiveErase1.asp?FIN_NO=" & myNo,"ReceiveErase","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsSalesBackColor%>" topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=30%>���������ꗗ&nbsp;
	  	<img style="cursor:hand" src=img/back.gif alt="�Ɩ���ʂ�" onmousedown="ShowJobInfo()">
	  	<td width=50%>�䒠�ԍ��F<%=JobCode%>�@<font color=red>�y<%=ctmType(GetCtmType(JobClient))%>�z</font>
	  	<td width=20% align=right>
<%	if CheckJobLocked(JobCode) then %>
	  	<img style="cursor:help" src=img/security.gif alt="���b�N�ς�">
<%	elseif myLevel > 0 then %>
	  	<img style="cursor:hand" src=img/new.gif alt="�������V�K�ǉ�" onmousedown="ShowHead('')">
<%	end if %>
	</table>
	
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT ChargeNo, ChargeType, ChargeClient, ChargePic, ChargeCheck, ConfirmerID"
		strSql = strSql & ", ChargeDate, ChargeAmount, ChargeTax, ChargePayDay, FinisherID"
		strSql = strSql & " FROM TBL_CTM_Charge WHERE Deleted = 0 AND JobCode = '" & FitSel(JobCode) & "'"
		strSql = strSql & " ORDER BY ChargeNo"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=right height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>�敪
		<TD class=line nowrap align=center>�����ԍ�
		<TD class=line nowrap align=center>������
		<TD class=line nowrap align=left>������
		<TD class=line nowrap align=center>������
		<TD class=line nowrap>�������z
		<TD class=line nowrap>����
		<TD class=line nowrap>�m��
		<TD class=line nowrap>����
		<TD class=line nowrap>�ҏW
		<TD class=line nowrap>����
<%
			cnt = 0:	SeqNo = 0
			ttlTax = 0:	ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				ChargeNo = GetString(.Fields("ChargeNo"))				
				RefName = GetRefName(GetString(.Fields("ChargeClient")))
				
				if GetLong(.Fields("ChargeCheck")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=red>��</font>"
				end if
				if GetLong(.Fields("ConfirmerID")) <> 0 then
					check = "<font color=black>��</font>"
				else
					check = "<font color=gray>��</font>"
				end if
				myErase = GetEraseInfo(ChargeNo, 0)
				if GetLong(.Fields("FinisherID")) <> 0 then
					if WebUserID = JobSalesman or myLevel > 2 then
						finish = "<a class=bar href=""javascript:ShowErase('" & GetEraseNo(myErase) & "')"">��</a>"
					else
						finish = "<font color=black>��</font>"
					end if
				else
					finish = "<font color=gray>��</font>"
				end if
%>
				<TR align=center height=20>
					<TD class=line><%=cnt%><BR>
					<TD class=line><%=ShowBillType(.Fields("ChargeType"))%><BR>
					<TD class=line nowrap align=left><%=ShowVoucherNo(ChargeNo)%><BR>
					<TD class=line style="color:#228b22"><%=Str2MD(.Fields("ChargeDate"))%><BR>
					<TD class=line nowrap align=left <%=ShowTitle(RefName, 8)%>><%=StringCut(RefName,8)%><BR>
					<TD class=line><%=Str2MD(.Fields("ChargePayDay"))%><BR>
					<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("ChargeAmount"))+GetLong(.Fields("ChargeTax")), 0, true)%><BR>
					<TD class=line><%=status%><BR>
					<TD class=line><%=check%><BR>
					<TD class=line style="cursor:help" title="<%=myErase%>"><%=finish%><BR>
					<TD class=line><IMG SRC='img/open.gif' STYLE='cursor:hand' onclick="ShowHead('<%=ChargeNo%>')">
					<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=ChargeNo%>')">
<%
				ttlTax = ttlTax + GetLong(.Fields("ChargeTax"))
				ttlAmount = ttlAmount + GetLong(.Fields("ChargeAmount"))
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=5 class=pt9>���v���z
					<TD colspan=2 class=line><%=formatnumber(ttlAmount + ttlTax, 0, true)%>
<%
			end if
%>
	</TABLE>
<%
			'if cnt = 1 then response.write "<script language=vbscript>call ShowDetail(" & SeqNo & ")</script>"
		else
			response.write "<br><div align=center class=pt9r>���������쐬���Ă��������B</div>"
			response.write "<script language=vbscript>call ShowHead("""")</script>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>


<%
function GetEraseNo(myNo)
dim buf
	buf = GetString(myNo)
	GetEraseNo = mid(buf, 6, 10)
end function
%>