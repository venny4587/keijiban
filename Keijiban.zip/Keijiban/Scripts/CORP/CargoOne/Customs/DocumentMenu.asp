
<html>
<head>
	<title>���ޏ������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)		
		btnObtain.style.color = "black"
		btnSend.style.color = "black"
		btnFetch.style.color = "black"
		btnReturn.style.color = "black"
		btnView.style.color = "black"	
		select case mySel 
		case 1
			url = "DocumentObtain.asp"
			rst = "DocumentResult.asp?type=1"
			btnObtain.style.color = "red"
		case 2
			url = "DocumentSend.asp"
			rst = "DocumentResult.asp?type=2"
			btnSend.style.color = "red"
		case 3
			url = "DocumentFetch.asp"
			rst = "DocumentResult.asp?type=3"
			btnFetch.style.color = "red"
		case 4
			url = "DocumentReturn.asp"
			rst = "DocumentResult.asp?type=4"
			btnReturn.style.color = "red"
		case 5
			url = "DocumentView.asp"
			rst = "DocumentResult.asp?type=5"
			btnView.style.color = "red"
		end select
		window.parent.cbody.location.href = url 
		window.parent.parent.result.location.href = rst
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnObtain value="���ގ擾" onclick="DoAct(1)"></TD>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnSend value="���ޑ��t" onclick="DoAct(2)"></TD>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnFetch value="���މ��" onclick="DoAct(3)"></TD>
		    <TD width=110>
				<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnReturn value="���ޕԋp" onclick="DoAct(4)"></TD>
		    <TD width=110>
				<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnView value="���ޏƉ�" onclick="DoAct(5)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
