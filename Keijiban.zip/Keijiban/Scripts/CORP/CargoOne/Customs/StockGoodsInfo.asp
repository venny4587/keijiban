<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	myMode = GetLong(request("mode"))
	SeqNo = GetLong(request("SeqNo"))
	if SeqNo <> 0 then
		with Recset
			strSql = "SELECT * FROM TBL_CTM_STOCK_GOODS WHERE Deleted = 0 AND SeqNo = " & SeqNo
			.Open strSql, Conn, adOpenStatic, adLockReadOnly 
			if not .eof then
				ClientCode = GetString(.fields("ClientCode"))
				
				GoodsKey = GetString(.fields("GoodsKey"))
				GoodsCode = GetString(.fields("GoodsCode"))
				GoodsName = GetString(.fields("GoodsName"))
				ReferNo = GetString(.fields("ReferNo"))
				Status = GetString(.fields("Status"))
				Remarks = GetString(.fields("Remarks"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
		end with
	elseif myMode <> 0 then
		ClientCode = GetPost(request("Client"))
	end if
%>
<html>
<HEAD>
	<TITLE>���i�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoSearch()
			dim win
			set win = window.open("ClientSearch.asp?mode=1&cd=" & frmInput.Shipper.value,"ClientSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub DataSave()
			if frmInput.ShipperName.value = "" then
				frmInput.Shipper.focus()
				msgbox "�����׎����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkText("GoodsKey","�i��",1) = false then exit sub
			if checkText("GoodsName","�i��",1) = false then exit sub
			if checkText("GoodsCode","JAN����",0) = false then exit sub
			if checkText("Status","���萔",0) = false then exit sub
			if checkText("ReferNo","���臂",0) = false then exit sub
			if checkText("Remarks","���l", 0) = false then exit sub
			if checkLen("Remarks","���l", 250) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.mode.value = 1
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then call DataSave() 
			if window.event.keyCode=27 then window.close()
		end sub
		
		sub InitForm()
			frmInput.Shipper.focus()
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsStockBackColor%>" onload="InitForm()" topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="StockGoodsSave.asp" method="post">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="mode" value="0">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>�����i�ڍ׏��&nbsp;
<%if SeqNo <> 0 then %>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
		<td width=50% align=right>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><TD><img src=img/spacer.gif height=3>
	  <TR height=28><TD nowrap>������<input type=hidden name="JobShipper" value="<%=ClientCode%>">
		<TD colspan=2><input class=si name="Shipper" size=8 maxlength=10 value="<%=GetRefName(ClientCode)%>" onkeydown="ResetEnter()">
			<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="ShipperName" size=40 value="<%=GetFullName(ClientCode)%>" onkeydown="ResetEnter()" readonly>
	  <TR><TD><img src=img/spacer.gif height=3>
	  <TR height=28><TD nowrap>�i��
		<TD colspan=2><input class=si name="GoodsKey" size=16 maxlength=20 value="<%=GoodsKey%>" onkeydown="ResetEnter()">
		�@	�i��&nbsp;<input class=sj name="GoodsName" size=48 maxlength=100 value="<%=GoodsName%>" onkeydown="ResetEnter()">
	  <TR height=28><TD nowrap>���臂
		<TD colspan=2><input class=si name="ReferNo" size=10 maxlength=20 value="<%=ReferNo%>" onkeydown="ResetEnter()">
		�@	���萔&nbsp;<input class=si name="Status" size=15 maxlength=10 value="<%=Status%>" onkeydown="ResetEnter()">
		�@	JAN����&nbsp;<input class=si name="GoodsCode" size=24 maxlength=30 value="<%=GoodsCode%>" onkeydown="ResetEnter()">
	  <TR><TD><img src=img/spacer.gif height=3>
	  <TR class=pt9>
		<TD width=80 valign=top>���l&nbsp;
		<TD width=400><textarea name="Remarks" rows=5 style="width:350"><%=Remarks%></textarea>
		<TD width=100 align=center><input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DataSave()">
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	</TABLE>
  </FORM>
<%if SeqNo <> 0 then%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
<%end if%>
<center>
<%if myMode <> 0 then %>
<script language=javascript>
	if (window.opener.frmInput.StockCode != null) frmInput.GoodsKey.value = window.opener.frmInput.StockCode.value;
	if (window.opener.frmInput.StockName != null) frmInput.GoodsName.value = window.opener.frmInput.StockName.value;
	if (window.opener.frmInput.StockReferNo != null) frmInput.ReferNo.value = window.opener.frmInput.StockReferNo.value;
	if (window.opener.frmInput.StockStatus != null) frmInput.Status.value = window.opener.frmInput.StockStatus.value;
</script>
<%end if%>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
%>
