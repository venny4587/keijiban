<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	JobCode = GetPost(request("JobCode"))
	SeqNo = GetLong(request("SeqNo"))
	
	if JobCode <> "" then
		if CheckJobFinished(JobCode) then
			JobCode = ""
			ShowMessage "�Y������Ɩ��͊��Ɋm�肳��܂����B"
		end if
	end if
	
	if JobCode <> "" then
	
		OpenSql Conn, SqlServerName, DataBaseName
				
		mode = GetLong(request("mode"))
		select case mode
		
		case -1
			strSql = "UPDATE TBL_CTM_CONTAINER SET Arranged = 0"
			strSql = strSql & ",Updated = GETDATE(), Updater = " & WebUserID
			strSql = strSql & " WHERE Deleted = 0 AND Arranged = " & SeqNo
			Conn.Execute strSql

			strSql = "UPDATE TBL_CTM_DELIVERY SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID 
			strSql = strSql & ",Updated = GETDATE()" 
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			Conn.Execute strSql
			
		case else
					
			if SeqNo = 0 then 
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Delivery"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
			end if
				
			set Recset = Server.CreateObject("adodb.recordset")	
			with Recset
				strSql = "SELECT * FROM TBL_CTM_DELIVERY WHERE Deleted = 0"
				strSql = strSql & " AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = GetPost(request("JobCode"))
					.fields("SeqNo") = SeqNo
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				.fields("OrderDate") = Date2Str(request("OrderDate"))
				.fields("OrderTime") = GetPost(request("OrderTime"))
				.fields("DeliveryDate") = Date2Str(request("DeliveryDate"))
				.fields("DeliveryTime") = GetPost(request("DeliveryTime"))
				.fields("DeliveryBroker") = GetPost(request("DeliveryBroker"))
				.fields("DeliveryType") = GetPost(request("DeliveryType"))
				.fields("DeliveryFrom") = GetPost(request("DeliveryFrom"))
				.fields("DeliveryTo") = GetLong(request("DeliveryTo"))
				.fields("Contents") = GetPost(request("Contents"))	
				.fields("Remarks") = GetPost(request("Remarks"))
					
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			set Recset = nothing
			
			if GetPost(request("ContainerSel")) <> "" then
				strSql = "UPDATE TBL_CTM_CONTAINER SET Arranged = 0"
				strSql = strSql & ",Updated = GETDATE(), Updater = " & WebUserID
				strSql = strSql & " WHERE Deleted = 0 AND Arranged = " & SeqNo
				Conn.Execute strSql
				
				strSql = "UPDATE TBL_CTM_CONTAINER SET Arranged = " & SeqNo
				strSql = strSql & ",Updated = GETDATE(), Updater = " & WebUserID
				strSql = strSql & " WHERE Deleted = 0 AND SeqNo IN (" & GetPost(request("ContainerSel")) & ")"
				Conn.Execute strSql
			end if
			
		end select	
				
		CloseDB Conn
%>
<html>
<script language=javascript>
	if (window.opener.name=="frameView") window.opener.location.href = "DeliveryList.asp?JobCode=<%=JobCode%>";
	else window.opener.frameView.location.href = "DeliveryList.asp?JobCode=<%=JobCode%>";
	window.close();
</script>
</html>
<%
	end if
%>