<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobBelong
dim JobBroker
dim LockCheck
dim HonbuCheck
dim TruckCheck
dim SokoCheck

	JobCode = GetPost(request("JobCode"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	LockCheck = true
	HonbuCheck = false
	TruckCheck = false
	SokoCheck = false
	with recset
		strSql = "SELECT JobCode FROM TBL_CTM_JOB WHERE Deleted = 0 AND LockerID = 0 AND JobCode = '" & JobCode & "'"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .EOF then LockCheck = false
		.Close
		
		if LockCheck then
			strSql = "SELECT JobCode FROM TBL_CTM_JOB WHERE Deleted = 0 AND CustomBroker = '" & gsCorpCode & "' AND JobCode = '" & JobCode & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .EOF then HonbuCheck = true
			.Close
			
			if HonbuCheck then
				strSql = "SELECT CostsNo FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsClient = '" & gsCorpCode & "' AND JobCode = '" & JobCode & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .EOF then HonbuCheck = false
				.Close
				
				strSql = "SELECT CostsNo FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsClient = '" & gsCorpTruck & "' AND JobCode = '" & JobCode & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if .EOF then TruckCheck = true
				.Close
			end if
			
			strSql = "SELECT CostsNo FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsClient = '" & gsCorpSoko & "' AND JobCode = '" & JobCode & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if .EOF then SokoCheck = true
			.Close
		end if
	end with
	
	mode = GetLong(request("mode"))
%>
<HTML>
<HEAD>
	<TITLE>�x���ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=javaScript>	
		function ShowChargeList() {
			window.parent.parent.ctms.location.href = "CostsInfo.asp?type=1&JobCode=<%=JobCode%>";
		}
			
		function ShowDetail(myNo) {
			var win = window.open("PaymentDetail.asp?JobCode=<%=JobCode%>&seq="+myNo,"PaymentDetail","scrollbars=no,width=600,height=400");
			win.focus();
		}
		
		function DoChargeHonbu() {
			window.parent.parent.ctms.location.href = "SokoCharge.asp?mode=0&JobCode=<%=JobCode%>";
		}
		
		function DoChargeSoko() {
			window.parent.parent.ctms.location.href = "SokoCharge.asp?mode=1&JobCode=<%=JobCode%>";
		}
		
		function DoChargeTruck() {
			window.parent.parent.ctms.location.href = "SokoCharge.asp?mode=2&JobCode=<%=JobCode%>";
		}
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsCostsBackColor%>" topmargin=3 class=pt9n <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td nowrap width=50%>�����ֈꗗ<td width=50% align=right>
<%if mode = 0 then%>
		<img style="cursor:hand" src=img/search.jpg alt="�x���`�[�Ɖ�" onmousedown="ShowChargeList();">
<%end if%>
	</table>
	<hr size=1 color=green>
<%
	with recset
		strSql = "SELECT SeqNo, ExpenseCost, COST_NAME, ConfirmerID, ExpenseClient, ExpenseAttr, ExpenseMemo"
		strSql = strSql & ",ExpenseAmount, ExpenseTax, ExpenseDate, ExpenseBill, ExpensePay, COST_CD"
		strSql = strSql & " FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseType = " & gsStand & " AND JobCode = '" & JobCode & "'"
		strSql = strSql & " ORDER BY COST_CD, ExpenseMemo, SeqNo"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .EOF then
			response.write "<br><center>�Y���f�[�^�͓o�^����Ă��܂���B</center>"
		else
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap align=center>����
		<TD class=line nowrap align=left>���֖���
		<TD class=line nowrap align=center>���֓�
		<TD class=line nowrap>���֋��z
		<TD class=line nowrap align=left>�x����
		<TD class=line nowrap align=center>����
<%
			cnt = 0
			ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				CostName = GetString(.Fields("COST_NAME"))
				RefName = GetRefName(GetString(.Fields("ExpenseClient")))
				if GetString(.Fields("ExpenseBill")) <> "" then
					status = "<font color=green>��</font>"
				else
					status = "<font color=red>��</font>"
				end if
				myAmount = GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax"))
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='<%=gsCostsForeColor%>';" onmouseout="this.bgColor='<%=gsCostsBackColor%>';" onclick="ShowDetail(<%=.Fields("SeqNo")%>);">
					<TD class=line><%=cnt%><BR>
					<TD class=line align=center><%=status%><BR>
					<TD class=line nowrap align=left nowrap <%=ShowTitle(CostName, 7)%>><%=StringCut(CostName,7)%><BR>
					<TD class=line nowrap align=center><%=Str2MD(.Fields("ExpenseDate"))%><BR>
					<TD class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
					<TD class=line nowrap nowrap <%=ShowTitle(RefName, 7)%>><%=StringCut(RefName,7)%><BR>
					<TD class=line align=center><%=ShowExpenseAttr(GetLong(.Fields("ExpenseAttr")))%><BR>
<%
				ttlAmount = ttlAmount + myAmount
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=3 class=pt9>���v���z
					<TD colspan=2 class=line nowrap><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%
		end if
		.Close
	end with
%> 
	<br> 
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td nowrap width=25%>���x���ꗗ&nbsp;
<%if mode = 0 then%>
	<%if HonbuCheck then %>
		<td nowrap width=20% title="�{�Ђ̎Г��������s" onmousedown="DoChargeHonbu()" style="cursor:hand;color:blue">�y�{�А����z
	<%end if%>
	<%if TruckCheck then %>
		<td nowrap width=20% title="�g���b�N�̐������s" onmousedown="DoChargeTruck()" style="cursor:hand;color:blue">�y�ׯ������z
	<%end if%>
<%if left(JobCode, 1) <> gsSokoInit then%>
	<%if SokoCheck then %>
		<td nowrap width=20% title="�ېł̎Г��������s" onmousedown="DoChargeSoko()" style="cursor:hand;color:blue">�y�ېŐ����z
	<%end if%>
<%end if%>

		<td nowrap width=15% align=right>
			<img style="cursor:hand" src=img/search.jpg alt="�x���`�[�Ɖ�" onmousedown="ShowChargeList();">
<%end if%>
	</table>
	<hr size=1 color=black>
<%
	with recset
		strSql = "SELECT SeqNo, ExpenseCost, COST_ID, COST_CD, COST_NAME, ConfirmerID, ExpenseClient, ExpenseAttr"
		strSql = strSql & ",ExpenseAmount, ExpenseTax, ExpenseDate, ExpenseBill, ExpensePay, ExpenseType, ExpenseMemo"
		strSql = strSql & " FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseType = " & gsPayment
		strSql = strSql & " ORDER BY COST_CD, SeqNo"
'response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .EOF then
			response.write "<center>�Y���f�[�^�͓o�^����Ă��܂���B</center>"
		else
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap align=center>�m��
		<TD class=line nowrap>�x������
		<TD class=line nowrap>���ڔ��l
		<TD class=line nowrap align=center>�x�����z
		<TD class=line nowrap>�x����
<%
			cnt = 0
			ttlTax = 0
			ttlAmount = 0
			ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				CostName = GetString(.Fields("COST_NAME"))
				myMemo = GetString(.Fields("ExpenseMemo"))
				RefName = GetRefName(GetString(.Fields("ExpenseClient")))
				select case GetLong(.Fields("ExpenseCost"))
				case 123:	myColor = "gray"
				case else:	myColor = "black"
				end select
				if GetLong(.Fields("ConfirmerID")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=gray>��</font>"
				end if
				myAmount = GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax"))
%>
				<TR height=20 style="cursor:hand;color:<%=myColor%>" onmouseover="this.bgColor='<%=gsCostsForeColor%>';" 
					onmouseout="this.bgColor='<%=gsCostsBackColor%>';" onclick="ShowDetail(<%=.Fields("SeqNo")%>);">
					<TD class=line><%=cnt%><BR>
					<TD class=line align=center><%=status%><BR>
<%if GetLong(.Fields("COST_ID")) <> 113 and GetLong(.Fields("COST_ID")) <> 123 then %>
					<TD class=line nowrap <%=ShowTitle(CostName, 7)%>><%=StringCut(CostName,7)%><BR>
					<TD class=line nowrap <%=ShowTitle(myMemo, 7)%>><%=StringCut(myMemo,7)%><BR>
<%else%>
					<TD class=line nowrap colspan=2<%=ShowTitle(myMemo, 15)%>><%=StringCut(myMemo,15)%><BR>
<%end if%>
					<TD class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
					<TD class=line nowrap <%=ShowTitle(RefName, 8)%>><%=StringCut(RefName,8)%><BR>
<%
				ttlAmount = ttlAmount + myAmount
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=3 class=pt9>���v���z
					<TD colspan=2 class=line nowrap><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%
		end if
		.Close
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>