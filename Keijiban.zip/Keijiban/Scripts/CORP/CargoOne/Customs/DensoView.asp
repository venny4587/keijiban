<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next

dim myMode
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		ClientRef = "VILENEJP"
		SalesTo = GetMonthLastDay(Dateadd("m", -1, date))
		SalesFrom = Dateadd("m", -1, Dateadd("d", 1, SalesTo))
	else
		JobType = GetPost(request("JobType"))
		ClientRef = GetPost(request("ClientRef"))
		SalesFrom = GetPost(request("SalesFrom"))
		SalesTo = GetPost(request("SalesTo"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		
		if ClientRef <> "" then ClientCode = GetCtmCode(ClientRef, 0)
	end if

%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function DoSearch()
			if frmInput.ClientRef.value = "" then
				msgbox "�����׎����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
			else
				frmInput.submit()
			end if
		end function
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		sub SalesFrom_OnBlur()
			frmInput.SalesFrom.value = setdate(frmInput.SalesFrom.value)
		end sub	
		sub SalesTo_OnBlur()
			frmInput.SalesTo.value = setdate(frmInput.SalesTo.value)
		end sub
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub	
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->
	<FORM METHOD="POST" ACTION="DensoView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">					
				������ <input class=si name="SalesFrom" value="<%=SalesFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="SalesTo" value="<%=SalesTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				���o�`�� <input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnSearch VALUE="����" onclick="DoSearch()">
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</FORM>
	<!----------��������--------->
<div id=list>
<%
	if myMode > 0 then
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & " SELECT J.JobCode, JobClient, Vessel, SalesDate, CASE SUBSTRING(J.JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD"
		strSQL = strSQL & ", InvoiceNo, JobType, SeqNo, ExpenseBill, COST_NAME, ExpenseQuantity, ExpenseUnit, ExpensePrice, ExpenseAmount, ExpenseTax, ExpenseMemo"
		strSQL = strSQL & " FROM TBL_CTM_JOB AS J INNER JOIN TBL_CTM_EXPENSE AS E ON J.JobCode = E.JobCode INNER JOIN MST_COST AS C"
		strSQL = strSQL & " ON E.ExpenseCost = C.COST_ID WHERE J.Deleted = 0 AND E.Deleted = 0 AND E.ExpenseType <> 3) AS TMP"
		if ClientRef = "690" then
			strSQL = strSQL & " WHERE JobClient LIKE '690%'"
		else
			strSQL = strSQL & " WHERE JobClient = '" & FitSel(ClientCode) & "'"
		end if
		if JobType <> "" then	strSQL = strSQL & " AND SUBSTRING(JobCode, 2, 1) = '" & JobType & "'"
		if SalesFrom <> "" then strSQL = strSQL & " AND SalesDate >= '" & Date2Str(SalesFrom) & "'"
		if SalesTo <> "" then strSQL = strSQL & " AND SalesDate <= '" & Date2Str(SalesTo) & "'"
		if DateFrom <> "" then strSQL = strSQL & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSQL = strSQL & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY JobCode"
		case 1:		strSQL = strSQL & " ORDER BY SUBSTRING(JobCode, 2, 1), InvoiceNo"
		case 2:		strSQL = strSQL & " ORDER BY SUBSTRING(JobCode, 2, 1), Vessel, ETAETD"
		case 3:		strSQL = strSQL & " ORDER BY SUBSTRING(JobCode, 2, 1), ETAETD, Vessel"
		case 4:		strSQL = strSQL & " ORDER BY SUBSTRING(JobCode, 2, 1), SalesDate"
		end select
		strSQL = strSQL & ", ExpenseBill, SeqNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=left>
			<colgroup span=3 align=center>
			<colgroup align=left>
			<colgroup align=right>
			<colgroup align=left>
			<colgroup span=4 align=right>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)" class=pt9n>Invoice ��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�D�@�@�@��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">���ד�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�����ԍ�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">������
			<TD nowrap>���@�ځ@��
			<TD nowrap>����
			<TD nowrap>�P��
			<TD nowrap>�P��
			<TD nowrap>���z
			<TD nowrap>�����
			<TD nowrap>���v���z
<%
				amount = 0:	tax = 0
				sumAmount = 0:	sumTax = 0
				JobCode = ""
				Do while not .EOF
					ExpenseQuantity = GetDouble(.Fields("ExpenseQuantity"))
					ExpensePrice = GetDouble(.Fields("ExpensePrice"))
					if JobCode <> GetString(.Fields("JobCode")) then
						if JobCode <> "" then
%>
					<TR><TD nowrap class=line><%=InvoiceNo%><br>
						<TD nowrap class=line><%=Vessel%><br>
						<TD nowrap class=line><%=EtaEtd%><br>
						<TD nowrap class=line><%=JobCode%>
						<TD nowrap class=line><%=ChargeDate%>
						<TD class=line><BR><TD class=line><BR>
						<TD class=line><BR><TD class=line><BR>
						<TD nowrap class=line><%=formatnumber(amount, 0, true)%>
						<TD nowrap class=line><%=formatnumber(tax, 0, true)%>
						<TD nowrap class=line><%=formatnumber(amount + tax, 0, true)%>
					<TR><TD><BR>
<%
							sumAmount = sumAmount + amount
							sumTax = sumTax + tax
						end if
						amount = 0:		tax = 0
						JobCode = GetString(.Fields("JobCode"))
						InvoiceNo = GetString(.Fields("InvoiceNo"))
						Vessel = GetString(.Fields("Vessel"))
						EtaEtd = Str2Date(.Fields("ETAETD"))
						ChargeDate = Str2Date(.Fields("SalesDate"))
%>
					<TR><TD nowrap class=line><%=InvoiceNo%><br>
						<TD nowrap class=line><%=Vessel%><br>
						<TD nowrap class=line><%=EtaEtd%><br>
						<TD nowrap class=line><%=JobCode%>
						<TD nowrap class=line><%=ChargeDate%>
						<TD nowrap class=line><%=ShowCostName(GetString(.Fields("COST_NAME")), GetString(.Fields("ExpenseMemo")))%>
					<%if GetString(.Fields("ExpenseUnit")) = "M/M" then%>
						<TD nowrap class=line><br>
						<TD nowrap class=line>M/M
						<TD nowrap class=line><br>
					<%else%>
						<TD nowrap class=line><%if ExpenseQuantity <> 0 then response.write formatnumber(ExpenseQuantity, 3, false)%><br>
						<TD nowrap class=line><%=GetString(.Fields("ExpenseUnit"))%><br>
						<TD nowrap class=line><%if ExpensePrice <> 0 then response.write formatnumber(ExpensePrice, 2, false)%><br>
					<%end if%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, false)%><br>
						<TD nowrap class=line><br>
<%
					else
%>
					<TR><TD><TD><TD><TD><TD>
						<TD nowrap class=line><%=ShowCostName(GetString(.Fields("COST_NAME")), GetString(.Fields("ExpenseMemo")))%>
					<%if GetString(.Fields("ExpenseUnit")) = "M/M" then%>
						<TD nowrap class=line><br>
						<TD nowrap class=line>M/M
						<TD nowrap class=line><br>
					<%else%>
						<TD nowrap class=line><%if ExpenseQuantity <> 0 then response.write formatnumber(ExpenseQuantity, 3, false)%><br>
						<TD nowrap class=line><%=GetString(.Fields("ExpenseUnit"))%><br>
						<TD nowrap class=line><%if ExpensePrice <> 0 then response.write formatnumber(ExpensePrice, 2, false)%><br>
					<%end if%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, false)%><br>
<%
						
					end if
					amount = amount + GetLong(.Fields("ExpenseAmount"))
					tax = tax + GetLong(.Fields("ExpenseTax"))
					.MoveNext
				Loop
				if JobCode <> "" then
%>
					<TR><TD nowrap class=line><%=InvoiceNo%>
						<TD nowrap class=line><%=Vessel%>
						<TD nowrap class=line><%=EtaEtd%><BR>
						<TD nowrap class=line><%=JobCode%>
						<TD nowrap class=line><%=ChargeDate%>
						<TD class=line><BR><TD class=line><BR>
						<TD class=line><BR><TD class=line><BR>
						<TD nowrap class=line><%=formatnumber(amount, 0, true)%>
						<TD nowrap class=line><%=formatnumber(tax, 0, true)%>
						<TD nowrap class=line><%=formatnumber(amount + tax, 0, true)%>
					<TR><TD><BR>
<%
					sumAmount = sumAmount + amount
					sumTax = sumTax + tax
				end if
%>
					<TR><TD><TD><TD><TD><TD>
						<TD nowrap class=line>TOTAL
						<TD class=line><BR><TD class=line><BR><TD class=line><BR>
						<TD nowrap class=line><%=formatnumber(sumAmount, 0, true)%>
						<TD nowrap class=line><%=formatnumber(sumTax, 0, true)%>
						<TD nowrap class=line><%=formatnumber(sumAmount + sumTax, 0, true)%>
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function GetJobType(myType, myNum)
	if myType = "" then
		GetJobType = "I-" & mid(myNum, 7)
	elseif instr(myType, ":") = 0 then
		GetJobType = myType & "-" & mid(myNum, 7)
	else
		GetJobType = left(myType, 1) & "-" & mid(myNum, 7)
	end if
end function

function ShowCostName(myName, myMemo)
	select case myName
	case "���̑�����", "RANDOM"
		ShowCostName = myMemo
	case else
		ShowCostName = myName
		if len(myName & myMemo) < 17 then ShowCostName = ShowCostName & " " & myMemo
	end select
end function
%>