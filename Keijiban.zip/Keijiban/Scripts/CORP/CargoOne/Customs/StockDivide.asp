<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next
dim myMode
	
	JobCode = GetPost(request("JobCode"))
	myClient = GetPost(request("Client"))
	ClientCode = GetCtmCode(myClient, 0)
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myMode = GetLong(request("mode"))
	if myMode <> 0 then
		StockCBM = GetDouble(request("StockCBM"))
		
		'�ꊇ�m�菈��
		if myMode = 2 then
			msg = ""
			
			Quantity = 0:	myPrice = 0
			with recset
				strSql = "SELECT SUM(StockPkgCnt) AS QTY FROM TBL_CTM_STOCK WHERE Deleted = 0 AND  SeqNo IN (" & GetPost(request("SeqNo")) & ")"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .EOF then Quantity = GetDouble(.Fields("QTY"))
				.Close
			end with
			if Quantity <> 0 and StockCBM <> 0 then myPrice = StockCBM / Quantity
			
			if myPrice = 0 then
				msg = "�Y������f�[�^�͈������s�ł��B"
			else
				sumCBM = 0
				Conn.BeginTrans
				with Recset
					strSql = "SELECT * FROM TBL_CTM_STOCK WHERE Deleted = 0 AND SeqNo IN (" & GetPost(request("SeqNo")) & ") ORDER BY StockPkgCnt"
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
					do while not .eof
						mySeq = GetLong(.fields("SeqNo"))
						myCBM = GetDouble(formatnumber(GetLong(.fields("StockPkgCnt")) * myPrice, 3, true))
						sumCBM = sumCBM + myCBM
						
						.fields("StockCBM") = myCBM
						.update
						
						if err.number <> 0 then exit do
						.movenext
					loop
					.Close
				end with
				
				if err.number = 0 AND mySeq <> 0 then
					if sumCBM <> StockCBM then
						strSql = "UPDATE TBL_CTM_STOCK SET "
						strSql = strSql & " StockCBM = StockCBM + " & StockCBM - sumCBM
						strSql = strSql & " WHERE SeqNo = " & mySeq
						Conn.Execute strSql
					end if
				end if
				
				if err.number = 0 then
					Conn.CommitTrans
					msg = "�������͖����������܂����B"
				else
					Conn.RollbackTrans
					msg = "�����������L�̃G���[���N����܂����B" & vbcrlf & err.number & ":" & err.description
				end if
			end if
		end if
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>���Ƀ��W���[������</TITLE>	
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoCheck()
			Call CheckAll("SeqNo", frmInput.CheckAll.Checked)
		end function 
		
		function DoCheck2()
			Call CheckAll("SeqNo", frmInput.CheckAll2.Checked)
		end function 
		
		function DoConfirm()
			if GetLong(frmInput.StockCBM.value) = 0 then
				msgbox "���W���[����͂��Ă��������B"
				exit function
			end if
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 5) = "SeqNo" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "���Ώۏ��i��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("�����������s���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.mode.value = 2
			frmInput.submit()
		end function
		
		function ShowDetail(myNo)
			set win = window.open("StockInDetail.asp?SeqNo=" & myNo,"StockInDetail","resizable=1,scrollbars=1,width=600,height=400")
			win.focus()
		end function
		
		sub StockDBM_OnBlur()
			frmInput.StockDBM.value = GetDouble(frmInput.StockDBM.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
<%if myMode = 2 then%>
	<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
	<%end if%>
<%else%>
			frmInput.StockCBM.focus()
<%end if%>
		end sub
		
		sub DoClose()
			window.close()
		end sub
	</SCRIPT>
</HEAD>

<body topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
	<FORM METHOD="POST" ACTION="StockDivide.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
			<TR height=40><TD nowrap><INPUT TYPE="HIDDEN" NAME="Client" VALUE='<%=myClient%>'>
				�䒠�ԍ� <input class=si name="JobCode" size=10 maxlength=10 value="<%=JobCode%>" onkeydown="ResetEnter()" readonly>
				�����׎� <input class=si name="ClientName" size=36 maxlength=100 value="<%=GetFullName(ClientCode)%>" onkeydown="ResetEnter()" readonly>
				�i<%=ClientCode%>�j
		</table>
		<hr width=96% size=1 color=blue>
		
	<!----------��������--------->
<%
	with recset
		strSql = "SELECT * FROM TBL_CTM_STOCK WHERE Deleted = 0 AND StockClient = '" & ClientCode & "' AND JobCode = '" & JobCode & "' ORDER BY StockNo"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			lngCount = 0
%>
		<TABLE width=96% Border=0 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=4 align=center>
			<colgroup align=right>
			<colgroup align=left>
			<colgroup span=2 align=right>
			<colgroup span=2 align=left>
			<colgroup span=2 align=center>
		  <TR height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>���ɇ�
			<TD class=line nowrap>���ɓ�
			<TD class=line nowrap>�i��
			<TD class=line nowrap>���ɐ�
			<TD class=line nowrap>�׎p
			<TD class=line nowrap>�d��
			<TD class=line nowrap>����
			<TD class=line nowrap>�i��
			<TD class=line nowrap>����
			<TD class=line nowrap colspan=2>�S�I��<input type=checkbox name="CheckAll" value="" onclick="DoCheck()">
<%
			cnt = 0
			ttlCNT = 0:		ttlGW = 0:		ttlCBM = 0
			Do while not .EOF
				cnt = cnt + 1
				SeqNo = GetLong(.Fields("SeqNo"))
				StockName = GetString(.Fields("StockName"))
				StockMark = GetString(.Fields("StockMark"))
				StockMemo = GetString(.Fields("StockMemo"))
				Package = GetString(.Fields("StockPackage"))
%>
		<TR height=20>
			<TD class=line><%=cnt%><BR>
			<TD class=line nowrap><%=GetString(.Fields("StockNo"))%><BR>
			<TD class=line nowrap><%=Str2Date(.Fields("StockDate"))%><BR>
			<TD class=line nowrap style="color:green"><%=GetString(.Fields("StockCode"))%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("StockPkgCnt")), 0, true)%><BR>
			<TD class=line nowrap><%=GetString(.Fields("StockPackage"))%><BR>
			<TD class=line nowrap><%=formatnumber(GetDouble(.Fields("StockGW")), 0, true)%><BR>
			<TD class=line nowrap><%=formatnumber(GetDouble(.Fields("StockCBM")), 3, true)%><BR>
			<TD class=line><%=StockName%><BR><TD class=line><%=StockMemo%><BR>
			<TD class=line><input type=checkbox name="SeqNo" value="<%=SeqNo%>">
			<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail(<%=SeqNo%>)">
<%
				ttlCNT = ttlCNT + GetLong(.Fields("StockPkgCnt"))
				ttlGW = ttlGW + GetDouble(.Fields("StockGW"))
				ttlCBM = ttlCBM + GetDouble(.Fields("StockCBM"))
				.movenext
			loop
			if cnt > 1 then
%>			
		<TR height=20>
			<TD colspan=3>
			<TD align=right>�� �v
			<TD nowrap><%=formatnumber(ttlCNT, 0, true)%>
			<TD nowrap><%=Package%>
			<TD nowrap><%=formatnumber(ttlGW, 0, true)%>
			<TD nowrap><%=formatnumber(ttlCBM, 3, true)%>
			<TD nowrap> M<sup>3</sup>
			<TD nowrap>
			<TD nowrap colspan=2>�S�I��<input type=checkbox name="CheckAll2" value="" onclick="DoCheck2()">
<%
			end if
%>
		</TABLE>
		
		<TABLE width=96% Cellspacing=3 CellPadding=3 class=pt9n>
			<tr><td align=right>
<%select case WebUserID
case 1, 36, 46, 51, 62 %>
				���W���[���v�@<input class=sn name="StockCBM" value="<%=StockCBM%>" maxlength=10 size=8 onkeydown="ResetEnter()"> M<sup>3</sup>
				<INPUT style="width:80px;height:30px;" TYPE=button VALUE="���s" onclick="DoConfirm()">�@
<%end select%>
				<INPUT style="width:80px;height:30px;" TYPE=button VALUE="����" onclick="DoClose()">
		</TABLE>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
%>
	</FORM>
</center>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>
