<!-- #include file="../common/common.asp" -->
<%
	select case webUserID
	case 1,33,34,51,52,57
		myExport = 1
	case else
		myExport = 0
	end select
	
	select case webUserID
	case 1,33,34,51,52,57
		myAssort = 1
	case else
		if instr(session("Depart"),"�c��") <> 0 then
			myAssort = 1
		else
			myAssort = 0
		end if
	end select 
	
	select case webUserID
	case 1, 2
		myDiscount = 1
	case else
		myDiscount = 0
	end select 
	
%>
<html>
<head>
	<title>Main Menu Bar</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		btnCustom.style.color = "black"
		btnSearch.style.color = "black"
		btnPattern.style.color = "black"
		btnPort.style.color = "black"
		btnPlace.style.color = "black"
<%if myExport = 1 then%>
		btnSoko.style.color = "black"
<%end if%>
<%if myAssort = 1 then%>
		btnAssort.style.color = "black"
<%end if%>
<%if myDiscount = 1 then%>
		btnDiscount.style.color = "black"
<%end if%>
		select case mySel 
		case 1
			url = "../Customer/mainframe.asp"
			btnCustom.style.color = "red"
		case 2
			url = "../Customer/CustomerView.asp"
			btnSearch.style.color = "red"
		case 3
			url = "ExpensePatternView.asp"
			btnPattern.style.color = "red"
		case 4
			url = "../baseinfo/mstCountry.asp"
			btnPort.style.color = "red"
		case 5
			url = "../baseinfo/mstPlace.asp"
			btnPlace.style.color = "red"
		case 6
			url = "SokoOutput.asp"
			btnSoko.style.color = "red"
		case 7
			url = "CustomsAssort.asp"
			btnAssort.style.color = "red"
		case 8
			url = "DiscountProc.asp"
			btnDiscount.style.color = "red"
		case else
			url = "../common/blank.htm"
		end select
		window.parent.tool.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnCustom value="�ڋq���Ǘ�" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnSearch value="�ڋq���Ɖ�" onclick="DoAct(2)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnPattern value="�����p�^�[��" onclick="DoAct(3)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnPort value="�`�����Ǘ�" onclick="DoAct(4)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnPlace value="���u�ꏊ�Ǘ�" onclick="DoAct(5)"></TD>
<%if myExport = 1 then%>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnSoko value="�q�ɐ����o��" onclick="DoAct(6)"></TD>
<%end if%>
<%if myAssort = 1 then%>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnAssort value="�l�ߍ�������" onclick="DoAct(7)"></TD>
<%end if%>
<%if myDiscount = 1 then%>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnDiscount value="�l���ꊇ����" onclick="DoAct(8)"></TD>
<%end if%>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
