<!-- #include file="../common/common.asp" -->
<%
	select case webUserID
	case 1,36,47
		myTruck = 1
	case else
		myTruck = 0
	end select
	
	select case webUserID
	case 1,73,74
		myDenso = 1
	case else
		myDenso = 0
	end select
%>
<html>
<head>
	<title>Main Menu Bar</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
<%if myTruck = 1 then%>
		btnTruck.style.color = "black"
<%end if%>
<%if myDenso = 1 then%>
		btnDenso.style.color = "black"
<%end if%>
		btnClose.style.color = "black"
		btnBalance.style.color = "black"
		btnReview.style.color = "black"
		select case mySel 
		case 4
			url = "DensoView.asp"
			btnDenso.style.color = "red"
		case 5
			url = "SokoTruck.asp"
			btnTruck.style.color = "red"
		case 1
			url = "CloseCheck.asp"
			btnClose.style.color = "red"
		case 2
			url = "BalanceView.asp"
			btnBalance.style.color = "red"
		case 3
			url = "CloseReview.asp"
			btnReview.style.color = "red"
		case else
			url = "../common/blank.htm"
		end select
		window.parent.lock.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
<%if myDenso = 1 then%>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnDenso value="�d���Ɖ�" onclick="DoAct(4)"></TD>
<%end if%>
<%if myTruck = 1 then%>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnTruck value="�g���b�N��" onclick="DoAct(5)"></TD>
<%end if%>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnClose value="�����ߑO����" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnBalance value="�e�����b�N" onclick="DoAct(2)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnReview value="�ʊ֗����Ɖ�" onclick="DoAct(3)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
