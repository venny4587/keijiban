<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim CTM_CD
	dim PATN_ID
	dim PATN_CD
	dim PATN_TYPE
	dim PATN_NAME
	dim PATN_ENAME
	dim PATN_REMARKS
	
	CTM_CD = GetPost(Request("cd"))
	PATN_ID = GetLong(Request("PATN_ID"))
	PATN_CD = GetPost(Request("PATN_CD"))
	PATN_TYPE = GetLong(Request("PATN_TYPE"))
	PATN_BELONG = GetPost(Request("PATN_BELONG"))
	PATN_NAME = GetPost(Request("PATN_NAME"))
	PATN_ENAME = GetPost(Request("PATN_ENAME"))
	PATN_REMARKS = GetPost(Request("PATN_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			strSql = "SELECT PATN_CD FROM MST_PATTERN WHERE PATN_DELETED = 0 AND PATN_ID <> " & PATN_ID
			strSql = strSql & " AND CTM_CD = '" & CTM_CD & "' AND PATN_CD = '"  & replace(PATN_CD,"'","''") & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����ڃR�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then
		With Recset
			strSql = "SELECT PATN_CD FROM MST_PATTERN WHERE PATN_DELETED = 0 AND PATN_ID <> " & PATN_ID
			strSql = strSql & " AND CTM_CD = '" & CTM_CD & "' AND PATN_NAME = '"  & replace(PATN_NAME,"'","''") & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����ڂ̘a�����̂͊����ł��B(�Y�����鍀�ں���:" & .Fields("PATN_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If false and blnEdit Then	
		With Recset
			strSql = "SELECT PATN_CD FROM MST_PATTERN WHERE PATN_DELETED = 0 AND PATN_ID <> " & PATN_ID
			strSql = strSql & " AND CTM_CD = '" & CTM_CD & "' AND PATN_ENAME = '"  & replace(PATN_ENAME,"'","''") & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����ڂ̉p�����̂͊����ł��B(�Y�����鍀�ں���:" & .Fields("PATN_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
	
		if PATN_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "PATN_ID"	
			cmdSQL.Execute
			PATN_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
		strSQL = "SELECT * FROM MST_PATTERN WHERE PATN_DELETED = 0 AND PATN_ID = " & PATN_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("CTM_CD") = CTM_CD
				.fields("PATN_ID") = PATN_ID
				.fields("PATN_CREATER") = WebUserID
				.fields("PATN_CREATED") = now
				.fields("PATN_DELETED") = 0
			End If
			.Fields("PATN_CD") = PATN_CD
			.Fields("PATN_TYPE") = PATN_TYPE
			.Fields("PATN_BELONG") = PATN_BELONG
			.Fields("PATN_NAME") = PATN_NAME
			.Fields("PATN_ENAME") = PATN_ENAME
			.Fields("PATN_REMARKS") = PATN_REMARKS	
		
			.fields("PATN_UPDATER") = WebUserID
			.fields("PATN_UPDATED") = now
			.Update 
			.Close 
		End With
'		if (Request("s") = "cd" or Request("s") = "") then
'			strURL = "ExpensePattern.asp?p=" & GetCurrentPage(Conn, "MST_PATTERN", "PATN_CD", 1, PATN_CD, " AND PATN_DELETED = 0") & "&s=" & Request("s")
'		elseif (Request("s") = "en") then
'			strURL = "ExpensePattern.asp?p=" & GetCurrentPage(Conn, "MST_PATTERN", "PATN_ENAME", 1, PATN_ENAME, " AND PATN_DELETED = 0") & "&s=" & Request("s")
'		elseif (Request("s") = "jp") then
'			strURL = "ExpensePattern.asp?p=" & GetCurrentPage(Conn, "MST_PATTERN", "PATN_NAME", 1, PATN_NAME, " AND PATN_DELETED = 0") & "&s=" & Request("s")
'		end if 
		strURL = "ExpensePattern.asp?cd=" & CTM_CD & "&p=" &  Request("p") & "&s=" & Request("s")
		Response.Redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
