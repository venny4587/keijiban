<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
dim JobCode, MBL, HBL, Canceled, FinisherID

JobCode = GetPost(request("JobCode"))
if JobCode <> "" then

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			Session("JobCode") = JobCode
			JobClient = GetString(.fields("JobClient"))
			JobBelong = GetString(.fields("JobBelong"))
			JobManager = GetLong(.fields("JobManager"))
			JobSalesman = GetLong(.fields("JobSalesman"))
			JobOperator = GetLong(.fields("JobOperator"))
			JobCountry = GetString(.fields("JobCountry"))
			JobService = GetString(.fields("JobService"))
			JobType = GetString(.fields("JobType"))
			ReferNo = GetString(.fields("ReferNo"))
			
			JobNo = GetString(.fields("JobNo"))
			EdaNo = GetString(.fields("EdaNo"))	
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POL = GetString(.fields("POL"))
			POD = GetString(.fields("POD"))
			POLN = GetString(.fields("POLN"))
			PODN = GetString(.fields("PODN"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			MBL = GetString(.fields("MBL"))
			HBL = GetString(.fields("HBL"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			RTON = GetDouble(.fields("RTON"))
			Marks = GetString(.fields("Marks"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Container = GetString(.fields("Container"))
			InvoiceNo = GetString(.fields("InvoiceNo"))
			
			JobShipper = GetString(.fields("JobShipper"))
			RequireDate = Str2Date(.fields("RequireDate"))
			Insurance = GetLong(.fields("Insurance"))
			Inspection = GetString(.fields("Inspection"))
			Surrendered = GetLong(.fields("Surrendered"))
			ShipCorp = GetString(.fields("ShipCorp"))
			ShipPic = GetString(.fields("ShipPic"))
			CustomBroker = GetString(.fields("CustomBroker"))
			CustomRemark = GetString(.fields("CustomRemark"))
			CustomType = GetLong(.fields("CustomType"))
			CustomDate = Str2MD(.fields("CustomDate"))
			CustomTime = GetString(.fields("CustomTime"))
			CustomSheet = GetString(.fields("CustomSheet"))
			ViaPlace = GetString(.fields("ViaPlace"))
			CarryPlace = GetString(.fields("CarryPlace"))
			CarryDate = Str2Date(.fields("CarryDate"))
			FreeTime = Str2Date(.fields("FreeTime"))
			PermitNo = GetString(.fields("PermitNo"))
			PermitDate = Str2Date(.fields("PermitDate"))
			ObtainDate = GetLong(.fields("ObtainDate"))
			ReturnDate = Str2Date(.fields("ReturnDate"))
			DeliveryDate = Str2Date(.fields("DeliveryDate"))
			
			Remarks = GetString(.fields("Remarks"))
			FinisherID = GetLong(.fields("FinisherID"))
			FinishDate = GetDate(.fields("FinishDate"))
			LockerID = GetLong(.fields("LockerID"))
			LockDate = GetDate(.fields("LockDate"))
			Canceled = GetLong(.fields("Canceled"))	
			
			SalesDate = Str2Date(.fields("SalesDate"))	
			StandDate = Str2Date(.fields("StandDate"))	
		end if
		.close
		
		StrSql = "SELECT CTM_NACCS_CD, CTM_ETC_CODE, CTM_ETC_DATA FROM CUSTOMER WHERE CTM_CD = '" & JobShipper & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			CTM_NACCS_CD = GetString(.fields("CTM_NACCS_CD"))
			CTM_ETC_CODE = GetString(.fields("CTM_ETC_CODE"))
			CTM_ETC_DATA = GetString(.fields("CTM_ETC_DATA"))
		end if 
		.close
	end with
	
	myJobType = CheckJobType(JobCode)
	select case myJobType 
	case gsExport
		myCheck = 0
		Surrendered = 1
		if DeliveryDate = "" then DeliveryDate = ETD
		if JobType = "" then JobType = GetInitJobType(POL)
	case gsImport
		myCheck = 1
		Surrendered = 1
		if Quantity = 0 OR Package = "" then myCheck = 0
	case gsOther
		myCheck = 0
		JobType = expType(11)
	end select

	if RTON = 0 then
		if myJobType = gsImport then 
			RTON = GetKGS(GW, CBM)
		else
			RTON = GetRTON(GW, CBM)
		end if
	end if
  	
	myLevel = CheckUserLevel(JobBelong, CustomBroker)
	if CustomBroker = gsCorpCode and UserShop = gsCorpInit then 
		myLevel = CheckUserLevel(gsCorpInit, CustomBroker)
		select case WebUserID
		case 33, 34, 51:	myLevel = 3
		end select
	end if
	if myLevel < 1 and JobOperator = WebUserID then myLevel = 1
	if myLevel < 2 and JobSalesman = WebUserID then myLevel = 2
	
	'OutsideCode = mid(Time2Code(now), 4) & Session("WebUserID") & Date2Code(date)
%>

<html>
<HEAD>
	<TITLE>�Ɩ��o�^</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=Javascript src="../common/css/function.js"></SCRIPT>
	<SCRIPT language=Javascript>
	<!--
		function GetPicInfo()
		{
			frmInput.PIC_CELL.value = "";
			frmInput.PIC_TEL.value = "";
			frmInput.PIC_FAX.value = "";
			var obj = frmInput.JobManager;
			if (obj.options.length > 0) {
				var pic = obj.options[obj.selectedIndex].value;		
				loadXMLDoc("../HttpXml/GetMstInfo.asp?mode=PicInfo&CTM_CD=<%=JobClient%>&PIC_ID=" + pic);
			}
		}
		
		function GetJobInfo()
		{
			var job = frmInput.JobNo.value;
			if (job == "") {
				frmInput.JobNo.focus();
				alert("�{�Б䒠�ԍ�����͂��Ă��������B");
			} else {
				loadXMLDoc("../HttpXml/GetJobInfo.asp?mode=jobinfo&JobCode=" + job);
			}
		}
	-->
	</SCRIPT>

	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub Addnew()
			window.location.href = "Customs.asp"
		end sub
		
		sub DataLock()
			call DataSave(2)
		end sub
		
		sub DataUnLock()
			if msgbox ("�Y���Ɩ��m����������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
		end sub
		
		sub DoCancel()
			if msgbox ("�Y���Ɩ��f�[�^�𒆎~���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 0
				frmInput.submit()
			end if
		end sub
		
		sub DoDelete()
			if msgbox ("�Y���Ɩ��f�[�^���폜���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoChange()
			dim win
			set win = window.open("ClientChange.asp?JobCode=<%=JobCode%>","ClientChange","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
			win.focus()
		end sub
		
		sub DoModify()
			dim win
			set win = window.open("CustomsModify.asp?JobCode=<%=JobCode%>","SokoModify","resizable=0,StatusBar=0,scrollbars=1,width=600,height=400")
			win.focus()
		end sub
		
		sub DoSearch()
			dim win
			set win = window.open("ClientSearch.asp?mode=1","ClientSearch","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
			win.focus()
		end sub
		
		sub DoCopy()
			dim win
			set win = window.open("CustomsCopy.asp?JobCode=<%=JobCode%>","CustomsCopy","resizable=0,StatusBar=0,scrollbars=1,width=500,height=300")
			win.focus()
		end sub
		
		sub DoPlace(mode)
			dim win
			set win = window.open("../common/PlaceSearch.asp?mode=" & mode,"PlaceSearch","resizable=0,StatusBar=0,scrollbars=1,width=500,height=400")
			win.focus()
		end sub
		
		sub DoContainer()
			dim win
			set win = window.open("ContainerInfo.asp?JobCode=<%=JobCode%>","ContainerInfo","resizable=0,StatusBar=0,scrollbars=1,width=600,height=400")
			win.focus()
		end sub
		
		sub DoPrint()
<%if CustomBroker = gsCorpCode then%>
			set win = window.open("HonshaSI.asp?JobCode=<%=JobCode%>", "CustomsSI","scrollbars=1,width=800,height=600") 
<%else%>
			set win = window.open("CustomsSI.asp?JobCode=<%=JobCode%>", "CustomsSI","scrollbars=1,width=800,height=600") 
<%end if%>
			win.focus()
		end sub
		
		sub DoPaper(mode)
			set win = window.open("PaperDetail.asp?JobCode=<%=JobCode%>&mode=" & mode, "PaperDetail","scrollbars=1,width=800,height=600") 
			win.focus()
		end sub
		
		sub ShowDetail()
		dim win
			set win = window.open("DeliveryDetail.asp?JobCode=<%=JobCode%>","Delivery","scrollbars=1,width=600,height=360")
			win.focus()
		end sub
		
		sub ShowSoko()
		dim win
			set win = window.open("SokoDetail.asp?JobCode=<%=JobCode%>","SokoDetail","scrollbars=1,width=600,height=360")
			win.focus()
		end sub
		
		sub ShowCountry()
		dim win
			set win = window.open("CustomerCountry.asp?JobCode=<%=JobCode%>","CustomerCountry","scrollbars=1,width=360,height=280")
			win.focus()
		end sub
		
		sub ShowCorpInfo()
		dim win
			if checkText("EdaNo","CORP Job ��", 1) = false then exit sub
			set win = window.open("ShowCorpDetail.asp?Job=" & frmInput.EdaNo.value,"CorpDetail","scrollbars=1,width=600,height=360")
			win.focus()
		end sub
		
		sub ShowCORP()
		dim cd, win
			cd = cstr(frmInput.ReferNo.Value & "")
			if cd = "" then
				frmInput.ReferNo.focus()
				msgbox "CORP�̑䒠�ԍ����_�񇂂ɓ��͂��Ă��������B"
			else
				set win = window.open("ShowJobDetail.asp?JobCode=" & cd,"CorpDetail","scrollbars=1,width=600,height=360")
				win.focus()
			end if
		end sub
		
		sub DataSave(mode)
			if checkText("Vessel","�D��",0) = false then exit sub
			if checkText("Voy","�֖�",0) = false then exit sub
<%select case myJobType
case gsImport %>
			if checkDate("ETA","���`��",<%=myCheck%>) = false then exit sub
			if checkDate("ETD","�o�`��",0) = false then exit sub
<%case gsExport%>
			if checkDate("ETA","���`��",0) = false then exit sub
			if checkDate("ETD","�o�`��",<%=myCheck%>) = false then exit sub
<%case else%>
			if checkDate("ETA","���`��",0) = false then exit sub
			if checkDate("ETD","�o�`��",0) = false then exit sub
<%end select%>
			if checkText("ReferNo","�_��ԍ�",0) = false then exit sub
			if checkText("JobNo","��\�䒠�ԍ�",0) = false then exit sub
			if checkText("EdaNo","CORP�C��ԍ�",0) = false then exit sub
			if checkText("Vessel","�D��",0) = false then exit sub
			if checkText("MBL","Master B/L",0) = false then exit sub
			if checkText("HBL","House B/L",0) = false then exit sub
			if checkText("Commodity","�i��",0) = false then exit sub
			if checkText("InvoiceNo","�C���{�C�X�ԍ�",0) = false then exit sub
			if checkDouble("Quantity","��",0) = false then exit sub
			if checkDouble("GW","Weight",0) = false then exit sub
			if checkDouble("CBM","Measurement",0) = false then exit sub
			if checkText("Container","�R���e�i���",0) = false then exit sub
			if checkLen("Container","�R���e�i���",255) = false then exit sub
			if checkText("Marks","�}�[�N���",0) = false then exit sub
			if checkLen("Marks","�}�[�N���",255) = false then exit sub
			if checkText("ShipCorp","�D���",0) = false then exit sub
			if checkText("ShipPic","�A����",0) = false then exit sub
			if checkDate("RequireDate","�[�i��]��", 0) = false then exit sub
'			if checkText("CustomBroker","�ʊ֋Ǝ�",0) = false then exit sub
			if checkText("CarryPlace","�����ꏊ",0) = false then exit sub
			if checkDate("CarryDate","������", 0) = false then exit sub
			if checkDate("FreeTime","FreeTime", 0) = false then exit sub
			if checkDate("PermitDate","�ʊ֋���", 0) = false then exit sub
			if checkText("PermitNo","�����ԍ�",0) = false then exit sub
			if checkDate("ReturnDate","�����ԋp��", 0) = false then exit sub
			if mode = 2 then
<%if myJobType <> gsOther then%>
				if checkText("Package","�׎p",1) = false then exit sub
<%end if%>
				if checkDate("DeliveryDate","��Ɗ�����", 1) = false then exit sub
			else
				if checkText("Package","�׎p",0) = false then exit sub
				if checkDate("DeliveryDate","��Ɗ�����", 0) = false then exit sub
			end if
			if checkText("CustomRemark","�ʊփ���", 0) = false then exit sub
			if checkLen("CustomRemark","�ʊփ���",255) = false then exit sub
			if checkText("Remarks","���l", 0) = false then exit sub
			if checkLen("Remarks","���l",255) = false then exit sub
			if mode = 2 then
				if msgbox ("�Y���Ɩ����m�肵�Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			else
<%if gsPolite = 1 then%>
				if msgbox ("�Ɩ��f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub JobNo_OnBlur()
			frmInput.JobNo.value = FitJobCode(frmInput.JobNo.value)
		end sub
		sub Quantity_OnBlur()
			frmInput.Quantity.value = FitZero(formatnumber(GetDouble(frmInput.Quantity.value),3,true))
		end sub
		sub GW_OnBlur()
			frmInput.GW.value = FitZero(formatnumber(GetDouble(frmInput.GW.value),3,true))
			frmInput.RTON.value = GetRTON(frmInput.GW.value, frmInput.CBM.value)
<%if myJobType = gsImport then %>
			frmInput.SAI.value = GetKGS(frmInput.GW.value, frmInput.CBM.value)
<%end if%>
		end sub
		sub CBM_OnBlur()
			frmInput.CBM.value = formatnumber(GetDouble(frmInput.CBM.value),3,true)
			frmInput.RTON.value = GetRTON(frmInput.GW.value, frmInput.CBM.value)
<%if myJobType = gsImport then %>
			frmInput.SAI.value = GetKGS(frmInput.GW.value, frmInput.CBM.value)
<%end if%>
		end sub
		
		sub Package_OnBlur()
			frmInput.Package.value = ucase(frmInput.Package.value)
		end sub		
		sub ETD_OnBlur()
			frmInput.ETD.value = setdate(frmInput.ETD.value)
		end sub		
		sub ETA_OnBlur()
			frmInput.ETA.value = setdate(frmInput.ETA.value)
		end sub
		sub RequireDate_OnBlur()
			frmInput.RequireDate.value = setdate(frmInput.RequireDate.value)
		end sub
		sub Sheet1_Onblur()
			frmInput.Sheet1.value = GetLong(frmInput.Sheet1.value)
		end sub		
		sub Sheet2_Onblur()
			frmInput.Sheet2.value = GetLong(frmInput.Sheet2.value)
		end sub
		sub ReturnDate_OnBlur()
			frmInput.ReturnDate.value = setdate(frmInput.ReturnDate.value)
		end sub
		sub PermitDate_OnBlur()
			frmInput.PermitDate.value = setdate(frmInput.PermitDate.value)
		end sub
		sub CarryDate_OnBlur()
			frmInput.CarryDate.value = setdate(frmInput.CarryDate.value)
		end sub
		sub FreeTime_OnBlur()
			frmInput.FreeTime.value = setdate(frmInput.FreeTime.value)
		end sub
		sub DeliveryDate_OnBlur()
			frmInput.DeliveryDate.value = setdate(frmInput.DeliveryDate.value)
		end sub
		sub SalesDate_OnBlur()
			frmInput.SalesDate.value = setdate(frmInput.SalesDate.value)
		end sub
		
		sub InitForm()
			frmInput.Vessel.focus()
<%if true or Quantity <> 0 OR Package <> "" then %>
			window.parent.info.location.href = "ExpenseInfo.asp?JobCode=<%=JobCode%>"
<%else%>
			window.parent.info.location.href = "../common/blank.htm"		' ���ӁF�@CustomsHistory.asp
<%end if %>
<%if FinisherID <> 0 or myLevel < 1 then %>
			call LockAll()
<%end if%>
		end sub
		
		sub DoShortCut()
<%if FinisherID = 0 then%>	
			if window.event.keyCode=119 then call ShowDetail() 
	<%if myLevel > 0 then%>
			if window.event.keyCode=120 then call DataSave(1) 
	<%end if%>
<%end if%>
		end sub
	//-->
	</SCRIPT>
</Head>
<body topmargin=3 onload="InitForm()" onkeydown="DoShortCut()" class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CustomsSave.asp" method="post">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	    <td width=50%>���׎���&nbsp;
<%	if myLevel > 1 and FinisherID = 0 then %>
	 	  <img style="cursor:hand" src=img/waste.gif width=16 height=16 alt="�폜" onmousedown="DoDelete()">�@
<%	end if %>
	  	  <img style="cursor:hand" src=img/copy.jpg alt="�R�s�[" onmousedown="DoCopy()">�@
<%	if Quantity <> 0 and Package <> "" then %>
		  <img style="cursor:hand" src=img/sicard.jpg alt="�ʊ�SI���" onmousedown="DoPrint()">�@
		  <%if MBL <>"" then %><img style="cursor:hand" src=img/cover.jpg alt="MB/L���o�^" onmousedown="DoPaper(0)">�@<%end if%>
		  <%if HBL <>"" then %><img style="cursor:hand" src=img/sheet.jpg alt="HB/L���o�^" onmousedown="DoPaper(1)">�@<%end if%>
<%	end if %>
	  	<td width=50% align=right>
<%	if FinisherID <> 0 then %>
<%if myLevel > 3 OR (LockerID = 0 AND myLevel > 2) then%><a href="javascript:DoModify()"><img src=img/open.gif border=0 alt="�ύX"></a>�@<%end if%>
	  	  <img style="cursor:help" src=img/security.gif  alt="�m�F�ҁF<%=GetEmployName(FinisherID, "F") & " (" & ShowDateTimeShort(FinishDate) & ")"%>" <%if myLevel > 1 then %>onmousedown="DataUnLock()"<%end if%>>
<%	else%>
	<%if myLevel > 0 then%>
		  <img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DataLock()">�@
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave(1)">
	<%end if%>
<%	end if %>
	</table>
	<hr width=96% size=1 color=blue>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=22>
		<TD>�䒠�ԍ�<TD><input class=si name="JobCode" size=12 maxlength=10 value="<%=JobCode%>" onkeydown="ResetEnter()" readonly>
		<TD>�����׎�<TD><input class=si name="ClientName" size=40 maxlength=100 value="<%=GetFullName(JobClient)%>" onkeydown="ResetEnter()" readonly>
<%if myLevel > 1 then%><a href="javascript:DoChange()"><img src=img/search.jpg border=0 alt="����"></a><%end if%>
			(<font class=pt9n><%=JobClient%></font>)
	  <TR height=22>
		<TD>NACCS����<TD><input class=si name="CTM_NACCS_CD" size=12 maxlength=10 value="<%=CTM_NACCS_CD%>" onkeydown="ResetEnter()" readonly>
		<TD>B/L��׎�<input type=hidden name="JobShipper" value="<%=JobShipper%>"><input type=hidden name="Shipper" value="<%=Shipper%>">
		<TD><input class=si name="ShipperName" size=40 maxlength=100 value="<%=GetCtmName(JobShipper)%>" onkeydown="ResetEnter()" readonly>
			<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a>
	  <TR height=22>
		<TD>��ی�<TD><input class=si name="CTM_ETC_CODE" size=12 maxlength=10 value="<%=CTM_ETC_CODE%>" onkeydown="ResetEnter()" readonly>
		<TD>���[�ԍ�<TD><input class=si name="CTM_ETC_DATA" size=14 maxlength=20 value="<%=CTM_ETC_DATA%>" onkeydown="ResetEnter()" readonly>
			�S����&nbsp;<select name="JobManager" onkeydown="ResetEnter()" onChange="GetPicInfo()" <%if FinisherID <> 0 then response.write "disabled" %>>
						<%=GetClientManager(JobClient, JobManager)%></select>
	  <TR height=22>
		<TD>�g�єԍ�<TD><input class=si name="PIC_CELL" size=12 maxlength=16 value="<%=PIC_CELL%>" onkeydown="ResetEnter()" readonly>
		<TD colspan=2>
			TEL&nbsp;<input class=si name="PIC_TEL" size=25 maxlength=50 value="<%=PIC_TEL%>" onkeydown="ResetEnter()" readonly>
			FAX&nbsp;<input class=si name="PIC_FAX" size=25 maxlength=50 value="<%=PIC_FAX%>" onkeydown="ResetEnter()" readonly>
	</table>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0>
	�@<tr><td width=50% valign=top>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  <TR><td width=50% class=pt9n>��B/L���&nbsp;
<%if FinisherID = 0 then%>
	<%if JobClient <> "7013A" and JobClient <> "3931" and left(JobCode, 1) = gsSokoInit then%>
		<a class=bar href="javascript:GetJobInfo()">�y�捞�z</a>
	<%else%>
		<%if myJobType = gsExport then %>
			<%if CustomBroker = gsCorpCode then %><a class=bar href="javascript:ShowSoko()">�y�捞�z</a><%end if%>
		<%else%>
			<%if left(JobClient, 4) = "7013" then %><a class=bar href="javascript:ShowCORP()">�yDC�捞�z</a><%end if%>
		<%end if%>
	<%end if%>
<%end if%>
		 	  <td width=50% class=pt9n align=center>�c�ƁF<%=GetEmployName(JobSalesman, "F")%>
		  <TR><td colspan=2><hr width=98% size=1 color=blue>
		</table>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  <TR height=22><TD colspan=2>
		  	POL<input type=hidden name="POLN" value="<%=POLN%>">
		  		<input class=si name="POL" size=11 maxlength=50 value="<%=POL%>" onkeydown="ResetEnter()" readonly>
		  	POD<input type=hidden name="PODN" value="<%=PODN%>">
				<input class=si name="POD" size=11 maxlength=50 value="<%=POD%>" onkeydown="ResetEnter()" readonly>
			<%if myLevel > 0 and FinisherID = 0 then%><a class=bar href="javascript:ShowCountry()">�y�ύX�z</a><%end if%>
		  <TR height=22><TD>VESSEL<TD><input class=si name="Vessel" size=15 maxlength=50 value="<%=Vessel%>" onkeydown="ResetEnter()">
							VOY&nbsp;<input class=si name="Voy" size=8 maxlength=20 value="<%=Voy%>" onkeydown="ResetEnter()">
		  <TR height=22><TD>ETD<TD><input class=si name="ETD" size=10 maxlength=10 value="<%=ETD%>" onkeydown="ResetEnter()" 
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
						�@�@ETA�@<input class=si name="ETA" size=10 maxlength=10 value="<%=ETA%>" onkeydown="ResetEnter()" 
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
		  <TR height=22><TD>�_��<TD><input class=si name="ReferNo" size=15 maxlength=50 value="<%=ReferNo%>" onkeydown="ResetEnter()">
		  				&nbsp;<font class=pt9t>�l��</font><input class=si name="JobNo" size=9 maxlength=10 value="<%=JobNo%>" onkeydown="ResetEnter()">
		  <TR height=22><TD>MB/L<TD><input class=si name="MBL" size=15 maxlength=50 value="<%=MBL%>" onkeydown="ResetEnter()">
		  				&nbsp;���n���&nbsp;<input type=checkbox name="Surrendered" value="1" onkeydown="ResetEnter()" <%if Surrendered then response.write "checked"%>>
		  <TR height=22><TD>HB/L<TD><input class=si name="HBL" size=15 maxlength=50 value="<%=HBL%>" onkeydown="ResetEnter()">
		  				&nbsp;<%if JobClient = "7013" or JobClient = "7013A" then%><a class=bar href="javascript:ShowCorpInfo()">CORP</a><%else%>CORP<%end if%>
		  				<input class=si name="EdaNo" size=10 maxlength=11 value="<%=EdaNo%>" onkeydown="ResetEnter()">
		  <TR height=22><TD>�i��<TD>
			<input class=si name="Commodity" size=32 maxlength=100 value="<%=Commodity%>" onkeydown="ResetEnter()">
		  <TR height=22><TD>INV ��<TD><input class=si name="InvoiceNo" size=32 maxlength=60 value="<%=InvoiceNo%>" onkeydown="ResetEnter()">
		  <TR height=22 class=pt9n><TD>��<TD><input class=sn name="Quantity" value="<%=FitZero(formatnumber(Quantity,3,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">
						�׎p&nbsp;<input class=si name="Package" value="<%=Package%>" size=15 maxlength=20 OnKeyDown="ResetEnter()">
		  <TR height=22><TD class=pt9n>WEIGHT<TD><input class=sn name="GW" value="<%=FitZero(formatnumber(GW,3,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">&nbsp;KGS
					�@	<input class=sn name="RTON" value="<%=RTON%>" size=8 maxlength=10 OnKeyDown="ResetEnter()"> <font class=pt9g>R/TON</font>
		  <TR height=22><TD>MEASURE<TD><input class=sn name="CBM" value="<%=formatnumber(CBM,3,true)%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">&nbsp;M<sup>3</sup>
					�@	<%if myJobType = gsImport then %>(<input class=sn name="SAI" value="<%=GetKGS(GW, CBM)%>" size=10 OnKeyDown="ResetEnter()">KGS)<%end if%>
		  <TR height=22><TD>���Ň�<BR><a href="javascript:DoContainer()"><img src=img/table.JPG border=0 alt="�ڍ�"></a><BR>
		  				<TD><textarea class=sz name="Container" rows=4 style="width:190"><%=Container%></textarea>
		  <TR height=22><TD>�}�[�N<BR><BR><TD><textarea class=sz name="Marks" rows=4 style="width:190"><%=Marks%></textarea>
		</table>
	  <td width=50% valign=top>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  <TR><td width=50% class=pt9n>���ʊ֏��&nbsp;
		 	  <td width=50% class=pt9n align=center>�Ɩ��F<%=GetEmployName(JobOperator, "F")%>
		  <TR><td colspan=2><hr width=98% size=1 color=blue>
		</table>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  <TR height=22><TD width=60>�D���<TD colspan=2><input class=si name="ShipCorp" size=30 maxlength=50 value="<%=ShipCorp%>" onkeydown="ResetEnter()">
		  <TR height=22><TD>�A����<TD colspan=2><input class=si name="ShipPic" size=30 maxlength=50 value="<%=ShipPic%>" onkeydown="ResetEnter()">
<%if myJobType = gsImport then %>
		  <TR height=22><TD>�[�i��]<TD><input class=si name="RequireDate" size=10 maxlength=10 value="<%=RequireDate%>" onkeydown="ResetEnter()" 
		  								<%if FinisherID <> 0 then%>onclick="setday(this)"<%end if%>>
<%else%>
		  <TR height=22><TD class=pt9t>��ƌ`��<TD>	<select name="JobType" class=pt9n onkeydown="ResetEnter()" <%if FinisherID <> 0 then response.write "disabled" %>>
		  	<%for i = 1 to ubound(expType)%><option value="<%=expType(i)%>" <%if JobType = expType(i) then response.write "selected"%>><%=expType(i)%><%next%></select>
<%end if%>
		  				<TD align=center><select name="JobService" class=pt9n onkeydown="ResetEnter()" <%if FinisherID <> 0 then response.write "disabled" %>>
		  	<%for i = 1 to ubound(expService)%><option value="<%=expService(i)%>" <%if JobService = expService(i) then response.write "selected"%>><%=expService(i)%><%next%></select>
		  <TR height=22><TD class=pt9t>�ʊ֋Ǝ�<TD colspan=2>
		  			<select name="CustomBroker" class=pt9n onkeydown="ResetEnter()" <%if FinisherID <> 0 then response.write "disabled" %>>
		  							<%=ShowBrokerList(CustomBroker)%></select>
			  		<%for i = 1 to 3%><input type=checkbox name="Inspection<%=i%>" value="1" onkeydown="ResetEnter()" 
			  		<%if mid(Inspection, i, 1) = "1" then response.write "checked"%>><%=left(ctmInspect(i), 1)%><%next%>
		  		
		  <TR height=22 class=pt9g>
		  				<TD>�\������<TD colspan=2><input class=si name="CustomDate" size=10 value="<%=CustomDate & " " & CustomTime%>" onkeydown="ResetEnter()" readonly>
		  				<%if CustomBroker = gsCorpCode %>�敪 [<%if CustomType = 0 then%>-<%else%><font class=pt9r><%=CustomType%></font><%end if%>]<%else
		  				%><select name="CustomType" onkeydown="ResetEnter()"><%for i = 0 to 5%><option value="<%=i%>" <%if CustomType = i then response.write "selected"%>><%=i%><%next%></select>
		  					<input class=sn name="Sheet1" size=2 maxlength=2 value="<%=GetLong(left(CustomSheet, 2))%> " onkeydown="ResetEnter()" 
		  						<%if CustomBroker = gsCorpCode then response.write "readonly"%>>��
		  					<input class=sn name="Sheet2" size=2 maxlength=2 value="<%=GetLong(right(CustomSheet, 2))%> " onkeydown="ResetEnter()" 
		  						<%if CustomBroker = gsCorpCode then response.write "readonly"%>>��
		  <TR height=22><TD>������<a href="javascript:DoPlace(1)"><img src=img/search.jpg border=0 alt="����"></a>
		  				<TD colspan=2><input class=sz name="CarryPlace" value="<%=CarryPlace%>" size=30 maxlength=100 OnKeyDown="ResetEnter()"></sup>
		  <TR height=22><TD>������<TD><input class=si name="CarryDate" size=10 maxlength=10 value="<%=CarryDate%>" onkeydown="ResetEnter()"  
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
		  				<TD nowrap><%for i = 4 to 6%><input type=checkbox name="Inspection<%=i%>" value="1" onkeydown="ResetEnter()" 
		  								<%if mid(Inspection, i, 1) = "1" then response.write "checked"%>><%=right(ctmInspect(i), 2)%><%next%>
		  <TR height=22><TD>FreeTime<TD><input class=si name="FreeTime" size=10 maxlength=10 value="<%=FreeTime%>" onkeydown="ResetEnter()"  
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
		  				<TD nowrap><%for i = 7 to 9%><input type=checkbox name="Inspection<%=i%>" value="1" onkeydown="ResetEnter()" 
		  								<%if mid(Inspection, i, 1) = "1" then response.write "checked"%>><%=right(ctmInspect(i), 2)%><%next%>
		  <TR height=22><TD>����<TD><input class=si name="PermitDate" size=10 maxlength=10 value="<%=PermitDate%>" onkeydown="ResetEnter()"  
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
						<TD nowrap>������<input class=si name="PermitNo" size=11 maxlength=50 value="<%=PermitNo%>" onkeydown="ResetEnter()">
		  <TR height=22><TD nowrap>�o�R�n<a href="javascript:DoPlace(2)"><img src=img/search.jpg border=0 alt="����"></a>
		  				<TD colspan=2><input class=sz name="ViaPlace" value="<%=ViaPlace%>" size=30 maxlength=100 OnKeyDown="ResetEnter()"></sup>
		  <TR height=22><TD>��Ɗ���<TD><input class=si name="DeliveryDate" size=10 maxlength=10 value="<%=DeliveryDate%>" onkeydown="ResetEnter()"  
		  								<%if FinisherID = 0 then%>onclick="setday(this)"<%end if%>>
<%if myLevel < 3 and CheckTopLevel() = 0 then %>
						<TD class=pt9g>�@�ԋp��<input class=si name="ReturnDate" size=10 maxlength=10 value="<%=ReturnDate%>" Disabled>
<%else%>
						<TD class=pt9r>�@�����<input class=si name="SalesDate" size=10 maxlength=10 value="<%=SalesDate%>" onkeydown="ResetEnter()">
<%end if%>
		  <TR height=22><TD>�ʊ֔��l<BR>(SI��)<BR><TD colspan=2><textarea class=sz name="CustomRemark" rows=4 style="width:200"><%=CustomRemark%></textarea>
		  <TR height=22><TD>�Ɩ�����<BR><BR><TD colspan=2><textarea class=sz name="Remarks" rows=4 style="width:200"><%=Remarks%></textarea>
		</table>
	</table>		
  </FORM>
  <IFRAME name=frameView FRAMEBORDER=0 scrolling=auto SRC="DeliveryList.asp?JobCode=<%=JobCode%>" height=300 width=100%></IFRAME>
<center>
<SCRIPT language=Javascript>GetPicInfo();</SCRIPT>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
end if
%>

<%
function GetInitJobType(myPOL)
	select case myPOL
	case "KOBE":		GetInitJobType = expType(1)
	case "OSAKA":		GetInitJobType = expType(12)
	case "NAGOYA":		GetInitJobType = expType(13)
	case "YOKOHAMA":	GetInitJobType = expType(14)
	case "TOKYO":		GetInitJobType = expType(15)
	case "SHIMONOSEKI":	GetInitJobType = expType(16)
	case else:			GetInitJobType = expType(17)
	end select
end function

function GetClientManager(myCD, myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT PIC_ID, PIC_NAME, PIC_DFT FROM CTM_PIC WHERE PIC_DELETED = 0 AND CTM_CD = '" & myCD & "'"
	mySql = mySql & " ORDER BY PIC_DFT DESC, PIC_NAME"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if myRec.eof then
		buf = buf & "<option value=0>���ݒ�"
	else
		do while not myRec.eof
			buf = buf & "<option value=" & myRec.fields("PIC_ID")
			if GetLong(myDft) = GetLong(myRec.fields("PIC_ID")) then buf = buf & " selected"
			buf = buf & ">" & StringCutRev(myRec.fields("PIC_NAME"), 8)
			myRec.movenext
		loop
	end if
	myRec.close
	set myRec = nothing	
	
	GetClientManager = buf	
end function

function ShowBrokerList(myDft)
dim mySql
dim myRec
dim buf
	
	set myRec = Server.CreateObject ("ADODB.Recordset")	
	mySql = "SELECT CTM_CD, CTM_REF FROM CUSTOMER WHERE CTM_CUSTOM = 1 ORDER BY CTM_REF"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CTM_CD")
		if myDft = myRec.fields("CTM_CD") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("CTM_REF")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowBrokerList = buf
end function
%>

