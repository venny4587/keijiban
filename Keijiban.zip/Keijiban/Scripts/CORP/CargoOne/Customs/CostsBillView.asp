<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next
dim JobSeq
dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(15)
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		CostsFinish = 0
		'DateFrom = formatDate(dateadd("m", -1, date))
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		PayDayFrom = GetPost(request("PayDayFrom"))
		PayDayTo = GetPost(request("PayDayTo"))
		AmntFrom = GetPost(request("AmntFrom"))
		AmntTo = GetPost(request("AmntTo"))
		if AmntFrom <> "" then AmntFrom = GetDouble(AmntFrom)
		if AmntTo <> "" then AmntTo = GetDouble(AmntTo)
		CostsBatch = GetPost(request("CostsBatch"))
		CostsNo = GetPost(request("CostsNo"))
		CostsBillNo = GetPost(request("CostsBillNo"))
		CostsFinish = GetLong(request("CostsFinish"))
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�x���`�[�������</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "ClientRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=2&JobCode=" & myJob & "&CostsNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
				
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
		
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub PayDayFrom_OnBlur()
			frmInput.PayDayFrom.value = setdate(frmInput.PayDayFrom.value)
		end sub
		sub PayDayTo_OnBlur()
			frmInput.PayDayTo.value = setdate(frmInput.PayDayTo.value)
		end sub
		sub AmntFrom_OnBlur()
			if frmInput.AmntFrom.value = "" then exit sub
			frmInput.AmntFrom.value = GetDouble(frmInput.AmntFrom.value)
		end sub
		sub AmntTo_OnBlur()
			if frmInput.AmntTo.value = "" then exit sub
			frmInput.AmntTo.value = GetDouble(frmInput.AmntTo.value)
		end sub
		sub CostsBatch_OnBlur()
			frmInput.CostsBatch.value = FitBatchNo(frmInput.CostsBatch.value)
		end sub
		sub CostsNo_OnBlur()
			frmInput.CostsNo.value = FitCostsNo(frmInput.CostsNo.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CostsBillView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�퐿����<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				�x����<input class=si name="PayDayFrom" value="<%=PayDayFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="PayDayTo" value="<%=PayDayTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				�x���z<input class=sn name="AmntFrom" value="<%=AmntFrom%>" maxlength=8 size=7 onkeydown="ResetEnter()">
					�`<input class=sn name="AmntTo" value="<%=AmntTo%>" maxlength=8 size=7 onkeydown="ResetEnter()">
			<TR><TD nowrap>
				�ޯ��� <input class=sn name="CostsBatch" value="<%=CostsBatch%>" maxlength=6 size=6 onkeydown="ResetEnter()">
				�`�[�ԍ�<input class=si name="CostsNo" value="<%=CostsNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				���臂<input class=si name="CostsBillNo" value="<%=CostsBillNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�x����<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="CostsFinish" value="1" <%if CostsFinish then response.write " checked"%>>
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if ClientRef <> "" then	strSel = strSel & " AND (ClientRef = '" & FitSel(ClientRef) & "' OR CostsClientName LIKE '% " & FitSel(ClientRef) & "%')"
	if DateFrom <> "" then strSel = strSel & " AND CostsDate >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND CostsDate <= '" & Date2Str(DateTo) & "'"	
	if PayDayFrom <> "" then strSel = strSel & " AND CostsPayDay >= '" & Date2Str(PayDayFrom) & "'"
	if PayDayTo <> "" then strSel = strSel & " AND CostsPayDay <= '" & Date2Str(PayDayTo) & "'"	
	if AmntFrom <> "" then strSel = strSel & " AND (CostsAmount + CostsTax) >= " & AmntFrom
	if AmntTo <> "" then strSel = strSel & " AND (CostsAmount + CostsTax) <= " & AmntTo
	if CostsBillNo <> "" then strSel = strSel & " AND CostsBillNo LIKE '%" & FitSel(CostsBillNo) & "%'"	
	if CostsBatch <> "" then strSel = strSel & " AND CostsBatch = '" & FitSel(CostsBatch) & "'"
	if CostsNo <> "" then strSel = strSel & " AND CostsNo = '" & FitSel(CostsNo) & "'"	
	if CostsFinish = 0 then strSel = strSel & " AND FinisherID = 0"
	
	ttlAmount = 0	
	with recset
		strSql = "SELECT SUM(CAST(CostsAmount + CostsTax AS float)) AS CostsTotal FROM TBL_CTM_Costs AS T INNER JOIN "
		strSql = strSql & " (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit
		strSql = strSql & "' ELSE JobBelong END AS JobBelong FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0"		'���폜�@�m���
'		if CheckTopLevel() = 0 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		if strSel <> "" then strSQL = strSQL & strSel
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then ttlAmount = GetDouble(.Fields("CostsTotal"))
		.close
		
		strSql = "SELECT JobCode, CostsNo, CostsType, ClientRef, CostsClientName, CostsBillNo, ConfirmDate, FinisherID, FinishDate"
		strSql = strSql & ", CostsDate, CostsAmount, CostsTax, CostsPayDay, CostsCheck, JobBelong FROM TBL_CTM_Costs AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit
		strSql = strSql & "' ELSE JobBelong END AS JobBelong FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0"		'���폜�@�m���
'		if CheckTopLevel() = 0 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		if strSel <> "" then strSQL = strSQL & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY CostsNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, CostsNo"
		case 2:		strSql = strSql & " ORDER BY CostsDate, CostsNo"
		case 3:		strSql = strSql & " ORDER BY CostsPayDay, CostsNo"
		case 4:		strSql = strSql & " ORDER BY CostsBillNo, CostsNo"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			.PageSize = myPageSize
			lngPageCount = .PageCount
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr>
				<td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%></td>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
				</td>
			</TR>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup span=5 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=2 align=center>
		  <TR align=center height=26 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�`�[�ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">���臂
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">����
			<TD class=line nowrap>�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x����
			<TD class=line nowrap>�x�����z
			<TD class=line colspan=2 align=left>�x��
<%
			cnt = 0
			Do Until .EOF
				lngCount = lngCount + 1
				JobCode = GetString(.Fields("JobCode"))	
				CostsNo = GetString(.Fields("CostsNo"))			
				BillNo = GetString(.Fields("CostsBillNo"))		
				If lngCount > lngPageNumber * myPageSize Then
					Exit Do
				Else
					cnt = cnt + 1
					myAmount = GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax"))
					if GetLong(.fields("FinisherID")) = 0 then
						msg = "�����F" & GetEmployName(GetLong(.Fields("FinisherID")), "F") & " (" & ShowDateTimeShort(.Fields("FinishDate")) & ")"
						status = "<font color=gray>��</font>"
					else
						msg = ""
						status = "<font color=black>��</font>"
					end if
%>
		<TR align=center height=26>
			<TD class=line><%=lngCount%><BR>
			<TD class=line><%=replace(ShowCostsType(.Fields("CostsType")),"��","")%><BR>
			<TD class=line><%=ShowVoucherNo(.Fields("CostsNo"))%><BR>
			<TD class=line><%=ShowJobCode(JobCode)%><BR>
			<TD class=line <%=ShowTitle(BillNo, 10)%>><%=StringCutRev(BillNo,10)%><BR>
			<TD class=line><%=Str2MD(.Fields("CostsDate"))%><BR>
			<TD class=line nowrap title="<%=GetString(.Fields("CostsClientName"))%>"><%=GetString(.Fields("ClientRef"))%><BR>
			<TD class=line><%=Str2MD(.Fields("CostsPayDay"))%><BR>
			<TD class=line nowrap><%=formatnumber(myAmount, 0, true)%><BR>
			<TD class=line title="<%=msg%>"><%=status%><BR>
			<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=JobCode%>', '<%=CostsNo%>')">
<%
				end if
				.movenext
			loop
			if lngCount > 1 then
%>			
		<TR height=20>
			<TD colspan=6 class=pt9r align=left><%if lngCount > lngPageNumber * myPageSize then response.write "��������܂�..."%>
			<TD class=line align=right>�����v
			<TD class=line align=right colspan=2><%=formatnumber(ttlAmount, 0, true)%>
		
<%
			end if
%>
		</TABLE>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>