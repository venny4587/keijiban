<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�x���`�[���ו�������
'----------------------------------------------

	JobCode = GetPost(request("JobCode"))
	SeqNo = GetLong(request("SeqNo"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")	
	
	
	Conn.BeginTrans
	
	strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
	Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
	if not Recset.eof then
		CostsNo = GetString(Recset.fields("ExpensePay"))
		
		'�����쐬
		Set cmdSQL = Server.CreateObject("ADODB.Command")
		Set cmdSQL.ActiveConnection = Conn
		cmdSQL.CommandType = 4
		cmdSQL.CommandText = "DB_CTM_NEW_SUB"
		cmdSQL.Parameters.Refresh
		cmdSQL.Parameters("@SubCode").Value = "Expense"
		cmdSQL.Execute
		SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
		
		set Rec = Server.CreateObject("adodb.recordset")	
		with Rec
			strSql = "SELECT * FROM TBL_CTM_EXPENSE"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			.AddNew
			.fields("JobCode") = JobCode
			.fields("SeqNo") = SeqNo
			
			.fields("ExpenseClient") = Recset.fields("ExpenseClient")
			.fields("ExpenseType") = Recset.fields("ExpenseType")
			.fields("ExpenseAttr") = Recset.fields("ExpenseAttr")
			.fields("ExpenseDate") = Recset.fields("ExpenseDate")
			.fields("ExpenseBill") = Recset.fields("ExpenseBill")
			.fields("ExpensePay") = Recset.fields("ExpensePay")
			.fields("ConfirmerID") = Recset.fields("ConfirmerID")
			.fields("ConfirmDate") = Recset.fields("ConfirmDate")
			
			.fields("ExpenseCost") = GetLong(request("ExpenseCost"))
			.fields("ExpensePrice") = GetDouble(request("ExpensePrice"))
			.fields("ExpenseQuantity") = GetDouble(request("ExpenseQuantity"))
			.fields("ExpenseUnit") = GetPost(request("ExpenseUnit"))
			.fields("ExpenseAmount") = GetLong(request("ExpenseAmount"))
			.fields("ExpenseTaxName") = GetPost(request("ExpenseTaxName"))
			.fields("ExpenseTax") = GetLong(request("ExpenseTax"))
			.fields("ExpenseMemo") = GetPost(request("ExpenseMemo"))
			.fields("Remarks") = GetPost(request("Remarks"))
			
			.fields("Creater") = WebUserID
			.fields("Created") = now
			.fields("Updater") = WebUserID
			.fields("Updated") = now
			.fields("Deleted") = 0
			.update
			.close
		end with
		set Rec = nothing
		
		'�������X�V
		Recset.fields("ExpenseAmount") = Recset.fields("ExpenseAmount") - GetLong(request("ExpenseAmount"))
		Recset.fields("ExpenseTax") = Recset.fields("ExpenseTax") - GetLong(request("ExpenseTax"))
		if GetDouble(Recset.fields("ExpenseQuantity")) <> 0 then
			Recset.fields("ExpensePrice") = GetDouble(Recset.fields("ExpenseAmount")) / GetDouble(Recset.fields("ExpenseQuantity"))
		else
			Recset.fields("ExpensePrice") = Recset.fields("ExpenseAmount") 
		end if
		Recset.fields("Updater") = WebUserID
		Recset.fields("Updated") = now
		Recset.update
		Recset.Close
	end if
	
	if err.number = 0 then 
	
		Conn.CommitTrans
%>
<html>
	<script language=javascript>
		window.opener.parent.parent.location.href = "mainframe.asp?mode=2&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
		window.close();
	</script>
</html>
<%
	else
	
		Conn.RollbackTrans
		ShowMessage "�������������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
		
	end if
	
	set Recset = nothing
	CloseDB Conn
%>