<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	myType = GetLong(request("Type"))			'0:���� 1:���� 2:���� 3:�ې�
	JobCode = GetPost(request("JobCode"))
	CostsNo = GetPost(request("CostsNo"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	
if JobCode <> "" and CostsNo <> "" then
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
	
	myMode = GetLong(request("mode"))
	if myMode <> 0 then
		JobSeq = GetPost(request("JobSeq"))
		SeqNo = GetLong(request("SeqNo"))
		if JobSeq <> "" and SeqNo <> 0 then
			sum = 0:		tax = 0
			qty = 0:		prc = 0:		unit = ""
			Conn.BeginTrans
			with Recset
				strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND SeqNo IN (" & JobSeq & ") OR SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
				do while not .eof
					sum = sum + GetLong(.fields("ExpenseAmount"))
					tax = tax + GetLong(.fields("ExpenseTax"))
					if SeqNo = GetLong(.fields("SeqNo")) then 
						qty = GetDouble(.fields("ExpenseQuantity"))
						prc = GetDouble(.fields("ExpensePrice"))
						unit = GetLong(.fields("ExpenseUnit"))
					end if
					.fields("Deleted") = 1
					.fields("Updater") = WebUserID
					.fields("Updated") = now
					.update
					.MoveNext
				loop
			end with
			select case unit
			case "US$"
				if prc <> 0 then qty = clng(sum * 100 / prc) / 100
			case else
				if qty <> 0 then prc = clng(sum * 100 / qty) / 100
			end select
			strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 0"
			strSql = strSql & ", ExpensePrice = " & prc
			strSql = strSql & ", ExpenseQuantity = " & qty
			strSql = strSql & ", ExpenseAmount = " & sum
			strSql = strSql & ", ExpenseTax = " & tax
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Updated = GETDATE()"
			strSql = strSql & " WHERE SeqNo = " & SeqNo
			Conn.Execute strSql
			
			if err.number = 0 then 
				Conn.CommitTrans
%>
<html>
	<script language=javascript>
<%if myType = 2 then%>
		window.parent.parent.location.href = "mainframe.asp?mode=2&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
<%else%>
		window.location.href = "CostsList.asp?type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
<%end if%>
		window.close();
	</script>
</html>
<%

			else
				Conn.RollbackTrans
				ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
			end if
		end if
	else
%>
<HTML>
<HEAD>
	<TITLE>�x���`�[���׏Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "JobSeq" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�������閼�ڂ�I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("�f�[�^���������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.submit()
		end function
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsCostsBackColor%>" topmargin=3 leftmargin=5 <%=gsBodyControl%>>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=30%>
	  		��<%if myType = 0 then%>����<%elseif myType = 1 then%>����<%else%>�x��<%end if%>�`�[����&nbsp;
	  	<td width=60% class=pt9 valign=bottom>
	  		�䒠�ԍ��F<font class=pt9b><%=JobCode%></font>
	  		�`�[�ԍ��F<font class=pt9n><%=CostsNo%></font>
	  	<td width=10% align=right>
<%	if ConfirmerID <> 0 then %>
<%		if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�x���ς�<%=GetEraseInfo(CostsNo, 1)%>">
<%		else %>
 		  <img style="cursor:help" src=img/security.gif alt="�m�F�ҁF<%=GetEmployName(ConfirmerID, "F") & " (" & ShowDateTimeShort(ConfirmDate) & ")"%>">
<%		end if %>
<%	end if %>
	</table>
	<hr size=1 color=green><%=JobHeader%><br>
	<form name=frmInput action="CostsCombine.asp" method="post">
		<input type=hidden name="mode" value="1">
		<input type=hidden name="Type" value="<%=myType%>">
		<input type=hidden name="JobCode" value="<%=JobCode%>">
		<input type=hidden name="CostsNo" value="<%=CostsNo%>">
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		  <TR align=center height=20 class=pt9>
			<TD class=line nowrap>�I��
			<TD class=line nowrap>�x������
			<TD class=line nowrap>���ڔ��l
			<TD class=line nowrap>�P��
			<TD class=line nowrap>����
			<TD class=line nowrap>�P��
			<TD class=line nowrap>�����
			<TD class=line nowrap>�Ŕ����z
			<TD class=line nowrap>������
<%
	with recset
		strSql = "SELECT SeqNo, ExpenseType, ExpenseAttr, ExpenseCost, COST_ID, COST_CD, COST_NAME, ExpenseTaxName"
		strSql = strSql & ",ExpenseQuantity, ExpenseUnit, ExpensePrice, ExpenseAmount, ExpenseTax, ExpenseMemo"
		strSql = strSql & " FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpensePay = '" & CostsNo & "'"
		strSql = strSql & " AND ExpenseType = " & gsStand & " ORDER BY COST_CD, SeqNo"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		do while not .eof
			cnt = cnt + 1
			CostName = GetString(.Fields("COST_NAME"))
			myMemo = GetString(.Fields("ExpenseMemo"))
			
%>
		<TR align=right height=20>
			<TD class=line align=center><input type=checkbox name="JobSeq" value="<%=GetLong(.Fields("SeqNo"))%>">
<%if GetLong(.Fields("COST_ID")) = 123 then %>
			<TD class=line nowrap align=left colspan=5><%=StringCut(myMemo,25)%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, false)%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, false)%><BR>
<%else%>
<%	if GetLong(.Fields("COST_ID")) <> 113 then %>
			<TD class=line nowrap align=left <%=ShowTitle(CostName, 10)%>><%=StringCut(CostName,10)%><BR>
			<TD class=line nowrap align=left <%=ShowTitle(myMemo, 8)%>><%=StringCut(myMemo,8)%><BR>
<%	else %>
			<TD class=line nowrap align=left colspan=2 <%=ShowTitle(myMemo, 16)%>><%=StringCut(myMemo,16)%><BR>
<%	end if %>
			<TD class=line nowrap><%=FitZero(formatnumber(GetDouble(.Fields("ExpensePrice")), 2, true))%><BR>
			<TD class=line nowrap><%=GetDouble(.Fields("ExpenseQuantity"))%><BR>
			<TD class=line nowrap align=center><%=GetString(.Fields("ExpenseUnit"))%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, true)%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%><BR>
			<TD class=line align=center><input type=radio name="SeqNo" value="<%=GetLong(.Fields("SeqNo"))%>" <%if cnt = 1 then response.write "checked"%>>
<%end if
			.movenext
		loop
	end with
%>
		</TABLE>
		<div align=right><br>
			<INPUT style="width:90px;height:30px;" TYPE=button VALUE="���s" onclick="DoConfirm()">
		</div>
	</form>
</BODY>
</HTML>
<% 
	end if
end if
	
set recset = nothing
CloseDB Conn
%>
