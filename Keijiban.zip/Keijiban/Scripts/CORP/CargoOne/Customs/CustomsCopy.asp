<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
dim JobCode
dim JobType

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobCode = GetPost(request("JobCode"))
	JobDiv = CheckJobType(JobCode)
	mode = GetLong(request("mode"))
	if mode = 0 then		
		with Recset		
			strSQL = "SELECT * FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if not .eof then
				JobBelong = GetString(.fields("JobBelong"))
				JobClient = GetString(.fields("JobClient"))
				JobShipper = GetString(.fields("JobShipper"))
				JobService = GetString(.fields("JobService"))
				JobType = GetString(.fields("JobType"))
				JobBroker = GetString(.fields("CustomBroker"))	
				
				JobCountry = GetString(.fields("JobCountry"))
				Vessel = GetString(.fields("Vessel"))
				Voy = GetString(.fields("Voy"))
				POL = GetString(.fields("POL"))
				POD = GetString(.fields("POD"))
				POLN = GetString(.fields("POLN"))
				PODN = GetString(.fields("PODN"))
				ETD = Str2Date(.fields("ETD"))
				ETA = Str2Date(.fields("ETA"))				
				ShipCorp = GetString(.fields("ShipCorp"))
				ShipPic = GetString(.fields("ShipPic"))		
			else
				msg = "�Y���f�[�^��������܂���ł����B"
			end if
		end with
		
		if msg <> "" then 
			ShowMessage msg
		else
%>
<html>
<HEAD>
	<TITLE>�䒠�ԍ��R�s�[����</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub Client_OnChange()
			frmInput.Client.value = ucase(frmInput.Client.value)
			frmInput.JobClient.value = ""			
			frmInput.EName.value = ""
			frmInput.JobManager.value = ""
						
			frmInput.Shipper.value = ""
			frmInput.JobShipper.value = ""
			frmInput.ShipperName.value = ""			
		end sub
		
		sub Shipper_OnChange()	
			frmInput.Shipper.value = ucase(frmInput.Shipper.value)
			frmInput.JobShipper.value = ""
			frmInput.ShipperName.value = ""
		end sub
		
		sub DoSearch(mode)
			dim win, param
			if mode = 0 then
				param = "?mode=0&cd=" & frmInput.Client.value
				set win = window.open("ClientSearch.asp" & param,"ClientSearch","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
			else
				param = "?mode=1&cd=" & frmInput.Shipper.value
				set win = window.open("ClientSearch.asp" & param,"ClientSearch","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
			end if
			win.focus()
		end sub
		
		sub DataSave()
			if msgbox ("�R�s�[���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
		
		sub InitForm()
			frmInput.CopyCount.focus()
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CustomsCopy.asp" method="post">
  	<input type=hidden name="mode" value="1">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="JobManager" value="<%=JobManager%>">
	<input type=hidden name="JobCountry" value="<%=JobCountry%>">
	<input type=hidden name="POLN" value="<%=POLN%>">
	<input type=hidden name="PODN" value="<%=PODN%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=100%>���䒠�ԍ��R�s�[���s&nbsp;
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
	  <TR height=24>
	  	<TD>POL <input class=si name="POL" size=12 maxlength=50 value="<%=POL%>" onkeydown="ResetEnter()" readonly>
			POD <input class=si name="POD" size=12 maxlength=50 value="<%=POD%>" onkeydown="ResetEnter()" readonly>
		�@�@ETD <input class=si name="ETD" size=10 maxlength=10 value="<%=ETD%>" onkeydown="ResetEnter()" readonly>
			ETA <input class=si name="ETA" size=10 maxlength=10 value="<%=ETA%>" onkeydown="ResetEnter()" readonly>
	  <TR height=24>
		<TD>VESSEL <input class=si name="Vessel" size=20 maxlength=50 value="<%=Vessel%>" onkeydown="ResetEnter()" readonly>
			VOY <input class=si name="Voy" size=10 maxlength=20 value="<%=Voy%>" onkeydown="ResetEnter()" readonly>
		�@�@��ƌ`�� <input class=si name="JobType" size=10 maxlength=20 value="<%=JobType%>" onkeydown="ResetEnter()" readonly>
	  <TR height=24>
		<TD>�D��� <input class=si name="ShipCorp" size=20 maxlength=50 value="<%=ShipCorp%>" onkeydown="ResetEnter()" readonly>
			�A���� <input class=si name="ShipPic" size=16 maxlength=50 value="<%=ShipPic%>" onkeydown="ResetEnter()" readonly>
		�@�@(<input class=si name="JobService" size=7 maxlength=50 value="<%=JobService%>" onkeydown="ResetEnter()" >)
	</table>
	<br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
	  <TR height=24>
		<TD class=pt9n nowrap>�����׎� <input type=hidden name="JobClient" value="<%=JobClient%>">
			<input class=si name="Client" size=8 maxlength=10 value="<%=GetRefName(JobClient)%>" onkeydown="ResetEnter()">
			<a href="javascript:DoSearch(0)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="EName" value="<%=GetFullName(JobClient)%>" size=45 onkeydown="ResetEnter()" readonly>
	  <TR height=24>
		<TD class=pt9n nowrap>B/L �׎� <input type=hidden name="JobShipper" value="<%=JobShipper%>">
			<input class=si name="Shipper" size=8 maxlength=10 value="<%=GetRefName(JobShipper)%>" onkeydown="ResetEnter()">
			<a href="javascript:DoSearch(1)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="ShipperName" value="<%=GetCtmName(JobShipper)%>" size=45 onkeydown="ResetEnter()" readonly>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD>�ʊ֋Ǝ� <input type=hidden name="JobBroker" value="<%=JobBroker%>">
					<input class=si name="CustomBroker" value="<%=GetFullName(JobBroker)%>" onkeydown="ResetEnter()" size=30 readonly>
			�R�s�[�� <select name="CopyCount" onkeydown="ResetEnter()"><%for i = 1 to 9%><option value="<%=i%>"><%=i%><%next%></select>
			�Ɩ� <select name="JobDivision" onkeydown="ResetEnter()"><option value="<%=JobDiv%>" selected><%=GetJobDivision(JobDiv)%><%if JobDiv = gsImport or JobDiv = gsExport then%><option value="<%=gsOther%>"><%=GetJobDivision(gsOther)%><%end if%></select>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=40>
		<TD class=pt9r>
			<input type=checkbox name="CopyAll" value="1">S/I�S�R�s�[�@
			<input class=pt9n type=button style="width:100;height:30" name=btnCreate value="F9:���s" onclick="DataSave()">�@�@
			<input class=pt9n type=button style="width:100;height:30" name=btnClose value="����" onclick="window.close()">
	</table>
  </FORM>
<center>
</body></html>
<%
		end if
		
	else
	
		JobClient = GetPost(request("JobClient"))
		JobShipper = GetPost(request("JobShipper"))
		JobService = GetPost(request("JobService"))
		JobType = GetPost(request("JobType"))
		JobBroker = GetPost(request("JobBroker"))
		
		JobDivision = GetPost(request("JobDivision"))
		JobCountry = GetPost(request("JobCountry"))
		Vessel = GetPost(request("Vessel"))
		Voy = GetPost(request("Voy"))
		POL = GetPost(request("POL"))
		POD = GetPost(request("POD"))
		POLN = GetPost(request("POLN"))
		PODN = GetPost(request("PODN"))
		ETD = Date2Str(request("ETD"))
		ETA = Date2Str(request("ETA"))
		
		ShipCorp = GetPost(request("ShipCorp"))
		ShipPic = GetPost(request("ShipPic"))	
		CopyCount = GetLong(request("CopyCount"))
		
		msg = ""		
		with Recset		
			strSQL = "SELECT CTM_BELONG, CTM_SALESMNGR FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_CD = '" & JobClient & "'"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if not .eof then
				JobBelong = GetString(.fields("CTM_BELONG"))	
				JobSalesman = GetLong(.fields("CTM_SALESMNGR"))			
			else
				msg = "�Y���׎傪������܂���ł����B"
			end if
			.Close
		end with
	
		if msg <> "" then 
			ShowMessage msg
		else

			strFld = "":						strVal = ""
			strFld = strFld & ",JobBelong":		strVal = strVal & ",'" & JobBelong & "'"
			strFld = strFld & ",JobClient":		strVal = strVal & ",'" & FitSel(JobClient) & "'"
			strFld = strFld & ",JobShipper":	strVal = strVal & ",'" & FitSel(JobShipper) & "'"
			strFld = strFld & ",JobService":	strVal = strVal & ",'" & FitSel(JobService) & "'"
			strFld = strFld & ",JobType":		strVal = strVal & ",'" & FitSel(JobType) & "'"
			strFld = strFld & ",JobCountry":	strVal = strVal & ",'" & FitSel(JobCountry) & "'"
			strFld = strFld & ",POL":			strVal = strVal & ",'" & FitSel(POL) & "'"
			strFld = strFld & ",POLN":			strVal = strVal & ",'" & FitSel(POLN) & "'"
			strFld = strFld & ",POD":			strVal = strVal & ",'" & FitSel(POD) & "'"
			strFld = strFld & ",PODN":			strVal = strVal & ",'" & FitSel(PODN) & "'"
			strFld = strFld & ",Vessel":		strVal = strVal & ",'" & FitSel(Vessel) & "'"
			strFld = strFld & ",Voy":			strVal = strVal & ",'" & FitSel(Voy) & "'"
			strFld = strFld & ",ETD":			strVal = strVal & ",'" & FitSel(ETD) & "'"
			strFld = strFld & ",ETA":			strVal = strVal & ",'" & FitSel(ETA) & "'"
			strFld = strFld & ",ShipCorp":		strVal = strVal & ",'" & FitSel(ShipCorp) & "'"
			strFld = strFld & ",ShipPic":		strVal = strVal & ",'" & FitSel(ShipPic) & "'"
			strFld = strFld & ",CustomBroker":	strVal = strVal & ",'" & FitSel(JobBroker) & "'"
			strFld = strFld & ",JobSalesman":	strVal = strVal & "," & GetLong(JobSalesman)
			
			if GetLong(request("CopyAll")) <> 0 then
				with Recset		
					strSQL = "SELECT * FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
					if not .eof then
						strFld = strFld & ",MBL":			strVal = strVal & ",'" & FitSel(.fields("MBL")) & "'"
						strFld = strFld & ",HBL":			strVal = strVal & ",'" & FitSel(.fields("HBL")) & "'"
						strFld = strFld & ",Commodity":		strVal = strVal & ",'" & FitSel(.fields("Commodity")) & "'"
						strFld = strFld & ",Quantity":		strVal = strVal & "," & GetDouble(.fields("Quantity"))
						strFld = strFld & ",Package":		strVal = strVal & ",'" & FitSel(.fields("Package")) & "'"
						strFld = strFld & ",GW":			strVal = strVal & "," & GetDouble(.fields("GW"))
						strFld = strFld & ",CBM":			strVal = strVal & "," & GetDouble(.fields("CBM"))
						strFld = strFld & ",RTON":			strVal = strVal & "," & GetDouble(.fields("RTON"))
						strFld = strFld & ",Marks":			strVal = strVal & ",'" & FitSel(.fields("Marks")) & "'"
						strFld = strFld & ",Container":		strVal = strVal & ",'" & FitSel(.fields("Container")) & "'"
						strFld = strFld & ",InvoiceNo":		strVal = strVal & ",'" & FitSel(.fields("InvoiceNo")) & "'"
						strFld = strFld & ",ReferNo":		strVal = strVal & ",'" & FitSel(.fields("ReferNo")) & "'"			
						strFld = strFld & ",JobNo":			strVal = strVal & ",'" & FitSel(.fields("JobNo")) & "'"
						strFld = strFld & ",EdaNo":			strVal = strVal & ",'" & FitSel(.fields("EdaNo")) & "'"
						
						strFld = strFld & ",JobManager":	strVal = strVal & "," & GetLong(.fields("JobManager"))
						strFld = strFld & ",CustomRemark":	strVal = strVal & ",'" & FitSel(.fields("CustomRemark")) & "'"
						strFld = strFld & ",ViaPlace":		strVal = strVal & ",'" & FitSel(.fields("ViaPlace")) & "'"
						strFld = strFld & ",CarryPlace":	strVal = strVal & ",'" & FitSel(.fields("CarryPlace")) & "'"
						strFld = strFld & ",CarryDate":		strVal = strVal & ",'" & FitSel(.fields("CarryDate")) & "'"
						strFld = strFld & ",FreeTime":		strVal = strVal & ",'" & FitSel(.fields("FreeTime")) & "'"
						strFld = strFld & ",PermitNo":		strVal = strVal & ",'" & FitSel(.fields("PermitNo")) & "'"
						strFld = strFld & ",PermitDate":	strVal = strVal & ",'" & FitSel(.fields("PermitDate")) & "'"
					end if
					.Close
				end with
			end if
			
			JobInit = JobBelong & JobDivision & Num2Code(year(date)-2000) & Num2Code(Month(date)) & "-"
			
			Conn.BeginTrans
			
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_CTM_NEW_JOB"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@JobInit").Value = JobInit
			
			for i = 1 to CopyCount
				cmdSQL.Execute
				JobCode = JobInit & right("0000" & GetLong(cmdSQL.Parameters("@MaxID").Value),5)
			
				strSql = "INSERT TBL_CTM_JOB (JobCode" & strFld & ", JobOperator,  Creater) VALUES ("
				strSql = strSql & "'" & JobCode & "'" & strVal & "," & WebUserID & "," & WebUserID & ")"
if WebUserID = gsAdmin then response.write strSql
				Conn.Execute strSql
			
				msg = msg & """ & vbcrlf & """ & JobCode
				if err.number <> 0 then exit for
			next
		
			if err.number <> 0 then
				Conn.RollbackTrans
				ShowMessage "�R�s�[�������G���[���N����܂����B"
			else
				Conn.CommitTrans
%>
<html>
<script language=vbscript>
	msgbox "���L�̑䒠�ԍ��𔭍s���܂����F<%=msg%>", 64, "�m�F���b�Z�[�W"
	window.close()
</script>
</html>
<%
			end if
		end if 
	end if	

	Set Recset = nothing
	CloseDB Conn
%>
