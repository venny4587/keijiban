<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	SeqNo = GetLong(request("SeqNo"))
	if SeqNo <> 0 then
		myMode = GetLong(request("mode"))
		
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		
		with Recset
			strSql = "SELECT StockCode, StockReferNo, StockName, StockClient FROM TBL_CTM_STOCK WHERE SeqNo = " & SeqNo
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				StockCode = GetString(.fields("StockCode"))
				StockName = GetString(.fields("StockName"))
				StockClient = GetString(.fields("StockClient"))
				StockReferNo = GetString(.fields("StockReferNo"))
			end if
			.Close
		end with
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�݌ɏ��Ɖ�</TITLE>	
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
			if window.event.keyCode=80 then window.print()
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 class=pt9n onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>

<!----------��������--------->
<FORM METHOD="POST" ACTION="StockGoodsView.asp" ID=frmInput NAME=frmInput>
	<table width=96% class=pt9n>
		<tr><td width=30%>�����i���o�ɏ��
			<td width=70%>�׎�F<%=GetFullName(StockClient)%>
	</table>
	<hr width=96% size=1>
	
	<table width=96% class=pt9n>
	  <tr><td>
		  
		<table width=80% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		  <TR height=28 class=pt9g align=center valign=bottom>
			<%if StockReferNo <> "" then response.write "<td width=60>���臂<td class=gline>" & StockReferNo%>�@
			<%if StockCode <> "" then response.write "<td width=60>�i��<td class=gline>" & StockCode%>�@
			<td width=60>�i��<td class=gline><%=StockName%>
		</table>
	<!----------��������--------->
<%
		With Recset
			strSQL = "SELECT SeqNo, JobCode, StockDate, StockNo, StockLot, StockPkgCnt, StockPkgZan FROM TBL_CTM_STOCK"
			strSQL = strSQL & " WHERE Deleted = 0 AND StockType = 0 AND StockClient = '" & StockClient & "'"
			select case myMode
			case 1:		strSQL = strSQL & " AND StockCode = '" & StockCode & "'"
			case 2:		strSQL = strSQL & " AND StockName = '" & StockName & "'"
			end select
			strSQL = strSQL & " ORDER BY StockDate, StockNo"
if WebUserID = gsAdmin then response.write strSQL
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<br><br>�����ɏ��ꗗ<br><br>
		<TABLE width=80% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=5 align=center>
			<colgroup span=2 align=right>
			<colgroup align=right>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap>���ɓ�
			<TD nowrap>���ɇ�
			<TD nowrap>�q��
			<TD nowrap>�䒠�ԍ�
			<TD nowrap>���ɐ�
			<TD nowrap>�݌ɐ�
<%
				cnt = 0:	sum = 0
				Do Until .EOF
					cnt = cnt + 1
%>
			<TR>
				<TD nowrap class=line><%=cnt%>
				<TD nowrap class=line><%=Str2YMD(.Fields("StockDate"))%>
				<TD nowrap class=line><%=GetString(.Fields("StockNo"))%>
				<TD nowrap class=line><%=GetString(.Fields("StockLot"))%><br>
				<TD nowrap class=line><%=GetString(.Fields("JobCode"))%><br>
				<TD nowrap class=line><%=formatnumber(GetLong(.Fields("StockPkgCnt")), 0, true)%>
				<TD nowrap class=line style="color:green"><%=formatnumber(GetLong(.Fields("StockPkgZan")), 0, true)%>
			</TR>
<%
					sum = sum + GetLong(.Fields("StockPkgZan"))
					.MoveNext
				Loop
				if cnt > 1 then
%>
			<TR><td colspan=6><td class=line style="color:green"><%=formatnumber(sum, 0, true)%>
<%				end if %>
		</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"
			end if
			.Close
			
			strSQL = "SELECT SeqNo, StockDate, StockName, Packages, StockDelivery FROM TBL_CTM_STOCK AS S"
			strSQL = strSQL & " INNER JOIN TBL_CTM_STOCK_LINK AS L ON S.SeqNo = L.ExportNo"
			strSQL = strSQL & " WHERE Deleted = 0 AND StockType = 1 AND StockClient = '" & StockClient & "'"
			strSQL = strSQL & " AND ImportNo IN (SELECT SeqNo FROM TBL_CTM_STOCK WHERE Deleted = 0 "
			strSQL = strSQL & " AND StockType = 0 AND StockClient = '" & StockClient & "'"
			select case myMode
			case 1:		strSQL = strSQL & " AND StockCode = '" & StockCode & "'"
			case 2:		strSQL = strSQL & " AND StockName = '" & StockName & "'"
			end select
			strSQL = strSQL & ") ORDER BY StockDate, SeqNo"
if WebUserID = gsAdmin then response.write strSQL
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<br><br>���o�ɏ��ꗗ<br><br>
		<TABLE width=90% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=2 align=center>
			<colgroup span=2 align=left>
			<colgroup align=right>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap>�o�ɓ�
			<TD nowrap>�^���Ǝ�
			<TD nowrap>�[�i��
			<TD nowrap>�o�ɐ�
<%
				cnt = 0:	sum = 0
				Do Until .EOF
					cnt = cnt + 1
					StockName = FitDoor(.Fields("StockName"))
					StockDelivery = GetString(.Fields("StockDelivery"))
%>
			<TR>
				<TD nowrap class=line><%=cnt%>
				<TD nowrap class=line><%=Str2YMD(.Fields("StockDate"))%><br>
				<TD nowrap class=line <%=ShowTitle(StockDelivery, 10)%>><%=stringCut(StockDelivery, 10)%><br>
				<TD nowrap class=line <%=ShowTitle(StockName, 24)%>><%=stringCut(StockName, 24)%><br>
				<TD nowrap class=line style="color:blue"><%=formatnumber(GetLong(.Fields("Packages")), 0, true)%>
			</TR>
<%
					sum = sum + GetLong(.Fields("Packages"))
					.MoveNext
				Loop
				if cnt > 1 then
%>
			<TR><td colspan=4><td class=line style="color:blue"><%=formatnumber(sum, 0, true)%>
<%				end if %>
		</TABLE>
<%
			end if
		end with
%>
	</table>
</FORM>
</center>
</BODY></HTML>
<%
	end if
	
	set Recset = nothing
	CloseDB Conn
%>

<%
function FitDoor(myData)
dim buf
	buf = GetString(myData)
	buf = replace(buf, "�@�C�t�@", "")
	buf = replace(buf, "�@�@", " ")
	FitDoor = buf
end function
%>