<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
	SeqNo = GetLong(request("SeqNo"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	with recset
		strSql = "SELECT * FROM TBL_CTM_STOCK WHERE SeqNo = " & SeqNo
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
			StockClient = GetString(.fields("StockClient"))
			StockNo = GetString(.fields("StockNo"))			
			JobCode = GetString(.fields("JobCode"))
			
			StockDate = Str2Date(.fields("StockDate"))
			StockTime = GetString(.fields("StockTime"))
			StockStatus = GetString(.fields("StockStatus"))
			
			StockCode = GetString(.fields("StockCode"))
			StockName = GetString(.fields("StockName"))
			StockMark = GetString(.fields("StockMark"))
			StockReferNo = GetString(.fields("StockReferNo"))
			
			StockPkgCnt = GetLong(.fields("StockPkgCnt"))
			StockPkgZan = GetLong(.fields("StockPkgZan"))
			StockPackage = GetString(.fields("StockPackage"))
			StockGW = GetDouble(.fields("StockGW"))
			StockCBM = GetDouble(.fields("StockCBM"))
			
			StockPlace = GetString(.fields("StockPlace"))
			StockDivision = GetString(.fields("StockDivision"))
			StockDelivery = GetString(.fields("StockDelivery"))
			StockLot = GetString(.fields("StockLot"))
			StockMemo = GetString(.fields("StockMemo"))
		end if
		.close
	end with
	
	if StockDivision <> "" then StockDivision = GetHornor(StockDivision) & "�^"
	if StockLot <> "" then
		StockTitle = StockDivision & StockDelivery & "�@" & GetHornor(StockLot)
	else
		StockTitle = StockDivision & StockDelivery & "�@�䒆"
	end if
	if isDate(StockStatus) then StockStatus = month(StockStatus) & "/" & day(StockStatus)
	if isDate(StockDate) then StockDate = month(StockDate) & "/" & day(StockDate)
%>
<HTML>
<HEAD>
	<TITLE>�o�Ɏw�}</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r �o����; FONT-SIZE: 9pt; LINE-HEIGHT: 1.2em; font-weight: normal; }
		.ptm { FONT-FAMILY: �l�r ����; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 12pt; LINE-HEIGHT: 1.5em; font-weight: normal; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 14pt; LINE-HEIGHT: 1.5em; color: black; }
		.ptn { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 14pt; LINE-HEIGHT: 1.5em; font-weight: bold; }
		.ptx { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 18pt; LINE-HEIGHT: 1.5em; color: black; }
	</style>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
  <table Border=0 Cellspacing=0 CellPadding=0 class=ptl>
  <tr><td height=800 valign=top align=center>
	<table width=640 Border=0 Cellspacing=0 CellPadding=0 class=ptx>
	  <tr><td nowrap><%=StockTitle%>
	  <tr><td nowrap>���ו��ɓY�t���Ă�������
	  <tr><td align=center>���@���@�L
	</table>
	<table width=640 border=1 cellspacing=0 bordercolor="#808080" bordercolorlight=#FFFFFF class=pth>
		<tr align=center>
			<td width=80 rowspan=2>������
			<td width=240>��Ж�
			<td width=320>������Z��
		<tr>
			<td align=center><%=StockName%><br>
			<td>�@<%=StockMark%><br>�@TEL: <%=StockReferNo%>
		<tr align=center>
			<td colspan=2 class=ptl>�o�׎�i�����ɖ��L���Ă��������j
			<td>���ד�
		<tr align=center>
			<td colspan=2><%=StockCode%><br>
			<td class=ptx><%if StockStatus <> "" then response.write StockStatus & "�@" & StockTime & "�@�K��"%><br>
	</table>
	<br>
<!--���׍s-->
<%
	with Recset
		strSQL = "SELECT * FROM TBL_CTM_STOCK AS S INNER JOIN TBL_CTM_STOCK_LINK AS L ON S.SeqNo = L.ImportNo"
		strSQL = strSQL & " WHERE Deleted = 0 AND ExportNo = " & SeqNo
		strSql = strSql & " ORDER BY StockLot, StockReferNo, StockCode, StockDate, StockNo"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
%>
	<TABLE width=640 Cellspacing=3 CellPadding=3 class=ptn>
<%if StockClient = "3865" then%>
		<colgroup align=left>
<%end if%>
		<colgroup span=3 align=left>
		<colgroup span=2 align=center>
		<TR valign=bottom class=ptl>
			<TD class=gline width=60>�i��
<%if StockClient = "3865" then%>
			<TD class=gline width=60>�I��
<%end if%>
			<TD class=gline width=280>���i��
			<TD class=gline width=50>�q��
			<TD class=gline width=120>���ɔԍ�
			<TD class=gline width=50 nowrap>��
<%
			cnt = 0
			do while not .eof
				cnt = cnt + 1
%>
		<TR valign=bottom>
			<TD nowrap><%=GetString(.fields("StockCode"))%>
<%if StockClient = "3865" then%>
			<TD nowrap class=ptl><%=GetString(.fields("StockReferNo"))%>
<%end if%>
			<TD nowrap class=pts><div style="height:17"><%=GetString(.fields("StockName"))%><div>
			<TD nowrap><%=GetString(.fields("StockLot"))%>
			<TD nowrap><%=GetString(.fields("StockNo"))%>
			<TD nowrap><%=formatnumber(GetLong(.fields("Packages")), 0, true)%>
<%
				.movenext
			loop
			if StockClient = "3865" then
				response.write "<TR><td colspan=6><hr color=gray size=1>"
			else
				response.write "<TR><td colspan=5><hr color=gray size=1>"
			end if
%>
		<tr><td colspan=5 class=pth align=left><%=replace(StockMemo, vbcrlf, "<br>")%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�������f�[�^�͌�����܂���ł����B</font>"
		end if
	end with
	
	'���y�[�W����
	line = 0
	if cnt > 10 and cnt < 18 then
		line = 18 - cnt
	elseif cnt > 20 and cnt < 28 then
		line = 28 - cnt
	elseif cnt > 37 and cnt < 45 then
		line = 45 - cnt
	elseif cnt > 64 and cnt < 72 then
		line = 72 - cnt
	end if
	if line <> 0 then
		for i = 1 to line
%>
  	<tr><td align=right class=ptn><br>
<%
		next
	end if
%>  
  <tr><td align=right>
	<table width=400 cellspacing=0 cellpadding=0 class=pth>
	  <tr><td><%=JobCode%>�@�@<%=StockNo%><br>
			<table width=100% border=1 cellspacing=0 bordercolor="#808080" bordercolorlight=#FFFFFF class=ptx>
				<tr align=center>
					<td width=200>���@�v
					<td width=200><%=StockPkgCnt%>�@<%=StockPackage%>
				<tr align=center>
					<td><%=formatnumber(StockGW, 0, true)%> KGS
					<td><%=formatnumber(StockCBM, 3, true)%> �l<sup>3</sup>
				<tr align=center>
					<td colspan=2><%=StockPlace%>�@<%=StockDate%>�@�o��
				<tr align=center>
					<td colspan=2><%=StockDelivery%>
 			</table>
	</table>
  </TABLE>
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>