<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�������ꊇ�������
'----------------------------------------------

'on error resume next

'	Response.Buffer = True

dim JobCode
dim strSeq

	ChargeNo = GetPost(request("nos"))
	ChargeNos = ResetBizNos(ChargeNo)
	if ChargeNos <> "" then	
		BatchNo = ""
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		With RecSet
			strSQL = "SELECT ChargeClient, ChargeClientName, ChargePic, ChargeDate, ChargePayDay, ChargeBatch, JobCode"
			strSQL = strSQL & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeNo IN (" & ChargeNos & ")" 
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				BatchNo = GetString(.Fields("ChargeBatch"))
				BatchBelong = Mid(GetString(.Fields("JobCode")), 1, 1)
				BatchClient = GetString(.Fields("ChargeClient"))
				if left(BatchClient, 3) = "690" then BatchClient = "690"
				BatchPic = GetString(.Fields("ChargePic"))
				BatchBillDay = GetString(.Fields("ChargeDate"))
				BatchPayDay = GetString(.Fields("ChargePayDay"))
			end if
			.Close
			
			strSql = "SELECT COUNT(ChargeNo) AS CNT, SUM(ChargeAmount + ChargeTax) AS TTL"
			strSql = strSql & ",SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN '" & gsExport & "' THEN 1 ELSE 0 END) AS EX"
			strSql = strSql & ",SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN '" & gsExport & "' THEN 0 ELSE 1 END) AS IM"
			strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeNo IN (" & ChargeNos & ")"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				BatchCount = GetLong(.fields("CNT"))
				BatchAmount = GetLong(.fields("TTL"))
				if GetLong(.fields("EX")) = 0 then
					BatchType = gsImport
				elseif GetLong(.fields("IM")) = 0 then
					BatchType = gsExport
				else
					BatchType = "Z"
				end if
			end if
			.Close
		end with
		
		mode = GetPost(request("mode"))
		if BatchNo = "" and mode = 1 then
			Conn.BeginTrans				
			BatchID = GetNewBatchNo(Conn, gsBatchPrint)
			BatchNo = GetBatchNo(BatchID, gsBatchPrint)					
			With RecSet
				strSQL = "SELECT * FROM TBL_CTM_BATCH"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				.addnew				
				
				.fields("BatchBelong") = BatchBelong
				.fields("BatchType") = BatchType
				.fields("BatchNo") = BatchNo
				.fields("BatchPic") = BatchPic
				.fields("BatchClient") = BatchClient
				.fields("BatchCount") = BatchCount
				.fields("BatchAmount") = BatchAmount
				.fields("BatchBillDay") = BatchBillDay
				.fields("BatchPayDay") = BatchPayDay
				
				.fields("Remarks") = "�ꊇ�������"
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				
				.fields("Creater") = WebUserID
				.fields("Created") = now
				.fields("Deleted") = 0
				.update
				.close
			End With
			Set Recset = nothing
			
			strSql = "UPDATE TBL_CTM_CHARGE SET ChargeBatch = '" & BatchNo & "' WHERE Deleted = 0 AND ChargeNo IN (" & ChargeNos & ")"
			Conn.Execute strSql
			
			strSql = "UPDATE TBL_CTM_BIZ SET BIZ_BATCH = '" & BatchNo & "' WHERE BIZ_DELETED = 0 AND BIZ_NO IN (" & ChargeNos & ")"
			Conn.Execute strSql
			
			if err.number = 0 then
				Conn.CommitTrans
			else
				ShowMessage "�ꊇ������G���[���N����܂����B"
				Conn.RollbackTrans
			end if
		end if
		CloseDB Conn

		if err.number = 0 then
			if mode = 2 then
				
				strSeq = split(ChargeNos, ",")
				strDivider = ""
				For i = 0 To ubound(strSeq)
					If i = 0 Then
						strDivider = "100%"
					Else
						strDivider = strDivider & ",0"
					End If
				Next

%>
		<HTML>
			<HEAD>
				<TITLE>����������v���r���[</TITLE>
				<META http-equiv=Content-Type content="text/html; charset=shift-jis">
			</HEAD>
			<FRAMESET COLS="<%=strDivider%>" FRAMEBORDER=0 ID="fraCalc" NAME="fraCalc">
				<%
				For i = 0 to ubound(strSeq)
					Response.Write "<FRAME name='" & i & "' SRC='BillPrint.asp?print=1&ChargeNo=" & ResetNo(strSeq(i)) & "'>"
				Next
				%>
			</FRAMESET>
		</HTML>
<%
			else
				Response.Redirect "BillCover.asp?nos=" & ChargeNo
			end if
		End If	
	end if
	
'	Response.Flush 
'	Response.End 	

function ResetNo(myNo)
	ResetNo = mid(myNo, 2, len(myNo) - 2)
end function
%>
