<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
		
	ChargeSort = GetLong(request("sort"))
	
	SelData = GetPost(request("sel"))
	BatchNo = GetPost(request("BatchNo"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>����ԍ��ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>			
		function DoSort(myNo)
			window.location.href = "ChargeBatchList.asp?BatchNo=<%=BatchNo%>&sort=" & myNo
		end function

		function ShowDetail(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & myJob & "&ChargeNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
  <form name=frmInput method="post" action="ChargeBatchList.asp">
  	<input type=hidden name="mode" value="<%=mode%>">
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR valign=bottom>
	  	<td nowrap width=30%>���������ꗗ&nbsp;
	  	<td nowrap width=50%>����� <%=BatchNo%>
	  	<td nowrap width=20%><img style="cursor:hand" src=img/cover.jpg alt="�\�����" onmousedown="DoPrint()">
	</table>
	<hr size=1 color=blue>
<%	
	ChargeNos = ""
	with recset
		strSql = "SELECT JobCode, ChargeType, ClientRef, ChargeClientName, ChargeNo, ChargeDate, ChargeAmount, ChargeTax, ChargePayDay, FinisherID"
		strSql = strSql & " FROM TBL_CTM_Charge AS T INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0 AND ChargeBatch = '" & BatchNo & "'"
		select case ChargeSort
		case 0:		strSql = strSql & " ORDER BY ChargeNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, ChargeNo"
		case 2:		strSql = strSql & " ORDER BY ChargeDate, ChargeNo"
		case 3:		strSql = strSql & " ORDER BY (ChargeAmount+ChargeTax), ChargeNo"
		end select
if WebUserID = gsAdmin then response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		<colgroup span=4 align=center>
		<colgroup align=right>
		<colgroup span=2 align=center>
	  <TR align=center height=20 class=pt9>
	  	<TD class=line nowrap>��
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�`�[�ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">������
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�������z
		<TD class=line nowrap align=center>������
		<TD class=line nowrap>�敪
<%
			cnt = 0
			ttlCount = 0
			ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode"))
				ChargeNo = GetString(.Fields("ChargeNo"))
				myAmount = GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax"))
%>
				<TR height=20>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=JobCode%>','<%=ChargeNo%>')"><%=cnt%>
					<TD class=line><%=ShowVoucherNo(ChargeNo)%><BR>
					<TD class=line nowrap><%=ShowJobCode(JobCode)%><BR>
					<TD class=line nowrap style="color:blue"><%=Str2MD(.Fields("ChargeDate"))%><BR>
					<TD class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
					<TD class=line nowrap style="color:blue"><%=Str2MD(.Fields("ChargePayDay"))%><BR>
					<TD class=line nowrap><%=ShowBillType(.Fields("ChargeType"))%><BR>
<%		
				ttlAmount = ttlAmount + myAmount
				if ChargeNos <> "" then ChargeNos = ChargeNos & ","
				ChargeNos = ChargeNos & ResetBizNo(.Fields("ChargeNo"))
				.movenext
			loop
			if cnt > 1 then
%>
				<TR height=20>
					<TD colspan=3 align=right class=pt9>���v���z
					<TD colspan=2 align=right class=line><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�����鐿�����͌�����܂���ł����B</font>"
		end if
	end with
%>  
  </form>
  
<script language=vbscript>
	function DoPrint()
		set win = window.open("BillCover.asp?nos=<%=ChargeNos%>","BillCover","resizable=1,scrollbars=1,width=800,height=600")
		win.focus()
	end function
</script>
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
