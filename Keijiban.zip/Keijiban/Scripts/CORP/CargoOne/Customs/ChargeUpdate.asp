<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	JobCode = GetPost(request("JobCode"))
	ChargeNo = GetPost(request("ChargeNo"))
	SeqNo = GetLong(request("SeqNo"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")	
		
	if JobCode <> "" and ChargeNo <> "" then
		if CheckBillLocked(Conn, JobCode, ChargeNo) then
			JobCode = ""
			ShowMessage "�Y�����鐿�����͊��Ɋm�肳��܂����B"
		end if
	end if
	
	if JobCode <> "" then
	
		Conn.BeginTrans
		
		mode = GetLong(request("mode"))
		select case mode
		case -1

			strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID
			strSql = strSql & ",Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			Conn.Execute strSql
			
			'�ۊǖ���
			strSql = "UPDATE TBL_CTM_KEEP SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID
			strSql = strSql & ",Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND ExpenseNo = " & SeqNo
			Conn.Execute strSql
			
		case else
		
			if SeqNo = 0 then 
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Expense"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
			else
				'�ۊǑΏۊO���׍폜
				select case GetLong(request("ExpenseCost"))
				case 36, 37
				case else 
					'�ۊǗ�����ύX�\
					strSql = "UPDATE TBL_CTM_KEEP SET Deleted = 1"
					strSql = strSql & ",Updater = " & WebUserID
					strSql = strSql & ",Updated = GETDATE()"
					strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND ExpenseNo = " & SeqNo
					Conn.Execute strSql
				end select
			end if
			
			with Recset
				strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = GetPost(request("JobCode"))
					.fields("SeqNo") = SeqNo
					.fields("ExpenseType") = gsCharge					'����
					.fields("ExpenseBill") = ChargeNo
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				
				.fields("ExpenseClient") = GetPost(request("JobShipper"))	'JobShipper�͌�����ʂ𗬗p���邽��
				.fields("ExpenseCost") = GetLong(request("ExpenseCost"))
				.fields("ExpenseAttr") = GetLong(request("ExpenseAttr"))
				.fields("ExpenseDate") = Date2Str(request("ExpenseDate"))
				.fields("ExpenseMemo") = GetPost(request("ExpenseMemo"))
				
				.fields("ExpensePrice") = GetDouble(request("ExpensePrice"))
				.fields("ExpenseQuantity") = GetDouble(request("ExpenseQuantity"))
				.fields("ExpenseUnit") = GetPost(request("ExpenseUnit"))
				.fields("ExpenseAmount") = GetLong(request("ExpenseAmount"))
				.fields("ExpenseTaxName") = GetPost(request("ExpenseTaxName"))
				.fields("ExpenseTax") = GetLong(request("ExpenseTax"))								
				.fields("Remarks") = GetPost(request("Remarks"))
					
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			
		end select
		
		if ChargeNo <> "" then 
			'�������X�V
			ChargeAmount = 0
			ChargeTax = 0
			with Recset
				strSql = "SELECT SUM(ExpenseAmount) AS ChargeAmount, SUM(ExpenseTax) AS ChargeTax FROM TBL_CTM_EXPENSE"
				strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
				strSql = strSql & " AND ExpenseType IN (" & gsCharge & "," & gsStand & ")"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					ChargeAmount = GetLong(.fields("ChargeAmount"))
					ChargeTax = GetLong(.fields("ChargeTax"))
				end if
				.close
			end with
		
			strSql = "UPDATE TBL_CTM_CHARGE SET ChargeAmount = " &  GetLong(ChargeAmount) & ", ChargeTax = " &  GetLong(ChargeTax)
			strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			Conn.Execute strSql
		end if
		
		
		if err.number = 0 then 
		
			Conn.CommitTrans
%>
<html>
<script language=javascript>
	window.opener.parent.parent.info.balance.location.href = "BalanceCheck.asp?JobCode=<%=JobCode%>";
	window.opener.parent.list.location.href = "ChargeBill.asp?JobCode=<%=JobCode%>";
	window.opener.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>";
	window.close();
</script>
</html>
<%
		else
		
			Conn.RollbackTrans
			ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
			
		end if
	end if
	
	set Recset = nothing
	CloseDB Conn
%>