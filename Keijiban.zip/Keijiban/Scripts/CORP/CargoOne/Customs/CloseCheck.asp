<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/Function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����߃`�F�b�N���
'----------------------------------------------

'on error resume next
dim mode
dim AccountMonth
dim AccountFrom
dim AccountTo
dim ShowCount
	
	ShowCount = 20
	ShowCount2 = 100	
	if WebUserID = gsAdmin then ShowCount = 100
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	SelType = GetLong(request("type"))
	SelYear = GetLong(request("SelYear"))
	SelMonth = GetLong(request("SelMonth"))
	if SelYear = 0 or SelMonth = 0 then
		SelDate = date
		if day(SelDate) <= 31 then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
	end if
	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
	myLevel = CheckUserLevel(UserShop, "")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����ߋƖ����׌���</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowCharge(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & myJob & "&ChargeNo=" & myNo,"","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		function ShowDetail(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=2&JobCode=" & myJob & "&CostsNo=" & myNo,"check","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		sub InitForm()
			frmInput.SelYear.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY class=pt9 onload="InitForm()" <%=gsBodyControl%>>
<!--�d�󌟍����x�ݒ�-->
  <FORM METHOD="POST" ACTION="CloseCheck.asp" ID=frmInput NAME=frmInput>
	<input type=hidden name="type" value="0">
	<table class=pt9>
		<TR><TD nowrap>			
			��v���x&nbsp;
				<select name="SelYear" onkeydown="ResetEnter()"><%
				for i = year(date) to year(gsSysStart) step -1
					response.write "<option value=" & i
					if i = SelYear then response.write " selected"
					response.write ">" & i
				next%></select>&nbsp;�N
				<select name="SelMonth" onkeydown="ResetEnter()"><%
				for i = 1 to 12
					response.write "<option value=" & i
					if i = SelMonth then response.write " selected"
					response.write ">" & i
				next%></select>&nbsp;��
			<TD nowrap>	
				<INPUT style="width:80px;height:30px;" TYPE=SUBMIT VALUE="���s">					
	</table>

	<table class=pt9n cellspacing=3>
	  <tr height=24 align=center bgcolor="#E0E0E0"><td rowspan=2 width=50>���m��
	  	<td width=170>����<td width=170>�x��<td width=170>�ޯ�<td width=170>�e��
	  <tr height=24 align=center><td valign=top>
<%
	'���������m��ꗗ
	with Recset
		strSql = "SELECT ChargeNo, C.JobCode, (ChargeAmount+ChargeTax) AS ChargeTotal"
		strSql = strSql & " FROM TBL_CTM_CHARGE AS C INNER JOIN TBL_CTM_JOB AS J ON C.JobCode = J.JobCode"
		strSql = strSql & " WHERE J.Deleted = 0 AND C.Deleted = 0 AND C.ConfirmerID = 0"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "' ORDER BY ChargeAmount"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>������<td>�������z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr style=""cursor:hand"" onmousedown=ShowCharge('" & .fields("JobCode") & "','" & .fields("ChargeNo") & "')>"
					response.write "<td>" & cnt & "<td>" & .fields("ChargeNo") & "<td align=right>" & .fields("ChargeTotal")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("ChargeTotal")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�x���`�[���m��ꗗ
	with Recset
		strSql = "SELECT CostsNo, C.JobCode, (C.CostsAmount+C.CostsTax) AS CostsTotal"
		strSql = strSql & " FROM TBL_CTM_COSTS AS C INNER JOIN TBL_CTM_JOB AS J ON C.JobCode = J.JobCode"
		strSql = strSql & " WHERE J.Deleted = 0 AND C.Deleted = 0 AND C.ConfirmerID = 0"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "' ORDER BY CostsAmount"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�x����<td>�x�����z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr style=""cursor:hand"" onmousedown=ShowDetail('" & .fields("JobCode") & "','" & .fields("CostsNo") & "')>"
					response.write "<td>" & cnt & "<td>" & .fields("CostsNo") & "<td align=right>" & .fields("CostsTotal")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("CostsTotal")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�ޯ��ԍ����m��ꗗ
	with Recset
		strSql = "SELECT BatchNo, BatchAmount FROM TBL_CTM_BATCH WHERE Deleted = 0 AND ConfirmerID = 0"
		strSql = strSql & " AND BatchBillDay BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if myLevel < 3 then strSql = strSql & " AND BatchBelong = '" & UserShop & "'"
		strSql = strSql & " ORDER BY BatchNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�ޯ���<td>�ޯ����z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr><td>" & cnt & "<td>" & .fields("BatchNo") & "<td align=right>" & .fields("BatchAmount")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("BatchAmount")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�e�����m��ꗗ
	with Recset
		strSql = "SELECT JobCode, Interests FROM TBL_CTM_JOB WHERE Deleted = 0 AND LockerID = 0"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�䒠�ԍ�<td>�e��"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr style=""cursor:hand"" onmousedown=ShowDetail('" & .fields("JobCode") & "','')>"
					response.write "<td>" & cnt & "<td>" & .fields("JobCode") & "<td align=right>" & .fields("Interests")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("Interests")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	</table>

	<table class=pt9n cellspacing=3>
	  <tr height=24 align=center bgcolor="#FFE0E0"><td rowspan=2 width=50>��p<td width=350>�����R��<td width=350>���֘R��
	  <tr height=24 align=center><td valign=top>
<%
	'�������Ǝx���`�[�s��v�ꗗ
	with Recset
		strSql = "SELECT A.JobCode, JobSalesman, COST_NAME, ExpenseP AS ExpenseTotal FROM "
		strSql = strSql & " (SELECT JobCode, ExpenseCost, SUM(ExpenseAmount + ExpenseTax) AS ExpenseP FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseCost <> 123 AND ExpenseCost <> 113 AND ExpenseType = " & gsPayment
		strSql = strSql & " AND ExpenseClient NOT IN ('" & gsCorpSoko & "','" & gsCorpCode & "','" & gsCorpTruck & "')"	'�q�ɂ̂���
		strSql = strSql & " AND ExpenseCost NOT IN (4, 14, 19, 35, 48, 102) AND SUBSTRING(JobCode,1,1) <> '" & gsSokoInit &"'"		'�q�ɂ̂���
		strSql = strSql & " GROUP BY JobCode, ExpenseCost) AS A LEFT JOIN "
		strSql = strSql & " (SELECT JobCode, ExpenseCost, SUM(ExpenseAmount + ExpenseTax) AS ExpenseR FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseType = " & gsCharge & " GROUP BY JobCode, ExpenseCost) AS B "
		strSql = strSql & " ON A.JobCode = B.JobCode AND A.ExpenseCost = B.ExpenseCost"
		strSql = strSql & " INNER JOIN (SELECT COST_ID, COST_NAME FROM MST_COST WHERE COST_DELETED = 0) AS C ON A.ExpenseCost = C.COST_ID"
		strSql = strSql & " INNER JOIN (SELECT JobCode, JobSalesman FROM TBL_CTM_JOB WHERE Deleted = 0 AND SUBSTRING(JobClient,1,3) <> '690'"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "') AS J ON A.JobCode = J.JobCode"
		strSql = strSql & " WHERE B.JobCode IS NULL ORDER BY JobSalesman, A.JobCode"
if webuserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<colgroup span=3><colgroup align=right><colgroup align=center>"
			response.write "<tr><td>��<td>�䒠�ԍ�<td>��p����<td>�������z<td>�c��"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount2 then
					response.write "<tr style=""cursor:hand"" onmousedown=ShowDetail('" & .fields("JobCode") & "','')>"
					response.write "<td>" & cnt & "<td>" & .fields("JobCode") & "<td>" & .fields("COST_NAME") & "<td>" & .fields("ExpenseTotal")
					response.write "<td>" & GetEmployName(.fields("JobSalesman"), "F")
				elseif cnt = ShowCount2 then
					response.write "<tr><td colspan=5 class=pt9r>��������܂�..."
				end if
				total = total + GetLong(.fields("ExpenseTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr><td>" & cnt & "<td align=right colspan=2>���z���v<td>" & total & "<td><br>"
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'���֐����Ɨ��֎x���s��v�ꗗ
	with Recset
		strSql = "SELECT E.JobCode, JobSalesman, COST_NAME, ExpenseTotal FROM "
		strSql = strSql & " (SELECT JobCode, ExpenseCost, SUM(ExpenseAmount + ExpenseTax) AS ExpenseTotal FROM TBL_CTM_EXPENSE"
		strSql = strSql & "  WHERE Deleted = 0 AND ExpenseType = " & gsStand & " AND (ExpenseBill = '' OR ExpensePay = '')"
		strSql = strSql & " GROUP BY JobCode, ExpenseCost) AS E"
		strSql = strSql & " INNER JOIN (SELECT COST_ID, COST_NAME FROM MST_COST) AS C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " INNER JOIN (SELECT JobCode, JobSalesman FROM TBL_CTM_JOB WHERE Deleted = 0"
		if myLevel < 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "') AS J"
		strSql = strSql & " ON E.JobCode = J.JobCode ORDER BY JobSalesman, E.JobCode"
if webuserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<colgroup span=3><colgroup align=right><colgroup align=center>"
			response.write "<tr align=center><td>��<td>�䒠�ԍ�<td>��p����<td>���֋��z<td>�c��"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount2 then
					response.write "<tr style=""cursor:hand"" onmousedown=ShowDetail('" & .fields("JobCode") & "','')>"
					response.write "<td>" & cnt & "<td>" & .fields("JobCode") & "<td>" & .fields("COST_NAME") & "<td>" & .fields("ExpenseTotal")
					response.write "<td>" & GetEmployName(.fields("JobSalesman"), "F")
				elseif cnt = ShowCount2 then
					response.write "<tr><td colspan=5 class=pt9r>��������܂�..."
				end if
				total = total + GetLong(.fields("ExpenseTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr><td>" & cnt & "<td align=right colspan=2>���z���v<td>" & total & "<td><br>"
			response.write "</table>"
		end if
		.close
	end with
%>
<%if WebUserID = 1 then
	'�Ɩ��������z�X�V
	strSql = "UPDATE TBL_CTM_JOB SET SalesSum = (SELECT ISNULL(SUM(ExpenseAmount), 0) FROM TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.JobCode = TBL_CTM_JOB.JobCode"
	strSql = strSql & " AND ExpenseType = " & gsCharge & ") FROM TBL_CTM_JOB, TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_JOB.Deleted = 0 AND TBL_CTM_JOB.AccountDate = ''"
	Conn.Execute strSql
	
	'�Ɩ������Ŋz�X�V
	strSql = "UPDATE TBL_CTM_JOB SET SalesTax = (SELECT ISNULL(SUM(ExpenseTax), 0) FROM TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.JobCode = TBL_CTM_JOB.JobCode"
	strSql = strSql & " AND ExpenseType = " & gsCharge & ") FROM TBL_CTM_JOB, TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_JOB.Deleted = 0 AND TBL_CTM_JOB.AccountDate = ''"
	Conn.Execute strSql
	
	'�Ɩ����֋��z�X�V
	strSql = "UPDATE TBL_CTM_JOB SET StandSum = (SELECT ISNULL(SUM(ExpenseAmount+ExpenseTax), 0) FROM TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.JobCode = TBL_CTM_JOB.JobCode"
	strSql = strSql & " AND ExpenseType = " & gsStand & ") FROM TBL_CTM_JOB, TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_JOB.Deleted = 0 AND TBL_CTM_JOB.AccountDate = ''"
	Conn.Execute strSql
	
	'�Ɩ��������z�X�V
	strSql = "UPDATE TBL_CTM_JOB SET CostsSum = (SELECT ISNULL(SUM(ExpenseAmount), 0) FROM TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.JobCode = TBL_CTM_JOB.JobCode"
	strSql = strSql & " AND ExpenseType = " & gsPayment & ") FROM TBL_CTM_JOB, TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_JOB.Deleted = 0 AND TBL_CTM_JOB.AccountDate = ''"
	Conn.Execute strSql
	
	'�Ɩ������Ŋz�X�V
	strSql = "UPDATE TBL_CTM_JOB SET CostsTax = (SELECT ISNULL(SUM(ExpenseTax), 0) FROM TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.JobCode = TBL_CTM_JOB.JobCode"
	strSql = strSql & " AND ExpenseType = " & gsPayment & ") FROM TBL_CTM_JOB, TBL_CTM_EXPENSE"
	strSql = strSql & " WHERE TBL_CTM_JOB.Deleted = 0 AND TBL_CTM_JOB.AccountDate = ''"
	Conn.Execute strSql
	
	'�Ɩ��e�����z�X�V
	strSql = "UPDATE TBL_CTM_JOB SET Interests = (SalesSum + SalesTax) - (CostsSum + CostsTax)"
	strSql = strSql & " WHERE TBL_CTM_JOB.Deleted = 0 AND TBL_CTM_JOB.AccountDate = ''"
	Conn.Execute strSql
%>
	  <tr height=24 align=center bgcolor="#E0FFE0"><td rowspan=2>�Ɩ�<td>�������v<td>�x�����v
	  <tr height=24 align=center><td valign=top>
<%
	'�Ɩ������Ɛ��������v�s��v�ꗗ
	with Recset
		strSql = "SELECT SalesDate, J.JobCode, (SalesSum+SalesTax+StandSum) AS JobTotal, ChargeTotal FROM TBL_CTM_JOB AS J"
		strSql = strSql & " INNER JOIN (SELECT JobCode, SUM(ExpenseAmount+ExpenseTax) AS ChargeTotal FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseType <> " & gsPayment & " GROUP BY JobCode) AS C ON J.JobCode = C.JobCode"
		strSql = strSql & " WHERE Deleted = 0 AND (SalesSum+SalesTax+StandSum) <> ChargeTotal"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY J.JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�䒠�ԍ�<td>������<td>�������z<td>�������v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr style=""cursor:hand"" onmousedown=ShowDetail('" & .fields("JobCode") & "','') align=right>"
					response.write "<td>" & cnt & "<td>" & .fields("JobCode") & "<td>" & Str2Date(.fields("SalesDate"))
					response.write "<td>" & .fields("JobTotal") & "<td>" & .fields("ChargeTotal")
					response.write "<td color=red>" & (.fields("JobTotal") - .fields("ChargeTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("JobTotal") - .fields("ChargeTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�Ɩ��x���Ǝx���`�[���v�s��v�ꗗ
	with Recset
		strSql = "SELECT SalesDate, J.JobCode, (CostsSum+CostsTax+StandSum) AS JobTotal, CostsTotal FROM TBL_CTM_JOB AS J"
		strSql = strSql & " INNER JOIN (SELECT JobCode, SUM(ExpenseAmount+ExpenseTax) AS CostsTotal FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseType <> " & gsCharge & " GROUP BY JobCode) AS C ON J.JobCode = C.JobCode"
		strSql = strSql & " WHERE Deleted = 0 AND (CostsSum+CostsTax+StandSum) <> CostsTotal"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY J.JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�䒠�ԍ�<td>������<td>�x�����z<td>�x�����v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr style=""cursor:hand"" onmousedown=ShowDetail('" & .fields("JobCode") & "','') align=right>"
					response.write "<td>" & cnt & "<td>" & .fields("JobCode") & "<td>" & Str2Date(.fields("SalesDate"))
					response.write "<td>" & .fields("JobTotal") & "<td>" & .fields("CostsTotal")
					response.write "<td color=red>" & (.fields("JobTotal") - .fields("CostsTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("JobTotal") - .fields("CostsTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	  <tr height=24 align=center bgcolor="#FFFFE0"><td rowspan=2>�ޯ�<td>����ԍ�<td>�ޯ��ԍ�
	  <tr height=24 align=center><td valign=top>
<%
	'��������Ɛ��������v�s��v�ꗗ
	with Recset
		strSql = "SELECT BatchNo, BatchCount, BatchAmount, ChargeTotal FROM TBL_CTM_BATCH AS B INNER JOIN"
		strSql = strSql & " (SELECT ChargeBatch, SUM(ChargeAmount+ChargeTax) AS ChargeTotal FROM TBL_CTM_CHARGE"
		strSql = strSql & " WHERE Deleted = 0 AND ChargeBatch <> '' GROUP BY ChargeBatch) AS C"
		strSql = strSql & " ON B.BatchNo = C.ChargeBatch WHERE Deleted = 0 AND BatchAmount <> ChargeTotal"
		strSql = strSql & " AND BatchBillDay BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BatchNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>����ԍ�<td>����<td>�������z<td>�������v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("BatchNo") & "<td>" & .fields("BatchCount")
					response.write "<td>" & .fields("BatchAmount") & "<td>" & .fields("ChargeTotal")
					response.write "<td color=red>" & (.fields("BatchAmount") - .fields("ChargeTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("BatchAmount") - .fields("ChargeTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�ޯ��ԍ��Ǝx���`�[���v�s��v�ꗗ
	with Recset
		strSql = "SELECT BatchNo, BatchCount, BatchAmount, CostsTotal FROM TBL_CTM_BATCH AS B INNER JOIN"
		strSql = strSql & " (SELECT CostsBatch, SUM(CostsAmount+CostsTax) AS CostsTotal FROM TBL_CTM_COSTS"
		strSql = strSql & " WHERE Deleted = 0 AND CostsBatch <> '' GROUP BY CostsBatch) AS C ON B.BatchNo = C.CostsBatch"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0 AND BatchAmount <> CostsTotal"
		strSql = strSql & " AND BatchBillDay BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BatchNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�ޯ��ԍ�<td>����<td>�������z<td>�������v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("BatchNo") & "<td>" & .fields("BatchCount")
					response.write "<td>" & .fields("BatchAmount") & "<td>" & .fields("CostsTotal")
					response.write "<td color=red>" & (.fields("BatchAmount") - .fields("CostsTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("BatchAmount") - .fields("CostsTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	  <tr height=24 align=center bgcolor="#E0FFFF"><td rowspan=2>�d��<td>�����d��<td>�x���d��
	  <tr height=24 align=center><td valign=top>
<%
	'�������Ɛ����d��s��v�ꗗ
	with Recset
		strSql = "SELECT ChargeNo, JobCode, (ChargeAmount+ChargeTax) AS ChargeTotal, BIZ_TOTAL FROM TBL_CTM_CHARGE AS C"
		strSql = strSql & " INNER JOIN (SELECT BIZ_NO, SUM(BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ"
		strSql = strSql & " WHERE BIZ_DELETED = 0 GROUP BY BIZ_NO) AS B ON C.ChargeNo = B.BIZ_NO"
		strSql = strSql & " WHERE Deleted = 0 AND (ChargeAmount+ChargeTax) <> BIZ_TOTAL"
		strSql = strSql & " AND ChargeDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY ChargeNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>������<td>�䒠�ԍ�<td>�������z<td>�d�󍇌v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("ChargeNo") & "<td>" & .fields("JobCode")
					response.write "<td>" & .fields("ChargeTotal") & "<td>" & .fields("BIZ_TOTAL")
					response.write "<td color=red>" & (.fields("ChargeTotal") - .fields("BIZ_TOTAL"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("ChargeTotal") - .fields("BIZ_TOTAL"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�x���`�[�Ǝx���d��s��v�ꗗ
	with Recset
		strSql = "SELECT CostsNo, JobCode, (CostsAmount+CostsTax) AS CostsTotal, BIZ_TOTAL FROM TBL_CTM_COSTS AS C"
		strSql = strSql & " INNER JOIN (SELECT BIZ_NO, SUM(BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ"
		strSql = strSql & " WHERE BIZ_DELETED = 0 GROUP BY BIZ_NO) AS B ON C.CostsNo = B.BIZ_NO"
		strSql = strSql & " WHERE Deleted = 0 AND (CostsAmount+CostsTax) <> BIZ_TOTAL"
		strSql = strSql & " AND CostsDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY CostsNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�x����<td>�䒠�ԍ�<td>�x�����z<td>�d�󍇌v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("CostsNo") & "<td>" & .fields("JobCode")
					response.write "<td>" & .fields("CostsTotal") & "<td>" & .fields("BIZ_TOTAL")
					response.write "<td color=red>" & (.fields("CostsTotal") - .fields("BIZ_TOTAL"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("CostsTotal") - .fields("BIZ_TOTAL"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
<%end if%>
	</table>
  </FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>