<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
dim JobCode, MBL, HBL, Canceled, FinisherID

JobCode = GetPost(request("JobCode"))
if JobCode <> "" then

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			JobClient = GetString(.fields("JobClient"))
			JobBelong = GetString(.fields("JobBelong"))
			JobCountry = GetString(.fields("JobCountry"))
			JobOperator = GetString(.fields("JobOperator"))
			JobManager = GetLong(.fields("JobManager"))
			JobNo = GetString(.fields("JobNo"))
			EdaNo = GetString(.fields("EdaNo"))
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POL = GetString(.fields("POL"))
			POD = GetString(.fields("POD"))
			POLN = GetString(.fields("POLN"))
			PODN = GetString(.fields("PODN"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			MBL = GetString(.fields("MBL"))
			HBL = GetString(.fields("HBL"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))	
			Marks = replace(GetString(.fields("Marks")), vbcrlf, "<br>")
			Container = replace(GetString(.fields("Container")), vbcrlf, "<br>")
			
			JobShipper = GetString(.fields("JobShipper"))
			RequireDate = Str2Date(.fields("RequireDate"))
			Insurance = GetLong(.fields("Insurance"))
			Inspection = GetString(.fields("Inspection"))
			Surrendered = GetLong(.fields("Surrendered"))
			ShipCorp = GetString(.fields("ShipCorp"))
			ShipPic = GetString(.fields("ShipPic"))
			CustomBroker = GetString(.fields("CustomBroker"))
			CustomRemark = replace(GetString(.fields("CustomRemark")), vbcrlf, "<br>")
			CarryPlace = GetString(.fields("CarryPlace"))
			CarryDate = Str2Date(.fields("CarryDate"))
			FreeTime = Str2Date(.fields("FreeTime"))
			PermitNo = GetString(.fields("PermitNo"))
			PermitDate = Str2Date(.fields("PermitDate"))
			ReturnDate = Str2Date(.fields("ReturnDate"))
			DeliveryDate = Str2MD(.fields("DeliveryDate"))			
			Remarks = GetString(.fields("Remarks"))
		end if
		.close
		if Voy <> "" then Vessel = Vessel & " V." & Voy

		StrSql = "SELECT PIC_NAME, PIC_TEL, PIC_FAX FROM CTM_PIC WHERE PIC_DFT <> 0 AND CTM_CD = '" & JobClient & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			PIC_TEL = GetString(.fields("PIC_TEL"))
			PIC_FAX = GetString(.fields("PIC_FAX"))
			PIC_NAME = GetString(.fields("PIC_NAME"))
		end if 
		.close
		
		StrSql = "SELECT CTM_ENAME, CTM_NACCS_CD, CTM_TEL, CTM_ETC_CODE, CTM_ETC_DATA FROM CUSTOMER WHERE CTM_CD = '" & JobShipper & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			CTM_TEL = GetString(.fields("CTM_TEL"))
			CTM_ENAME = GetString(.fields("CTM_ENAME"))
			CTM_NACCS_CD = GetString(.fields("CTM_NACCS_CD"))
			CTM_ETC_CODE = GetString(.fields("CTM_ETC_CODE"))
			CTM_ETC_DATA = GetString(.fields("CTM_ETC_DATA"))
		end if 
		.close
		
		CarryTel = "":	CarryFax = ""
		if CarryPlace <> "" then
			SearchPlace = CarryPlace
			idx = instrrev(SearchPlace, " (")
			if idx <> 0 then SearchPlace = left(SearchPlace, idx - 1)
			StrSql = "SELECT PLC_CD, PLC_TEL, PLC_FAX FROM MST_PLACE WHERE PLC_DELETED = 0"
			StrSql = StrSql & " AND SUBSTRING(PLC_NAME, 1, " & len(SearchPlace) & ") = '" & SearchPlace & "'"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				CarryTel = GetString(.fields("PLC_TEL"))
				CarryFax = GetString(.fields("PLC_FAX"))
			end if
			.close
		end if
		if CarryTel <> "" then CarryTel = "�@Tel: " & CarryTel
		if CarryFax <> "" then CarryFax = "�@Fax: " & CarryFax
		
		Cnt20 = 0:	Cnt40 = 0:	CntEtc = 0
		StrSql = "SELECT ContainerSize, COUNT(SeqNo) AS CNT FROM TBL_CTM_CONTAINER"
		StrSql = StrSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' GROUP BY ContainerSize"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		do while not .eof
			select case GetString(.fields("ContainerSize"))
			case "20'":	Cnt20 = GetLong(.fields("CNT"))
			case "40'":	Cnt40 = GetLong(.fields("CNT"))
			case else :	CntEtc = GetLong(.fields("CNT"))
			end select
			.Movenext
		loop
		.close
		myCnt = Cnt20 + Cnt40 + CntEtc
		myStr = ""
		if myCnt > 0 then
			if Cnt20 > 0 then myStr = myStr & " + 20'x " & Cnt20
			if Cnt40 > 0 then myStr = myStr & " + 40'x " & Cnt40
			if CntEtc > 0 then myStr = myStr & " + �� x " & CntEtc
		end if
		if myStr <> "" then myStr = mid(myStr, 4)
	end with
%>
<html>
<head>
	<title>�ʊ�SI</title>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }
		
		.pt8 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.2em; color: black; }
		.pts { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.2em; color: gray; }
		.ptm { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptl { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub DoShortCut()	
			if window.event.keyCode=27 then window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	//-->
	</SCRIPT>
</head>
<body topmargin=3 onkeydown="DoShortCut()" class=pts  >
<center>
	<table width=650 class=pts>
		<tr><td class=bline width=160>
			<table class=pts width=160>
				<tr><td width=60>�䒠�ԍ�<td class=ptl width=100><%=JobCode%>
			</table>
		<td width=20>
		<td width=150 class=bline>
			<table class=pts width=150>
				<tr><td align=center width=60>��������<td class=ptm width=90 nowrap><%=GetRefName(JobClient)%>
			</table>
		<td width=20>
		<td width=150>
			<table class=pts>
				<tr><td align=center width=60>�o�͓��t<td class=ptm width=90><u><%=formatDate(date)%></u>
			</table>
		<td width=150 class=ptx align=center><b>�A���w�}��</b>
	</table>
	<table width=650 class=pts>
		<tr valign=top>
		  <td class=bline width=300>
			<table width=100% class=pts>
				<tr><td>������ <font class=ptm><%=GetFullName(JobClient)%></font>
				<tr><td>TEL <font class=ptm><%=PIC_TEL%></font> FAX <font class=ptm><%=PIC_FAX%></font>
			</table>
		  <td class=bline width=50>
			<table width=100% class=pts>
				<tr><td align=center>�S��<tr><td align=center class=ptm><%=PIC_NAME%>
			</table>
		  <td width=10>
		  <td class=bline width=300>
			<table width=100% class=pts>
				<tr><td>�A���� <font class=ptm><%=GetCtmName(JobShipper)%></font>
				<tr><td>NACCS�@<font class=ptm><%=CTM_NACCS_CD%></font>�@TEL <font class=ptm><%=CTM_TEL%></font>
			</table>
	</table>
	<table width=650 class=pts border=1 cellspacing=0 bordercolor="#808080" bordercolorlight=#FFFFFF>
		<tr valign=top>
		  <td width=280>
			<table width=280 class=pts>
				<tr><td>�D��<td class=ptm colspan=3><%=Vessel%>
				<tr><td>�D���<td class=ptm colspan=3><%=ShipCorp%>
			</table>
		  <td colspan=2>
			<table width=350 class=pts>					
				<tr><td width=10% nowrap>�Ϗo�`<td width=45% class=ptm>(<%=POLN%>)<%=POL%>
					<td width==15% nowrap>��ی�<td width=30% class=ptm><%=CTM_ETC_CODE%>
				<tr><td>�扵�`<td class=ptm>(<%=PODN%>)<%=POD%>
					<td>���[�ԍ�<td class=ptm><%=CTM_ETC_DATA%>
			</table>
		<tr valign=top>
		  <td rowspan=4>
			<table width=280 class=pts>
				<tr><td colspan=2>Marks Numbers
				<tr><td width=60><br><td width=220 class=ptm height=120 valign=top><%=Marks%>
				<tr><td>Packages<td class=ptm><%=myStr%>
				<tr><td><td class=ptm><%=Quantity%>�@<%=Package%>
				<tr><td colspan=2>Description
				<tr><td><td class=ptm><%=Commodity%>
			</table>
		  <td colspan=2>
			<table width=350 class=pts>
				<tr><td width=60>���`��<td width=60 class=ptm><%=ETA%>
					<td width=60 align=right>������<td width=60 class=ptm nowrap><%=right(CarryDate, 5)%>
					<td width=60 align=right>Free<td width=60 class=ptm nowrap><%=right(FreeTime, 5)%>
				<tr><td>H B/L ��<td class=ptm colspan=2><%=HBL%>
					<td>Weight<td class=ptm colspan=2><%=GW%> KGS
				<tr><td>M B/L ��<td class=ptm colspan=2><%=MBL%>
					<td>M'Ment<td class=ptm colspan=2><%=CBM%> M<sup>3</sup>
				<tr valign=top><td>Container<br>No.<td class=ptm colspan=5 height=60><%=Container%>
			</table>
		<tr><td colspan=2>
			<table class=pts width=350>
				<tr height=25><td width=60>�����ꏊ<td class=ptm><%=CarryPlace%><br><%=trim(CarryTel & CarryFax)%>
			</table>
		<tr><td colspan=2>
			<table class=ptm width=350>
				<tr><td><%=ShowSign(mid(Inspection, 4, 1))%>�H�i�@<%=ShowSign(mid(Inspection, 5, 1))%>�A���@<%=ShowSign(mid(Inspection, 6, 1))%>���b�@
						<%=ShowSign(mid(Inspection, 7, 1))%>�򎖁@<%=ShowSign(mid(Inspection, 8, 1))%>�b���@<%=ShowSign(mid(Inspection, 10, 1))%>17��
				<tr><td><%=ShowSign(mid(Inspection, 9, 1))%>�]���\���i��� <u>�@�@�@�@�@�@</u>�@�j
			</table>
		<tr><td width=210>
			<table class=ptm width=100%>
				<tr><td nowrap class=pts>�\�����@<td nowrap>IC IS OLT �C�� �p�r�O
			</table>
			<td width=140 class=ptm align=center nowrap>���� �\���\�� ����
	</table>
	<table width=650 class=pts border=1 cellspacing=0 bordercolor="#808080" bordercolorlight=#FFFFFF>
		<tr align=center height=24>
			<td width=60>�\���\��<td width=50><br>
			<td width=45>�{�\��<td width=50><br>
			<td width=35>�敪<td width=30><br>
			<td width=60>�������e<td width=30><br>
			<td width=60>������<td width=30><br>
			<td width=45>������<td width=50><br>
			<td width=45>����<td width=50><br>
		<tr align=center height=24>
			<td>�ʊ֗�<td colspan=2 align=left>�@\
			<td colspan=2>��z�E���z
			<td colspan=2>�����@�@��
			<td colspan=2 align=left>�@@\
			<td colspan=2>�H�i �@��
			<td>����<td colspan=3>�Վ��J���@����
		<tr align=center height=24>
			<td>�[�i���@
			<td colspan=8>�R���e�i�[�[�i�@�f�o���g���b�N�@�f�o���q�ɕۊǁ@�q�ɕۊ�
			<td colspan=5>�g���b�N�@�`���[�^�[�@���ڕ�
	</table>
	<table width=650 class=pts border=1 cellspacing=0 bordercolor="#808080" bordercolorlight=#FFFFFF>
		<tr align=center>
			<td width=50>�o�ɓ�<td width=50>�[�i��<td width=50>��
			<td width=180>�ׁ@�n�@��<td width=120>�^�����<td width=50>�c����<td width=150>���@�l
		<tr height=30 class=ptm><td><br><td><br><td><br><td><br><td><br><td><br><td><br>
		<tr height=30 class=ptm><td><br><td><br><td><br><td><br><td><br><td><br><td><br>
		<tr height=30 class=ptm><td><br><td><br><td><br><td><br><td><br><td><br><td><br>
		<tr height=30 class=ptm><td><br><td><br><td><br><td><br><td><br><td><br><td><br>
		<tr height=30 class=ptm><td><br><td><br><td><br><td><br><td><br><td><br><td><br>
	</table>
	<table width=650 class=ptm border=1 cellspacing=0 bordercolor="#808080" bordercolorlight=#FFFFFF>
		<colgroup span=4 align=center>
		<colgroup align=left>
		<colgroup align=center>
		<tr height=24>
			<td width=130>B/L�@ORIGINAL<td width=60>/<td width=90>���@�L
			<td width=130>���i���o�ɗ�<td width=100>��
			<td width=130>���̑���ƍ���
		<tr height=24><td>(B/K�S/G) L/G<td>/<td>���@�L<td>����- �ړ���<td>��<td>�d������Ɓ@��
		<tr height=24><td>B/L SURRENDER<td>/<td>���@�L<td>����- ���<td>��<td>���ւ���Ɓ@��
		<tr height=24><td>D/O�ؑ� �� ��<td>/<td>������<td>�ہ@ �� �@��<td>��<td>�J����Ɓ@��
		<tr height=24><td>�g���b�N�@��z<td>/<td class=pts>�����E����<td>CY�CFS �����<td>��<td>SAMPLE CUT�@��
		<tr height=24><td>�R���e�i�[��z<td>/<td class=pts>�����E����<td>�� ���@�� �v<td>��<td>���b�V���O�@��
		<tr height=24><td>�o�� RSS / WEB<td>/<td class=pts>�����E����<td><br><td>��<td><br>
		<tr height=24><td>�\��ԍ� �@��<td colspan=2><br><td><br><td>��<td><br>
		<tr><td colspan=3 class=pt8 valign=top align=left height=100>�Ɩ����l<br><%=CustomRemark%>
			<td colspan=3 class=pt8 valign=top align=left height=100>�ʊ֔��l<br>
	</table>
	<table width=650 class=ptm>
		<tr><td width=300>�f����p�������
		  <td width=350 align=right>SOKO WAREHOUSE CO., LTD.
	</table>
</center>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
end if
%>

<%
function ShowSign(mySign)
	if GetLong(mySign) = 0 then
		ShowSign = "��"
	else
		ShowSign = "��"
	end if
end function
%>
