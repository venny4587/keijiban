<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
	CTM_REF = GetString(request("ref"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	with recset
		strSql = "SELECT CTM_CD, CTM_ABR, CTM_NAME FROM CUSTOMER WHERE CTM_REF = '" & CTM_REF & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
			CTM_CD = GetString(.fields("CTM_CD"))
			CTM_ABR = GetString(.fields("CTM_ABR"))
			CTM_NAME = GetString(.fields("CTM_NAME"))
		end if
		.close
	end with
%>
<HTML>
<HEAD>
	<TITLE>�݌Ɉꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 12pt; LINE-HEIGHT: 1.5em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 14pt; LINE-HEIGHT: 1.5em; color: black; }
		.ptx { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 18pt; LINE-HEIGHT: 1.5em; color: black; }
	</style>
	<SCRIPT language=javascript>
		function ShowDetail(no) {
			var win = window.open("StockGoodsView.asp?mode=2&SeqNo="+no, no, "resizable=1,scrollbars=1,width=600,height=600");
		}
		
		function DoShortCut() {
			if (window.event.keyCode==27) window.close();
			if (window.event.keyCode==80) window.print();
			if (window.event.keyCode==120) DoCopy();
		}
		
		function DoCopy() {
			var doc = document.body.createTextRange();
			doc.moveToElementText(document.all("list"));
			doc.execCommand("copy");
		}
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<div id="list">
<!--�w�b�_-->
	<table width=640 Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <tr height=30>
	  	<td nowrap width=300><%=CTM_NAME%>�a
	  	<td nowrap width=200>�݌ɏؖ���
	 	<td nowrap width=140 align=right><%=formatDate(date)%>
	</table>
<!--���׍s-->
<%
	with Recset
		strSQL = "SELECT SeqNo, StockCode, StockName, StockPkgCnt, StockPkgZan, StockDate FROM TBL_CTM_STOCK"
		strSQL = strSQL & " WHERE Deleted = 0 AND StockType = 0 AND StockClient = '" & CTM_CD & "'"
		strSQL = strSQL & " ORDER BY StockName, StockDate"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
%>
	<TABLE width=640 Cellspacing=3 CellPadding=3 class=pts>
		<colgroup span=3 align=left>
		<colgroup align=right>
		<TR valign=bottom>
			<TD width=80>�i��
			<TD width=400>���i��
			<TD width=120>���ɗ���
			<TD width=40>�݌�
<%
			cnt = 1:	sum = 0
			SeqNo = 0
			StockName = ""
			StockList = ""
			StockPkgZan = 0
			do while not .eof
				if StockName <> GetString(.fields("StockName")) then
					if StockName <> "" and StockPkgZan <> 0 then
%>
		<TR valign=top style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=SeqNo%>')">
			<TD class=upline nowrap><%=StockCode%>
			<TD class=upline><%=StockName%>
			<TD class=upline><%=StockList%>
			<TD class=upline nowrap><%=formatnumber(StockPkgZan, 0, true)%>
<%
						cnt = cnt + 1
						sum = sum + StockPkgZan
					end if
					SeqNo = GetLong(.fields("SeqNo"))
					StockCode = GetString(.fields("StockCode"))
					StockName = GetString(.fields("StockName"))
					StockList = ""
					StockPkgZan = 0
					if StockCode = "" then StockCode = "<BR>"
				end if
				StockDate = Str2YMD(.fields("StockDate"))
				StockList = StockList & StockDate & "-" & GetLong(.fields("StockPkgCnt")) & "<br>"
				StockPkgZan = StockPkgZan + GetLong(.fields("StockPkgZan"))
				.movenext
			loop
			if StockCode <> "" then
				sum = sum + StockPkgZan
%>
		<TR valign=top style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=SeqNo%>')">
			<TD class=upline nowrap><%=StockCode%>
			<TD class=upline><%=StockName%>
			<TD class=upline><%=StockList%>
			<TD class=upline nowrap><%=formatnumber(StockPkgZan, 0, true)%>
<%
			end if
%>
		<TR><td class=upline colspan=3 align=right>�݌ɍ��v
			<TD class=upline nowrap><%=formatnumber(sum, 0, true)%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�������f�[�^�͌�����܂���ł����B</font>"
		end if
	end with
%> 
</div>
</center>
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>