<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�x���`�[���ה�p����
'----------------------------------------------

	SeqNo = GetLong(request("SeqNo"))
	JobCode = GetPost(request("JobCode"))
	ExpenseCost = GetLong(request("ExpenseCost"))
	ExpenseAttr = GetLong(request("ExpenseAttr"))
	ExpenseBill = UCASE(GetPost(request("ExpenseBill")))
	ExpenseMemo = GetPost(request("ExpenseMemo"))
	Remarks = GetPost(request("Remarks"))
	
	if ExpenseBill <> "" then
		if ExpenseAttr = 0 and left(ExpenseBill, 3) <> "CHS" then
			JobCode = ""
			ShowMessage "�Y�����鐿�����ԍ��͗��֐������ł͂���܂���B"
		end if
		
		if ExpenseAttr = 1 and left(ExpenseBill, 3) = "CHS" then
			JobCode = ""
			ShowMessage "�Y�����鐿�����ԍ��͗��֐������ł��B"
		end if
	end if
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")	
		
	if JobCode <> "" and ExpenseBill <> "" then
		with Recset				
			strSql = "SELECT ConfirmerID FROM TBL_CTM_CHARGE WHERE JobCode = '" & JobCode & "' AND ChargeNo = '" & ExpenseBill & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if .eof then 
				JobCode = ""
			else
				ConfirmerID = GetLong(.fields("ConfirmerID"))
			end if
			.close
		end with
		
		if JobCode = "" then
			ShowMessage "�Y�����鐿�����ԍ��͕s���ł��B"
		elseif ConfirmerID <> 0 then
			JobCode = ""
			ShowMessage "�Y�����鐿�����ԍ��͊��Ɋm�肳��܂����B"
		end if
	end if
	
	if JobCode <> "" then
			
		strSql = "UPDATE TBL_CTM_EXPENSE SET ExpenseCost = " & ExpenseCost
		strSql = strSql & ", ExpenseAttr = " & ExpenseAttr
		strSql = strSql & ", ExpenseBill = '" &  FitSel(ExpenseBill) & "'"
		strSql = strSql & ", ExpenseMemo = '" &  FitSel(ExpenseMemo) & "'"
		strSql = strSql & ", Remarks = '" &  FitSel(Remarks) & "'"
		strSql = strSql & ", Updater = " &  WebUserID & ", Updated = GETDATE()"
		strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
		Conn.Execute strSql
%>
<html>
	<script language=javascript>
		window.opener.location.href = "PaymentList.asp?JobCode=<%=JobCode%>";
		window.close();
	</script>
</html>
<%	
	end if
	set Recset = nothing
	CloseDB Conn
%>