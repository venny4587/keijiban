<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<%	
	myType = GetLong(request("type"))
	myMode = GetLong(request("mode"))
	JobCode = GetPost(request("JobCode"))
	CostsNo = GetPost(request("CostsNo"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT * FROM TBL_CTM_COSTS WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
		.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if not .eof then
			CostsDate = GetString(.fields("CostsDate"))
			CostsBillNo = GetString(.fields("CostsBillNo"))
			CostsClient = GetString(.fields("CostsClient"))
		end if
		.close
	end with
	
	if CostsBillNo <> "" then
		CheckFlag = 0
		Response.Buffer = True
		
		filePath = "http://127.0.0.1/scripts/CORP/Programs/HttpXml/GetChargeInfo.asp?Jobcode=" & CostsBillNo

		set HttpXML = server.CreateObject("MSXML2.XMLHTTP")
		HttpXML.open "GET", filepath, False
		HttpXML.send
		CleanXML = HttpXML.responseStream

		Set objDoc = Server.CreateObject("Msxml2.DOMDocument")
		objDoc.async = false
		objDoc.Load(CleanXML)
		
		set objRoot = objDoc.documentElement
		If not objRoot Is Nothing Then
			set objNode = objRoot.selectSingleNode("//response")
			If not objNode Is Nothing Then			
				set objDataList = objRoot.ChildNodes
				
				CheckFlag = 1
				
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Expense"
				
				Conn.BeginTrans
				Recset.Open "SELECT * FROM TBL_CTM_EXPENSE", Conn, adOpenKeyset, adLockOptimistic 
				
				For Each objRecord In objDataList
					
					cmdSQL.Execute
					mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
					
					with Recset
						.AddNew
						.fields("JobCode") = JobCode
						.fields("SeqNo") = mySeq
						.fields("ExpenseClient") = CostsClient
						.fields("ExpenseDate") = CostsDate
						.fields("ExpenseType") = gsStand
						if myMode then
							.fields("ExpenseAttr") = 0			'����
						else
							.fields("ExpenseAttr") = 1			'����
						end if
						
						set objField = objRecord.selectSingleNode("ExpenseCost")
						.fields("ExpenseCost") = GetLong(objField.text)
						set objField = objRecord.selectSingleNode("ExpensePrice")
						.fields("ExpensePrice") = GetDouble(objField.text)
						set objField = objRecord.selectSingleNode("ExpenseQuantity")
						.fields("ExpenseQuantity") = GetDouble(objField.text)
						set objField = objRecord.selectSingleNode("ExpenseUnit")
						.fields("ExpenseUnit") = GetString(objField.text)
						set objField = objRecord.selectSingleNode("ExpenseAmount")
						.fields("ExpenseAmount") = GetLong(objField.text)
						.fields("ExpenseTaxName") = "��ې�"
						.fields("ExpenseTax") = 0
						
						.fields("ExpensePay") = CostsNo
						.fields("ExpenseMemo") = ""
						.fields("Remarks") = "DC��荞��"
						
						.fields("Updater") = WebUserID
						.fields("Creater") = WebUserID
						.update
					end with
					
					if err.number <> 0 then exit for
				next
				Recset.Close
				
				'�x���`�[�X�V
				CostsAmount = 0
				CostsTax = 0
				with Recset
					strSql = "SELECT SUM(ExpenseAmount) AS CostsAmount, SUM(ExpenseTax) AS CostsTax FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpensePay = '" & CostsNo & "'"
					strSql = strSql & " AND ExpenseType IN (" & gsPayment & "," & gsStand & ")"
					.Open strSql,conn,adOpenStatic,adLockReadOnly 
					if not .eof then
						CostsAmount = GetLong(.fields("CostsAmount"))
						CostsTax = GetLong(.fields("CostsTax"))
					end if
					.close
				end with
				
				strSql = "UPDATE TBL_CTM_COSTS SET CostsAmount = " &  GetLong(CostsAmount) & ", CostsTax = " &  GetLong(CostsTax)
				strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
				Conn.Execute strSql
				
				if err.number = 0 then
					Conn.CommitTrans
					response.redirect "CostsList.asp?JobCode=" & JobCode & "&CostsNo=" & CostsNo & "&Type=" & myType
				else
					CostsNo = ""
					Conn.RollbackTrans
					response.write err.number & ":" & err.description
				end if
			end if
		end if
		
		set objRoot = nothing
		set objDoc = nothing
		
	end if
	
	if CheckFlag = 0 OR CostsNo = "" then
		response.write "�Y������f�[�^�͌�����܂���ł����B" 
	end if
%>
