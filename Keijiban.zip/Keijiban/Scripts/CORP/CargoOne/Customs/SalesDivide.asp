<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next
dim JobCode
dim JobClient
		
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 0)
	
	SeqNo = GetLong(request("seq"))
	if JobCode <> "" and SeqNo <> 0 then		
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
			strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				mode = 1
				ExpenseClient = GetString(.fields("ExpenseClient"))
				ExpenseCost = GetLong(.fields("ExpenseCost"))
				ExpenseType = GetLong(.fields("ExpenseType"))
				ExpenseAttr = GetLong(.fields("ExpenseAttr"))
				ExpenseDate = Str2Date(.fields("ExpenseDate"))
				ExpenseMemo = GetString(.fields("ExpenseMemo"))
				
				ExpenseQuantity = GetDouble(.fields("ExpenseQuantity"))
				ExpenseUnit = GetString(.fields("ExpenseUnit"))
				ExpensePrice = GetDouble(.fields("ExpensePrice"))
				ExpenseAmount = GetLong(.fields("ExpenseAmount"))
				ExpenseTaxName = GetString(.fields("ExpenseTaxName"))
				ExpenseTax = GetLong(.fields("ExpenseTax"))
				Remarks = GetString(.fields("Remarks"))
			end if
			.close
		end with
%>
<html>
<HEAD>
	<TITLE>�ʊ֗��ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
		end sub
		
		sub ExpenseCode_OnBlur()
			if frmInput.ExpenseCode.value <> "" then
				buf = len(frmInput.ExpenseCode.value)
				for each obj in frmInput.ExpenseCost.options
					if left(obj.text, buf) = ucase(frmInput.ExpenseCode.value) then
						obj.selected = true
						exit for
					end if
				next
			end if
		end sub
		
		sub ExpensePrice_OnBlur()
			frmInput.ExpensePrice.value = FitZero(formatnumber(GetDouble(frmInput.ExpensePrice.value),2,true))
			Call CalculateSales()
		end sub
		sub ExpenseQuantity_OnBlur()
			frmInput.ExpenseQuantity.value = GetDouble(frmInput.ExpenseQuantity.value)
			Call CalculateSales()
		end sub
		sub CalculateSales()
		dim buf
			if frmInput.ExpenseCost.options(frmInput.ExpenseCost.selectedIndex).value <> "123" then
				buf = GetDouble(frmInput.ExpensePrice.value) * GetDouble(frmInput.ExpenseQuantity.value)
				frmInput.ExpenseAmount.value = formatnumber(ResetDigital(buf, 0, 0), 0, true)
				Call CalculateTax()
			end if
		end sub
		
		sub ExpenseTax_OnBlur()
			frmInput.ExpenseTax.value = formatnumber(GetLong(frmInput.ExpenseTax.value),0,true)
		end sub
		sub ExpenseAmount_OnBlur()
			frmInput.ExpenseAmount.value = formatnumber(GetLong(frmInput.ExpenseAmount.value),0,true)
			Call CalculateTax()
		end sub
		sub ExpenseTaxName_OnChange()
			Call CalculateTax()
		end sub
		sub CalculateTax()
		dim buf
			if frmInput.ExpenseCost.options(frmInput.ExpenseCost.selectedIndex).value <> "123" then
				buf = frmInput.ExpenseTaxName.options(frmInput.ExpenseTaxName.selectedIndex).text
				buf = GetLong(frmInput.ExpenseAmount.value) * GetTaxRate(buf)
				frmInput.ExpenseTax.value = formatnumber(ResetDigital(buf, 0, -1), 0, true)	
			end if
		end sub
		
		sub DoSave()
		dim buf
			if checkDouble("ExpensePrice","�x���P��",3) = false then exit sub
			if checkDouble("ExpenseQuantity","�x������",1) = false then exit sub
			if checkNum("ExpenseAmount","�Ŕ����z",3) = false then exit sub
			if checkNum("ExpenseTax","����Ŋz",3) = false then exit sub
			if GetLong(frmInput.ExpenseAmount.value) > <%=ExpenseAmount%> then
				frmInput.ExpenseAmount.focus()
				msgbox "�����Ŕ����z�͕��������傫���ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			buf = frmInput.ExpenseCost.options(frmInput.ExpenseCost.selectedIndex).value
			if buf = "<%=ExpenseCost%>" then
				frmInput.ExpenseCost.focus()
				msgbox "����捀�ږ��͕������Ɠ����ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if buf = "123" or buf = "113" then
				if checkText("ExpenseMemo","���ڔ��l",1) = false then exit sub
			else
				if checkText("ExpenseMemo","���ڔ��l",0) = false then exit sub
			end if
			if msgbox ("�������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then frmInput.submit()
		end sub
	</script>
</Head>
<body bgcolor="<%=gsSalesBackColor%>" onkeydown="DoShortCut()"  topmargin=10 class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="SalesSave.asp" method="post">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=18>
	  	<td width=50%>���ʊ֗��ڍו���
	  	<td width=50% align=right><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><TD><br>
	  <TR>
	  	<TD>��������
	  <TR height=28 valign=bottom>
		<TD align=center width=60 nowrap>������
		<TD colspan=3 class=gline><%=GetFullName(ExpenseClient)%><br>
		<TD align=center width=60 nowrap>����Ŋz
		<TD align=center class=gline><%=formatnumber(ExpenseTax, 0, true)%><br>
		<TD align=center width=60 nowrap>�Ŕ����z
		<TD align=center class=gline><%=formatnumber(ExpenseAmount, 0, true)%><br>
	  <TR height=28 valign=bottom>
		<TD align=center>��������
		<TD colspan=3 class=gline><%=GetExpenseName(ExpenseCost)%><br>
		<TD align=center class=pt9>���ڔ��l
		<TD colspan=3 class=gline><%=ExpenseMemo%><br>
	  <TR><TD><br>
	  <TR>
	  	<TD>�������
	  <TR height=28>
		<TD>����<input class=si name="ExpenseCode" size=3 maxlength=3 value="" onkeydown="ResetEnter()">
		<TD colspan=3><select name="ExpenseCost" onkeydown="ResetEnter()"><%=ShowExpenseList(7)%></select>
		<TD align=center class=pt9>���ڔ��l
		<TD colspan=3><input class=sj name="ExpenseMemo" size=40 maxlength=50 value="" onkeydown="ResetEnter()">
	  <TR height=28>
		<TD align=center width=60 nowrap>�����P��
		<TD><input class=sn name="ExpensePrice" size=10 maxlength=8 value="" onkeydown="ResetEnter()">
		<TD align=center width=60 nowrap>��������
		<TD><input class=sn name="ExpenseQuantity" size=8 maxlength=8 value="" onkeydown="ResetEnter()">
		<TD align=center width=60 nowrap>�����P��
		<TD><select name="ExpenseUnit" onkeydown="ResetEnter()"><%=ShowCategoryList("ChargeUnit", ExpenseUnit, 1)%></select>
		<TD align=center width=60 nowrap>�Ŕ����z
		<TD><input class=sn name="ExpenseAmount" size=12 maxlength=8 value="" onkeydown="ResetEnter()">
	  <TR height=28>
		<TD align=center>�ېŋ敪
		<TD><select name="ExpenseTaxName" onkeydown="ResetEnter()"><%=ShowCategoryList("TaxCode", ExpenseTaxName, 1)%></select>
		<TD align=center class=pt9>�����
		<TD><input class=sn name="ExpenseTax" size=8 maxlength=8 value="" onkeydown="ResetEnter()">
		<TD align=center colspan=2>
		<TD align=center colspan=2 rowspan=2>
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DoSave()">
	  <TR height=28>
		<TD class=pt9 align=center>����
		<TD colspan=5><textarea name="Remarks" rows=4 style="width:350"><%=Remarks%></textarea>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function GetExpenseName(myDft)
	GetExpenseName = ""	
	with Recset			
		strSql = "SELECT COST_NAME FROM MST_COST WHERE COST_ID = " & myDft
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then GetExpenseName = GetString(.Fields("COST_NAME"))
		.close
	end with
end function

function ShowExpenseList(myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT COST_ID, COST_CD, COST_NAME FROM MST_COST"
	mySql = mySql & " WHERE COST_DELETED = 0"	' AND COST_TYPE = 2
	mySql = mySql & " ORDER BY COST_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("COST_ID")
		if myDft = myRec.fields("COST_ID") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("COST_CD") & " " & myRec.fields("COST_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowExpenseList = buf	
end function
%>
