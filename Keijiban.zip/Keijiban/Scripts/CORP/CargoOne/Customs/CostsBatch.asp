<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�o�b�`�Ǘ��w�b�_���
'----------------------------------------------

'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim BatchNo
dim BatchClient
dim BatchBillDay
dim BatchPayDay
dim Remarks

dim mySubmit
dim mySort
dim myCode
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	BatchNo = GetString(Request("BatchNo"))
	BatchBelong = GetString(Request("BatchBelong"))
%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="javascript" src="../common/css/calendar_JP.js"></SCRIPT> 
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
		<SCRIPT LANGUAGE=vbscript>						
			function ConfirmDelete(myNo)
				if msgbox("�Y���o�b�`�����폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "CostsBatch0.asp?BatchNo=" & myNo & "&p=<%=myPage%>&s=<%=mySort%>&BatchBelong=<%=BatchBelong%>"
				End If
			End function
			
			sub ShowDetail(myNo)
				window.parent.parent.result.location.href = "CostsBatchDetail.asp?p=<%=myPage%>&s=<%=mySort%>&BatchBelong=<%=BatchBelong%>&BatchNo=" & myNo
				'window.location.href = "CostsBatch.asp?p=<%=myPage%>&s=<%=mySort%>&BatchBelong=<%=BatchBelong%>&BatchNo=" & myNo
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "CostsBatch.asp?s=<%=mySort%>&BatchBelong=<%=BatchBelong%>&p=" & myPage
			end sub
		</SCRIPT>
	</HEAD>
	<BODY class=pt9 <%=gsBodyControl%>>
		<TABLE width=100% class=pt9n>
			<TR><TD width=100% ALIGN=center VALIGN=TOP>	
				<%
					strSQL = ""
					strSQL = strSQL & "SELECT BatchNo,"
					strSQL = strSQL & "       BatchBelong,"
					strSQL = strSQL & "       BatchType,"
					strSQL = strSQL & "       CTM_REF,"
					strSQL = strSQL & "       CTM_NAME,"
					strSQL = strSQL & "       BatchBillDay,"
					strSQL = strSQL & "       BatchPayDay,"
					strSQL = strSQL & "       ConfirmerID,"
					strSQL = strSQL & "       BatchCnt,"
					strSQL = strSQL & "       BatchAmnt,"
					strSQL = strSQL & "       Creater,"
					strSQL = strSQL & "       Remarks"
					strSQL = strSQL & "  FROM TBL_CTM_BATCH AS B INNER JOIN CUSTOMER AS C ON B.BatchClient = C.CTM_CD"
					strSQL = strSQL & "  LEFT JOIN (SELECT CostsBatch, COUNT(CostsNo) AS BatchCnt, SUM(CostsAmount+CostsTax) AS BatchAmnt"
					strSQL = strSQL & "  FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsBatch <> '' GROUP BY CostsBatch) AS T ON B.BatchNo = T.CostsBatch"
					strSQL = strSQL & " WHERE SUBSTRING(BatchNo,1,1)= '" & gsBatchBill & "' AND Deleted = 0 AND FinisherID = 0"
					if BatchBelong <> "" then 
						strSQL = strSQL & " AND BatchBelong = '" & BatchBelong & "'"
					else
						if CheckTopLevel() < 1 then strSQL = strSQL & " AND BatchBelong = '" & UserShop & "'"
					end if
					Select Case mySort
					Case "kb"
						strSQL = strSQL & " ORDER BY BatchType, BatchNo;"
					Case "bk"
						strSQL = strSQL & " ORDER BY Remarks, BatchNo;"
					Case "jp"
						strSQL = strSQL & " ORDER BY BatchNo DESC;"
					Case "en"
						strSQL = strSQL & " ORDER BY BatchBillDay, BatchNo;"
					Case "cn"
						strSQL = strSQL & " ORDER BY BatchCnt DESC, BatchNo;"
					Case "mn"
						strSQL = strSQL & " ORDER BY BatchAmnt DESC, BatchNo;"
					Case "cd"
						strSQL = strSQL & " ORDER BY CTM_REF,BatchNo;"
					Case else
						strSQL = strSQL & " ORDER BY ConfirmerID, BatchNo;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
if WebUserID = gsAdmin then response.write strSQL
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize * 2
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=12>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										
									</TR>
								</table>
							
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=5%>No.
							<TD class=line nowrap width=5%><a class=bar href="CostsBatch.asp?s=de&BatchBelong=<%=BatchBelong%>">�폜</a>
							<TD class=line nowrap width=5%>�戵
							<TD class=line nowrap width=5%><a class=bar href="CostsBatch.asp?s=kb&BatchBelong=<%=BatchBelong%>">�敪</a>
							<TD class=line nowrap width=10%><a class=bar href="CostsBatch.asp?s=jp&BatchBelong=<%=BatchBelong%>">�ޯ���</a>
							<TD class=line nowrap width=10%><a class=bar href="CostsBatch.asp?s=cd&BatchBelong=<%=BatchBelong%>">�x����</a>
							<TD class=line nowrap width=10%><a class=bar href="CostsBatch.asp?s=en&BatchBelong=<%=BatchBelong%>">���ߓ�</a>
							<TD class=line nowrap width=5%><a class=bar href="CostsBatch.asp?s=cn&BatchBelong=<%=BatchBelong%>">����</a>
							<TD class=line nowrap width=15%><a class=bar href="CostsBatch.asp?s=mn&BatchBelong=<%=BatchBelong%>">���z</a>
							<TD class=line nowrap width=10%><a class=bar href="CostsBatch.asp?s=bk&BatchBelong=<%=BatchBelong%>">���l</a>
							<TD class=line nowrap width=5%>�ҏW
							<TD class=line nowrap width=5%>����
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize * 2
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize * 2 Then
										Exit Do
									else
										myClient = GetString(.Fields("CTM_REF"))
										myName = GetString(.Fields("CTM_NAME"))
										myMemo = GetString(.Fields("Remarks"))
										select case GetBatchType(GetString(.Fields("BatchNo"))) 
										case 0 
											mycolor = "blue"
										case 1
											mycolor = "black"
										case else
											mycolor = "red"
										end select
						%>
						<TR align=center>
							<TD class=line><%=lngCount%><BR>
						<%	if GetLong(.Fields("ConfirmerID")) = 0 then %>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("BatchNo")%>')">
						<%	else%>
							<TD class=line nowrap>�~
						<%	end if %>
							<TD class=line nowrap><%=GetShopName(.Fields("BatchBelong"))%><BR>
							<TD class=line nowrap><%=GetJobDivision(.Fields("BatchType"))%><BR>
							<TD class=line nowrap style="color:<%=mycolor%>"><%=GetString(.Fields("BatchNo"))%><BR>
							<TD class=line nowrap align=left title="<%=myName%>"><%=stringCut(myClient,8)%><BR>
							<TD class=line nowrap><%=Str2MD(.Fields("BatchBillDay"))%><BR>
							<TD class=line nowrap align=right><%=GetLong(.Fields("BatchCnt"))%><BR>
							<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("BatchAmnt")), 0, true)%><BR>
							<TD class=line nowrap align=left <%=ShowTitle(myMemo, 8)%>>
								<font class=pt9><%=stringCut(myMemo,8)%></font><BR>
						<%
							If BatchNo = GetString(.Fields("BatchNo")) Then
								Response.Write "<TD class=line nowrap>..."
							Else
								Response.Write "<TD class=line nowrap><A href=""javascript:ShowDetail('" & GetString(.Fields("BatchNo")) & "')""><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A>"
							End If
						%>
							<TD class=line nowrap>
								<A HREF="CostsBatchMain.asp?no=<%=.Fields("BatchNo")%>"><IMG SRC='img/group.gif' ALT='�Ɖ�' STYLE='cursor:hand' BORDER=0></A>
							
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>

<%
function GetBatchType(myBatch)
dim mySql
dim myRec
dim myCnt
	myCnt = 0
	GetBatchType = -1 
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT DISTINCT CostsType FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsBatch = '" & myBatch & "'"
		.Open mySql,conn,adOpenStatic,adLockReadOnly
		do while not .eof
			myCnt = myCnt + 1
			GetBatchType = GetLong(.fields("CostsType"))
			.movenext
		loop
		.Close
	end with
	set myRec = nothing
	if myCnt > 1 then GetBatchType =  -1
end function
%>