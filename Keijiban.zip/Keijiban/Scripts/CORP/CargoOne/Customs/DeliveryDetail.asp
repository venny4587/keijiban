<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim JobBelong
dim JobBroker
dim JobClient
dim JobShipper
dim JobFinisher
dim JobCarryPlace
	
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 0)	
	myLevel = CheckUserLevel(JobBelong, JobBroker)
		
	SeqNo = GetLong(request("seq"))
	if JobCode <> "" then
		mode = 0
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset		
			if SeqNo <> 0 then
				strSql = "SELECT * FROM TBL_CTM_DELIVERY WHERE Deleted = 0"
				strSql = strSql & " AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					OrderDate = Str2Date(.fields("OrderDate"))
					OrderTime = GetString(.fields("OrderTime"))
					DeliveryDate = Str2Date(.fields("DeliveryDate"))
					DeliveryTime = GetString(.fields("DeliveryTime"))
					DeliveryBroker = GetString(.fields("DeliveryBroker"))
					DeliveryType = GetString(.fields("DeliveryType"))
					DeliveryFrom = GetString(.fields("DeliveryFrom"))
					DeliveryTo = GetLong(.fields("DeliveryTo"))
					Contents = GetString(.fields("Contents"))
					Remarks = GetString(.fields("Remarks"))
					
					Creater = GetLong(.fields("Creater"))
					Created = GetDate(.fields("Created"))
					Updater = GetLong(.fields("Updater"))
					Updated = GetDate(.fields("Updated"))
				end if
				.close
				
				strSql ="SELECT DOOR_PIC, DOOR_TEL, DOOR_FAX, DOOR_ADDR1+' '+DOOR_ADDR2 AS DOOR_ADDR"
				strSql = strSql &  " FROM CTM_DOOR WHERE DOOR_ID = " & GetLong(DeliveryTo)
				.Open strSql, Conn, adOpenKeyset, adLockReadOnly
				if not .eof then
					DOOR_PIC = GetString(.fields("DOOR_PIC"))
					DOOR_TEL = GetString(.fields("DOOR_TEL"))
					DOOR_FAX = GetString(.fields("DOOR_FAX"))
					DOOR_ADDR = GetString(.fields("DOOR_ADDR"))
				end if
				.close
			else
				OrderDate = formatDate(dateadd("d",1,date))
				DeliveryBroker = JobBroker
				DeliveryFrom = JobCarryPlace
			end if
		end with
		
%>
<html>
<HEAD>
	<TITLE>�[�i��z�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=Javascript src="../common/css/function.js"></SCRIPT>
	<SCRIPT language=Javascript>
	<!--
		function GetDoorInfo() 
		{
			//var buf = frmInput.Remarks.value;
			frmInput.DOOR_PIC.value = "";
			frmInput.DOOR_TEL.value = "";
			frmInput.DOOR_FAX.value = "";
			frmInput.DOOR_ADDR.value = "";
			frmInput.Remarks.value = "";
			var obj = frmInput.DeliveryTo;
			var door = obj.options[obj.selectedIndex].value;
			loadXMLDoc("../HttpXml/GetMstInfo.asp?mode=DoorInfo&DOOR_ID=" + door);
			//if (! buf == null) frmInput.Remarks.value = buf;
		}
	-->
	</SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoPrint()		
			set win = window.open("DeliveryPrint.asp?JobCode=<%=JobCode%>&seq=<%=SeqNo%>","DeliveryPrint","scrollbars=1,width=800,height=600")
			win.focus()
		end sub		
		
		sub DoContents()
			dim win, sel
			sel = frmInput.DeliveryType.options(frmInput.DeliveryType.selectedindex).value
			set win = window.open("ContainerSel.asp?JobCode=<%=JobCode%>&SeqNo=<%=SeqNo%>&sel=" & sel,"ContainerSel","resizable=0,StatusBar=0,scrollbars=1,width=600,height=500")
			win.focus()
		end sub
		
		sub OrderDate_OnBlur()
			frmInput.OrderDate.value = setdate(frmInput.OrderDate.value)
		end sub	
		sub OrderTime_OnBlur()
			if len(frmInput.OrderTime.value) >=4 then
				frmInput.OrderTime.value = setTime(frmInput.OrderTime.value)
			end if
		end sub		
		sub DeliveryDate_OnBlur()
			frmInput.DeliveryDate.value = setdate(frmInput.DeliveryDate.value)
		end sub		
		sub DeliveryTime_OnBlur()
			if len(frmInput.DeliveryTime.value) >=4 then
				frmInput.DeliveryTime.value = setTime(frmInput.DeliveryTime.value)
			end if
		end sub		
		
		sub DataSave()
			if checkDate("OrderDate","�W�ד��t",1) = false then exit sub
			if checkDate("DeliveryDate","�[�i���t",1) = false then exit sub
			if checkText("DeliveryTime","�[�i����",0) = false then exit sub
			if checkText("DeliveryFrom","�N�_",0) = false then exit sub
			if checkText("Contents","�[�i���e",1) = false then exit sub
			if checkLen("Contents","�[�i���e",250) = false then exit sub
			if frmInput.DeliveryTo.SelectedIndex = 0 then
				if checkText("Remarks","�[�i����", 1) = false then exit sub
			else
				if checkText("Remarks","�[�i����", 0) = false then exit sub
			end if
			if checkLen("Remarks","�[�i����", 250) = false then exit sub
<%if gsPolite = 0 then%>
			frmInput.submit()
<%else%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then frmInput.submit()
<%end if%>
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
<%if JobFinisher = 0 then%>	
					call DataSave() 
<%end if%>
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
		
		sub InitForm()
<%	if JobFinisher <> 0 or myLevel < 1 then %>
			call LockAll()
<%	else %>
			frmInput.OrderDate.focus()
<%	end if %>
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="DeliveryUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="ContainerSel" value="">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR valign=bottom><td width=30%>���[�i�ڍ�&nbsp;
<%if mode = 1 then%>
	<%if JobFinisher = 0 and myLevel > 0 then%>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
	<%end if%>
		  <img style="cursor:hand" src=img/sheet.jpg alt="�z�Ԉ˗��[" onmousedown="DoPrint()">
<%end if%>
		<td width=40%>�䒠�ԍ��F<%=JobCode%><%if SeqNo <> 0 then response.write "�@�}�ԁF" & SeqNo%>
		<td width=30% align=right>
<%	if JobFinisher <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="���b�N�ς�">
<%	elseif myLevel > 0 then %>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
<%	end if %>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <colgroup align=center>
	  <colgroup align=left>
	  <colgroup align=center>
	  <colgroup align=left>
	  <TR>
	  	<TD><img src=img/spacer.gif height=10>
	  <TR height=24>
		<TD width=70 nowrap>�W�ד��t
		<TD width=260 nowrap><input class=si name="OrderDate" size=10 maxlength=10 value="<%=OrderDate%>" onkeydown="ResetEnter()" 
						<%if JobFinisher = 0 then%> onclick="setday(this)"<%end if%>>
		�@	<font color=gray>�W�׎���</font>&nbsp;<input class=sz name="OrderTime" size=5 maxlength=5 value="<%=OrderTime%>" onkeydown="ResetEnter()">
		<TD width=60 nowrap>�^���Ǝ�
		<TD width=160 nowrap><select name="DeliveryBroker" onkeydown="ResetEnter()" <%if JobFinisher <> 0 then response.write "disabled" %>>
				<%=ShowBrokerList(DeliveryBroker)%></select>
	  <TR height=24>
		<TD>�[�i���t<TD><input class=si name="DeliveryDate" size=10 maxlength=10 value="<%=DeliveryDate%>" onkeydown="ResetEnter()" 
						<%if JobFinisher = 0 then%> onclick="setday(this)"<%end if%>>			
		�@	<font color=gray>�[�i����</font>&nbsp;<input class=sz name="DeliveryTime" size=5 maxlength=5 value="<%=DeliveryTime%>" onkeydown="ResetEnter()">
		<TD>�[�i���@<TD><select name="DeliveryType" onkeydown="ResetEnter()" <%if JobFinisher <> 0 then response.write "disabled" %>>
				<%=ShowCategoryList("Delivery", DeliveryType, 1)%></select>
	  <TR height=24>
		<TD>�[�i�N�_<TD><input class=sj name="DeliveryFrom" size=40 maxlength=100 value="<%=DeliveryFrom%>" onkeydown="ResetEnter()">
		<TD>�[�i���e<TD><%if JobFinisher = 0 then%><a href="javascript:DoContents()"><img src=img/table.JPG border=0 alt="�ڍ�"></a><%end if%>
	  <TR height=24 class=pt9>
		<TD>�[�i�I�_<TD><select name="DeliveryTo" onkeydown="ResetEnter()" onChange="GetDoorInfo()" <%if JobFinisher <> 0 then response.write "disabled" %>>
				<%=ShowDoorList(JobClient, DeliveryTo)%></select>
		<TD colspan=2 rowspan=3><textarea class=sz name="Contents" rows=5 style="width:200"><%=Contents%></textarea>
	  <TR height=24 class=pt9>
		<TD>�S����<TD><input class=si name="DOOR_PIC" size=40 maxlength=50 value="<%=DOOR_PIC%>" readonly onkeydown="ResetEnter()">
	  <TR height=24 class=pt9>
		<TD>TEL<TD colspan=2><input class=si name="DOOR_TEL" size=18 maxlength=50 value="<%=DOOR_TEL%>" readonly onkeydown="ResetEnter()">
			FAX<input class=si name="DOOR_FAX" size=18 maxlength=50 value="<%=DOOR_FAX%>" readonly onkeydown="ResetEnter()">
	  <TR height=24 class=pt9>
		<TD>�Z��<TD colspan=3><input class=si name="DOOR_ADDR" size=75 maxlength=250 value="<%=DOOR_ADDR%>" readonly onkeydown="ResetEnter()">
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24 class=pt9>
		<TD>�@����<TD colspan=2><textarea class=sj name="Remarks" rows=4 style="width:300"><%=Remarks%></textarea>
		<TD align=center>
<%if gsSaveButton = 1 and  JobFinisher = 0 and myLevel > 0 then%>
			<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" name=btnClose value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=24 align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline ><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline ><%=formatDate(Updated)%><br>
	</TABLE>
<center>
<%if SeqNo = 0 then%>
<SCRIPT language=Javascript>GetDoorInfo();</SCRIPT>
<%end if%>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function ShowBrokerList(myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT CTM_CD, CTM_REF FROM CUSTOMER WHERE CTM_TRUCKER = 1 AND CTM_CD <> 'Z'"
	mySql = mySql & " ORDER BY CTM_REF"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CTM_CD")
		if myDft = myRec.fields("CTM_CD") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("CTM_REF")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowBrokerList = buf	
end function

function ShowDoorList(myCtm, myDft)
dim mySql
dim myRec
dim buf
	buf = ""
	
	buf = buf & "<option value=0"
	if myDft = "" then buf = buf & " selected"
	buf = buf & ">�[�i�����ɋL��"
	
	buf = buf & "<option value=80"
	if myDft = "80" then buf = buf & " selected"
	buf = buf & ">�f��������Ё@�ېőq��"	
	
	mySql = "SELECT DOOR_ID, DOOR_CD, DOOR_NAME FROM CTM_DOOR WHERE CTM_CD = '" & myCtm & "'"
	mySql = mySql & " ORDER BY DOOR_CD, DOOR_NAME"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("DOOR_ID")
		if myDft = GetLong(myRec.fields("DOOR_ID")) then buf = buf & " selected"
		buf = buf & ">" & StringCut(myRec.fields("DOOR_NAME"), 18)
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowDoorList = buf	
end function
%>
