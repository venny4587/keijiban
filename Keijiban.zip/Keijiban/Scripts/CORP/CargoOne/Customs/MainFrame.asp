<%
	JobCode = cstr(request("JobCode") & "")
	if instr(JobCode, " ") <> 0 then JobCode = ""
	if JobCode = "" then 
		title = "�ʊ֋Ɩ����C�����"
		leftUrl = "customsNew.asp"
	else
		title = "�ʊ֑䒠�ԍ��F " & JobCode
		leftUrl = "customsEdit.asp?JobCode=" & JobCode
	end if
	
	rightUrl = "../common/blank.htm"
	mode = clng("0" & request("mode"))
	if mode = 1 then
		leftUrl = "ChargeInfo.asp?mode=" & mode & "&JobCode=" & JobCode & "&ChargeNo=" & request("ChargeNo")
		rightUrl = "ExpenseInfo.asp?JobCode=" & JobCode
	elseif mode = 2 then
		leftUrl = "CostsInfo.asp?mode=" & mode & "&JobCode=" & JobCode & "&CostsNo=" & request("CostsNo")
		rightUrl = "ExpenseInfo.asp?JobCode=" & JobCode
	end if
%>
<HTML>
<HEAD>
<TITLE><%=title%></TITLE>
</HEAD>
	<FRAMESET cols="580,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="<%=leftUrl%>" NAME="ctms" MARGINWIDTH="0" MARGINHEIGHT="0">
		<FRAME SRC="<%=rightUrl%>" NAME="info" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>