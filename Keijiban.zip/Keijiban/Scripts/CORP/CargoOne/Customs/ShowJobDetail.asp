<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<%	
	JobCode = GetPost(request("JobCode"))
	
	if JobCode <> "" then
		JobCode = left(JobCode, 10)
		Response.Buffer = True 
		'filePath = "http://127.0.0.1/scripts/CORP/programs/HttpXml/GetCustomInfo.asp?jobcode=" & JobCode
		filePath = "http://keijiban.8800.org/scripts/CORP/programs/HttpXml/GetCustomInfo.asp?jobcode=" & JobCode
		
		set HttpXML = server.CreateObject("MSXML2.XMLHTTP")
		HttpXML.open "GET", filepath, False
		HttpXML.send
		CleanXML = HttpXML.responseStream

		Set objDoc = Server.CreateObject("Msxml2.DOMDocument")
		objDoc.async = false
		objDoc.Load(CleanXML)

		set objRoot = objDoc.documentElement
		If not objRoot Is Nothing Then
			set objNode = objRoot.selectSingleNode("//response")
			If not objNode Is Nothing Then			
				set objField = objNode.selectSingleNode("JobNo")
				if not objField Is Nothing Then JobNo = GetString(objField.text)
				set objField = objNode.selectSingleNode("EdaNo")
				if not objField Is Nothing Then EdaNo = GetString(objField.text)
				set objField = objNode.selectSingleNode("Vessel")
				if not objField Is Nothing Then Vessel = GetString(objField.text)
				set objField = objNode.selectSingleNode("Voy")
				if not objField Is Nothing Then Voy = GetString(objField.text)
				set objField = objNode.selectSingleNode("ETD")
				if not objField Is Nothing Then ETD = Str2Date(objField.text)
				set objField = objNode.selectSingleNode("ETA")
				if not objField Is Nothing Then ETA = Str2Date(objField.text)
				set objField = objNode.selectSingleNode("MBL")
				if not objField Is Nothing Then MBL = GetString(objField.text)
				set objField = objNode.selectSingleNode("HBL")
				if not objField Is Nothing Then HBL = GetString(objField.text)
				set objField = objNode.selectSingleNode("GW")
				if not objField Is Nothing Then GW = GetDouble(objField.text)
				set objField = objNode.selectSingleNode("CBM")
				if not objField Is Nothing Then CBM = GetDouble(objField.text)
				set objField = objNode.selectSingleNode("Quantity")
				if not objField Is Nothing Then Quantity = GetDouble(objField.text)
				set objField = objNode.selectSingleNode("Package")
				if not objField Is Nothing Then Package = GetString(objField.text)
				set objField = objNode.selectSingleNode("Commodity")
				if not objField Is Nothing Then Commodity = GetString(objField.text)
				set objField = objNode.selectSingleNode("Marks")
				if not objField Is Nothing Then Marks = GetString(objField.text)
				set objField = objNode.selectSingleNode("Container")
				if not objField Is Nothing Then Container = GetString(objField.text)
				set objField = objNode.selectSingleNode("JobShipper")
				if not objField Is Nothing Then JobShipper = GetString(objField.text)
				set objField = objNode.selectSingleNode("RequireDate")
				if not objField Is Nothing Then RequireDate = Str2Date(objField.text)
				set objField = objNode.selectSingleNode("ShipCorp")
				if not objField Is Nothing Then ShipCorp = GetString(objField.text)
				set objField = objNode.selectSingleNode("ShipPic")
				if not objField Is Nothing Then ShipPic = GetString(objField.text)	
			end if
		end if
		
		set objRoot = nothing
		set objDoc = nothing
		
	end if
	
	if JobCode = "" then
		response.write "�Y������f�[�^�͌�����܂���ł����B" 
	else
%>
<html>
<HEAD>
	<TITLE>�q��B/L���捞��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=javascript src="../common/css/function.js"></script>
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT LANGUAGE=javascript>
	<!--
		function DoUpdate() {
			if (window.opener.frmInput.JobNo != null) window.opener.frmInput.JobNo.value = frmInput.JobNo.value;
			if (window.opener.frmInput.EdaNo != null) window.opener.frmInput.EdaNo.value = frmInput.EdaNo.value;
			if (window.opener.frmInput.Vessel != null) window.opener.frmInput.Vessel.value = frmInput.Vessel.value;
			if (window.opener.frmInput.Voy != null) window.opener.frmInput.Voy.value = frmInput.Voy.value;
			if (window.opener.frmInput.ETD != null) window.opener.frmInput.ETD.value = frmInput.ETD.value;
			if (window.opener.frmInput.ETA != null) window.opener.frmInput.ETA.value = frmInput.ETA.value;
			if (window.opener.frmInput.MBL != null) window.opener.frmInput.MBL.value = frmInput.MBL.value;
			if (window.opener.frmInput.HBL != null) window.opener.frmInput.HBL.value = frmInput.HBL.value;
			if (window.opener.frmInput.GW != null) window.opener.frmInput.GW.value = frmInput.GW.value;
			if (window.opener.frmInput.CBM != null) window.opener.frmInput.CBM.value = frmInput.CBM.value;
			if (window.opener.frmInput.Commodity != null) window.opener.frmInput.Commodity.value = frmInput.Commodity.value;
			if (window.opener.frmInput.Quantity != null) window.opener.frmInput.Quantity.value = frmInput.Quantity.value;
			if (window.opener.frmInput.Package != null) window.opener.frmInput.Package.value = frmInput.Package.value;
			if (window.opener.frmInput.Container != null) window.opener.frmInput.Container.value = frmInput.Container.value;
			if (window.opener.frmInput.Marks != null) window.opener.frmInput.Marks.value = frmInput.Marks.value;
			if (window.opener.frmInput.RequireDate != null) window.opener.frmInput.RequireDate.value = frmInput.RequireDate.value;
			if (window.opener.frmInput.ShipCorp != null) window.opener.frmInput.ShipCorp.value = frmInput.ShipCorp.value;
			if (window.opener.frmInput.ShipPic != null) window.opener.frmInput.ShipPic.value = frmInput.ShipPic.value;
			window.close();
		}
	//-->
	</SCRIPT>
</Head>
<body topmargin=3 class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="ShowJobDetail.asp" method="post">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	    <td width=50%>��CORP���&nbsp;
	</table>
	<hr width=96% size=1 color=blue>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=30>
		<TD colspan=3 class=pt9g>�䒠�ԍ� <input class=si name="JobCode" size=10 maxlength=10 value="<%=JobCode%>" onkeydown="ResetEnter()" readonly>
			(<input class=sn name="JobNo" size=6 maxlength=8 value="<%=JobNo%>" onkeydown="ResetEnter()">
			-<input class=sn name="EdaNo" size=6 maxlength=8 value="<%=EdaNo%>" onkeydown="ResetEnter()">)
			<input type=hidden name="JobShipper" value="<%=JobShipper%>">
			�����׎� <input class=si name="ClientName" size=36 maxlength=100 value="<%=GetFullName(JobShipper)%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
	  	<TD colspan=3>VESSEL <input class=si name="Vessel" size=15 maxlength=50 value="<%=Vessel%>" onkeydown="ResetEnter()">
		�@�@VOY <input class=si name="Voy" size=8 maxlength=20 value="<%=Voy%>" onkeydown="ResetEnter()">
		�@�@ETD <input class=si name="ETD" size=10 maxlength=10 value="<%=ETD%>" onkeydown="ResetEnter()">
		�@�@ETA <input class=si name="ETA" size=10 maxlength=10 value="<%=ETA%>" onkeydown="ResetEnter()">
	  <TR height=30>
	  	<TD colspan=3>�D��� <input class=si name="ShipCorp" size=25 maxlength=100 value="<%=ShipCorp%>" onkeydown="ResetEnter()">
		�@	MBL�@<input class=si name="MBL" size=15 maxlength=50 value="<%=MBL%>" onkeydown="ResetEnter()">
		�@	HBL�@<input class=si name="HBL" size=15 maxlength=50 value="<%=HBL%>" onkeydown="ResetEnter()">
	  <TR height=30>
	  	<TD colspan=3>�A���� <input class=si name="ShipPic" size=20 maxlength=100 value="<%=ShipPic%>" onkeydown="ResetEnter()">
	 	�@	�� <input class=sn name="Quantity" value="<%=Quantity%>" size=8 maxlength=10 OnKeyDown="ResetEnter()">
		�@	<input class=si name="Package" value="<%=Package%>" size=8 maxlength=10 OnKeyDown="ResetEnter()">
		�@	�[�i��] <input class=si name="RequireDate" size=10 maxlength=10 value="<%=RequireDate%>" onkeydown="ResetEnter()">
	  <TR height=30>
	  	<TD colspan=3>�i�� <input class=si name="Commodity" size=40 maxlength=255 value="<%=Commodity%>" onkeydown="ResetEnter()">
		�@	<input class=sn name="GW" value="<%=GW%>" size=8 maxlength=10 OnKeyDown="ResetEnter()"> KGS
		�@	<input class=sn name="CBM" value="<%=CBM%>" size=8 maxlength=10 OnKeyDown="ResetEnter()"> M<sup>3</sup>
	  <TR height=30 class=pt9t>
	  	<TD>���Ň� <br><textarea name="Container" rows=8 style="width:190"><%=Container%></textarea>
		<TD>�}�[�N <br><textarea name="Marks" rows=8 style="width:190"><%=Marks%></textarea>
		<TD align=center><input type=button style="width:100;height:40" name=btnUpdate value="�㏑��" onclick="DoUpdate()">
	</table>
</center>
<SCRIPT language=Javascript>
<!--
//loadXMLDoc("http://127.0.0.1/scripts/CORP/programs/HttpXml/GetJobInfo.asp?mode=jobinfo&jobcode=<%=jobcode%>");
//loadXMLDoc("http://keijiban.8800.org/scripts/CORP/programs/HttpXml/GetJobInfo.asp?mode=jobinfo&jobcode=<%=jobcode%>");
//-->
</SCRIPT>
</body>
</html>
<%		
	end if
%>

