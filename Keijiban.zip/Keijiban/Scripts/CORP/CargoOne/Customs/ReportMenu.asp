<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<html>
<head>
	<title>Main Menu Bar</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)		
		btnDetail.style.color = "black"
		btnBenefit.style.color = "black"
		btnMonthly.style.color = "black"
		btnBalance.style.color = "black"
		btnShift.style.color = "black"
		btnSales.style.color = "black"
		btnCosts.style.color = "black"
		select case mySel 
		case 1
			url = "ReportDetail.asp"
			btnDetail.style.color = "red"
		case 2
			url = "ReportBenefit.asp"
			btnBenefit.style.color = "red"
		case 3
			url = "ReportMonthly.asp"
			btnMonthly.style.color = "red"
		case 4
			url = "ReportBalance.asp"
			btnBalance.style.color = "red"
		case 5
			url = "ReportMonthlyShift.asp"
			btnShift.style.color = "red"
		case 6
			url = "ReportMonthlySales.asp"
			btnSales.style.color = "red"
		case 7
			url = "ReportMonthlyCosts.asp"
			btnCosts.style.color = "red"
		case else
			url = "../common/blank.htm"
		end select
		window.parent.report.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnDetail value="���x���׈ꗗ" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnBenefit value="�q�ʎ��x�ꗗ" onclick="DoAct(2)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnMonthly value="���x���шꗗ" onclick="DoAct(3)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnBalance value="�q�ʎc������" onclick="DoAct(4)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnShift value="���ʋq�ʐ���" onclick="DoAct(5)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnSales value="�q�ʔ��㐄��" onclick="DoAct(6)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnCosts value="�ƎҎx������" onclick="DoAct(7)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
