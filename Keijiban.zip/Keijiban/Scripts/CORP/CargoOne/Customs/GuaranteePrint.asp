<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%

SeqNo = GetLong(request("seq"))
JobCode = GetPost(request("JobCode"))
if JobCode <> "" then

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM TBL_CTM_PAPER WHERE Deleted = 0 AND JobCode = '" & JobCode & "' ORDER BY PaperMode DESC"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			NO = GetString(.fields("PaperNo"))
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POL = GetString(.fields("POL"))
			POD = GetString(.fields("POD"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Container = replace(GetString(.fields("Container")), vbcrlf, "<br>")
			if Container = "" then Container = "�@N/M"
			
			Shipper = GetString(.fields("Shipper"))
			ShipCorp = GetString(.fields("ShipCorp"))
			Remarks = GetString(.fields("Remarks"))
		end if
		.close
	end with
%>
<html>
<head>
	<title>Letter Of Guarantee</title>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<style>
		.pts { FONT-FAMILY: Century; FONT-SIZE: 9pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptm { FONT-FAMILY: Century; FONT-SIZE: 10pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptl { FONT-FAMILY: Century; FONT-SIZE: 12pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: Century; FONT-SIZE: 20pt; LINE-HEIGHT: 1.2em; color: black; }	
			
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }
	</style>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub DoShortCut()	
			if window.event.keyCode=27 then window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	//-->
	</SCRIPT>
</head>
<body topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
	<table cellspacing="10" cellpadding="10" class=pts>
	  <tr align=center height=40>
		<td width=450 class=bline align=center>
			LETTER OF GUARANTEE FOR PRODUCTION OF BILLS OF LADING
	</table>
	<br>
	<table width=600 class=ptm>
		<tr><td nowrap>
			Messrs. <%=ucase(ShipCorp)%><br><br>
			Dear Sirs,<br>
			<label style="width:50"><br></label>
			In consideration of your granting us delivery of the undermentioned Cargo ex<br><br>
			M.S.<br>
			S.S. <u>" <%=Vessel%> V.<%=Voy%> "</u> at <u> <%=FitSpace(POD, 10)%> </u> 
			on <u> <%=formatEngDate(ETA)%> </u> from <u> <%=FitSpace(POL, 10)%> </u><br><br>
	</table>
	<br>
	<table width=600 class=pts border=1 cellspacing=0 cellpadding=2 bordercolor="#808080" bordercolorlight=#FFFFFF>
		<tr align=center>
			<td width=80>Nos.of B/L
			<td width=100>Nos.&marks
			<td width=80>Packages
			<td width=140>Description of<br>Goods
			<td width=100>Shippers
			<td width=100>Remarks.
		<tr height=200 valign=top>
			<td><br><%=NO%>
			<td><br><%=Container%>
			<td><br><%=Quantity%><%=Package%>
			<td><br><%=Commodity%>
			<td><br><%=Shipper%>
			<td><br><%=Remarks%>
	</table>
	<br>
	<table width=600 class=ptm>
		<tr><td colspan=4>
		�@�@WHICH cargo we declare to have been shipped to our consignment, but Bills of Lading for which have not been received, we hereby engage to hand you the said Bills of Lading as soon as we receive them and we further guarantee to indemnify yourselves and/or the owners of the said vessel against any claims that may be made by other parties on account of the aforesaid Cargo, and to pay to you on demand any freight, demurrage or other charges that may be due here or that may have remained unpaid at the port of shipment in respect of the above mentioned goods.<br>
		�@�@In the event of the Bills of Lading for the cargo herein mentioned being hypothecated to any other Bank, Company, firm or person we further guarantee to hold you harmless from all consequences whatsoever arising therefrom and furthermore undertake to inform you immediately in the event of the Bills of Lading being so hypothecated.<br>
		�@�@And we further undertake and agree that no statement relating to the contents, quantity weight, numbers, marks and/or value of the goods inserted herein shall limit in any way our liability or that of the bankers hereunder.<br>
		<br><br>
		<tr><td><td align=right>Yours faithfully,
		<tr><td>
			<table cellspacing=2 cellpadding=2 class=pts>
			  <tr align=center><td width=160 class=bline>Banker�fs Endorsement
			</table>
		<tr><td width=160><td width=140><td width=100>Consignee<br><br><td width=200>
		<tr><td colspan=4><label style="width:50"><br></label>
			We hereby guarantee the performance of the above Contract.
	</table>
</center>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
end if
%>

<%
function FitSpace(myStr, myLen)
dim buf, spc
	buf = GetString(myStr)
	if len(buf) < myLen then
		spc = (myLen - len(buf)) \ 2
		buf = space(spc) & buf & space(myLen - len(buf) - spc)
	else
		buf = " " & buf & " "
	end if
	FitSpace = replace(buf, " ", "&nbsp;")
end function
%>