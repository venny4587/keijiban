<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim mode
dim myCode

	mode = GetLong(request("mode"))
	seqNo = GetPost(request("seqNo"))
	ClientCode = GetPost(request("Client"))
	
	myCode = GetPost(request("cd"))
	selCode = replace(myCode, "'", "''")
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	StockCode = ""
	if seqNo <> "" then
		with Recset
			StrSql = "SELECT GoodsKey, GoodsName, ReferNo, Status FROM TBL_CTM_STOCK_GOODS WHERE seqNo = " & seqNo
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				StockCode = GetString(.fields("GoodsKey"))
				StockName = GetString(.fields("GoodsName"))
				StockReferNo = GetString(.fields("ReferNo"))
				StockStatus = GetString(.fields("Status"))
				.movenext
				if not .eof then StockCode = ""
			end if
			.close
		end with
	end if

	if StockCode <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
	if (window.opener.frmInput.StockReferNo != null) window.opener.frmInput.StockReferNo.value = "<%=StockReferNo%>";
	if (window.opener.frmInput.StockCode != null) window.opener.frmInput.StockCode.value = "<%=StockCode%>";
	if (window.opener.frmInput.StockName != null) window.opener.frmInput.StockName.value = "<%=StockName%>";
	if (window.opener.frmInput.StockStatus != null) window.opener.frmInput.StockStatus.value = "<%=StockStatus%>";
	if (window.opener.frmInput.StockPkgCnt != null) window.opener.frmInput.StockPkgCnt.focus();
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>���i����</TITLE>
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(no) {
			window.location.href = "StockGoods.asp?SeqNo=" + no;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("���i�R�[�h�܂��͏��i���̈ꕔ����͂��Ă��������B")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
		
		function ShowDetail(no) {
			var win = window.open("StockGoodsInfo.asp?SeqNo="+no, "StockGoodsInfo", "scrollbars=1,width=600,height=400");
			win.focus();
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="StockGoods.asp" NAME=frmInput>
		<input type=hidden name="mode" value="<%=mode%>">
		<input type=hidden name="Client" value="<%=ClientCode%>">
		<table class=pt9n>
			<TR height=30 align=center><TD nowrap>�@
				<font class=pt9g>�׎� : <%=GetFullName(ClientCode)%></font>�@
				���i : <input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=20 onkeydown="ResetEnter()">�@
				<INPUT TYPE=button style="cursor:hand; width:60; height:25" VALUE="����" onclick="DoSearch()">�@
				<INPUT TYPE=button style="cursor:hand; width:60; height:25" VALUE="�V�K" onclick="ShowDetail('')">
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then
			With Recset
				StrSql = "SELECT COUNT(GoodsCode) AS CNT FROM TBL_CTM_STOCK_GOODS"
				StrSql = StrSql & " WHERE Deleted = 0 AND (GoodsCode LIKE '%" & selCode & "%'"
				StrSql = StrSql & " OR GoodsName LIKE '%" & selCode & "%' OR ReferNo LIKE '%" & selCode & "%')"
				if ClientCode <> "" then StrSql = StrSql & " AND ClientCode = '" & ClientCode & "'"
if WebUserID = gsAdmin then response.write StrSql
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if GetLong(.fields("CNT")) = 0 then
					response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
				elseif GetLong(.fields("CNT")) > 30 then
					response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
				else
					.close
					
					StrSql = "SELECT SeqNo, GoodsKey, GoodsCode, GoodsName, ReferNo, Status FROM TBL_CTM_STOCK_GOODS"
					StrSql = StrSql & " WHERE Deleted = 0 AND (GoodsCode LIKE '%" & selCode & "%'"
					StrSql = StrSql & " OR GoodsName LIKE '%" & selCode & "%' OR ReferNo LIKE '%" & selCode & "%')"
					if ClientCode <> "" then StrSql = StrSql & " AND ClientCode = '" & ClientCode & "'"
					strSQL = strSQL + " ORDER BY GoodsKey"
if WebUserID = gsAdmin then response.write StrSql
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<colgroup span=6 align=left>
				<colgroup span=2 align=center>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD width=5% nowrap>��
					<TD width=10% nowrap>�i��
					<TD width=40% nowrap>�i��
					<TD width=10% nowrap>���臂
					<TD width=10% nowrap>���萔
					<TD width=20% nowrap>���iCD
					<TD width=5% nowrap>�ڍ�
					<TD width=5% nowrap>�I��
<%
						myCnt = 0
						myShortCut = ""
						Do Until .EOF	
							myCnt = myCnt + 1
							myName = GetString(.Fields("GoodsName"))
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("SeqNo") & "');"
							if myCnt < 10 then
								myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("SeqNo") & "');"
							end if			
%>
				<TR><TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("GoodsKey"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myName, 20)%>><%=StringCut(myName,20)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("ReferNo"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("Status"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("GoodsCode"))%><BR>
					<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=.Fields("SeqNo")%>')">
					<TD class=line><IMG SRC='img/open.gif' STYLE='cursor:hand' onclick="clickLine('<%=.Fields("SeqNo")%>')">
<%							
							.MoveNext
						Loop
					end if				
%>
			</table>
<%
				end if	
				.Close 
			End With
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>