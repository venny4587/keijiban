<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�o�b�`�ۑ����
'----------------------------------------------

'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim BatchNo
	dim BatchClient
	dim BatchBillDay
	dim BatchPayDay
	dim Remarks
	
	BatchNo = GetPost(Request("BatchNo"))
	BatchBelong = GetPost(Request("BatchBelong"))
	BatchType = GetPost(Request("BatchType"))
	BatchClient = GetPost(Request("ChargeClient"))
	BatchClientName = GetPost(request("ChargeName"))
	BatchPic = GetPost(Request("ChargePic"))
	BatchBillDay = GetDate(Request("BatchBillDay"))
	BatchPayDay = GetDate(Request("BatchPayDay"))
	Delivered = GetLong(Request("Delivered"))
	Remarks = GetPost(Request("Remarks"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	if BatchClient = gsDummy then
		blnEdit = False
		msg = "�Y���x����̓o�b�`�����ł��܂���B"
	elseif GetFullName(BatchClient) <> BatchClientName then
		blnEdit = False
		msg = "�Y���x����͑��݂��܂���B"
	end if
	
	If blnEdit Then	
	
		if BatchNo = "" then	
			BatchID = GetNewBatchNo(Conn, gsBatchBill)
			BatchNo = GetBatchNo(BatchID, gsBatchBill)
			strURL = "ChargeBatchMain.asp?id=" & BatchID
		end if
		
		With RecSet
			BatchCount = 0
			BatchAmount = 0
			strSQL = "SELECT COUNT(ChargeNo) AS CNT, SUM(ChargeAmount + ChargeTax) AS TTL FROM TBL_CTM_CHARGE"
			strSQL = strSQL & " WHERE Deleted = 0 AND ChargeBatch = '" & BatchNo & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				BatchCount = GetLong(.fields("CNT"))
				BatchAmount = GetLong(.fields("TTL"))
			end if
			.Close
			
			strSQL = "SELECT * FROM TBL_CTM_BATCH WHERE BatchNo = '" & BatchNo & "'"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then 
				.addnew
				.fields("BatchNo") = BatchNo
				.fields("BatchBelong") = BatchBelong
				.fields("BatchType") = BatchType
				
				.fields("Creater") = WebUserID
				.fields("Created") = now
				.fields("Deleted") = 0
			end if
				
			.fields("BatchClient") = BatchClient
			.fields("BatchPic") = BatchPic
			.fields("BatchCount") = BatchCount
			.fields("BatchAmount") = BatchAmount
			.fields("BatchBillDay") = Date2Str(BatchBillDay)
			.fields("BatchPayDay") = Date2Str(BatchPayDay)
			.fields("Remarks") = Remarks
			
			if Delivered <> 0 then
				.fields("ConfirmerID") = WebUserID
				.fields("ConfirmDate") = now
			elseif CheckUserLevel(UserShop, "") > 2 then
				.fields("ConfirmerID") = 0
			end if
			
			.fields("Updater") = WebUserID
			.fields("Updated") = now
			.update
			.close
		
		end with
				
		'�x���`�[�X�V
		strSql = "UPDATE TBL_CTM_CHARGE SET ChargePayDay = '" & Date2Str(BatchPayDay) & "'"
		strSql = strSql & " WHERE ChargeBatch = '" & BatchNo & "'"
		Conn.execute strSql
		
		
		Response.Redirect "ChargeBatchDetail.asp?BatchNo=" & BatchNo & "&p=" & Request("p") & "&s=" & Request("s") & "&BatchBelong=" & BatchBelong
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
