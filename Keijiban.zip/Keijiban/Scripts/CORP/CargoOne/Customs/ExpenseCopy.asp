<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim myRec
	dim strURL
	dim strErrMsg
	
	dim CTM_CD
	dim PATN_ID
	dim PATN_CD
	
	dim PatternID
	dim ExpenseCost
	dim ExpenseType
	dim ExpenseUnit
	dim Remarks
	
	PATN_ID = GetLong(Request("ID"))
	PATN_CD = GetPost(Request("PTN_CD"))
	CTM_CD = GetPost(Request("CTM_CD"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	
	strSQL = "SELECT * FROM MST_PATTERN WHERE PATN_ID = " & PATN_ID
	myRec.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
	if not myRec.eof then
		CHK_CD = GetString(myRec.Fields("CTM_CD"))
		PATN_TYPE = GetLong(myRec.Fields("PATN_TYPE"))
		PATN_BELONG = GetString(myRec.Fields("PATN_BELONG"))
		PATN_NAME = GetString(myRec.Fields("PATN_NAME"))
		PATN_ENAME = GetString(myRec.Fields("PATN_ENAME"))
		PATN_REMARKS = GetString(myRec.Fields("PATN_REMARKS"))
	end if
	myRec.Close
	if CHK_CD = CTM_CD then PATN_NAME = "�R�s�["
	
	
	PatternID = 0
	strSQL = "SELECT * FROM MST_PATTERN WHERE CTM_CD = '" & CTM_CD & "' AND PATN_CD = '" & PATN_CD & "'"
	myRec.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
	if not myRec.eof then PatternID = 1
	myRec.Close
	
	if PatternID = 0 then
		
		Set cmdSQL = Server.CreateObject("ADODB.Command")
		Set cmdSQL.ActiveConnection = Conn
		cmdSQL.CommandType = 4
		cmdSQL.CommandText = "DB_NEW_KEY"
		cmdSQL.Parameters.Refresh
		cmdSQL.Parameters("@SysKey").Value = "PATN_ID"	
		cmdSQL.Execute
		PatternID = GetLong(cmdSQL.Parameters("@MaxID").Value)		
		Set cmdSQL = nothing

		Set Recset = Server.CreateObject ("ADODB.Recordset")
		strSQL = "SELECT * FROM MST_PATTERN WHERE PATN_DELETED = 0 AND PATN_ID = " & PatternID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("CTM_CD") = CTM_CD
				.fields("PATN_ID") = PatternID
				.fields("PATN_CREATER") = WebUserID
				.fields("PATN_CREATED") = now
				.fields("PATN_DELETED") = 0
			End If
			.Fields("PATN_CD") = PATN_CD
			.Fields("PATN_TYPE") = PATN_TYPE
			.Fields("PATN_BELONG") = PATN_BELONG
			.Fields("PATN_NAME") = PATN_NAME
			.Fields("PATN_ENAME") = PATN_ENAME
			.Fields("PATN_REMARKS") = PATN_REMARKS	
		
			.fields("PATN_UPDATER") = WebUserID
			.fields("PATN_UPDATED") = now
			.Update 
			.Close 
		End With
	
		Set cmdSQL = Server.CreateObject("ADODB.Command")
		Set cmdSQL.ActiveConnection = Conn
		cmdSQL.CommandType = 4
		cmdSQL.CommandText = "DB_NEW_KEY"
		cmdSQL.Parameters.Refresh
		cmdSQL.Parameters("@SysKey").Value = "EXPN_ID"
			
		strSQL = "SELECT * FROM PTN_EXPENSE"
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		
		strSQL = "SELECT * FROM PTN_EXPENSE WHERE PatternID = " & PATN_ID
		myRec.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		do while not myRec.eof
			cmdSQL.Execute
			ExpenseID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		
			With RecSet
				.AddNew
				.Fields("PatternID") = PatternID
				.fields("ExpenseID") = ExpenseID
				.Fields("ExpenseCost") = myRec.Fields("ExpenseCost")
				.Fields("ExpenseType") = myRec.Fields("ExpenseType")
				.Fields("ExpenseUnit") = myRec.Fields("ExpenseUnit")
				.Fields("ExpensePrice") = myRec.Fields("ExpensePrice")
				.Fields("ExpenseTaxName") = myRec.Fields("ExpenseTaxName")
				.Fields("ExpenseMemo") = myRec.Fields("ExpenseMemo")
				.Fields("Remarks") = myRec.Fields("Remarks")
				.Fields("Creater") = WebUserID
				.Fields("Updater") = WebUserID
				.Update 
			End With
			myRec.movenext
		loop
		myRec.Close
		Recset.Close

		if err.number = 0 then
			'Conn.CommitTrans
		else
			'Conn.RollBackTrans
		end if

		Set myRec = Nothing
		Set RecSet = Nothing
		closeDB Conn
		
		msg = "�p�^�[���̃R�s�[�͖����I�����܂����B"
	else
		PatternID = PATN_ID
		msg = "�Y���p�^�[���R�[�h�͊����ł��B"
	end if
%>
<html>
<script languange=javascript>
	alert("<%=msg%>");
<%if PATN_ID <> 0 then %>
	window.location.href = "ExpensePattern.asp?cd=<%=CTM_CD%>&PATN_ID=<%=PatternID%>";
<%end if%>
</script>
</html>
<%
%>