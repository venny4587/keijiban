<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	if CTM_CD <> "" then
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�݌ɏ��Ɖ�</TITLE>	
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoSelect()
		dim obj, sel
			for each obj in frmInput.elements
				if obj.type="radio" and obj.checked then
		      		if obj.name="SeqNo" then 
		      			sel = obj.value
		      			exit for
		      		end if
				end if
			next
			if GetLong(sel) = 0 then
				msgbox "�ǋL��o�Ƀf�[�^��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
			else
				if msgbox("�Y���o�ɂɒǋL���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
				window.opener.frmInput.mode.value = 2
				window.opener.frmInput.SeqNo.value = GetLong(sel)
				window.opener.frmInput.Submit()
				window.close()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
  <center>
	<!----------��������--------->
	<FORM METHOD="POST" ACTION="StockOutSelect.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
  		<table width=96% class=pt9n>
  			<tr><td>���o�Ɉꗗ���
		</table>
		<hr width=96% size=1>
		<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		  <TR height=28><TD nowrap class=pt9g>
				�׎喼&nbsp;<%=GetFullName(CTM_CD)%>
		</table>
		
	<!----------��������--------->
<%
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		
		strSQL = "SELECT SeqNo, StockDate, StockNo, StockName, StockPkgCnt, StockStatus, StockDelivery"
		strSQL = strSQL & " FROM TBL_CTM_STOCK WHERE Deleted = 0 AND StockClient = '" & CTM_CD & "'"
		strSQL = strSQL & " AND StockType = 1 AND StockDate >= '" & Date2Str(date) & "'"
		strSQL = strSQL & " ORDER BY StockDate, StockNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<TABLE width=96% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=2 align=center>
			<colgroup span=3 align=left>
			<colgroup align=right>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=6% nowrap>�I��
			<TD width=14% nowrap>�o�ɓ�
			<TD width=20% nowrap>�o�ɇ�
			<TD width=20% nowrap>�^���Ǝ�
			<TD width=30% nowrap>�[�i��
			<TD width=10% nowrap>�o�ɐ�
<%
				Do Until .EOF
					StockName = GetString(.Fields("StockName"))
					StockDelivery = GetString(.Fields("StockDelivery"))
%>
			<TR>
				<TD nowrap class=line><input type=radio name="SeqNo" value="<%=GetLong(.Fields("SeqNo"))%>">
				<TD nowrap class=line><%=Str2YMD(.Fields("StockDate"))%><br>
				<TD nowrap class=line><%=GetString(.Fields("StockNo"))%><br>
				<TD nowrap class=line <%=ShowTitle(StockDelivery, 8)%>><%=stringCut(StockDelivery, 8)%><br>
				<TD nowrap class=line <%=ShowTitle(StockName, 15)%>><%=stringCut(StockName, 15)%><br>
				<TD nowrap class=line style="color:green"><%=formatnumber(GetLong(.Fields("StockPkgCnt")), 0, true)%>
			</TR>
<%
					.MoveNext
				Loop
%>
			
			<TR><td colspan=6 align=center><input type=button name=btnSelect value="�m��" style="width:100;height:30" onclick="DoSelect()">
		</TABLE>
<%
			else
				myFlag = 0
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"
			end if
			.Close
		end with
%>
	</FORM>
  </center>
</BODY></HTML>
<%
	end if
	
	set Recset = nothing
	CloseDB Conn
%>