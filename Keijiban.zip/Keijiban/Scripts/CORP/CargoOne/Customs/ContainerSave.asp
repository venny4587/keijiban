<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	JobCode = GetPost(request("JobCode"))
	SeqNo = GetLong(request("SeqNo"))
		
	if JobCode <> "" then
	
		OpenSql Conn, SqlServerName, DataBaseName
		
		mode = GetLong(request("mode"))
		select case mode
		
		case -1

			strSql = "UPDATE TBL_CTM_CONTAINER SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID 
			strSql = strSql & ",Updated = GETDATE()" 
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			Conn.Execute strSql
			
		case else
					
			if SeqNo = 0 then 
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Container"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
			end if
				
			set Recset = Server.CreateObject("adodb.recordset")	
			with Recset
				strSql = "SELECT * FROM TBL_CTM_CONTAINER WHERE Deleted = 0"
				strSql = strSql & " AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = GetPost(request("JobCode"))
					.fields("SeqNo") = SeqNo
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				.fields("ContainerSize") = GetPost(request("ContainerSize"))
				.fields("ContainerNo") = GetPost(request("ContainerNo"))
				.fields("BookingNo") = GetPost(request("BookingNo"))
				.fields("Remarks") = GetPost(request("Remarks"))
					
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			set Recset = nothing
			
		end select
		
		CloseDB Conn
		
		response.redirect "ContainerInfo.asp?JobCode=" & JobCode 
	end if
%>