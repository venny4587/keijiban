<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�x���`�[����
'----------------------------------------------
on error resume next

dim msg

dim JobCode
dim CostsClient
dim BatchNo
dim CostsNo
dim CostsType
dim CostsDate
dim CostsPattern
dim CostsAmount
dim CostsTax
	
	myType = GetLong(request("type"))		'0:���� 1:���� 2:���� 3:�ې�
	select case myType
	case 0:		BatchNo = ""
	case 1:		BatchNo = GetString(session("CTM_CostsBatch"))
	case else:	BatchNo = GetString(request("CostsBatch"))
	end select

	mode = GetLong(request("mode"))
	JobCode = GetPost(request("JobCode"))
	CostsNo = GetPost(request("CostsNo"))
	
	msg = ""
	if mode <> -1 and mode <> 3 then
		CostsType = GetLong(Request("CostsType"))
		CostsDate = Date2Str(Request("CostsDate"))
		CostsPattern = GetLong(Request("CostsPattern"))
		if myType = 1 then Session("CTM_CostsPattern") = CostsPattern		'�A�����͂̂���
			
		CostsClient = GetPost(request("ChargeClient"))
		CostsClientName = GetPost(request("ChargeName"))
		if CostsClient <> gsDummy then
			if GetFullName(CostsClient) <> CostsClientName then
				msg = "�Y���x����͑��݂��܂���B"
			end if
		end if
		
		'�d�����̓`�F�b�N�i�����䒠�ԍ��̓����x���悩��̐����ԍ��͏d���s�A�ɒ[�Ȃ�}�ԕt���܂��j
		if msg = "" then
			msg = CheckBillRepeat(JobCode, CostsNo, CostsClient, CostsClientName, GetPost(Request("CostsBillNo")))
			if msg <> "" then
				msg = "�Y�����萿�����͊��ɓ��͂��܂����B�i�`�[�ԍ��F" & msg & "�j"
			end if
		end if	
		
		'�ʋƖ��Ŏx���f�[�^����͂����ꍇ�o�b�`�ԍ��̓��̓`�F�b�N
		if msg = "" and myType > 1 and BatchNo <> "" then
			if CheckBatchNoExist(BatchNo, CostsClient) = false then
				msg = "�Y���o�b�`�ԍ��͊ԈႢ�܂����B"
			end if
		end if
	end if
	
if msg = "" then 

	OpenSQL Conn, SqlServerName, DataBaseName
	Conn.BeginTrans

	select case mode
	case 0, 1, 2					'�o�^
	
		if mode = 0 then						'�V�K�ԍ����s
		
			select case CostsClient
			case gsCorpCode, gsCorpSoko
				SeqNo = GetNewShanaiNo(Conn, CostsClient)
				CostsNo = GetShanaiNo(SeqNo, CostsClient)
			case else
				SeqNo = GetNewAcntNo(Conn, 2)	
				CostsNo = GetAccountNo(SeqNo, 2)
			end select
			
		elseif CheckCostsLocked(Conn, JobCode, CostsNo) then
			
			msg = "�Y���x���`�[�͊��Ɋm�肳��܂����I"
						
		end if	

		if msg = "" then
			Set Recset = Server.CreateObject ("ADODB.Recordset")
			with Recset		
				strSql = "SELECT * FROM TBL_CTM_COSTS WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = GetPost(request("JobCode"))
					.fields("CostsNo") = CostsNo
					.fields("CostsAmount") = 0
					.fields("CostsTax") = 0
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				
				.fields("CostsType") = GetLong(Request("CostsType"))
				.fields("CostsBelong") = GetPost(request("JobBelong"))
				.fields("CostsClient") = CostsClient
				.fields("CostsClientName") = CostsClientName
				.fields("CostsPic") = GetPost(Request("ChargePic"))
				.fields("CostsDate") = Date2Str(Request("CostsDate"))
				.fields("CostsCloseDay") = Date2Str(Request("CostsCloseDay"))
				.fields("CostsPayDay") = Date2Str(Request("CostsPayDay"))
				.fields("CostsBillNo") = GetPost(Request("CostsBillNo"))
				.fields("CostsBatch") = BatchNo
				
				.fields("CostsMemo") = GetPost(Request("CostsMemo"))
				.fields("CostsCheck") = GetLong(Request("CostsCheck"))
				.fields("Remarks") = GetPost(Request("Remarks"))
				
				.fields("Updater") = WebUserID
				.fields("Updated") = now()
				.update
				.close
			end with
			
			if mode = 0	then 
			
				'������ڐݒ�
				if CostsPattern <> 0 then 		'�������͑Ή�
					Call GetCostsPattern() 
				
					strSql = "UPDATE TBL_CTM_COSTS SET CostsAmount = " &  GetLong(CostsAmount) & ", CostsTax = " &  GetLong(CostsTax)
					strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
					Conn.Execute strSql
				end if
				
				if mid(gsMsgConfirm,1,1) <> "0" then msg = "�Y���x���`�[�͐V�K���s����܂����I"
				
			else
				'�x����E�������X�V
				strSql = "UPDATE TBL_CTM_EXPENSE SET ExpenseDate = '" & Date2Str(Request("CostsDate")) & "'"
				strSql = strSql & ", ExpenseClient = '" &  CostsClient & "'"
				strSql = strSql & " WHERE ExpenseType IN (" & gsPayment & "," & gsStand & ") AND ExpensePay = '" & CostsNo & "'" 	'AND JobCode = '" & JobCode & "'
				Conn.Execute strSql
				
				if mid(gsMsgConfirm,2,1) <> "0" then msg = "�Y���x���`�[�͕ۑ�����܂����I"
				
				if mode = 2	then	'�x���`�[�m��
				
					if CheckCostsMatched(Conn, JobCode, CostsNo) = false then
					
						msg = "�Y���x���`�[���z�Ɩ��׍��v���z�͈�v�ł͂���܂���I"
						
					else
					
						'��p���ڊm��
						strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = GETDATE()"
						strSql = strSql & ", ConfirmerID = " & WebUserID
						strSql = strSql & " WHERE ExpensePay = '" & CostsNo & "'"
						'strSql = strSql & " AND JobCode = '" & JobCode & "'"
						Conn.execute strSql
						
						'�x���`�[�m��
						strSql = "UPDATE TBL_CTM_COSTS SET CostsCheck = 1, ConfirmDate = GETDATE()"
						strSql = strSql & ", ConfirmerID = " & WebUserID
						strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
						strSql = strSql & " AND CostsNo = '" & CostsNo & "'"
						Conn.execute strSql
						
						'�Ɩ��f�[�^�ɐ������̍X�V
						StandSum = 0:	CostsSum = 0:	CostsTax = 0
						with Recset
							strSql = "SELECT ExpenseType, SUM(ExpenseAmount) AS TTL_COST, SUM(ExpenseTax) AS TTL_TAX"
							strSql = strSql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
							strSql = strSql & " GROUP BY ExpenseType"
							recset.Open strSql, Conn, adOpenStatic, adLockReadOnly
							do while not .eof
								select case GetLong(.fields("ExpenseType"))
								case 3
									CostsSum = GetLong(.fields("TTL_COST"))
									CostsTax = GetLong(.fields("TTL_TAX"))
								case 4
									StandSum = GetLong(.fields("TTL_COST"))
								end select
								.movenext
							loop
							.Close
						end with
						
						strSql = "UPDATE TBL_CTM_JOB SET "
						strSql = strSql & " StandSum = " & StandSum
						strSql = strSql & ",CostsSum = " & CostsSum
						strSql = strSql & ",CostsTax = " & CostsTax
						strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
						Conn.execute strSql
												
						call Payment2Biz(1, Conn, CostsNo, JobCode)		'�d��쐬
						
						if mid(gsMsgConfirm,3,1) <> "0" then msg = "�Y���x���`�[�͊m�肳��܂����I"
						
					end if
					
				end if
				
			end if			
			
		end if
		
	case 3		'�m�����
	
		if CheckCostsFinished(Conn, JobCode, CostsNo) then
		
			msg = "�Y���x���`�[�͊��ɏ�������܂����I"
			
		else
		
			call Payment2Biz(-1, Conn, CostsNo, JobCode)		'�d��폜			�t�Ɍ���
		
			'��p���ڊm�����
			strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = NULL"
			strSql = strSql & ", ConfirmerID = 0"
			strSql = strSql & " WHERE ExpensePay = '" & CostsNo & "'"
			'strSql = strSql & " AND JobCode = '" & JobCode & "'"
			strSql = strSql & " AND ExpenseBill NOT IN "					'�����m��ςݗ��֍��ڂ͑ΏۊO
			strSql = strSql & " (SELECT DISTINCT ChargeNo FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ConfirmerID <> 0 AND JobCode = '" & JobCode & "')"
			Conn.execute strSql
			
			'�x���`�[�m�����
			strSql = "UPDATE TBL_CTM_COSTS SET ConfirmDate = NULL"
			strSql = strSql & ", ConfirmerID = 0"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			strSql = strSql & " AND CostsNo = '" & CostsNo & "'"
			Conn.execute strSql
			
			if mid(gsMsgConfirm,4,1) <> "0" then msg = "�Y���x���`�[�̊m��͉�������܂����I"
			
		end if

	case -1			'�폜
	
		if CheckCostsLocked(Conn, JobCode, CostsNo) then
		
			msg = "�Y���x���`�[�͊��Ɋm�肳��܂����I"
		
		elseif CheckChargeConfirm(Conn, JobCode, CostsNo) then
		
			msg = "�Y�����֕��̐����͊��Ɋm�肳��܂����I"
		else
		
			call Payment2Biz(-1, Conn, CostsNo, JobCode)			'�d��폜
			
			'�x������ (�_���폜)
			strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 1, Updated = GETDATE(), Updater = " & WebUserID
			strSql = strSql & " WHERE ExpensePay = '" & CostsNo & "'" ' AND JobCode = '" & JobCode & "'"
			Conn.execute strSql

			'�x���`�[ (�_���폜)
			strSql = "UPDATE TBL_CTM_COSTS SET Deleted = 1"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			strSql = strSql & " AND CostsNo = '" & CostsNo & "'"
			Conn.execute strSql
			
			if mid(gsMsgConfirm,5,1) <> "0" then msg = "�Y���x���`�[�͍폜����܂����I"
		
		end if
		
	end select
	
	if err.number = 0 then 
		Conn.CommitTrans
%>

<html>
	<script language=javascript>
<%if mode = -1 then%>
		window.location.href = "../common/blank.htm";
<%elseif mode = 0 then%>
		window.location.href = "CostsList.asp?type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
<%else%>
<%	select case myType
	case 0				'����%>
		window.location.href = "CostsHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
<%	case 1 				'���� %>
		window.location.href = "CloseHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
<%	case else			'���� %>
		window.location.href = "PaymentHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&type=<%=myType%>";
<%	end select %>
<%end if%>
<%	select case myType
	case 0				'����%>
		window.parent.parent.result.location.href = "CostsResult.asp";
<%	case 1 				'���� %>
		window.parent.parent.parent.result.location.href = "CostsResult.asp?type=1";
<%	case 2 				'���� %>
		window.parent.list.location.href = "CostsBill.asp?JobCode=<%=JobCode%>";
		window.parent.parent.info.location.href = "ExpenseInfo.asp?JobCode=<%=JobCode%>";
<%	end select %>
<%if msg <> "" then%>
		alert("<%=msg%>");
<%end if%>
	</script>
</html>

<%
	else
		Conn.RollbackTrans
		ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
	end if		
	
	set Recset = nothing
	CloseDB Conn
else
	ShowMessage msg
end if 
%>


<%
'���̉�ʂ̂݌Ăяo���A�p�����[�^�s�v�A�w�b�_��`�ς�
function GetCostsPattern()
dim mySql
dim myRec
dim myRs
dim mySeq
dim myTyp
dim myPrc
dim myTax

	CostsAmount = 0
	CostsTax = 0
	
	Set cmdSQL = Server.CreateObject("ADODB.Command")
	Set cmdSQL.ActiveConnection = Conn
	cmdSQL.CommandType = 4
	cmdSQL.CommandText = "DB_CTM_NEW_SUB"
	cmdSQL.Parameters.Refresh
	cmdSQL.Parameters("@SubCode").Value = "Expense"
	
	set myRec = Server.CreateObject("adodb.recordset")
	mySql ="SELECT * FROM TBL_CTM_EXPENSE"
	myRec.Open mySql, Conn, adOpenKeyset, adLockOptimistic 
						
	set myRs = Server.CreateObject("adodb.recordset")		
	mySql = "SELECT ExpenseCost, ExpenseType, ExpensePrice, ExpenseUnit, ExpenseTaxName, ExpenseMemo, Remarks"
	mySql = mySql & " FROM PTN_EXPENSE WHERE PatternID = " & CostsPattern
	mySql = mySql & " ORDER BY ExpenseType, ExpenseCost"
	myRs.Open mySql, Conn, adOpenStatic, adLockReadOnly 		
	do while not myRs.eof 
		'SeqNo�擾	
		cmdSQL.Execute
		mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
		
		myTyp = GetLong(myRs.fields("ExpenseType"))
		if myTyp = gsCharge then myTyp = gsPayment
		
		myPrc = GetLong(myRs.fields("ExpensePrice"))
		myTax = ResetDigital(myPrc * GetTaxRate(myRs.fields("ExpenseTaxName")), 0, -1)
		
		with myRec
			.AddNew
			.fields("JobCode") = JobCode
			.fields("SeqNo") = mySeq
			.fields("ExpenseClient") = CostsClient
			.fields("ExpenseDate") = CostsDate
			.fields("ExpenseType") = myTyp
			.fields("ExpenseAttr") = 0
			
			.fields("ExpenseCost") = GetLong(myRs.fields("ExpenseCost"))				
			.fields("ExpensePrice") = myPrc
			.fields("ExpenseQuantity") = 1
			.fields("ExpenseUnit") = GetString(myRs.fields("ExpenseUnit"))
			.fields("ExpenseAmount") = myPrc
			.fields("ExpenseTaxName") = GetString(myRs.fields("ExpenseTaxName"))
			.fields("ExpenseTax") = GetLong(myTax)
			
			.fields("ExpensePay") = CostsNo
			.fields("ExpenseMemo") = myRs.fields("ExpenseMemo")
			.fields("Remarks") = myRs.fields("Remarks")
			
			.fields("Updater") = WebUserID
			.fields("Creater") = WebUserID
			.update
		end with
		
		CostsAmount = CostsAmount + myPrc
		CostsTax = CostsTax + myTax
		myRs.movenext
	loop
	myRs.close
	myRec.close
	
	set myRs = nothing
	set myRec = nothing
				
end function
%>