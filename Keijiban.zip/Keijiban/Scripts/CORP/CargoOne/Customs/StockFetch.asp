<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<%	
	myMode = GetLong(request("mode"))
	JobCode = GetPost(request("JobCode"))
	myClient = GetPost(request("Client"))
	StockNo = GetPost(request("StockNo"))
	CTM_CD = GetCtmCode(myClient, 0)
	
	if JobCode <> "" and myClient <> "" then
		JobCode = left(JobCode, 10)
		Response.Buffer = True
		filePath = "http://127.0.0.1/GetStockInfo.asp?jobcode=" & JobCode & "&Client=" & myClient & "&StockNo=" & StockNo
		StockNo = ""
		ClientCode = GetCtmCode(myClient, 0)
		
		set HttpXML = server.CreateObject("MSXML2.XMLHTTP")
		HttpXML.open "GET", filepath, False
		HttpXML.send
		CleanXML = HttpXML.responseStream

		Set objDoc = Server.CreateObject("Msxml2.DOMDocument")
		objDoc.async = false
		objDoc.Load(CleanXML)

		set objRoot = objDoc.documentElement
		If not objRoot Is Nothing Then
			set objNode = objRoot.selectSingleNode("//response")
			If not objNode Is Nothing Then			
				set objDataList = objRoot.ChildNodes
				
				OpenSQL Conn, SqlServerName, DataBaseName
				Set Recset = Server.CreateObject ("ADODB.Recordset")
				
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "StockNo"
				
				Conn.BeginTrans
				
				For Each objRecord In objDataList
					
					cmdSQL.Execute
					SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
				
					set objField = objRecord.selectSingleNode("StockNo")
					StockNo = GetPost(objField.text)
					
					with Recset
						StrSql = "SELECT * FROM TBL_CTM_STOCK WHERE StockNo = '" & StockNo & "'"
						.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
						if .eof then
							.addnew
							.fields("SeqNo") = SeqNo
							.fields("StockNo") = StockNo
							.fields("StockClient") = ClientCode
							.fields("Creater") = WebUserID
							.fields("Deleted") = 0
							
							set objField = objRecord.selectSingleNode("StockPkgZan")
							.fields("StockPkgZan") = GetLong(objField.text)
						end if
						
						set objField = objRecord.selectSingleNode("JobCode")
						.fields("JobCode") = GetString(objField.text)
						set objField = objRecord.selectSingleNode("StockDate")
						.fields("StockDate") = GetString(objField.text)
						set objField = objRecord.selectSingleNode("StockCode")
						.fields("StockCode") = GetString(objField.text)
						set objField = objRecord.selectSingleNode("StockName")
						InputName = GetString(objField.text)
						set objField = objRecord.selectSingleNode("StockPackage")
						.fields("StockPackage") = GetString(objField.text)
						set objField = objRecord.selectSingleNode("StockPkgCnt")
						.fields("StockPkgCnt") = GetLong(objField.text)
						set objField = objRecord.selectSingleNode("StockGW")
						.fields("StockGW") = GetDouble(objField.text) * 1000
						set objField = objRecord.selectSingleNode("StockCBM")
						.fields("StockCBM") = GetDouble(objField.text)
						set objField = objRecord.selectSingleNode("StockLot")
						.fields("StockLot") = GetString(objField.text)
						set objField = objRecord.selectSingleNode("StockMemo")
						.fields("StockMemo") = GetString(objField.text)
						set objField = objRecord.selectSingleNode("StockMark")
						.fields("StockMark") = GetString(objField.text)
						
						StockName = ""
						ReferNo = ""
						Status = ""
						call GetReferNo(CTM_CD, GetString(.fields("StockCode")), StockName, ReferNo, Status)
						if StockName = "" then StockName = InputName
						.fields("StockName") = StockName
						.fields("StockReferNo") = ReferNo
						.fields("StockStatus") = Status
						.fields("StockPlace") = "�ېőq��"
						.fields("StockDivision") = "����"
						
						'set objField = objRecord.selectSingleNode("StockDelivery")
						'.fields("StockDelivery") = GetString(objField.text)
						
						.fields("Updater") = WebUserID
						.fields("Updated") = now
						.update
											
						.close
					end with
					
					if err.number <> 0 then exit for
				next
			
				if err.number = 0 then
					Conn.CommitTrans
					response.redirect "StockDivide.asp?jobcode=" & JobCode & "&Client=" & myClient
				else
					StockNo = ""
					Conn.RollbackTrans
					response.write err.number & ":" & err.description
				end if
			end if
		end if
		
		set objRoot = nothing
		set objDoc = nothing
		
	end if
	
	if StockNo = "" then
		response.write "�Y������f�[�^�͌�����܂���ł����B" 
	end if
%>

<%
function GetReferNo(myClient, myKey, myName, myRefer, myStatus)
dim myRec
dim mySql
	GetReferNo = false
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT GoodsName, ReferNo, Status FROM TBL_CTM_STOCK_GOODS WHERE ClientCode = '" & myClient & "' AND GoodsKey = '" & myKey & "'"
		.Open mySql, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then 
			myName = GetString(.fields("GoodsName"))
			myRefer = GetString(.fields("ReferNo"))
			myStatus = GetString(.fields("Status"))
		end if
		.Close
	end with
	set myRec = nothing
end function 
%>
