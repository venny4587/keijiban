<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
dim JobCode, MBL, HBL, Canceled, FinisherID

JobCode = GetPost(request("JobCode"))
if JobCode <> "" then

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			JobClient = GetString(.fields("JobClient"))
			JobBelong = GetString(.fields("JobBelong"))
			JobOperator = GetString(.fields("JobOperator"))
			JobManager = GetLong(.fields("JobManager"))
			JobNo = GetString(.fields("JobNo"))
			EdaNo = GetString(.fields("EdaNo"))
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POL = GetString(.fields("POL"))
			POD = GetString(.fields("POD"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			MBL = GetString(.fields("MBL"))
			HBL = GetString(.fields("HBL"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Container = replace(GetString(.fields("Container")), vbcrlf, "<br>")
			CustomRemark = replace(GetString(.fields("CustomRemark")), vbcrlf, "<br>")
			
			JobShipper = GetString(.fields("JobShipper"))
			RequireDate = Str2Date(.fields("RequireDate"))
			Insurance = GetLong(.fields("Insurance"))
			Surrendered = GetLong(.fields("Surrendered"))
			ShipCorp = GetString(.fields("ShipCorp"))
			ShipPic = GetString(.fields("ShipPic"))
			CustomBroker = GetString(.fields("CustomBroker"))
			CarryPlace = GetString(.fields("CarryPlace"))
			CarryDate = Str2Date(.fields("CarryDate"))
			FreeTime = Str2Date(.fields("FreeTime"))
			PermitNo = GetString(.fields("PermitNo"))
			PermitDate = Str2Date(.fields("PermitDate"))
			ReturnDate = Str2Date(.fields("ReturnDate"))
			DeliveryDate = Str2MD(.fields("DeliveryDate"))
			
			Remarks = GetString(.fields("Remarks"))
			Inspection = GetString(.fields("Inspection"))
			SalesDate = formatdate(.fields("SalesDate"))
			StandDate = formatdate(.fields("StandDate"))
		end if
		.close
		
		StrSql = "SELECT CTM_ENAME, CTM_NACCS_CD, CTM_ETC_CODE, CTM_ETC_DATA FROM CUSTOMER WHERE CTM_CD = '" & JobShipper & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			CTM_ENAME = GetString(.fields("CTM_ENAME"))
			CTM_NACCS_CD = GetString(.fields("CTM_NACCS_CD"))
			CTM_ETC_CODE = GetString(.fields("CTM_ETC_CODE"))
			CTM_ETC_DATA = GetString(.fields("CTM_ETC_DATA"))
		end if 
		.close
		
		StrSql = "SELECT PIC_NAME, PIC_DPT, PIC_POS, PIC_TEL, PIC_FAX FROM CTM_PIC WHERE CTM_CD = '" & JobClient & "' AND PIC_ID = " & JobManager
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			PIC_NAME = GetString(.fields("PIC_DPT")) & " " & GetString(.fields("PIC_POS")) & " " & GetHornor(.fields("PIC_NAME"))
			PIC_TEL = GetString(.fields("PIC_TEL"))
			PIC_FAX = GetString(.fields("PIC_FAX"))
		end if
		.close
		
		StrSql = "SELECT PIC_NAME, PIC_DPT, PIC_POS, PIC_TEL, PIC_FAX FROM CTM_PIC WHERE CTM_CD = '" & CustomBroker & "' ORDER BY PIC_DFT DESC, PIC_CD"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			BROKER_PIC = GetString(.fields("PIC_DPT")) & " " & GetString(.fields("PIC_POS")) & " " & GetHornor(.fields("PIC_NAME"))
			BROKER_TEL = GetString(.fields("PIC_TEL"))
			BROKER_FAX = GetString(.fields("PIC_FAX"))
			.movenext
			if not .eof then BROKER_PIC2 = GetString(.fields("PIC_DPT")) & " " & GetString(.fields("PIC_POS")) & " " & GetHornor(.fields("PIC_NAME"))
		end if
		.close
	end with
	
	call GetEmployTelFax(JobOperator, OPERATOR_TEL, OPERATOR_FAX, OPERATOR_MAIL)
%>
<html>
<head>
	<title>�ʊ�SI</title>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<style>
		.pts { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptm { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptl { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 20pt; LINE-HEIGHT: 1.2em; color: black; }
		
		.mi{FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
		.mn{FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;TEXT-ALIGN:right}
		.mb{FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
	</style>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub DoShortCut()	
			if window.event.keyCode=27 then window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	//-->
	</SCRIPT>
</head>
<body topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
	<table width=600 class=pts>
		<tr height=40>
			<td nowrap class=ptx>�ʊ֗pINSTRUCTION
			<td nowrap valign=top align=right>
			<font class=ptm><b>�f����p�������<%if left(JobCode, 1) = gsCorpInit then%>�i�ېőq�Ɂj<%end if%></b></font>
			<br>TEL <%=OPERATOR_TEL%>
			<br>FAX <%=OPERATOR_FAX%>
	</table>
	<br>
	<table width=600 class=pts>
		<tr><td><b>�䒠�ԍ��F<input class=mb value="<%=JobCode%>" size=10 readonly>�@�S���ҁ@<input class=mi style="text-align:center" value="<%=GetEmployName(JobOperator, "F")%>" size=10 readonly>
			<td align=right>JOB No. <input class=mn value="<%=JobNo%>" size=8 readonly>�@EDA No. <input class=mn value="<%=EdaNo%>" size=8 readonly>
	</table>
	<hr width=600 size=1 color=black>
	<table width=600 border=0 class=pts>	
		<tr><td nowrap>B/L��׎�<td colspan=4 style="font-size:10pt" nowrap>
			<input class=mb value="<%=CTM_ENAME%>" size=42 readonly>�@<input class=mb value="<%=PIC_NAME%>" size=26 readonly>
		<tr height=24>
			<td width=100>�����׎�<td width=220><input class=mi value="<%=GetCtmName(JobClient)%>" size=32 readonly><td width=40 rowspan=16>
			<td width=100>TEL<td width=140><input class=mi value="<%=PIC_TEL%>" size=28 readonly><br>	
		<tr height=24>
			<td>VESSEL<td><input class=mi value="<%=Vessel%>" size=24 readonly><br>
			<td>FAX<td><input class=mi value="<%=PIC_FAX%>" size=28 readonly><br>
		<tr height=24>
			<td>VOYAGE<td><input class=mi value="<%=Voy%>" size=10 readonly><br>
			<td nowrap>NACCS CD<td><input class=mi value="<%=CTM_NACCS_CD%>" size=28 readonly><br>	
		<tr height=24>
			<td nowrap>MASTER B/L ��<td><input class=mi value="<%=MBL%>" size=20 readonly><br>
			<td>��ی�<td><input class=mi value="<%=CTM_ETC_CODE%>" size=28 readonly><br>
		<tr height=24>
			<td>HOUSE B/L ��<td><input class=mi value="<%=HBL%>" size=20 readonly><br>
			<td>���[�ԍ�<td><input class=mi value="<%=CTM_ETC_DATA%>" size=28
			 readonly><br>
	</table>
	<table width=600 class=pts border=0>	
		<tr height=24>
			<%if CheckJobType(JobCode) = "I" then%><td>���`��<td><input class=mi value="<%=ETA%>" size=10 readonly>
			<%else%><td>�o�`��<td><input class=mi value="<%=ETD%>" size=10 readonly><%end if%><br>
			<td colspan=2>�@�@�@���ʊ֔��l��
		<tr height=24>
			<td>�i��<td><input class=mi value="<%=Commodity%>" size=32 readonly><br>
			<td colspan=2 rowspan=6 class=gline valign=top> <%=CustomRemark%> <br>
		<tr height=24>
			<td>��<td><input class=mn value="<%=Quantity%>" size=10 readonly>�@<input class=mi value="<%=Package%>" size=16 readonly><br>
		<tr height=24>
			<td>WEIGHT<td><input class=mn value="<%=formatnumber(GW,3,true)%>" size=10 readonly> KGS
		<tr height=24>
			<td>MEASURE<td><input class=mn value="<%=formatnumber(CBM,3,true)%>" size=10 readonly> M<sup>3</sup> (=<%=GetKGS(GW, CBM)%>KGS)
		<tr height=24>
			<td>POL<td><input class=mi value="<%=POL%>" size=20 readonly><br>
		<tr height=24>
			<td>POD<td><input class=mi value="<%=POD%>" size=20 readonly><br>
		<tr height=24 valign=top>
			<td rowspan=4>CONTAINER ��<td colspan=2 rowspan=4 class=gline> <%=Container%> <br>	
			<td><%=ShowSign(mid(Inspection, 4, 1))%>�H�i�\���@<%=ShowSign(mid(Inspection, 5, 1))%>�A���\���@
		<tr height=24 valign=top>
			<td colspan=2 nowrap><%=ShowSign(mid(Inspection, 6, 1))%>���b�@<%=ShowSign(mid(Inspection, 7, 1))%>�򎖁@<%=ShowSign(mid(Inspection, 8, 1))%>�b��
		<tr height=24 valign=top>
			<td colspan=2 nowrap><%=ShowSign(mid(Inspection, 9, 1))%>�]���\���@
		<tr height=24 valign=top>
			<td colspan=2 nowrap><%if mid(Inspection, 9, 1) = "1" then%>&nbsp;�i��� <u>�@�@�@�@�@�@</u>&nbsp;�j<%end if%>
		<tr height=24 valign=top>
		<tr height=24>
			<td>�D���<td colspan=3><input class=mi value="<%=ShipCorp%>" size=48 readonly><br>
		<tr height=24>
			<td nowrap>�D��ИA����<td colspan=3><input class=mi value="<%=ShipPic%>" size=48 readonly><br>		
		<tr height=24>
			<td>�ݕ�������<td><input class=mi value="<%=CarryDate%>" size=10 readonly>
			�@�@FREE TIME�@<input class=mi value="<%=FreeTime%>" size=10 readonly><br>
			<td colspan=2 align=center class=pt12n>
				<b><%if Surrendered then%>���n���<%else%>�I���W�i��<%end if%></b>
		<tr height=30>
			<td>�����ꏊ<td colspan=3 class=gline><%=CarryPlace%><br>
	</table>
	<br>
	<hr width=600 size=1 color=black>
	<br>
	<table width=600 border=0 class=pts>
		<tr><td>�ʊ֋Ǝ�<td colspan=3><input class=mi value="<%=GetFullName(CustomBroker)%>" size=50 readonly>
		<tr><td>�d�b�ԍ�<td><input class=mi value="<%=BROKER_TEL%>" size=40 readonly>
			<td>�S����1<td><input class=mi value="<%=BROKER_PIC%>" size=20 readonly>
		<tr><td>FAX�ԍ�<td><input class=mi value="<%=BROKER_FAX%>" size=40 readonly>
			<td>�S����2<td><input class=mi value="<%=BROKER_PIC2%>" size=20 readonly>
	</table>
	<br><br>
	<table width=600 class=pt9n border=1 cellspacing=0 bordercolor="#808080" bordercolorlight=#FFFFFF class=pts>
		<tr align=center>
			<td width=66>�ʊ֎�z
			<td width=66>�`�^�m
			<td width=66>B/L,L/G,<br>D/O,��z
			<td width=66>�[�i��z
			<td width=66>�f�r�o
			<td width=66>�\����
			<td width=66>����
			<td width=66>�[����
			<td width=66>����
		<tr align=center height=60>
			<td class=bline><br>
			<td><br>
			<td><br>
			<td><br>
			<td><br>
			<td><br>
			<td><br>
			<td><br>
			<td><br>
	</table>
</center>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
end if
%>

<%
function ShowSign(mySign)
	if GetLong(mySign) = 0 then
		ShowSign = "��"
	else
		ShowSign = "��"
	end if
end function
%>
