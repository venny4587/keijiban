<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next
dim ExpSeq
dim myMode
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		JobType = ""
		if instr(session("Depart"), "�A��") <> 0 then JobType = gsImport
		if instr(session("Depart"), "�A�o") <> 0 then JobType = gsExport
		ClientRef = ""
		ClientCode = ""
		ExpenseCost = 52
		
		DiscountMode = 0
		DiscountRate = 0
		DigitalMode = 0
	else
		ClientRef = GetPost(request("ClientRef"))
		ClientCode = GetCtmCode(ClientRef, 0) 
		
		ExpenseCost = GetLong(request("ExpenseCost"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		AmntFrom = GetPost(request("AmntFrom"))
		AmntTo = GetPost(request("AmntTo"))
		if AmntFrom <> "" then AmntFrom = GetDouble(AmntFrom)
		if AmntTo <> "" then AmntTo = GetDouble(AmntTo)
		
		JobType = GetPost(request("JobType"))
		DiscountType = GetLong(request("DiscountType"))
		DiscountNo = GetPost(request("DiscountNo"))
		BatchNo = GetPost(request("BatchNo"))
		JobCode = GetPost(request("JobCode"))
		PayDayFrom = GetPost(request("PayDayFrom"))
		PayDayTo = GetPost(request("PayDayTo"))
		
		DiscountMode = GetLong(request("DiscountMode"))
		DiscountRate = GetDouble(request("DiscountRate"))
		DigitalMode = GetLong(request("DigitalMode"))
		
		'�ꊇ�m�菈��
		if myMode = 2 then
			msg = ""		
			myNo = ""
			myJob = "" 					
			Conn.BeginTrans
			
			ExpSeq = split(GetPost(request("ExpSeq")), ",")
			for i = 0 to ubound(ExpSeq)
				mySeq = GetLong(trim(ExpSeq(i)))
				with Recset
					strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE SeqNo = " & mySeq
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
					if not .eof then
						myAmount = GetLong(.fields("ExpenseAmount"))
						myTax = GetLong(.fields("ExpenseTax"))
						myTotal = myAmount + myTax
						myAmount = myAmount + GetLong(ResetDigital(myAmount * DiscountRate / 100, 0, DigitalMode)) * DiscountMode
						myTotal = myTotal + GetLong(ResetDigital(myTotal * DiscountRate / 100, 0, DigitalMode)) * DiscountMode
						.fields("ExpenseAmount") = myAmount
						.fields("ExpenseTax") = myTotal - myAmount
						.fields("ExpenseAttr") = 1					'�l��
						if DiscountType = 1 then
							myNo = myNo & ",'" & GetString(.fields("ExpenseBill")) & "'"
						end if
						if DiscountType = -1 then
							myNo = myNo & ",'" & GetString(.fields("ExpensePay")) & "'"
						end if
						myJob = myJob & ",'" & GetString(.fields("JobCode")) & "'"
						.update
					end if
					.Close
				end with
				
				if err.number <> 0 then exit for
			next
			
			if err.number = 0 AND myNo <> "" then
				if DiscountType = 1 then
					strSql = "UPDATE TBL_CTM_CHARGE SET ChargeAmount = (SELECT SUM(ExpenseAmount) FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.ExpenseBill = TBL_CTM_CHARGE.ChargeNo)"
					strSql = strSql & " FROM TBL_CTM_CHARGE, TBL_CTM_EXPENSE WHERE TBL_CTM_CHARGE.ChargeNo IN (" & mid(myNo, 2) & ")"
					Conn.Execute strSql
					
					strSql = "UPDATE TBL_CTM_CHARGE SET ChargeTax = (SELECT SUM(ExpenseTax) FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.ExpenseBill = TBL_CTM_CHARGE.ChargeNo)"
					strSql = strSql & " FROM TBL_CTM_CHARGE, TBL_CTM_EXPENSE WHERE TBL_CTM_CHARGE.ChargeNo IN (" & mid(myNo, 2) & ")"
					Conn.Execute strSql
					
					strSql = "UPDATE TBL_CTM_JOB SET SalesSum = (SELECT SUM(ChargeAmount) FROM TBL_CTM_CHARGE"
					strSql = strSql & " WHERE TBL_CTM_CHARGE.Deleted = 0 AND TBL_CTM_CHARGE.JobCode = TBL_CTM_JOB.JobCode)"
					strSql = strSql & "  FROM TBL_CTM_CHARGE, TBL_CTM_JOB WHERE TBL_CTM_JOB.JobCode IN (" & mid(myJob, 2) & ")"
					Conn.Execute strSql
					
					strSql = "UPDATE TBL_CTM_JOB SET SalesTax = (SELECT SUM(ChargeTax) FROM TBL_CTM_CHARGE"
					strSql = strSql & " WHERE TBL_CTM_CHARGE.Deleted = 0 AND TBL_CTM_CHARGE.JobCode = TBL_CTM_JOB.JobCode)"
					strSql = strSql & "  FROM TBL_CTM_CHARGE, TBL_CTM_JOB WHERE TBL_CTM_JOB.JobCode IN (" & mid(myJob, 2) & ")"
					Conn.Execute strSql
					
				end if
				if DiscountType = -1 then
					strSql = "UPDATE TBL_CTM_COSTS SET CostsAmount = (SELECT SUM(ExpenseAmount) FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.ExpensePay = TBL_CTM_COSTS.CostsNo)"
					strSql = strSql & "  FROM TBL_CTM_COSTS, TBL_CTM_EXPENSE WHERE TBL_CTM_COSTS.CostsNo IN (" & mid(myNo, 2) & ")"
					Conn.Execute strSql
					
					strSql = "UPDATE TBL_CTM_COSTS SET CostsTax = (SELECT SUM(ExpenseTax) FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.ExpensePay = TBL_CTM_COSTS.CostsNo)"
					strSql = strSql & "  FROM TBL_CTM_COSTS, TBL_CTM_EXPENSE WHERE TBL_CTM_COSTS.CostsNo IN (" & mid(myNo, 2) & ")"
					Conn.Execute strSql
					
					strSql = "UPDATE TBL_CTM_JOB SET CostsSum = (SELECT SUM(ExpenseAmount) FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.ExpenseType = " & gsPayment & " AND TBL_CTM_EXPENSE.JobCode = TBL_CTM_JOB.JobCode)"
					strSql = strSql & "  FROM TBL_CTM_EXPENSE, TBL_CTM_JOB WHERE TBL_CTM_JOB.JobCode IN (" & mid(myJob, 2) & ")"
					Conn.Execute strSql
					
					strSql = "UPDATE TBL_CTM_JOB SET CostsTax = (SELECT SUM(ExpenseTax) FROM TBL_CTM_EXPENSE"
					strSql = strSql & " WHERE TBL_CTM_EXPENSE.Deleted = 0 AND TBL_CTM_EXPENSE.ExpenseType = " & gsPayment & " AND TBL_CTM_EXPENSE.JobCode = TBL_CTM_JOB.JobCode)"
					strSql = strSql & "  FROM TBL_CTM_EXPENSE, TBL_CTM_JOB WHERE TBL_CTM_JOB.JobCode IN (" & mid(myJob, 2) & ")"
					Conn.Execute strSql
				end if
				
				strSql = "UPDATE TBL_CTM_JOB SET Interests = (SalesSum + SalesTax) - (CostsSum + CostsTax)"
				strSql = strSql & " FROM TBL_CTM_JOB WHERE JobCode IN (" & mid(myJob, 2) & ")"
				Conn.Execute strSql
			end if
			
			if err.number = 0 then
				Conn.CommitTrans
				msg = "�l���������͖����������܂����B"
			
				DiscountMode = 0
				DiscountRate = 0
				DigitalMode = 0
			else
				Conn.RollbackTrans
				msg = "�l�������������L�̃G���[���N����܂����B" & vbcrlf & err.number & ":" & err.description
			end if
		end if
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�������m�菈��</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoCheck()
			Call CheckAll("ExpSeq", frmInput.CheckAll.Checked)
		end function 
		
		function DoCheck2()
			Call CheckAll("ExpSeq", frmInput.CheckAll2.Checked)
		end function 
		
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "ExpSeq" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�l�����Ώ۔�ڂ�I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("�l���������s���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myJob, myNo)
<%if DiscountType = 1 then%>
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & myJob & "&ChargeNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
<%end if%>
<%if DiscountType = -1 then%>
			set win = window.open("MainFrame.asp?mode=2&JobCode=" & myJob & "&CostsNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
<%end if%>
			win.focus()
		end function
				
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
				
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub PayDayFrom_OnBlur()
			frmInput.PayDayFrom.value = setdate(frmInput.PayDayFrom.value)
		end sub
		sub PayDayTo_OnBlur()
			frmInput.PayDayTo.value = setdate(frmInput.PayDayTo.value)
		end sub
		sub AmntFrom_OnBlur()
			if frmInput.AmntFrom.value = "" then exit sub
			frmInput.AmntFrom.value = GetDouble(frmInput.AmntFrom.value)
		end sub
		sub AmntTo_OnBlur()
			if frmInput.AmntTo.value = "" then exit sub
			frmInput.AmntTo.value = GetDouble(frmInput.AmntTo.value)
		end sub
		sub DiscountNo_OnBlur()
			if frmInput.DiscountType.selectedIndex = 1 then
				frmInput.DiscountNo.value = FitChargeNo(frmInput.DiscountNo.value)
			else
				frmInput.DiscountNo.value = FitCostsNo(frmInput.DiscountNo.value)
			end if
		end sub
		sub BatchNo_OnBlur()
			if frmInput.DiscountType.selectedIndex = 1 then
				frmInput.BatchNo.value = FitPrintNo(frmInput.BatchNo.value)
			else
				frmInput.BatchNo.value = FitBatchNo(frmInput.BatchNo.value)
			end if
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
<%if myMode = 2 then%>
	<%if gsMsgBatch = 1 then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
	<%end if%>
<%else%>
			frmInput.ClientRef.focus()
<%end if%>
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="DiscountProc.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				���Ӑ�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				��p����<select name="ExpenseCost" onkeydown="ResetEnter()"><%=ShowExpenseList(ExpenseCost)%></select>		
				������<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">			
				�������z<input class=sn name="AmntFrom" value="<%=AmntFrom%>" maxlength=8 size=7 onkeydown="ResetEnter()">
					�`<input class=sn name="AmntTo" value="<%=AmntTo%>" maxlength=8 size=7 onkeydown="ResetEnter()">
			<TR><TD nowrap>						
				�Ɩ�����&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��
						<option value="<%=gsImport%>" <%if JobType=gsImport then response.write "selected"%>>�A��
						<option value="<%=gsExport%>" <%if JobType=gsExport then response.write "selected"%>>�A�o</select>
				�`�[�敪&nbsp;<SELECT name="DiscountType" onkeydown="ResetEnter()">
						<option value="-1" <%if DiscountType = -1 then response.write "selected"%>>�x��
						<option value="1" <%if DiscountType = 1 then response.write "selected"%>>����</select>
				�ԍ�<input class=si name="DiscountNo" value="<%=DiscountNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�o�b�`��<input class=si name="BatchNo" value="<%=BatchNo%>" maxlength=6 size=6 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">		
				�x����<input class=si name="PayDayFrom" value="<%=PayDayFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="PayDayTo" value="<%=PayDayTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""			
	if ClientCode <> "" then
		strSel = strSel & " AND ClientCode = '" & ClientCode & "'"
	elseif ClientRef <> "" then	
		strSel = strSel & " AND ClientName LIKE '% " & FitSel(ClientRef) & "%'"
	end if
	if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,5,1) = '" & JobType & "'" 
	if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'"
	if DateFrom <> "" then strSel = strSel & " AND ExpenseDate >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND ExpenseDate <= '" & Date2Str(DateTo) & "'"	
	if PayDayFrom <> "" then strSel = strSel & " AND ExpensePayDay >= '" & Date2Str(PayDayFrom) & "'"
	if PayDayTo <> "" then strSel = strSel & " AND ExpensePayDay <= '" & Date2Str(PayDayTo) & "'"	
	if AmntFrom <> "" then strSel = strSel & " AND (ExpenseAmount + ExpenseTax) >= " & AmntFrom
	if AmntTo <> "" then strSel = strSel & " AND (ExpenseAmount + ExpenseTax) <= " & AmntTo
	if DiscountNo <> "" then strSel = strSel & " AND ExpenseNo = '" & FitSel(ChargeNo) & "'"
	if BatchNo <> "" then strSel = strSel & " AND BatchNo = '" & FitSel(ChargeNo) & "'"
	
	with recset
		strSql = "SELECT SeqNo, JobCode, ExpenseType, ExpenseCost, ExpenseName, ClientCode, ClientName, ExpenseDate, ExpenseAmount, ExpenseTax, ExpensePayDay, ExpenseNo, BatchNo, ConfirmerID FROM"
		strSql = strSql & " (SELECT SeqNo, JobCode, ExpenseCost, ExpenseDate, ExpenseAmount, ExpenseTax, ExpenseBill, ExpensePay, ConfirmerID FROM TBL_CTM_EXPENSE WHERE Deleted = 0) AS E"
		strSql = strSql & " INNER JOIN (SELECT COST_ID, COST_NAME AS ExpenseName FROM MST_COST) AS M ON E.ExpenseCost = M.COST_ID"
		if DiscountType = 1 then		'����
			strSql = strSql & " INNER JOIN (SELECT ChargeClient AS ClientCode, ChargeClientName AS ClientName, ChargeType AS ExpenseType, ChargeNo AS ExpenseNo, ChargePayday AS ExpensePayDay"
			strSql = strSql & " , ChargeBatch AS BatchNo FROM TBL_CTM_CHARGE WHERE Deleted = 0) AS C ON E.ExpenseBill = C.ExpenseNo"
		end if
		if DiscountType = -1 then		'�x��
			strSql = strSql & " INNER JOIN (SELECT CostsClient AS ClientCode, CostsClientName AS ClientName, CostsType AS ExpenseType, CostsNo AS ExpenseNo, CostsPayday AS ExpensePayDay"
			strSql = strSql & " , CostsBatch AS BatchNo FROM TBL_CTM_COSTS WHERE Deleted = 0) AS C ON E.ExpensePay = C.ExpenseNo"
		end if
		strSQL = strSQL & " WHERE ExpenseCost = " & ExpenseCost & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY JobCode, ExpenseNo, SeqNo"
		case 1:		strSql = strSql & " ORDER BY ExpenseNo, SeqNo"
		case 2:		strSql = strSql & " ORDER BY ExpenseDate, ExpenseNo, SeqNo"
		case 3:		strSql = strSql & " ORDER BY ExpensePayDay, ExpenseNo, SeqNo"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			lngCount = 0
%>
		<TABLE width=720 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=6 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=2 align=center>
		  <TR height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>��p����
			<TD class=line nowrap>������
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�䒠�ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�`�[�ԍ�
			<TD class=line nowrap>�敪
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">������
			<TD class=line nowrap>�����z
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x����
			<TD class=line nowrap>�l����
			<TD class=line nowrap colspan=2>�S�I��<input type=checkbox name="CheckAll" value="" onclick="DoCheck()">
<%
			cnt = 0
			ttlAmount = 0
			ttlDiscount = 0
			Do while not .EOF
				lngCount = lngCount + 1
				SeqNo = GetLong(.Fields("SeqNo"))
				JobCode = GetString(.Fields("JobCode"))
				ExpenseNo = GetString(.Fields("ExpenseNo"))
				ClientName = ResetCorpName(.fields("ClientName"))	
				myAmount = GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax"))
				myDiscount = myAmount + GetLong(ResetDigital(myAmount * DiscountRate / 100, 0, DigitalMode)) * DiscountMode
%>
		<TR height=20>
			<TD class=line><%=lngCount%><BR>
			<TD class=line nowrap><%=GetString(.Fields("ExpenseName"))%><BR>
			<TD class=line nowrap><%=StringCut(ClientName, 20)%>
			<TD class=line><%=ShowJobCode(JobCode)%><BR>
			<TD class=line><%=ShowVoucherNo(ExpenseNo)%><BR>
<%		if DiscountType = 1 then %>
			<TD class=line><%=ShowBillType(.Fields("ExpenseType"))%><BR>
<%		end if %>
<%		if DiscountType = -1 then %>
			<TD class=line><%=ShowCostsType(.Fields("ExpenseType"))%><BR>
<%		end if %>
			<TD class=line nowrap style="color:green"><%=Str2MD(.Fields("ExpenseDate"))%><BR>
			<TD class=line nowrap><%=formatnumber(myAmount, 0, true)%><BR>
			<TD class=line style="color:blue"><%=Str2MD(.Fields("ExpensePayDay"))%><BR>
			<TD class=line nowrap><%=formatnumber(myDiscount, 0, true)%><BR>
			<TD class=line style="color:gray"><%if GetLong(.Fields("ConfirmerID")) = 0 then%>
				<input type=checkbox name="ExpSeq" value="<%=SeqNo%>"><%else%>��<%end if%>
			<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=JobCode%>', '<%=ExpenseNo%>')">
<%
				if GetLong(.Fields("ConfirmerID")) = 0 then cnt = cnt + 1
				ttlAmount = ttlAmount + myAmount
				ttlDiscount = ttlDiscount + myDiscount
				.movenext
			loop
			if lngCount > 1 then
%>			
		<TR height=20>
			<TD colspan=5>
			<TD class=line align=right>�� �v
			<TD class=line align=right colspan=2><%=formatnumber(ttlAmount, 0, true)%>
			<TD class=line align=right colspan=2><%=formatnumber(ttlDiscount, 0, true)%>
			<TD class=line nowrap colspan=2><input type=checkbox name="CheckAll2" value="" onclick="DoCheck2()">�S�I��
		
<%
			end if
%>
		</TABLE>
		
		<TABLE width=720 Cellspacing=3 CellPadding=3 class=pt9n>
			<tr><td align=right>	
			�l��&nbsp;<SELECT name="DiscountMode" onkeydown="ResetEnter()">
					<option value="-1" <%if DiscountMode = -1 then response.write "selected"%>>�|
					<option value="1" <%if DiscountMode = 1 then response.write "selected"%>>�{</select>
					<input class=sn name="DiscountRate" value="<%=DiscountRate%>" maxlength=5 size=5 onkeydown="ResetEnter()">��
			�[��&nbsp;<SELECT name="DigitalMode" onkeydown="ResetEnter()">
					<option value="-1" <%if DigitalMode = -1 then response.write "selected"%>>�؂�̂�
					<option value="0" <%if DigitalMode = 0 then response.write "selected"%>>�l�̌ܓ�
					<option value="1" <%if DigitalMode = 1 then response.write "selected"%>>�؂�グ</select>
			<INPUT style="width:60px;height:25px;" TYPE=submit VALUE="���Z">
<!--��ϕ|���Ȃ̂ŁA����C��ی��̂ݎ��s�\-->
<%if false then%>
<%if DiscountType = -1 AND ExpenseCost = 52 and DiscountRate <> 0 and CheckUserLevel(UserShop, "") > 2 then %>
			<INPUT style="width:60px;height:25px;" TYPE=button VALUE="���s" onclick="DoConfirm()">
<%end if%>
<%end if%>
		</TABLE>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowExpenseList(myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT COST_ID, COST_CD, COST_NAME FROM MST_COST"
	mySql = mySql & " WHERE COST_DELETED = 0"
	mySql = mySql & " ORDER BY COST_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("COST_ID")
		if myDft = myRec.fields("COST_ID") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("COST_CD") & " " & myRec.fields("COST_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowExpenseList = buf	
end function
%>