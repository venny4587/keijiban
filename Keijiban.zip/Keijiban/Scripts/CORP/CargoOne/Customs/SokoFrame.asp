<%
	JobCode = cstr(request("JobCode") & "")	
	CostsNo = cstr(request("CostsNo") & "")	
%>
<HTML>
<HEAD>
<TITLE><%=title%></TITLE>
</HEAD>
	<FRAMESET cols="*,550" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="CustomsSoko.asp?JobCode=<%=JobCode%>" NAME="Bill" MARGINWIDTH="10" MARGINHEIGHT="0">
		<FRAME SRC="PaymentHead.asp?type=3&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>" NAME="ctms" MARGINWIDTH="0" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>