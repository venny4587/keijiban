<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	SeqNo = GetLong(request("SeqNo"))
	JobCode = GetPost(request("JobCode"))
	ChargeNo = GetPost(request("ChargeNo"))
	ExpenseNo = GetPost(request("ExpenseNo"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")	
		
	if JobCode <> "" and ChargeNo <> "" then
		if CheckBillLocked(Conn, JobCode, ChargeNo) then
			JobCode = ""
			ShowMessage "�Y�����鐿�����͊��Ɋm�肳��܂����B"
		end if
	end if
	
	if JobCode <> "" then
	
		Conn.BeginTrans
		
		mode = GetLong(request("mode"))
		select case mode
		case -1

			strSql = "UPDATE TBL_CTM_KEEP SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID
			strSql = strSql & ",Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			Conn.Execute strSql
			
		case else
		
			if SeqNo = 0 then 
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "KeepNo"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)				
			end if
			
			with Recset
				strSql = "SELECT * FROM TBL_CTM_KEEP WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = GetPost(request("JobCode"))
					.fields("SeqNo") = SeqNo
					.fields("ExpenseNo") = ExpenseNo
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				
				.fields("KeepCode") = GetPost(request("KeepCode"))
				.fields("KeepInDate") = Date2Str(request("KeepInDate"))
				.fields("KeepOutDate") = Date2Str(request("KeepOutDate"))				
				.fields("KeepFreetime") = GetLong(request("KeepFreetime"))
				.fields("KeepDayCount") = GetLong(request("KeepDayCount"))				
				.fields("KeepPKG") = GetLong(request("KeepPKG"))
				.fields("KeepRTON") = GetDouble(request("KeepRTON"))				
				.fields("KeepAmount") = GetLong(request("KeepAmount"))
				.fields("KeepTaxName") = GetPost(request("KeepTaxName"))
				.fields("KeepTax") = GetLong(request("KeepTax"))				
				.fields("KeepDivision") = GetPost(request("KeepDivision"))		
				
				.fields("KeepPrice1") = GetLong(request("KeepPrice"))	'GetLong(request("KeepPrice1"))		
				.fields("KeepPrice2") = 0								'GetLong(request("KeepPrice2"))
				.fields("KeepPrice3") = 0								'GetLong(request("KeepPrice3"))		
				.fields("KeepPrice4") = 0								'GetLong(request("KeepPrice4"))								
				.fields("Remarks") = GetPost(request("Remarks"))				
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			
		end select
		
		if err.number = 0 then 
		
			Conn.CommitTrans
			
			myStr = right(request("KeepInDate"), 5) & "-" & right(request("KeepOutDate"), 5)
			myStr = myStr & "(Free:" & GetLong(request("KeepFreetime")) & ") �����F"
			myStr = myStr & GetLong(request("KeepPrice")) & "�~��" & GetLong(request("KeepDayCount")) & "��"
%>
<html>
<script language=javascript>
	window.opener.frmInput.ExpenseMemo.value = "<%=myStr%>";
	window.opener.frmInput.ExpenseAmount.value = "<%=GetLong(request("KeepAmount"))%>";
	window.opener.frmInput.ExpensePrice.value = "<%=GetLong(request("KeepPrice")) * GetLong(request("KeepDayCount"))%>";
	window.opener.frmInput.ExpenseTax.value = "<%=GetLong(request("KeepTax"))%>";
	window.opener.frmInput.ExpenseQuantity.value = "<%=GetDouble(request("KeepRTON"))%>";
	if (window.opener.frmInput.ExpenseUnit != null) {
		  var obj = window.opener.frmInput.ExpenseUnit;
		  if (obj.options[obj.selectedIndex].value!='RTON') { 
		  	for (var i=0;i<obj.options.length;i++){
		    	if (obj.options[i].value=='�l3') obj.options[i].selected = true;
		    }
		  }
	};
	window.close();
</script>
</html>
<%
		else
		
			Conn.RollbackTrans
			ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
			
		end if
	end if
	
	set Recset = nothing
	CloseDB Conn
%>