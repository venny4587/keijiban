
<html>
<head>
	<title>�����������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)			
		btnCreate.style.color = "black"
		btnConfirm.style.color = "black"
		btnPrint.style.color = "black"
		btnBatch.style.color = "black"
		btnView.style.color = "black"
		select case mySel 
		case 1
			url = "ChargeBillExec.asp"
			rst = "ChargeResult.asp?type=0"
			btnCreate.style.color = "red"
		case 2
			url = "ChargeBillProc.asp"
			rst = "ChargeResult.asp?type=1"
			btnConfirm.style.color = "red"
		case 3
			url = "ChargeBillPrint.asp"
			rst = "../common/blank.htm"
			btnPrint.style.color = "red"
		case 4
			url = "ChargeBatch.asp"	
			rst = "../common/blank.htm"
			btnBatch.style.color = "red"
		case 5
			url = "ChargeBillView.asp"	
			rst = "ReceiveResult.asp"
			btnView.style.color = "red"
		end select
		window.parent.cbody.location.href = url 
		window.parent.parent.result.location.href = rst
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnCreate value="�������쐬" onclick="DoAct(1)"></TD>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnConfirm value="�������m��" onclick="DoAct(2)"></TD>
		    <TD width=110>
		    	<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnPrint value="���������" onclick="DoAct(3)"></TD>
		    <TD width=110>
				<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnBatch value="������Ǘ�" onclick="DoAct(4)"></TD>
		    <TD width=110>
				<INPUT type=button style="WIDTH: 100px; HEIGHT: 30px;" name=btnView value="������Ɖ�" onclick="DoAct(5)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
