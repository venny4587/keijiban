<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	mode = GetLong(Request("mode"))
	JobCode = GetPost(Request("JobCode"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	with Recset
		SeqNo = 0
		strSql = "SELECT * FROM TBL_CTM_PAPER WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND PaperMode = " & mode
		.Open strSql, Conn ,adOpenKeyset ,adLockReadOnly
		if not .EOF then
			SeqNo = GetLong(.Fields("SeqNo"))
			PaperNo = GetString(.Fields("PaperNo"))
			JobClient = GetString(.Fields("JobClient"))
			
			Shipper = GetString(.Fields("Shipper"))
			Shipper1 = GetString(.Fields("Shipper1"))
			Shipper2 = GetString(.Fields("Shipper2"))
			Shipper3 = GetString(.Fields("Shipper3"))
			Shipper4 = GetString(.Fields("Shipper4"))
			Consignee = GetString(.Fields("Consignee"))
			Consignee1 = GetString(.Fields("Consignee1"))
			Consignee2 = GetString(.Fields("Consignee2"))
			Consignee3 = GetString(.Fields("Consignee3"))
			Consignee4 = GetString(.Fields("Consignee4"))
			Notify = GetString(.Fields("Notify"))
			Notify1 = GetString(.Fields("Notify1"))
			Notify2 = GetString(.Fields("Notify2"))
			Notify3 = GetString(.Fields("Notify3"))
			Notify4 = GetString(.Fields("Notify4"))
			Agent = GetString(.Fields("Agent"))
			Agent1 = GetString(.Fields("Agent1"))
			Agent2 = GetString(.Fields("Agent2"))
			Agent3 = GetString(.Fields("Agent3"))
			Agent4 = GetString(.Fields("Agent4"))
			ShipType = GetString(.Fields("ShipType"))
			ShipCorp = GetString(.Fields("ShipCorp"))
			Container20GP = GetLong(.Fields("Container20GP"))	
			Container40GP = GetLong(.Fields("Container40GP"))	
			Container40HC = GetLong(.Fields("Container40HC"))	
			Remarks = GetString(.Fields("Remarks"))		
			
			Vessel = GetString(.Fields("Vessel"))
			Voy = GetString(.Fields("Voy"))
			POL = GetString(.Fields("POL"))	
			POD = GetString(.Fields("POD"))
			ETD = Str2Date(.Fields("ETD"))
			ETA = Str2Date(.Fields("ETA"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))			
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Container = GetString(.Fields("Container"))			
		end if
		.close
		
		if SeqNo = 0 then
			StrSql = "SELECT * FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				Vessel = GetString(.fields("Vessel"))
				Voy = GetString(.fields("Voy"))
				POL = GetString(.fields("POL"))
				POD = GetString(.fields("POD"))
				ETD = Str2Date(.fields("ETD"))
				ETA = Str2Date(.fields("ETA"))
				if mode = 0 then
					PaperNo =  GetString(.fields("MBL"))
				else
					PaperNo =  GetString(.fields("HBL"))
				end if
				GW = GetDouble(.fields("GW"))
				CBM = GetDouble(.fields("CBM"))
				Commodity = GetString(.fields("Commodity"))
				Quantity = GetDouble(.fields("Quantity"))
				Package = GetString(.fields("Package"))
				Container = GetString(.fields("Marks"))
				ShipCorp = GetString(.fields("ShipCorp"))				
				Remarks = GetString(.fields("Remarks"))	
					
				JobClient = GetString(.Fields("JobClient"))
				JobShipper = GetString(.fields("JobShipper"))
			end if
			.close
			
			StrSql = "SELECT CTM_NAME, CTM_ENAME FROM CUSTOMER WHERE CTM_CD = '" & JobShipper & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				if CheckJobType(JobCode) = gsExport then Shipper = GetString(.fields("CTM_ENAME"))
				if CheckJobType(JobCode) = gsImport then Consignee = GetString(.fields("CTM_ENAME"))
			end if
			.close
		end if
	end with
	
	if mode = 0 then
		PaperTitle = "MASTER BILL OF LADING"
	else
		PaperTitle = "HOUSE BILL OF LADING"
	end if
%>
<html>
<head>
<TITLE>�a�^�k���׏��o�^</TITLE>
<meta http-equiv="Content-Type" content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
	<!--		
		sub DoSearch(no)
		dim win
			set win = window.open("LinkSearch.asp?CTM_CD=<%=JobClient%>&type=" & no,"LinkSearch","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
			win.focus()
		end sub		
		
		sub DoDelete()
			if msgbox ("�Y���Ɩ��f�[�^���폜���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DataSave()
<%if mode = 0 then%>
			if checkText("PaperNo","MB/L No.", 1) = false then exit sub
<%else%>
			if checkText("PaperNo","HB/L No.", 1) = false then exit sub
<%end if%>
			if checkText("Vessel","�D��", 1) = false then exit sub
			if checkText("Voy","�֖�", 1) = false then exit sub
			if checkText("POL","�o���`", 1) = false then exit sub
			if checkText("POD","�ړI�`", 1) = false then exit sub
			if checkDate("ETA","���`��", 1) = false then exit sub
			if checkDate("ETD","�o�`��", 1) = false then exit sub
			if checkText("Commodity","�i��", 1) = false then exit sub
			if checkDouble("Quantity","��", 2) = false then exit sub
			if checkText("Package","�׎p", 1) = false then exit sub
			if checkDouble("GW","Weight", 2) = false then exit sub
			if checkDouble("CBM","Measurement", 2) = false then exit sub
			if checkText("ShipCorp","�D���",1) = false then exit sub
			if checkText("Container","�}�[�N���",1) = false then exit sub
			if checkLen("Container","�}�[�N���",255) = false then exit sub
			if checkText("Remarks","���l", 0) = false then exit sub
			if checkLen("Remarks","���l",255) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�Ɩ��f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub ETD_OnBlur()
			frmInput.ETD.value = setdate(frmInput.ETD.value)
		end sub		
		sub ETA_OnBlur()
			frmInput.ETA.value = setdate(frmInput.ETA.value)
		end sub			
		sub Quantity_OnBlur()
			frmInput.Quantity.value = formatnumber(GetDouble(frmInput.Quantity.value),3,true)
		end sub
		sub Package_OnBlur()
			frmInput.Package.value = ucase(frmInput.Package.value)
		end sub		
		sub GW_OnBlur()
			frmInput.GW.value = formatnumber(GetDouble(frmInput.GW.value),3,true)
		end sub
		sub CBM_OnBlur()
			frmInput.CBM.value = formatnumber(GetDouble(frmInput.CBM.value),3,true)
		end sub		
						
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
			if window.event.keyCode=120 then call DataSave() 
		end sub
	//-->
	</SCRIPT>
</script>
</HEAD>

<BODY onkeydown="DoShortCut()" <%=gsBodyControl%>>
<form method = post action="PaperUpdate.asp" name="frmInput">
	<input type=hidden name="SeqNo" VALUE="<%=SeqNo%>">
	<input type=hidden name="JobCode" VALUE="<%=JobCode%>">
	<input type=hidden name="JobClient" VALUE="<%=JobClient%>">
	<input type=hidden name="PaperMode" VALUE="<%=mode%>">
	
<center>
<table width=96% border=0 cellspacing=0 cellpadding=0 class=pt9>
  <tr>
	<td width=40% align=center class=pt12><b><%=PaperTitle%></b>
	<td width=40% align=right>Bill No.<input size=15 class=si NAME="PaperNo" MAXLENGTH=20 VALUE="<%=PaperNo%>" OnKeyDown="ResetEnter()">  
</table>

<table width=96% border=0 cellspacing=1 cellpadding=2 class=pt9>
  <tr><td width=50%>
		<table class=pt9>
		  <tr><td valign=top width=80>Shipper
			<td><a href="javascript:DoSearch(1)"><img src=img/search.jpg border=0 alt="����"></a>
			<input size=45 class=si NAME="Shipper" MAXLENGTH=50 VALUE="<%=Shipper%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Shipper1" MAXLENGTH=100 VALUE="<%=Shipper1%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Shipper2" MAXLENGTH=100 VALUE="<%=Shipper2%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Shipper3" MAXLENGTH=100 VALUE="<%=Shipper3%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Shipper4" MAXLENGTH=100 VALUE="<%=Shipper4%>" OnKeyDown="ResetEnter()"><br>
		</table>
	<td width=50%>
  		<table class=pt9 width=100%>
  		  <tr height=20>
  		  	<td>�D�ό`��<td><select name="ShipType" OnKeyDown="ResetEnter()"><%=ShowShipType(ShipType)%></select>
  		  <tr height=20>
			<td>�D �� ��<td><input class=si NAME="ShipCorp" MAXLENGTH=50 size=45 VALUE="<%=ShipCorp%>" OnKeyDown="ResetEnter()">
  		  <tr height=20>
  		  	<td>Container<td>
				20GP x <select name="Container20GP" OnKeyDown="ResetEnter()"><%=ShowCount(Container20GP)%></select>�@
				40GP x <select name="Container40GP" OnKeyDown="ResetEnter()"><%=ShowCount(Container40GP)%></select>�@
				40HC x <select name="Container40HC" OnKeyDown="ResetEnter()"><%=ShowCount(Container40HC)%></select>�@
		</table>
  <tr><td>
		<table class=pt9>
		  <tr><td valign=top width=80>Consignee
			<td><a href="javascript:DoSearch(2)"><img src=img/search.jpg border=0 alt="����"></a>
			<input size=45 class=si NAME="Consignee" MAXLENGTH=50 VALUE="<%=Consignee%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Consignee1" MAXLENGTH=100 VALUE="<%=Consignee1%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Consignee2" MAXLENGTH=100 VALUE="<%=Consignee2%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Consignee3" MAXLENGTH=100 VALUE="<%=Consignee3%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Consignee4" MAXLENGTH=100 VALUE="<%=Consignee4%>" OnKeyDown="ResetEnter()"><br>
		</table>
	<td colspan=2>
		<table class=pt9>
		  <tr><td valign=top width=80>Agent
			<td><a href="javascript:DoSearch(4)"><img src=img/search.jpg border=0 alt="����"></a>
			<input size=45 class=si NAME="Agent" MAXLENGTH=50 VALUE="<%=Agent%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Agent1" MAXLENGTH=100 VALUE="<%=Agent1%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Agent2" MAXLENGTH=100 VALUE="<%=Agent2%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Agent3" MAXLENGTH=100 VALUE="<%=Agent3%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Agent4" MAXLENGTH=100 VALUE="<%=Agent4%>" OnKeyDown="ResetEnter()"><br>
		</table>
	
  <tr><td>
		<table class=pt9>
		  <tr><td valign=top width=80>Notify Party
			<td><a href="javascript:DoSearch(3)"><img src=img/search.jpg border=0 alt="����"></a>
			<input size=45 class=si NAME="Notify" MAXLENGTH=50 VALUE="<%=Notify%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Notify1" MAXLENGTH=100 VALUE="<%=Notify1%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Notify2" MAXLENGTH=100 VALUE="<%=Notify2%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Notify3" MAXLENGTH=100 VALUE="<%=Notify3%>" OnKeyDown="ResetEnter()"><br>
			<input size=50 class=si NAME="Notify4" MAXLENGTH=100 VALUE="<%=Notify4%>" OnKeyDown="ResetEnter()"><br>
    	</table>	
	<td colspan=2>
  		<table class=pt9>
  		  <tr><td valign=top>Remarks<td><textarea class=si NAME="Remarks" style="width:300px;height:60px"><%=Remarks%></textarea>	
		</table>
</table>
		
<table width=96% border=0 cellspacing=1 cellpadding=2 class=pt9>
  <tr valign=top>
	<td width=20%>Vessel<br>
		<input size=16 class=si NAME="VESSEL" MAXLENGTH=50 VALUE="<%=VESSEL%>" OnKeyDown="ResetEnter()">
	<td width=15%>Voy<br>
		<input size=10 class=si NAME="VOY" MAXLENGTH=20 VALUE="<%=VOY%>" OnKeyDown="ResetEnter()">
	<td width=15%>ETD<br>
		<input size=10 class=si NAME="ETD" MAXLENGTH=10 VALUE="<%=ETD%>" OnKeyDown="ResetEnter()" onclick="setday(this)">
	<td width=20%>POL<br>
		<input size=15 class=si NAME="POL" MAXLENGTH=50 VALUE="<%=POL%>" OnKeyDown="ResetEnter()">
	<td width=15%>ETA<br>
		<input size=10 class=si NAME="ETA" MAXLENGTH=10 VALUE="<%=ETA%>" OnKeyDown="ResetEnter()" onclick="setday(this)">  
	<td width=20%>POD<br>
		<input size=15 class=si NAME="POD" MAXLENGTH=50 VALUE="<%=POD%>" OnKeyDown="ResetEnter()">	
</table>
<BR>
<table width="96%" BORDER=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9>
  <tr height=20 valign=top>
	<td nowrap>Marks��No.
	<td nowrap>Quantity
	<td nowrap>Packages
	<td nowrap>Description of Goods
	<td nowrap>Weight
	<td nowrap>Measurement
  
  <tr height=20 align=center valign=top>
	<td><textarea class=si NAME="Container" style="width:150px;height:100px"><%=Container%></textarea>
  	<td><input class=sn name="Quantity" size=8 maxlength=8 value="<%=formatnumber(Quantity,3,true)%>" OnKeyDown="ResetEnter()">
  	<td><input class=si name="Package" size=10 maxlength=10 value="<%=Package%>" OnKeyDown="ResetEnter()">
  	<td><input class=si name="Commodity" size=32 maxlength=100 value="<%=Commodity%>" onkeydown="ResetEnter()">	
  	<td><input class=sn name="GW" value="<%=formatnumber(GW,3,true)%>" size=8 maxlength=8 OnKeyDown="ResetEnter()">
  	<td><input class=sn name="CBM" value="<%=formatnumber(CBM,3,true)%>" size=8 maxlength=8 OnKeyDown="ResetEnter()"> 
</table>
<BR>
<table width=96% border=0 cellspacing=0 cellpadding=2>
  <tr><td width=50%>
<%if SeqNo <> 0 then%>
	<input type=button style="width:90;height:30" name=btnSave value="�폜" onclick="DoDelete()">
<%end if%>
  <td width=50% align=right>
	<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave()">
</table>
</center>
</form>
</body>
</html>

<%
	Set Recset = Nothing
	CloseDB Conn
%>

<%
function ShowShipType(myDef)
dim buf
	for i = 1 to ubound(ctmShip)
		buf = buf & "<option value='" & ctmShip(i) & "'"
		if myDef = ctmShip(i) then buf = buf & " selected"
		buf = buf & ">" & ctmShip(i)
	next
	ShowShipType = buf
end function

function ShowCount(myDef)
dim buf
	for i = 0 to 9
		buf = buf & "<option value=" & i
		if myDef = i then buf = buf & " selected"
		buf = buf & ">" & i
	next
	ShowCount = buf
end function
%>