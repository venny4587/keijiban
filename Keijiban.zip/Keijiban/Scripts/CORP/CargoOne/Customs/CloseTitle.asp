<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�����`�[�o�b�`�ԍ�����
'----------------------------------------------

'on error resume next
dim BatchNo
dim BatchPic
dim BatchClient
dim BatchBillDay
dim BatchPayDay

	mode = GetLong(request("mode"))
	BatchNo = GetPost(request("no"))
	if BatchNo <> "" then
	
		myLevel = CheckUserLevel(UserShop, "")
		if myLevel < 2 and CheckTopLevel() > 0 then myLevel = 2
	
		OpenSQL Conn, SqlServerName, DatabaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		
'		Conn.BeginTrans				'�蓮�܂��͕��U�g�����U�N�V���� ���[�h�̂��߁A�V�K�ڑ����쐬�ł��܂���B
		
		select case mode
		case 2					'�m��	
			
			BatchCount = 0
			BatchAmount = 0
			with Recset	
				strSql = "SELECT JobCode, CostsNo, CostsAmount + CostsTax AS TTL, ConfirmerID FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsBatch = '" & BatchNo & "'"
				.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
				do while not .eof 
					
					'�x���`�[�m��
					if GetLong(.Fields("ConfirmerID")) = 0 then
						call Payment2Biz(1, Conn, GetString(.fields("CostsNo")), GetString(.fields("JobCode")))		'�d��쐬
					
						'��p���ڊm��
						strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = GETDATE(), ConfirmerID = " & WebUserID
						strSql = strSql & " WHERE Deleted = 0 AND ExpensePay = '" & GetString(.fields("CostsNo")) & "'"
						Conn.execute strSql
					end if
					
					BatchCount = BatchCount + 1
					BatchAmount = BatchAmount + GetLong(.fields("TTL"))
					
					.movenext
				loop
				.close
			end with
			
			'�x���`�[�m��(�O�̂���)
			strSql = "UPDATE TBL_CTM_COSTS SET CostsCheck = 1, ConfirmDate = GETDATE(), ConfirmerID = " & WebUserID
			strSql = strSql & " WHERE Deleted = 0 AND CostsBatch = '" & BatchNo & "'"
			Conn.execute strSql
					
			'�o�b�`���m��
			strSQL = "UPDATE TBL_CTM_BATCH SET ConfirmDate = GETDATE(), ConfirmerID = " & WebUserID & ", BatchCount = " & BatchCount & ", BatchAmount = " & BatchAmount
			strSql = strSql & " WHERE Deleted = 0 AND BatchNo = '" & BatchNo & "'"
			Conn.Execute strSQL
			
			msg = "�Y������o�b�`�ԍ��͊m�肳��܂����B"
	
			
		case 3					'����	

if WebUserID = gsAdmin then
			'�x���d��폜
			strSql = "DELETE FROM TBL_CTM_BIZ WHERE BIZ_BATCH = '" & BatchNo & "'"
			Conn.execute strSql

			'��p���ڊm�����
			strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = NULL, ConfirmerID = 0" 
			strSql = strSql & " WHERE Deleted = 0 AND ExpensePay IN (SELECT CostsNo FROM TBL_CTM_COSTS WHERE CostsBatch = '" & BatchNo & "')"
			Conn.execute strSql
			
			'�x���`�[�m�����
			strSql = "UPDATE TBL_CTM_COSTS SET ConfirmDate = NULL, ConfirmerID = 0" 
			strSql = strSql & " WHERE Deleted = 0 AND CostsBatch = '" & BatchNo & "'"
			Conn.execute strSql
end if
			'�o�b�`���m�����		
			strSql = "UPDATE TBL_CTM_BATCH SET ConfirmDate = NULL, ConfirmerID = 0" 
			strSql = strSql & " WHERE Deleted = 0 AND BatchNo = '" & BatchNo & "'"
			Conn.Execute strSQL
			
			msg = "�Y������o�b�`�ԍ��̊m��͉�������܂����B"
	
		end select
		
		
		strSQL = "SELECT * FROM TBL_CTM_BATCH WHERE BatchNo = '" & BatchNo & "'"
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			BatchClient = GetString(Recset.Fields("BatchClient"))
			BatchPic = GetString(Recset.Fields("BatchPic"))
			BatchBillDay = Str2Date(Recset.Fields("BatchBillDay"))
			BatchPayDay = Str2Date(Recset.Fields("BatchPayDay"))
			Remarks = GetString(Recset.Fields("Remarks"))
			ConfirmerID = GetLong(Recset.Fields("ConfirmerID"))
			FinisherID = GetLong(Recset.Fields("FinisherID"))
		end if
				
'		if err.number = 0 then
'			Conn.CommitTrans
'		else
'			Conn.RollbackTrans
'			msg = "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
'		end if
		
		Recset.Close
		CloseDB Conn
				
		BatchClientRef = GetRefName(BatchClient)
		BatchClientName = GetFullName(BatchClient)
		
		session("CTM_CostsBatch") = BatchNo
		session("CTM_CostsClient") = BatchClient
		session("CTM_CostsClientRef") = BatchClientRef
		session("CTM_CostsClientName") = BatchClientName
		session("CTM_CostsClientPic") = BatchPic
		session("CTM_CostsCloseDay") = BatchBillDay
		session("CTM_CostsPayDay") = BatchPayDay
		
%>
<html>
<HEAD>
	<TITLE>�����ڍד���</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoPrint() 
		dim win
			set win = window.open("CostsCover.asp?BatchNo=<%=BatchNo%>","CostsCover","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
					
		sub DoRepeat()
			window.parent.dtl.location.href = "CloseInput.asp"
		end sub
		
		sub DoLock()
			if msgbox ("�Y���������m�肵�Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 2
			frmInput.submit()
		end sub
		
		sub DoUnLock()
			if msgbox ("�Y���m����������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 3
			frmInput.submit()
		end sub
		
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
<%if ConfirmerID = 0 then %>
			window.parent.dtl.location.href = "CloseInput.asp"
<%end if%>
			window.parent.parent.parent.result.location.href = "CostsResult.asp?type=1"
		end sub
	</SCRIPT>
</Head>
<body onload="InitForm()" leftmargin=0 topmargin=0 class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CloseTitle.asp" method="post">
  	<input type=hidden name="no" value="<%=BatchNo%>">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0>
	  <tr><td>			
		<table Cellspacing=0 CellPadding=0 class=pt9g>
		  <TR height=28>
			<TD nowrap>�ޯ���&nbsp;<input class=si value="<%=BatchNo%>" size=6 readonly>
				�x����&nbsp;<font color=black>(<input class=si value="<%=BatchClientRef%>" size=6 readonly>)</font>
				<input class=sj name="ChargeName" size=30 maxlength=50 value="<%=BatchClientName%>" readonly>
		  <TR height=28>
			<TD>���ߓ�&nbsp;<input class=si value="<%=BatchBillday%>" size=10 readonly>
				�x����&nbsp;<input class=si value="<%=BatchPayDay%>" size=10 readonly>
				����S��&nbsp;<input class=sj name="BatchPic" size=15 maxlength=50 value="<%=BatchPic%>" readonly>
		</table>
	  <td align=center nowrap class=pt9r>
<%if ConfirmerID = 0 then %>	   
	  	<input type=button style="width:60;height:30" name=btnRepeat value="����" onclick="DoRepeat()">
	  <%if myLevel > 1 then%>
	  	<input type=button style="width:60;height:30" name=btnFinish value="�m��" onclick="DoLock()">
	  <%end if%>
<%else%>
	  	<input type=button style="width:60;height:30" name=btnPrint value="���" onclick="DoPrint()">
	<%if FinisherID = 0 and myLevel > 2 then%>
	  	<input type=button style="width:60;height:30" name=btnFinish value="����" onclick="DoUnLock()">
	<%end if%>
<%end if%>
	  </table>
  </FORM>
<center>
</body></html>
<%
	end if
%>