<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim EstimateID
	
	blnDelete = True
	EstimateClient = GetPost(request("cd"))
	EstimateID = GetLong(request("id"))
	
	OpenSQL Conn, SqlServerName, DatabaseName

	strSQL = "DELETE FROM TBL_CTM_ESTIMATE WHERE EstimateID = " & EstimateID
	Conn.Execute strSQL
	
	strURL = "EstimateDetail.asp?cd=" & EstimateClient & "&p=" & Request("p") & "&s=" & Request("s")
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing

	Response.Redirect strURL
%>