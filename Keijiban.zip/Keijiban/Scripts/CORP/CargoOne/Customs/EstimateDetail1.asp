<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim EstimateClient
	dim ExpenseCost
	dim EstimateType
	dim ExpenseUnit
	dim Remarks
	
	EstimateClient = GetPost(Request("cd"))
	EstimateID = GetLong(Request("EstimateID"))
	EstimateType = GetPost(Request("EstimateType"))
	ExpenseCost = GetLong(Request("ExpenseCost"))
	ExpenseUnit = GetPost(Request("ExpenseUnit"))
	ExpensePrice = GetLong(Request("ExpensePrice"))
	ExpenseTaxName = GetPost(Request("ExpenseTaxName"))
	Remarks = GetPost(Request("Remarks"))

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If false Then			'�����d���\
		With Recset
			strSql = "SELECT ExpenseCost FROM TBL_CTM_ESTIMATE WHERE EstimateID <> " & EstimateID & " AND EstimateClient = '" & EstimateClient & "' AND ExpenseCost = " & ExpenseCost
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����p���ڂ͊����ł��B"
			End If
			.Close 
		End With 
	End If
	
	If blnEdit Then	
			
		if EstimateID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "ESTM_ID"
			cmdSQL.Execute
			EstimateID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
		strSQL = "SELECT * FROM TBL_CTM_ESTIMATE WHERE EstimateID = " & EstimateID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.Fields("EstimateClient") = EstimateClient
				.Fields("EstimateID") = EstimateID
			End If
			.Fields("ExpenseCost") = ExpenseCost
			.Fields("EstimateType") = EstimateType
			.Fields("ExpenseUnit") = ExpenseUnit
			.Fields("ExpensePrice") = ExpensePrice
			.Fields("ExpenseTaxName") = ExpenseTaxName
			.Fields("Remarks") = Remarks
			.Update 
			.Close 
		End With

		strURL = "EstimateDetail.asp?cd=" & EstimateClient & "&p=" &  Request("p") & "&s=" & Request("s")
		Response.redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
