<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myPageSize = GetUserPageSize(20)
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		JobType = 0
		Confirm = 0
		mySort = 4
		DateTo = GetMonthLastDay(dateadd("m", -1, date))
		DateFrom = dateadd("m", -1, dateadd("d", 1, DateTo))
		SalesDate = left(Date2Str(dateadd("m",-1,Date)), 6)
	else
		JobType = GetLong(request("JobType"))
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		JobCode = GetPost(request("JobCode"))
		AmountFrom = GetPost(request("AmountFrom"))
		AmountTo = GetPost(request("AmountTo"))
		Confirm = GetLong(request("Confirm"))
		BillNo = GetPost(request("BillNo"))
		SalesDate = GetPost(request("SalesDate"))
		
		if AmountFrom <> "" then AmountFrom = GetLong(AmountFrom)
		if AmountTo <> "" then AmountTo = GetLong(AmountTo)
	end if

%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�q�ɐ����Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function DoSearch()
			frmInput.page.value = 1
			frmInput.submit()
		end function
		
		function DoSort(no)
			frmInput.page.value = 1
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function ShowList(mode)
		dim win
			set win = window.open("../common/CustomerSearch.asp?txt=ClientRef&mode=1","CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(cd, no)
		dim win
<%if JobType = 0 then%>
			set win = window.open("../customs/MainFrame.asp?mode=1&JobCode=" & cd & "&ChargeNo=" & no, "", "resizable=1,scrollbars=1,width=960,height=640")
<%else%>
			set win = window.open("../customs/MainFrame.asp?mode=2&JobCode=" & cd & "&CostsNo=" & no, "", "resizable=1,scrollbars=1,width=960,height=640")
<%end if%>
			win.focus()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
		
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub AmountFrom_OnBlur()
			if frmInput.AmountFrom.value = "" then exit sub
			frmInput.AmountFrom.value = GetDouble(frmInput.AmountFrom.value)
		end sub
		sub AmountTo_OnBlur()
			if frmInput.AmountTo.value = "" then exit sub
			frmInput.AmountTo.value = GetDouble(frmInput.AmountTo.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.ClientRef)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="SokoList.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='<%=lngPageNumber%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()">
					<option value="0" <%if JobType = 0 then response.write "selected"%>>����
					<option value="1" <%if JobType = 1 then response.write "selected"%>>�x��</select>
				�����<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�������x&nbsp;<SELECT name="SalesDate" onkeydown="ResetEnter()"><%for i = -6 to 1%><%myDate=dateadd("m",i,date)%>
					<option value="<%=left(Date2Str(myDate), 6)%>" <%if SalesDate = left(Date2Str(myDate), 6) then response.write "selected"%>>
					<%=left(formatDate(myDate), 7)%><%next%></select>
				�䒠�ԍ� <input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				���z <input class=sn name="AmountFrom" value="<%=AmountFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="AmountTo" value="<%=AmountTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				�m�F��<input type=checkbox name="Confirm" value="1" onkeydown="ResetEnter()" <%if Confirm then response.write " checked"%>>
				<INPUT style="width:60px;height:25px;" TYPE=BUTTON VALUE="����" onclick="DoSearch()">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if ClientRef <> "" then	strSel = strSel & " AND ClientRef = '" & FitSel(ClientRef) & "'"
		if DateFrom <> "" then strSel = strSel & " AND SalesDate >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND SalesDate <= '" & Date2Str(DateTo) & "'"
		if BillNo <> "" then strSel = strSel & " AND BillNo LIKE '%" & FitSel(BillNo) & "%'"
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'" 
		if AmountFrom <> "" then strSel = strSel & " AND (Amount+Tax) >= " & AmountFrom
		if AmountTo <> "" then strSel = strSel & " AND (Amount+Tax) <= " & AmountTo
		if Confirm = 0 then strSel = strSel & " AND ISNULL(ConfirmerID, 0) = 0"
		if SalesDate <> "" then 
			strSel = strSel & " AND (SalesDate Between '" & SalesDate & "00' AND '" & SalesDate & "99'"
			if SalesDate = left(Date2Str(date), 6) then strSel = strSel & " OR SalesDate = ''"
			strSel = strSel & ")"
		end if
		
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT JobCode, JobClient, POL, POD, ETA, ETD,Vessel, SalesDate, LockerID FROM TBL_CTM_JOB WHERE Deleted = 0"
		strSQL = strSQL & ") AS J LEFT JOIN (SELECT JobCode AS CD, ConfirmerID, "
		if JobType = 0 then
			strSQL = strSQL & "ChargeClient AS Client, ChargeNo AS BillNo, ChargeAmount AS Amount, ChargeTax AS Tax FROM TBL_CTM_CHARGE"
		else
			strSQL = strSQL & "CostsClient AS Client, CostsNo AS BillNo, CostsAmount AS Amount, CostsTax AS Tax FROM TBL_CTM_COSTS"
		end if
		strSQL = strSQL & " WHERE Deleted = 0) AS C ON J.JobCode = C.CD LEFT JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME FROM CUSTOMER) AS M"
		strSQL = strSQL & "  ON C.Client = M.CTM_CD WHERE SUBSTRING(JobCode, 1, 1) = '" & gsSokoInit & "' " & strSel
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY BillNo"
		case 1:		strSQL = strSQL & " ORDER BY JobCode, BillNo"
		case 2:		strSQL = strSQL & " ORDER BY ISNULL(Client, JobClient), SalesDate"
		case 3:		strSQL = strSQL & " ORDER BY SalesDate"
		case 4:		strSQL = strSQL & " ORDER BY (Amount+Tax) DESC"
		case 5:		strSQL = strSQL & " ORDER BY ConfirmerID"
		end select
		if mySort > 1 then strSQL = strSQL & ", BillNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=3 align=center>
			<colgroup span=4 align=left>
			<colgroup align=center>
			<colgroup span=3 align=right>
			<colgroup align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�`�[�ԍ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD width=16% nowrap>�D��
			<TD width=8% nowrap>���o�`
			<TD width=10% nowrap>�`��
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">������
			<TD width=10% nowrap>�Ŕ����z
			<TD width=8% nowrap>�����
			<TD width=12% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">���v���z
			<TD width=4% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�m��
<%
				cnt = 0
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						Vessel = GetString(.Fields("Vessel"))
						if CheckJobType(.Fields("JobCode")) = gsExport then
							Port = GetString(.Fields("POD"))
							EtaEtd = GetString(.Fields("ETD"))
						else
							Port = GetString(.Fields("POL"))
							EtaEtd = GetString(.Fields("ETA"))
						end if
						JobClient = GetString(.Fields("ClientRef"))
						if JobClient = "" then JobClient = GetRefName(GetString(.Fields("JobClient")))
%>
					<TR style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
						 onclick="ShowDetail('<%=GetString(.Fields("JobCode"))%>','<%=GetString(.Fields("BillNo"))%>');">
						<TD nowrap class=line><%=lngCount%>
						<TD nowrap class=line><%=ShowVoucherNo(.Fields("BillNo"))%><BR>
						<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%>
						<TD nowrap class=line><%=Vessel%><BR>
						<TD nowrap class=line><%=Str2YMD(EtaEtd)%><BR>
						<TD nowrap class=line><%=Port%><BR>
						<TD nowrap class=line><%=JobClient%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("SalesDate"))%><BR>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("Amount")), 0, true)%><BR>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("Tax")), 0, true)%><BR>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("Amount")) + GetLong(.Fields("Tax")), 0, true)%><BR>
						<TD class=line ><%=ShowConfirm(.Fields("ConfirmerID"))%>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowConfirm(myFlag)
	if isnull(myFlag) then
		ShowConfirm = "�|"
	elseif GetLong(myFlag) = 0 then
		ShowConfirm = "<font class=pt9r>��</font>"
	else
		ShowConfirm = "<font class=pt9g>��</font>"
	end if
end function
%>