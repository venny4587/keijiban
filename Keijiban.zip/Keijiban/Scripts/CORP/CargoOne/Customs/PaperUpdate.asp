<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	mode = GetLong(request("mode"))
	SeqNo = GetLong(request("SeqNo"))
	JobCode = GetPost(request("JobCode"))
		
	if JobCode <> "" then
	
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset")	
		
		mode = GetLong(request("mode"))
		select case mode
		
		case -1
		
			strSql = "UPDATE TBL_CTM_PAPER SET Deleted = 1, Updated = GETDATE(), Updater = " & WebUserID 
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			Conn.Execute strSql
		
		case else
		
			if SeqNo = 0 then
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "PaperNo"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
			end if
			
			with Recset
				strSql = "SELECT * FROM TBL_CTM_PAPER WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = JobCode
					.fields("SeqNo") = SeqNo
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				
				.fields("JobClient") = GetPost(request("JobClient"))
				.fields("PaperMode") = GetLong(request("PaperMode"))
				.fields("PaperNo") = GetPost(request("PaperNo"))
				
				.fields("Shipper") = GetPost(request("Shipper"))
				.fields("Shipper1") = GetPost(request("Shipper1"))
				.fields("Shipper2") = GetPost(request("Shipper2"))
				.fields("Shipper3") = GetPost(request("Shipper3"))
				.fields("Shipper4") = GetPost(request("Shipper4"))
				.fields("Consignee") = GetPost(request("Consignee"))
				.fields("Consignee1") = GetPost(request("Consignee1"))
				.fields("Consignee2") = GetPost(request("Consignee2"))
				.fields("Consignee3") = GetPost(request("Consignee3"))
				.fields("Consignee4") = GetPost(request("Consignee4"))
				.fields("Notify") = GetPost(request("Notify"))
				.fields("Notify1") = GetPost(request("Notify1"))
				.fields("Notify2") = GetPost(request("Notify2"))
				.fields("Notify3") = GetPost(request("Notify3"))
				.fields("Notify4") = GetPost(request("Notify4"))
				.fields("Agent") = GetPost(request("Agent"))
				.fields("Agent1") = GetPost(request("Agent1"))
				.fields("Agent2") = GetPost(request("Agent2"))
				.fields("Agent3") = GetPost(request("Agent3"))
				.fields("Agent4") = GetPost(request("Agent4"))
				.fields("ShipType") = GetPost(request("ShipType"))
				.fields("ShipCorp") = GetPost(request("ShipCorp"))
				.fields("Container20GP") = GetLong(request("Container20GP"))
				.fields("Container40GP") = GetLong(request("Container40GP"))
				.fields("Container40HC") = GetLong(request("Container40HC"))
				.fields("Remarks") = GetPost(request("Remarks"))
				
				.fields("Vessel") = GetPost(request("Vessel"))
				.fields("Voy") = GetPost(request("Voy"))
				.fields("POL") = GetPost(request("POL"))
				.fields("POD") = GetPost(request("POD"))
				.fields("Remarks") = GetPost(request("Remarks"))
			
				.fields("Vessel") = GetPost(Request("Vessel"))
				.fields("Voy") = GetPost(Request("Voy"))
				.fields("ETD") = Date2Str(Request("ETD"))
				.fields("ETA") = Date2Str(Request("ETA"))
				.fields("POL") = GetPost(Request("POL"))
				.fields("POD") = GetPost(Request("POD"))
				.fields("GW") = GetDouble(Request("GW"))
				.fields("CBM") = GetDouble(Request("CBM"))
				.fields("Commodity") = GetPost(Request("Commodity"))
				.fields("Quantity") = GetDouble(Request("Quantity"))
				.fields("Package") = GetPost(Request("Package"))
				.fields("Container") = GetPost(Request("Container"))
								
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			
		end select

		set Recset = nothing
		CloseDB Conn
	end if
%>
<html>
<script language=javascript>
	window.close();
</script>
</html>