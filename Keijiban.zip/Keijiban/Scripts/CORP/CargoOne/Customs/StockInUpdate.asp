<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
	
	SeqNo = GetLong(request("SeqNo"))
	mode = GetLong(request("mode"))
	if mode <> 0 then
	
		Conn.BeginTrans
		
		select case mode
		case -1

			strSql = "UPDATE TBL_CTM_STOCK SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID
			strSql = strSql & ",Updated = GETDATE()"
			strSql = strSql & " WHERE SeqNo = " & SeqNo
			Conn.Execute strSql
			
		case else
		
			if SeqNo = 0 then 
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "StockNo"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)				
			end if
			
			with Recset
				strSql = "SELECT * FROM TBL_CTM_STOCK WHERE SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("SeqNo") = SeqNo
					.fields("StockType") = 0
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				
				.fields("JobCode") = GetPost(request("JobCode"))
				.fields("StockClient") = GetPost(request("StockClient"))
				
				.fields("StockNo") = GetPost(request("StockNo"))
				.fields("StockDate") = Date2Str(request("StockDate"))
				.fields("StockTime") = GetPost(request("StockTime"))
				.fields("StockCode") = GetPost(request("StockCode"))
				.fields("StockName") = GetPost(request("StockName"))
				
				.fields("StockPkgCnt") = GetLong(request("StockPkgCnt"))
				.fields("StockPkgZan") = GetLong(request("StockPkgZan"))
				.fields("StockPackage") = GetPost(request("StockPackage"))
				.fields("StockGW") = GetDouble(request("StockGW"))
				.fields("StockCBM") = GetDouble(request("StockCBM"))
				.fields("StockMark") = GetPost(request("StockMark"))
				.fields("StockReferNo") = GetPost(request("StockReferNo"))
				
				.fields("StockPlace") = GetPost(request("StockPlace"))
				.fields("StockDelivery") = GetPost(request("StockDelivery"))
				.fields("StockDivision") = GetPost(request("StockDivision"))
				.fields("StockStatus") = GetPost(request("StockStatus"))
				.fields("StockLot") = GetPost(request("StockLot"))
				.fields("StockMemo") = GetPost(request("StockMemo"))				
				.fields("Remarks") = GetPost(request("Remarks"))
				
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			
		end select
		
		if err.number = 0 then
			Conn.CommitTrans
%>
<html>
<script language=javascript>
	alert("�f�[�^�X�V���܂����I");
	if (window.opener.frmInput != null) window.opener.frmInput.submit();
	window.location.href = "StockInDetail.asp?SeqNo=<%=SeqNo%>";
</script>
</html>
<%
		else
			Conn.RollbackTrans
			ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
			
		end if
	end if
	
	set Recset = nothing
	CloseDB Conn
%>