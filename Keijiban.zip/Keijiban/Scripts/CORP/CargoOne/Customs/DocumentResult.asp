<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
	
	if instr(session("Depart"), "�A��") <> 0 then JobType = gsImport
	if instr(session("Depart"), "�A�o") <> 0 then JobType = gsExport
	JobType = ""				'�q�ɔ��p
	
	mySort = GetLong(request("sort"))
	SearchDate = GetDate(request("SearchDate"))
	if SearchDate = "" then SearchDate = formatDate(date)
	
	myType = GetLong(request("type"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>���ވꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>	
		sub SearchDate_OnBlur()
			SearchDate.value = setdate(SearchDate.value)
		end sub
	
		function DoSelect()
			window.location.href = "DocumentResult.asp?type=<%=myType%>&SearchDate=" & cstr(SearchDate.value)
		end function
		
		function DoSort(myNo)
			window.location.href = "DocumentResult.asp?type=<%=myType%>&sort=" & myNo & "&SearchDate=" & cstr(SearchDate.value)
		end function
		
		function ShowDetail(tp, cd, no)
		dim win
			set win = window.open("DocumentDetail.asp?type=<%=myType%>&DocumentType=" & tp & "&JobCode=" & cd & "&seq=" & no,"DocumentDetail","resizable=1,scrollbars=1,width=600,height=400")
			win.focus()
		end function
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td nowrap width=40%>��<%
	  	  	select case myType 
	  	  	case 1:		response.write "�擾��"
	  	  	case 2:		response.write "���t��"
	  	  	case 3:		response.write "�����"
	  	  	case 4:		response.write "�ԋp��"
	  	  	case 5:		response.write "������"
	  	  	end select%>�ꗗ&nbsp;
	  	  <td nowrap width=60%><%
	  	  	select case myType 
	  	  	case 1:		response.write "�擾��"
	  	  	case 2:		response.write "���t��"
	  	  	case 3:		response.write "�����"
	  	  	case 4:		response.write "�ԋp��"
	  	  	case 5:		response.write "������"
	  	  	end select%>
			<input class=si name="SearchDate" size=10 maxlength=10 value="<%=SearchDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<img style="cursor:hand" src=img/search.jpg alt="���t�I��" onmousedown="DoSelect()">
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT * FROM (SELECT DocumentType, DocumentTitle, ObtainDate, SendDate, FetchDate, ReturnDate,"
		strSql = strSql & " SeqNo, JobCode, FinisherID, CONVERT(VARCHAR(10), FinishDate, 112) AS Finished"
		strSql = strSql & " , ObtainTime, SendTime, FetchTime, ReturnTime "
		strSql = strSql & " FROM TBL_CTM_DOCUMENT WHERE Deleted = 0"
		strSql = strSql & " UNION ALL "
		strSql = strSql & " SELECT '" & gsReceipt & "' AS DocumentType, PermitNo AS DocumentTitle"
		strSql = strSql & " , ObtainDate, '' AS SendDate, '' AS FetchDate, ReturnDate, 0 AS SeqNo, JobCode"
		strSql = strSql & " , (CASE ReturnDate WHEN '' THEN 0 ELSE 1 END) AS FinisherID, ReturnDate AS Finished"
		strSql = strSql & " , '' AS ObtainTime, '' AS SendTime, '' AS FetchTime, '' AS ReturnTime"
		strSql = strSql & " FROM TBL_CTM_JOB WHERE Deleted = 0) AS TMP"
		select case myType
		case 1:		strSql = strSql & " WHERE ObtainDate = '" & Date2Str(SearchDate) & "'"
		case 2:		strSql = strSql & " WHERE SendDate = '" & Date2Str(SearchDate) & "'"
		case 3:		strSql = strSql & " WHERE FetchDate = '" & Date2Str(SearchDate) & "'"
		case 4:		strSql = strSql & " WHERE ReturnDate = '" & Date2Str(SearchDate) & "'"
		case 5:		strSql = strSql & " WHERE Finished = '" & Date2Str(SearchDate) & "'"
		end select
		if JobType <> "" then strSql = strSql & " AND SUBSTRING(JobCode, 5, 1) = '" & JobType & "'"
		select case mySort
		case 0:		strSql = strSql & " ORDER BY DocumentType, JobCode"
		case 1:		strSql = strSql & " ORDER BY JobCode, DocumentType"
		case 2:		strSql = strSql & " ORDER BY ObtainDate, JobCode"
		case 3:		strSql = strSql & " ORDER BY SendDate, JobCode"
		case 4:		strSql = strSql & " ORDER BY FetchDate, JobCode"
		case 5:		strSql = strSql & " ORDER BY ReturnDate, JobCode"
		end select
if WebUserID = gsAdmin then response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20 class=pt9>
		<TD class=line colspan=2 align=center style="cursor:hand;color:blue" onmousedown="DoSort(0)">����
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�擾��
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">���t��
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�����
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�ԋp��
		<TD class=line nowrap>����
<%
			cnt = cnt + 1
			do while not .eof
				cnt = cnt + 1
				SeqNo = GetLong(.Fields("SeqNo"))
				JobCode = GetString(.Fields("JobCode"))
				DocumentType = GetString(.Fields("DocumentType"))
				if GetLong(.Fields("FinisherID")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=red>��</font>"
				end if
%>
		<TR height=20>
<%if DocumentType = gsReceipt then%>
			<TD nowrap class=line colspan=2 align=center><%=DocumentType%><BR>
<%else%>
			<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=DocumentType%>','<%=JobCode%>',<%=SeqNo%>)">
			<TD nowrap class=line><%=DocumentType%><BR>
<%end if%>
			<TD nowrap class=line><%=ShowJobCode(JobCode)%><BR>
			<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("ObtainDate"))%>&nbsp;<%=GetString(.Fields("ObtainTime"))%><BR>
<%if DocumentType = gsReceipt then%>
			<TD nowrap class=line colspan=2><%=GetString(.fields("DocumentTitle"))%><BR>
<%else%>
			<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("SendDate"))%>&nbsp;<%=GetString(.Fields("SendTime"))%><BR>
			<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("FetchDate"))%>&nbsp;<%=GetString(.Fields("FetchTime"))%><BR>
<%end if%>
			<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("ReturnDate"))%>&nbsp;<%=GetString(.Fields("ReturnTime"))%><BR>
			<TD nowrap class=line><%=status%><BR>
<%
				.movenext
			loop
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�����ނ͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
