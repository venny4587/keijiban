<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(50)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Confirmed = 0
		Division = 0
		JobSalesman = WebUserID
	else
		JobType = GetPost(request("JobType"))
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		InvoiceNo = GetPost(request("InvoiceNo"))
		DeliveryFrom = GetPost(request("DeliveryFrom"))
		DeliveryTo = GetPost(request("DeliveryTo"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		Vessel = GetPost(request("Vessel"))
		Port = GetPost(request("Port"))
		JobSalesman = GetLong(request("JobSalesman"))
		Confirmed = GetLong(request("Confirmed"))
		Division = GetLong(request("Division"))
	end if

	myLevel = CheckUserLevel(UserShop, "")
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowSelect(myMode, mySel)
		dim url
			select case myMode 
			case 10:	url = "CustomsStand.asp?mode=1&Division=0&JobSalesman=" & mySel
			case 11:	url = "CustomsStand.asp?mode=1&Division=0&JobType=E&JobSalesman=" & mySel
			case 12:	url = "CustomsStand.asp?mode=1&Division=0&JobType=I&JobSalesman=" & mySel
			case 20:	url = "CustomsStand.asp?mode=1&Division=1&JobSalesman=" & mySel
			case 21:	url = "CustomsStand.asp?mode=1&Division=1&JobType=E&JobSalesman=" & mySel
			case 22:	url = "CustomsStand.asp?mode=1&Division=1&JobType=I&JobSalesman=" & mySel
			end select
			window.location.href = url
		end function
			
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DeliveryFrom_OnBlur()
			frmInput.DeliveryFrom.value = setdate(frmInput.DeliveryFrom.value)
		end sub
		sub DeliveryTo_OnBlur()
			frmInput.DeliveryTo.value = setdate(frmInput.DeliveryTo.value)
		end sub
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CustomsStand.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>&nbsp;
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				INV ��<input class=si name="InvoiceNo" value="<%=InvoiceNo%>" maxlength=16 size=10 onkeydown="ResetEnter()">
				������<input class=si name="DeliveryFrom" value="<%=DeliveryFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DeliveryTo" value="<%=DeliveryTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�c��&nbsp;<SELECT name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartSales, JobSalesman)%></select>
			<TR><TD nowrap>
				���o�`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�D��<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=10 onkeydown="ResetEnter()">
				�`<input class=si name="Port" value="<%=Port%>" maxlength=16 size=10 onkeydown="ResetEnter()">
				�m�F��<input type=checkbox name="Confirmed" value="1" <%if Confirmed = 1 then response.write "checked"%>>
				�Ɩ����X�g<input type=radio name="Division" value="0" <%if Division = 0 then response.write "checked"%>>
				���֖�����<input type=radio name="Division" value="1" <%if Division = 1 then response.write "checked"%>>
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'"
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'"
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)
		if InvoiceNo <> "" then strSel = strSel & " AND InvoiceNo LIKE '%" & FitSel(InvoiceNo) & "%'"
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if Vessel <> "" then strSel = strSel & " AND Vessel LIKE '%" & FitSel(Vessel) & "%'"	
		if Port <> "" then strSel = strSel & " AND Port LIKE '%" & FitSel(Port) & "%'"
		if DeliveryFrom <> "" then strSel = strSel & " AND DeliveryDate >= '" & Date2Str(DeliveryFrom) & "'"
		if DeliveryTo <> "" then strSel = strSel & " AND DeliveryDate <= '" & Date2Str(DeliveryTo) & "'"
		if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman
		if Division = 1 then
			strSel = strSel & " AND JobCode IN (SELECT DISTINCT JobCode FROM TBL_CTM_EXPENSE WHERE Deleted=0 AND ExpenseType=2 AND ExpenseAttr=0 AND ISNULL(ExpenseBill, '')='')"
		elseif Confirmed = 0 then
			strSel = strSel & " AND ISNULL(CheckerID, 0) = 0"
		end if
		
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT JobCode, CTM_CD, CTM_ABR, ClientRef, JobSalesman, InvoiceNo, Vessel, GW, CBM, Commodity, Remarks, Quantity"	'ReferNo+' '+InvoiceNo AS 
		strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN POL ELSE POD END AS Port, FinisherID, CheckerID, TTL"
		strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN DOOR_NAME ELSE CarryPlace END AS Delivery, DeliveryDate"
		strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD, Broker FROM TBL_CTM_JOB AS J "
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_ABR, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD AS CD, CTM_ABR AS Broker FROM CUSTOMER) AS B ON J.CustomBroker = B.CD LEFT JOIN"
		strSQL = strSQL & " (SELECT JobCode AS CD, MIN(ConfirmerID) AS CheckerID, SUM(ChargeAmount+ChargeTax) AS TTL FROM TBL_CTM_CHARGE"
		strSQL = strSQL & " WHERE Deleted = 0 AND ChargeType <> " & gsStand & " GROUP BY JobCode) AS T ON J.JobCode = T.CD LEFT JOIN"
		strSQL = strSQL & " (SELECT JobCode AS CD, DOOR_NAME FROM TBL_CTM_DELIVERY AS M INNER JOIN CTM_DOOR AS D ON M.DeliveryTo = D.DOOR_ID"
		strSQL = strSQL & " INNER JOIN (SELECT JobCode AS CD, Max(SeqNo) AS SEQ FROM TBL_CTM_DELIVERY WHERE Deleted = 0 GROUP BY JobCode) AS S"
		strSQL = strSQL & " ON M.JobCode = S.CD AND M.SeqNo = S.SEQ) AS N ON J.JobCode = N.CD WHERE Deleted = 0 AND LockerID = 0"
		if CheckTopLevel() = 0 and myLevel <= 3 then strSql = strSql & " AND SUBSTRING(JobCode,1,1) = '" & UserShop & "'"
		strSQL = strSQL & ") AS TMP"
		if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel, 5)
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY SUBSTRING(JobCode,2,1), JobCode"
		case 1:		strSQL = strSQL & " ORDER BY JobCode"
		case 2:		strSQL = strSQL & " ORDER BY ClientRef, ETAETD"
		case 3:		strSQL = strSQL & " ORDER BY InvoiceNo"
		case 4:		strSQL = strSQL & " ORDER BY Vessel, JobCode"
		case 5:		strSQL = strSQL & " ORDER BY ETAETD, JobCode"
		case 6:		strSQL = strSQL & " ORDER BY Port, ETAETD"
		case 7:		strSQL = strSQL & " ORDER BY DeliveryDate, JobCode"
		case 8:		strSQL = strSQL & " ORDER BY FinisherID, DeliveryDate, JobCode"
		case 9:		strSQL = strSQL & " ORDER BY CheckerID, DeliveryDate, JobCode"
		case 10:	strSQL = strSQL & " ORDER BY TTL DESC"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
<div id=List>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=3 align=center>
			<colgroup span=5 align=left>
			<colgroup align=right>
			<colgroup span=4 align=left>
			<colgroup span=2 align=center>
			<colgroup align=right>
			<colgroup align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=4% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�敪
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����׎�
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">INV ��
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�D�@��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">���o�`��
			<TD width=10% nowrap>�i��
			<TD width=4% nowrap>��
			<TD width=4% nowrap>Ton/m3
			<TD width=4% nowrap align=center>VAN
			<TD width=8% nowrap>�ʊ֋Ǝ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">�g�n/�ϒn
			<TD width=10% nowrap>������/�[�i��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">������
			<TD width=4% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">ۯ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(10)">�����z
			<TD width=4% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">�m��
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						ClientRef = GetString(.Fields("ClientRef"))
						InvoiceNo = GetString(.Fields("InvoiceNo"))
						Vessel = GetString(.Fields("Vessel"))
						Commodity = GetString(.Fields("Commodity"))
						RTON = GetDouble(.Fields("CBM"))
						if RTON * 1000 < GetDouble(.Fields("GW")) then RTON = GetDouble(.Fields("GW")) / 1000
%>
					<TR style="cursor:hand;" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("JobCode")%>');">
						<TD nowrap class=line nowrap><%=lngCount%><BR>
						<TD nowrap class=line nowrap><%if CheckJobType(.Fields("JobCode"))=gsImport then%>�A��<%else%>�A�o<%end if%>
						<TD nowrap class=line nowrap><%=ShowJobCode(.Fields("JobCode"))%><BR>
						<TD nowrap class=line nowrap><%=GetString(.Fields("CTM_ABR"))%><BR>
						<TD nowrap class=line nowrap><%=InvoiceNo%><BR>
						<TD nowrap class=line nowrap><%=Vessel%><BR>
						<TD nowrap class=line nowrap><%=Str2YMD(.Fields("ETAETD"))%><BR>
						<TD nowrap class=line nowrap <%=ShowTitle(Commodity, 12)%>><%=StringCut(Commodity, 12)%><BR>
						<TD nowrap class=line nowrap><%=GetDouble(.Fields("Quantity"))%><BR>
						<TD nowrap class=line nowrap><%if RTON <> 0 then response.write formatnumber(RTON, 3, true)%><BR>
						<TD nowrap class=line nowrap><%=GetContainer(.Fields("JobCode"), .Fields("Remarks"))%><BR>
						<TD nowrap class=line nowrap><%=GetString(.Fields("Broker"))%><BR>
						<TD nowrap class=line nowrap><%=GetString(.Fields("Port"))%><BR>
						<TD nowrap class=line nowrap><%=FitPlace(.Fields("Delivery"))%><BR>
						<TD nowrap class=line nowrap><%=Str2YMD(.Fields("DeliveryDate"))%><BR>
						<TD nowrap class=line nowrap><%=ShowFlag(.Fields("FinisherID"), 0)%><BR>
						<TD nowrap class=line nowrap><%=formatnumber(GetLong(.Fields("TTL")), 0, false)%><BR>
						<TD nowrap class=line nowrap><%=ShowFlag(.Fields("CheckerID"), 1)%><BR>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
		</TABLE>
</div>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	else
%>
  <center>
  	<br>
	<table width=98% class=pt9n cellspacing=3>
	  <tr><td align=center>���֏����҂��ꗗ (<b><%=ShowDateTimeShort(now)%></b>����)
	</table>
	<br>
	<table width=50% class=pt9n cellspacing=3>
	  <tr height=24 align=center>
	  	<td width=50% bgcolor="#FFE0E0">������
	  <tr valign=top align=center>
	  	<td>
<%
if false then 
	'���֖��o�^
	with Recset
		strSql = "SELECT JobSalesman, SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN 'I' THEN 1 ELSE 0 END) AS IM_CNT"
		strSql = strSql & ", SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN 'E' THEN 1 ELSE 0 END) AS EX_CNT FROM TBL_CTM_JOB"
		strSql = strSql & " WHERE Deleted = 0 AND LockerID = 0"
		strSql = strSql & " AND JobCode NOT IN (SELECT DISTINCT JobCode FROM TBL_CTM_EXPENSE WHERE Deleted=0 AND ExpenseType=2)"
		strSql = strSql & " GROUP BY JobSalesman ORDER BY JobSalesman"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9n>���o�^�Ȃ�</font>"
		else
			cnt = 0:	ttl_im = 0:		ttl_ex = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>"
			response.write "<colgroup align=center><colgroup span=3 align=right>"
			response.write "<tr height=24 bgcolor=#E0E0E0><td>�c��<td>�A�o<td>�A��<td>���v"
			do while not .eof
				cnt = cnt + 1
				response.write "<tr height=24><td>" &  GetEmployName(.Fields("JobSalesman"), "F")
				if GetLong(.fields("EX_CNT")) = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(11, " & GetLong(.Fields("JobSalesman")) & ")"">" & GetLong(.fields("EX_CNT")) & "��"
				end if
				if GetLong(.fields("IM_CNT")) = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(12, " & GetLong(.Fields("JobSalesman")) & ")"">" & GetLong(.fields("IM_CNT")) & "��"
				end if
				if GetLong(.fields("EX_CNT")) = 0 and GetLong(.fields("IM_CNT")) = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(10, " & GetLong(.Fields("JobSalesman")) & ")"">" & GetLong(.fields("IM_CNT")) + GetLong(.fields("EX_CNT")) & "��"
				end if
				ttl_ex = ttl_ex + GetLong(.fields("EX_CNT"))
				ttl_im = ttl_im + GetLong(.fields("IM_CNT"))
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24><td>���v"
				if ttl_ex = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(11, 0)"">" & ttl_ex & "��"
				end if
				if ttl_im = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(12, 0)"">" & ttl_im & "��"
				end if
				if ttl_ex + ttl_im = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(10, 0)"">" & ttl_ex + ttl_im & "��"
				end if
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
	  	<td>
<%
end if
	'���֖�����
	with Recset
		strSql = "SELECT JobSalesman, SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN 'I' THEN 1 ELSE 0 END) AS IM_CNT"
		strSql = strSql & ", SUM(CASE SUBSTRING(JobCode, 2, 1) WHEN 'E' THEN 1 ELSE 0 END) AS EX_CNT FROM TBL_CTM_JOB"
		strSql = strSql & " WHERE Deleted = 0 AND LockerID = 0"
		strSql = strSql & " AND JobCode IN (SELECT DISTINCT JobCode FROM TBL_CTM_EXPENSE WHERE Deleted=0 AND ExpenseType=2 AND ExpenseAttr=0 AND ISNULL(ExpenseBill, '')='')"
		if CheckTopLevel() = 0 and myLevel <= 3 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		strSql = strSql & " GROUP BY JobSalesman ORDER BY JobSalesman"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9n>�������Ȃ�</font>"
		else
			cnt = 0:	ttl_im = 0:		ttl_ex = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=98% bordercolorlight=#FFFFFF>"
			response.write "<colgroup align=center><colgroup span=3 align=right>"
			response.write "<tr height=24 bgcolor=#E0E0E0><td>�c��<td>�A�o<td>�A��<td>���v"
			do while not .eof
				cnt = cnt + 1
				myColor = ""
				if WebUserID = GetLong(.Fields("JobSalesman")) then myColor = ";color:red"
				response.write "<tr height=24 style=""cursor:hand" & myColor & """>"
				response.write "<td>" &  GetEmployName(.Fields("JobSalesman"), "F")
				if GetLong(.fields("EX_CNT")) = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(21, " & GetLong(.Fields("JobSalesman")) & ")"">" & GetLong(.fields("EX_CNT")) & "��"
				end if
				if GetLong(.fields("IM_CNT")) = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(22, " & GetLong(.Fields("JobSalesman")) & ")"">" & GetLong(.fields("IM_CNT")) & "��"
				end if
				if GetLong(.fields("EX_CNT")) = 0 and GetLong(.fields("IM_CNT")) = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(20, " & GetLong(.Fields("JobSalesman")) & ")"">" & GetLong(.fields("IM_CNT")) + GetLong(.fields("EX_CNT")) & "��"
				end if
				ttl_ex = ttl_ex + GetLong(.fields("EX_CNT"))
				ttl_im = ttl_im + GetLong(.fields("IM_CNT"))
				.movenext
			loop
			if cnt > 1 then 
				response.write "<tr height=24><td>���v"
				if ttl_ex = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(21, 0)"">" & ttl_ex & "��"
				end if
				if ttl_im = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(22, 0)"">" & ttl_im & "��"
				end if
				if ttl_ex + ttl_im = 0 then
					response.write "<td align=center>�|"
				else
					response.write "<td style=""cursor:hand"" onmousedown=""ShowSelect(20, 0)"">" & ttl_ex + ttl_im & "��"
				end if
			end if
			response.write "</table>"
		end if
		.close
	end with
%>
	</TABLE>
<%
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowFlag(myFlag, myMode)
	if myFlag then
		if myMode then
			ShowFlag = "<font class=pt9b>��</font>"
		else
			ShowFlag = "<font class=pt9n>��</font>"
		end if
	else
		ShowFlag = "<font class=pt9>��</font>"
	end if
end function

function GetContainer(myJobCode, myRemarks)
dim myRec
dim mySql
dim myStr
dim buf, pos
	myStr = ""
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		Cnt20 = 0:	Cnt40 = 0:	CntEtc = 0
		mySql = "SELECT ContainerSize, COUNT(SeqNo) AS CNT FROM TBL_CTM_CONTAINER"
		mySql = mySql & " WHERE Deleted = 0 AND JobCode = '" & myJobCode & "' GROUP BY ContainerSize"
		.Open mySql, Conn ,adOpenKeyset ,adLockReadOnly
		do while not .eof
			select case GetString(.fields("ContainerSize"))
			case "20'":	Cnt20 = GetLong(.fields("CNT"))
			case "40'":	Cnt40 = GetLong(.fields("CNT"))
			case else :	CntEtc = GetLong(.fields("CNT"))
			end select
			.Movenext
		loop
		.close
		myCnt = Cnt20 + Cnt40 + CntEtc
		if myCnt > 0 then
			if Cnt20 > 0 then myStr = myStr & "+20'x" & Cnt20
			if Cnt40 > 0 then myStr = myStr & "+40'x" & Cnt40
			if CntEtc > 0 then myStr = myStr & "+��x" & CntEtc
			GetContainer = mid(myStr, 2)
		else
			buf = ucase(GetString(myRemarks))
			pos = instr(buf, "CONTAINER") 
			if pos <> 0 then
				GetContainer = "x" & GetLong(left(buf, pos - 1))
			end if
		end if
	end with
end function

function FitPlace(myDate)
dim buf, pos
	buf = GetString(myDate)
	if buf <> "" then
		pos = instrrev(buf, "(") - 1
		if pos > 0 then buf = left(buf, pos)
	end if
	FitPlace = buf
end function
%>