<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount

dim PatternID
dim PatternType
dim PatternName
dim PatternClient

dim ExpenseID
dim ExpenseCost
dim ExpenseType
dim ExpenseUnit
dim ExpensePrice
dim ExpenseTaxName
dim ExpenseMemo
dim Remarks

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	PatternID = GetLong(Request("PatternID"))
	Call GetPatternInfo(PatternID, PatternType, PatternClient, PatternCode, PatternName)
	ExpenseID = GetLong(Request("ExpenseID"))
	If ExpenseID = 0 Then
		blnEdit = False
		myTitle = "��ڃf�[�^�ǉ�"
		mySubmit = "�ǉ�"
		
		ExpenseCost = 0
		ExpenseType = 0
		ExpensePrice = 0
		ExpenseUnit = "��"
		ExpenseTaxName = ""
		ExpenseMemo = ""
		ExpenseMin = 0
		Remarks = ""
	Else
		blnEdit = True
		myTitle = "��ڃf�[�^�ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM PTN_EXPENSE WHERE ExpenseID = " & ExpenseID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			ExpenseCost = GetLong(Recset.Fields("ExpenseCost"))
			ExpenseType = GetLong(Recset.Fields("ExpenseType"))
			ExpensePrice = GetDouble(Recset.Fields("ExpensePrice"))
			ExpenseUnit = GetString(Recset.Fields("ExpenseUnit"))
			ExpenseTaxName = GetString(Recset.Fields("ExpenseTaxName"))
			ExpenseMemo = GetString(Recset.Fields("ExpenseMemo"))
			Remarks = GetString(Recset.Fields("Remarks"))
			ExpenseMin = GetMinPrice(Remarks)
				
			Creater = GetLong(Recset.fields("Creater"))
			Created = GetDate(Recset.fields("Created"))
			Updater = GetLong(Recset.fields("Updater"))
			Updated = GetDate(Recset.fields("Updated"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
		<SCRIPT LANGUAGE="VBScript">	
			sub ShowList()
				window.location.href = "ExpensePattern.asp?cd=<%=PatternClient%>"
			end sub
			
			sub DoSearch()
				dim win
				set win = window.open("ChargerSearch.asp?cd=" & frmInput.ChargeRef.value,"ChargerSearch","resizable=1,scrollbars=1,width=800,height=600")
			end sub	
			
			sub DoCopy()
			dim win, copy, code
				if frmInput.ChargeRef.value = "" or frmInput.ChargeClient.value = "" then
					frmInput.ChargeRef.focus()
					msgbox "�R�s�[��׎����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
					exit sub
				end if
				copy = "<%=PatternCode%>"
				code = frmInput.ChargeClient.value
				if code = "<%=PatternClient%>" then copy = "COPY"
				copy = inputbox("�p�^�[���R�[�h(5���܂�)����͂��Ă��������B"& vbcrlf & "[�L�����Z��]�F ��", "�p�^�[���R�[�h����", copy)
				if copy <> "" then window.location.href = "ExpenseCopy.asp?ID=<%=PatternID%>&CTM_CD=" & code & "&PTN_CD=" & copy
			end sub
			
			function AddNew()
				window.location.href = "ExpenseDetail.asp?PatternID=<%=PatternID%>&p=<%=myPage%>&s=<%=mySort%>"
			End function
					
			function ConfirmDelete(myID)
				if msgbox("�Y����ڂ��폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "ExpenseDetail0.asp?PatternID=<%=PatternID%>&ExpenseID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkDouble("ExpensePrice","��ڒP��", 1) = false then exit sub
				if checkText("ExpenseMemo","��ڔ��l", 0) = false then exit sub
				if checkLen("ExpenseMemo","��ڔ��l",250) = false then exit sub
				if checkText("Remarks","��ڃ���", 0) = false then exit sub
				if checkLen("Remarks","��ڃ���",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then frmInput.submit() 
			End Sub
			
			sub ExpenseCode_OnBlur()
				if frmInput.ExpenseCode.value <> "" then
					buf = len(frmInput.ExpenseCode.value)
					for each obj in frmInput.ExpenseCost.options
						if left(obj.text, buf) = ucase(frmInput.ExpenseCode.value) then
							obj.selected = true
							exit for
						end if
					next
				end if
			end sub
			
			sub ExpensePrice_OnBlur()
				frmInput.ExpensePrice.value = FitZero(formatnumber(GetDouble(frmInput.ExpensePrice.value), 2, true))
			end sub
			
			sub ExpenseMin_OnBlur()
			dim num
				num = GetLong(frmInput.ExpenseMin.value)
				if num = 0 then
					frmInput.ExpenseMin.value = ""
				else
					frmInput.ExpenseMin.value = formatnumber(num, 0, true)
				end if
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(frmInput.selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "ExpenseDetail.asp?PatternID=<%=PatternID%>&s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
	</HEAD>
	<BODY class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ExpenseDetail1.asp" ID=frmInput NAME=frmInput>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
						<INPUT type=hidden name="ExpenseID" value="<%=ExpenseID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD colspan=2 class=gline>����ڃ��X�g&nbsp;
	  								<img style="cursor:hand" src=img/back.gif alt="�p�^�[���ꗗ��" onmousedown="ShowList()">
								<TD colspan=2 class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td colspan=3><img src=img/spacer.gif height=3>
							<TR><TD class=pt9g align=center nowrap valign=top>�׎喼��
								<TD class=pt9g colspan=3><%=GetFullName(PatternClient)%>
							<TR><td colspan=3><img src=img/spacer.gif height=3>
							<TR><TD class=pt9g align=center nowrap>�p�^�[��
								<TD class=pt9g colspan=3><INPUT type=hidden NAME="PatternID" VALUE="<%=PatternID%>"><%=PatternCode%>(<%=PatternName%>)
							<TR><td><img src=img/spacer.gif height=3>
							<TR height=30>
								<TD align=center nowrap width=70>��p����
								<TD colspan=3><input class=si name="ExpenseCode" size=3 maxlength=3 value="" onkeydown="ResetEnter()">
									<select name="ExpenseCost" onkeydown="ResetEnter()"><%=ShowExpenseList(ExpenseCost)%></select>
							<TR height=30>
								<TD align=center nowrap>�P��
								<TD><select name="ExpenseUnit" onkeydown="ResetEnter()"><%=ShowCategoryList("ChargeUnit", ExpenseUnit, 1)%></select>
								<TD align=center nowrap>�P��
								<TD><INPUT class=sn NAME="ExpensePrice" MAXLENGTH=9 SIZE=8 VALUE="<%=FitZero(formatnumber(ExpensePrice, 2, true))%>" OnKeyDown="ResetEnter()">
							<TR height=30>
								<TD align=center nowrap>�ŋ敪
								<TD><select name="ExpenseTaxName" onkeydown="ResetEnter()"><%=ShowCategoryList("TaxCode", ExpenseTaxName, 1)%></select>
<%if PatternType = 0 then%>
								<TD align=center nowrap>����<INPUT type=hidden NAME="ExpenseType" VALUE="<%=gsCharge%>">
								<TD><INPUT class=sn NAME="ExpenseMin" MAXLENGTH=9 SIZE=8 VALUE="<%=ExpenseMin%>" OnKeyDown="ResetEnter()">
<%else%>
								<TD align=center nowrap>��p�敪
		 						<TD><select name="ExpenseType" onkeydown="ResetEnter()">
										<option value="<%=gsCharge%>" <%if ExpenseType = gsCharge then response.write " selected"%>>����
										<option value="<%=gsStand%>" <%if ExpenseType = gsStand then response.write " selected"%>>����
									</SELECT>
<%end if%>
							<TR>
								<TD align=center nowrap class=pt9>��ڔ��l
								<TD colspan=3><INPUT class=sj NAME="ExpenseMemo" MAXLENGTH=100 SIZE=40 VALUE="<%=ExpenseMemo%>" OnKeyDown="ResetEnter()">
							<TR>
								<TD align=center nowrap class=pt9>��ڃ���
								<TD colspan=3><textarea NAME="Remarks" style="width:250px;height:50px;"><%=Remarks%></textarea>
							
						</TABLE>
<%If ExpenseID <> 0 Then%>
						<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
						  <TR height=24 align=center>
							<TD width=12% class=pt9g nowrap>�쐬��<TD width=10% class=gline><%=GetEmployName(Creater, "F")%><br>
							<TD width=12% class=pt9g nowrap>�쐬��<TD width=15% class=gline><%=right(formatDate(Created),8)%><br>
							<TD width=12% class=pt9g nowrap>�X�V��<TD width=10% class=gline><%=GetEmployName(Updater, "F")%><br>
							<TD width=12% class=pt9g nowrap>�X�V��<TD width=15% class=gline><%=right(formatDate(Updated),8)%><br>
						</TABLE>
<%end if%>
						<BR>
<%	if PatternID <> "" then %>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
<%	end if %>
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
				
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center class=pt9>
					<%
					lngCount = 0
					strSQL = ""
					strSQL = strSQL & "SELECT ExpenseID,"
					strSQL = strSQL & "       COST_CD,"
					strSQL = strSQL & "       COST_NAME,"
					strSQL = strSQL & "       ExpenseType,"
					strSQL = strSQL & "       ExpensePrice,"
					strSQL = strSQL & "       ExpenseUnit,"
					strSQL = strSQL & "       ExpenseTaxName,"
					strSQL = strSQL & "       Remarks"
					strSQL = strSQL & "  FROM PTN_EXPENSE INNER JOIN MST_COST"
					strSQL = strSQL & "    ON PTN_EXPENSE.ExpenseCost = MST_COST.COST_ID"
					strSQL = strSQL & " WHERE PatternID = '" & PatternID & "'"
					Select Case mySort
					Case "jp"
						strSQL = strSQL & " ORDER BY ExpenseType, COST_CD;"
					Case "en"
						strSQL = strSQL & " ORDER BY ExpensePrice, COST_CD;"
					Case Else
						strSQL = strSQL & " ORDER BY ExpenseType DESC, COST_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										
									
								</table>
							
						
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.
							<TD class=line nowrap width=20%><a class=bar href="ExpenseDetail.asp?s=cd&PatternID=<%=PatternID%>">��p����</a>
							<TD class=line nowrap width=10%>�P��
							<TD class=line nowrap width=8%><a class=bar href="ExpenseDetail.asp?s=jp&PatternID=<%=PatternID%>">�敪</a>
							<TD class=line nowrap width=10%>�ŋ敪
							<TD class=line nowrap width=10%><a class=bar href="ExpenseDetail.asp?s=en&PatternID=<%=PatternID%>">�P��</a>
							<TD class=line nowrap width=20%>���l
							<TD class=line nowrap width=8%>�ҏW
							<TD class=line nowrap width=8%>�폜
						
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("COST_NAME"))
										myPrice = GetDouble(.Fields("ExpensePrice"))
										myUnit = GetString(.Fields("ExpenseUnit"))
										myRemarks = GetString(.Fields("Remarks"))
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR>
							<TD class=line nowrap align=left <%=ShowTitle(myName,15)%>><%=stringCut(myName,15)%><BR>
							<TD class=line nowrap <%=ShowTitle(myUnit,6)%>><%=stringCut(myUnit,6)%><BR>
							<TD class=line nowrap><%=ShowExpenseType(GetLong(.Fields("ExpenseType")))%><BR>
							<TD class=line nowrap><%=GetString(.Fields("ExpenseTaxName"))%><BR>
							<TD class=line nowrap align=right><%=FitZero(formatnumber(myPrice, 2, true))%><BR>
							<TD class=line nowrap align=left <%=ShowTitle(myRemarks,20)%>><%=stringCut(myRemarks,20)%><BR>
						<%
							If ExpenseID = GetLong(.Fields("ExpenseID")) Then
								Response.Write "<TD class=line nowrap>..."
							Else
								Response.Write "<TD class=line nowrap><A HREF=""ExpenseDetail.asp?p=" & myPage & "&s=" & mySort & "&PatternID=" & PatternID & "&ExpenseID=" & .Fields("ExpenseID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("ExpenseID")%>')">
						
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center class=pt9n>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
<%if lngCount > 0 then%>
					<br>
					�R�s�[��<input type=hidden name="ChargeClient" value="<%=PatternClient%>">
					<input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(PatternClient)%>" onkeydown="ResetEnter()">
					<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a>
					<input class=sj name="ChargeName" size=32 maxlength=50 value="<%=GetFullName(PatternClient)%>" onkeydown="ResetEnter()" readonly>	
					<input type=button name=btnCopy value="�R�s�[" onclick="DoCopy()" style="width:90;height:30">
<%end if%>
		</TABLE>
	</FORM>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>

<%
function GetMinPrice(myStr)
dim buf, pos
	GetMinPrice = ""
	pos = instr(myStr, "�~")
	if pos = 0 then exit function	
	
	buf = left(myStr, pos - 1)
	if left(buf, 4) <> "����" then exit function
	
	myStr = mid(myStr, pos + 1)
	GetMinPrice = formatnumber(GetLong(mid(buf, 5)), 0, false)
	if GetMinPrice = 0 then GetMinPrice = ""
end function

function ShowExpenseList(myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT COST_ID, COST_CD, COST_NAME FROM MST_COST"
	mySql = mySql & " WHERE COST_DELETED = 0"
	mySql = mySql & " ORDER BY COST_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("COST_ID")
		if myDft = myRec.fields("COST_ID") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("COST_CD") & " " & myRec.fields("COST_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowExpenseList = buf	
end function

function GetPatternInfo(myID, myType, myClient, myCode, myName)
dim mySql
dim myRec

	GetPatternType = 0
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT CTM_CD, PATN_TYPE, PATN_CD, PATN_NAME FROM MST_PATTERN WHERE PATN_ID = " & myID
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if not myRec.eof then 
		myClient = GetString(myRec.fields("CTM_CD"))
		myType = GetLong(myRec.fields("PATN_TYPE"))
		myCode = GetString(myRec.Fields("PATN_CD"))
		myName = GetString(myRec.Fields("PATN_NAME"))
	end if
	myRec.close
	set myRec = nothing	
	
end function
%>