<%
'on error resume next
	
	mode = clng("0" & Request("mode"))
	myType = clng("0" & Request("type"))
	JobCode = cstr(Request("JobCode") & "")
	if instr(JobCode, " ") <> 0 then JobCode = ""
	if JobCode <> "" then
		url = "../common/blank.htm"
		CostsNo = cstr(Request("CostsNo") & "")
		if CostsNo <> "" then
			if mode = 1 then
				url = "paymentHead.asp?type=" & myType & "&JobCode=" & JobCode & "&CostsNo=" & CostsNo			'����g���ĂȂ�
			elseif mode = 2 then
				url = "CostsList.asp?type=2&JobCode=" & JobCode & "&CostsNo=" & CostsNo
			end if
		end if
%>
<HTML>
<HEAD>
<TITLE>�x���`�[�ꗗ���</TITLE>
</HEAD>
	<FRAMESET rows="170,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="CostsBill.asp?type=<%=myType%>&JobCode=<%=JobCode%>" NAME="list" MARGINWIDTH="10" MARGINHEIGHT="0">
		<FRAME SRC="<%=url%>" NAME="data" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>
<%
	end if
%>