<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim CostsNo
dim CostsDate
dim CostsClient
dim CostsAmount
dim CostsTax
dim PatternID

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	myType = GetString(Request("Type"))
	JobCode = GetString(Request("JobCode"))
	CostsNo = GetString(Request("CostsNo"))
	PatternID = GetLong(Request("PatternID"))
	Recset.Open "SELECT CostsClient, CostsDate FROM TBL_CTM_COSTS WHERE CostsNo='" & CostsNo & "'", Conn ,adOpenKeyset ,adLockReadOnly
	if not Recset.EOF then 
		CostsDate = GetString(Recset.Fields("CostsDate"))
		CostsClient = GetString(Recset.Fields("CostsClient"))
	end if
	Recset.Close
	
	myMode = GetLong(request("mode"))
	if myMode = 1 then
		msg = ""
		SeqNo = GetString(Request("SeqNo"))
		
		strSQL = "SELECT ExpenseType, COST_CD, ExpenseCost, ExpensePrice, ExpenseUnit, ExpenseTaxName, ExpenseMemo"
		strSQL = strSQL & ", Remarks FROM PTN_EXPENSE INNER JOIN MST_COST ON PTN_EXPENSE.ExpenseCost = MST_COST.COST_ID"
		strSQL = strSQL & " WHERE PatternID = " & PatternID & " AND ExpenseID IN (" & SeqNo & ")"
		strSQL = strSQL & " ORDER BY COST_CD, ExpenseMemo"
		Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if Recset.EOF then msg = "�Y����ڂ͌�����܂���ł����B"
		
		if msg = "" then
			
			Conn.BeginTrans
			
			call GetCostsPattern(Recset)
			
			'�x���`�[�X�V
			CostsAmount = 0
			CostsTax = 0
			with Recset
				strSql = "SELECT SUM(ExpenseAmount) AS CostsAmount, SUM(ExpenseTax) AS CostsTax FROM TBL_CTM_EXPENSE"
				strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpensePay = '" & CostsNo & "'"
				strSql = strSql & " AND ExpenseType IN (" & gsPayment & "," & gsStand & ")"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					CostsAmount = GetLong(.fields("CostsAmount"))
					CostsTax = GetLong(.fields("CostsTax"))
				end if
				.close
			end with
			
			strSql = "UPDATE TBL_CTM_COSTS SET CostsAmount = " &  GetLong(CostsAmount) & ", CostsTax = " &  GetLong(CostsTax)
			strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
			Conn.Execute strSql
						
			if err.number = 0 then
				Conn.CommitTrans
			else
				Conn.RollbackTrans
				msg = "���������L�̃G���[���N����܂����B(" & err.number & ":" & err.description & ")"
			end if
		end if
		
		if msg <> "" then
			ShowMessage msg
		else
%>
<html><script language=javascript>
window.opener.location.href = "CostsList.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&type=<%=myType%>";
if (window.opener.parent.list != null) window.opener.parent.list.location.href = "CostsBill.asp?JobCode=<%=JobCode%>";
window.close();
</script></html>
<%
		end if
	else
%>
<HTML>
<HEAD>
	<TITLE><%=myTitle%></TITLE>
	<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
	<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	<SCRIPT LANGUAGE="VBScript">
		function ShowPattern(myID)
			window.location.href = "CostsPattern.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&type=<%=myType%>&PatternID=" & myID
		end function
		
		function DoCheck()
			Call CheckAll("SeqNo", frmInput.CheckAll.Checked)
		end function 
		
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 5) = "SeqNo" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�x����p��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("����ł�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.submit()
		end function 
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
			if window.event.keyCode=120 then call DoConfirm()
		end sub
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsCostsBackColor%>" class=pt9n onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CostsPattern.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value="1">
		<input type=hidden name="type" value="<%=myType%>">
		<input type=hidden name="JobCode" value="<%=JobCode%>">
		<input type=hidden name="CostsNo" value="<%=CostsNo%>">
		<input type=hidden name="PatternID" value="<%=PatternID%>">
		<TABLE width=100%><TR>
			<!----------left---------->
			<TD width=40% ALIGN=center VALIGN=TOP>
				<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  			<TR height=18>
		  				<td class=pt9n>�������p�^�[���ꗗ&nbsp;
		  			<TR><td><hr width=98% size=1 color=blue>
				</table>
				<TABLE width=90% BORDER=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9n>
					<TR height=24 ALIGN=CENTER bgcolor=#E0E0E0>
						<TD nowrap width=10%>No.</TD>
						<TD nowrap width=20%>����</TD>
						<TD nowrap width=50%>�a������</TD>
						<TD nowrap width=10%>����</TD>
			<%
				With Recset
					strSql = ""
					strSql = strSql & "SELECT CASE PATN_CREATER WHEN " & WebUserID & " THEN 0 ELSE 1 END AS kb,"
					strSql = strSql & " PATN_ID, PATN_CD, PATN_NAME, PATN_CNT FROM MST_PATTERN LEFT JOIN ("
					strSql = strSql & "SELECT PatternID, COUNT(ExpenseCost) AS PATN_CNT FROM PTN_EXPENSE GROUP BY PatternID"
					strSql = strSql & ") AS TMP ON MST_PATTERN.PATN_ID = TMP.PatternID WHERE PATN_DELETED = 0"
					strSql = strSql & " AND PATN_TYPE = 1 AND PATN_BELONG = '" & CheckJobType(JobCode) & "'"				
					Recset.Open strSql & " AND CTM_CD = '" & CostsClient & "' ORDER BY kb, PATN_CD", Conn ,adOpenKeyset ,adLockReadOnly
					if Recset.EOF then
						Recset.Close
						Recset.Open strSql & " AND CTM_CD = '" & gsDummy & "' ORDER BY kb, PATN_CD", Conn ,adOpenKeyset ,adLockReadOnly
					end if
					cnt = 0
					Do while not .EOF
						cnt = cnt + 1
						mybgcolor = "#FFFFFF"
						If PatternID = GetLong(.Fields("PATN_ID")) Then	mybgcolor = "#C0FFC0"
						myName = GetString(.Fields("PATN_NAME"))
			%>
					<TR height=24 style="cursor:hand" onmousedown="ShowPattern(<%=GetLong(.Fields("PATN_ID"))%>)">
						<TD nowrap bgcolor=#E0E0E0 align=center><%=cnt%>
						<TD nowrap bgcolor="<%=mybgcolor%>"><%=GetString(.Fields("PATN_CD"))%>
						<TD bgcolor="<%=mybgcolor%>"><%=myName%>
						<TD nowrap bgcolor="<%=mybgcolor%>" align=center><%=GetLong(.Fields("PATN_CNT"))%>
			<%
						.MoveNext
					Loop
					.Close
				End With
			%>
				</TABLE>
			
			<!----------right---------->
			<TD width=60% VALIGN=TOP align=center class=pt9>
				<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		  			<TR height=18>
		  				<td width=50% align=left>����p���׈ꗗ&nbsp;
	 	  				<td width=50% align=right><img style="cursor:hand" src=img/save.gif alt="�m��" onmousedown="DoConfirm()">&nbsp;
		  			<TR><td colspan=2><hr width=98% size=1 color=blue>
				</table>
				<%
					strSQL = "SELECT ExpenseID AS SeqNo, COST_CD, COST_NAME, ExpensePrice, ExpenseUnit, ExpenseTaxName, ExpenseMemo"
					strSQL = strSQL & ",Remarks FROM PTN_EXPENSE INNER JOIN MST_COST ON PTN_EXPENSE.ExpenseCost = MST_COST.COST_ID"
					strSQL = strSQL & " WHERE PatternID = '" & PatternID & "'"
					strSQL = strSQL & " ORDER BY COST_CD, ExpenseMemo"
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not recset.EOF then
				%>
				<TABLE width=90% BORDER=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9n>
					<TR ALIGN=CENTER bgcolor=#E0E0E0>
						<TD nowrap width=5%>No.
						<TD nowrap width=50%>��p����
						<TD nowrap width=10%>�P��
						<TD nowrap width=15%>�P��
						<TD nowrap width=10%>�ŋ敪
						<TD nowrap width=10%><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�I��
				<%
						With Recset
							cnt = 0
							Do While not .EOF
								cnt = cnt + 1
								myName = GetString(.Fields("COST_NAME"))
								myMemo = GetString(.Fields("ExpenseMemo"))
								if myName = "���̑�����" OR myName = "RANDOM" then 
									if myMemo <> "" then myName = myMemo
								elseif myMemo <> "" then 
									myName = myName & " [" & left(myMemo, 17) & "]"
								end if
								myPrice = GetDouble(.Fields("ExpensePrice"))
								myUnit = GetString(.Fields("ExpenseUnit"))
								myRemark = GetString(.Fields("Remarks"))
								if myRemark = "" then
				%>
					<TR align=center>
						<TD bgcolor=#E0E0E0><%=cnt%><BR>
						<TD nowrap align=left><%=myName%><BR>
						<TD nowrap <%=ShowTitle(myUnit,6)%>><%=stringCut(myUnit,6)%><BR>
						<TD nowrap align=right><%=FitZero(formatnumber(myPrice, 2, true))%><BR>
						<TD nowrap><%=GetString(.Fields("ExpenseTaxName"))%><BR>
						<TD><input type=checkbox name="SeqNo" value="<%=GetLong(.Fields("SeqNo"))%>">
				<%
								else
				%>
					<TR align=center>
						<TD rowspan=2 bgcolor=#E0E0E0><%=cnt%><BR>
						<TD nowrap align=left><%=myName%><BR>
						<TD nowrap <%=ShowTitle(myUnit,6)%>><%=stringCut(myUnit,6)%><BR>
						<TD nowrap align=right><%=FitZero(formatnumber(myPrice, 2, true))%><BR>
						<TD nowrap><%=GetString(.Fields("ExpenseTaxName"))%><BR>
						<TD rowspan=2><input type=checkbox name="SeqNo" value="<%=GetLong(.Fields("SeqNo"))%>">
					<TR><TD colspan=4 class=pt9g><%=myRemark%><BR>
				<%
								end if
								.MoveNext
							Loop
							.Close
						End With
					else
						Response.Write "<br><div align=center class=pt9n>�Y���f�[�^��������܂���ł����B</div>"	
					end if
				%>
				</TABLE>
<!--
				<br>
				<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  			<TR><td align=center>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="F9:�m��" OnClick="DoConfirm()">�@�@
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnClose VALUE="����" OnClick="window.close()">
				</table>
-->
		</TABLE>
	</FORM>
</BODY>
</HTML>
<%
	end if
	Set Recset = Nothing
	CloseDB Conn
%>

<%
'���̉�ʂ̂݌Ăяo���A�p�����[�^�s�v�A�w�b�_��`�ς�
function GetCostsPattern(myRs)
dim mySql
dim myRec
dim mySeq
dim myTyp
dim myPrc
dim myTax
	
	Set cmdSQL = Server.CreateObject("ADODB.Command")
	Set cmdSQL.ActiveConnection = Conn
	cmdSQL.CommandType = 4
	cmdSQL.CommandText = "DB_CTM_NEW_SUB"
	cmdSQL.Parameters.Refresh
	cmdSQL.Parameters("@SubCode").Value = "Expense"
	
	set myRec = Server.CreateObject("adodb.recordset")
	mySql ="SELECT * FROM TBL_CTM_EXPENSE"
	myRec.Open mySql, Conn, adOpenKeyset, adLockOptimistic 							
	do while not myRs.eof 
		'SeqNo�擾	
		cmdSQL.Execute
		mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
		
		myTyp = GetLong(myRs.fields("ExpenseType"))
		if myTyp = gsCharge then myTyp = gsPayment
		
		myPrc = GetDouble(myRs.fields("ExpensePrice"))
		myTax = ResetDigital(myPrc * GetTaxRate(myRs.fields("ExpenseTaxName")), 0, -1)
		
		with myRec
			.AddNew
			.fields("JobCode") = JobCode
			.fields("SeqNo") = mySeq
			.fields("ExpenseClient") = CostsClient
			.fields("ExpenseDate") = CostsDate
			.fields("ExpenseType") = myTyp
			.fields("ExpenseAttr") = 0
			
			.fields("ExpenseCost") = GetLong(myRs.fields("ExpenseCost"))				
			.fields("ExpensePrice") = myPrc
			.fields("ExpenseQuantity") = 1
			.fields("ExpenseUnit") = GetString(myRs.fields("ExpenseUnit"))
			.fields("ExpenseAmount") = myPrc
			.fields("ExpenseTaxName") = GetString(myRs.fields("ExpenseTaxName"))
			.fields("ExpenseTax") = GetLong(myTax)
			
			.fields("ExpensePay") = CostsNo
			.fields("ExpenseMemo") = myRs.fields("ExpenseMemo")
			.fields("Remarks") = myRs.fields("Remarks")
			
			.fields("Updater") = WebUserID
			.fields("Creater") = WebUserID
			.update
		end with
		myRs.movenext
	loop
	myRs.close
	myRec.close	
	set myRec = nothing
	
end function
%>