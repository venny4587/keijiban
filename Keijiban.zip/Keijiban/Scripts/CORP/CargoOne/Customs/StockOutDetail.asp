<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim SeqNo
dim JobClient
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
		
	SeqNo = GetLong(request("SeqNo"))
	if SeqNo <> 0 then
		with Recset
			strSql = "SELECT * FROM TBL_CTM_STOCK WHERE Deleted = 0 AND SeqNo = " & SeqNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if .eof then
				SeqNo = 0
			else
				JobCode = GetString(.fields("JobCode"))
				StockClient = GetString(.fields("StockClient"))
				StockReferNo = GetString(.fields("StockReferNo"))
				
				StockNo = GetString(.fields("StockNo"))
				StockDate = Str2Date(.fields("StockDate"))
				StockTime = GetString(.fields("StockTime"))
				StockCode = GetString(.fields("StockCode"))
				StockName = GetString(.fields("StockName"))
				
				StockPkgCnt = GetLong(.fields("StockPkgCnt"))
				StockPkgZan = GetLong(.fields("StockPkgZan"))
				StockPackage = GetString(.fields("StockPackage"))
				StockGW = GetDouble(.fields("StockGW"))
				StockCBM = GetDouble(.fields("StockCBM"))
				StockMark = GetString(.fields("StockMark"))
				
				StockPlace = GetString(.fields("StockPlace"))
				StockDelivery = GetString(.fields("StockDelivery"))
				StockStatus = GetString(.fields("StockStatus"))
				StockLot = GetString(.fields("StockLot"))
				StockDivision = GetString(.fields("StockDivision"))
				StockMemo = GetString(.fields("StockMemo"))
				Remarks = GetString(.fields("Remarks"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
		end with
		if StockDate <> "" then
			Exported = (StockDate < formatDate(date))
		end if
	else
		StockClient = GetString(Session("StockIn_Client"))
		with Recset
			strSql = "SELECT CTM_ABR FROM CUSTOMER WHERE CTM_CD = '" & StockClient & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then StockCode = GetString(.fields("CTM_ABR"))
			.close
		end with
		StockPlace = "�ېőq��"
		StockDivision = "����"
	end if
%>
<html>
<HEAD>
	<TITLE>�o�ɏڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoAddNew()
			dim win
			set win = window.open("StockOutSelect.asp?CTM_CD=<%=StockClient%>","StockOutSelect","resizable=1,scrollbars=1,width=600,height=400")
		end sub
		
		sub DoPlace()
			dim win
			set win = window.open("StockDoorSearch.asp?CTM_CD=<%=StockClient%>","StockDoorSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub DoPrint()
			dim win
			set win = window.open("StockOutPrint.asp?SeqNo=<%=SeqNo%>","StockOutPrint","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub DoDelivery(mode)
			dim win
			select case mode
			case 1:		txt = "StockPlace"
			case 2:		txt = "StockDelivery"
			end select
			set win = window.open("StockSearch.asp?mode=" & mode & "&txt=" & txt,"PlaceSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub DoGoods()
			if frmInput.ShipperName.value = "" then
				frmInput.Shipper.focus()
				msgbox "�����׎����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			dim win
			set win = window.open("StockGoods.asp?Client=" & frmInput.JobShipper.value & "&cd=" & frmInput.StockCode.value,"StockGoods","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		sub StockDate_OnBlur()
			frmInput.StockDate.value = SetDate(frmInput.StockDate.value)
		end sub
		sub StockStatus_OnBlur()
			frmInput.StockStatus.value = SetDate(frmInput.StockStatus.value)
		end sub
		
		sub DataSave()
		dim buf
			if checkText("StockClient","�����׎�",1) = false then exit sub
			if checkNum("StockPkgCnt","�o�ɐ�",1) = false then exit sub
			
			if checkDate("StockDate","�o�ɓ�", 1) = false then exit sub
			if checkText("StockNo","�o�ɔԍ�",0) = false then exit sub
			if checkDate("StockStatus","���ד�", 0) = false then exit sub
			if checkText("JobCode","�䒠�ԍ�", 0) = false then exit sub
			
			if checkText("StockName","�[�i��",1) = false then exit sub
			if checkText("StockMark","�[�i��Z��",1) = false then exit sub
			if checkText("StockCode","�[�i��S����",0) = false then exit sub
			if checkText("StockReferNo","�[�i��d�b�ԍ�",1) = false then exit sub
			
			if checkText("StockPlace","���n�ꏊ",1) = false then exit sub
			if checkText("StockDelivery","�^���Ǝ�",1) = false then exit sub
			if checkText("StockMemo","�o�Ƀ���", 0) = false then exit sub
			if checkLen("StockMemo","�o�Ƀ���", 250) = false then exit sub
			if checkText("Remarks","�Г����l", 0) = false then exit sub
			if checkLen("Remarks","�Г����l", 250) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then call DataSave() 
			if window.event.keyCode=27 then window.close()
		end sub
		
		function SetInpData(myIdx, myMax, myGW, myCBM)
			dim buf
			for each obj in frmInput.elements
				if obj.type = "text" then
					if obj.name = "PKG" & myIdx then
						buf = GetLong(obj.value)
						if buf > myMax then buf = myMax
						obj.value = buf
						document.all("GW" & myIdx).innerText = formatnumber(myGW * buf, 0, true)
						document.all("CBM" & myIdx).innerText = formatnumber(myCBM * buf, 3, true)
						call ResetTotal()
						exit for
					end if
				end if
			next
		end function
		
		function ResetTotal()
			dim i, cnt, gw, cbm, sum
			cnt = GetLong(frmInput.StockCnt.value)
			sum = 0:	gw = 0:		cbm = 0
			for each obj in frmInput.elements
				if obj.type = "text" and left(obj.name, 3) = "PKG" then
					sum = sum + GetLong(obj.value)
				end if
			next
			for i = 1 to cnt
				gw = gw + GetDouble(document.all("GW" & cstr(i)).innerText)
				cbm = cbm + GetDouble(document.all("CBM" & cstr(i)).innerText)
			next
			frmInput.StockGW.value = formatnumber(gw, 0, true)
			frmInput.StockCBM.value = formatnumber(cbm, 3, true)
			frmInput.StockPKG.value = formatnumber(sum, 0, true)
		end function
		
		sub InitForm()
<%if Exported <> 0 then%>
			call LockAll()
<%else%>
			frmInput.StockDate.focus()
<%end if%>
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsStockBackColor%>" onload="InitForm()" topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="StockOutUpdate.asp" method="post">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="mode" value="1">
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=60% align=center valign=top>
	  		<table width=96% class=pt9n>
	  			<tr><td width=50%>���o�ɏ��i�ꗗ&nbsp;
<%if SeqNo <> 0 and (Exported = 0 or WebUserID = 1) then %>
		  				<img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
	  				<td width=50% align=right>
<%if SeqNo <> 0 then %>
	  	  				<img style="cursor:hand" src=img/print.jpg alt="���" onmousedown="DoPrint()">
<%end if%>
		  	</table>
			<hr width=96% size=1><br>
			<table width=96% Border=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9n>
			  <colgroup align=center>
			  <colgroup span=2 align=left>
			  <colgroup span=4 align=center>
			  <TR height=28>
			  	<TD nowrap>��
<%if StockClient = "3865" then%>
			  	<TD nowrap>�I��
<%else%>
			  	<TD nowrap>�i��
<%end if%>
			  	<TD nowrap>�i��
			  	<TD nowrap>�݌�
			  	<TD nowrap>KGS
			  	<TD nowrap>CBM
			  	<TD nowrap>�o��
<%
		with Recset
			if SeqNo <> 0 then
				strSql = "SELECT SeqNo, StockCode, StockName, StockPkgCnt, StockPkgZan, StockPackage, StockGW, StockCBM, StockReferNo, Packages"
				strSql = strSql & " FROM TBL_CTM_STOCK AS S INNER JOIN TBL_CTM_STOCK_LINK AS L ON S.SeqNo = L.ImportNo"
				strSql = strSql & " WHERE Deleted = 0 AND ExportNo = " & SeqNo
			else
				strSql = "SELECT SeqNo, StockCode, StockName, StockPkgCnt, StockPkgZan, StockPackage, StockGW, StockCBM, StockReferNo, StockPkgZan AS Packages"
				strSql = strSql & " FROM TBL_CTM_STOCK WHERE Deleted = 0 AND StockClient = '" & StockClient & "'"
				strSql = strSql & " AND SeqNo IN (" & Session("StockIn_Select") & ")"
			end if
			strSql = strSql & " ORDER BY StockReferNo, StockCode, StockDate, StockNo"
if WebUserID = gsAdmin then response.write strSql
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			cnt = 0:	sumPKG = 0
			sumZAN = 0:		sumGW = 0:	sumCBM = 0
			do while not .eof
				cnt = cnt + 1
				GW = 0:		CBM = 0
				ZAN = GetLong(.fields("StockPkgZan"))
				PKG = GetLong(.fields("Packages"))
				if SeqNo <> 0 then ZAN = ZAN + PKG
				if GetLong(.fields("StockPkgCnt")) <> 0 then
					GW = formatnumber(GetDouble(.fields("StockGW")) / GetLong(.fields("StockPkgCnt")), 6, 0)
					CBM = formatnumber(GetDouble(.fields("StockCBM")) / GetLong(.fields("StockPkgCnt")), 6, 0)
				end if
%>
				<tr><td><%=cnt%><input type=hidden name="SeqNo<%=cnt%>" value="<%=GetLong(.fields("SeqNo"))%>">
<%if StockClient = "3865" then%>
					<td nowrap><%=GetString(.fields("StockReferNo"))%><br>
<%else%>
					<td><%=GetString(.fields("StockCode"))%><br>
<%end if%>
					<td><%=GetString(.fields("StockName"))%>
					<td><div id="ZAN<%=cnt%>" style="width:40;text-align:right"><%=formatnumber(ZAN, 0, true)%></div>
					<td><div id="GW<%=cnt%>" style="width:50;text-align:right"><%=formatnumber(GW * PKG, 0, true)%></div>
					<td><div id="CBM<%=cnt%>" style="width:50;text-align:right"><%=formatnumber(CBM * PKG, 3, true)%></div>
					<td><input class=sn name="PKG<%=cnt%>" maxlength=5 size=3 value="<%=PKG%>" onkeydown="ResetEnter()" onblur="SetInpData(<%=cnt%>,<%=ZAN%>,<%=GW%>,<%=CBM%>)">
<%
				sumZAN = sumZAN + ZAN
				sumPKG = sumPKG + PKG
				sumGW = sumGW + GW * PKG
				sumCBM = sumCBM + CBM * PKG
				
				.movenext
			loop
			.Close
		end with
%>
			  <TR height=28>
			  	<TD colspan=3>���v<input type=hidden name="StockCnt" value="<%=cnt%>">
			  	<TD nowrap><div id="TTL" style="width:40;text-align:right"><%=formatnumber(sumZAN, 0, true)%></div>
			  	<TD nowrap><input class=sn name="StockGW" maxlength=8 size=6 value="<%=formatnumber(sumGW, 0, true)%>" readonly>
			  	<TD nowrap><input class=sn name="StockCBM" maxlength=8 size=6 value="<%=formatnumber(sumCBM, 3, true)%>" readonly>
			  	<TD nowrap><input class=sn name="StockPKG" maxlength=5 size=3 value="<%=formatnumber(sumPKG, 0, true)%>" readonly>
			</table>
		<td width=40% align=center valign=top>
	  		<table width=96% class=pt9n>
	  			<tr><td width=40%>���o�ɏڍ׏��&nbsp;
	  				<td width=40%><%if SeqNo = 0 then%><a class=bar href="javascript:DoAddNew()">�y�ǋL�z</a><%end if%>
	  				<td width=20% align=right>
<%if WebUserID = 1 or Exported = 0 then%>
	  	  				<img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
<%else%>
	  	  				<img style="cursor:hand" src=img/security.gif alt="�o�ɍ�">
<%end if%>
		  	</table>
			<hr width=96% size=1>
			<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
			  <TR height=28><TD nowrap class=pt9g>
					�׎喼&nbsp;<%=GetFullName(StockClient)%><input type=hidden name="JobShipper" value="<%=StockClient%>">
			  <TR height=28><TD nowrap>
					�o�ɓ�<input class=si name="StockDate" size=9 maxlength=10 value="<%=StockDate%>" onkeydown="ResetEnter()" onclick="setday(this)">
					<font class=pt9>�o�ɔԍ�</font>&nbsp;<input class=sj name="StockNo" size=16 maxlength=20 value="<%=StockNo%>" onkeydown="ResetEnter()">
			  <TR height=28><TD nowrap class=pt9>
					<font class=pt9n>���ד�</font><input class=si name="StockStatus" size=9 maxlength=10 value="<%=StockStatus%>" onkeydown="ResetEnter()" onclick="setday(this)">
					����<input class=sj name="StockTime" size=5 maxlength=5 value="<%=StockTime%>" onkeydown="ResetEnter()">
					�䒠�ԍ�<input class=si name="JobCode" size=9 maxlength=10 value="<%=JobCode%>" onkeydown="ResetEnter()">
			  <TR height=28><TD nowrap>
					�[�i��<a href="javascript:DoPlace()"><img src=img/search.jpg border=0 alt="����"></a>
					<input class=sj name="StockName" size=34 maxlength=50 value="<%=StockName%>" onkeydown="ResetEnter()">
			  <TR height=28><TD nowrap>
					TEL&nbsp;<input class=si name="StockReferNo" size=12 maxlength=20 value="<%=StockReferNo%>" onkeydown="ResetEnter()">
					�o�׎�&nbsp;<input class=sj name="StockCode" size=18 maxlength=15 value="<%=StockCode%>" onkeydown="ResetEnter()">
			  <TR height=28><TD nowrap>
					�Z��&nbsp;<input class=sj name="StockMark" size=39 maxlength=200 value="<%=StockMark%>" onkeydown="ResetEnter()">
			  <TR height=28><TD nowrap>
					���n�ꏊ&nbsp;<a href="javascript:DoDelivery(1)"><img src=img/search.jpg border=0 alt="����"></a>
					<input class=sj name="StockPlace" size=20 maxlength=50 value="<%=StockPlace%>" onkeydown="ResetEnter()">
					�S��&nbsp;<input class=sj name="StockDivision" size=6 maxlength=10 value="<%=StockDivision%>" onkeydown="ResetEnter()">
			  <TR height=28><TD nowrap>
					�^���Ǝ�&nbsp;<a href="javascript:DoDelivery(2)"><img src=img/search.jpg border=0 alt="����"></a>
					<input class=sj name="StockDelivery" size=20 maxlength=50 value="<%=StockDelivery%>" onkeydown="ResetEnter()">
					�S��&nbsp;<input class=sj name="StockLot" size=6 maxlength=10 value="<%=StockLot%>" onkeydown="ResetEnter()">
			  <TR height=20><TD class=pt9 valign=bottom>�o�Ƀ���
			  <TR><TD><textarea name="StockMemo" rows=4 style="width:280"><%=StockMemo%></textarea>
			  <TR height=20><TD class=pt9 valign=bottom>�Г����l
			  <TR><TD><textarea name="Remarks" rows=4 style="width:280"><%=Remarks%></textarea>
			</TABLE>
  </FORM>
<%if SeqNo <> 0 then%>
			<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
			  <TR align=center>
				<TD width=16% class=pt9g>�쐬��<TD width=18% class=gline><%=right(formatDate(Updated), 8)%><br>
				<TD width=16% class=pt9g>�X�V��<TD width=18% class=gline><%=right(formatDate(Updated), 8)%><br>
				<TD width=16% class=pt9g>�X�V��<TD width=16% class=gline><%=GetEmployName(Updater, "F")%><br>
			</TABLE>
<%end if%>
	</table>
<center>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
%>
