<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		BrokerRef = ""
	else
		JobType = GetPost(request("JobType"))
		ClientRef = GetPost(request("ClientRef"))
		BrokerRef = GetPost(request("BrokerRef"))
		OrderFrom = GetPost(request("OrderFrom"))
		OrderTo = GetPost(request("OrderTo"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		Process = GetLong(request("Process"))
	end if

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
		
		sub DoPrint()
		dim win
			set win = window.open("DeliveryCover.asp?cd=<%=BrokerRef%>&dt1=<%=OrderFrom%>&dt2=<%=OrderTo%>","DeliveryCover","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end sub
		
		sub OrderFrom_OnBlur()
			frmInput.OrderFrom.value = setdate(frmInput.OrderFrom.value)
		end sub		
		sub OrderTo_OnBlur()
			frmInput.OrderTo.value = setdate(frmInput.OrderTo.value)
		end sub		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
				
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="DeliveryView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�Ɩ��敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=9 onkeydown="ResetEnter()">
				�^���Ǝ�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="BrokerRef" value="<%=BrokerRef%>" maxlength=10 size=9 onkeydown="ResetEnter()">
				�W�ד�<input class=si name="OrderFrom" value="<%=OrderFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="OrderTo" value="<%=OrderTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				�[�i��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
<!--				�����Ɩ�<input type=checkbox name="Process" value="1" onkeydown="ResetEnter()" <%if Process then response.write " checked"%>>	-->
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)	
		if BrokerRef <> "" then	strSel = strSel & " AND BrokerRef = '" & FitSel(BrokerRef) & "'"
		if OrderFrom <> "" then strSel = strSel & " AND OrderDate >= '" & Date2Str(OrderFrom) & "'"
		if OrderTo <> "" then strSel = strSel & " AND OrderDate <= '" & Date2Str(OrderTo) & "'"
		if DateFrom <> "" then strSel = strSel & " AND DeliveryDate >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND DeliveryDate <= '" & Date2Str(DateTo) & "'"
'		if Process = 0 then strSel = strSel & " AND FinisherID = 0"
		
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT D.JobCode, C.CTM_CD, ClientRef, BrokerRef, FinisherID, DeliveryType, Contents, D.DeliveryDate, DeliveryFrom, DeliveryTo, OrderDate"
		strSQL = strSQL & ",ISNULL(Addr, '') AS DeliveryDoor, D.Remarks FROM TBL_CTM_DELIVERY AS D INNER JOIN TBL_CTM_JOB AS J ON D.JobCode = J.JobCode"
		strSQL = strSQL & " LEFT JOIN (SELECT DOOR_ID, DOOR_NAME AS Addr FROM CTM_DOOR) AS R ON D.DeliveryTo = R.DOOR_ID"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON D.DeliveryBroker = B.CTM_CD"
		strSQL = strSQL & " WHERE D.Deleted = 0 AND J.Deleted = 0) AS TMP"
		if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel, 5)
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY DeliveryDate, JobCode"
		case 1:		strSQL = strSQL & " ORDER BY JobCode"
		case 2:		strSQL = strSQL & " ORDER BY ClientRef, DeliveryDate, JobCode"
		case 3:		strSQL = strSQL & " ORDER BY BrokerRef, DeliveryDate, JobCode"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=2 align=center>
			<colgroup span=4 align=left>
			<colgroup align=center>
			<colgroup span=4 align=left>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=4% nowrap>�敪
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����׎�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�[�i��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�^���Ǝ�
			<TD width=8% nowrap>�[�i���@
			<TD width=12% nowrap>�[�i���e
			<TD width=10% nowrap>�N�_
			<TD width=20% nowrap>�I�_
			<TD width=10% nowrap>���l
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						Client = GetString(.Fields("ClientRef"))
						Broker = GetString(.Fields("BrokerRef"))
						Contents = GetString(.Fields("Contents"))
						DeliveryType = GetString(.Fields("DeliveryType"))
						DeliveryFrom = GetString(.Fields("DeliveryFrom"))
						DeliveryTo = GetString(.Fields("DeliveryTo"))
						DeliveryDoor = GetString(.Fields("DeliveryDoor"))
						if DeliveryDoor = "" then DeliveryDoor = "�[�i�����ɋL��"
						Memo = GetString(.Fields("Remarks"))
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("JobCode")%>');">
						<TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=GetJobDivision(CheckJobType(.Fields("JobCode")))%>
						<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%><BR>
						<TD nowrap class=line <%=ShowTitle(Client, 8)%>><%=stringCut(Client, 8)%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("DeliveryDate"))%><BR>
						<TD nowrap class=line <%=ShowTitle(Broker, 8)%>><%=stringCut(Broker, 8)%><BR>
						<TD nowrap class=line><%=DeliveryType%><BR>
						<TD nowrap class=line align=left <%=ShowTitle(Contents, 15)%>><%=stringCut(Contents, 15)%><BR>
						<TD nowrap class=line <%=ShowTitle(DeliveryFrom, 8)%>><%=stringCut(DeliveryFrom, 8)%><BR>
<%if DeliveryDoor <> "" then%>
						<TD nowrap class=line <%=ShowTitle(DeliveryDoor, 12)%>><%=stringCut(DeliveryDoor, 12)%><BR>
						<TD nowrap class=line <%=ShowTitle(Memo, 6)%>><%=stringCut(Memo, 8)%><BR>
<%else%>
						<TD nowrap class=line colspan=2 <%=ShowTitle(Memo, 18)%>><%=stringCut(Memo, 18)%><BR>
<%end if%>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
				
	</TABLE><br>
	<div align=right>
<%if lngCount > 0 and BrokerRef <> "" and OrderFrom <> "" and OrderFrom = OrderTo then%>
		<INPUT style="width:60px;height:25px;" TYPE=button VALUE="���" onclick="DoPrint()">
<%end if%>
	</div>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>