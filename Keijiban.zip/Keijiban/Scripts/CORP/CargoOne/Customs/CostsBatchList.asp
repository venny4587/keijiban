<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	CostsSort = GetLong(request("sort"))
	CostsType = GetLong(request("type"))
	mode = GetLong(request("mode"))
	
	select case mode
	case 0 							'�m��ψꗗ
	
		CostsDate = GetDate(request("CostsDate"))
		if CostsDate = "" then CostsDate = formatDate(date)
	
	case 1, 2						'�x���ʈꗗ
	
		SelData = GetPost(request("sel"))
		BatchNo = GetPost(request("BatchNo"))
		CostsClient = GetLeft(SelData, ".")
		myLevel = CheckUserLevel(UserShop, "")
		if myLevel < 2 and CheckTopLevel() > 0 then myLevel = 2
		if WebUserID = 51 then myLevel = 2	'�����p
		
		if mode = 2 then
				
			msg = ""
			BatchType = ""
			BatchBelong = ""
			CostsNos = GetPost(request("nos"))
			CostsNos = ResetBizNos(CostsNos)
					
			With RecSet
				strSQL = "SELECT JobCode, CostsClient, CostsClientName, CostsPic, CostsDate, CostsPayDay, ConfirmerID FROM TBL_CTM_COSTS"
				strSQL = strSQL & " WHERE Deleted = 0 AND CostsNo IN (" & CostsNos & ")" 
if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then
					BatchBelong = mid(GetString(.Fields("JobCode")), 1, 1)
					BatchType = mid(GetString(.Fields("JobCode")), 2, 1)
					BatchClient = GetString(.Fields("CostsClient"))
					BatchPic = GetString(.Fields("CostsPic"))
					BatchBillDay = GetString(.Fields("CostsDate"))
					BatchPayDay = GetString(.Fields("CostsPayDay"))
				end if
				.Close
			end with
			select case BatchClient
			case gsCorpCode, gsCorpSoko
				BatchBelong = "K"
			end select
				
			if BatchNo <> "" then			
				With RecSet
					strSQL = "SELECT BatchNo FROM TBL_CTM_BATCH WHERE Deleted = 0 AND ConfirmerID = 0"
					strSQL = strSQL & " AND BatchNo = '" & BatchNo & "' AND BatchClient = '" & BatchClient & "'"
					.Open strSql,conn,adOpenStatic,adLockReadOnly
					if .eof then msg = "�Y���o�b�`�ԍ��͕s���ł��B"
					.Close
				end with
			end if
			
			if msg <> "" then  
				ShowMessage msg
			else
				Conn.BeginTrans
				
				if BatchNo = "" then 			
					BatchID = GetNewBatchNo(Conn, gsBatchBill)
					BatchNo = GetBatchNo(BatchID, gsBatchBill)
					
					strSQL = "INSERT INTO TBL_CTM_BATCH (BatchNo, BatchBelong, BatchType, BatchPic, BatchClient, BatchBillDay, BatchPayDay, Remarks, Creater, Updater)"
					strSQL = strSQL & " VALUES ('" & BatchNo & "','" & BatchBelong & "','" & BatchType & "','" & BatchPic & "','" & BatchClient & "','" & BatchBillDay
					strSQL = strSQL & "','" & BatchPayDay & "','�ꊇ����'," & WebUserID & "," & WebUserID & ")"
					Conn.Execute strSQL
				end if
				
				strSql = "UPDATE TBL_CTM_COSTS SET CostsBatch = '" & BatchNo & "' WHERE CostsNo IN (" & CostsNos & ")" 
				Conn.Execute strSql
				
				strSql = "UPDATE TBL_CTM_BIZ SET BIZ_BATCH = '" & BatchNo & "' WHERE BIZ_NO IN (" & CostsNos & ")" 
				Conn.Execute strSql
				
				With RecSet
					strSQL = "SELECT COUNT(CostsNo) AS CNT, SUM(CostsAmount + CostsTax) AS TTL FROM TBL_CTM_COSTS"
					strSQL = strSQL & " WHERE Deleted = 0 AND CostsBatch = '" & BatchNo & "'"
					.Open strSql,conn,adOpenStatic,adLockReadOnly
					if not .eof then
						BatchCount = GetLong(.fields("CNT"))
						BatchAmount = GetLong(.fields("TTL"))
					end if
					.Close
				end with
					
				strSql = "UPDATE TBL_CTM_BATCH SET BatchCount = " & BatchCount
				strSql = strSql & ", BatchAmount = " & BatchAmount
				strSql = strSql & " WHERE BatchNo = '" & BatchNo & "'"
				Conn.Execute strSql
				
				if err.number = 0 then
					Conn.CommitTrans
					msg = "�o�b�`�����͖����������܂����B"
				else
					Conn.RollbackTrans
					msg = "�o�b�`���������L�̃G���[���N����܂����B" & vbcrlf & err.number & ":" & err.description
				end if
			end if
		end if
		
	end select
	
%>
<HTML>
<HEAD>
	<TITLE>�x���`�[�ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>	
		function DoPrint() 
		dim win
			set win = window.open("CostsCover.asp?BatchNo=<%=BatchNo%>","CostsCover","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
<%if mode = 0 then%>
		sub CostsDate_OnBlur()
			frmInput.CostsDate.value = setdate(frmInput.CostsDate.value)
		end sub
	
		function DoSelect()
			window.location.href = "CostsBatchList.asp?CostsDate=" & cstr(frmInput.CostsDate.value)
		end function
		
		function DoSort(myNo)
			window.location.href = "CostsBatchList.asp?sort=" & myNo & "&CostsDate=" & cstr(frmInput.CostsDate.value)
		end function
<%else%>	
		function DoCheck()
			Call CheckAll("nos", frmInput.CheckAll.Checked)
		end function 
	
		function DoConfirm()
			'MyValue = InputBox("1 ���� 3 �܂ł̒l����͂��Ă��������B", "InputBox ���" , "1")
			
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 3) = "nos" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�o�b�`��������x���`�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("�o�b�`�������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.btnProc.disabled = True
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function DoSort(myNo)
			window.location.href = "CostsBatchList.asp?mode=1&sort=" & myNo & "&sel=<%=SelData%>&BatchNo=<%=BatchNo%>&type=<%=CostsType%>"
		end function
<%end if%>

		function ShowDetail(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=2&JobCode=" & myJob & "&CostsNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		sub BatchNo_OnBlur()
			frmInput.BatchNo.value = FitBatchNo(frmInput.BatchNo.value)
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
  <form name=frmInput method="post" action="CostsBatchList.asp">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="sel" value="<%=SelData%>">
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
<%if mode = 0 then%>
	  <TR><td nowrap width=40%>���m��ꗗ&nbsp;
	  	  <td nowrap width=60%>�m���
			<input class=si name="CostsDate" size=10 maxlength=10 value="<%=CostsDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<img style="cursor:hand" src=img/search.jpg alt="���t�I��" onmousedown="DoSelect()">
<%else%>
	  <TR><td nowrap width=30%>���x���ꗗ&nbsp;
	  	  <td nowrap width=40%><%
	  	  	if BatchNo <> "" then 
	  	  		response.write "�ޯ��� " & BatchNo
		  	  	if CheckBatchLocked(BatchNo) = false then
		  	  		response.write "�@<font class=pt9t>���m��</font>"
		  	  	else
%>
		  <td nowrap width=30%><img style="cursor:hand" src=img/cover.jpg alt="�\�����" onmousedown="DoPrint()">
<%
				end if
	  	  	else
	  	  		response.write GetFullName(CostsClient)
	  	  	end if%>
<%end if%>
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT JobCode, CostsType, ClientRef, CostsClientName, CostsNo, CostsBillNo, CostsBatch, CostsAmount, CostsTax, CostsDate, FinisherID"
		strSql = strSql & " FROM TBL_CTM_COSTS AS T INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0"		'���폜�@�m��ρ@����������
		if mode = 0 then
			strSql = strSql & " AND CONVERT(VARCHAR(10), ConfirmDate, 111) = '" & CostsDate & "'"
		else
			strSql = strSql & session("CostsBatch_Sel")
			if BatchNo <> "" then
				strSql = strSql & " AND CostsBatch = '" & BatchNo & "'"
			else
				strSql = strSql & " AND CostsBatch = '' AND CostsClient = '" & CostsClient & "'"
				strSql = strSql & " AND CostsType = " & CostsType
			end if
		end if
		select case CostsSort
		case 0:		strSql = strSql & " ORDER BY CostsType, CostsNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, CostsNo"
		case 2:		strSql = strSql & " ORDER BY CostsDate, CostsNo"
		case 3:		strSql = strSql & " ORDER BY (CostsAmount+CostsTax), CostsNo"
		case 4:		strSql = strSql & " ORDER BY CostsBillNo, CostsNo"
		end select
'if WebUserID = 1 then response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		<colgroup span=2 align=center>
<%if mode <> 0 then%>
		<colgroup align=right>
<%end if%>
		<colgroup span=2 align=center>
		<colgroup align=right>
		<colgroup span=2 align=left>
<%if mode <> 0 then%>
		<colgroup align=right>
<%end if%>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>��
<%if mode <> 0 then%>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">���臂
<%end if%>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">������
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x�����z
<%if mode = 0 then%>
		<TD class=line nowrap align=left>�x����
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�`�[�ԍ�
		<TD class=line nowrap>�x��
<%else%>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�`�[�ԍ�
	<%if BatchNo = "" and myLevel > 1 then %>
		<TD class=line nowrap><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S
		<TD class=line nowrap>�Ŕ����z
	<%end if%>
<%end if%>
<%
			cnt = 0
			ttlCount = 0
			ttlAmount = 0:	ttlTax = 0:	ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode"))
				CostsNo = GetString(.Fields("CostsNo"))
				CostsBatch = GetString(.Fields("CostsBatch"))
				CostsBillNo = GetString(.Fields("CostsBillNo"))
				
				ClientRef = GetString(.Fields("ClientRef"))
				ClientName = GetString(.Fields("CostsClientName"))
				if GetLong(.Fields("FinisherID")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=gray>��</font>"
				end if
				myAmount = GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax"))
%>
				<TR height=20>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=JobCode%>','<%=CostsNo%>')"><%=cnt%>
					<TD class=line><%=replace(ShowCostsType(.Fields("CostsType")),"��","")%><BR>
<%if mode <> 0 then%>
					<TD class=line nowrap <%=ShowTitle(CostsBillNo, 10)%>><%=StringCutRev(CostsBillNo, 10)%><BR>
<%end if%>
					<TD class=line nowrap><%=ShowJobCode(JobCode)%><BR>
					<TD class=line style="color:blue"><%=Str2MD(.Fields("CostsDate"))%><BR>
					<TD class=line nowrap><%=formatnumber(myAmount, 0, true)%><BR>
<%if mode = 0 then%>
					<TD class=line nowrap style="cursor:help" title="<%=ClientName%>"><%=StringCut(ClientRef,7)%><BR>
					<TD class=line><%=ShowVoucherNo(CostsNo)%><BR>
					<TD class=line><%=status%><BR>
<%else%>
					<TD class=line><%=ShowVoucherNo(CostsNo)%><BR>
	<%if BatchNo = "" and myLevel > 1 then %>
					<TD class=line style="color:gray"><%
						if CostsBatch <> "" or GetLong(.Fields("FinisherID")) <> 0 then
							response.write "��"
						else
							ttlCount = ttlCount + 1
							response.write "<input type=checkbox name=nos value=" & ResetBizNo(CostsNo) & ">"
						end if	%>
					<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("CostsAmount")), 0, true)%><BR>
	<%end if
end if
				if GetLong(.Fields("CostsTax")) = 0 then 
					ttlTaxFree = ttlTaxFree + GetLong(.Fields("CostsAmount")) 
				else
					ttlTax = ttlTax + GetLong(.Fields("CostsTax"))
					ttlAmount = ttlAmount + GetLong(.Fields("CostsAmount"))
				end if
				.movenext
			loop
			if cnt > 0 then
				myCol = 3
				if mode <> 0 then myCol = myCol + 1
%>
<%if ttlAmount <> 0 then%>
				<TR height=20>
					<TD colspan=<%=myCol%> align=right class=pt9>�Ŕ����z
					<TD class=line align=right colspan=2><%=formatnumber(ttlAmount + ttlTaxFree, 0, true)%>
				<TR height=20>
					<TD colspan=<%=myCol%> align=right class=pt9>�� �� ��
					<TD class=line align=right colspan=2><%=formatnumber(ttlTax, 0, true)%>
<%end if%>
				<TR height=20 valign=bottom>
					<TD colspan=<%=myCol%> align=right class=pt9>���v���z
					<TD class=line align=right colspan=2><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%if mode <> 0 then%>
					<TD colspan=<%=myCol%> align=center nowrap><%if ttlCount > 0 and myLevel > 1 then%>
						�ޯ���<INPUT class=si maxlength=6 size=6 name="BatchNo" VALUE="" onkeydown="ResetEnter()">
						<INPUT style="width:60px;height:25px;" TYPE=button name=btnProc VALUE="���s" onclick="DoConfirm()">
					<%end if%>
<%end if
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y���x���`�[�͌�����܂���ł����B</font>"
		end if
	end with
%>  
  </form>
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
