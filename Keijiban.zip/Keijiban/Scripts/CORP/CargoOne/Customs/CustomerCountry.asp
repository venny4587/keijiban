<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	
	OpenSql Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	JobCode = GetPost(request("JobCode"))
	with Recset
		strSql = "SELECT CN_LINE, JobCountry, POLN, POL, PODN, POD FROM TBL_CTM_JOB INNER JOIN"
		strSql = strSql & " MST_COUNTRY ON TBL_CTM_JOB.JobCountry = MST_COUNTRY.CN_CD"
		strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			JobArea = GetString(.fields("CN_LINE"))
			JobCountry = GetString(.fields("JobCountry"))
			POLN = GetString(.fields("POLN"))
			POL = GetString(.fields("POL"))
			PODN = GetString(.fields("PODN"))
			POD = GetString(.fields("POD"))
		end if
		.Close
	end with
	
	if GetPost(request("JobArea")) <> "" then 
		JobArea = GetPost(request("JobArea"))
		if mid(JobCode, 2, 1) = gsImport then
			POLN = ""
			POL = ""
		else
			PODN = ""
			POD = ""
		end if
	end if
	
	mode = GetLong(request("mode"))
	if mode > 1 then
		JobCountry = GetPost(request("JobCountry"))
		POLN = GetPost(request("POLN"))
		POL = GetPortName(request("POL"))
		PODN = GetPost(request("PODN"))
		POD = GetPortName(request("POD"))
		
		if JobCountry <> "" and POL <> "" and POD <> "" then
			
			strSql = "UPDATE TBL_CTM_JOB SET Updated = GETDATE()"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", JobCountry = '" & JobCountry & "'"
			strSql = strSql & ", POLN = '" & POLN & "'"
			strSql = strSql & ", POL = '" & POL & "'"
			strSql = strSql & ", PODN = '" & PODN & "'"
			strSql = strSql & ", POD = '" & POD & "'"
			strSql = strSql & "WHERE JobCode = '" & JobCode & "'"
			Conn.Execute strSql
%>
<html><script language=javascript>
window.opener.location.href = "CustomsEdit.asp?JobCode=<%=JobCode%>";
window.close();
</script></html>
<%
		else
			ShowMessage "�V�X�e���G���[���N����܂����B�Ǘ��҂ɂ��A�����������B"
		end if
	else
%>
<html>
<HEAD>
	<TITLE>�C�O�G���A�ݒ�ύX</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
	<!--		
		sub JobArea_OnChange()
			frmInput.mode.value = 1
			frmInput.submit()
		end sub
		
		sub JobCountry_OnChange()			
			ClearPort()
		end sub
		
		sub ClearPort()
<%if mid(JobCode, 2, 1) = gsImport then%>
			frmInput.POLCD.value = ""
			frmInput.POLN.value = ""
			frmInput.POL.value = ""
<%else%>
			frmInput.PODCD.value = ""
			frmInput.PODN.value = ""
			frmInput.POD.value = ""
<%end if%>
		end sub	
		
		sub POLCD_OnBlur()			
			frmInput.POLCD.value = ucase(frmInput.POLCD.value)
			frmInput.POLN.value = ""	
			frmInput.POL.value = ""
		end sub
		
		sub POL_OnBlur()	
			if frmInput.POLCD.value <> "ZZZ" then
				frmInput.POLCD.value = ""	
				frmInput.POLN.value = ""	
				frmInput.POL.value = ucase(frmInput.POL.value)
			end if
		end sub	
		
		sub PODCD_OnBlur()
			frmInput.PODCD.value = ucase(frmInput.PODCD.value)
			frmInput.PODN.value = ""	
			frmInput.POD.value = ""
		end sub
		
		sub POD_OnBlur()
			if frmInput.PODCD.value <> "ZZZ" then
				frmInput.PODCD.value = ""
				frmInput.PODN.value = ""	
				frmInput.POD.value = ucase(frmInput.POD.value)
			end if
		end sub
				
		sub PortSearch(mode)
			dim win, param
<%if mid(JobCode, 2, 1) = gsImport then%>
			POL_CN = frmInput.JobCountry.options(frmInput.JobCountry.selectedindex).value
			POD_CN = "JP"
<%else%>
			POL_CN = "JP"
			POD_CN = frmInput.JobCountry.options(frmInput.JobCountry.selectedindex).value
<%end if%>
			if mode = 0 then
				param = "?mode=0&cn=" & POL_CN & "&cd=" & frmInput.POLCD.value & "&nm=" & frmInput.POL.value
			else
				param = "?mode=1&cn=" & POD_CN & "&cd=" & frmInput.PODCD.value & "&nm=" & frmInput.POD.value
			end if
			set win = window.open("../common/PortSearch.asp" & param,"PortSearch","resizable=0,StatusBar=0,scrollbars=1,width=360,height=300")
		end sub
		
		sub DataSave()
			if checkText("POLCD","�o���`�R�[�h",1) = false then exit sub
			if checkText("POL","�o���`",1) = false then exit sub
			if checkText("PODCD","�ړI�`�R�[�h",1) = false then exit sub
			if checkText("POD","�ړI�`",1) = false then exit sub
			if msgbox("����ł�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then 
				frmInput.mode.value = 2
				frmInput.submit()
			end if
		end sub
	-->
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CustomerCountry.asp" method="post">
  	<input type=hidden name="mode" value="1">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>�����E�`���ύX&nbsp;
	 	  <td width=50% align=right><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()"><br>
	</table>
	<hr width=96% size=1 color=blue>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=30>
		<TD width=50>�Ɩ�
		<TD class=pt9g><%
			select case mid(JobCode, 2, 1)
			case gsImport:	response.write "�A��"
			case gsExport:	response.write "�A�o"
			case gsOther:	response.write "�ق�"
			end select%>
	  <TR height=30>
		<TD>�G���A
		<TD><select style="width:100" name=JobArea onkeydown="ResetEnter()"><%=ShowAreaList(JobArea)%></select>
	  <TR height=30>
		<TD>���Ɩ�
		<TD><select class=pt9n name=JobCountry onkeydown="ResetEnter()"><%=ShowCountryList(JobArea, JobCountry)%></select>	
	  <TR height=30>
		<TD>�o���`<input type=hidden name="POLN" value="<%=POLN%>">
		<TD><input class=si name="POLCD" size=8 maxlength=10 value="<%=POLN%>" onkeydown="ResetEnter()">
			<a href="javascript:PortSearch(0)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="POL" value="<%=POL%>" Maxlength=50 size=25 onkeydown="ResetEnter()">
	  <TR height=30>
		<TD>�ړI�`<input type=hidden name="PODN" value="<%=PODN%>">
		<TD><input class=si name="PODCD" size=8 maxlength=10 value="<%=PODN%>" onkeydown="ResetEnter()">
			<a href="javascript:PortSearch(1)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="POD" value="<%=POD%>" Maxlength=50 size=25 onkeydown="ResetEnter()">
	  <TR height=50>
		<TD colspan=2 align=center>
			<input type=button style="width:90;height:30" name=btnCreate value="�X�V" onclick="DataSave()">�@�@
			<input type=button style="width:90;height:30" name=btnClose value="����" onclick="window.close()">
	</table>
  </FORM>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function ShowAreaList(myArea)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT DISTINCT CN_LINE FROM MST_COUNTRY WHERE CN_DELETED = 0 AND ISNULL(CN_LINE, '') <> ''" 
	mySql = mySql & " ORDER BY CN_LINE"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CN_LINE")
		if myRec.fields("CN_LINE") = myArea then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("CN_LINE")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowAreaList = buf	
end function

function ShowCountryList(myArea, myCode)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT CN_CD, CN_NAME, CN_ENAME FROM MST_COUNTRY WHERE CN_DELETED = 0 AND CN_CD <> 'JP' AND CN_LINE = '" & myArea & "'"
	mySql = mySql & " ORDER BY CN_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CN_CD")
		if myCode = myRec.fields("CN_CD") then buf = buf & " selected"
		buf = buf & ">" & replace(left(myRec.fields("CN_ENAME") & space(20), 20), " ", "&nbsp;") & myRec.fields("CN_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowCountryList = buf	
end function

function ShowPortList(myCn, myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT PORT_CD, PORT_ENAME FROM MST_PORT WHERE PORT_DELETED = 0 AND PORT_CN = '" & myCn & "'"
	mySql = mySql & " ORDER BY PORT_ENAME"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("PORT_ENAME")
		if myDft = myRec.fields("PORT_ENAME") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("PORT_ENAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowPortList = buf	
end function
%>

