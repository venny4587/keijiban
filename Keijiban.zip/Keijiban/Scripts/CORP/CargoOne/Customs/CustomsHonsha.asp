<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(15)
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myCode = GetPost(request("JobCode"))
	if myCode <> "" then
		Conn.Execute "UPDATE TBL_CTM_JOB SET JobOperator = " & WebUserID & " WHERE JobCode = '" & myCode & "'"
	end if
	
	myLevel = CheckUserLevel(UserShop, "")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowDetail(cd)
		dim win
			if cd = "" then exit function
			set win = window.open("MainFrame.asp?JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
			
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
	</SCRIPT>
</HEAD>

<BODY topmargin=5 <%=gsBodyControl%> <%if myCode <> "" then response.write "onload=""ShowDetail('" & myCode & "')"""%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CustomsHonsha.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE="1">
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<INPUT TYPE="HIDDEN" NAME="JobCode" VALUE="">
		<center><b><%=formatDateTime(now)%> ����</b></center>
	<!----------��������--------->
<%
		strSQL = "SELECT TMP.*, M.FamilyName FROM ("
		strSQL = strSQL & "SELECT JobCode, ClientRef, POL, POD, Vessel, Voy, Quantity, Package, JobSalesman, Creater, Created, FinisherID"
		strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD FROM TBL_CTM_JOB AS T "
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.JobClient = C.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0 AND CustomBroker = '" & gsCorpCode & "' AND SUBSTRING(JobCode,1,1) <> '" & gsCorpInit & "'"
		if UserShop = gsCorpInit then 
			if myLevel < 3 then strSQL = strSQL & " AND Creater = " & WebUserID
		else
			if myLevel < 4 then strSQL = strSQL & " AND JobSalesman = " & WebUserID
		end if
		strSQL = strSQL & ") AS TMP INNER JOIN WebMaster.dbo.MstWebUser AS M ON TMP.Creater = M.WebUserID WHERE M.ShopID = 2"
		strSQL = strSQL & " ORDER BY Created DESC"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=3 align=center>
			<colgroup span=3 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup align=left>
			<colgroup span=4 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=4% nowrap>�敪
			<TD width=8% nowrap>�䒠�ԍ�
			<TD width=8% nowrap>�����׎�
			<TD width=20% nowrap>�֖�
			<TD width=16% nowrap>�q�H
			<TD width=8% nowrap>���o�`��
			<TD width=6% nowrap>��
			<TD width=6% nowrap>�׎p
<%if UserShop = gsCorpInit OR myLevel > 3 then %>
			<TD width=4% nowrap>�c��
<%end if%>
			<TD width=10% nowrap>���s����
			<TD width=4% nowrap>���s��
			<TD width=2% nowrap><br>
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						JobCode = GetString(.Fields("JobCode"))
						ClientRef = GetString(.Fields("ClientRef"))
						VesselVoy = GetString(.Fields("Vessel"))
						if GetString(.Fields("Voy")) <> "" then VesselVoy = VesselVoy & " V." & GetString(.Fields("Voy"))
						POLPOD = GetString(.Fields("POL")) & " �� " & GetString(.Fields("POD"))
						if GetLong(.Fields("FinisherID")) <> 0 then
							myColor = "gray"
						elseif CheckJobType(.Fields("JobCode"))=gsExport then
							myColor = "black"
						else
							myColor = "maroon"
						end if
%>
					<TR style="color:<%=myColor%>">
						<TD class=line><%=lngCount%><BR> 
						<TD nowrap class=line><%=GetJobDivision(CheckJobType(.Fields("JobCode")))%> 
						<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%><BR> 
						<TD nowrap class=line <%=ShowTitle(ClientRef, 8)%>><%=stringCut(ClientRef, 8)%><BR> 
						<TD nowrap class=line <%=ShowTitle(VesselVoy, 20)%>><%=stringCut(VesselVoy, 20)%><BR> 
						<TD nowrap class=line <%=ShowTitle(POLPOD, 18)%>><%=stringCut(POLPOD, 18)%><BR> 
						<TD nowrap class=line style="color:green"><%=Str2YMD(.Fields("ETAETD"))%><BR> 
						<TD nowrap class=line><%=GetString(.Fields("Quantity"))%><BR> 
						<TD nowrap class=line><%=GetString(.Fields("Package"))%><BR> 
<%if UserShop = gsCorpInit OR myLevel > 3 then %>
						<TD nowrap class=line><%=GetEmployName(.Fields("JobSalesman"), "F")%><BR> 
<%end if%>
						<TD nowrap class=line><%=ShowDateTimeShort(.Fields("Created"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("FamilyName"))%><BR> 
						<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=JobCode%>')">
<%
						.MoveNext
					End If
				Loop
%>
				
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>