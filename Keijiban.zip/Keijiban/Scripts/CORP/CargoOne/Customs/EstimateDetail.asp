<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim EstimateID
dim EstimateClient
dim EstimateCode
dim ExpenseCost
dim EstimateType
dim ExpenseUnit
dim ExpensePrice
dim ExpenseTaxName
dim Remarks

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	EstimateClient = GetPost(Request("cd"))
	EstimateID = GetLong(Request("id"))
	If EstimateID = 0 Then
		blnEdit = False
		myTitle = "��ڃf�[�^�ǉ�"
		mySubmit = "�ǉ�"
		
		ExpenseCost = 0
		EstimateType = gsImport		'�q�ɂ�	gsExport
		ExpensePrice = 0
		ExpenseUnit = "��"
		ExpenseTaxName = ""
		Remarks = ""
	Else
		blnEdit = True
		myTitle = "��ڃf�[�^�ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM TBL_CTM_ESTIMATE WHERE EstimateID = " & EstimateID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			ExpenseCost = GetLong(Recset.Fields("ExpenseCost"))
			EstimateType = GetLong(Recset.Fields("EstimateType"))
			ExpensePrice = GetLong(Recset.Fields("ExpensePrice"))
			ExpenseUnit = GetString(Recset.Fields("ExpenseUnit"))
			ExpenseTaxName = GetLong(Recset.Fields("ExpenseTaxName"))
			Remarks = GetString(Recset.Fields("Remarks"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY class=pt9n <%=gsBodyControl%>>
		<SCRIPT LANGUAGE="VBScript">			
			function AddNew()
				window.location.href = "EstimateDetail.asp?cd=<%=EstimateClient%>&p=<%=myPage%>&s=<%=mySort%>"
			End function
					
			function ConfirmDelete(myID)
				if msgbox("�Y����ڂ��폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "EstimateDetail0.asp?cd=<%=EstimateClient%>&id=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkNum("ExpensePrice","��ڒP��", 1) = false then exit sub
				if checkText("Remarks","��ڔ��l", 0) = false then exit sub
				if checkLen("Remarks","��ڔ��l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then frmInput.submit() 
			End Sub
			
			sub ExpensePrice_OnChange()
				frmInput.ExpensePrice.value = formatnumber(GetLong(frmInput.ExpensePrice.value), 0, true)
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "EstimateDetail.asp?cd=<%=EstimateClient%>&s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="EstimateDetail1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="EstimateID" value="<%=EstimateID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD colspan=2 class=gline>����ڃ��X�g
								<TD colspan=2 class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td colspan=3><img src=img/spacer.gif height=3>
							<TR>
								<TD class=pt9g align=center nowrap>��Ж���
								<TD class=pt9g colspan=3><INPUT type=hidden NAME="cd" VALUE="<%=EstimateClient%>"><%=GetFullName(EstimateClient)%>
							<TR><td><img src=img/spacer.gif height=3>
							<TR height=30>
								<TD align=center nowrap width=70>��p����
								<TD colspan=3><select name="ExpenseCost" onkeydown="ResetEnter()"><%=ShowExpenseList(ExpenseCost)%></select>
							<TR height=30>
								<TD align=center nowrap>�P��
								<TD><select name="ExpenseUnit" onkeydown="ResetEnter()"><%=ShowCategoryList("ChargeUnit", ExpenseUnit, 1)%></select>
								<TD align=center nowrap>�敪
		 						<TD><select name="EstimateType" onkeydown="ResetEnter()">
									<option value="<%=gsImport%>" <%if EstimateType = gsImport then response.write " selected"%>>�A��
									<option value="<%=gsExport%>" <%if EstimateType = gsExport then response.write " selected"%>>�A�o
									</select>
							<TR height=30>
								<TD align=center nowrap>�ŋ敪
								<TD><select name="ExpenseTaxName" onkeydown="ResetEnter()"><%=ShowCategoryList("TaxCode", ExpenseTaxName, 1)%></select>
								<TD align=center nowrap>�P��
								<TD><INPUT class=sn NAME="ExpensePrice" MAXLENGTH=9 SIZE=10 VALUE="<%=formatnumber(ExpensePrice, 0, true)%>" OnKeyDown="ResetEnter()">
							<TR>
								<TD align=center nowrap class=pt9>��ڔ��l
								<TD colspan=3><textarea NAME="Remarks" style="width:250px;height:50px;"><%=Remarks%></textarea>
							
						</TABLE>
						<BR>
<%	if EstimateClient <> "" then %>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
<%	end if %>
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL & "SELECT EstimateID,"
					strSQL = strSQL & "       COST_NAME,"
					strSQL = strSQL & "       EstimateType,"
					strSQL = strSQL & "       ExpensePrice,"
					strSQL = strSQL & "       ExpenseUnit,"
					strSQL = strSQL & "       ExpenseTaxName,"
					strSQL = strSQL & "       Remarks"
					strSQL = strSQL & "  FROM TBL_CTM_ESTIMATE INNER JOIN MST_COST"
					strSQL = strSQL & "    ON TBL_CTM_ESTIMATE.ExpenseCost = MST_COST.COST_ID"
					strSQL = strSQL & " WHERE EstimateClient = '" & EstimateClient & "'"
					Select Case mySort
					Case "jp"
						strSQL = strSQL & " ORDER BY EstimateType DESC, ExpenseTaxName;"
					Case "en"
						strSQL = strSQL & " ORDER BY EstimateType DESC, ExpensePrice;"
					Case Else
						strSQL = strSQL & " ORDER BY EstimateType DESC, ExpenseCost;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										
									
								</table>
							
						
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.
							<TD class=line nowrap width=10%>�敪
							<TD class=line nowrap width=20%><a class=bar href="EstimateDetail.asp?s=cd&cd=<%=EstimateClient%>">��p����</a>
							<TD class=line nowrap width=10%>�P��
							<TD class=line nowrap width=10%><a class=bar href="EstimateDetail.asp?s=jp&cd=<%=EstimateClient%>">�ŋ敪</a>
							<TD class=line nowrap width=10%><a class=bar href="EstimateDetail.asp?s=en&cd=<%=EstimateClient%>">�P��</a>
							<TD class=line nowrap width=20%>���l
							<TD class=line nowrap width=8%>�ҏW
							<TD class=line nowrap width=8%>�폜
						
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("COST_NAME"))
										myPrice = GetLong(.Fields("ExpensePrice"))
										myUnit = GetString(.Fields("ExpenseUnit"))
										myRemarks = GetString(.Fields("Remarks"))
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR>
							<TD class=line nowrap><%if GetString(.Fields("EstimateType"))=gsImport then%>�A��<%else%>�A�o<%end if%><BR>
							<TD class=line nowrap align=left <%=ShowTitle(myName,15)%>><%=stringCut(myName,15)%><BR>
							<TD class=line nowrap <%=ShowTitle(myUnit,6)%>><%=stringCut(myUnit,6)%><BR>
							<TD class=line nowrap><%=GetString(.Fields("ExpenseTaxName"))%><BR>
							<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("ExpensePrice")), 0 ,true)%><BR>
							<TD class=line nowrap align=left <%=ShowTitle(myRemarks,20)%>><%=stringCut(myRemarks,20)%><BR>
						<%
							If EstimateID = GetLong(.Fields("EstimateID")) Then
								Response.Write "<TD class=line nowrap>..."
							Else
								Response.Write "<TD class=line nowrap><A HREF=""EstimateDetail.asp?p=" & myPage & "&s=" & mySort & "&cd=" & EstimateClient & "&id=" & .Fields("EstimateID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("EstimateID")%>')">
						
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center class=pt9n>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				
			
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>

<%
function ShowExpenseList(myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT COST_ID, COST_CD, COST_NAME FROM MST_COST"
	mySql = mySql & " WHERE COST_DELETED = 0"
	mySql = mySql & " ORDER BY COST_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("COST_ID")
		if myDft = myRec.fields("COST_ID") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("COST_CD") & " " & myRec.fields("COST_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowExpenseList = buf	
end function
%>