<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�x���`�[���ה�p����
'----------------------------------------------

	CostsNo = GetPost(request("CostsNo"))
	JobCode = GetPost(request("JobCode"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")	
	
	with Recset
		strSql = "SELECT JobCode FROM TBL_CTM_COSTS WHERE CostsNo = '" & CostsNo & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then myJobCode = GetString(.fields("JobCode"))
		.close
		
		strSql = "SELECT LockerID FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if .eof then 
			JobCode = ""
		else
			LockerID = GetLong(.fields("LockerID"))
		end if
		.close
	end with
	
	if JobCode = "" then
		ShowMessage "�ؑ֐�䒠�ԍ��͌�����܂���ł����B"
	elseif LockerID <> 0 then
		ShowMessage "�ؑ֐�䒠�ԍ��u" & JobCode & "�v�͊��ɑe�����b�N����܂����B"
	else
		Conn.BeginTrans
	
		strSql = "UPDATE TBL_CTM_EXPENSE SET JobCode = '" & JobCode & "'"
		strSql = strSql & " WHERE Deleted = 0 AND ExpensePay = '" & CostsNo & "'"
		Conn.Execute strSql
		
		strSql = "UPDATE TBL_CTM_COSTS SET JobCode = '" & JobCode & "'"
		strSql = strSql & " WHERE Deleted = 0 AND CostsNo = '" & CostsNo & "'"
		Conn.Execute strSql
		
		strSql = "UPDATE TBL_CTM_BIZ SET BIZ_JOBCODE = '" & JobCode & "'"
		strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_NO = '" & CostsNo & "'"
		Conn.Execute strSql
		
		if err.number = 0 then
			Conn.CommitTrans
%>
<html>
<script language=javascript>
	window.location.href = "../common/blank.htm";
	window.parent.parent.location.href = "MainFrame.asp?type=2&JobCode=<%=myJobCode%>"
</script>
</html>
<%	
		else
			Conn.RollbackTrans
			ShowMessage "�o�b�`���������L�̃G���[���N����܂����B" & vbcrlf & err.number & ":" & err.description
		end if
	end if
	set Recset = nothing
	CloseDB Conn
%>