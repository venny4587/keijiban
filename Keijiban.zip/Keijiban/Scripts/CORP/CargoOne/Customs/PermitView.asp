<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		'JobCode = Session("ShopCode") & Num2Code(year(date)-2000) & Num2Code(Month(date)) & GetInitJobType()
		if WebUserID <> 18 then
			JobOperator = WebUserID
			JobSalesman = WebUserID
		end if
	else
		JobType = GetPost(request("JobType"))
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		BrokerRef = GetPost(request("BrokerRef"))
		BLNO = GetPost(request("BLNO"))
		Port = GetPost(request("Port"))
		PermitNo = GetPost(request("PermitNo"))
		PermitFrom = GetPost(request("PermitFrom"))
		PermitTo = GetPost(request("PermitTo"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		QtyFrom = GetPost(request("QtyFrom"))
		QtyTo = GetPost(request("QtyTo"))
		Vessel = GetPost(request("Vessel"))
		Process = GetLong(request("Process"))
		JobOperator = GetLong(request("JobOperator"))
		
		if QtyFrom <> "" then QtyFrom = GetDouble(QtyFrom)
		if QtyTo <> "" then QtyTo = GetDouble(QtyTo)
	end if

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		function DoSort(mySort)
			frmInput.sort.value = mySort
			frmInput.submit()
		end function
		
		sub PermitFrom_OnBlur()
			frmInput.PermitFrom.value = setdate(frmInput.PermitFrom.value)
		end sub		
		sub PermitTo_OnBlur()
			frmInput.PermitTo.value = setdate(frmInput.PermitTo.value)
		end sub		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub QtyFrom_OnBlur()
			if frmInput.QtyFrom.value = "" then exit sub
			frmInput.QtyFrom.value = GetDouble(frmInput.QtyFrom.value)
		end sub
		sub QtyTo_OnBlur()
			if frmInput.QtyTo.value = "" then exit sub
			frmInput.QtyTo.value = GetDouble(frmInput.QtyTo.value)
		end sub	
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.JobCode)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="PermitView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�ʊ֋Ǝ�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="BrokerRef" value="<%=BrokerRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				������<input class=sj name="PermitNo" value="<%=PermitNo%>" maxlength=30 size=12 onkeydown="ResetEnter()">
				����<input class=si name="PermitFrom" value="<%=PermitFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="PermitTo" value="<%=PermitTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�Ɩ��S��&nbsp;<SELECT name="JobOperator" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartCustoms, JobOperator)%></select>
			<TR><TD nowrap>
				�Ɩ��敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��
						<option value="<%=gsImport%>" <%if JobType=gsImport then response.write "selected"%>>�A��
						<option value="<%=gsExport%>" <%if JobType=gsExport then response.write "selected"%>>�A�o</select>
				���o�`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�֖�<input class=si name="Vessel" value="<%=Vessel%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				B/L No.<input class=si name="BLNO" value="<%=BLNO%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				�`<input class=si name="Port" value="<%=Port%>" maxlength=16 size=10 onkeydown="ResetEnter()">
				��<input class=sn name="QtyFrom" value="<%=QtyFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="QtyTo" value="<%=QtyTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'" 
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)		
		if BrokerRef <> "" then	strSel = strSel & " AND BrokerRef = '" & FitSel(BrokerRef) & "'"
		if BLNO <> "" then strSel = strSel & " AND BLNO LIKE '%" & FitSel(BLNO) & "%'"
		if PermitFrom <> "" then strSel = strSel & " AND PermitDate >= '" & Date2Str(PermitFrom) & "'"
		if PermitTo <> "" then strSel = strSel & " AND PermitDate <= '" & Date2Str(PermitTo) & "'"
		if PermitNo <> "" then strSel = strSel & " AND PermitNo LIKE '%" & FitSel(PermitNo) & "%'"
		if Port <> "" then strSel = strSel & " AND (POL LIKE '%" & FitSel(Port) & "%' OR POD LIKE '%" & FitSel(Port) & "%')"
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if Vessel <> "" then strSel = strSel & " AND VesselVoy LIKE '%" & FitSel(Vessel) & "%'"	
		if QtyFrom <> "" then strSel = strSel & " AND Quantity >= " & QtyFrom
		if QtyTo <> "" then strSel = strSel & " AND Quantity <= " & QtyTo
		if JobOperator <> 0 then strSel = strSel & " AND JobOperator = " & JobOperator
		
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT JobCode, C.CTM_CD, ClientRef, BrokerRef, JobOperator, PermitNo, PermitDate, MBL+' '+HBL AS BLNO, Vessel+' '+Voy AS VesselVoy"
		strSQL = strSQL & ", POL, POD, Quantity, Package, CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD FROM TBL_CTM_JOB AS T "
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON T.CustomBroker = B.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0) AS TMP"
		if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel, 5)
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY JobCode"
		case 1:		strSQL = strSQL & " ORDER BY ETAETD"
		case 2:		strSQL = strSQL & " ORDER BY Quantity"
		case 3:		strSQL = strSQL & " ORDER BY PermitDate"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=4 align=left>
			<colgroup span=3 align=center>
			<colgroup span=2 align=left>
			<colgroup align=right>
			<colgroup span=2 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=2% nowrap>��</TD>
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�䒠�ԍ�</TD>
			<TD width=8% nowrap>�����׎�</TD>
			<TD width=12% nowrap>�֖�</TD>
			<TD width=8% nowrap>�o���`</TD>
			<TD width=8% nowrap>�ړI�`</TD>
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">���o�`��</TD>
			<TD width=10% nowrap>B/L ��</TD>
			<TD width=8% nowrap>�ʊ֋Ǝ�</TD>
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">��</TD>
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">����</TD>
			<TD width=10% nowrap>������</TD>
			<TD width=4% nowrap>�Ɩ�</TD>
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else						
						ClientRef = GetString(.Fields("ClientRef"))
						BrokerRef = GetString(.Fields("BrokerRef"))
						VesselVoy = GetString(.Fields("VesselVoy"))
						BLNO = GetString(.Fields("BLNO"))
						POL = GetString(.Fields("POL"))
						POD = GetString(.Fields("POD"))
						PermitNo = GetString(.Fields("PermitNo"))
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("JobCode")%>');">
						<TD nowrap class=line><%=lngCount%><BR></TD>
						<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%><BR></TD>
						<TD nowrap class=line <%=ShowTitle(ClientRef, 8)%>><%=stringCut(ClientRef, 8)%><BR></TD>
						<TD nowrap class=line <%=ShowTitle(VesselVoy, 15)%>><%=stringCut(VesselVoy, 15)%><BR></TD>
						<TD nowrap class=line <%=ShowTitle(POL, 8)%>><%=stringCut(POL, 8)%><BR></TD>
						<TD nowrap class=line <%=ShowTitle(POD, 8)%>><%=stringCut(POD, 8)%><BR></TD>
						<TD nowrap class=line><%=Str2YMD(.Fields("ETAETD"))%><BR></TD>
						<TD nowrap class=line align=left <%=ShowTitle(BLNO, 12)%>><%=stringCut(BLNO, 12)%><BR></TD>
						<TD nowrap class=line <%=ShowTitle(BrokerRef, 8)%>><%=stringCut(BrokerRef, 8)%><BR></TD>
						<TD nowrap class=line><%=GetDouble(.Fields("Quantity"))%><BR></TD>
						<TD nowrap class=line><%=Str2YMD(.Fields("PermitDate"))%><BR></TD>
						<TD nowrap class=line <%=ShowTitle(PermitNo, 11)%>><%=stringCut(PermitNo, 11)%><BR></TD>
						<TD nowrap class=line><%=GetEmployName(.Fields("JobOperator"), "F")%><BR></TD>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
				
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>