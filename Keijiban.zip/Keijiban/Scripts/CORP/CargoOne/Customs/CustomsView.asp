<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Process = 1
		'JobCode = "DC" & Num2Code(year(date)-2000) & Num2Code(Month(date)) & GetInitJobType()
		'JobOperator = WebUserID
		'JobSalesman = WebUserID
	else
		JobType = GetPost(request("JobType"))
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		BrokerRef = GetPost(request("BrokerRef"))
		ReferNo = GetPost(request("ReferNo"))
		Container = GetPost(request("Container"))
		Port = GetPost(request("Port"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		DeliveryFrom = GetPost(request("DeliveryFrom"))
		DeliveryTo = GetPost(request("DeliveryTo"))
		QtyFrom = GetPost(request("QtyFrom"))
		QtyTo = GetPost(request("QtyTo"))
		Vessel = GetPost(request("Vessel"))
		Process = GetLong(request("Process"))
		JobOperator = GetLong(request("JobOperator"))
		JobSalesman = GetLong(request("JobSalesman"))
		Memo = GetPost(request("Memo"))
		
		if QtyFrom <> "" then QtyFrom = GetDouble(QtyFrom)
		if QtyTo <> "" then QtyTo = GetDouble(QtyTo)
	end if

	myLevel = CheckUserLevel(UserShop, "")

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub DeliveryFrom_OnBlur()
			frmInput.DeliveryFrom.value = setdate(frmInput.DeliveryFrom.value)
		end sub		
		sub DeliveryTo_OnBlur()
			frmInput.DeliveryTo.value = setdate(frmInput.DeliveryTo.value)
		end sub	
		sub QtyFrom_OnBlur()
			if frmInput.QtyFrom.value = "" then exit sub
			frmInput.QtyFrom.value = GetDouble(frmInput.QtyFrom.value)
		end sub
		sub QtyTo_OnBlur()
			if frmInput.QtyTo.value = "" then exit sub
			frmInput.QtyTo.value = GetDouble(frmInput.QtyTo.value)
		end sub	
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.JobCode)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CustomsView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">					
				�ʊ֋Ǝ�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="BrokerRef" value="<%=BrokerRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">
				INV ��<input class=si name="ReferNo" value="<%=ReferNo%>" maxlength=20 size=10 onkeydown="ResetEnter()">					
				���Ň�<input class=sz name="Container" value="<%=Container%>" maxlength=16 size=10 onkeydown="ResetEnter()">
				�Ɩ�&nbsp;<SELECT name="JobOperator" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartCustoms, JobOperator)%></select>
				�c��&nbsp;<SELECT name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartSales, JobSalesman)%></select>
				����<input type=checkbox name="Process" value="1" onkeydown="ResetEnter()" <%if Process then response.write " checked"%>>
			<TR><TD nowrap>
				���o�`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				�֖�<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=9 onkeydown="ResetEnter()">
				�`<input class=si name="Port" value="<%=Port%>" maxlength=16 size=9 onkeydown="ResetEnter()">
				������<input class=si name="DeliveryFrom" value="<%=DeliveryFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DeliveryTo" value="<%=DeliveryTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				��<input class=sn name="QtyFrom" value="<%=QtyFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="QtyTo" value="<%=QtyTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">			
<!--
				���l<input class=sj name="Memo" value="<%=Memo%>" maxlength=16 size=10 onkeydown="ResetEnter()">
-->
				�敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'" 
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)
		if BrokerRef <> "" then	strSel = strSel & " AND BrokerRef = '" & FitSel(BrokerRef) & "'"
		if ReferNo <> "" then strSel = strSel & " AND (ReferNo LIKE '%" & FitSel(ReferNo) & "%' OR InvoiceNo LIKE '%" & FitSel(ReferNo) & "%')"			
		if Container <> "" then strSel = strSel & " AND Container LIKE '%" & FitSel(Container) & "%'"					
		if Port <> "" then strSel = strSel & " AND (POL LIKE '%" & FitSel(Port) & "%' OR POD LIKE '%" & FitSel(Port) & "%')"
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if DeliveryFrom <> "" then strSel = strSel & " AND DeliveryDate >= '" & Date2Str(DeliveryFrom) & "'"
		if DeliveryTo <> "" then strSel = strSel & " AND DeliveryDate <= '" & Date2Str(DeliveryTo) & "'"
		if Vessel <> "" then strSel = strSel & " AND VesselVoy LIKE '%" & FitSel(Vessel) & "%'"	
		if Memo <> "" then strSel = strSel & " AND Memo LIKE '%" & FitSel(Memo) & "%'"
		if QtyFrom <> "" then strSel = strSel & " AND Quantity >= " & QtyFrom
		if QtyTo <> "" then strSel = strSel & " AND Quantity <= " & QtyTo
		if JobOperator <> 0 then strSel = strSel & " AND JobOperator = " & JobOperator
		if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman
		if Process = 0 then strSel = strSel & " AND FinisherID = 0"
		if myLevel < 4 then strSel = strSel & " AND SUBSTRING(JobCode,1,2) <> '" & gsInitial & "'"
		
		strSQL = "SELECT * FROM (SELECT JobCode, C.CTM_CD, ClientRef, BrokerRef, JobOperator, JobSalesman, FinisherID, Created, ReferNo, InvoiceNo"
		strSQL = strSQL & ", POL, POD, MBL+' '+HBL AS BLNo, Vessel+' '+Voy AS VesselVoy, Quantity, Container, CustomRemark+' '+Remarks AS Memo, DeliveryDate"
		strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD FROM TBL_CTM_JOB AS T "
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON T.CustomBroker = B.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0) AS TMP"
		if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel, 5)
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY SUBSTRING(JobCode,2,1), Created"
		case 1:		strSQL = strSQL & " ORDER BY JobCode"
		case 2:		strSQL = strSQL & " ORDER BY ClientRef"
		case 3:		strSQL = strSQL & " ORDER BY VesselVoy"
		case 4:		strSQL = strSQL & " ORDER BY POL"
		case 5:		strSQL = strSQL & " ORDER BY POD"
		case 6:		strSQL = strSQL & " ORDER BY ETAETD"
		case 7:		strSQL = strSQL & " ORDER BY Quantity"
		case 8:		strSQL = strSQL & " ORDER BY BrokerRef"
		case 9:		strSQL = strSQL & " ORDER BY JobOperator"
		case 10:	strSQL = strSQL & " ORDER BY InvoiceNo"
		case 11:	strSQL = strSQL & " ORDER BY DeliveryDate"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=2 align=center>
			<colgroup span=4 align=left>
			<colgroup span=4 align=center>
			<colgroup align=right>
			<colgroup span=2 align=left>
			<colgroup span=2 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=4% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�敪
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����׎�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(10)">Inv ��
			<TD width=10% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�֖�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�o���`
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�ړI�`
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">���o�`��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(11)">��Ɗ���
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">��
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">�ʊ֋Ǝ�
			<TD width=5% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">�Ɩ�
			<TD width=5% nowrap>�c��
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else						
						if GetLong(.Fields("FinisherID")) = 0 then
							mycolor = "#000000"
						else
							mycolor = "#606060"
						end if
						
						ClientRef = GetString(.Fields("ClientRef"))
						BrokerRef = GetString(.Fields("BrokerRef"))
						VesselVoy = GetString(.Fields("VesselVoy"))
						ReferNo = GetString(.Fields("InvoiceNo"))
						if ReferNo = "" then ReferNo = GetString(.Fields("ReferNo"))
						POL = GetString(.Fields("POL"))
						POD = GetString(.Fields("POD"))
						'BLNO = GetString(.Fields("BLNO"))
						'Memo = GetString(.Fields("Memo"))
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("JobCode")%>');">
						<TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=GetJobDivision(CheckJobType(.Fields("JobCode")))%>
						<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%><BR>
						<TD nowrap class=line title="<%=GetFullName(.Fields("CTM_CD"))%>"><%=stringCut(ClientRef, 9)%><BR>
						<TD nowrap class=line <%=ShowTitle(ReferNo, 10)%>><%=stringCut(ReferNo, 10)%><BR>
						<TD nowrap class=line <%=ShowTitle(VesselVoy, 18)%>><%=stringCut(VesselVoy, 18)%><BR>
						<TD nowrap class=line <%=ShowTitle(POL, 8)%>><%=stringCut(POL, 8)%><BR>
						<TD nowrap class=line <%=ShowTitle(POD, 8)%>><%=stringCut(POD, 8)%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("ETAETD"))%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("DeliveryDate"))%><BR>
						<TD nowrap class=line><%=GetDouble(.Fields("Quantity"))%><BR>
						<TD nowrap class=line <%=ShowTitle(BrokerRef, 8)%>><%=stringCut(BrokerRef, 8)%><BR>
						<TD nowrap class=line><%=GetEmployName(.Fields("JobOperator"), "F")%><BR>
						<TD nowrap class=line><%=GetEmployName(.Fields("JobSalesman"), "F")%><BR>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
				
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>