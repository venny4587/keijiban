<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim JobBelong
dim JobBroker
dim contents
	
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 0)	
	SelMode = GetPost(request("Sel"))
	
	if JobCode <> "" then
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 

		SeqNo = GetLong(request("SeqNo"))
		myMode = GetLong(request("mode"))
		if myMode > 0 then
			contents = ""
			with Recset
				strSql = "SELECT * FROM TBL_CTM_CONTAINER WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
				strSql = strSql & "AND SeqNo IN (" & GetPost(request("mySel")) & ") ORDER BY SeqNo"
				.Open strSql, Conn, adOpenStatic, adLockReadOnly 
				do while not .eof 
					if contents <> "" then contents = contents & "@@"
					contents = contents & GetString(.fields("ContainerNo"))
					contents = contents & "(" & GetString(.fields("ContainerSize")) & ")"
					if GetString(.fields("BookingNo")) <> "" then
						contents = contents & "-" & GetString(.fields("BookingNo"))
					end if
					.movenext
				loop
				.close
			end with			
		end if
%>
<html>
<HEAD>
	<TITLE>�R�����e�i�[�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		sub DoSelect()
		dim buf
			if GetDouble(frmInput.Quantity.value) = 0 then
				msgbox "���͂��ꂽ���͕s���ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			elseif GetDouble(frmInput.Quantity.value) > GetDouble(frmInput.Limit.value) then
				msgbox "���͂��ꂽ���͕s���ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			buf = ""
			buf = buf & FitZero(frmInput.Quantity.value) & frmInput.Package.value
			if GetDouble(frmInput.Weight.value) <> 0 then 
				buf = buf & " = " & FitZero(frmInput.Weight.value) & "KGS"
			end if 
			if GetDouble(frmInput.Measure.value) <> 0 then 
				buf = buf & " = " & FitZero(frmInput.Measure.value) & "M3"
			end if 
			window.opener.frmInput.contents.value = buf
			window.opener.frmInput.Remarks.focus()
			window.close
		end sub
	
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 5) = "mySel" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�R���e�i�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end function 
	
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
		end sub		
		
		sub Quantity_OnBlur()
		dim qty, cbm, gw, ttl
			gw = 0
			cbm = 0
			qty = GetDouble(frmInput.Quantity.value)
			ttl = GetDouble(frmInput.QTY.value)
			if ttl <> 0 then
				cbm = qty / ttl * GetDouble(frmInput.CBM.value)
				gw = qty / ttl * GetDouble(frmInput.GW.value)
			end if
			frmInput.Quantity.value = qty
			frmInput.Measure.value = formatnumber(cbm, 3, true)
			frmInput.Weight.value = formatnumber(gw, 3, true)
		end sub
		
		function FitZero(myStr)
		dim buf, pos
			buf = cstr(myStr & "")
			pos = instr(buf, ".")
			if pos > 0 then
				do while right(buf, 1) = "0"
					buf = left(buf, len(buf)-1)
				loop 
				if right(buf, 1) = "." then buf = left(buf, len(buf)-1)
			end if
			FitZero = buf
		end function
		
		sub InitForm()
<%if myMode > 0 then%>
			window.opener.frmInput.ContainerSel.value = "<%=GetPost(request("mySel"))%>"
			window.opener.frmInput.contents.value = "<%=replace(contents, "@@", """ & vbcrlf & """)%>"
			window.opener.frmInput.Remarks.focus()
			window.close()
<%end if%>
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="ContainerSel.asp" method="post">
  	<input type=hidden name="mode" value="1">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=40%>���[�i���&nbsp;
		<td width=40%>�䒠�ԍ��F<%=JobCode%>
		<td width=20% align=right>
	</table>
	<hr width=96% size=1><%=JobHeader%><br><br>
<%
select case SelMode
case "CY ���[", "��ݏo���ׯ�"
		'�R���e�i�[���
		cnt = 0
		with Recset
			strSql = "SELECT COUNT(SeqNo) AS CNT FROM TBL_CTM_CONTAINER WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			strSql = strSql & " AND (Arranged = 0 OR Arranged = " & SeqNo & ")"
			.Open strSql, Conn, adOpenStatic, adLockReadOnly 
			if not .eof then cnt = GetLong(.fields("CNT"))
			.Close
%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		<TR><td width=40%>���R���e�i�[
			<td width=60% class=pt9g>�I���\ <input class=sn name="VAN" size=5 value="<%=cnt%>" onkeydown="ResetEnter()" readonly>
			 CONTAINER<%if cnt > 0 then response.write "S"%>
	</table>
	<hr width=96% size=1>
	<table width=80% class=pt9n>
	  <TR class=pt9><TD class=gline>��<TD class=gline>�T�C�Y<TD class=gline>�R���e�i�[��<TD class=gline>�\��ԍ�<TD class=gline>�I��				
<%
			strSql = "SELECT * FROM TBL_CTM_CONTAINER WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			strSql = strSql & "ORDER BY SeqNo"
			.Open strSql, Conn, adOpenStatic, adLockReadOnly 
			cnt = 0
			do while not .eof
				cnt = cnt + 1
				mySeq = GetLong(.fields("SeqNo"))
				mySeqNo = GetLong(.fields("Arranged"))
				ContainerNo = GetString(.fields("ContainerNo")) & "(" & GetString(.fields("ContainerSize")) & ")"
				ContainerNo = ContainerNo & "<BR>�\�񇂁F" & GetString(.fields("BookingNo"))
%>
	  <TR><TD class=gline><%=cnt%><TD class=gline><%=GetString(.fields("ContainerSize"))%><TD class=gline><%=GetString(.fields("ContainerNo"))%>
	  	  <TD class=gline><%=GetString(.fields("BookingNo"))%><br><TD class=gline><%if mySeqNo <> 0 and mySeqNo <> SeqNo then%>�|<%else%>
	  	  	<input type=checkbox name="mySel" value="<%=mySeq%>" <%if mySeqNo <> 0 and mySeqNo = SeqNo then response.write "checked"%>><%end if%>
<%
				.movenext
			loop
			.Close
%>
	  <TR><td colspan=5 align=right><input type=button style="width:90;height:30" name=btnSave value="�m��" onclick="DoConfirm()">
	</table>
<%
		end with
		
case else 

		'�����
		CBM = 0:	GW = 0:		Qty = 0:	Quantity = 0
		with Recset
			'����
			strSql = "SELECT CBM, GW, Quantity, Package FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			.Open strSql, Conn, adOpenStatic, adLockReadOnly 
			if not .eof then
				GW = GetDouble(.fields("GW"))
				CBM = GetDouble(.fields("CBM"))
				Qty = GetDouble(.fields("Quantity"))
				Package = GetString(.fields("Package"))
			end if
			.Close
			
			'����
			Limit = Qty:	Quantity = Qty:		Measure = CBM:		Weight = GW
			strSql = "SELECT SeqNo, Contents FROM TBL_CTM_DELIVERY WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			.Open strSql, Conn, adOpenStatic, adLockReadOnly 
			do while not .eof
				buf = GetString(.fields("Contents"))
				pos = instr(buf, FitPackage(Package))
				if pos > 0 then
					buf = left(buf, pos-1)
					if GetLong(.fields("SeqNo")) = SeqNo then
						Quantity = GetLong(buf)
					else
						Limit = Limit - GetLong(buf)
					end if
				end if
				.movenext
			loop
			.Close
		
			if Quantity <> Qty and Qty <> 0 then
				Measure = Quantity / Qty * CBM
				Weight = Quantity / Qty * GW
			end if
		end with
%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		<TR><td width=40%>�������
			<td width=60% class=pt9g>���p�\ <input class=sn name="Limit" size=5 value="<%=Limit%>" onkeydown="ResetEnter()" readonly> <%=Package%>
	</table>
	<hr width=96% size=1>
	  	<input type=hidden name="GW" value="<%=GW%>">
	  	<input type=hidden name="CBM" value="<%=CBM%>">
	  	<input type=hidden name="Qty" value="<%=Qty%>">
	  	<input type=hidden name="Package" value="<%=Package%>">
	<table width=80% class=pt9>
	  <tr>
		<td><input class=sn name="Quantity" size=8 maxlength=9 value="<%=Quantity%>" onkeydown="ResetEnter()"> <%=Package%>
		<td>(<input class=sn name="Weight" size=8 maxlength=9 value="<%=formatnumber(Weight, 3, true)%>" onkeydown="ResetEnter()"> KGS
		<td><input class=sn name="Measure" size=8 maxlength=9 value="<%=formatnumber(Measure, 3, true)%>" onkeydown="ResetEnter()"> M<sup>3</sup>)
	  	<td align=right><input type=button style="width:90;height:30" name=btnSave value="�m��" onclick="DoSelect()">
	</table>
	<br><br>
<%
end select
%>
  </FORM>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>


<%
function FitPackage(myPkg)
dim pos
	FitPackage = myPkg
	pos = len(myPkg)
	if pos > 2 then 
		if right(ucase(myPkg), 2) = "ES" then
			FitPackage = left(myPkg, pos - 2)
		elseif right(ucase(myPkg), 1) = "S" then
			FitPackage = left(myPkg, pos - 1)
		end if
	end if
end function
%>