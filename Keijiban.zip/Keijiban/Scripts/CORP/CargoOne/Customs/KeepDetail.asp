<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim JobClient
dim JobLocker
dim ExpenseNo

	JobCode = GetPost(request("JobCode"))	
	JobHeader = ShowCstmJobHead(JobCode, 0)
	
	ChargeNo = GetPost(request("No"))
	ExpenseNo = GetLong(request("Seq"))
	if JobCode <> "" AND ExpenseNo <> 0 then

		SeqNo = 0
		OpenSql Conn, SqlServerName, DataBaseName
		if CheckBillLocked(Conn, JobCode, ChargeNo) then JobLocker = 1

		ExpenseQuantity = GetDouble(request("Qty"))
		ExpenseMemo = GetPost(request("Memo"))
		ExpenseTax = GetLong(request("Tax"))
				
		set Recset = Server.CreateObject("adodb.recordset")
		with Recset
			strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "' AND SeqNo = " & ExpenseNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then			
				ExpenseQuantity = GetDouble(.fields("ExpenseQuantity"))
				ExpenseMemo = GetString(.fields("ExpenseMemo"))	
				ExpenseTax = GetLong(.fields("ExpenseTax"))	
			end if
			.close
		end with
		
		KeepTax = ExpenseTax
		KeepRTON = ExpenseQuantity
		KeepInDate = mid(ExpenseMemo, 1, 5)
		KeepOutDate = mid(ExpenseMemo, 7, 5)
		curYear = year(date)
		KeepOutDate = curYear & "/" & KeepOutDate
		if KeepOutDate < KeepInDate then curYear = curYear - 1
		KeepInDate = curYear & "/" & KeepInDate
		
		KeepFreetime = NumInStr(ExpenseMemo, ":", ")")
		KeepPrice = NumInStr(ExpenseMemo, "�F", "�~")
		KeepDayCount = NumInStr(ExpenseMemo, "��", "��")
		KeepAmount = fix(KeepPrice * KeepDayCount * KeepRTON)
		
		with Recset
			strSql = "SELECT * FROM TBL_CTM_KEEP WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseNo = " & ExpenseNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				SeqNo = GetLong(.fields("SeqNo"))
				KeepCode = GetString(.fields("KeepCode"))
				KeepInDate = Str2Date(.fields("KeepInDate"))
				KeepOutDate = Str2Date(.fields("KeepOutDate"))
				KeepFreetime = GetLong(.fields("KeepFreetime"))
				KeepDayCount = GetLong(.fields("KeepDayCount"))
				
				KeepPKG = GetLong(.fields("KeepPKG"))
				KeepRTON = GetDouble(.fields("KeepRTON"))
				KeepPrice1 = GetLong(.fields("KeepPrice1"))
				KeepPrice2 = GetLong(.fields("KeepPrice2"))
				KeepPrice3 = GetLong(.fields("KeepPrice3"))
				KeepPrice4 = GetLong(.fields("KeepPrice4"))
				KeepAmount = GetLong(.fields("KeepAmount"))
				KeepTax = GetLong(.fields("KeepTax"))
				KeepTaxName = GetString(.fields("KeepTaxName"))
				KeepDivision = GetString(.fields("KeepDivision"))
								
				Remarks = GetString(.fields("Remarks"))		
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
		end with
		
		if KeepPrice = 0 then KeepPrice = KeepPrice4
		if KeepPrice = 0 then KeepPrice = KeepPrice3
		if KeepPrice = 0 then KeepPrice = KeepPrice2
		if KeepPrice = 0 then KeepPrice = KeepPrice1
%>
<html>
<HEAD>
	<TITLE>�ۊǏڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub KeepInDate_OnBlur()
			frmInput.KeepInDate.value = setDate(frmInput.KeepInDate.value)
			Call SetDayCount()
		end sub		
		sub KeepOutDate_OnBlur()
			frmInput.KeepOutDate.value = setDate(frmInput.KeepOutDate.value)
			Call SetDayCount()
		end sub
		sub KeepPKG_OnBlur()
			frmInput.KeepPKG.value = GetLong(frmInput.KeepPKG.value)
		end sub
		sub KeepFreetime_OnBlur()
			frmInput.KeepFreetime.value = GetLong(frmInput.KeepFreetime.value)
			Call SetDayCount()
		end sub
		sub SetDayCount()
		dim cnt
			if not isdate(frmInput.KeepInDate.value) then exit sub
			if not isdate(frmInput.KeepOutDate.value) then exit sub
			cnt = Datediff("d", cdate(frmInput.KeepInDate.value), cdate(frmInput.KeepOutDate.value))
			frmInput.KeepDayCount.value = cnt - GetLong(frmInput.KeepFreetime.value) + 1
			Call CalculateAmount()
		end sub
		
		sub KeepPKG_OnBlur()
			frmInput.KeepPKG.value = GetLong(frmInput.KeepPKG.value)
		end sub
		sub KeepRTON_OnBlur()
			frmInput.KeepRTON.value = GetLong(GetDouble(frmInput.KeepRTON.value) * 1000) / 1000
			Call CalculateAmount()
		end sub
		sub KeepPrice_OnBlur()
			frmInput.KeepPrice.value = GetLong(frmInput.KeepPrice.value)
			Call CalculateAmount()
		end sub
		sub CalculateAmount()
		dim prc
			prc = GetLong(frmInput.KeepPrice.value) * GetLong(frmInput.KeepDayCount.value)
			frmInput.KeepAmount.value = formatnumber(prc * GetDouble(frmInput.KeepRTON.value), 0, true)
			Call CalculateTax()
		end sub
		
		sub KeepAmount_OnBlur()
			frmInput.KeepAmount.value = formatnumber(GetLong(frmInput.KeepAmount.value),0,true)
			Call CalculateTax()
		end sub
		sub KeepTaxName_OnChange()
			Call CalculateTax()
		end sub
		sub KeepTax_OnBlur()
			frmInput.KeepTax.value = formatnumber(GetLong(frmInput.KeepTax.value),0,true)
		end sub
		sub CalculateTax()
		dim buf
			buf = frmInput.KeepTaxName.options(frmInput.KeepTaxName.selectedIndex).text
			buf = GetLong(frmInput.KeepAmount.value) * GetTaxRate(buf)
			frmInput.KeepTax.value = formatnumber(ResetDigital(buf, 0, -1), 0, true)			
		end sub
		
		sub DataSave()
			if checkText("KeepCode","���ɔԍ�",0) = false then exit sub
			if checkDate("KeepInDate","���ɓ�",1) = false then exit sub
			if checkDate("KeepOutDate","�o�ɓ�",1) = false then exit sub
			if checkNum("KeepPKG","��",1) = false then exit sub
			if checkNum("KeepFreetime","FreeTime",1) = false then exit sub
			if checkNum("KeepDayCount","����",1) = false then exit sub
			if checkDouble("KeepRTON","R/TON",1) = false then exit sub
			if checkNum("KeepPrice","�P��",1) = false then exit sub
			if checkNum("KeepAmount","��ېŊz",1) = false then exit sub
			if checkNum("KeepTax","����Ŋz",1) = false then exit sub
			if checkNum("KeepDivision","�q�ɋ敪",0) = false then exit sub
			if checkNum("KeepPrice1","�P��",0) = false then exit sub
			if checkNum("KeepPrice2","�Q��",0) = false then exit sub
			if checkNum("KeepPrice3","�R��",0) = false then exit sub
			if checkNum("KeepPrice4","�S��",0) = false then exit sub
			if checkText("Remarks","�x������", 0) = false then exit sub
			if checkLen("Remarks","�x������", 250) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub InitForm()
<%if JobLocker <> 0 then%>
			call LockAll()
<%else%>
			frmInput.KeepCode.focus()
<%end if%>
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
<%if ConfirmerID = 0 then%>	
					call DataSave() 
<%end if%>
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsKeepBackColor%>" topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()"  <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="KeepUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="ChargeNo" value="<%=ChargeNo%>">
  	<input type=hidden name="ExpenseNo" value="<%=ExpenseNo%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td width=30%>���ۊǗ��ڍ׏��&nbsp;
<%	if JobLocker = 0 and SeqNo <> 0 then %>
	  	  <img style="cursor:help" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%	end if %>
	  	<td width=30% class=pt9b>�䒠�ԍ��F<%=JobCode%>
		<td width=30% align=right>
<%	if JobLocker <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="���b�N�ς�">
<%	else %>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
<%	end if %><br>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=28>
		<TD align=center width=60>���ɔԍ�
		<TD><input class=si name="KeepCode" maxlength=20 size=15 value="<%=KeepCode%>" onkeydown="ResetEnter()">
		<TD align=center width=50>���ɓ�
		<TD><input class=si name="KeepInDate" maxlength=10 size=10 value="<%=KeepInDate%>" onkeydown="ResetEnter()" 
				<%if JobLocker = 0 then%> onclick="setday(this)"<%end if%>>
		<TD align=center width=50>�o�ɓ�
		<TD><input class=si name="KeepOutDate" maxlength=10 size=10 value="<%=KeepOutDate%>" onkeydown="ResetEnter()" 
				<%if JobLocker = 0 then%> onclick="setday(this)"<%end if%>>
		<TD align=center width=40>��
		<TD><input class=sn name="KeepPKG" maxlength=8 size=8 value="<%=formatnumber(KeepPKG, 0, true)%>" onkeydown="ResetEnter()">
	  <TR height=28>
		<TD align=center>FreeTime
		<TD><input class=sn name="KeepFreetime" maxlength=8 size=8 value="<%=formatnumber(KeepFreetime, 0, true)%>" onkeydown="ResetEnter()"> ��
		<TD align=center>����
		<TD><input class=sn name="KeepDayCount" maxlength=8 size=8 value="<%=formatnumber(KeepDayCount, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=center>R/TON
		<TD><input class=sn name="KeepRTON" maxlength=8 size=8 value="<%=formatnumber(KeepRTON, 3, true)%>" onkeydown="ResetEnter()">
		<TD align=center>�P��
		<TD nowrap><input class=sn name="KeepPrice" size=8 maxlength=8 value="<%=formatnumber(KeepPrice, 0, true)%>" onkeydown="ResetEnter()"> �~
	  <TR height=28>
		<TD align=center>��ېŊz
		<TD><input class=sn name="KeepAmount" size=10 maxlength=8 value="<%=formatnumber(KeepAmount, 0, true)%>" onkeydown="ResetEnter()"> �~
		<TD align=center>�ŋ敪
		<TD><select name="KeepTaxName" onkeydown="ResetEnter()" <%if JobLocker <> 0 then response.write "disabled" %>>
			<%=ShowCategoryList("TaxCode", KeepTaxName, 1)%></select>
		<TD align=center class=pt9>�����
		<TD><input class=sn name="KeepTax" size=8 maxlength=8 value="<%=formatnumber(KeepTax, 0, true)%>" onkeydown="ResetEnter()"> �~
		<TD align=center class=pt9>�敪
		<TD><input class=si name="KeepDivision" maxlength=2 size=8 value="<%=KeepDivision%>" onkeydown="ResetEnter()">
	  <TR height=28 class=pt9>
		<TD align=center>�P��
		<TD><input class=sn name="KeepPrice1" size=8 maxlength=8 value="<%=formatnumber(KeepPrice1, 0, true)%>" onkeydown="ResetEnter()"> �~
		<TD align=center>�Q��
		<TD><input class=sn name="KeepPrice2" size=8 maxlength=8 value="<%=formatnumber(KeepPrice2, 0, true)%>" onkeydown="ResetEnter()"> �~
		<TD align=center>�R��
		<TD><input class=sn name="KeepPrice3" size=8 maxlength=8 value="<%=formatnumber(KeepPrice3, 0, true)%>" onkeydown="ResetEnter()"> �~
		<TD align=center>�S��
		<TD><input class=sn name="KeepPrice4" size=8 maxlength=8 value="<%=formatnumber(KeepPrice4, 0, true)%>" onkeydown="ResetEnter()"> �~
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=28>
		<TD class=pt9 align=center>����
		<TD colspan=5><textarea name="Remarks" rows=4 style="width:350"><%=Remarks%></textarea>
		<TD colspan=2 align=center>
<%if gsSaveButton = 1 and JobLocker = 0 then%>
			<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" name=btnClose value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function NumInStr(myStr, myChr1, myChr2)
dim buf, pos
	NumInStr = 0
	
	pos = instr(myStr, myChr1)
	if pos = 0 then exit function
	buf = mid(myStr, pos + 1)
	
	pos = instr(buf, myChr2)
	if pos = 0 then exit function
	buf = left(buf, pos - 1)
	
	NumInStr = GetLong(buf)
end function
%>