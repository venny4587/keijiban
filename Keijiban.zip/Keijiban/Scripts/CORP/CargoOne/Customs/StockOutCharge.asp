<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
dim StartDate
dim EndDate
dim PrevDate
dim NextDate
dim term1
dim term2
dim term3
dim price

	price = 300		'���P��

	CTM_MONTH = GetLong(request("sel"))
	if CTM_MONTH = 0 then CTM_MONTH = 1 	'1�����O
	
	EndDate = GetMonthLastDay(dateadd("m", 0-CTM_MONTH, date))
	StartDate = CDate(Year(EndDate) & "/" & Month(EndDate) & "/1")
    
    PrevDate = "20050601"					'2005�N6���ȍ~�L��
    StartDate = Date2Str(StartDate)
    EndDate = Date2Str(EndDate)
    
    term1 = left(StartDate, 6) & "20"
    term2 = left(StartDate, 6) & "10"
    term3 = left(StartDate, 6) & "00"
    
	CTM_REF = GetString(request("ref"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	with recset
		strSql = "SELECT CTM_CD, CTM_ABR, CTM_NAME FROM CUSTOMER WHERE CTM_REF = '" & CTM_REF & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
			CTM_CD = GetString(.fields("CTM_CD"))
			CTM_ABR = GetString(.fields("CTM_ABR"))
			CTM_NAME = GetString(.fields("CTM_NAME"))
		end if
		.close
	end with
%>
<HTML>
<HEAD>
	<TITLE>���ɕۊǗ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 12pt; LINE-HEIGHT: 1.5em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 14pt; LINE-HEIGHT: 1.5em; color: black; }
		.ptx { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 18pt; LINE-HEIGHT: 1.5em; color: black; }
	</style>
	<SCRIPT language=javascript>
		function DoShortCut() {
			if (window.event.keyCode==27) window.close();
			if (window.event.keyCode==80) window.print();
			if (window.event.keyCode==120) DoCopy();
		}
		
		function DoCopy() {
			var doc = document.body.createTextRange();
			doc.moveToElementText(document.all("list"));
			doc.execCommand("copy");
		}
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
	<table width=660 Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <tr height=30>
	  	<td nowrap width=300><%=CTM_NAME%>�a
	  	<td nowrap width=200>���ɕۊǗ�
	 	<td nowrap width=140 align=right class=pts>�o�͓��F<%=formatDate(date)%>
	</table>
<div id="list">
<!--���׍s-->
<%
	myTotal = 0
	with Recset
		
        '�݌ɕۊǗ�
        strSql = "SELECT * FROM (SELECT SeqNo, StockDate, StockNo, StockCBM, StockName, StockPkgCnt, StockPkgZan"
        strSql = strSql & " FROM TBL_CTM_STOCK WHERE Deleted = 0 AND StockType = 0 AND StockClient = '" & CTM_CD & "'"
        strSql = strSql & " AND StockDate BETWEEN '" & PrevDate & "' AND '" & term1 & "') AS IM LEFT JOIN"			'1��FREE
        strSql = strSql & " (SELECT ImportNo, SUM(Packages) AS StockPkgOut FROM TBL_CTM_STOCK_LINK AS L INNER JOIN"
        strSql = strSql & " TBL_CTM_STOCK AS S ON L.ExportNo = S.SeqNo WHERE Deleted = 0 AND StockType = 1 "
        strSql = strSql & " AND S.StockDate > '" & EndDate & "' GROUP BY ImportNo) AS EX ON IM.SeqNo = EX.ImportNo"
        strSql = strSql & " WHERE StockPkgZan + ISNULL(StockPkgOut, 0) > 0 ORDER BY StockDate, StockNo"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
%>
	<TABLE width=660 Cellspacing=3 CellPadding=3 class=pts>
		<colgroup span=3 align=left>
		<colgroup span=4 align=right>
		<TR><TD class=line nowrap>���ɓ�
			<TD class=line nowrap>���ɔԍ�
			<TD class=line width=260>���i��
			<TD class=line nowrap>��
			<TD class=line nowrap>�c��
			<TD class=line nowrap>�c�Ԑ�
			<TD class=line nowrap>�ۊǗ�
<%
            myQty = 0
            myDate = ""
			do while not .eof
                '�ۊǗ��v�Z
                myCount = GetLong(.Fields("StockPkgZan")) + GetLong(.Fields("StockPkgOut"))
                myQuantity = myCount * GetDouble(.Fields("StockCBM")) / GetLong(.Fields("StockPkgCnt"))
                If myQuantity > 0 Then
                    
                    '�挎�܂Ŗ��o�ɕ�
                    If myDate <> GetString(.Fields("StockDate")) Then
                                            
                        '�݌ɂR�����v
                        If myDate <= term3 And GetString(.Fields("StockDate")) > term3 Then
                            If myQty > 0 Then
                            	myPrice = price * 3
                                mySum = GetLong(myQty * myPrice)
%>
		<TR><TD class=line colspan=2>�݌ɂR��
			<TD class=line colspan=2>�P���F<%=formatnumber(myPrice, 0, true)%>
			<TD class=line>���v
			<TD class=line><%=formatnumber(myQty, 3, true)%>
			<TD class=line><%=formatnumber(mySum, 0, true)%>
<%
                            	myQty = 0
                                myTotal = myTotal + mySum
                            End If
                            
                        '�݌ɂQ�����v
                        elseIf myDate <= term2 And GetString(.Fields("StockDate")) > term2 Then
                            If myQty > 0 Then
                            	myPrice = price * 2
                                mySum = GetLong(myQty * myPrice)
%>
		<TR><TD class=line colspan=2>�݌ɂQ��
			<TD class=line colspan=2>�P���F<%=formatnumber(myPrice, 0, true)%>
			<TD class=line>���v
			<TD class=line><%=formatnumber(myQty, 3, true)%>
			<TD class=line><%=formatnumber(mySum, 0, true)%>
<%
                            	myQty = 0
                                myTotal = myTotal + mySum
                            End If
                            
                        end if
                        myDate = GetString(.Fields("StockDate"))
%>
		<TR><TD class=line nowrap><%=Str2YMD(myDate)%>
			<TD class=line nowrap><%=GetString(.Fields("StockNo"))%>
			<TD class=line nowrap><%=GetString(.Fields("StockName"))%>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("StockPkgCnt")), 0, true)%>
			<TD class=line nowrap><%=formatnumber(myCount, 0, true)%>
			<TD class=line nowrap><%=formatnumber(myQuantity, 3, true)%>
<%
               		else
%>
		<TR><TD><BR>
			<TD class=line nowrap><%=GetString(.Fields("StockNo"))%>
			<TD class=line nowrap><%=GetString(.Fields("StockName"))%>
			<TD class=line nowrap><%=GetLong(.Fields("StockPkgCnt"))%>
			<TD class=line nowrap><%=formatnumber(myCount, 0, true)%>
			<TD class=line nowrap><%=formatnumber(myQuantity, 3, true)%>
<%
               		end if
               		
                    myQty = myQty + myQuantity
                End If
                        
                .MoveNext
            Loop
            If myQty > 0 Then
                '�݌ɂR�����v
                If myDate <= term3 Then
                	myPrice = price * 3
                    mySum = GetLong(myQty * myPrice)
                    myTitle = "�݌ɂR��"
                    
                '�݌ɂQ�����v
                ElseIf myDate <= term2 Then
                	myPrice = price * 2
                    mySum = GetLong(myQty * myPrice)
                    myTitle = "�݌ɂQ��"
                   
                '�݌ɂP�����v
                Else
                	myPrice = price
                    mySum = GetLong(myQty * myPrice)
                    myTitle = "�݌ɂP��"
                    
                End If
%>
		<TR><TD class=line colspan=2><%=myTitle%>
			<TD class=line colspan=2>�P���F<%=formatnumber(myPrice, 0, true)%>
			<TD class=line>���v
			<TD class=line><%=formatnumber(myQty, 3, true)%>
			<TD class=line><%=formatnumber(mySum, 0, true)%>
<%
                myTotal = myTotal + mySum
            End If
		end if
		.close
		
        '�o�ɕۊǗ�
        strSql = ""
        strSql = strSql & "SELECT * FROM (SELECT SeqNo, StockDate AS OutDate FROM TBL_CTM_STOCK"
        strSql = strSql & " WHERE StockType = 1 AND Deleted = 0 AND StockClient = '" & CTM_CD & "'"
        strSql = strSql & " AND StockDate BETWEEN '" & StartDate & "' AND '" & EndDate & "'"
        strSql = strSql & ") AS EX INNER JOIN TBL_CTM_STOCK_LINK AS L ON EX.SeqNo = L.ExportNo INNER JOIN ("
        strSql = strSql & "SELECT SeqNo, StockDate AS InDate, StockNo, StockPkgCnt, StockCBM, StockName"
        strSql = strSql & " FROM TBL_CTM_STOCK WHERE StockType = 0 AND Deleted = 0 AND StockClient = '" & CTM_CD & "'"
        strSql = strSql & ") AS IM ON IM.SeqNo = L.ImportNo ORDER BY OutDate, InDate, StockNo"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
            myQty1 = 0
            myQty2 = 0
            myQty3 = 0
            myDate = ""
%>
		<TR><TD class=line>�o�ɓ�
			<TD class=line>���ɔԍ�
			<TD class=line>���i��
			<TD class=line>���ɓ�
			<TD class=line>�o��
			<TD class=line>�o�Ԑ�
			<TD class=line>�ۊǗ�
<%
            Do While Not .EOF
                '�ۊǗ��v�Z
                myAmount = 0
                myQuantity = GetLong(.Fields("Packages")) * GetDouble(.Fields("StockCBM")) / GetLong(.Fields("StockPkgCnt"))
                myCount = TermDiff(Str2Date(.Fields("InDate")), Str2Date(.Fields("OutDate")))
                if myCount > 3 then myCount = 3
                If myCount > 0 Then myAmount = Price * myCount * myQuantity
                
                If myAmount > 0 Then
                	if myDate <> GetString(.Fields("OutDate")) then
                		myDate = GetString(.Fields("OutDate"))
%>
		<TR><TD class=line nowrap><%=Str2YMD(myDate)%>
<%
					else
%>
		<TR><TD><BR>
<%
					end if
%>
			<TD class=line nowrap><%=GetString(.Fields("StockNo"))%>
			<TD class=line nowrap><%=GetString(.Fields("StockName"))%>
			<TD class=line nowrap><%=Str2YMD(.Fields("InDate"))%>
			<TD class=line nowrap><%=GetLong(.Fields("Packages"))%>
			<TD class=line nowrap><%=formatnumber(myQuantity, 3, true)%>
			<TD class=line nowrap><%=myCount%>��
<%
                    Select Case myCount
                    Case 1:     myQty1 = myQty1 + myQuantity
                    Case 2:     myQty2 = myQty2 + myQuantity
                    Case 3:     myQty3 = myQty3 + myQuantity
                    End Select
                End If
                .MoveNext
            Loop
            .Close
	            
	        '�R���݌ɍ��v
	        If myQty3 > 0 Then
	        	myPrice = Price * 3
	            mySum = GetLong(myQty3 * myPrice)
%>
		<TR><TD class=line colspan=2>�o�ɂR��
			<TD class=line colspan=2>�P���F<%=formatnumber(myPrice, 0, true)%>
			<TD class=line>���v
			<TD class=line><%=formatnumber(myQty3, 3, true)%>
			<TD class=line><%=formatnumber(mySum, 0, true)%>
<%
	            myTotal = myTotal + mySum
	        End If
	        
	        '�Q���݌ɍ��v
	        If myQty2 > 0 Then
	        	myPrice = Price * 2
	            mySum = GetLong(myQty2 * myPrice)
%>
		<TR><TD class=line colspan=2>�o�ɂQ��
			<TD class=line colspan=2>�P���F<%=formatnumber(myPrice, 0, true)%>
			<TD class=line>���v
			<TD class=line><%=formatnumber(myQty2, 3, true)%>
			<TD class=line><%=formatnumber(mySum, 0, true)%>
<%
	            myTotal = myTotal + mySum
	        End If
	        
	        '�P���݌ɍ��v
	        If myQty1 > 0 Then
	        	myPrice = Price
	            mySum = GetLong(myQty1 * myPrice)
%>
		<TR><TD class=line colspan=2>�o�ɂP��
			<TD class=line colspan=2>�P���F<%=formatnumber(myPrice, 0, true)%>
			<TD class=line>���v
			<TD class=line><%=formatnumber(myQty1, 3, true)%>
			<TD class=line><%=formatnumber(mySum, 0, true)%>
<%
	            myTotal = myTotal + mySum
	        End If
		end if
	end with
    If myTotal <> 0 Then
%>
		<TR><TD class=line colspan=2><%=ShowJpnYear(left(EndDate, 4))%><%=GetJapanNo(mid(EndDate, 5, 2))%>��
			<TD class=line colspan=2>���ɕۊǗ�
			<TD class=line>���v
			<TD class=line colspan=2><%=formatnumber(myTotal, 0, true)%>
<%
    End If
%> 
	</table>
</div>
</center>
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>

<%
Function TermDiff(dt1, dt2)
Dim t1
Dim t2
Dim mon
    t1 = GetTerm(dt1)
    t2 = GetTerm(dt2)
    mon = DateDiff("m", dt1, dt2)
    If mon > 0 Then t2 = t2 + mon * 3
    TermDiff = t2 - t1
End Function

Function GetTerm(mydt)
    GetTerm = 1
    If Day(mydt) > 10 Then
        GetTerm = 2
        If Day(mydt) > 20 Then GetTerm = 3
    End If
End Function

%>