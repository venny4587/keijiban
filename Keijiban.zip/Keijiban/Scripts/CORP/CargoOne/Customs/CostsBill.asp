<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim JobBelong
dim JobBroker
	
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	if JobBroker = gsCorpCode then			'�{�Јϑ�
		myLevel = CheckUserLevel(gsCorpInit, JobBroker)
		if UserShop <> gsCorpInit and UserShop = left(JobCode, 1) then 
			myLevel = CheckUserLevel(JobBelong, JobBroker)
		end if
	else
		myLevel = CheckUserLevel(JobBelong, JobBroker)
	end if
			
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�x���`�[�ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript>
		function ShowHead(myNo)
			window.parent.data.location.href = "PaymentHead.asp?type=2&JobCode=<%=JobCode%>&CostsNo=" & myNo
			window.parent.data.focus()
		end function
		
		function ShowDetail(myNo)
			window.parent.data.location.href = "CostsList.asp?type=2&JobCode=<%=JobCode%>&CostsNo=" & myNo
			window.parent.data.focus()
		end function
		
		function ShowJobInfo()
			window.parent.location.href = "CustomsEdit.asp?JobCode=<%=JobCode%>"
		end function
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsCostsBackColor%>" topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=30%>���x���`�[�ꗗ&nbsp;
	  	<img style="cursor:hand" src=img/back.gif alt="�Ɩ���ʂ�" onmousedown="ShowJobInfo()">
	  	<td width=40%>�䒠�ԍ��F<%=JobCode%>
	  	<td width=30% align=right>
<%	if CheckJobLocked(JobCode) then %>
	  	<img style="cursor:help" src=img/security.gif alt="���b�N�ς�">
<%	elseif myLevel > 0 then %>
	  	<img style="cursor:hand" src=img/new.gif alt="�x���`�[�V�K�ǉ�" onmousedown="ShowHead('')">
<%	end if %>
	</table>
	
	<hr size=1 color=black>
<%
	with recset
		strSql = "SELECT CostsNo, CostsType, CostsClient, CostsPic, CostsCheck, CostsDate"
		strSql = strSql & ", CostsAmount, CostsTax, CostsPayDay, ConfirmerID, FinisherID"
		strSql = strSql & " FROM TBL_CTM_Costs WHERE Deleted = 0 AND JobCode = '" & FitSel(JobCode) & "'"
		strSql = strSql & " ORDER BY CostsNo"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>�敪
		<TD class=line nowrap>�`�[�ԍ�
		<TD class=line nowrap>�퐿��
		<TD class=line nowrap>�x����
		<TD class=line nowrap>�x����
		<TD class=line nowrap>�x�����z
		<TD class=line nowrap>����
		<TD class=line nowrap>�m��
		<TD class=line nowrap>�x��
		<TD class=line nowrap>�ҏW
		<TD class=line nowrap>����
<%
			cnt = 0:	SeqNo = 0
			ttlTax = 0:	ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				CostsNo = GetString(.Fields("CostsNo"))
				
				RefName = GetRefName(GetString(.Fields("CostsClient")))
				PicName = GetString(.Fields("CostsPic"))
				if GetLong(.Fields("CostsCheck")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=red>��</font>"
				end if
				if GetLong(.Fields("ConfirmerID")) <> 0 then
					check = "<font color=black>��</font>"
				else
					check = "<font color=gray>��</font>"
				end if
				if GetLong(.Fields("FinisherID")) <> 0 then
					finish = "<font color=black>��</font>"
				else
					finish = "<font color=gray>��</font>"
				end if
%>
				<TR align=center height=20>
					<TD class=line><%=cnt%><BR>
					<TD class=line><%=ShowCostsType(.Fields("CostsType"))%><BR>
					<TD class=line nowrap align=left><%=ShowVoucherNo(CostsNo)%><BR>
					<TD class=line style="color:#228b22"><%=Str2MD(.Fields("CostsDate"))%><BR>
					<TD class=line nowrap align=left <%=ShowTitle(RefName, 8)%>><%=StringCut(RefName,8)%><BR>
					<TD class=line><%=Str2MD(.Fields("CostsPayDay"))%><BR>
					<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("CostsAmount"))+GetLong(.Fields("CostsTax")), 0, true)%><BR>
					<TD class=line><%=status%><BR>
					<TD class=line><%=check%><BR>
					<TD class=line style="cursor:help" title="<%=GetEraseInfo(CostsNo, 1)%>"><%=finish%><BR>
					<TD class=line><IMG SRC='img/open.gif' STYLE='cursor:hand' onclick="ShowHead('<%=CostsNo%>')">
					<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=CostsNo%>')">
<%
				ttlTax = ttlTax + GetLong(.Fields("CostsTax"))
				ttlAmount = ttlAmount + GetLong(.Fields("CostsAmount"))
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=5 class=pt9>���v���z
					<TD colspan=2 class=line><%=formatnumber(ttlAmount+ttlTax, 0, true)%>
<%
			end if
%>
	</TABLE>
<%
			'if cnt = 1 then response.write "<script language=vbscript>call ShowDetail(" & SeqNo & ")</script>"
		else
			response.write "<br><div align=center class=pt9r>�Y���x�����쐬���Ă��������B</div>"
			response.write "<script language=vbscript>call ShowHead("""")</script>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
