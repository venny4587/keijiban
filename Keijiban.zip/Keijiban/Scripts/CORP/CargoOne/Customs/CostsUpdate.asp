<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�x���`�[���ה�p����
'----------------------------------------------

	myType = GetLong(request("type"))
	JobCode = GetPost(request("JobCode"))
	CostsNo = GetPost(request("CostsNo"))
	SeqNo = GetLong(request("SeqNo"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")	
		
	if JobCode <> "" and CostsNo <> "" then
		if CheckCostsFinished(Conn, JobCode, CostsNo) then
			JobCode = ""
			ShowMessage "�Y������x���`�[�͊��ɏ�������܂����B"
		end if
	end if
	
	if JobCode <> "" then
	
		Conn.BeginTrans
		
		mode = GetLong(request("mode"))
		select case mode
		case -1					'��p�폜

			strSql = "UPDATE TBL_CTM_EXPENSE SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID
			strSql = strSql & ",Updated = GETDATE()"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			Conn.Execute strSql
			
		case else				'��p�ۑ�
		
			if SeqNo = 0 then 
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Expense"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)				
			end if
			
			with Recset
				strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = GetPost(request("JobCode"))
					.fields("SeqNo") = SeqNo
					.fields("ExpensePay") = CostsNo					
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				
				.fields("ExpenseClient") = GetPost(request("JobShipper"))	'JobShipper�͌�����ʂ𗬗p���邽��
				.fields("ExpenseCost") = GetLong(request("ExpenseCost"))
				.fields("ExpenseType") = GetLong(request("ExpenseType"))	'���ցE����
				.fields("ExpenseAttr") = GetLong(request("ExpenseAttr"))
				.fields("ExpenseDate") = Date2Str(request("ExpenseDate"))
				.fields("ExpenseMemo") = GetPost(request("ExpenseMemo"))
				
				.fields("ExpensePrice") = GetDouble(request("ExpensePrice"))
				.fields("ExpenseQuantity") = GetDouble(request("ExpenseQuantity"))
				.fields("ExpenseUnit") = GetPost(request("ExpenseUnit"))
				.fields("ExpenseAmount") = GetLong(request("ExpenseAmount"))
				.fields("ExpenseTaxName") = GetPost(request("ExpenseTaxName"))
				.fields("ExpenseTax") = GetLong(request("ExpenseTax"))								
				.fields("Remarks") = GetPost(request("Remarks"))
					
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			
		end select
		
		'�x���`�[�X�V
		if CostsNo <> "" then 
			CostsAmount = 0
			CostsTax = 0
			with Recset
				strSql = "SELECT SUM(ExpenseAmount) AS CostsAmount, SUM(ExpenseTax) AS CostsTax FROM TBL_CTM_EXPENSE"
				strSql = strSql & " WHERE Deleted = 0 AND ExpensePay = '" & CostsNo & "'"	' AND JobCode = '" & JobCode & "'
				strSql = strSql & " AND ExpenseType IN (" & gsPayment & "," & gsStand & ")"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					CostsAmount = GetLong(.fields("CostsAmount"))
					CostsTax = GetLong(.fields("CostsTax"))
				end if
				.close
			end with
		
			strSql = "UPDATE TBL_CTM_COSTS SET CostsAmount = " &  GetLong(CostsAmount) & ", CostsTax = " &  GetLong(CostsTax)
			strSql = strSql & " WHERE Deleted = 0 AND CostsNo = '" & CostsNo & "'" 		'AND JobCode = '" & JobCode & "'
			Conn.Execute strSql
		end if
			
			
		'�������X�V(���ւ̂�)
		ChargeNo = GetPost(request("ExpenseBill"))
		if ChargeNo <> "" and GetLong(request("ExpenseType")) = gsStand then
			ChargeAmount = 0
			ChargeTax = 0
			with Recset
				strSql = "SELECT SUM(ExpenseAmount) AS ChargeAmount, SUM(ExpenseTax) AS ChargeTax FROM TBL_CTM_EXPENSE"
				strSql = strSql & " WHERE Deleted = 0 AND ExpenseBill = '" & ChargeNo & "'"	' AND JobCode = '" & JobCode & "'
				strSql = strSql & " AND ExpenseType IN (" & gsCharge & "," & gsStand & ")"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					ChargeAmount = GetLong(.fields("ChargeAmount"))
					ChargeTax = GetLong(.fields("ChargeTax"))
				end if
				.close
			end with
			
			strSql = "UPDATE TBL_CTM_CHARGE SET ChargeAmount = " &  GetLong(ChargeAmount) & ", ChargeTax = " &  GetLong(ChargeTax)
			strSql = strSql & " WHERE Deleted = 0 AND ChargeNo = '" & ChargeNo & "'"		 'AND JobCode = '" & JobCode & "'
			Conn.Execute strSql	
		end if
		
		if err.number = 0 then 
		
			Conn.CommitTrans
%>
<html>
	<script language=javascript>
		window.opener.location.href = "CostsList.asp?type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
<%	select case myType
	case 0		'���� %>
		
		if (window.opener.parent.parent.result != null) {
			window.opener.parent.parent.result.location.href = "CostsResult.asp?CostsDate=<%=request("ExpenseDate")%>";
		}
<%	case 1		'���� %>
		window.opener.parent.parent.parent.result.location.href = "CostsResult.asp?type=1";
<%	case else 	'���� %>
		if (window.opener.parent.list != null) {
			window.opener.parent.list.location.href = "CostsBill.asp?JobCode=<%=JobCode%>";
		}
		if (window.opener.parent.parent.info != null) {
			window.opener.parent.parent.info.location.href = "ExpenseInfo.asp?JobCode=<%=JobCode%>";
		}
<%	end select %>
		window.close();
	</script>
</html>
<%
		else
		
			Conn.RollbackTrans
			ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
			
		end if
		
	end if
	
	set Recset = nothing
	CloseDB Conn
%>