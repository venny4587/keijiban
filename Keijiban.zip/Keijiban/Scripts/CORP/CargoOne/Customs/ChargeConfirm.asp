<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	myMode = GetLong(request("Mode"))
	myType = GetLong(request("Type"))
	JobCode = GetPost(request("JobCode"))
	ChargeNo = GetPost(request("ChargeNo"))
	
	if JobCode = "" or ChargeNo = "" then
		ShowMessage "�Y���������݂͂���܂���ł����B"	
	else
		msg = ""
		OpenSql Conn, SqlServerName, DataBaseName	
		if myType <> gsStand then				
			msg = checkInspect()
			if msg <> "" then 
				ShowMessage msg	
			elseif myMode = 0 then
				strSql = "SELECT COST_NAME, ExpenseAmount+ExpenseTax AS COST_TTL FROM TBL_CTM_EXPENSE AS E INNER JOIN"
				strSql = strSql & " MST_COST AS C ON E.ExpenseCost = C.COST_ID WHERE Deleted = 0 AND COST_DELETED = 0"
				strSql = strSql & " AND ExpenseType = " & gsPayment & " AND JobCode = '" & JobCode & "' AND ExpenseAmount > 0"
				strSql = strSql & " AND COST_ID NOT IN (SELECT DISTINCT ExpenseCost FROM TBL_CTM_EXPENSE WHERE Deleted = 0"
				strSql = strSql & " AND ExpenseType = " & gsCharge & " AND JobCode = '" & JobCode & "')"
				Set Recset = Server.CreateObject ("ADODB.Recordset")	
				with Recset
					.Open strSql, Conn, adOpenKeyset , adLockOptimistic 
					do while not .eof
						msg = msg & vbcrlf & GetString(.fields("COST_NAME")) & ": ��" & formatnumber(GetLong(.fields("COST_TTL")), 0, true) & "�~"
						.movenext
					loop
					.Close
				end with
				Set Recset = Nothing				
			end if
		end if
		
		if msg = "" then
			strSQL = "UPDATE TBL_CTM_CHARGE SET ChargeCheck = 1"
			strSQL = strSQL & ",Updated = GETDATE()"
			strSQL = strSQL & ",Updater = " & WebUserID
			strSQL = strSQL & " WHERE JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"

			Conn.Execute strSQL
%>
<html>
<script language=javascript>
	window.parent.list.location.href = "ChargeBill.asp?JobCode=<%=JobCode%>";
	window.location.href = "ChargeHead.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>";
</script>
</html>
<%
		else
%>
<html>
<script language=vbscript>
dim rtn
	rtn = msgbox("���L�̔�ڂ𐿋����Ȃ��Ă�낵���ł����H<%=replace(msg, vbcrlf, """ & vbcrlf & """)%>", 289, "�m�F���b�Z�[�W")
	if rtn = 1 then
		window.location.href = "ChargeConfirm.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>&Type=<%=myType%>&mode=1"
	else
		window.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>&Type=<%=myType%>"
	end if
</script>
</html>
<%

		end if
		CloseDB Conn
	end if
	
function checkInspect()
dim mySql
dim myRec
dim myStr
dim myLen
dim myCheck

	checkInspect = ""
	set myRec = Server.CreateObject("adodb.recordset")
	mySql = "SELECT Inspection FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
	myRec.Open mySql,Conn,adOpenStatic,adLockReadOnly
	if not myRec.eof then myStr = GetString(myRec.fields("Inspection")) 
	myRec.Close
	
	myLen = len(myStr)
	if myLen < 1 then exit function
	
	for i = 1 to myLen
		if mid(myStr, i, 1) = "1" then
			myCheck = ""
			select case i
			case 1, 3		'������
				myCheck = " AND ExpenseCost = 13"
			case 4				
				myCheck = " AND ExpenseCost = 167"
			case 5
				myCheck = " AND ExpenseCost = 168"
			case 8
				myCheck = " AND ExpenseCost = 67 AND ExpenseMemo LIKE '%�b%' "
			end select
			if myCheck <> "" then
				mySql = "SELECT ExpenseCost FROM TBL_CTM_EXPENSE WHERE Deleted = 0"
				mySql = mySql & " AND JobCode = '" & JobCode & "'" & myCheck
				myRec.Open mySql,Conn,adOpenStatic,adLockReadOnly
				if myRec.eof then checkInspect = "�u" & ctmInspect(i) & "�v�������R��ł��B"
				myRec.Close
			end if
			if checkInspect <> "" then exit for
		end if
	next
	set myRec = nothing
end function
%>