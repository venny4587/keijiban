<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�o�b�`�Ǘ��w�b�_���
'----------------------------------------------

'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim BatchNo
dim BatchClient
dim BatchBillDay
dim BatchPayDay
dim Remarks

dim mySubmit
dim mySort
dim myCode
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	BatchNo = GetString(Request("BatchNo"))
	If BatchNo = "" Then
		blnEdit = False
		myTitle = "�o�b�`�����s"
		mySubmit = "���s"
		
		BatchNo = ""
		BatchType = GetInitJobType()
		BatchBelong = GetString(Request("BatchBelong"))
		if BatchBelong = "" then BatchBelong = UserShop
		BatchClient = ""
		BatchPic = ""
		BatchBillDay = formatDate(date)
		BatchPayDay = ""
		Remarks = ""
	Else
		blnEdit = True
		myTitle = "�o�b�`���ύX"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM TBL_CTM_BATCH WHERE BatchNo = '" & BatchNo & "'"
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			BatchNo = GetString(Recset.Fields("BatchNo"))
			BatchBelong = GetString(Recset.Fields("BatchBelong"))
			BatchType = GetString(Recset.Fields("BatchType"))
			BatchClient = GetString(Recset.Fields("BatchClient"))
			BatchPic = GetString(Recset.Fields("BatchPic"))
			BatchBillDay = Str2Date(Recset.Fields("BatchBillDay"))
			BatchPayDay = Str2Date(Recset.Fields("BatchPayDay"))
			BatchCount = GetLong(Recset.Fields("BatchCount"))
			BatchAmount = GetLong(Recset.Fields("BatchAmount"))
			Remarks = GetString(Recset.Fields("Remarks"))
			Creater = GetLong(Recset.Fields("Creater"))
			Created = GetDate(Recset.Fields("Created"))
			ConfirmerID = GetLong(Recset.Fields("ConfirmerID"))
			ConfirmDate = GetDate(Recset.Fields("ConfirmDate"))
			FinisherID = GetLong(Recset.Fields("FinisherID"))
		end if
		Recset.Close
		
		if BatchClient <> "" AND BatchPic = "" then BatchPic = GetDftManager(BatchClient)
		if GetCtmClose(BatchClient, CloseSales, CloseStand, CloseCosts) then
			CostsClose = ShowClose(CloseCosts)
		end if
		if GetCtmSight(BatchClient, CostsSales, CostsStand, CostsCosts) then
			CostsSight = ctmCredit(CostsCosts \ 1000) & ShowPayDay(CostsCosts mod 1000)
		end if
	End If
	
	myLevel = CheckUserLevel(UserShop, "")
%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="javascript" src="../common/css/calendar_JP.js"></SCRIPT> 
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
		<SCRIPT LANGUAGE=vbscript>					
			sub InitForm()
<%if BatchNo = "" then %>
				frmInput.ChargeRef.focus()
<%else%>
				frmInput.BatchBillDay.focus()
<%end if%>
<%if ConfirmerID <> 0 and myLevel < 3 then%>
				Call LockAll()
<%end if%>
			end sub
			
			sub ShowList(cd)
				window.parent.input.cbody.location.href = "CostsBatch.asp?p=<%=myPage%>&s=<%=mySort%>&BatchNo=<%=BatchNo%>&BatchBelong=" & cd 
			end sub	
			
			sub DoSearch()
				dim win
				set win = window.open("ChargerSearch.asp?cd=" & frmInput.ChargeRef.value,"ChargerSearch","resizable=1,scrollbars=1,width=800,height=600")
			end sub	
			
			Sub DoSubmit()
				if checkCode("ChargeClient","�x����", 1) = false then exit sub
				if checkText("ChargeName","�x���於��", 1) = false then exit sub
				if checkText("BatchPic","����S����", 1) = false then exit sub
				if checkDate("BatchBillDay","�x�����ߓ�", 1) = false then exit sub
				if checkDate("BatchPayDay","�x���\���", 1) = false then exit sub
				if checkText("Remarks","�o�b�`�����l", 0) = false then exit sub
				if checkLen("Remarks","�o�b�`�����l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub BatchBillDay_Onblur()
				frmInput.BatchBillDay.value = setdate(frmInput.BatchBillDay.value)
			end sub		
			sub BatchPayDay_Onblur()
				frmInput.BatchPayDay.value = setdate(frmInput.BatchPayDay.value)
			end sub
		</SCRIPT>
	</HEAD>
	<BODY onload="InitForm()" class=pt9 <%=gsBodyControl%>>
		<TABLE width=100% class=pt9n>
			<TR>
				<!----------left---------->
				<TD width=100% VALIGN=TOP>
					<p><br>
					<table width=250 class=pt9b>
						<tr align=center><td width=70 onmousedown="ShowList('K')" style="cursor:hand">�_�˖{��
						<td width=20><br><td width=70 onmousedown="ShowList('O')" style="cursor:hand">���x�X
						<td width=20><br><td width=70 onmousedown="ShowList('T')" style="cursor:hand">�����x�X
					</table>
					<FORM METHOD="POST" ACTION="CostsBatch1.asp" ID=frmInput NAME=frmInput>
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD nowrap class=pt9g>�o�b�`��
								<TD><INPUT class=si NAME="BatchNo" MAXLENGTH=6 SIZE=6 VALUE="<%=BatchNo%>" OnKeyDown="ResetEnter()" readonly>
<%if BatchNo = "" then%>
								�@	&nbsp;�戵
									<SELECT name="BatchBelong" onkeydown="ResetEnter()"><%=ShowShopList(BatchBelong)%></select>
<%else%>
									<font class=pt9g>&nbsp;�戵�敪</font>
									<input class=si name="BatchBelong" size=8 maxlength=10 value=" <%=GetShopName(BatchBelong)%>" onkeydown="ResetEnter()" readonly>
<%end if%>
<%if BatchNo = "" then%>
							<TR><TD>�x����<input type=hidden name="ChargeClient" value="<%=BatchClient%>">
								<TD><input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(BatchClient)%>" onkeydown="ResetEnter()">
									<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a>
								�@	�敪&nbsp;<SELECT name="BatchType" onkeydown="ResetEnter()"><option value="Z">����<%=ShowJobType(BatchType)%></select>
<%else%>
							<TR><TD>�x����<input type=hidden name="ChargeClient" value="<%=BatchClient%>">
								<TD><input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(BatchClient)%>" onkeydown="ResetEnter()" readonly>
									<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a>
									<font class=pt9g>����</font>
									<input class=si name="BatchType" size=8 maxlength=10 value=" <%=GetJobDivision(BatchType)%>" onkeydown="ResetEnter()" readonly>
<%end if%>
							<TR><TD colspan=2><input class=sj name="ChargeName" size=38 maxlength=50 value="<%=GetFullName(BatchClient)%>" onkeydown="ResetEnter()" readonly>	
							<TR><TD colspan=2 class=pt9g>
								�x������ <input class=si size=8 name="CostsClose" value="<%=CostsClose%>" onkeydown="ResetEnter()" readonly>
								�x����� <input class=si size=10 name="CostsSight" value="<%=CostsSight%>" onkeydown="ResetEnter()" readonly>
						  	<TR height=28><TD>����S��
								<TD><input class=sj name="ChargePic" size=20 maxlength=50 value="<%=BatchPic%>" onkeydown="ResetEnter()">		
							<TR height=28><TD nowrap>�x������
								<TD class=pt9r><INPUT class=si NAME="BatchBillDay" MAXLENGTH=10 SIZE=10 VALUE="<%=BatchBillDay%>" onclick="setday(this)" OnKeyDown="ResetEnter()">
						�@�@�@�@<%if FinisherID <> 0 then%>�����ς�<%elseif ConfirmerID <> 0 then%>�m��ς�<%end if%>
							<TR height=28><TD nowrap>�x���\��
								<TD><INPUT class=si NAME="BatchPayDay" MAXLENGTH=10 SIZE=10 VALUE="<%=BatchPayDay%>" onclick="setday(this)" OnKeyDown="ResetEnter()">
							<TR height=28 class=pt9g><TD nowrap>�x�����z
								<TD><INPUT class=sn NAME="BatchAmount" MAXLENGTH=10 SIZE=10 VALUE="<%=formatnumber(BatchAmount, 0, true)%>" OnKeyDown="ResetEnter()" readonly>
							�@�@�����@<INPUT class=sn NAME="BatchCount" MAXLENGTH=5 SIZE=5 VALUE="<%=formatnumber(BatchCount, 0, true)%>" OnKeyDown="ResetEnter()" readonly>
							<TR height=28><TD nowrap class=pt9>���l
								<TD><textarea NAME="Remarks" style="width:150px;height:50px;"><%=Remarks%></textarea>
							<TR><TD colspan=2 nowrap class=pt9g>
								�쐬���@<input class=si size=10 name="Created" value="<%=formatDate(Created)%>" onkeydown="ResetEnter()" readonly>
							�@	�쐬�ҁ@<input class=si size=8 name="Creater" value=" <%=GetEmployName(Creater, "F")%>" onkeydown="ResetEnter()" readonly>
							<TR><TD colspan=2 nowrap class=pt9g>
								�m����@<input class=si size=10 name="Created" value="<%=formatDate(ConfirmDate)%>" onkeydown="ResetEnter()" readonly>
							�@	�m��ҁ@<input class=si size=8 name="Creater" value=" <%=GetEmployName(ConfirmerID, "F")%>" onkeydown="ResetEnter()" readonly>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="���Z�b�g">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
