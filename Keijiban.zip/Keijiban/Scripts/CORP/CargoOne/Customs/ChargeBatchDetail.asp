<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�o�b�`�Ǘ��w�b�_���
'----------------------------------------------

'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim BatchNo
dim BatchClient
dim BatchBillDay
dim BatchPayDay
dim Remarks

dim mySubmit
dim mySort
dim myCode
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "en"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	BatchNo = GetString(Request("BatchNo"))
	If BatchNo = "" Then
		blnEdit = False
		myTitle = "�o�b�`�����s"
		mySubmit = "���s"
		
		BatchNo = ""
		BatchClient = ""
		BatchPic = ""
		BatchType = GetInitJobType()
		BatchBelong = GetString(Request("BatchBelong"))
		BatchBillDay = formatDate(date)
		BatchPayDay = ""
		Remarks = ""
	Else
		blnEdit = True
		myTitle = "�o�b�`���ύX"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM TBL_CTM_BATCH WHERE BatchNo = '" & BatchNo & "'"
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			BatchNo = GetString(Recset.Fields("BatchNo"))
			BatchClient = GetString(Recset.Fields("BatchClient"))
			BatchPic = GetString(Recset.Fields("BatchPic"))
			BatchBelong = GetString(Recset.Fields("BatchBelong"))
			BatchType = GetString(Recset.Fields("BatchType"))
			BatchBillDay = Str2Date(Recset.Fields("BatchBillDay"))
			BatchPayDay = Str2Date(Recset.Fields("BatchPayDay"))
			BatchCount = GetLong(Recset.Fields("BatchCount"))
			BatchAmount = GetLong(Recset.Fields("BatchAmount"))
			Remarks = GetString(Recset.Fields("Remarks"))
			Creater = GetLong(Recset.Fields("Creater"))
			Created = GetDate(Recset.Fields("Created"))
			ConfirmerID = GetLong(Recset.Fields("ConfirmerID"))
			ConfirmDate = GetDate(Recset.Fields("ConfirmDate"))
			FinisherID = GetLong(Recset.Fields("FinisherID"))
		end if
		Recset.Close
	
		if BatchClient <> "" AND BatchPic = "" then BatchPic = GetDftManager(BatchClient)
		if GetCtmClose(BatchClient, CloseSales, CloseStand, CloseCosts) then
			SalesClose = ShowClose(CloseSales)
		end if
		if GetCtmSight(BatchClient, SightSales, SightStand, SightCosts) then
			SalesSight = ctmCredit(fix(SightSales / 1000)) & ShowPayDay(SightSales mod 1000)
		end if
	End If

	myLevel = CheckUserLevel(UserShop, "")
%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="javascript" src="../common/css/calendar_JP.js"></SCRIPT> 
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
		<SCRIPT LANGUAGE=vbscript>
			sub DoSearch()
				dim win
				set win = window.open("ChargerSearch.asp?cd=" & frmInput.ChargeRef.value,"ChargerSearch","resizable=1,scrollbars=1,width=800,height=600")
			end sub	
			
			sub ShowList(cd)
				window.parent.search.cbody.location.href = "ChargeBatch.asp?p=<%=myPage%>&s=<%=mySort%>&BatchNo=<%=BatchNo%>&BatchBelong=" & cd 
			end sub	
											
			Sub DoSubmit()
				if checkCode("ChargeClient","������", 1) = false then exit sub
				if checkText("ChargeName","�����於��", 1) = false then exit sub
				if checkText("BatchPic","����S����", 1) = false then exit sub
				if checkDate("BatchBillDay","������", 1) = false then exit sub
				if checkDate("BatchPayDay","�����\���", 1) = false then exit sub
				if checkText("Remarks","�o�b�`�����l", 0) = false then exit sub
				if checkLen("Remarks","�o�b�`�����l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub		
						
			sub InitForm()
<%if BatchNo <> "" then %>
				frmInput.BatchBillDay.focus()
<%end if%>
<%if ConfirmerID <> 0 and myLevel < 3 then%>
				Call LockAll()
<%end if%>
			end sub
			
			sub BatchBillDay_Onblur()
				frmInput.BatchBillDay.value = setdate(frmInput.BatchBillDay.value)
			end sub		
			sub BatchPayDay_Onblur()
				frmInput.BatchPayDay.value = setdate(frmInput.BatchPayDay.value)
			end sub
		</SCRIPT>
	</HEAD>
	<BODY onload="InitForm()" class=pt9 <%=gsBodyControl%>>
		<TABLE width=100% class=pt9n>
			<TR>
				<!----------left---------->
				<TD width=100% VALIGN=TOP>
					<p><br>
					<table width=250 class=pt9b>
						<tr align=center><td width=70 onmousedown="ShowList('K')" style="cursor:hand">�_�˖{��
						<td width=20><br><td width=70 onmousedown="ShowList('O')" style="cursor:hand">���x�X
						<td width=20><br><td width=70 onmousedown="ShowList('T')" style="cursor:hand">�����x�X
					</table>
					<FORM METHOD="POST" ACTION="ChargeBatch1.asp" ID=frmInput NAME=frmInput>
<%if BatchNo <> "" then%>
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD nowrap class=pt9g>�����
								<TD><INPUT class=si NAME="BatchNo" MAXLENGTH=6 SIZE=6 VALUE="<%=BatchNo%>" OnKeyDown="ResetEnter()" readonly>
								<TD><font class=pt9g>�戵�敪</font>
									<input class=si name="BatchBelong" size=8 maxlength=10 value=" <%=GetShopName(BatchBelong)%>" onkeydown="ResetEnter()" readonly>
							<TR><TD nowrap>������<input type=hidden name="ChargeClient" value="<%=BatchClient%>">
<%if BatchNo = "" then%>
								<TD><input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(BatchClient)%>" onkeydown="ResetEnter()">
									<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a>
<%else%>
								<TD><input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(BatchClient)%>" onkeydown="ResetEnter()" readonly>
								<TD><font class=pt9g>����</font>
									<input class=si name="BatchType" size=8 maxlength=10 value=" <%=GetJobDivision(BatchType)%>" onkeydown="ResetEnter()" readonly>
<%end if%>
							<TR><TD colspan=3><input class=sj name="ChargeName" size=32 maxlength=50 value="<%=GetFullName(BatchClient)%>" onkeydown="ResetEnter()" readonly>	
							<TR><TD colspan=3 nowrap class=pt9g>
								������ <input class=si size=8 name="SalesClose" value="<%=SalesClose%>" onkeydown="ResetEnter()" readonly>
								���� <input class=si size=10 name="SalesSight" value="<%=SalesSight%>" onkeydown="ResetEnter()" readonly>
						  	<TR height=28><TD>����S��
								<TD colspan=2><input class=sj name="ChargePic" size=20 maxlength=50 value="<%=BatchPic%>" onkeydown="ResetEnter()">		
							<TR height=28><TD nowrap>������
								<TD><INPUT class=si NAME="BatchBillDay" MAXLENGTH=10 SIZE=10 VALUE="<%=BatchBillDay%>" OnKeyDown="ResetEnter()" 
								<%if ConfirmerID = 0 then%>onclick="setday(this)"<%end if%>>
								<TD rowspan=2 class=pt9r align=center><%if FinisherID <> 0 then%>�����ς�<%else%>���t�ς�
									<%if ConfirmerID = 0 or CheckUserLevel(BatchBelong, "") > 2 then%><input type=checkbox name="Delivered" value="1" 
									<%if ConfirmerID <> 0 then response.write "checked"%>><%end if%><%end if%>
							<TR height=28><TD nowrap>�����\��
								<TD><INPUT class=si NAME="BatchPayDay" MAXLENGTH=10 SIZE=10 VALUE="<%=BatchPayDay%>" OnKeyDown="ResetEnter()" 
								<%if ConfirmerID = 0 then%>onclick="setday(this)"<%end if%>>
							<TR height=28 class=pt9g><TD nowrap>�������z
								<TD><INPUT class=sn NAME="BatchAmount" MAXLENGTH=10 SIZE=10 VALUE="<%=formatnumber(BatchAmount, 0, true)%>" OnKeyDown="ResetEnter()" readonly>
								<TD align=center>����<INPUT class=sn NAME="BatchCount" MAXLENGTH=5 SIZE=5 VALUE="<%=formatnumber(BatchCount, 0, true)%>" OnKeyDown="ResetEnter()" readonly>
							<TR height=28><TD nowrap class=pt9>���l
								<TD colspan=2><textarea NAME="Remarks" style="width:150px;height:50px;"><%=Remarks%></textarea>
<%if CheckUserLevel(UserShop, "") > 1 then %>
							<TR><TD colspan=3 nowrap class=pt9g>
								�쐬��<input class=si size=10 name="Created" value="<%=formatDate(Created)%>" onkeydown="ResetEnter()" readonly>
								�쐬��<input class=si size=8 name="Creater" value=" <%=GetEmployName(Creater, "F")%>" onkeydown="ResetEnter()" readonly>
							<TR><TD colspan=3 nowrap class=pt9g>
								�m���<input class=si size=10 name="Created" value="<%=formatDate(ConfirmDate)%>" onkeydown="ResetEnter()" readonly>
								�m���<input class=si size=8 name="Creater" value=" <%=GetEmployName(ConfirmerID, "F")%>" onkeydown="ResetEnter()" readonly>
<%end if%>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="���Z�b�g">
<%end if%>
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
