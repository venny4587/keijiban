<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�q�ʎc���ꗗ�Ɖ���
'----------------------------------------------
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobType = GetPost(request("JobType"))
	JobBelong = GetPost(request("JobBelong"))
	JobSalesman = GetLong(request("JobSalesman"))
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 4  then JobBelong = UserShop
	
	mySort = GetLong(request("sort"))
	if mySort = 0 then mySort = 1
	
	SelName = GetString(request("SelName"))
	if SelName = "" then SelName = "jp"
	
	SelYear = GetLong(request("SelYear"))
	SelMonth = GetLong(request("SelMonth"))
	if SelYear = 0 or SelMonth = 0 then
		SelDate = date
		if day(SelDate) <= 31 then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
		if myLevel < 4  then JobSalesman = WebUserID
	end if	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
	Osaka = GetLong(request("Osaka"))
%>

<HTML>
<HEAD>
	<TITLE>�q�ʎc���ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		sub DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.Submit()
		end sub
			
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ReportBenefit.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="AccountMonth" VALUE='<%=AccountMonth%>'>
		<input type=hidden name="sort" value="<%=mySort%>">
		<table class=pt9>
			<TR><TD nowrap>�Ɩ�����
<%if myLevel > 3 then%>
	  				<select name=JobBelong onkeydown="ResetEnter()"><option value="">�S��<%=ShowShopList(JobBelong)%></select>&nbsp;
<%else%>
					<input type=hidden name="JobBelong" value="<%=JobBelong%>">
					<u>&nbsp;<font color=green><%=GetShopName(JobBelong)%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�c�ƒS��
<%if myLevel > 1 then%>
					<select name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
						<%=ShowEmployList(DepartSales, JobSalesman)%>
					</select>&nbsp;
<%else%>
					<input type=hidden name="JobSalesman" value="<%=JobSalesman%>">
					<u>&nbsp;<font color=green><%=GetEmployName(JobSalesman, "F")%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�Ɩ��敪
					<select name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>&nbsp;
				<TD nowrap>�׎喼��
					<select name="SelName" onkeydown="ResetEnter()">
						<option value="jp" <%if SelName = "jp" then response.write "selected"%>>�a������
						<option value="en" <%if SelName = "en" then response.write "selected"%>>�p������
						<option value="ref" <%if SelName = "ref" then response.write "selected"%>>��������
						<option value="abr" <%if SelName = "abr" then response.write "selected"%>>�a������
					</select>&nbsp;
				<TD nowrap>�Ώ۔N��
					<select name="SelYear" onkeydown="ResetEnter()"><%
						for i = year(date) to year(gsSysStart) step -1
							response.write "<option value=" & i
							if i = SelYear then response.write " selected"
							response.write ">" & i
						next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
						for i = 1 to 12
							response.write "<option value=" & i
							if i = SelMonth then response.write " selected"
							response.write ">" & i
						next%></select>&nbsp;��&nbsp;
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
					<input type=checkbox name="Osaka" value="1" <%if Osaka then response.write "checked"%>>���̂�
		</table>
	</form>
<div id=list>
�Ώ۔N���F<%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup align=right>
		<colgroup span=3 align=left>
		<colgroup span=2
		 align=center>
		<colgroup span=7 align=right>
		<TR style="cursor:hand;">
			<TD>��
<%select case SelName%>
<%case "jp"%><TD onmousedown="DoSort(1)" <%if mySort=1 then%>style="color:blue"<%end if%>>�a������
<%case "en"%><TD onmousedown="DoSort(2)" <%if mySort=2 then%>style="color:blue"<%end if%>>�p������
<%case "ref"%><TD onmousedown="DoSort(3)" <%if mySort=3 then%>style="color:blue"<%end if%>>��������
<%case "abr"%><TD onmousedown="DoSort(4)" <%if mySort=4 then%>style="color:blue"<%end if%>>�a������
<%end select%>
			<TD onmousedown="DoSort(14)" <%if mySort=14 then%>style="color:blue"<%end if%>>����
			<TD onmousedown="DoSort(15)" <%if mySort=15 then%>style="color:blue"<%end if%>>����
			<TD onmousedown="DoSort(16)" <%if mySort=16 then%>style="color:blue"<%end if%> nowrap>���֌�
			<TD onmousedown="DoSort(5)" <%if mySort=5 then%>style="color:blue"<%end if%>>����
			<TD onmousedown="DoSort(6)" <%if mySort=6 then%>style="color:blue"<%end if%>>���֋��z
			<TD onmousedown="DoSort(7)" <%if mySort=7 then%>style="color:blue"<%end if%>>�������z
			<TD onmousedown="DoSort(8)" <%if mySort=8 then%>style="color:blue"<%end if%>>�x�����z
			<TD onmousedown="DoSort(9)" <%if mySort=9 then%>style="color:blue"<%end if%>>�e��
			<TD onmousedown="DoSort(10)" <%if mySort=10 then%>style="color:blue"<%end if%>>�e����
			<TD onmousedown="DoSort(11)" <%if mySort=11 then%>style="color:blue"<%end if%>>�֐�
			<TD onmousedown="DoSort(12)" <%if mySort=12 then%>style="color:blue"<%end if%>>�Ί֐�<br>�e����
		
<%
	cnt = 0
	with recset
		strSql = "SELECT J.*, ISNULL(CTM_REF, '') AS ref, ISNULL(CTM_NAME, '') AS jp, ISNULL(CTM_ENAME, '') AS en, ISNULL(CTM_ABR, '') AS abr, CTM_TYPE"
		strSql = strSql & ", CTM_SALES_CLOSE, CTM_SALES_CREDIT, CTM_SALES_PAYDAY, CTM_STAND_CLOSE, CTM_STAND_CREDIT, CTM_STAND_PAYDAY, CTM_STAND_LIMIT"
		strSql = strSql & " FROM (SELECT CTM_FINANCE_CD, COUNT(JobCode) AS Total, SUM(SalesSum+SalesTax) AS Sales, SUM(StandSum) AS Stand"
		strSql = strSql & ", SUM(CostsSum+CostsTax) AS Costs, SUM(Interests) AS Benefit, SUM(ISNULL(Kanzei, 0)) AS Duty"
		strSql = strSql & ", CASE SUM(ISNULL(Kanzei, 0)) WHEN 0 THEN 0 ELSE (SUM(Interests) * 100 / SUM(ISNULL(Kanzei, 0))) END AS DutyRate"
		strSql = strSql & ", CASE SUM(SalesSum+SalesTax) WHEN 0 THEN 0 ELSE (SUM(Interests) * 100 / SUM(SalesSum+SalesTax)) END AS Rate"
		strSql = strSql & " FROM TBL_CTM_JOB INNER JOIN CUSTOMER ON TBL_CTM_JOB.JobClient = CUSTOMER.CTM_CD "
		strSql = strSql & " LEFT JOIN (SELECT Jobcode AS CD, SUM(ExpenseAmount) AS Kanzei FROM TBL_CTM_EXPENSE WHERE Deleted = 0"
		strSql = strSql & " AND ExpenseCost IN (72, 73, 74) GROUP BY JobCode) AS C ON TBL_CTM_JOB.Jobcode = C.CD"
		strSql = strSql & " WHERE Deleted = 0 AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if JobBelong <> "" then strSql = strSql & " AND JobBelong = '" & JobBelong & "'"
		if JobType <> "" then strSql = strSql & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if JobSalesman <> 0 then strSql = strSql & " AND JobSalesman = " & JobSalesman
		if Osaka <> 0 then strSql = strSql & " AND (POL = 'OSAKA' OR POD = 'OSAKA')"
		if JobBelong = "" then strSql = strSql & " AND SUBSTRING(JobCode,1,1) <> '" & gsSokoInit & "'"
		strSql = strSql & " GROUP BY CTM_FINANCE_CD) AS J INNER JOIN (SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_ENAME, CTM_ABR, CTM_TYPE"
		strSql = strSql & " FROM CUSTOMER) AS C ON J.CTM_FINANCE_CD = C.CTM_CD LEFT JOIN ("
		strSql = strSql & " SELECT CTM_CD, CTM_SALES_CLOSE, CTM_SALES_CREDIT, CTM_SALES_PAYDAY, CTM_STAND_CLOSE, CTM_STAND_CREDIT, CTM_STAND_PAYDAY, CTM_STAND_LIMIT"
		strSql = strSql & " FROM CTM_CONTACT WHERE CONTACT_PAST = 0) AS T ON J.CTM_FINANCE_CD = T.CTM_CD"
		select case mySort
		case 1:		strSql = strSql & " ORDER BY jp"
		case 2:		strSql = strSql & " ORDER BY en"
		case 3:		strSql = strSql & " ORDER BY ref"
		case 4:		strSql = strSql & " ORDER BY abr"
		case 5:		strSql = strSql & " ORDER BY Total DESC"
		case 6:		strSql = strSql & " ORDER BY Stand DESC"
		case 7:		strSql = strSql & " ORDER BY Sales DESC"
		case 8:		strSql = strSql & " ORDER BY Costs DESC"
		case 9:		strSql = strSql & " ORDER BY Benefit DESC"
		case 10:	strSql = strSql & " ORDER BY Rate DESC"
		case 11:	strSql = strSql & " ORDER BY Duty DESC"
		case 12:	strSql = strSql & " ORDER BY DutyRate DESC"
		case 14:	strSql = strSql & " ORDER BY CTM_SALES_CLOSE, CTM_SALES_CREDIT, CTM_SALES_PAYDAY"
		case 15:	strSql = strSql & " ORDER BY CTM_STAND_CLOSE, CTM_STAND_CREDIT, CTM_STAND_PAYDAY"
		case 16:	strSql = strSql & " ORDER BY CTM_STAND_LIMIT DESC"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		sumCount = 0
		sumSales = 0
		sumCosts = 0
		sumStand = 0
		sumDuty = 0
		do while not .EOF
			cnt = cnt + 1
			myName = ResetCorpName(.fields(SelName))
			if GetLong(.Fields("Benefit")) < 0 then
				myColor = "red"
			else
				myColor = "black"
			end if
%>
		<TR style="color:<%=myColor%>">
			<TD><%=cnt%>
			<TD nowrap title="<%=.fields("CTM_FINANCE_CD")%>"><%=myName%>
			<TD nowrap><%=ShowClose(.Fields("CTM_SALES_CLOSE"))%>�@<%=ctmCredit(GetLong(.Fields("CTM_SALES_CREDIT"))) & ShowPayDay(.Fields("CTM_SALES_PAYDAY"))%>��
<%if GetLong(.fields("CTM_TYPE")) = 0 then%>
			<TD nowrap><br>
<%else%>
			<TD nowrap><%=ShowClose(.Fields("CTM_STAND_CLOSE"))%>�@<%=ctmCredit(GetLong(.Fields("CTM_STAND_CREDIT"))) & ShowPayDay(.Fields("CTM_STAND_PAYDAY"))%>��
<%end if%>
			<TD><%=formatnumber(GetLong(.Fields("CTM_STAND_LIMIT")), 0, true)%>��
			<TD><%=formatnumber(GetLong(.Fields("Total")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("Stand")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("Sales")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("Costs")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("Benefit")), 0, true)%>
			<TD><%=formatnumber(GetDouble(.Fields("Rate")), 2, true)%>%
			<TD><%=formatnumber(GetLong(.Fields("Duty")), 0, true)%>
			<TD><%=formatnumber(GetDouble(.Fields("DutyRate")), 2, true)%>%
<%
			sumCount = sumCount + GetLong(.Fields("Total"))
			sumStand = sumStand + GetLong(.Fields("Stand"))
			sumSales = sumSales + GetLong(.Fields("Sales"))
			sumCosts = sumCosts + GetLong(.Fields("Costs"))
			sumDuty = sumDuty + GetLong(.Fields("Duty"))
			.movenext
		loop
		.Close
	end with
	if cnt > 0 then
		sumRate = 0:	sumDutyRate = 0
		sumInterest = sumSales - sumCosts
		if sumSales <> 0 then sumRate = sumInterest * 100 / sumSales
		if sumDuty <> 0 then sumDutyRate = sumInterest * 100 / sumDuty
		
%>
		<TR>
			<TD colspan=5 align=center>���@�v
			<TD nowrap><%=formatnumber(sumCount, 0, true)%>
			<TD nowrap><%=formatnumber(sumStand, 0, true)%>
			<TD nowrap><%=formatnumber(sumSales, 0, true)%>
			<TD nowrap><%=formatnumber(sumCosts, 0, true)%>
			<TD nowrap><%=formatnumber(sumInterest, 0, true)%>
			<TD nowrap><%=formatnumber(sumRate, 2, true)%>%
			<TD nowrap><%=formatnumber(sumDuty, 0, true)%>
			<TD nowrap><%=formatnumber(sumDutyRate, 2, true)%>%
<%end if%>
	</TABLE>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>