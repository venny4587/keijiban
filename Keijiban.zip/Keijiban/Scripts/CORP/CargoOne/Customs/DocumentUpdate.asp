<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	JobCode = GetPost(request("JobCode"))
	SeqNo = GetLong(request("SeqNo"))
		
	if JobCode <> "" then
	
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset")	
		
		mode = GetLong(request("mode"))
		select case mode
		
		case -1

			strSql = "UPDATE TBL_CTM_DOCUMENT SET Deleted = 1"
			strSql = strSql & ",Updater = " & WebUserID 
			strSql = strSql & ",Updated = GETDATE()" 
			strSql = strSql & " WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			Conn.Execute strSql
						
		case else
			
			if SeqNo = 0 then 
				Set cmdSQL = Server.CreateObject("ADODB.Command")
				Set cmdSQL.ActiveConnection = Conn
				cmdSQL.CommandType = 4
				cmdSQL.CommandText = "DB_CTM_NEW_SUB"
				cmdSQL.Parameters.Refresh
				cmdSQL.Parameters("@SubCode").Value = "Document"
				cmdSQL.Execute
				SeqNo = GetLong(cmdSQL.Parameters("@CurrentID").Value)
			end if
			
			with Recset
				strSql = "SELECT * FROM TBL_CTM_DOCUMENT WHERE Deleted = 0"
				strSql = strSql & " AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("JobCode") = JobCode
					.fields("SeqNo") = SeqNo
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
				end if
				.fields("DocumentType") = GetPost(request("DocumentType"))
				.fields("DocumentTitle") = GetPost(request("DocumentTitle"))
				.fields("ObtainDate") = Date2Str(request("ObtainDate"))
				.fields("ObtainTime") = GetPost(request("ObtainTime"))
				.fields("ObtainMemo") = GetPost(request("ObtainMemo"))
				.fields("SendDate") = Date2Str(request("SendDate"))
				.fields("SendTime") = GetPost(request("SendTime"))
				.fields("SendMemo") = GetPost(request("SendMemo"))
				.fields("FetchDate") = Date2Str(request("FetchDate"))
				.fields("FetchTime") = GetPost(request("FetchTime"))
				.fields("FetchMemo") = GetPost(request("FetchMemo"))
				.fields("ReturnDate") = Date2Str(request("ReturnDate"))
				.fields("ReturnTime") = GetPost(request("ReturnTime"))
				.fields("ReturnMemo") = GetPost(request("ReturnMemo"))
				.fields("Remarks") = GetPost(request("Remarks"))
				
				if mode = 2 then
					.fields("FinisherID") = WebUserID
					.fields("FinishDate") = now
				else
					.fields("FinisherID") = 0
					.fields("FinishDate") = Null
				end if
				
				.fields("Updater") = WebUserID
				.fields("Updated") = now
				.update
				.close
			end with
			
if false then
			'�̎����[�t�ς݊m�F
			if GetPost(request("DocumentType")) = gsReceipt and Date2Str(request("ReturnDate")) <> "" then					
				strSql = "UPDATE TBL_CTM_JOB SET ReturnDate = '" & Date2Str(request("ReturnDate")) & "'"
				strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
				Conn.Execute strSql
			end if
end if
			
		end select
		
		set Recset = nothing
		CloseDB Conn
%>
<html>
<script language=javascript>
<%if GetLong(request("step")) <> 0 then%>
	if (window.opener.frmInput != null) window.opener.frmInput.submit();
<%elseif GetLong(request("type")) <> 0 then%>
	window.opener.location.href = "DocumentResult.asp?type=<%=request("type")%>";
<%else%>
	window.opener.location.href = "DocumentList.asp?JobCode=<%=JobCode%>";
<%end if%>
	window.close();
</script>
</html>
<%
	end if
%>