<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next

	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	BatchNo = session("CTM_CostsBatch")
	With RecSet
		strSql = "SELECT CTM_ABR FROM TBL_CTM_BATCH AS B INNER JOIN CUSTOMER AS C ON B.BatchClient = C.CTM_CD"
		strSql = strSql & " WHERE B.BatchNo = '" & BatchNo & "'" 
		.Open strSql, conn, adOpenStatic, adLockReadOnly
		if not .eof then BatchClientName = GetString(.fields("CTM_ABR"))
		.Close
	end with
	
	mySort = GetLong(request("sort"))
	mode = GetLong(request("mode"))
	if mode <> 0 then
		
		cnt = GetLong(request("cnt"))
		if cnt > 0 then
			Conn.BeginTrans
			
			for i = 1 to cnt
				CostsNo = GetPost(request("no" & i))
				OldNo = GetPost(request("old" & i))
				NewNo = GetPost(request("new" & i))
				if OldNo <> NewNo then
					strSql = "UPDATE TBL_CTM_COSTS SET CostsBillNo = '" & NewNo & "'"
					strSql = strSql & " WHERE CostsBatch = '" & BatchNo & "'"
					strSql = strSql & " AND CostsNo = '" & CostsNo & "'"
					Conn.Execute strSql
				end if
				if err.number <> 0 then exit for
			next
			
			if err.number = 0 then
				Conn.CommitTrans
%>
<html>
<SCRIPT language=javascript>
window.opener.location.href = "CostsResult.asp?type=1&sort=4";
window.close();
</script>
</html>
<%
				
			else
				Conn.RollbackTrans
				msg = "�o�b�`���������L�̃G���[���N����܂����B" & vbcrlf & err.number & ":" & err.description
			end if
		end if
	end if
	
%>
<HTML>
<HEAD>
	<TITLE>�x���`�[�������ꊇ�ҏW</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>
		function DataSave()
			if msgbox ("���������X�V���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.btnProc.disabled = True
			frmInput.submit()
		end function 
		
		function DoSort(myNo)
			window.location.href = "CostsBatchModify.asp?BatchNo=<%=BatchNo%>&sort=" & myNo
		end function
		
		function ShowDetail(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=2&JobCode=" & myJob & "&CostsNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		sub DoShortCut()
			if window.event.keyCode=120 then call DataSave() 
			if window.event.keyCode=27 then window.close()
		end sub
	</SCRIPT>
</HEAD>
<BODY onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <form name=frmInput method="post" action="CostsBatchModify.asp">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td nowrap width=30%>�����萿�����ҏW
	  	  <td nowrap width=40% class=pt9g>�ޯ����F<%=BatchNo%>�@�x����F<%=BatchClientName%>
	  	  <td nowrap width=30% align=right><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT JobCode, CostsType, CostsNo, CostsBillNo, CostsBatch, CostsAmount, CostsTax, CostsDate"
		strSql = strSql & ", FinisherID FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsBatch = '" & BatchNo & "'"
		select case mySort
		case 0:		strSql = strSql & " ORDER BY CostsBillNo, CostsNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, CostsNo"
		case 2:		strSql = strSql & " ORDER BY CostsDate, CostsNo"
		case 3:		strSql = strSql & " ORDER BY (CostsAmount+CostsTax), CostsNo"
		case 4:		strSql = strSql & " ORDER BY CostsNo"
		end select
if WebUserID = gsAdmin then response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=96% Cellspacing=3 CellPadding=3 class=pt9n>
		<colgroup span=5 align=center>
		<colgroup align=right>
		<colgroup span=2 align=center>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>��
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">���臂
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�퐿����
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x�����z
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�`�[�ԍ�
		<TD class=line nowrap>�m��
<%
			cnt = 0
			ttlCount = 0
			ttlAmount = 0:	ttlTax = 0:	ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode"))
				CostsNo = GetString(.Fields("CostsNo"))
				CostsBillNo = GetString(.Fields("CostsBillNo"))
				myAmount = GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax"))
				if GetLong(.Fields("FinisherID")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=gray>��</font>"
				end if
%>
				<TR height=20>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=JobCode%>','<%=CostsNo%>')"><%=cnt%>
					<TD class=line><%=ShowCostsType(.Fields("CostsType"))%><BR>
					<TD class=line><input class=sn name="new<%=cnt%>" value="<%=CostsBillNo%>" maxlength=30 size=14 onkeydown="ResetEnter()">
					<TD class=line><%=ShowJobCode(JobCode)%><BR>
					<TD class=line style="color:green"><%=Str2Date(.Fields("CostsDate"))%><BR>
					<TD class=line><%=formatnumber(myAmount, 0, true)%><BR>
					<TD class=line><%=ShowVoucherNo(CostsNo)%><BR>
					<TD class=line><%=status%><input type=hidden name="no<%=cnt%>" value="<%=CostsNo%>">
						<input type=hidden name="old<%=cnt%>" value="<%=CostsBillNo%>">
<%
				if GetLong(.Fields("CostsTax")) = 0 then 
					ttlTaxFree = ttlTaxFree + GetLong(.Fields("CostsAmount")) 
				else
					ttlTax = ttlTax + GetLong(.Fields("CostsTax"))
					ttlAmount = ttlAmount + GetLong(.Fields("CostsAmount"))
				end if
				.movenext
			loop
			if cnt > 1 then
%>
				<TR height=20>
					<TD colspan=5 align=right class=pt9>�Ŕ����z
					<TD class=line align=right><%=formatnumber(ttlAmount + ttlTaxFree, 0, true)%>
					<TD colspan=2 rowspan=3><INPUT style="width:80px;height:30px;" TYPE=button name=btnProc VALUE="F9:�ۑ�" onclick="DataSave()">
				<TR height=20>
					<TD colspan=5 align=right class=pt9>�� �� ��
					<TD class=line align=right><%=formatnumber(ttlTax, 0, true)%>
				<TR height=20 valign=bottom>
					<TD colspan=5 align=right class=pt9>���v���z
					<TD class=line align=right nowrap><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y���x���`�[�͌�����܂���ł����B</font>"
		end if
	end with
%>
	<input type=hidden name="cnt" value="<%=cnt%>">
  </form>
</center>
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
