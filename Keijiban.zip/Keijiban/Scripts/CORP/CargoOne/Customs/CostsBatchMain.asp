<%
	BatchNo = cstr("" & request("no"))
%>
<HTML>
<HEAD>
<TITLE>�x������</TITLE>
</HEAD>
	<FRAMESET rows="60,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="CloseTitle.asp?no=<%=BatchNo%>" NAME="ttl" MARGINWIDTH="0" MARGINHEIGHT="0" scrolling=no>
		<FRAME SRC="../common/blank.htm" NAME="dtl" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>