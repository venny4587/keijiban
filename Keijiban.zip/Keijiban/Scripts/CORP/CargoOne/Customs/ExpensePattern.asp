<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
dim myPageSize
	myPageSize = GetUserPageSize(15)
	
dim CTM_CD
dim PATN_ID
dim PATN_CD
dim PATN_NAME
dim PATN_ENAME
dim PATN_REMARKS

dim mySubmit
dim mySort
dim myCode
	
	CTM_CD = GetPost(Request("cd"))
	if CTM_CD = "" then CTM_CD = gsDummy
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	PATN_ID = GetLong(Request("PATN_ID"))
	If PATN_ID = 0 Then
		blnEdit = False
		myTitle = "�p�^�[���ǉ�"
		mySubmit = "�ǉ�"
		
		PATN_CD = ""
		PATN_TYPE = 0
		PATN_NAME = "" 
		PATN_ENAME = ""
		PATN_REMARKS = ""
	Else
		blnEdit = True
		myTitle = "�p�^�[���ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_PATTERN WHERE PATN_ID = " & PATN_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			PATN_CD = GetString(Recset.Fields("PATN_CD"))
			PATN_TYPE = GetLong(Recset.Fields("PATN_TYPE"))
			PATN_BELONG = GetString(Recset.Fields("PATN_BELONG"))
			PATN_NAME = GetString(Recset.Fields("PATN_NAME"))
			PATN_ENAME = GetString(Recset.Fields("PATN_ENAME"))
			PATN_REMARKS = GetString(Recset.Fields("PATN_REMARKS"))
			
			PATN_CREATER = GetLong(Recset.Fields("PATN_CREATER"))
			PATN_CREATED = GetDate(Recset.Fields("PATN_CREATED"))
			PATN_UPDATER = GetLong(Recset.Fields("PATN_UPDATER"))
			PATN_UPDATED = GetDate(Recset.Fields("PATN_UPDATED"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY class=pt9n <%=gsBodyControl%>>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "ExpensePattern.asp?cd=<%=CTM_CD%>&p=<%=myPage%>&s=<%=mySort%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y���p�^�[�����폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "ExpensePattern0.asp?cd=<%=CTM_CD%>&PATN_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkCode("PATN_CD","�R�[�h", 1) = false then exit sub
				if checkText("PATN_NAME","�a������", 1) = false then exit sub
				if checkText("PATN_ENAME","�p������", 0) = false then exit sub
				if checkText("PATN_REMARKS","�p�^�[�����l", 0) = false then exit sub
				if checkLen("PATN_REMARKS","�p�^�[�����l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "ExpensePattern.asp?cd=<%=CTM_CD%>&s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="ExpensePattern1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="cd" value="<%=CTM_CD%>">
						<INPUT type=hidden name="PATN_ID" value="<%=PATN_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline nowrap>�������p�^�[��</TD>
								<TD class=gline align=right><img src=img/spacer.gif height=3><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center class=pt9g width=70>�׎喼</TD>
								<TD class=pt9g><%=GetFullName(CTM_CD)%>�@(<%=CTM_CD%>)</TD>
							</TR>
							<TR>
								<TD align=center nowrap>�R�[�h</TD>
								<TD><INPUT class=si NAME="PATN_CD" MAXLENGTH=5 SIZE=5 VALUE="<%=PATN_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�Ɩ�</TD>
								<TD><SELECT name="PATN_BELONG" onkeydown="ResetEnter()"><%=ShowJobType(PATN_BELONG)%></select>
								�@�@�敪&nbsp;
									<INPUT type=radio NAME="PATN_TYPE" VALUE="0" OnKeyDown="ResetEnter()" <%if PATN_TYPE=0 then response.write "checked"%>>����
									<INPUT type=radio NAME="PATN_TYPE" VALUE="1" OnKeyDown="ResetEnter()" <%if PATN_TYPE=1 then response.write "checked"%>>�x��
							</TR>
							<TR>
								<TD align=center nowrap>�a������</TD>
								<TD><INPUT class=sj NAME="PATN_NAME" MAXLENGTH=50 SIZE=30 VALUE="<%=PATN_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�p������</TD>
								<TD><INPUT class=si NAME="PATN_ENAME" MAXLENGTH=50 SIZE=40 VALUE="<%=PATN_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>���l</TD>
								<TD><textarea NAME="PATN_REMARKS" style="width:250px;height:50px;"><%=PATN_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
<%If PATN_ID <> 0 Then%>
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD width=12% class=pt9g nowrap>�쐬��<TD width=10% class=gline><%=GetEmployName(PATN_CREATER, "F")%>
								<TD width=12% class=pt9g nowrap>�쐬��<TD width=15% class=gline><%=right(formatDate(PATN_CREATED),8)%>
								<TD width=12% class=pt9g nowrap>�X�V��<TD width=10% class=gline><%=GetEmployName(PATN_UPDATER, "F")%>
								<TD width=12% class=pt9g nowrap>�X�V��<TD width=15% class=gline><%=right(formatDate(PATN_UPDATED),8)%>
						</TABLE>
						<BR>
<%end if%>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
						
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL & "SELECT PATN_ID,"
					strSQL = strSQL & "       PATN_CD,"
					strSQL = strSQL & "       PATN_TYPE,"
					strSQL = strSQL & "       PATN_BELONG,"
					strSQL = strSQL & "       PATN_NAME,"
					strSQL = strSQL & "       PATN_ENAME,"
					strSQL = strSQL & "       PATN_CNT,"
					strSQL = strSQL & "       PATN_REMARKS"
					strSQL = strSQL & "  FROM MST_PATTERN LEFT JOIN (SELECT PatternID, COUNT(ExpenseCost) AS PATN_CNT FROM PTN_EXPENSE GROUP BY PatternID) AS TMP"
					strSQL = strSQL & "    ON MST_PATTERN.PATN_ID = TMP.PatternID"
					strSQL = strSQL & " WHERE PATN_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
					Select Case mySort
					Case "jp"
						strSQL = strSQL & " ORDER BY PATN_BELONG, PATN_TYPE, PATN_CD;"
					Case "en"
						strSQL = strSQL & " ORDER BY PATN_TYPE, PATN_BELONG, PATN_CD;"
					Case Else
						strSQL = strSQL & " ORDER BY PATN_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = myPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.</TD>
							<TD class=line nowrap width=10%><a class=bar href="ExpensePattern.asp?s=jp&cd=<%=CTM_CD%>">�Ɩ�</a></TD>
							<TD class=line nowrap width=10%><a class=bar href="ExpensePattern.asp?s=en&cd=<%=CTM_CD%>">�敪</a></TD>
							<TD class=line nowrap width=10%><a class=bar href="ExpensePattern.asp?s=cd&cd=<%=CTM_CD%>">����</a></TD>
							<TD class=line nowrap width=20%>�a������</a></TD>
							<TD class=line nowrap width=8%>����</TD>
							<TD class=line nowrap width=20%>���l</TD>
							<TD class=line nowrap width=8%>�ҏW</TD>
							<TD class=line nowrap width=8%>�Ɖ�</TD>
<%if CheckUserLevel(UserShop, "") > 1 then%>
							<TD class=line nowrap width=8%>�폜</TD>
<%end if%>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * myPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * myPageSize Then
										Exit Do
									else
										myBelong = GetString(.Fields("PATN_BELONG"))
										myName = GetString(.Fields("PATN_NAME"))
										myEname = GetString(.Fields("PATN_ENAME"))
										myRemark = GetString(.Fields("PATN_REMARKS"))
										if GetLong(.Fields("PATN_TYPE")) then
											status = "<font color=red>�x��</font>"
										else
											status = "<font color=black>����</font>"
										end if
						%>
						<TR>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetJobDivision(myBelong)%><BR></TD>
							<TD class=line nowrap><%=status%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("PATN_CD"))%><BR></TD>
							<TD class=line nowrap <%=ShowTitle(myName,10)%>><%=stringCut(myName,10)%><BR></TD>
							<TD class=line nowrap align=center><%=GetLong(.Fields("PATN_CNT"))%><BR></TD>
							<TD class=line nowrap <%=ShowTitle(myRemark,15)%>><%=stringCut(myRemark,15)%><BR></TD>
						<%
							If PATN_ID = GetLong(.Fields("PATN_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""ExpensePattern.asp?cd=" & CTM_CD & "&p=" & myPage & "&s=" & mySort & "&PATN_ID=" & .Fields("PATN_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap>
								<A HREF="ExpenseDetail.asp?cd=<%=CTM_CD%>&PatternID=<%=.Fields("PATN_ID")%>"><IMG SRC='img/group.gif' ALT='�Ɖ�' STYLE='cursor:hand' BORDER=0></A>
							</TD>
<%if CheckUserLevel(UserShop, "") > 1 then%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("PATN_ID")%>')"></TD>
<%	end if %>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center class=pt9n>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
