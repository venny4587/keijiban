<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
		
	SearchDate = GetDate(request("SearchDate"))
	if SearchDate = "" then SearchDate = formatDate(date)
	
	ReceiveSort = GetLong(request("sort"))
	SalesManager = GetLong(request("SalesManager"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�c�ƔC���ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></SCRIPT>
	<SCRIPT language=vbscript>		
		function DoSort(myNo)
			window.location.href = "ReceiveResult.asp?sort=" & myNo
		end function
		
		function ShowDetail(myNo)
			dim win
			set win = window.open("../Account/ReceiveErase.asp?FIN_NO=" & myNo,"ReceiveErase","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		sub SalesManager_OnChange()
		dim myID
			myID = SalesManager.options(SalesManager.SelectedIndex).value
			window.location.href = "ReceiveResult.asp?SalesManager=" & myID
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=0 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=30 valign=bottom>
	  	  <td nowrap width=40% valign=bottom>�������҂��ꗗ&nbsp;
	  	  <td nowrap width=60%>
			�c�ƒS��&nbsp;<SELECT class=pt9n name="SalesManager" onkeydown="ResetEnter()"><option value=0>�S��<%=ShowEmployList(DepartSales, SalesManager)%></select>
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT FIN_NO, CTM_CD, ClientRef, ClientName, SalesManager, FIN_BELONG, FIN_AMOUNT, FIN_DATE, FIN_SECURITIES, ERASE_ID FROM TBL_CTM_FIN AS F"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME AS ClientName, CTM_SALESMNGR AS SalesManager FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE FIN_DELETED = 0 AND SUBSTRING(FIN_NO,3,1) = 'R' AND ERASE_ID = 0 AND FIN_CURRENT = 1"
		if SalesManager <> 0 then strSql = strSql & " AND SalesManager = " & SalesManager 
		select case ReceiveSort
		case 0:		strSql = strSql & " ORDER BY FIN_NO"
		case 1:		strSql = strSql & " ORDER BY ClientRef, FIN_NO"
		case 2:		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
		case 3:		strSql = strSql & " ORDER BY FIN_AMOUNT, FIN_NO"
		case 4:		strSql = strSql & " ORDER BY SalesManager, FIN_NO"
		end select
if WebUserID = gsAdmin then response.write strSQL
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line colspan=2 style="cursor:hand;color:blue" onmousedown="DoSort(0)">�����ԍ�
		<TD class=line nowrap align=left style="cursor:hand;color:blue" onmousedown="DoSort(1)">������
		<TD class=line nowrap align=center style="cursor:hand;color:blue" onmousedown="DoSort(2)">������
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�����z
<%if true then%>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�S��
<%end if%>
		<TD class=line nowrap>����
<%
			cnt = 0
			ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				FIN_NO = GetString(.Fields("FIN_NO"))
				ClientRef = GetString(.Fields("ClientRef"))
				ClientName = GetString(.Fields("ClientName"))
				if true then
					status = GetEmployName(GetSalesManager(GetString(.Fields("CTM_CD"))), "F")
				else
					status = GetString(.Fields("FIN_CLIENT_PIC"))
				end if
%>
				<TR align=center height=20>
					<TD class=line><%=cnt%><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=FIN_NO%>')">
					<TD nowrap class=line align=left><%=ShowVoucherNo(FIN_NO)%><BR>
					<TD nowrap class=line nowrap align=left style="cursor:help" title="<%=ClientName%>"><%=StringCut(ClientRef,7)%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("FIN_DATE"))%><BR>
					<TD nowrap class=line nowrap align=right><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
					<TD nowrap class=line><%=status%><BR>
					<TD nowrap class=line><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
<%
				ttlAmount = ttlAmount + GetLong(.Fields("FIN_AMOUNT"))
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=3 class=pt9>�������v
					<TD colspan=2 class=line nowrap><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�������`�[�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
