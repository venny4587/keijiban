<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim SeqNo
dim JobClient
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
		
	SeqNo = GetLong(request("SeqNo"))
	if SeqNo <> 0 then
		with Recset
			strSql = "SELECT * FROM TBL_CTM_STOCK WHERE Deleted = 0 AND SeqNo = " & SeqNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if .eof then
				SeqNo = 0
			else
				JobCode = GetString(.fields("JobCode"))
				StockClient = GetString(.fields("StockClient"))
				StockReferNo = GetString(.fields("StockReferNo"))
				StockNo = GetString(.fields("StockNo"))
				StockDate = Str2Date(.fields("StockDate"))
				StockTime = GetString(.fields("StockTime"))
				StockCode = GetString(.fields("StockCode"))
				StockName = GetString(.fields("StockName"))
				
				StockPkgCnt = GetLong(.fields("StockPkgCnt"))
				StockPkgZan = GetLong(.fields("StockPkgZan"))
				StockPackage = GetString(.fields("StockPackage"))
				StockGW = GetDouble(.fields("StockGW"))
				StockCBM = GetDouble(.fields("StockCBM"))
				StockMark = GetString(.fields("StockMark"))
				
				StockPlace = GetString(.fields("StockPlace"))
				StockDelivery = GetString(.fields("StockDelivery"))
				StockStatus = GetString(.fields("StockStatus"))
				StockLot = GetString(.fields("StockLot"))
				StockDivision = GetString(.fields("StockDivision"))
				StockMemo = GetString(.fields("StockMemo"))
				Remarks = GetString(.fields("Remarks"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
			
			Exported = 0
			'Exported = (StockPkgCnt <> StockPkgZan)
			if Exported then 
				myPkg = StockPkgCnt
				ExportList = ""
				strSql = "SELECT StockDate, StockPkgCnt, StockPackage FROM TBL_CTM_STOCK AS S INNER JOIN TBL_CTM_STOCK_LINK AS L"
				strSql = strSql & " ON S.SeqNo = L.ExportNo WHERE Deleted = 0 AND ImportNo = " & SeqNo & " ORDER BY StockDate"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof
					ExportList = ExportList & "<tr><td align=center>" & Str2Date(.fields("StockDate"))
					ExportList = ExportList & "<td align=right>" & GetLong(.fields("StockPkgCnt"))
					ExportList = ExportList & "<td>" & GetString(.fields("StockPackage"))
					.movenext
				loop
				.close
				if ExportList = "" then
					ExportList = "�o�ɗ����F�Y���Ȃ�"
				else
					ExportList = "<TABLE width=90% border=1 class=pt9g><tr align=center><td>�o�ɓ�<td>�o�ɐ�<td>�׎p" & ExportList & "</table>"
				end if
			end if
		end with
	else
		StockClient = GetString(Session("StockIn_Client"))
		StockPlace = "�ېőq��"
		StockDivision = "����"
	end if
%>
<html>
<HEAD>
	<TITLE>���ɏڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoPlace(mode)
			dim win
			select case mode
			case 0:		txt = "ClientName&cd=" & frmInput.ClientRef.value
			case 1:		txt = "StockPlace"
			case 2:		txt = "StockDelivery"
			end select
			set win = window.open("StockSearch.asp?mode=" & mode & "&txt=" & txt,"PlaceSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub DoGoods()
			if frmInput.ClientName.value = "" then
				frmInput.ClientRef.focus()
				msgbox "�����׎����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			dim win
			set win = window.open("StockGoods.asp?Client=" & frmInput.StockClient.value & "&cd=" & frmInput.StockCode.value,"StockGoods","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub DoAddNew()
			if frmInput.ClientName.value = "" then
				frmInput.ClientRef.focus()
				msgbox "�����׎����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkText("StockCode","�i��",1) = false then exit sub
			if checkText("StockName","�i��",1) = false then exit sub
			if checkText("StockReferNo","���臂",0) = false then exit sub
			if checkText("StockStatus","���萔", 0) = false then exit sub
			dim win
			set win = window.open("StockGoodsInfo.asp?mode=1&Client=" & frmInput.StockClient.value,"StockGoodsInfo","resizable=1,scrollbars=1,width=600,height=400")
		end sub
		
		sub JobCode_OnBlur()
			'frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub StockDate_OnBlur()
			frmInput.StockDate.value = SetDate(frmInput.StockDate.value)
		end sub
		
		sub StockPkgCnt_OnBlur()
			frmInput.StockPkgCnt.value = GetLong(frmInput.StockPkgCnt.value)
		end sub		
		sub StockPkgZan_OnBlur()
			frmInput.StockPkgZan.value = GetLong(frmInput.StockPkgZan.value)
		end sub		
		sub StockGW_OnBlur()
			frmInput.StockGW.value = GetDouble(frmInput.StockGW.value)
		end sub
		sub StockCBM_OnBlur()
			frmInput.StockCBM.value = GetDouble(frmInput.StockCBM.value)
		end sub
		
		sub DataSave()
		dim buf
			if checkText("StockClient","�����׎�",1) = false then exit sub
			if checkText("StockReferNo","���臂",0) = false then exit sub
			if checkText("JobCode","�䒠�ԍ�", 0) = false then exit sub
			if checkText("StockNo","���ɔԍ�",1) = false then exit sub
			if checkDate("StockDate","���ɓ�", 1) = false then exit sub
			if checkText("StockTime","���Ɏ���", 0) = false then exit sub
			if checkText("StockCode","�i��",0) = false then exit sub
			if checkText("StockName","�i��",1) = false then exit sub
			if checkNum("StockPkgCnt","���ɐ�",1) = false then exit sub
			if checkText("StockPackage","�׎p",1) = false then exit sub
			if checkDouble("StockGW","�d��",1) = false then exit sub
			if checkDouble("StockCBM","����",1) = false then exit sub
			if checkText("StockStatus","���萔", 0) = false then exit sub
			if checkNum("StockPkgZan","�c�ɐ�",1) = false then exit sub
			if GetLong(frmInput.StockPkgCnt.value) < GetLong(frmInput.StockPkgZan.value) then
				frmInput.StockPkgZan.focus()
				msgbox "�c�ɐ��͓��ɐ���葽���ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkText("StockLot","�q��", 0) = false then exit sub
			if checkText("StockPlace","���n�ꏊ",1) = false then exit sub
			if checkText("StockDelivery","�^���Ǝ�",0) = false then exit sub
			if checkText("StockMark","�}�[�N", 0) = false then exit sub
			if checkLen("StockMark","�}�[�N", 250) = false then exit sub
			if checkText("StockMemo","���Ƀ���", 0) = false then exit sub
			if checkLen("StockMemo","���Ƀ���", 250) = false then exit sub
			if checkText("Remarks","�Г����l", 0) = false then exit sub
			if checkLen("Remarks","�Г����l", 250) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
<%if Exported = 0 then%>
				call DataSave() 
<%end if%>
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
		
		sub InitForm()
<%if Exported <> 0 then%>
			call LockAll()
<%else%>
			frmInput.ClientRef.focus()
<%end if%>
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsStockBackColor%>" onload="InitForm()" topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="StockInUpdate.asp" method="post">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>�����ɏڍ׏��&nbsp;
<%if SeqNo <> 0 and Exported = 0 then %>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
		<td width=50% align=right>
<%if Exported = 0 then%>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
<%elseif StockPkgZan = 0 then%>
	  	  <img style="cursor:hand" src=img/security.gif alt="�o�ɍ�">
<%end if%>
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=28><TD colspan=2 nowrap>
			������&nbsp;<input type=hidden name="StockClient" value="<%=StockClient%>">
			<input class=si name="ClientRef" size=8 maxlength=10 value="<%=GetRefName(StockClient)%>" onkeydown="ResetEnter()">
			<a href="javascript:DoPlace(0)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="ClientName" size=40 value="<%=GetFullName(StockClient)%>" onkeydown="ResetEnter()" readonly>�@
			�䒠�ԍ�&nbsp;<input class=si name="JobCode" size=10 maxlength=10 value="<%=JobCode%>" onkeydown="ResetEnter()">
	  <TR height=28><TD colspan=2 nowrap>
			���ɔԍ�&nbsp;<input class=si name="StockNo" size=16 maxlength=20 value="<%=StockNo%>" onkeydown="ResetEnter()">
			���ɓ�&nbsp;<input class=si name="StockDate" size=10 maxlength=10 value="<%=StockDate%>" onkeydown="ResetEnter()" onclick="setday(this)">
			<font class=pt9>���Ɏ���</font>
			<input class=sj name="StockTime" size=8 maxlength=8 value="<%=StockTime%>" onkeydown="ResetEnter()">
			���臂&nbsp;<input class=si name="StockReferNo" size=8 maxlength=20 value="<%=StockReferNo%>" onkeydown="ResetEnter()">
			<img src=img/new.gif border=0 alt="�V�K" onmousedown="DoAddNew()" style="cursor:hand">
	  <TR height=28><TD colspan=2 nowrap>
			�i��&nbsp;<input class=si name="StockCode" size=16 maxlength=20 value="<%=StockCode%>" onkeydown="ResetEnter()">
			<a href="javascript:DoGoods()"><img src=img/search.jpg border=0 alt="����"></a>�@
			�i��&nbsp;<input class=sj name="StockName" size=52 maxlength=50 value="<%=StockName%>" onkeydown="ResetEnter()">
	  <TR height=28><TD colspan=2 nowrap>
			���ɐ�&nbsp;<input class=sn name="StockPkgCnt" size=6 maxlength=6 value="<%=StockPkgCnt%>" onkeydown="ResetEnter()">�@
			�c��&nbsp;<input class=sn name="StockPkgZan" size=6 maxlength=6 value="<%=StockPkgZan%>" onkeydown="ResetEnter()">�@
			�׎p&nbsp;<input class=si name="StockPackage" size=8 maxlength=20 value="<%=StockPackage%>" onkeydown="ResetEnter()">�@
			�d��&nbsp;<input class=sn name="StockGW" size=6 maxlength=6 value="<%=StockGW%>" onkeydown="ResetEnter()"> KGS�@
			����&nbsp;<input class=sn name="StockCBM" size=6 maxlength=6 value="<%=StockCBM%>" onkeydown="ResetEnter()"> M<sup>3</sup>
	  <TR height=28><TD nowrap>
			���萔&nbsp;<input class=si name="StockStatus" size=14 maxlength=10 value="<%=StockStatus%>" onkeydown="ResetEnter()">�@
			�q��&nbsp;<input class=si name="StockLot" size=14 maxlength=10 value="<%=StockLot%>" onkeydown="ResetEnter()">
<%if Exported then %>
			<TD rowspan=3 class=pt9g align=center><%=ExportList%>
<%else%>
			<TD rowspan=3 class=pt9>�}�[�N<BR><textarea name="StockMark" rows=5 style="width:220"><%=StockMark%></textarea>
<%end if%>
	  <TR height=28><TD nowrap>
			���n�ꏊ&nbsp;<a href="javascript:DoPlace(1)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=sj name="StockPlace" size=16 maxlength=50 value="<%=StockPlace%>" onkeydown="ResetEnter()">
			�S��&nbsp;<input class=sj name="StockDivision" size=8 maxlength=10 value="<%=StockDivision%>" onkeydown="ResetEnter()">
	  <TR height=28><TD nowrap class=pt9>
			�^���Ǝ�&nbsp;<a href="javascript:DoPlace(2)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=sj name="StockDelivery" size=32 maxlength=50 value="<%=StockDelivery%>" onkeydown="ResetEnter()">
	  <TR height=100 class=pt9 valign=bottom>
		<TD>���Ƀ���<BR><textarea name="StockMemo" rows=5 style="width:280"><%=StockMemo%></textarea>
		<TD>�Г����l<BR><textarea name="Remarks" rows=5 style="width:220"><%=Remarks%></textarea>
	</TABLE>
  </FORM>
<%if SeqNo <> 0 then%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
<%end if%>
<center>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
%>
