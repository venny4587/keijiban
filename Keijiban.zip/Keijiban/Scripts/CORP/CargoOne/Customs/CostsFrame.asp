<HTML>
<HEAD>
<TITLE>�x������</TITLE>
</HEAD>
	<FRAMESET cols="550,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="CostsMain.asp" NAME="input" MARGINWIDTH="0" MARGINHEIGHT="0">
		<FRAME SRC="" NAME="result" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>