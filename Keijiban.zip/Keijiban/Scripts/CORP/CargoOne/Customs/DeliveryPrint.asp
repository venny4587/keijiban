<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim JobBelong
dim JobBorker
dim JobClient
dim JobShipper
	
	JobCode = GetPost(request("JobCode"))		
	SeqNo = GetLong(request("seq"))
	if JobCode <> "" then
		mode = 0
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset	
			StrSql = "SELECT * FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				JobClient = GetString(.fields("JobClient"))
				JobBelong = GetString(.fields("JobBelong"))
				JobBorker = GetString(.fields("CustomBroker"))
				JobOperator = GetString(.fields("JobOperator"))
				JobManager = GetString(.fields("JobManager"))
				JobNo = GetString(.fields("JobNo"))
				EdaNo = GetString(.fields("EdaNo"))
				Vessel = GetString(.fields("Vessel"))
				Voy = GetString(.fields("Voy"))
				POL = GetString(.fields("POL"))
				POD = GetString(.fields("POD"))
				ETD = Str2Date(.fields("ETD"))
				ETA = Str2Date(.fields("ETA"))
				MBL = GetString(.fields("MBL"))
				HBL = GetString(.fields("HBL"))
				GW = GetDouble(.fields("GW"))
				CBM = GetDouble(.fields("CBM"))
				Commodity = GetString(.fields("Commodity"))
				Quantity = GetDouble(.fields("Quantity"))
				Package = GetString(.fields("Package"))				
				JobShipper = GetString(.fields("JobShipper"))
			end if
			.close
			if Voy <> "" then Vessel = Vessel & " V." & Voy
		
			if SeqNo <> 0 then
				strSql = "SELECT * FROM TBL_CTM_DELIVERY WHERE Deleted = 0"
				strSql = strSql & " AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					OrderDate = Str2Date(.fields("OrderDate"))
					OrderTime = GetString(.fields("OrderTime"))
					DeliveryDate = Str2Date(.fields("DeliveryDate"))
					DeliveryTime = GetString(.fields("DeliveryTime"))
					DeliveryBroker = GetString(.fields("DeliveryBroker"))
					DeliveryType = GetString(.fields("DeliveryType"))
					DeliveryFrom = GetString(.fields("DeliveryFrom"))
					DeliveryTo = GetLong(.fields("DeliveryTo"))
					Contents = GetString(.fields("Contents"))
					Remarks = replace(GetString(.fields("Remarks")), vbcrlf, "<br>")
				end if
				.close
				
				StrSql = "SELECT PIC_NAME, PIC_DPT, PIC_POS, PIC_TEL, PIC_FAX FROM CTM_PIC WHERE CTM_CD = '" & DeliveryBroker & "' AND PIC_DFT <> 0"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if not .eof then
					BROKER_PIC = GetString(.fields("PIC_DPT")) & " " & GetString(.fields("PIC_POS")) & " " & GetHornor(.fields("PIC_NAME"))
					BROKER_TEL = GetString(.fields("PIC_TEL"))
					BROKER_FAX = GetString(.fields("PIC_FAX"))
				end if
				.close
				
				strSql = "SELECT DOOR_NAME, DOOR_PIC, DOOR_TEL, DOOR_FAX, DOOR_ADDR1, DOOR_ADDR2 FROM CTM_DOOR WHERE DOOR_ID = " & DeliveryTo 
				.Open strSql, Conn ,adOpenKeyset ,adLockReadOnly
				if not .eof then
					DOOR_NAME = GetString(.fields("DOOR_NAME"))
					DOOR_ADDR1 = GetString(.fields("DOOR_ADDR1"))
					DOOR_ADDR2 = GetString(.fields("DOOR_ADDR2"))
					DOOR_PIC = GetHornor(.fields("DOOR_PIC"))
					DOOR_TEL = GetString(.fields("DOOR_TEL"))
					DOOR_FAX = GetString(.fields("DOOR_FAX"))
				end if
				.close
				
				if DeliveryTo = 0 then DOOR_NAME = "�[�i�����ɋL��"
			end if
		end with
	end if
%>
<html>
<head>
	<title>�z�Ԉ˗��[</title>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<style>
		.pts { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptm { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptl { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 20pt; LINE-HEIGHT: 1.2em; color: black; }
		
		.mi{FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
		.mn{FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;TEXT-ALIGN:right}
		.mb{FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
	</style>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub DoShortCut()	
			if window.event.keyCode=27 then window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	//-->
	</SCRIPT>
</head>
<body topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
	<table width=600 class=pts border=0>
		<tr>
			<td colspan=2 class=ptx>�z�Ԉ˗��[
			<td nowrap valign=top align=right>�o�͓��t:<%=formatDate(date)%>
	</table>
	<br>
	<table width=560 class=pts border=0>
		<tr><td colspan=3><input class=mb value="<%=GetFullName(DeliveryBroker)%>" size=60 readonly>
		<tr><td>TEL<td><input class=mb value="<%=BROKER_TEL%>" size=50 readonly><br>
		<tr><td>FAX<td><input class=mb value="<%=BROKER_FAX%>" size=50 readonly>
		<tr><td nowrap>�S����<td><input class=mb value="<%=BROKER_PIC%>" size=50 readonly>
	</table>
	<br>
	<table width=600 class=pts>			
		<tr><td><b>�䒠�ԍ��F<input class=mb value="<%=JobCode%>" size=10 readonly> �| <input class=mb style="text-align:right" value="<%=SeqNo%>" size=6 readonly>
			<td align=right>JOB No. <input class=mn value="<%=JobNo%>" size=6 readonly>�@EDA No. <input class=mn value="<%=EdaNo%>" size=6 readonly>
	</table>
	<hr width=600 size=1 color=black>
	<table width=580 class=pts border=0>	
		<tr height=24>
			<td width=100>�׎�<td width=220><input class=mi value="<%=GetCtmName(JobShipper)%>" size=50 readonly>
		<tr height=24>
			<td>�֖�<td><input class=mi value="<%=Vessel%>" size=24 readonly>	
<%if false then%>
		<tr height=24>
			<td>��<td><input class=mn value="<%=Quantity%>" size=10 readonly>&nbsp;<input class=mi value="<%=Package%>" size=16 readonly>
		<tr height=24>
			<td>WEIGHT<td><input class=mn value="<%=formatnumber(GW,3,true)%>" size=10 readonly> KGS
		<tr height=24>
			<td>MEASURE<td><input class=mn value="<%=formatnumber(CBM,3,true)%>" size=10 readonly> M<sup>3</sup>
<%end if%>
		<tr height=24>
			<td nowrap>MASTER B/L ��<td><input class=mi value="<%=MBL%>" size=20 readonly>
		<tr height=24>
			<td>HOUSE B/L ��<td><input class=mi value="<%=HBL%>" size=20 readonly>
		<tr height=24>
			<%if CheckJobType(JobCode) = "I" then%><td>���`��<td><input class=mi value="<%=ETA%>" size=10 readonly>
			<%else%><td>�o�`��<td><input class=mi value="<%=ETD%>" size=10 readonly><%end if%><br>
		<tr height=24>
			<td>�W�ד�<td><input class=mi value="<%=OrderDate & " " & OrderTime%>" size=20 readonly>
		<tr height=24>
			<td>�[�i��<td><input class=mi value="<%=DeliveryDate & " " & DeliveryTime%>" size=20 readonly>
		<tr height=24 valign=top>
			<td>�[�i���e<td class=gline><%=replace(Contents, vbcrlf, "<br>")%>
		<tr height=24>
			<td>�N�_<td><input class=mi value="<%=DeliveryFrom%>" size=56 readonly>
		<tr height=24>
			<td>�[�i��<td><input class=mi value="<%=DOOR_NAME%>" size=56 readonly>
		<tr height=24>
			<td>�Z���P<td><input class=mi value="<%=DOOR_ADDR1%>" size=56 readonly>
		<tr height=24>
			<td>�Z���Q<td><input class=mi value="<%=DOOR_ADDR2%>" size=56 readonly>
		<tr height=24>
			<td>TEL<td><input class=mi value="<%=DOOR_TEL%>" size=50 readonly>
		<tr height=24>
			<td>FAX<td><input class=mi value="<%=DOOR_FAX%>" size=50 readonly>
		<tr height=24>
			<td>�S��<td><input class=mi value="<%=DOOR_PIC%>" size=50 readonly>
		<tr height=30>
			<td>�[�i���@<td><input class=mi value="<%=DeliveryType%>" size=24 readonly>
		<tr height=100 valign=top>
			<td>�[�i����
			<td class=gline><%=Remarks%><br>	
	</table>
	<br>
	<table width=600 class=pt12n border=0>
		<tr><td>�f����p������Ё@<%=myTitle%>
		<tr><td><%=myTelFax%>
		<tr><td>�S���@<%=GetEmployName(JobOperator, "F")%>
	</table>
	<hr width=600 size=1 color=black>
</center>
<%if GetLong(request("print")) = 1 then%>
	<script languange=vbscript>
		window.print()
	</script>
<%end if%>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
end if
%>