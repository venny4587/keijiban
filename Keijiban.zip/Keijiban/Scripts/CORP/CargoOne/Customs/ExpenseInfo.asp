<%
'on error resume next
	JobCode = cstr(Request("JobCode") & "")
	if instr(JobCode, " ") <> 0 then JobCode = ""
	if JobCode <> "" then
%>
<HTML>
<HEAD>
<TITLE>��p�ꗗ���</TITLE>
</HEAD>
	<FRAMESET rows="130,80%,20%" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="BalanceCheck.asp?JobCode=<%=JobCode%>" NAME="balance" MARGINWIDTH="10" MARGINHEIGHT="0" scrolling=no>
		<FRAME SRC="PaymentList.asp?JobCode=<%=JobCode%>" NAME="payment" MARGINWIDTH="10" MARGINHEIGHT="0">
		<FRAME SRC="DocumentList.asp?JobCode=<%=JobCode%>" NAME="document" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>
<%
	end if
%>