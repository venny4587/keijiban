<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�o�b�`�Ǘ��w�b�_���
'----------------------------------------------

'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim BatchNo
dim BatchClient
dim BatchBillDay
dim BatchPayDay
dim Remarks

dim mySubmit
dim mySort
dim myCode
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myType = cstr(request("t"))	
	
	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "en"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	BatchNo = GetString(Request("BatchNo"))
	BatchBelong = GetString(Request("BatchBelong"))
%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
		<SCRIPT LANGUAGE="VBScript">
			function ShowList(myNo)
				window.parent.parent.result.location.href = "ChargeBatchList.asp?BatchNo=" & myNo
			end function
			
			function ShowDetail(myNo)
				window.parent.parent.result.location.href = "ChargeBatchDetail.asp?p=<%=myPage%>&s=<%=mySort%>&BatchBelong=<%=BatchBelong%>&BatchNo=" & myNo
				'window.location.href = "ChargeBatch.asp?p=<%=myPage%>&s=<%=mySort%>&BatchBelong=<%=BatchBelong%>&BatchNo=" & myNo
			end function
			
			function ConfirmDelete(myNo)
				if msgbox("�Y���o�b�`�ԍ����폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "ChargeBatch0.asp?BatchNo=" & myNo & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
						
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "ChargeBatch.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
	</HEAD>
	<BODY class=pt9 <%=gsBodyControl%>>
		<TABLE width=100% class=pt9n>
			<TR><TD width=100% ALIGN=center VALIGN=TOP>	
				<%
					strSQL = ""
					strSQL = strSQL & "SELECT BatchNo,"
					strSQL = strSQL & "       BatchBelong,"
					strSQL = strSQL & "       BatchType,"
					strSQL = strSQL & "       CTM_REF,"
					strSQL = strSQL & "       CTM_NAME,"
					strSQL = strSQL & "       BatchBillDay,"
					strSQL = strSQL & "       BatchPayDay,"
					strSQL = strSQL & "       ConfirmerID,"
					strSQL = strSQL & "       FinisherID,"
					strSQL = strSQL & "       BatchCnt,"
					strSQL = strSQL & "       BatchAmnt,"
					strSQL = strSQL & "       Creater,"
					strSQL = strSQL & "       Remarks"
					strSQL = strSQL & "  FROM TBL_CTM_BATCH AS B INNER JOIN CUSTOMER AS C ON B.BatchClient = C.CTM_CD"
					strSQL = strSQL & "  LEFT JOIN (SELECT ChargeBatch, COUNT(ChargeNo) AS BatchCnt, SUM(ChargeAmount+ChargeTax) AS BatchAmnt"
					strSQL = strSQL & "  FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeBatch <> '' GROUP BY ChargeBatch) AS T ON B.BatchNo = T.ChargeBatch"
					strSQL = strSQL & " WHERE SUBSTRING(BatchNo,1,1)= '" & gsBatchPrint & "' AND Deleted = 0"
					if BatchBelong <> "" then 
						strSQL = strSQL & " AND BatchBelong = '" & BatchBelong & "'"
					else
						if CheckTopLevel() < 1 then strSQL = strSQL & " AND BatchBelong = '" & UserShop & "'"
					end if
					Select Case mySort
					Case "kb"
						strSQL = strSQL & " ORDER BY BatchType, BatchNo DESC;"
					Case "jp"
						strSQL = strSQL & " ORDER BY BatchNo DESC;"
					Case "en"
						strSQL = strSQL & " ORDER BY BatchPayDay DESC, BatchNo;"
					Case "cn"
						strSQL = strSQL & " ORDER BY BatchCnt DESC, BatchNo;"
					Case "mn"
						strSQL = strSQL & " ORDER BY BatchAmnt DESC, BatchNo;"
					Case "fn"
						strSQL = strSQL & " ORDER BY FinisherID, BatchNo;"
					Case "cd"
						strSQL = strSQL & " ORDER BY CTM_REF, BatchNo DESC;"
					Case else
						strSQL = strSQL & " ORDER BY ConfirmerID, BatchNo;"
					End Select
if WebUserID = gsAdmin then response.write strSQL
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize * 2
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=12>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										
									</TR>
								</table>
							
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.
							<TD class=line nowrap width=6%><a class=bar href="ChargeBatch.asp?s=de&BatchBelong=<%=BatchBelong%>">�폜</a>
							<TD class=line nowrap width=6%>�戵
							<TD class=line nowrap width=6%><a class=bar href="ChargeBatch.asp?s=kb&BatchBelong=<%=BatchBelong%>">�敪</a>
							<TD class=line nowrap width=10%><a class=bar href="ChargeBatch.asp?s=jp&BatchBelong=<%=BatchBelong%>">�����</a>
							<TD class=line nowrap width=10%><a class=bar href="ChargeBatch.asp?s=cd&BatchBelong=<%=BatchBelong%>">������</a>
							<TD class=line nowrap width=6%><a class=bar href="ChargeBatch.asp?s=cn&BatchBelong=<%=BatchBelong%>">����</a>
							<TD class=line nowrap width=14%><a class=bar href="ChargeBatch.asp?s=mn&BatchBelong=<%=BatchBelong%>">���z</a>
							<TD class=line nowrap width=10%><a class=bar href="ChargeBatch.asp?s=en&BatchBelong=<%=BatchBelong%>">������</a>
							<TD class=line nowrap width=8%><a class=bar href="ChargeBatch.asp?s=fn&BatchBelong=<%=BatchBelong%>">����</a>
							<TD class=line nowrap width=6%>�ҏW
							<TD class=line nowrap width=6%>����
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize * 2
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize * 2 Then
										Exit Do
									else
										myClient = GetString(.Fields("CTM_REF"))
										myName = GetString(.Fields("CTM_NAME"))
										select case GetBatchType(GetString(.Fields("BatchNo"))) 
										case 0, 1
											mycolor = "black"
										case 2
											mycolor = "green"
										case else
											mycolor = "blue"
										end select
										myStatus = ""
										if GetLong(.Fields("FinisherID")) then
											myStatus = "<font class=pt9n>��</font>"
										else
											myStatus = "<font class=pt9r>��</font>"
										end if
										
						%>
						<TR align=center>
							<TD class=line><%=lngCount%><BR>
						<%	if GetLong(.Fields("ConfirmerID")) = 0 then %>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("BatchNo")%>')">
						<%	else%>
							<TD class=line nowrap>�~
						<%	end if %>
							<TD class=line nowrap><%=GetShopName(.Fields("BatchBelong"))%><BR>
							<TD class=line nowrap><%=GetJobDivision(.Fields("BatchType"))%><BR>
							<TD class=line nowrap style="color:<%=mycolor%>"><%=GetString(.Fields("BatchNo"))%><BR>
							<TD class=line nowrap align=left title="<%=myName%>"><%=stringCut(myClient,8)%><BR>
							<TD class=line nowrap align=right><%=GetLong(.Fields("BatchCnt"))%><BR>
							<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("BatchAmnt")), 0, true)%><BR>
							<TD class=line nowrap><%=Str2MD(.Fields("BatchPayDay"))%><BR>
							<TD class=line nowrap><%=myStatus%><BR>
							<TD class=line nowrap><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' OnClick="ShowDetail('<%=.Fields("BatchNo")%>')">
							<TD class=line nowrap><IMG SRC='img/group.gif' ALT='�Ɖ�' STYLE='cursor:hand' OnClick="ShowList('<%=.Fields("BatchNo")%>')">
							
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>

<%
function GetBatchType(myBatch)
dim mySql
dim myRec
dim myCnt
	myCnt = 0
	GetBatchType = -1 
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT DISTINCT ChargeType FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeBatch = '" & myBatch & "'"
		.Open mySql,conn,adOpenStatic,adLockReadOnly
		do while not .eof
			myCnt = myCnt + 1
			GetBatchType = GetLong(.fields("ChargeType"))
			.movenext
		loop
		.Close
	end with
	set myRec = nothing
	if myCnt > 1 then GetBatchType =  -1
end function
%>