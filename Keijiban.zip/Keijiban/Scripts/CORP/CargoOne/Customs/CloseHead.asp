<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobClient
dim JobClientName
dim JobBelong
dim JobBroker
dim JobMemo
dim JobFinisher
dim JobLocker

	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	if JobBroker = gsCorpCode then			'�{�Јϑ�
		myLevel = CheckUserLevel(gsCorpInit, JobBroker)
		if UserShop <> gsCorpInit and UserShop = left(JobCode, 1) then 
			myLevel = CheckUserLevel(JobBelong, JobBroker)
		end if
	else
		myLevel = CheckUserLevel(JobBelong, JobBroker)
	end if
	if myLevel < 2 and JobSalesman = WebUserID then myLevel = 2
			
	if JobCode <> "" then
	
		mode = 0

		CostsDate = formatDate(date)
		CostsPattern = GetLong(Session("CTM_CostsPattern"))
		ConfirmerID = 0
		FinisherID = 0
		
		OpenSql Conn, SqlServerName, DataBaseName
		
		CostsNo = GetPost(request("CostsNo"))
		if CostsNo <> "" then
			set Recset = Server.CreateObject("adodb.recordset") 
			with Recset
				strSql = "SELECT * FROM TBL_CTM_COSTS WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then
					mode = 1
					CostsType = GetLong(.fields("CostsType"))
					CostsDate = Str2Date(.fields("CostsDate"))
					
					CostsBillNo = GetString(.fields("CostsBillNo"))
					CostsClient = GetString(.fields("CostsClient"))
					CostsName = GetString(.fields("CostsClientName"))
					CostsPic = GetString(.fields("CostsPic"))
					CostsAmount = GetLong(.fields("CostsAmount"))
					CostsTax = GetLong(.fields("CostsTax"))
					CostsCloseDay = Str2Date(.fields("CostsCloseDay"))
					CostsPayDay = Str2Date(.fields("CostsPayDay"))
					CostsBatch = GetString(.fields("CostsBatch"))
					
					CostsMemo = GetString(.fields("CostsMemo"))
					CostsCheck = GetLong(.fields("CostsCheck"))
					Remarks = GetString(.fields("Remarks"))
					
					Creater = GetLong(.fields("Creater"))
					Created = GetDate(.fields("Created"))
					Updater = GetLong(.fields("Updater"))
					Updated = GetDate(.fields("Updated"))
					
					ConfirmerID = GetLong(.fields("ConfirmerID"))
					ConfirmDate = GetDate(.fields("ConfirmDate"))
					FinisherID = GetLong(.fields("FinisherID"))
					FinishDate = GetDate(.fields("FinishDate"))
				end if
				.close
			end with
		else
		
			CostsClient = session("CTM_CostsClient")
			CostsRef = session("CTM_CostsClientRef")
			CostsName = session("CTM_CostsClientName")
			CostsPic = session("CTM_CostsClientPic")
			CostsCloseDay = session("CTM_CostsCloseDay")
			CostsPayDay = session("CTM_CostsPayDay")
		end if
%>
<html>
<HEAD>
	<TITLE>�����`�[�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		function ShowDetail()
			window.location.href = "CostsList.asp?type=1&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>"
		end function
		
		sub DataLock()
			call DataSave(2)
		end sub
		
		sub DataUnLock()
<%if JobLocker <> 0 then%>
			msgbox "�Y���䒠�ԍ��͊��ɑe�����b�N����܂����B", 48, "�m�F���b�Z�[�W"
<%elseif CheckBatchLocked(CostsBatch) <> 0 then %>
			msgbox "�Y���x���`�[�̃o�b�`���͊��Ɋm�肳��܂����B", 48, "�m�F���b�Z�[�W"
<%else%>
			if msgbox ("�Y���x���`�[�m����������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
<%end if%>
		end sub
				
		sub DoDelete()
			if msgbox ("�Y���x���`�[���폜���Ă�낵���ł����H",289, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DataSave(mode)
			if checkText("CostsBillNo","���萿�����ԍ�", 1) = false then exit sub
			if checkDate("CostsDate","�퐿����", 1) = false then exit sub
			if frmInput.CostsDate.value > frmInput.CostsCloseDay.value then
				if msgbox("�퐿�����͒��ߓ��ȍ~�ɂȂ��Ă�낵���ł����H", 49, "�m�F���b�Z�[�W") <> 1 then exit sub
			end if
			if checkText("CostsMemo","�x������", 0) = false then exit sub
			if checkLen("CostsMemo","�x������", 250) = false then exit sub
			if checkText("Remarks","�x�����l", 0) = false then exit sub
			if checkLen("Remarks","�x�����l", 250) = false then exit sub
			if mode = 2 then
<%if CostsClient = gsCorpSoko and WebUserID <> gsSokoID then%>
				if msgbox ("�Y���x���`�[�͎Г�������p�ł��B" & vbcrlf & _
							"�ېł̑���Ɋm�肵�Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") <> 1 then exit sub
<%else%>
				if msgbox ("�Y���x���`�[���m�肵�Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub CostsDate_OnBlur()
			frmInput.CostsDate.value = setdate(frmInput.CostsDate.value)
		end sub		
		
		sub DoShortCut()
			if window.event.keyCode=40 then ShowDetail()
<%if ConfirmerID = 0 then%>	if window.event.keyCode=120 then call DataSave(<%=mode%>) <%end if%>
		end sub
		
		sub InitForm()
<%if ConfirmerID <> 0 then %>
			call LockAll()
<%else%>
	<%if mode = 0 then%>
			frmInput.CostsBillNo.focus()
	<%else%>
			frmInput.CostsMemo.focus()
	<%end if%>
<%end if%>
			window.parent.parent.parent.result.location.href = "PaymentList.asp?mode=1&JobCode=<%=JobCode%>"
		end sub	
	</SCRIPT>
</Head>
<body bgcolor="<%=gsCostsBackColor%>" leftmargin=0 topmargin=3 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>�������`�[<%if mode=0 then%>�쐬<%else%>���<%end if%>&nbsp;
<%if mode = 1 then
	if ConfirmerID = 0 then 
%>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DoDelete()">
<%	else%>
		  <img style="cursor:hand" src=img/next.gif alt="���ׂ�" onmousedown="ShowDetail()">
<%	end if	
end if%>
		<td width=50% align=right>
<%	if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�����ς�">
<%	elseif ConfirmerID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�m�F�ς�" <%if myLevel > 2 then %>onmousedown="DataUnLock()"<%end if%>>
<%	else %>
	<%	if mode = 1 and (CostsAmount <> 0 or CostsTax <> 0) then %>
	 	  <%if myLevel > 0 then %><img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DataLock()">&nbsp;<%end if%>
	<%	end if %>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave(<%=mode%>)">
<%	end if %>
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=22><td width=160>&nbsp;�䒠�ԍ��@<font color=#228b22><%=JobCode%></font>
		<td>&nbsp;�����׎�@<font color=#228b22><%=JobClientName%></font>
	</table><br>
	<%=JobHeader%>
  <FORM NAME="frmInput" action="CostsSave.asp" method="post">
  	<input type=hidden name="JobBelong" value="<%=JobBelong%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="CostsNo" value="<%=CostsNo%>">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="ChargeClient" value="<%=CostsClient%>">
  	<input type=hidden name="ChargeName" value="<%=CostsName%>">
  	<input type=hidden name="ChargePic" value="<%=CostsPic%>">
  	<input type=hidden name="CostsCloseDay" value="<%=CostsCloseDay%>">
  	<input type=hidden name="CostsPayDay" value="<%=CostsPayDay%>">
  	<input type=hidden name="CostsType" value="1">
  	<input type=hidden name="type" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22>
		<TD width=60 align=center class=pt9g nowrap>�Ŕ����z
		<TD nowrap width=60 class=gline align=right><%=formatnumber(CostsAmount, 0, true)%>
		<TD width=60 align=center class=pt9g nowrap>�����
		<TD nowrap width=60 class=gline align=right><%=formatnumber(CostsTax, 0, true)%>
		<TD width=60 align=center nowrap>�퐿����
		<TD><input class=si name="CostsDate" size=10 maxlength=10 value="<%=CostsDate%>" onkeydown="ResetEnter()">
		<TD width=60 align=center nowrap>���臂
		<TD><input class=si name="CostsBillNo" size=15 maxlength=50 value="<%=CostsBillNo%>" onkeydown="ResetEnter()">
	  <tr>
	  	<td><img src=img/spacer.gif height=3>
	  <TR>
		<TD align=center>�x��<br>����
		<TD colspan=5><textarea name="CostsMemo" rows=5 style="width:300"><%=CostsMemo%></textarea>
<%	if mode = 0 then%>
		<TD colspan=2 rowspan=3 align=center valign=top><b>�p�^�[��</b><br>
			<select name="CostsPattern" size=10 style="width:120" class=pt9n onkeydown="ResetEnter()">
				<%=ShowExpensePattern(CostsClient, CheckJobType(JobCode), 1, CostsPattern)%><option value="0">�����</select>
<%	elseif CostsCheck <> 0 then %>
		<TD colspan=2 align=center class=pt12b nowrap>���͊���<br>
			<input type=checkbox name="CostsCheck" value=1 <%if CostsCheck then response.write " checked"%>>
<%	end if %>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR>
		<TD class=pt9 align=center>�Г�<br>���l
		<TD colspan=5><textarea class=sz name="Remarks" rows=5 style="width:300"><%=Remarks%></textarea>
<%	if mode = 1 and ConfirmerID <> 0 then %>
		<TD colspan=2 align=center class=pt12r>���b�N��
<%	end if %>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD align=center class=pt9g nowrap>�`�[�ԍ�<TD class=gline align=center><%=CostsNo%><BR>
		<TD align=center class=pt9g>�쐬��<TD class=gline align=center><%=GetEmployName(Creater, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=GetEmployName(ConfirmerID, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=formatDate(ConfirmDate)%><br>
	</TABLE>
  </FORM>
<center>
<script language=vbscript>
	window.parent.parent.parent.result.location.href = "CostsResult.asp?type=1"
</script>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function ShowExpensePattern(myCode, myBelong, myType, myDft)
dim mySql
dim myRec
dim myCon
dim buf

	buf = ""
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	with myRec
		mySql = "SELECT PATN_ID, PATN_CD, PATN_NAME FROM MST_PATTERN"
		mySql = mySql & " WHERE PATN_DELETED = 0 AND CTM_CD = '" & myCode & "'"
		mySql = mySql & " AND PATN_BELONG = '" & myBelong & "' AND PATN_TYPE = " & myType
		mySql = mySql & " ORDER BY PATN_NAME"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if .eof then
			.Close
			mySql = "SELECT PATN_ID, PATN_CD, PATN_NAME FROM MST_PATTERN WHERE PATN_DELETED = 0"
			mySql = mySql & " AND PATN_BELONG = '" & myBelong & "' AND PATN_TYPE = " & myType
			mySql = mySql & " AND CTM_CD = '" & gsDummy & "'"
			mySql = mySql & " ORDER BY PATN_NAME"
			.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		end if
		do while not .eof
			buf = buf & "<option value=" & .fields("PATN_ID")
			if myDft = GetLong(.fields("PATN_ID")) then buf = buf & " selected"
			buf = buf & ">" & GetString(.fields("PATN_NAME"))
			.movenext
		loop
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
	
	ShowExpensePattern = buf	
end function
%>