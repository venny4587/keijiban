<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim mode
dim JobCode
dim JobBelong
dim JobBroker
dim JobClient
dim ChargeClient

	mode = GetLong(request("mode"))
	JobCode = GetPost(request("JobCode"))
	if JobCode <> "" then
		if len(JobCode) < 10 then
			if instr(JobCode, "-") <> 0 then
				JobCode = ucase(left(JobCode,5)) & right("0000" & mid(JobCode,6),5)
			else
				JobCode = ucase(left(JobCode,4)) & "-" & right("0000" & mid(JobCode,5),5)
			end if
		end if
		JobCode = ucase(JobCode)
		JobHeader = ShowCstmJobHead(JobCode, 1)
		if JobBroker = gsCorpCode then			'�{�Јϑ�
			myLevel = CheckUserLevel(gsCorpInit, JobBroker)
			if UserShop <> gsCorpInit and UserShop = left(JobCode, 1) then 
				myLevel = CheckUserLevel(JobBelong, JobBroker)
			end if
		else
			myLevel = CheckUserLevel(JobBelong, JobBroker)
			if UserShop = gsCorpInit then 
				myLevel = CheckUserLevel(gsCorpInit, "")
			end if
		end if
		if trim(JobHeader) <> "" then 
			if CheckJobLocked(JobCode) then
				mode = 3
			elseif myLevel > 0 then
				goNext = 0
				if mode = 5 or JobBroker = session("CTM_CostsClient") then
					goNext = 1
				elseif CheckCostsClient(JobCode, session("CTM_CostsClient")) then
					goNext = 1
				else
					select case session("CTM_CostsClient")
					case "G26", "CH000121"
						goNext = 1
					case else
						mode = 4
					end select
				end if
				if goNext = 1 then
					session("CTM_CLOSE_INIT") = left(JobCode, 5)
					response.redirect "CloseHead.asp?JobCode=" & JobCode
					response.end
				end if
			else
				mode = 2
			end if
		end if
	else
		JobCode = GetString(Session("CTM_CLOSE_INIT"))
	end if	
%>
<html>
<HEAD>
	<TITLE>�����ڍד���</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<script language=vbscript>
		sub InitForm()
			call SetEndFocus(frmInput.JobCode)
		end sub
		
		sub DoProc()
			frmInput.mode.value = 5
			frmInput.submit()
		end sub
		
		sub DoCancel()
			window.location.href = "CloseInput.asp"
		end sub
	</script>
</Head>
<body leftmargin=0 topmargin=3 class=pt9 onload="InitForm()" <%=gsBodyControl%>>
<center>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td width=50%>����������&nbsp;
		<td width=50% align=right>
	</table>
	<hr width=96% size=1>
  <FORM NAME="frmInput" action="CloseInput.asp" method="post">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td>&nbsp;�䒠�ԍ�&nbsp;
	  	<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10>
		<%if mode = 1 then%><font color=red>�Y���䒠�ԍ��͌�����܂���ł����B</font><%end if%>
		<%if mode = 2 then%><font color=red>�Y���䒠�ԍ���<%=GetShopName(myBelong)%>�̏����ΏۊO�ł��B</font><%end if%>
		<%if mode = 3 then%><font color=red>�Y������Ɩ��͊��Ƀ��b�N����܂����B</font><%end if%>
		<%if mode = 4 then%><br><br>
			�Y���䒠�ԍ��́w<%=GetFullName(session("CTM_CostsClient"))%>�x�̎�z�L�^���Ȃ��ł����A<br>
			����ł��o�^���Ă�낵���ł����H<br><br>
			<input type=button style="width:90;height:30" name=btnOK value="�͂�" onclick="DoProc()">�@
			<input type=button style="width:90;height:30" name=btnNo value="������" onclick="DoCancel()">
		<%end if%>
	</table>
  </FORM>
<center>
<script language=vbscript>
	window.parent.parent.parent.result.location.href = "CostsResult.asp?type=1"
</script>
</body></html>

<%
function CheckCostsClient(myJob, myClient)
dim myCon
dim myRec
dim mySql
	CheckCostsClient = false
	if CheckJobType(myJob) <> gsImport then
		CheckCostsClient = true
	else
		OpenSQL myCon, SqlServerName, DatabaseName
		Set myRec = Server.CreateObject ("ADODB.Recordset")
		with myRec
			mySql = "SELECT SeqNo FROM TBL_CTM_DELIVERY WHERE Deleted = 0 "
			mySql = mySql & " AND JobCode = '" & myJob & "' AND DeliveryBroker = '" & myClient & "'"
			.Open mySql, myCon, adOpenForwardOnly, adLockReadOnly 
			if not .eof then CheckCostsClient = true
			.Close
		end with
		set myRec = nothing
		CloseDB Conn
	end if
end function
%>