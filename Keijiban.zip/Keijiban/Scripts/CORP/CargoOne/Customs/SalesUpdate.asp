<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�x���`�[���ה�p����
'----------------------------------------------

	SeqNo = GetLong(request("SeqNo"))
	JobCode = GetPost(request("JobCode"))
	ChargeNo = GetPost(request("ChargeNo"))
	ExpenseAttr = GetLong(request("ExpenseAttr"))
	ExpenseMemo = GetPost(request("ExpenseMemo"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")	
		
	if JobCode <> "" and ChargeNo <> "" then
		with Recset				
			strSql = "SELECT FinisherID FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if .eof then 
				JobCode = ""
			else
				FinisherID = GetLong(.fields("FinisherID"))
			end if
			.close
		end with
		
		if JobCode = "" then
			ShowMessage "�Y�����鐿�����ԍ��͕s���ł��B"
		elseif FinisherID <> 0 then
			JobCode = ""
			ShowMessage "�Y�����鐿�����ԍ��͊��ɏ�������܂����B"
		end if
	end if
	
	if JobCode <> "" then
		
		strSql = "UPDATE TBL_CTM_EXPENSE SET ExpenseAttr = " & ExpenseAttr
		strSql = strSql & ", ExpenseMemo = '" &  ExpenseMemo & "'"
		strSql = strSql & ", Updater = " &  WebUserID & ", Updated = GETDATE()"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseBill = '" & ChargeNo & "' AND SeqNo = " & SeqNo
		Conn.Execute strSql
%>
<html>
	<script language=javascript>
		window.opener.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>";
		window.close();
	</script>
</html>
<%	
	end if
	set Recset = nothing
	CloseDB Conn
%>