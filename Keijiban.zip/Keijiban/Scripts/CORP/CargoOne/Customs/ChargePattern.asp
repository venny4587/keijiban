<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim ChargeNo
dim ChargeDate
dim ChargeClient
dim PatternID

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	JobCode = GetString(Request("JobCode"))
	ChargeNo = GetString(Request("ChargeNo"))
	PatternID = GetLong(Request("PatternID"))
	Recset.Open "SELECT ChargeClient, ChargeDate FROM TBL_CTM_CHARGE WHERE ChargeNo='" & ChargeNo & "'", Conn ,adOpenKeyset ,adLockReadOnly
	if not Recset.EOF then 
		ChargeDate = GetString(Recset.Fields("ChargeDate"))
		ChargeClient = GetString(Recset.Fields("ChargeClient"))
	end if
	Recset.Close
	
	myMode = GetLong(request("mode"))
	if myMode = 1 then
		msg = ""
		SeqNo = GetString(Request("SeqNo"))
		
		if PatternID <> 0 then
			strSQL = "SELECT ExpenseID AS SeqNo, COST_CD, ExpenseCost, ExpensePrice, ExpenseUnit, ExpenseTaxName, ExpenseMemo"
			strSQL = strSQL & ", Remarks FROM PTN_EXPENSE INNER JOIN MST_COST ON PTN_EXPENSE.ExpenseCost = MST_COST.COST_ID"
			strSQL = strSQL & " WHERE PatternID = " & PatternID & " AND ExpenseID IN (" & SeqNo & ")"
			strSQL = strSQL & " ORDER BY COST_CD, ExpenseMemo"
		else
			strSQL = "SELECT SeqNo, COST_CD, ExpenseCost, ExpensePrice, ExpenseQuantity, ExpenseUnit, ExpenseTaxName, ExpenseTax, ExpenseAmount"
			strSQL = strSQL & ",ExpenseMemo, Remarks FROM TBL_CTM_EXPENSE INNER JOIN MST_COST ON TBL_CTM_EXPENSE.ExpenseCost = MST_COST.COST_ID"
			strSQL = strSQL & " WHERE Deleted = 0 AND ExpenseType = " & gsPayment & " AND SeqNo IN (" & SeqNo & ")"
			strSQL = strSQL & " ORDER BY COST_CD, SeqNo"
		end if
		Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if Recset.EOF then msg = "�Y����ڂ͌�����܂���ł����B"
		
		if msg = "" then
			
			Conn.BeginTrans
			
			call GetChargePattern(Recset, PatternID)
			
			'�������X�V
			ChargeAmount = 0
			ChargeTax = 0
			with Recset
				strSql = "SELECT SUM(ExpenseAmount) AS ChargeAmount, SUM(ExpenseTax) AS ChargeTax FROM TBL_CTM_EXPENSE"
				strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
				strSql = strSql & " AND ExpenseType IN (" & gsCharge & "," & gsStand & ")"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					ChargeAmount = GetLong(.fields("ChargeAmount"))
					ChargeTax = GetLong(.fields("ChargeTax"))
				end if
				.close
			end with
		
			strSql = "UPDATE TBL_CTM_CHARGE SET ChargeAmount = " &  GetLong(ChargeAmount) & ", ChargeTax = " &  GetLong(ChargeTax)
			strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			Conn.Execute strSql
						
			if err.number = 0 then
				Conn.CommitTrans
			else
				Conn.RollbackTrans
				msg = "���������L�̃G���[���N����܂����B(" & err.number & ":" & err.description & ")"
			end if
		end if
		if msg <> "" then
			ShowMessage msg
		else
%>
<html><script language=vbscript>
window.opener.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>"
window.opener.parent.list.location.href = "ChargeBill.asp?JobCode=<%=JobCode%>"
window.close
</script></html>
<%
		end if
	else
%>
<HTML>
<HEAD>
	<TITLE><%=myTitle%></TITLE>
	<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
	<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	<SCRIPT LANGUAGE="VBScript">
		function ShowPattern(myID)
			window.location.href = "ChargePattern.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>&PatternID=" & myID
		end function
		
		function DoCheck()
			Call CheckAll("SeqNo", frmInput.CheckAll.Checked)
		end function 
		
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 5) = "SeqNo" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "������p��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("����ł�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.submit()
		end function 
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
			if window.event.keyCode=120 then call DoConfirm()
		end sub
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsSalesBackColor%>" class=pt9n onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ChargePattern.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value="1">
		<input type=hidden name="JobCode" value="<%=JobCode%>">
		<input type=hidden name="ChargeNo" value="<%=ChargeNo%>">
		<input type=hidden name="PatternID" value="<%=PatternID%>">
		<TABLE width=100%><TR>
			<!----------left---------->
			<TD width=40% ALIGN=center VALIGN=TOP>
				<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  			<TR height=18>
		  				<td class=pt9n>�������p�^�[���ꗗ&nbsp;
		  			<TR><td><hr width=98% size=1 color=blue>
				</table>
				<TABLE width=90% BORDER=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9n>
					<TR height=24 ALIGN=CENTER bgcolor=#E0E0E0>
						<TD nowrap width=10%>No.</TD>
						<TD nowrap width=20%>����</TD>
						<TD nowrap width=50%>�a������</TD>
						<TD nowrap width=10%>����</TD>
			<%
				With Recset
					cnt = 0
					strSql = "SELECT COUNT(SeqNo) AS CNT FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "'"
					strSql = strSql & " AND Deleted = 0 AND ExpenseBill = '' AND ExpenseType = " & gsPayment	'�������x��
					.Open strSql, Conn ,adOpenKeyset ,adLockReadOnly
					if not .eof then cnt = GetLong(.fields("CNT"))
					.Close
					mybgcolor = "#FFFFFF"
					If PatternID = 0 Then mybgcolor = "#C0FFC0"
					response.write "<TR height=24 style=""cursor:hand"" onmousedown=""ShowPattern(0)"">"
					response.write "<TD nowrap bgcolor=#E0E0E0 align=center>0"
					response.write "<TD bgcolor=" & mybgcolor & " colspan=2>�������׈ꗗ�i���������j"
					response.write "<TD bgcolor=" & mybgcolor & " align=center>" & cnt
					
					cnt = 0
					strSql = ""
					strSql = strSql & "SELECT CASE PATN_CREATER WHEN " & WebUserID & " THEN 0 ELSE 1 END AS kb,"
					strSql = strSql & " PATN_ID, PATN_CD, PATN_NAME, PATN_CNT FROM MST_PATTERN LEFT JOIN ("
					strSql = strSql & "SELECT PatternID, COUNT(ExpenseCost) AS PATN_CNT FROM PTN_EXPENSE GROUP BY PatternID"
					strSql = strSql & ") AS TMP ON MST_PATTERN.PATN_ID = TMP.PatternID WHERE PATN_DELETED = 0"
					strSql = strSql & " AND PATN_TYPE = 0 AND PATN_BELONG = '" & CheckJobType(JobCode) & "'"				
					Recset.Open strSql & " AND CTM_CD = '" & ChargeClient & "' ORDER BY kb, PATN_CD", Conn ,adOpenKeyset ,adLockReadOnly
					if Recset.EOF then
						Recset.Close
						Recset.Open strSql & " AND CTM_CD = '" & gsDummy & "' ORDER BY kb, PATN_CD", Conn ,adOpenKeyset ,adLockReadOnly
					end if
					Do while not .EOF
						cnt = cnt + 1
						mybgcolor = "#FFFFFF"
						If PatternID = GetLong(.Fields("PATN_ID")) Then	mybgcolor = "#C0FFC0"
						myName = GetString(.Fields("PATN_NAME"))
			%>
					<TR height=24 style="cursor:hand" onmousedown="ShowPattern(<%=GetLong(.Fields("PATN_ID"))%>)">
						<TD nowrap bgcolor=#E0E0E0 align=center><%=cnt%>
						<TD nowrap bgcolor="<%=mybgcolor%>"><%=GetString(.Fields("PATN_CD"))%>
						<TD bgcolor="<%=mybgcolor%>"><%=myName%>
						<TD nowrap bgcolor="<%=mybgcolor%>" align=center><%=GetLong(.Fields("PATN_CNT"))%>
			<%
						.MoveNext
					Loop
					.Close
				End With
			%>
				</TABLE>
			
			<!----------right---------->
			<TD width=60% VALIGN=TOP align=center class=pt9>
				<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		  			<TR height=18>
		  				<td width=50% align=left>����p���׈ꗗ&nbsp;
	 	  				<td width=50% align=right><img style="cursor:hand" src=img/save.gif alt="�m��" onmousedown="DoConfirm()">&nbsp;
		  			<TR><td colspan=2><hr width=98% size=1 color=blue>
				</table>
				<%
					if PatternID <> 0 then
						lngCount = 0
						strSQL = "SELECT ExpenseID AS SeqNo, COST_CD, COST_NAME, ExpensePrice, ExpenseUnit, ExpenseTaxName, ExpenseMemo"
						strSQL = strSQL & ",Remarks FROM PTN_EXPENSE INNER JOIN MST_COST ON PTN_EXPENSE.ExpenseCost = MST_COST.COST_ID"
						strSQL = strSQL & " WHERE PatternID = " & PatternID
						strSQL = strSQL & " ORDER BY COST_CD, ExpenseMemo"
					else
						strSQL = "SELECT SeqNo, COST_CD, COST_NAME, ExpensePrice, ExpenseUnit, ExpenseTaxName, ExpenseMemo, Remarks"
						strSQL = strSQL & " FROM TBL_CTM_EXPENSE INNER JOIN MST_COST ON TBL_CTM_EXPENSE.ExpenseCost = MST_COST.COST_ID"
						strSQL = strSQL & " WHERE Deleted = 0 AND ExpenseType = " & gsPayment & " AND JobCode = '" & JobCode & "'"
						strSQL = strSQL & " ORDER BY COST_CD, SeqNo"
					end if
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not recset.EOF then
				%>
				<TABLE width=90% BORDER=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9n>
					<TR ALIGN=CENTER bgcolor=#E0E0E0>
						<TD nowrap width=5%>No.
						<TD nowrap width=50%>��p����
						<TD nowrap width=10%>�P��
						<TD nowrap width=15%>�P��
						<TD nowrap width=10%>�ŋ敪
						<TD nowrap width=10%><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�I��
				<%
						With Recset
							cnt = 0
							Do While not .EOF
								cnt = cnt + 1
								myName = GetString(.Fields("COST_NAME"))
								myMemo = GetString(.Fields("ExpenseMemo"))
								if myName = "���̑�����" OR myName = "RANDOM" then 
									if myMemo <> "" then myName = myMemo
								elseif myMemo <> "" then 
									myName = myName & " [" & left(myMemo, 17) & "]"
								end if
								myPrice = GetDouble(.Fields("ExpensePrice"))
								myUnit = GetString(.Fields("ExpenseUnit"))
								myRemark = GetString(.Fields("Remarks"))
								if myRemark = "" then
				%>
					<TR align=center>
						<TD bgcolor=#E0E0E0><%=cnt%><BR>
						<TD nowrap align=left><%=myName%><BR>
						<TD nowrap <%=ShowTitle(myUnit,6)%>><%=stringCut(myUnit,6)%><BR>
						<TD nowrap align=right><%=FitZero(formatnumber(myPrice, 2, true))%><BR>
						<TD nowrap><%=GetString(.Fields("ExpenseTaxName"))%><BR>
						<TD><input type=checkbox name="SeqNo" value="<%=GetLong(.Fields("SeqNo"))%>">
				<%
								else
				%>
					<TR align=center>
						<TD rowspan=2 bgcolor=#E0E0E0><%=cnt%><BR>
						<TD nowrap align=left><%=myName%><BR>
						<TD nowrap <%=ShowTitle(myUnit,6)%>><%=stringCut(myUnit,6)%><BR>
						<TD nowrap align=right><%=FitZero(formatnumber(myPrice, 2, true))%><BR>
						<TD nowrap><%=GetString(.Fields("ExpenseTaxName"))%><BR>
						<TD rowspan=2><input type=checkbox name="SeqNo" value="<%=GetLong(.Fields("SeqNo"))%>">
					<TR><TD colspan=4 class=pt9g><%=myRemark%><BR>
				<%
								end if
								.MoveNext
							Loop
							.Close
						End With
					else
						Response.Write "<br><div align=center class=pt9n>�Y���f�[�^��������܂���ł����B</div>"	
					end if
				%>
				</TABLE>
<!--
				<br>
				<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
		  			<TR><td align=center>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="F9:�m��" OnClick="DoConfirm()">�@�@
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnClose VALUE="����" OnClick="window.close()">
				</table>
-->
		</TABLE>
	</FORM>
</BODY>
</HTML>
<%
	end if
	Set Recset = Nothing
	CloseDB Conn
%>

<%
'���̉�ʂ̂݌Ăяo���A�p�����[�^�s�v�A�w�b�_��`�ς�
function GetChargePattern(myRs, myID)
dim mySql
dim myRec
dim mySeq
dim myPrc
dim myTax
dim myQty
dim myUnit
dim myAmount
dim myRemarks
dim cbmQty
dim airKgs
dim pkgCnt
dim pkgUnit
dim mySheet
dim myCheck
dim myCustom

	'�����p�^�[���ǉ�
	Set cmdSQL = Server.CreateObject("ADODB.Command")
	Set cmdSQL.ActiveConnection = Conn
	cmdSQL.CommandType = 4
	cmdSQL.CommandText = "DB_CTM_NEW_SUB"
	cmdSQL.Parameters.Refresh
	cmdSQL.Parameters("@SubCode").Value = "Expense"
	
	set myRec = Server.CreateObject("adodb.recordset")
	mySql ="SELECT GW, RTON, Quantity, Package, CustomSheet FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if not myRec.eof then 
		airKgs = GetDouble(myRec.fields("GW"))
		cbmQty = GetDouble(myRec.fields("RTON"))
		pkgCnt = GetDouble(myRec.fields("Quantity"))
		pkgUnit = GetString(myRec.fields("Package"))
		mySheet = GetString(myRec.fields("CustomSheet"))
	end if
	myRec.Close

	'�ʊ֑��������m�F
	myCheck = CheckSheet(JobCode, mySheet)
	if myCheck > 0 then
		mySql ="SELECT SeqNo FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseType = " & gsCharge
		mySql = mySql & " AND ExpenseClient = '" & ChargeClient & "' AND ExpenseCost = 67 AND ExpenseMemo = '����'"
		myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly 
		if not myRec.eof then myCheck = 0
		myRec.Close
	end if
	
	mySql ="SELECT * FROM TBL_CTM_EXPENSE"
	myRec.Open mySql, Conn, adOpenKeyset, adLockOptimistic 
	do while not myRs.eof
		myPrc = GetDouble(myRs.fields("ExpensePrice")) 
		myUnit = GetString(myRs.fields("ExpenseUnit"))
		myRemarks = GetString(myRs.fields("Remarks"))
		if myID > 0 then
			select case GetString(myRs.fields("ExpenseUnit")) 
			case "�l3", "TON", "RTON":		myQty = cbmQty
			case "KGS":						myQty = airKgs
			case pkgUnit:					myQty = pkgCnt
			case "C/S"
				if ucase(left(pkgUnit, 4)) = "CASE" then myQty = pkgCnt
			case "C/T"
				if ucase(left(pkgUnit, 6)) = "CARTON" then myQty = pkgCnt
			case "D/M"
				if ucase(left(pkgUnit, 4)) = "DRUM" then myQty = pkgCnt
			case "PCS"
				if ucase(left(pkgUnit, 6)) = "PIECE" then myQty = pkgCnt
			case "P/K"
				if ucase(left(pkgUnit, 7)) = "PACKAGE" then myQty = pkgCnt
			case "P/L", "P/T"
				if ucase(left(pkgUnit, 6)) = "PALLET" then myQty = pkgCnt
			case "SKID"
				if ucase(left(pkgUnit, 4)) = "SKID" then myQty = pkgCnt
			case else
				myQty = 1
				if GetLong(myRs.fields("ExpenseCost")) = 67 then
					if myCheck > 0 then
					   	if GetString(myRs.fields("ExpenseMemo")) = "����" then 
							myQty = myCheck
							myCheck = 0
						elseif myUnit = "��" then
							myCustom = myPrc
						else
							myCheck = 0
						end if
					end if
				end if
			end select
			if myQty < 1 then myQty = 1
			if left(myRemarks, 4) = "����" and instr(myRemarks, "�~") > 5 then
				myMin = GetLong(mid(myRemarks, 5, instr(myRemarks, "�~") - 5))
				if myPrc * myQty < myMin then 
					myPrc = myMin
					myQty = 1
					myUnit = "M/M"
				end if
			end if
			myAmount = GetLong(myPrc * myQty)
			myTax = GetLong(ResetDigital(myAmount * GetTaxRate(myRs.fields("ExpenseTaxName")), 0, -1))
		else
			myQty = GetDouble(myRs.fields("ExpenseQuantity"))
			myAmount = GetLong(myRs.fields("ExpenseAmount"))
			myTax = GetLong(myRs.fields("ExpenseTax"))
		end if
		
		'SeqNo�擾
		cmdSQL.Execute
		mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
		with myRec
			.AddNew
			.fields("JobCode") = JobCode
			.fields("SeqNo") = mySeq
			.fields("ExpenseClient") = ChargeClient
			.fields("ExpenseDate") = ChargeDate
			.fields("ExpenseType") = gsCharge
			.fields("ExpenseAttr") = 0
			if CheckJobType(JobCode) = gsImport and left(ChargeClient, 3) = "690" then
				select case GetLong(myRs.fields("ExpenseCost"))
				case 4, 14, 67		'�萔���E�h���[�E�ʊ֗�
					.fields("ExpenseAttr") = 1		'�L�ʌ���
				end select
			end if
			.fields("ExpenseCost") = GetLong(myRs.fields("ExpenseCost"))
			.fields("ExpenseUnit") = myUnit
			if myUnit <> "M/M" then
				.fields("ExpensePrice") = myPrc
				.fields("ExpenseQuantity") = myQty
			end if
			.fields("ExpenseAmount") = myAmount
			.fields("ExpenseTax") = myTax
			.fields("ExpenseTaxName") = GetString(myRs.fields("ExpenseTaxName"))
			
			.fields("ExpenseBill") = ChargeNo
			.fields("ExpenseMemo") = GetString(myRs.fields("ExpenseMemo"))
			.fields("Remarks") = myRemarks
			
			.fields("Updater") = WebUserID
			.fields("Creater") = WebUserID
			.update
		end with
		myRs.movenext
	loop
	if myCheck > 0 then
		'SeqNo�擾
		cmdSQL.Execute
		mySeq = GetLong(cmdSQL.Parameters("@CurrentID").Value)
		with myRec
			.AddNew
			.fields("JobCode") = JobCode
			.fields("SeqNo") = mySeq
			.fields("ExpenseClient") = ChargeClient
			.fields("ExpenseDate") = ChargeDate
			.fields("ExpenseType") = gsCharge
			.fields("ExpenseAttr") = 0
			.fields("ExpenseCost") = 67
			.fields("ExpenseUnit") = "��"
			.fields("ExpensePrice") = GetLong(myCustom)
			.fields("ExpenseQuantity") = myCheck
			.fields("ExpenseAmount") = GetLong(myCustom) * myCheck
			.fields("ExpenseTax") = 0
			.fields("ExpenseTaxName") = "��ې�"
			.fields("ExpenseBill") = ChargeNo
			.fields("ExpenseMemo") = "����"
			.fields("Remarks") = myRemarks
			
			.fields("Updater") = WebUserID
			.fields("Creater") = WebUserID
			.update
		end with
	end if
	myRs.close
	myRec.close
	set myRec = nothing
	
end function

function CheckSheet(myJob, mySheet)
dim buf
	buf = GetLong(right(mySheet, 2))
	if CheckJobType(myJob) = gsExport then
		if buf <= 3 then
			CheckSheet = 0
		else
			CheckSheet = ((buf - 3) \ 5)
			if ((buf - 3) mod 5) > 0 then CheckSheet = CheckSheet + 1
		end if
	else
		if buf <= 2 then
			CheckSheet = 0
		else
			CheckSheet = ((buf - 2) \ 4)
			if ((buf - 2) mod 4) > 0 then CheckSheet = CheckSheet + 1
		end if
	end if
end function
%>