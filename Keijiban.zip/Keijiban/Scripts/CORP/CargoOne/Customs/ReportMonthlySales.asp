<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�q�ʔ��㌎�ʐ��ڕ\
'----------------------------------------------
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobType = GetPost(request("JobType"))
	JobBelong = GetPost(request("JobBelong"))
	JobSalesman = GetLong(request("JobSalesman"))
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 4  then JobBelong = UserShop
	
	mySort = GetLong(request("sort"))
	if mySort = 0 then mySort = 1
	
	SelName = GetString(request("SelName"))
	if SelName = "" then SelName = "jp"
		
	SelYear = GetLong(request("SelYear"))
	if SelYear = 0 then 
		if month(date) > 4 then 
			SelYear = year(date)
		else
			SelYear = year(date) - 1
		end if
		if myLevel < 4  then JobSalesman = WebUserID
	end if
		
	call GetAccountYear(SelYear, AccountFrom, AccountTo)

%>

<HTML>
<HEAD>
	<TITLE>�q�ʔ��㌎�ʐ��ڕ\</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		sub DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.Submit()
		end sub
			
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ReportMonthlySales.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="AccountMonth" VALUE='<%=AccountMonth%>'>
		<input type=hidden name="sort" value="<%=mySort%>">
		<table class=pt9>
			<TR><TD nowrap>�Ɩ�����
<%if myLevel > 3 then%>
	  			<select name=JobBelong onkeydown="ResetEnter()"><option value="">�S��<%=ShowShopList(JobBelong)%></select>&nbsp;
<%else%>
					<input type=hidden name="JobBelong" value="<%=JobBelong%>">
					<u>&nbsp;<font color=green><%=GetShopName(JobBelong)%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�c�ƒS��
<%if myLevel > 1 then%>
					<select name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
						<%=ShowEmployList(DepartSales, JobSalesman)%>
					</select>&nbsp;
<%else%>
					<input type=hidden name="JobSalesman" value="<%=JobSalesman%>">
					<u>&nbsp;<font color=green><%=GetEmployName(JobSalesman, "F")%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�Ɩ��敪
					<select name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>&nbsp;
				<TD nowrap>�׎喼��
					<select name="SelName" onkeydown="ResetEnter()">
						<option value="jp" <%if SelName = "jp" then response.write "selected"%>>�a������
						<option value="en" <%if SelName = "en" then response.write "selected"%>>�p������
						<option value="ref" <%if SelName = "ref" then response.write "selected"%>>��������
						<option value="abr" <%if SelName = "abr" then response.write "selected"%>>�a������
					</select>&nbsp;				
				<TD nowrap>�Ώ۔N�x
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N&nbsp;
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
<div id=list>
�Ώ۔N�x�F<%=ShowJpnYear(left(AccountFrom,4))%><%=GetJapanNo(right(AccountFrom,2))%>���`<%=ShowJpnYear(left(AccountTo,4))%><%=GetJapanNo(right(AccountTo,2))%>��
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup span=3 align=left>
		<colgroup span=13 align=right>
		<TR>
			<TD>��
<%select case SelName%>
<%case "jp"%><TD style="cursor:hand;" onmousedown="DoSort(1)" <%if mySort=1 then%>style="color:blue"<%end if%>>�a������
<%case "en"%><TD style="cursor:hand;" onmousedown="DoSort(2)" <%if mySort=2 then%>style="color:blue"<%end if%>>�p������
<%case "ref"%><TD style="cursor:hand;" onmousedown="DoSort(3)" <%if mySort=3 then%>style="color:blue"<%end if%>>��������
<%case "abr"%><TD style="cursor:hand;" onmousedown="DoSort(4)" <%if mySort=4 then%>style="color:blue"<%end if%>>�a������
<%end select%>
			<TD nowrap>����
<%for i = 1 to 12%>
			<TD nowrap><%if gsSysCloseMonth + i > 12 then%><%=(gsSysCloseMonth + i - 12)%>����<%else%><%=(gsSysCloseMonth + i)%>����<%end if%>
<%next%>	
			<TD nowrap>���v
		
<%
	cnt = 0
	redim sumCount(12)
	redim sumSales(12)
	redim sumStand(12)
	redim sumBenefit(12)	
	for i = 0 to 12 
		sumStand(i) = 0:		sumSales(i) = 0
		sumCount(i) = 0:		sumBenefit(i) = 0
	next
	with recset
		strSql = "SELECT J.*, ISNULL(CTM_REF, 'UNKNOWN') AS ref, ISNULL(CTM_NAME, '���o�^') AS jp, ISNULL(CTM_ENAME, 'UNKNOWN') AS en, ISNULL(CTM_ABR, '���o�^') AS abr "
		strSql = strSql & " FROM (SELECT CTM_FINANCE_CD, AccountDate, COUNT(JobCode) AS Total, SUM(SalesSum+SalesTax) AS Sales, SUM(StandSum) AS Stand, SUM(Interests) AS Benefit"
		strSql = strSql & " FROM TBL_CTM_JOB INNER JOIN CUSTOMER ON TBL_CTM_JOB.JobClient = CUSTOMER.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0 AND CTM_FINANCE_CD <> '" & gsDummy & "'"
		strSql = strSql & " AND AccountDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if JobBelong <> "" then strSql = strSql & " AND JobBelong = '" & JobBelong & "'" 
		if JobType <> "" then strSql = strSql & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if JobSalesman <> 0 then strSql = strSql & " AND JobSalesman = " & JobSalesman
		strSql = strSql & " GROUP BY CTM_FINANCE_CD, AccountDate) AS J INNER JOIN ("
		strSql = strSql & "SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_ENAME, CTM_ABR FROM CUSTOMER) AS C ON J.CTM_FINANCE_CD = C.CTM_CD"
		select case mySort
		case 1:		strSql = strSql & " ORDER BY jp"
		case 2:		strSql = strSql & " ORDER BY en"
		case 3:		strSql = strSql & " ORDER BY ref"
		case 4:		strSql = strSql & " ORDER BY abr"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		myClient = ""
		fromMonth = Str2Date(AccountFrom & "01")
		do while not .EOF
			myName = ResetCorpName(.fields(SelName))
			if myClient <> myName then
				if myClient <> "" then
					cnt = cnt + 1
%>
		<TR>
			<TD rowspan=4><%=cnt%>
			<TD rowspan=4><%=myClient%>
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(myCount(i), 0, true)%>
<%	next%>
		<TR bgcolor="F0FFF0">
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(myStand(i), 0, true)%>
<%	next%>
		<TR>
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(mySales(i), 0, true)%>
<%	next%>
		<TR bgcolor="FFF0F0">
			<TD>�e��
<%for i = 0 to 12%>
		<%if myBenefit(i) < 0 then%>
			<TD class=pt9r><%=formatnumber(myBenefit(i), 0, true)%>
		<%else%>
			<TD><%=formatnumber(myBenefit(i), 0, true)%>
		<%end if%>
<%	next%>
<%
					for i = 0 to 12
						sumCount(i) = sumCount(i) + myCount(i)
						sumSales(i) = sumSales(i) + mySales(i)
						sumStand(i) = sumStand(i) + myStand(i)
						sumBenefit(i) = sumBenefit(i) + myBenefit(i)
					next
				end if
				myClient = myName
				redim myCount(12)
				redim mySales(12)
				redim myStand(12)
				redim myBenefit(12)				
				for i = 0 to 12 
					myStand(i) = 0:		mySales(i) = 0
					myCount(i) = 0:		myBenefit(i) = 0
				next
			end if
			
			curMonth = Str2Date(GetString(.fields("AccountDate")) & "01")
			idx = datediff("m",fromMonth, curMonth)
			
			myCount(idx) = myCount(idx) + GetLong(.fields("Total"))
			mySales(idx) = mySales(idx) + GetLong(.fields("Sales"))
			myStand(idx) = myStand(idx) + GetLong(.fields("Stand"))
			myBenefit(idx) = myBenefit(idx) + GetLong(.fields("Benefit"))
			
			myCount(12) = myCount(12) + GetLong(.fields("Total"))
			mySales(12) = mySales(12) + GetLong(.fields("Sales"))
			myStand(12) = myStand(12) + GetLong(.fields("Stand"))
			myBenefit(12) = myBenefit(12) + GetLong(.fields("Benefit"))
			
			.movenext
		loop
		.Close
	end with
	
	if myClient <> "" then
		cnt = cnt + 1
%>
		<TR>
			<TD rowspan=4><%=cnt%>
			<TD rowspan=4><%=myClient%>
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(myCount(i), 0, true)%>
<%	next%>
		<TR bgcolor="F0FFF0">
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(myStand(i), 0, true)%>
<%	next%>
		<TR>
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(mySales(i), 0, true)%>
<%	next%>
		<TR bgcolor="FFF0F0">
			<TD>�e��
<%for i = 0 to 12%>
		<%if myBenefit(i) < 0 then%>
			<TD class=pt9r><%=formatnumber(myBenefit(i), 0, true)%>
		<%else%>
			<TD><%=formatnumber(myBenefit(i), 0, true)%>
		<%end if%>
<%	next%>
<%
		for i = 0 to 12
			sumCount(i) = sumCount(i) + myCount(i)
			sumSales(i) = sumSales(i) + mySales(i)
			sumStand(i) = sumStand(i) + myStand(i)
			sumBenefit(i) = sumBenefit(i) + myBenefit(i)
		next
	end if
	if cnt > 0 then		
%>
		<TR>
			<TD colspan=2 rowspan=4 align=center>���@�v
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(sumCount(i), 0, true)%>
<%	next%>
		<TR bgcolor="F0FFF0">
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(sumStand(i), 0, true)%>
<%	next%>
		<TR>
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(sumSales(i), 0, true)%>
<%	next%>
		<TR bgcolor="FFF0F0">
			<TD>�e��
<%for i = 0 to 12%>
		<%if sumBenefit(i) < 0 then%>
			<TD class=pt9r><%=formatnumber(sumBenefit(i), 0, true)%>
		<%else%>
			<TD><%=formatnumber(sumBenefit(i), 0, true)%>
		<%end if%>
<%	next%>
<%end if%>
	</TABLE>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>