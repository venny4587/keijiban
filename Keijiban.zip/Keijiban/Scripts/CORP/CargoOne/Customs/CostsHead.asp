<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'----------------------------------------------
'	�����`�[�w�b�_���
'----------------------------------------------

'on error resume next
dim JobClient
dim JobClientName
dim JobBelong
dim JobBroker
dim JobMemo
dim JobFinisher
dim JobLocker
dim JobOperator
dim JobSalesman

	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	if JobBroker = gsCorpCode then			'�{�Јϑ�
		myLevel = CheckUserLevel(gsCorpInit, JobBroker)
		if UserShop <> gsCorpInit and UserShop = left(JobCode, 1) then 
			myLevel = CheckUserLevel(JobBelong, JobBroker)
		end if
	else
		myLevel = CheckUserLevel(JobBelong, JobBroker)
	end if
	if myLevel < 2 and JobSalesman = WebUserID then myLevel = 2
	
	if JobCode <> "" then
		mode = 0
		
		CostsDate = formatDate(date)
		CostsType = 0
		ConfirmerID = 0
		FinisherID = 0
		
		OpenSql Conn, SqlServerName, DataBaseName
		
		CostsNo = GetPost(request("CostsNo"))
		if CostsNo <> "" then
			set Recset = Server.CreateObject("adodb.recordset") 
			with Recset
				strSql = "SELECT * FROM TBL_CTM_COSTS WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then
					mode = 1
					CostsType = GetLong(.fields("CostsType"))
					CostsDate = Str2Date(.fields("CostsDate"))
					
					CostsBillNo = GetString(.fields("CostsBillNo"))
					CostsClient = GetString(.fields("CostsClient"))
					CostsClientName = GetString(.fields("CostsClientName"))
					CostsPic = GetString(.fields("CostsPic"))
					CostsAmount = GetLong(.fields("CostsAmount"))
					CostsTax = GetLong(.fields("CostsTax"))
					CostsCloseDay = Str2Date(.fields("CostsCloseDay"))
					CostsPayDay = Str2Date(.fields("CostsPayDay"))
					CostsBatch = GetString(.fields("CostsBatch"))
					
					CostsMemo = GetString(.fields("CostsMemo"))
					CostsCheck = GetLong(.fields("CostsCheck"))
					Remarks = GetString(.fields("Remarks"))
					
					Creater = GetLong(.fields("Creater"))
					Created = GetDate(.fields("Created"))
					Updater = GetLong(.fields("Updater"))
					Updated = GetDate(.fields("Updated"))
					
					ConfirmerID = GetLong(.fields("ConfirmerID"))
					ConfirmDate = GetDate(.fields("ConfirmDate"))
					FinisherID = GetLong(.fields("FinisherID"))
					FinishDate = GetDate(.fields("FinishDate"))
				end if
				.close
			end with
		end if
		
		if CostsClient <> "" AND CostsPic = "" then CostsPic = GetDftManager(CostsClient)
		if GetCtmClose(CostsClient, CloseSales, CloseStand, CloseCosts) then
			StandClose = ShowClose(CloseStand)
		end if
		if GetCtmSight(CostsClient, SightSales, SightStand, SightCosts) then
			StandSight = ctmCredit(SightStand \ 1000) & ShowPayDay(SightStand mod 1000)
		end if
		
		if mode = 0 then
			CostsCloseDay = Close2Date(CloseStand, CostsDate)
			CostsPayDay = Sight2Date(SightStand, CostsCloseDay)
		end if
%>
<html>
<HEAD>
	<TITLE>�x���`�[�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		sub DoSearch()
		dim cd, dt
			cd = frmInput.ChargeRef.value
			dt = frmInput.CostsDate.value
			dim win
			set win = window.open("ChargerSearch.asp?type=4&cd=" & cd & "&dt=" & dt,"ChargerSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		function ShowDetail()
			window.location.href = "CostsList.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>"
		end function
		
		sub DataLock()
			call DataSave(2)
		end sub
		
		sub DataUnLock()
<%if JobLocker <> 0 then%>
			msgbox "�Y���䒠�ԍ��͊��ɑe�����b�N����܂����B", 48, "�m�F���b�Z�[�W"
<%elseif CheckBatchLocked(CostsBatch) <> 0 then %>
			msgbox "�Y���x���`�[�̃o�b�`���͊��Ɋm�肳��܂����B", 48, "�m�F���b�Z�[�W"
<%else%>
			if msgbox ("�Y���x���`�[�m����������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
<%end if%>
		end sub
				
		sub DoDelete()
			if msgbox ("�Y���x���`�[���폜���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DataSave(mode)
			if checkText("ChargeClient","�x����R�[�h",1) = false then exit sub
			if checkText("ChargeName","�x���於",1) = false then exit sub
			if checkText("CostsBillNo","���萿����", 1) = false then exit sub
			if checkDate("CostsDate","�퐿����", 1) = false then exit sub
			if checkDate("CostsCloseDay","���ߓ�", 1) = false then exit sub
			if frmInput.CostsDate.value > frmInput.CostsCloseDay.value then
				if msgbox("�퐿�����͒��ߓ��ȍ~�ɂȂ��Ă�낵���ł����H", 49, "�m�F���b�Z�[�W") <> 1 then exit sub
			end if
			if checkDate("CostsPayDay","�x����", 1) = false then exit sub
			if checkText("CostsMemo","�x������", 0) = false then exit sub
			if checkLen("CostsMemo","�x������", 250) = false then exit sub
			if checkText("Remarks","�x�����l", 0) = false then exit sub
			if checkLen("Remarks","�x�����l", 250) = false then exit sub
			if mode = 2 then
<%if CostsClient = gsCorpSoko and WebUserID <> gsSokoID then%>
				if msgbox ("�Y���x���`�[�͎Г�������p�ł��B" & vbcrlf & _
							"�ېł̑���Ɋm�肵�Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") <> 1 then exit sub
<%else%>
				if msgbox ("�Y���x���`�[���m�肵�Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
				
		sub ChargeRef_OnChange()
			frmInput.ChargeClient.value = ""
			frmInput.ChargeName.value = ""
		end sub
		sub CostsDate_Onblur()
			frmInput.CostsDate.value = setdate(frmInput.CostsDate.value)
			ResetClosePayDay(0)
		end sub		
		sub CostsCloseDay_Onblur()
			frmInput.CostsCloseDay.value = setdate(frmInput.CostsCloseDay.value)
			ResetClosePayDay(1)
		end sub
		sub CostsPayDay_Onblur()
			frmInput.CostsPayDay.value = setdate(frmInput.CostsPayDay.value)
		end sub
		
		sub ResetClosePayDay(myMode)
		dim cls, pay
			cls = frmInput.CloseStand.value
			pay = frmInput.SightStand.value
			if myMode = 0 then
				frmInput.CostsCloseDay.value = Close2Date(cls, frmInput.CostsDate.value)
			end if
			frmInput.CostsPayDay.value = Sight2Date(pay, frmInput.CostsCloseDay.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=40 then ShowDetail()
<%if ConfirmerID = 0 then%>	if window.event.keyCode=120 then call DataSave(<%=mode%>) <%end if%>
		end sub
		
		sub InitForm()
<%if ConfirmerID <> 0 or myLevel < 1 then %>
			call LockAll()
<%else%>
	<%if mode = 0 then%>
			frmInput.ChargeRef.focus()
	<%else%>
			frmInput.CostsMemo.focus()
	<%end if%>
<%end if%>
			window.parent.parent.result.location.href = "PaymentList.asp?mode=1&JobCode=<%=JobCode%>"
		end sub	
	</SCRIPT>
</Head>
<body bgcolor="<%=gsCostsBackColor%>" leftmargin=0 topmargin=3 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>�������`�[<%if mode=0 then%>�쐬<%else%>���<%end if%>&nbsp;
<%if mode = 1 then
	if ConfirmerID = 0 then 
%>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DoDelete()">
<%	else%>
		  <img style="cursor:hand" src=img/next.gif alt="���ׂ�" onmousedown="ShowDetail()">
<%	end if	
end if%>
		<td width=50% align=right>
<%	if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�����ς�">
<%	elseif ConfirmerID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�m�F�ς�" <%if myLevel > 2 then %>onmousedown="DataUnLock()"<%end if%>>
<%	else %>
	<%	if mode = 1 and (CostsAmount <> 0 or CostsTax <> 0) then %>
	 	  <%if myLevel > 0 then %><img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DataLock()">&nbsp;<%end if%>
	<%	end if %>
	  	  <%if myLevel > 0 then %><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave(<%=mode%>)"><%end if%>
<%	end if %>
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td width=160>&nbsp;�䒠�ԍ��@<font color=#228b22><%=JobCode%></font>
		<td>&nbsp;�����׎�@<font color=#228b22><%=JobClientName%></font>
	</table><br>
	<%=JobHeader%>
  <FORM NAME="frmInput" action="CostsSave.asp" method="post">
  	<input type=hidden name="JobBelong" value="<%=JobBelong%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="CostsNo" value="<%=CostsNo%>">
  	<input type=hidden name="CostsBatch" value="<%=CostsBatch%>">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="CloseStand" value="<%=CloseStand%>">
  	<input type=hidden name="SightStand" value="<%=SightStand%>">
  	<input type=hidden name="ChargePic" value="<%=ChargePic%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=28><!--�x���׎匟���𗬗p���邽�߁@Charge-->
		<TD align=center>�x����<input type=hidden name="ChargeClient" value="<%=CostsClient%>">
		<TD colspan=5><input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(CostsClient)%>" onkeydown="ResetEnter()">
			<%if ConfirmerID = 0 then %><a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a><%end if%>
			<input class=sj name="ChargeName" size=38 maxlength=50 value="<%=CostsClientName%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9g>�x���敪
		<TD width=60 align=center class=gline><%=ShowCostsType(CostsType)%>
	  <TR height=28>
		<TD width=60 align=center nowrap>���臂
		<TD><input class=si name="CostsBillNo" size=15 maxlength=50 value="<%=CostsBillNo%>" onkeydown="ResetEnter()">
		<TD width=60 align=center nowrap>�퐿����
		<TD><input class=si name="CostsDate" size=10 maxlength=10 value="<%=CostsDate%>" onkeydown="ResetEnter()">
		<TD width=60 align=center nowrap class=pt9g>���ߓ�
		<TD><input class=si name="CostsCloseDay" size=10 maxlength=10 value="<%=CostsCloseDay%>" onkeydown="ResetEnter()">
		<TD width=60 align=center nowrap class=pt9g>�x����
		<TD><input class=si name="CostsPayDay" size=10 maxlength=10 value="<%=CostsPayDay%>" onkeydown="ResetEnter()">
	  <tr>
	  	<td><img src=img/spacer.gif height=3>
	  <TR>
		<TD align=center>�x��<br>����
		<TD colspan=5><textarea name="CostsMemo" rows=5 style="width:320"><%=CostsMemo%></textarea>
		<TD colspan=2 align=center class=pt12b>���͊���<br>
			<input type=checkbox name="CostsCheck" value=1 <%if CostsCheck then response.write " checked"%>>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR>
		<TD class=pt9 align=center>�Г�<br>���l
		<TD colspan=5><textarea class=sz name="Remarks" rows=5 style="width:320"><%=Remarks%></textarea>
<%	if mode = 1 and ConfirmerID <> 0 then %>
		<TD colspan=2 align=center class=pt12r>���b�N��
<%	end if %>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD width=60 align=center class=pt9g nowrap>�`�[�ԍ�
		<TD width=60 class=gline align=center><%=CostsNo%><br>
		<TD width=60 align=center class=pt9g nowrap>�ޯ��ԍ�
		<TD width=60 class=gline align=center><%=CostsBatch%><br>
		<TD width=60 align=center class=pt9g nowrap>�Ŕ����z
		<TD width=60 class=gline align=right><%=formatnumber(CostsAmount, 0, true)%>
		<TD width=60 align=center class=pt9g nowrap>�����
		<TD width=60 class=gline align=right><%=formatnumber(CostsTax, 0, true)%>
	  <TR height=24>
		<TD align=center class=pt9g>�쐬��<TD class=gline align=center><%=GetEmployName(Creater, "F")%><br>
		<TD align=center class=pt9g>�쐬��<TD class=gline align=center><%=formatDate(Created)%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=GetEmployName(ConfirmerID, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=formatDate(ConfirmDate)%><br>
	</TABLE>
  </FORM>
<center>
<script language=vbscript>
	window.parent.parent.result.location.href = "CostsResult.asp?JobCode=<%=JobCode%>&CostsDate=<%=CostsDate%>"
</script>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>
