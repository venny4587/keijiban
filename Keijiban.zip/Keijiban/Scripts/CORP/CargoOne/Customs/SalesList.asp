<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	JobCode = GetPost(request("JobCode"))
	SeqNo = GetLong(request("seq"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	with Recset
		strSql = "SELECT SeqNo, ChargeNo, ChargeClient, ChargeClientName, ChargeDate, ChargePayDay, ChargeType"
		strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then 
			 ChargeNo = GetString(.fields("ChargeNo"))
			 ExpenseClient = GetString(.fields("ChargeClient"))
			 ExpenseClientName = GetString(.fields("ChargeClientName"))
			 ChargeDate = GetString(.fields("ChargeDate"))
		end if
		.close
	end with

%>
<HTML>
<HEAD>
	<TITLE>�����ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=javaScript>
		function ShowDetail(myNo) {
			var win = window.open("SalesDetail.asp?JobCode=<%=JobCode%>&SubNo=<%=SeqNo%>&seq="+myNo,"SalesDetail","scrollbars=no,width=600,height=400");
			win.focus();
		}
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td nowrap width=30%>������������&nbsp;
		<td nowrap width=70% class=pt9>
	  		�`�[�ԍ�:<font class=pt9n><%=ChargeNo%></font>
	  		�䒠�ԍ�:<font class=pt9b><%=JobCode%></font>
	</table>
	<hr size=1 color=black>
<%
	with recset
		strSql = "SELECT SeqNo, ExpenseCost, COST_NAME, ConfirmerID, ExpenseClient, ExpenseAttr,"
		strSql = strSql & " ExpenseAmount, ExpenseTax, ExpenseDate, ExpenseBill, ExpensePay, ExpenseType"
		strSql = strSql & " FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
		strSql = strSql & " AND ExpenseBill = '" & SeqNo & "' ORDER BY ExpenseType Desc, ExpenseCost, SeqNo"
'response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap align=center>����
		<TD class=line nowrap align=left>��������
		<TD class=line nowrap>�������z
		<TD class=line nowrap>�����
		<TD class=line nowrap align=center>������
		<TD class=line nowrap align=left>�x����
		<TD class=line nowrap align=center>�敪
<%
			cnt = 0
			ttlTax = 0
			ttlAmount = 0
			ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				CostName = GetString(.Fields("COST_NAME"))
				RefName = GetRefName(GetString(.Fields("ExpenseClient")))
				if GetLong(.Fields("ConfirmerID")) <> 0 then
					status = "<font color=blue>�m</font>"
				else
					status = "<font color=gray>��</font>"
				end if
%>
				<TR align=right height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail(<%=.Fields("SeqNo")%>);">
					<TD class=line><%=cnt%><BR>
					<TD class=line nowrap align=center><%=ShowExpenseType(GetLong(.Fields("ExpenseType")))%>
					<TD class=line nowrap align=left nowrap <%=ShowTitle(CostName, 5)%>><%=StringCut(CostName,5)%><BR>
					<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%><BR>
					<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, true)%><BR>
					<TD class=line nowrap align=center><%=Str2MD(ChargeDate)%><BR>
					<TD class=line nowrap align=left <%=ShowTitle(RefName, 7)%>><%=StringCut(RefName,7)%><BR>
					<TD class=line align=center><%=ShowExpenseAttr(GetLong(.Fields("ExpenseAttr")))%><BR>
<%
				if GetLong(.Fields("ExpenseTax")) = 0 then 
					ttlTaxFree = ttlTaxFree + GetLong(.Fields("ExpenseAmount")) 
				else
					ttlTax = ttlTax + GetLong(.Fields("ExpenseTax"))
					ttlAmount = ttlAmount + GetLong(.Fields("ExpenseAmount"))
				end if
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=3 class=pt9>�ېőΏ�
					<TD class=line nowrap><%=formatnumber(ttlAmount, 0, true)%>
					<TD class=line nowrap><%=formatnumber(ttlTax, 0, true)%>
				<TR align=right height=20>
					<TD colspan=3 class=pt9>��ېŊz
					<TD class=line nowrap><%=formatnumber(ttlTaxFree, 0, true)%>
					<TD colspan=2 class=pt9>�����z
					<TD class=line colspan=2><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%
			end if
%>
	</TABLE>
<%
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
