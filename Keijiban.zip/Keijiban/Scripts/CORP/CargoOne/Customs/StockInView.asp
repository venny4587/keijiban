<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		StockType = 0
		ClientRef = GetPost(request("ClientRef"))
	else
		JobCode = GetPost(request("JobCode"))
		StockType = GetLong(request("StockType"))
		ClientRef = GetPost(request("ClientRef"))
		StockNo = GetPost(request("StockNo"))
		StockPlace = GetPost(request("StockPlace"))
		StockCode = GetPost(request("StockCode"))
		StockName = GetPost(request("StockName"))
		StockFrom = GetPost(request("StockFrom"))
		StockTo = GetPost(request("StockTo"))
		PkgFrom = GetPost(request("PkgFrom"))
		PkgTo = GetPost(request("PkgTo"))
		QtyFrom = GetPost(request("QtyFrom"))
		QtyTo = GetPost(request("QtyTo"))
		StockReferNo = GetPost(request("StockReferNo"))
		Finished = GetLong(request("Finished"))
		
		if PkgFrom <> "" then PkgFrom = GetLong(PkgFrom)
		if PkgTo <> "" then PkgTo = GetLong(PkgTo)
		if QtyFrom <> "" then QtyFrom = GetDouble(QtyFrom)
		if QtyTo <> "" then QtyTo = GetDouble(QtyTo)
		
		if myMode = 2 then
			session("StockIn_Client") = GetString(request("StockClient"))
			if GetString(session("StockIn_Select")) <> "" then 
				session("StockIn_Select") = session("StockIn_Select") & ", "
			end if
			session("StockIn_Select") = session("StockIn_Select") & GetString(request("SeqNo"))
		end if
	end if

if WebUserID = gsAdmin then response.write session("StockIn_Select")

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�݌ɏ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(no)
		dim win
			set win = window.open("StockInDetail.asp?SeqNo=" & no, no, "scrollbars=1,width=600,height=400")
			win.focus()
		end function
		
		function ShowGoods()
		dim win
			set win = window.open("StockGoodsInfo.asp", "StockGoodsInfo", "scrollbars=1,width=600,height=400")
			win.focus()
		end function
		
		function StockFetch(mode)
		dim win
			set win = window.open("StockFetch.asp?JobCode=<%=JobCode%>&Client=<%=ClientRef%>&StockNo=<%=StockNo%>&mode=" & mode, "StockImport", "scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		function StockDivide()
		dim win
			set win = window.open("StockDivide.asp?JobCode=<%=JobCode%>&Client=<%=ClientRef%>", "StockDivide", "scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		function ShowGoods()
		dim win
			set win = window.open("StockGoodsInfo.asp", "StockGoodsInfo", "scrollbars=1,width=600,height=400")
			win.focus()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		function DoSort(mySort)
			frmInput.sort.value = mySort
			frmInput.submit()
		end function
		
		function DoSearch()
			if frmInput.ClientRef.value = "" then
				frmInput.ClientRef.focus()
				msgbox "�׎�̌���������͂��Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			else
				frmInput.submit()
			end if
		end function
		
		function DoSelect()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "SeqNo" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�o�ɂ���݌ɏ��i��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�Y�����i���o�ɂ��Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.mode.value = 2
			frmInput.submit()
		end function
		
		function ShowSelect()
		dim win
			set win = window.open("StockOutDetail.asp", "StockOutDetail", "scrollbars=1,width=800,height=500")
			win.focus()
		end function
		
		sub StockFrom_OnBlur()
			frmInput.StockFrom.value = setdate(frmInput.StockFrom.value)
		end sub		
		sub StockTo_OnBlur()
			frmInput.StockTo.value = setdate(frmInput.StockTo.value)
		end sub		
		sub PkgFrom_OnBlur()
			if frmInput.PkgFrom.value = "" then exit sub
			frmInput.PkgFrom.value = GetLong(frmInput.PkgFrom.value)
		end sub		
		sub PkgTo_OnBlur()
			if frmInput.PkgTo.value = "" then exit sub
			frmInput.PkgTo.value = GetLong(frmInput.PkgTo.value)
		end sub		
		sub QtyFrom_OnBlur()
			if frmInput.QtyFrom.value = "" then exit sub
			frmInput.QtyFrom.value = GetDouble(frmInput.QtyFrom.value)
		end sub
		sub QtyTo_OnBlur()
			if frmInput.QtyTo.value = "" then exit sub
			frmInput.QtyTo.value = GetDouble(frmInput.QtyTo.value)
		end sub	
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		sub StockType_OnChange()
			if frmInput.StockType.selectedIndex > 0 then
				window.location.href = "StockOutView1.asp?ClientRef=" & frmInput.ClientRef.value
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=119 then DoImport()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.ClientRef)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="StockInView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				���ɇ�<input class=sj name="StockNo" value="<%=StockNo%>" maxlength=30 size=12 onkeydown="ResetEnter()">
				�q��<input class=sj name="StockPlace" value="<%=StockPlace%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�i��<input class=si name="StockCode" value="<%=StockCode%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				�i��<input class=sj name="StockName" value="<%=StockName%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				���臂<input class=si name="StockReferNo" value="<%=StockReferNo%>" maxlength=20 size=10 onkeydown="ResetEnter()">
			<TD rowspan=2>
				<INPUT style="width:80px;height:30px;" TYPE=Button VALUE="�V�K���i" onclick="ShowGoods()">
			<TR><TD nowrap>
				�敪&nbsp;<SELECT name="StockType" onkeydown="ResetEnter()">
						<option value="0" <%if StockType=0 then response.write "selected"%>>����
						<option value="1" <%if StockType=1 then response.write "selected"%>>�o��</select>
				���ɓ�<input class=si name="StockFrom" value="<%=StockFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="StockTo" value="<%=StockTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				���ɐ�<input class=sn name="PkgFrom" value="<%=PkgFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="PkgTo" value="<%=PkgTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				�݌ɐ�<input class=sn name="QtyFrom" value="<%=QtyFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="QtyTo" value="<%=QtyTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				�o�ɍ�<input type=checkbox name="Finished" value="1" onkeydown="ResetEnter()" <%if Finished = 1 then response.write "checked"%>>
				<INPUT style="width:60px;height:25px;" TYPE=Button VALUE="����" onclick="DoSearch()">
				<INPUT style="width:60px;height:25px;" TYPE=Button VALUE="����" onclick="ShowDetail(0)">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if StockType <> "" then strSel = strSel & " AND StockType = " & StockType
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'" 
		if ClientRef <> "" then	strSel = strSel & " AND ClientRef = '" & FitSel(ClientRef) & "'"	
		if StockNo <> "" then strSel = strSel & " AND StockNo LIKE '%" & FitSel(StockNo) & "%'"	
		if StockPlace <> "" then strSel = strSel & " AND StockPlace LIKE '%" & FitSel(StockPlace) & "%'"
		if StockCode <> "" then strSel = strSel & " AND StockCode LIKE '%" & FitSel(StockCode) & "%'"
		if StockName <> "" then strSel = strSel & " AND StockName LIKE '%" & FitSel(StockName) & "%'"		
		if StockFrom <> "" then strSel = strSel & " AND StockDate >= '" & Date2Str(StockFrom) & "'"
		if StockTo <> "" then strSel = strSel & " AND StockDate <= '" & Date2Str(StockTo) & "'"
		if PkgFrom <> "" then strSel = strSel & " AND StockPkgCnt >= " & PkgFrom
		if PkgTo <> "" then strSel = strSel & " AND StockPkgCnt <= " & PkgTo
		if QtyFrom <> "" then strSel = strSel & " AND StockPkgZan >= " & QtyFrom
		if QtyTo <> "" then strSel = strSel & " AND StockPkgZan <= " & QtyTo
		if StockReferNo <> "" then strSel = strSel & " AND StockReferNo LIKE '%" & FitSel(StockReferNo) & "%'"
		if Finished = 0 then strSel = strSel & " AND StockPkgZan <> 0"
		
		strSQL = "SELECT S.*, ClientRef FROM TBL_CTM_STOCK AS S INNER JOIN"
		strSQL = strSQL & " (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON S.StockClient = C.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0 " & strSel
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY StockNo"
		case 1:		strSQL = strSQL & " ORDER BY StockDate, StockNo"
		case 2:		strSQL = strSQL & " ORDER BY ClientRef, StockDate, StockNo"
		case 3:		strSQL = strSQL & " ORDER BY JobCode, StockDate, StockNo"
		case 4:		strSQL = strSQL & " ORDER BY StockCode, StockDate, StockNo"
		case 5:		strSQL = strSQL & " ORDER BY StockReferNo, StockDate, StockNo"
		case 6:		strSQL = strSQL & " ORDER BY StockPkgCnt, StockDate, StockNo"
		case 7:		strSQL = strSQL & " ORDER BY StockPkgZan, StockDate, StockNo"
		case 8:		strSQL = strSQL & " ORDER BY StockLot, StockDate, StockNo"
		case 9:		strSQL = strSQL & " ORDER BY StockName, StockDate, StockNo"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				myFlag = 1
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=7 align=center>
			<colgroup align=left>
			<colgroup span=2 align=right>
			<colgroup span=3 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">���ɔԍ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">���ɓ�
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�׎�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�䒠�ԍ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�i��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">���臂
			<TD width=20% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">�i��
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">���Ɍ�
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">�݌ɐ�
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">�q��
			<TD width=4% nowrap>�I��
			<TD width=4% nowrap>�ڍ�
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						StockClient = GetString(.Fields("StockClient"))
						StockPlace = GetString(.Fields("StockPlace"))
						StockName = GetString(.Fields("StockName"))
						StockPkgZan = GetLong(.fields("StockPkgZan"))
						myColor = ""
						if StockPkgZan = 0 then myColor = "style=""color:gray"""
%>
					<TR <%=myColor%>>
						<TD nowrap class=line><%=lngCount%>
						<TD nowrap class=line><%=GetString(.Fields("StockNo"))%>
						<TD nowrap class=line><%=Str2YMD(.Fields("StockDate"))%>
						<TD nowrap class=line><%=GetString(.Fields("ClientRef"))%>
						<TD nowrap class=line><%=GetString(.Fields("JobCode"))%><br>
						<TD nowrap class=line><%=GetString(.Fields("StockCode"))%><br>
						<TD nowrap class=line><%=GetString(.Fields("StockReferNo"))%><br>
						<TD nowrap class=line <%=ShowTitle(StockName, 20)%>><%=stringCut(StockName, 20)%><br>
						<TD nowrap class=line><%=GetLong(.Fields("StockPkgCnt"))%><br>
						<TD nowrap class=line><%=formatnumber(StockPkgZan, 0, true)%><br>
						<TD nowrap class=line><%=GetString(.Fields("StockLot"))%><br>
						<TD nowrap class=line><%if StockPkgZan = 0 then %>��<%else%><input type=checkbox name="SeqNo" value="<%=.Fields("SeqNo")%>"
							<%if instr(" " & session("StockIn_Select") & ",", " " & .Fields("SeqNo") & ",") > 0 then response.write "checked"%>><%end if%>
						<TD nowrap class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=.Fields("SeqNo")%>')">
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
		</TABLE>
		<br>
		<div align=center>
<%	if len(JobCode) = 10 and ClientRef <> "" then%>
			<input type=button value="������" style="width:120;height:30" onclick="StockDivide()">�@
<%	end if%>
			<input type=hidden name="StockClient" value="<%=StockClient%>">
			<input type=button value="�o�ɒǉ�" style="width:120;height:30" onclick="DoSelect()">
<%	if Session("StockIn_Select") <> "" then%>
			<input type=button value="�o�ɏ���" style="width:120;height:30" onclick="ShowSelect()">
<%	end if%>
		</div>
<%
			else
				myFlag = 0
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"
				if len(JobCode) = 10 and (UCASE(ClientRef) = "ENAJI" OR UCASE(ClientRef) = "TRUST") then
%>
		<br>
		<div align=center>
			<input type=button value="�ېœ���ODN" style="width:120;height:30" onclick="StockFetch(1)">�@
			<input type=button value="�ېœ���WEB" style="width:120;height:30" onclick="StockFetch(2)">
		</div>
<%
				end if
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>