<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next
	
dim CloseSales
dim CloseStand
dim CloseCosts
dim SalesCloseDate
dim StandCloseDate
dim CostsCloseDate

dim ChargeSales
dim ChargeStand
dim ChargeCosts
dim SalesSightDate
dim StandSightDate
dim CostsSightDate

	myMode = GetLong(request("mode"))
	myType = GetLong(request("Type"))
	JobCode = GetPost(request("JobCode"))
	CostsNo = GetPost(request("CostsNo"))
	
if JobCode <> "" and CostsNo <> "" then
	
	OpenSql Conn, SqlServerName, DataBaseName

	strSQL = "UPDATE TBL_CTM_COSTS SET CostsCheck = 1"
	strSQL = strSQL & ",Updated = GETDATE()"
	strSQL = strSQL & ",Updater = " & WebUserID
	strSQL = strSQL & " WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"	
	Conn.Execute strSQL

	if myMode = 1 then
	
		SeqNo = GetNewAcntNo(Conn, 0)
		ChargeNo = GetAccountNo(SeqNo, 0)		'���֐���
		
		CTM_CD = GetPost(request("JobClient"))
		if GetCtmClose(CTM_CD, CloseSales, CloseStand, CloseCosts) then	StandCloseDate = Close2Date(CloseStand, date)
		
		if GetCtmSight(CTM_CD, ChargeSales, ChargeStand, ChargeCosts) then		
			StandSightDate = FitDatePlus(Sight2Date(ChargeStand, StandCloseDate))
			if Date2Str(StandSightDate) = Date2Str(StandCloseDate) then StandSightDate = FitDatePlus(dateadd("d", 7, StandSightDate))			
		end if
				
		set Recset = Server.CreateObject("adodb.recordset")
		with Recset
			strSql = "SELECT * FROM TBL_CTM_CHARGE WHERE JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then
				.AddNew
				.fields("JobCode") = JobCode
				.fields("ChargeNo") = ChargeNo
				.fields("ChargeType") = gsStand
				
				.fields("Creater") = WebUserID
				.fields("Created") = now
				.fields("Deleted") = 0
			end if
				
			.fields("ChargeBelong") = GetString(request("JobBelong"))
			.fields("ChargeClient") = CTM_CD
			.fields("ChargeClientName") = GetFullName(CTM_CD)
			.fields("ChargePic") = GetDftManager(CTM_CD)
			.fields("ChargeDate") = Date2Str(StandCloseDate)
			.fields("ChargePayDay") = Date2Str(StandSightDate)
			.fields("ChargeAmount") = GetLong(Request("ChargeAmount"))
			.fields("ChargeTax") = 0
			
			.fields("ChargeBatch") = ""
			.fields("ChargeMemo") = ""
			.fields("ChargeCheck") = 1				'���͊���
			.fields("Remarks") = "���֌��������쐬"
			
			.fields("Updater") = WebUserID
			.fields("Updated") = now()
			.update
			.close
		end with
		
		strSQL = "UPDATE TBL_CTM_COSTS SET ConfirmDate = GETDATE(), ConfirmerID = " & WebUserID
		strSQL = strSQL & " WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"	
		Conn.Execute strSQL
		
		strSQL = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = GETDATE(), ConfirmerID = " & WebUserID & ", ExpenseBill = '" & ChargeNo & "'"
		strSQL = strSQL & " WHERE ExpenseType = " & gsStand & " AND JobCode = '" & JobCode & "' AND ExpensePay = '" & CostsNo & "'"
		Conn.Execute strSQL
	
	end if

	CloseDB Conn
End If
	
	
%>
<html>
<script language=javascript>
<%	select case myType
	case 0				'����%>
//		window.location.href = "CostsHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
		window.location.href = "CostsInput.asp";
		window.parent.parent.result.location.href = "CostsResult.asp";
<%if myMode = 1 then%>
		var win = window.open("MainFrame.asp?mode=1&JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>", "", "resizable=1,scrollbars=1,width=960,height=640");
		win.focus();
<%end if%>

<%	case 1 				'���� %>
//		window.location.href = "CloseHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
		window.location.href = "CloseInput.asp";
		window.parent.parent.parent.result.location.href = "CostsResult.asp?type=1";
<%	case else			'���� %>
		window.parent.list.location.href = "CostsBill.asp?JobCode=<%=JobCode%>";
		window.parent.parent.info.location.href = "ExpenseInfo.asp?JobCode=<%=JobCode%>";
		window.location.href = "PaymentHead.asp?type=2&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
<%	end select %>
</script>
</html>