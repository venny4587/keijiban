<HTML>
<HEAD>
<TITLE>��������</TITLE>
</HEAD>
	<FRAMESET rows="60,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="ChargeMenu.asp" NAME="cmenu" MARGINWIDTH="0" MARGINHEIGHT="0">
		<FRAME SRC="ChargeStats.asp" NAME="cbody" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>