<HTML>
<HEAD>
<TITLE>�ʊ֌����߃��C�����</TITLE>
</HEAD>
	<FRAMESET rows="50,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="closemenu.asp" NAME="lockmenu" MARGINWIDTH="0" MARGINHEIGHT="0" noresize scrolling=no>
		<FRAME SRC="" NAME="lock" MARGINWIDTH="10" MARGINHEIGHT="0" noresize>
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>