<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	mode = GetLong(request("mode"))
	JobBelong = GetPost(request("JobBelong"))
	JobType = GetPost(request("JobType"))
	if JobType = "" then JobType = GetInitJobType()
	
	JobArea = GetPost(request("JobArea"))
	if JobArea = "" then JobArea = "���A�W�A"
	
	OpenSql Conn, SqlServerName, DataBaseName

	if mode > 1 then
		JobCountry = GetPost(request("JobCountry"))
		JobClient = GetPost(request("JobClient"))
		JobShipper = GetPost(request("JobShipper"))
		'JobManager = GetLong(request("JobManager"))
		'JobImport = GetLong(request("JobImport"))
		'JobExport = GetLong(request("JobExport"))
		POLN = GetPost(request("POLN"))
		POL = GetPortName(request("POL"))
		PODN = GetPost(request("PODN"))
		POD = GetPortName(request("POD"))
		
		if JobCountry <> "" and JobClient <> "" and JobShipper <> "" then
			
			JobInit = JobBelong & JobType & Num2Code(year(date)-2000) & Num2Code(Month(date)) & "-"
			
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_CTM_NEW_JOB"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@JobInit").Value = JobInit
			cmdSQL.Execute
			JobCode = JobInit & right("0000" & GetLong(cmdSQL.Parameters("@MaxID").Value),5)
			
			strSql = "INSERT TBL_CTM_JOB (JobCode, JobBelong, JobCountry, JobClient, JobShipper, CustomBroker, POLN, POL, PODN, POD, JobSalesman, JobOperator,  Creater)"
			strSql = strSql & " VALUES ('" & JobCode & "','" & JobBelong & "','" & JobCountry & "','" & JobClient & "','" & JobShipper & "', '" & gsDummy & "'"
			strSql = strSql & ",'" & POLN & "','" & FitSel(POL) & "','" & PODN & "','" & FitSel(POD) & "',60," & WebUserID & "," & WebUserID & ")"
			Conn.Execute strSql
			
			response.redirect "MainFrame.asp?JobCode=" & JobCode
		else
			ShowMessage "�V�X�e���G���[���N����܂����B�Ǘ��҂ɂ��A�����������B"
		end if
	end if
%>

<html>
<HEAD>
	<TITLE>�V�K�o�^</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
	<!--		
		sub JobArea_OnChange()
			frmInput.mode.value = 1
			frmInput.submit()
		end sub
		
		sub JobCountry_OnChange()			
			ClearPort()
		end sub
		
		sub ClearPort()
			if GetElementVal("JobType") = "<%=gsImport%>" then
				frmInput.POLCD.value = ""
				frmInput.POLN.value = ""	
				frmInput.POL.value = ""
			else
				frmInput.PODCD.value = ""
				frmInput.PODN.value = ""	
				frmInput.POD.value = ""
			end if
		end sub	
		
		sub POLCD_OnBlur()			
			frmInput.POLCD.value = ucase(frmInput.POLCD.value)
			frmInput.POLN.value = ""	
			frmInput.POL.value = ""
		end sub
		
		sub POL_OnBlur()	
			if frmInput.POLCD.value <> "ZZZ" then
				frmInput.POLCD.value = ""	
				frmInput.POLN.value = ""	
				frmInput.POL.value = ucase(frmInput.POL.value)
			end if
		end sub	
		
		sub PODCD_OnBlur()
			frmInput.PODCD.value = ucase(frmInput.PODCD.value)
			frmInput.PODN.value = ""	
			frmInput.POD.value = ""
		end sub
		
		sub POD_OnBlur()
			if frmInput.PODCD.value <> "ZZZ" then
				frmInput.PODCD.value = ""
				frmInput.PODN.value = ""	
				frmInput.POD.value = ucase(frmInput.POD.value)
			end if
		end sub
		
		sub PortSearch(mode)
			dim win, param
			if GetElementVal("JobType") = "<%=gsImport%>" then
				POL_CN = frmInput.JobCountry.options(frmInput.JobCountry.selectedindex).value
				POD_CN = "JP"
			else
				POL_CN = "JP"
				POD_CN = frmInput.JobCountry.options(frmInput.JobCountry.selectedindex).value
			end if
			if mode = 0 then
				param = "?mode=0&cn=" & POL_CN & "&cd=" & frmInput.POLCD.value & "&nm=" & frmInput.POL.value
			else
				param = "?mode=1&cn=" & POD_CN & "&cd=" & frmInput.PODCD.value & "&nm=" & frmInput.POD.value
			end if
			set win = window.open("../common/PortSearch.asp" & param,"PortSearch","resizable=0,StatusBar=0,scrollbars=1,width=360,height=300")
		end sub
							
		sub Client_OnChange()
			frmInput.Client.value = ucase(frmInput.Client.value)
			frmInput.JobClient.value = ""
			frmInput.EName.value = ""
			frmInput.AName.value = ""
			frmInput.JName.value = ""
			frmInput.JobManager.value = ""
			frmInput.JobImport.value = ""
			frmInput.JobExport.value = ""
			
			frmInput.JobShipper.value = ""
			frmInput.Shipper.value = ""
			frmInput.ShipperName.value = ""
		end sub
		
		sub Shipper_OnChange()	
			frmInput.Shipper.value = ucase(frmInput.Shipper.value)
			frmInput.JobShipper.value = ""
			frmInput.ShipperName.value = ""
		end sub
		
		sub DoSearch(mode)
			dim win, param
			if mode = 0 then
				param = "?mode=0&cd=" & frmInput.Client.value
				set win = window.open("ClientSearch.asp" & param,"ClientSearch","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
			else
				param = "?mode=1&cd=" & frmInput.Shipper.value
				set win = window.open("ClientSearch.asp" & param,"ClientSearch","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
				'param = "?type=1&cd=" & frmInput.Shipper.value & "&CTM_CD=" & frmInput.JobClient.value
				'set win = window.open("LinkSearch.asp" & param,"ClientSearch","resizable=0,StatusBar=0,scrollbars=1,width=800,height=600")
			end if
			win.focus()
		end sub
		
		sub DataSave()
			if checkText("POLCD","�o���`�R�[�h",1) = false then exit sub
			if checkText("POL","�o���`",1) = false then exit sub
			if checkText("PODCD","�o���`�R�[�h",1) = false then exit sub
			if checkText("POD","�ړI�`",1) = false then exit sub
			if checkText("Client","�����׎�",1) = false then exit sub
			if checkText("EName","�����׎�",1) = false then exit sub
			if checkText("Shipper","B/L��׎�",1) = false then exit sub
			if msgbox("����ő䒠�ԍ��𔭍s���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then 
				frmInput.mode.value = 2
				frmInput.submit()
			end if
		end sub
		
		sub InitForm()
			frmInput.JobArea.focus()
		end sub
	-->
	</SCRIPT>
</Head>
<body topmargin=3 onload="InitForm()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="SokoNew.asp" method="post">
  	<input type=hidden name="mode" value="">
  	<input type=hidden name="JobManager" value="<%=JobManager%>">
  	<input type=hidden name="JobImport" value="<%=JobImport%>">
  	<input type=hidden name="JobExport" value="<%=JobExport%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���V�K�Ɩ�&nbsp;
	 	  <td width=50% align=right><!--<img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">--><br>
	</table>
	<hr width=96% size=1 color=blue>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=30>
		<TD width=80>�Ɩ�����
	  	<TD><select name=JobBelong onkeydown="ResetEnter()"><option value="M">�ېőq��</select>
	  <TR height=30>
		<TD>�Ɩ��敪
		<TD><input type=radio name=JobType value="<%=gsImport%>" <%if JobType = gsImport then response.write " checked" %> onkeydown="ResetEnter()">�A��
			<input type=radio name=JobType value="<%=gsExport%>" <%if JobType = gsExport then response.write " checked" %> onkeydown="ResetEnter()">�A�o
			<input type=radio name=JobType value="<%=gsOther%>" <%if JobType = gsOther then response.write " checked" %> onkeydown="ResetEnter()">�ق�
	  <TR height=30>
		<TD>�C�O�G���A
		<TD><select style="width:100" name=JobArea onkeydown="ResetEnter()"><%=ShowAreaList(JobArea)%></select>
			<select class=pt9n name=JobCountry onkeydown="ResetEnter()"><%=ShowCountryList(JobArea)%></select>	
	  <TR height=30>
		<TD>�o���`<input type=hidden name="POLN" value="<%=POLN%>">
		<TD><input class=si name="POLCD" size=8 maxlength=10 value="<%=POLCD%>" onkeydown="ResetEnter()">
			<a href="javascript:PortSearch(0)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="POL" value="<%=POL%>" Maxlength=50 size=30 onkeydown="ResetEnter()">
	  <TR height=30>
		<TD>�ړI�`<input type=hidden name="PODN" value="<%=PODN%>">
		<TD><input class=si name="PODCD" size=8 maxlength=10 value="<%=PODCD%>" onkeydown="ResetEnter()">
			<a href="javascript:PortSearch(1)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="POD" value="<%=POD%>" Maxlength=50 size=30 onkeydown="ResetEnter()">
	  <TR height=30>
		<TD>�����׎�
		<TD><input class=si name="Client" size=8 maxlength=10 value="<%=Client%>" onkeydown="ResetEnter()">
			<a href="javascript:DoSearch(0)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="EName" value="" size=50 readonly>
	  <TR height=30>
		<TD class=pt9>�a������
		<TD>(<input class=si name="JobClient" value="<%=JobClient%>" size=8 readonly>)�@
			<input class=si name="JName" value="<%=JName%>" size=50 readonly>
	  <TR height=30>
		<TD>B/L��׎�<input type=hidden name="JobShipper" value="<%=JobShipper%>">
		<TD><input class=si name="Shipper" size=8 maxlength=10 value="<%=Shipper%>" onkeydown="ResetEnter()">
			<a href="javascript:DoSearch(1)"><img src=img/search.jpg border=0 alt="����"></a>
			<input class=si name="ShipperName" value="<%=ShipperName%>" size=50 readonly>
	  <TR height=80>
		<TD colspan=2 align=center><input type=button style="width:120;height:40" name=btnCreate value="�䒠�ԍ����s" onclick="DataSave()">
	</table>
  </FORM>
<center>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowAreaList(myArea)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT DISTINCT CN_LINE FROM MST_COUNTRY WHERE CN_DELETED = 0 AND ISNULL(CN_LINE, '') <> ''" 
	mySql = mySql & " ORDER BY CN_LINE"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CN_LINE")
		if myRec.fields("CN_LINE") = myArea then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("CN_LINE")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowAreaList = buf	
end function

function ShowCountryList(myArea)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT CN_CD, CN_NAME, CN_ENAME FROM MST_COUNTRY WHERE CN_DELETED = 0 AND CN_CD <> 'JP' AND CN_LINE = '" & myArea & "'"
	mySql = mySql & " ORDER BY CN_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CN_CD") & ">" & replace(left(myRec.fields("CN_ENAME") & space(20), 20), " ", "&nbsp;") & myRec.fields("CN_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowCountryList = buf	
end function

function ShowPortList(myCn, myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT PORT_CD, PORT_ENAME FROM MST_PORT WHERE PORT_DELETED = 0 AND PORT_CN = '" & myCn & "'"
	mySql = mySql & " ORDER BY PORT_ENAME"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("PORT_ENAME")
		if myDft = myRec.fields("PORT_ENAME") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("PORT_ENAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowPortList = buf	
end function
%>

