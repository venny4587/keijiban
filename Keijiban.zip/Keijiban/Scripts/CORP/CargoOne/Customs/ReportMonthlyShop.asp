<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�Ɩ����ь��ʐ��ڕ\
'----------------------------------------------
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobBelong = GetPost(request("JobBelong"))
	JobSalesman = GetLong(request("JobSalesman"))
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 4  then JobBelong = UserShop
	
	SelYear = GetLong(request("SelYear"))
	if SelYear = 0 then
		if month(date) > 4 then
			SelYear = year(date)
		else
			SelYear = year(date) - 1
		end if
		if myLevel < 4  then JobSalesman = WebUserID
	end if
		
	call GetAccountYear(SelYear, AccountFrom, AccountTo)
	
%>

<HTML>
<HEAD>
	<TITLE>�Ɩ����ь��ʐ��ڕ\</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ReportMonthlyShop.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="JobBelong" VALUE='<%=JobBelong%>'>
		<INPUT TYPE="HIDDEN" NAME="AccountMonth" VALUE='<%=AccountMonth%>'>
		<input type=hidden name="sort" value="<%=mySort%>">
		<table class=pt9>
			<TR><TD nowrap>�c�ƒS��
<%if myLevel > 2 then%>
					<select name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
						<%=ShowEmployList(DepartSales, JobSalesman)%>
					</select>&nbsp;
<%else%>
					<input type=hidden name="JobSalesman" value="<%=JobSalesman%>">
					<u>&nbsp;<font color=green><%=GetEmployName(JobSalesman, "F")%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap class=pt9>�Ώ۔N�x&nbsp;
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
<div id=list>
�Ώ۔N�x�F<%=ShowJpnYear(left(AccountFrom,4))%><%=GetJapanNo(right(AccountFrom,2))%>���`<%=ShowJpnYear(left(AccountTo,4))%><%=GetJapanNo(right(AccountTo,2))%>��
		
<%
	redim myCount(12)
	redim mySales(12)
	redim myCosts(12)
	redim myBenefit(12)				
	for i = 0 to 12 
		myCount(i) = 0:		mySales(i) = 0:		myCosts(i) = 0:		myBenefit(i) = 0
	next
	with recset
		strSql = "SELECT AccountDate, COUNT(JobCode) AS Total, SUM(SalesSum+SalesTax) AS Sales, SUM(CostsSum+CostsTax) AS Costs, SUM(Interests) AS Benefit"
		strSql = strSql & " FROM TBL_CTM_JOB WHERE Deleted = 0 AND SUBSTRING(JobCode,2,1) = '" & gsExport & "' AND AccountDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if JobBelong <> "" then strSql = strSql & " AND JobBelong = '" & JobBelong & "'"
		if JobSalesman <> 0 then strSql = strSql & " AND JobSalesman = " & JobSalesman
		strSql = strSql & " GROUP BY AccountDate"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		fromMonth = Str2Date(AccountFrom & "01")
		do while not .EOF
			curMonth = Str2Date(GetString(.fields("AccountDate")) & "01")
			idx = datediff("m",fromMonth, curMonth)
			
			myCount(idx) = myCount(idx) + GetLong(.fields("Total"))
			mySales(idx) = mySales(idx) + GetLong(.fields("Sales"))
			myCosts(idx) = myCosts(idx) + GetLong(.fields("Costs"))
			myBenefit(idx) = myBenefit(idx) + GetLong(.fields("Benefit"))
			
			myCount(12) = myCount(12) + GetLong(.fields("Total"))
			mySales(12) = mySales(12) + GetLong(.fields("Sales"))
			myCosts(12) = myCosts(12) + GetLong(.fields("Costs"))
			myBenefit(12) = myBenefit(12) + GetLong(.fields("Benefit"))
			
			.movenext
		loop
		.Close
	end with	
%>
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup align=center>
		<colgroup span=13 align=right>
		<TR height=24>
			<TD width=7% nowrap>�A�o����
<%for i = 1 to 12%>
			<TD width=7%><%if gsSysCloseMonth + i > 12 then%><%=(gsSysCloseMonth + i - 12)%>����<%else%><%=(gsSysCloseMonth + i)%>����<%end if%>
<%next%>	
			<TD width=9%>�A�o���v
		<TR height=24 style="color:blue"><TD>����<%for i = 0 to 12%><TD><%=formatnumber(mySales(i), 0, true)%><%next%>
		<TR height=24 style="color:red"><TD>�x��<%for i = 0 to 12%><TD><%=formatnumber(myCosts(i), 0, true)%><%next%>
		<TR height=24><TD>�e��<%for i = 0 to 12%><TD><%=formatnumber(myBenefit(i), 0, true)%><%next%>
		<TR height=24 style="color:green"><TD>����<%for i = 0 to 12%><TD><%=formatnumber(myCount(i), 0, true)%><%next%>
		<TR height=24><TD>�e����
		<%for i = 0 to 12%>
			<TD><%if mySales(i) = 0 then%>0<%else%><%=formatnumber(myBenefit(i) * 100 / mySales(i), 2, true)%>%<%end if%>
		<%next%>		
	</TABLE>
	<br>
<%
	redim myCount(12)
	redim mySales(12)
	redim myCosts(12)
	redim myBenefit(12)				
	for i = 0 to 12 
		myCount(i) = 0:		mySales(i) = 0:		myCosts(i) = 0:		myBenefit(i) = 0
	next
	with recset
		strSql = "SELECT AccountDate, COUNT(JobCode) AS Total, SUM(SalesSum+SalesTax) AS Sales, SUM(CostsSum+CostsTax) AS Costs, SUM(Interests) AS Benefit"
		strSql = strSql & " FROM TBL_CTM_JOB WHERE Deleted = 0 AND SUBSTRING(JobCode,2,1) = '" & gsImport & "' AND AccountDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if JobBelong <> "" then strSql = strSql & " AND JobBelong = '" & JobBelong & "'"
		if JobSalesman <> 0 then strSql = strSql & " AND JobSalesman = " & JobSalesman
		strSql = strSql & " GROUP BY AccountDate"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		fromMonth = Str2Date(AccountFrom & "01")
		do while not .EOF
			curMonth = Str2Date(GetString(.fields("AccountDate")) & "01")
			idx = datediff("m",fromMonth, curMonth)
			
			myCount(idx) = myCount(idx) + GetLong(.fields("Total"))
			mySales(idx) = mySales(idx) + GetLong(.fields("Sales"))
			myCosts(idx) = myCosts(idx) + GetLong(.fields("Costs"))
			myBenefit(idx) = myBenefit(idx) + GetLong(.fields("Benefit"))
			
			myCount(12) = myCount(12) + GetLong(.fields("Total"))
			mySales(12) = mySales(12) + GetLong(.fields("Sales"))
			myCosts(12) = myCosts(12) + GetLong(.fields("Costs"))
			myBenefit(12) = myBenefit(12) + GetLong(.fields("Benefit"))
			
			.movenext
		loop
		.Close
	end with
%>
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup align=center>
		<colgroup span=13 align=right>
		<TR height=24>
			<TD width=7% nowrap>�A������
<%for i = 1 to 12%>
			<TD width=7%><%if gsSysCloseMonth + i > 12 then%><%=(gsSysCloseMonth + i - 12)%>����<%else%><%=(gsSysCloseMonth + i)%>����<%end if%>
<%next%>	
			<TD width=9%>�A�����v

		<TR height=24 style="color:blue"><TD>����<%for i = 0 to 12%><TD><%=formatnumber(mySales(i), 0, true)%><%next%>
		<TR height=24 style="color:red"><TD>�x��<%for i = 0 to 12%><TD><%=formatnumber(myCosts(i), 0, true)%><%next%>
		<TR height=24><TD>�e��<%for i = 0 to 12%><TD><%=formatnumber(myBenefit(i), 0, true)%><%next%>
		<TR height=24 style="color:green"><TD>����<%for i = 0 to 12%><TD><%=formatnumber(myCount(i), 0, true)%><%next%>
		<TR height=24><TD>�e����
		<%for i = 0 to 12%>
			<TD><%if mySales(i) = 0 then%>0<%else%><%=formatnumber(myBenefit(i) * 100 / mySales(i), 2, true)%>%<%end if%>
		<%next%>		
	</TABLE>
	<br>
<%
	redim myCount(12)
	redim mySales(12)
	redim myCosts(12)
	redim myBenefit(12)				
	for i = 0 to 12 
		myCount(i) = 0:		mySales(i) = 0:		myCosts(i) = 0:		myBenefit(i) = 0
	next
	with recset
		strSql = "SELECT AccountDate, COUNT(JobCode) AS Total, SUM(SalesSum+SalesTax) AS Sales, SUM(CostsSum+CostsTax) AS Costs, SUM(Interests) AS Benefit"
		strSql = strSql & " FROM TBL_CTM_JOB WHERE Deleted = 0 AND AccountDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if JobBelong <> "" then strSql = strSql & " AND JobBelong = '" & JobBelong & "'"
		if JobSalesman <> 0 then strSql = strSql & " AND JobSalesman = " & JobSalesman
		strSql = strSql & " GROUP BY AccountDate"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		fromMonth = Str2Date(AccountFrom & "01")
		do while not .EOF
			curMonth = Str2Date(GetString(.fields("AccountDate")) & "01")
			idx = datediff("m",fromMonth, curMonth)
			
			myCount(idx) = myCount(idx) + GetLong(.fields("Total"))
			mySales(idx) = mySales(idx) + GetLong(.fields("Sales"))
			myCosts(idx) = myCosts(idx) + GetLong(.fields("Costs"))
			myBenefit(idx) = myBenefit(idx) + GetLong(.fields("Benefit"))
			
			myCount(12) = myCount(12) + GetLong(.fields("Total"))
			mySales(12) = mySales(12) + GetLong(.fields("Sales"))
			myCosts(12) = myCosts(12) + GetLong(.fields("Costs"))
			myBenefit(12) = myBenefit(12) + GetLong(.fields("Benefit"))
			
			.movenext
		loop
		.Close
	end with
%>
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup align=center>
		<colgroup span=13 align=right>
		<TR height=24>
			<TD width=7% nowrap>���v����
<%for i = 1 to 12%>
			<TD width=7%><%if gsSysCloseMonth + i > 12 then%><%=(gsSysCloseMonth + i - 12)%>����<%else%><%=(gsSysCloseMonth + i)%>����<%end if%>
<%next%>	
			<TD width=9%>�A�o�����v

		<TR height=24 style="color:blue"><TD>����<%for i = 0 to 12%><TD><%=formatnumber(mySales(i), 0, true)%><%next%>
		<TR height=24 style="color:red"><TD>�x��<%for i = 0 to 12%><TD><%=formatnumber(myCosts(i), 0, true)%><%next%>
		<TR height=24><TD>�e��<%for i = 0 to 12%><TD><%=formatnumber(myBenefit(i), 0, true)%><%next%>
		<TR height=24 style="color:green"><TD>����<%for i = 0 to 12%><TD><%=formatnumber(myCount(i), 0, true)%><%next%>
		<TR height=24><TD>�e����
		<%for i = 0 to 12%>
			<TD><%if mySales(i) = 0 then%>0<%else%><%=formatnumber(myBenefit(i) * 100 / mySales(i), 2, true)%>%<%end if%>
		<%next%>		
	</TABLE>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>