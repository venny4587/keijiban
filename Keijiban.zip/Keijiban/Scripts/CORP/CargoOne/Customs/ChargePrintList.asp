<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
dim BatchNo
dim ChargeNo
dim ChargeNos

ChargeSort = GetLong(request("sort"))
ChargeNos = GetPost(request("nos"))
ChargeNo = ResetBizNos(ChargeNos)
BatchNo = GetPost(request("batch"))
mode = GetLong(request("mode"))
if ChargeNos <> "" then

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 2 and CheckTopLevel() > 0 then myLevel = 2
		
	if mode = 1 then
		PrintNo = GetPost(request("PrintNo"))
		With RecSet
			strSQL = "SELECT JobCode, ChargeClient, ChargePic, ChargeDate, ChargePayDay, ConfirmerID FROM TBL_CTM_CHARGE"
			strSQL = strSQL & " WHERE Deleted = 0 AND ChargeNo IN (" & ChargeNo & ")" 
if WebUserID = gsAdmin then response.write strSql
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				BatchBelong = mid(GetString(.Fields("JobCode")), 1, 1)
				BatchType = mid(GetString(.Fields("JobCode")), 2, 1)
				BatchClient = GetString(.Fields("ChargeClient"))
				BatchPic = GetString(.Fields("ChargePic"))
				BatchBillDay = GetString(.Fields("ChargeDate"))
				BatchPayDay = GetString(.Fields("ChargePayDay"))
			end if
			.Close
		end with
		select case BatchClient
		case gsCorpCode, gsCorpSoko
			BatchBelong = "K"
		end select
				
		if PrintNo <> "" then			
			With RecSet
				strSQL = "SELECT BatchNo FROM TBL_CTM_BATCH WHERE Deleted = 0 AND ConfirmerID = 0"
				if left(BatchClient, 3) = "690" then
					strSQL = strSQL & " AND BatchNo = '" & PrintNo & "' AND BatchClient = '690'"
				else
					strSQL = strSQL & " AND BatchNo = '" & PrintNo & "' AND BatchClient = '" & BatchClient & "'"
				end if
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if .eof then msg = "�Y��������͕s���ł��B"
				.Close
			end with
		end if
		
		if msg <> "" then
			ShowMessage msg
		else
			Conn.BeginTrans
			
			if PrintNo = "" then
				PrintID = GetNewBatchNo(Conn, gsBatchPrint)
				PrintNo = GetBatchNo(PrintID, gsBatchPrint)
				
				strSQL = "INSERT INTO TBL_CTM_BATCH (BatchNo, BatchBelong, BatchType, BatchPic, BatchClient, BatchBillDay, BatchPayDay, Remarks, Creater, Updater)"
				strSQL = strSQL & " VALUES ('" & PrintNo & "','" & BatchBelong & "','" & BatchType & "','" & BatchPic & "','" & BatchClient & "','" & BatchBillDay
				strSQL = strSQL & "','" & BatchPayDay & "','�ꊇ����'," & WebUserID & "," & WebUserID & ")"
				Conn.Execute strSQL
			end if
			
			strSql = "UPDATE TBL_CTM_CHARGE SET ChargeBatch = '" & PrintNo & "' WHERE ChargeNo IN (" & ChargeNo & ")" 
			Conn.Execute strSql
			
			strSql = "UPDATE TBL_CTM_BIZ SET BIZ_BATCH = '" & PrintNo & "' WHERE BIZ_NO IN (" & ChargeNo & ")" 
			Conn.Execute strSql
			
			With RecSet
				strSQL = "SELECT COUNT(ChargeNo) AS CNT, SUM(ChargeAmount + ChargeTax) AS TTL FROM TBL_CTM_CHARGE"
				strSQL = strSQL & " WHERE Deleted = 0 AND ChargeBatch = '" & PrintNo & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then
					BatchCount = GetLong(.fields("CNT"))
					BatchAmount = GetLong(.fields("TTL"))
				end if
				.Close
			end with
				
			strSql = "UPDATE TBL_CTM_BATCH SET BatchCount = " & BatchCount
			strSql = strSql & ", BatchAmount = " & BatchAmount
			strSql = strSql & " WHERE BatchNo = '" & PrintNo & "'"
			Conn.Execute strSql
			
			if err.number = 0 then
				Conn.CommitTrans
				msg = "�o�b�`�����͖����������܂����B"
				BatchNo = PrintNo
			else
				Conn.RollbackTrans
				msg = "�o�b�`���������L�̃G���[���N����܂����B" & vbcrlf & err.number & ":" & err.description
			end if
		end if
	end if
%>
<HTML>
<HEAD>
	<TITLE>�������ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>	
		function DoCover()
			set win = window.open("BillCover.asp?nos=<%=ChargeNos%>","BillCover","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function DoPrint()
			set win = window.open("ChargePrintMain.asp?mode=2&nos=<%=ChargeNos%>","ChargePrint","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function DoBatch()
		dim mySel
			mySel = ""
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 3) = "nos" and obj.Checked then
						mySel = mySel & "," & obj.value
					end if
				end if
			next 	
			if mySel = "" then
				msgbox "�������x���`�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			msgbox mySel
			set win = window.open("ChargePrintMain.asp?mode=2&nos=" & mid(mySel,2),"ChargePrint","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function DoCheck()
			Call CheckAll("nos", frmInput.CheckAll.Checked)
		end function 
	
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 3) = "nos" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�o�b�`��������x���`�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
			if msgbox ("�o�b�`�������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit function
			frmInput.btnProc.disabled = True
			frmInput.mode.value = 1
			frmInput.submit()
		end function 
		
		function DoSort(myNo)
			window.location.href = "ChargePrintList.asp?nos=<%=ChargeNos%>&batch=<%=BatchNo%>&sort=" & myNo 
		end function
		
		function ShowJob(Job, No)
		dim win
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & Job & "&ChargeNo=" & No,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		sub PrintNo_OnBlur()
			frmInput.PrintNo.value = FitPrintNo(frmInput.PrintNo.value)
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
<%
	with recset
		strSql = "SELECT JobCode, ChargeNo, ChargeBatch, ChargeClient, ChargeClientName, ChargePrinted, ConfirmerID"
		strSql = strSql & ", ChargeBelong, ChargeType, ChargeAmount, ChargeTax, ChargeDate, ChargePayDay, FinisherID"
		strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0"
		if BatchNo = "" then 
			strSql = strSql & " AND ChargeNo IN (" & ChargeNo & ")"
		else
			strSql = strSql & " AND ChargeBatch = '" & BatchNo & "'"
		end if
		select case ChargeSort
		case 0:		strSql = strSql & " ORDER BY ChargeNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, ChargeNo"
		end select
if WebUserID = gsAdmin then response.write strSQL
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then	
			ClientName = GetString(.Fields("ChargeClientName"))
%>
  <form name=frmInput method="post" action="ChargePrintList.asp">
  	<input type=hidden name="mode" value="0">
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=20 valign=bottom>
	  	<td nowrap>���������ꗗ&nbsp;
		<td nowrap>������F<%=ClientName%>&nbsp;
	  	<td nowrap><img style="cursor:hand" src=img/cover.jpg alt="�\�����" onmousedown="DoCover()">&nbsp;
<%if BatchNo = "" then%>
	  			<img style="cursor:hand" src=img/printer.jpg alt="���׈��" onmousedown="DoBatch()">
<%else%>
	  			<img style="cursor:hand" src=img/printer.jpg alt="���׈��" onmousedown="DoPrint()">
<%end if%>
	</table>
	<hr size=1 color=blue>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=28 class=pt9>
		<TD class=line nowrap colspan=2>��
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap align=center>������
		<TD class=line nowrap>�������z
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�����ԍ�
		<TD class=line nowrap>������
<%if BatchNo = "" then%>
		<TD class=line nowrap><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S
<%end if%>
		<TD class=line nowrap>���
<%
			cnt = 0:	SeqNo = 0:		ttlCount = 0
			ttlAmount = 0:	ttlTax = 0:	ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode"))
				ChargeNo = GetString(.Fields("ChargeNo"))	
				ChargeBatch = GetString(.Fields("ChargeBatch"))
				if GetLong(.Fields("ChargePrinted")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=red>��</font>"
				end if 
%>
				<TR align=center height=28>
					<TD class=line><%=cnt%><BR>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowJob('<%=JobCode%>','<%=ChargeNo%>')">
					<TD nowrap class=line align=left nowrap><%=ShowJobCode(JobCode)%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("ChargeDate"))%><BR>
					<TD nowrap class=line nowrap align=right><%=formatnumber(GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax")), 0, true)%><BR>
					<TD nowrap class=line align=left><%=ShowVoucherNo(ChargeNo)%><BR>
					<TD nowrap class=line><%=Str2MD(.Fields("ChargePayDay"))%><BR>
<%if BatchNo = "" then%>
					<TD class=line style="color:gray"><%
						if ChargeBatch <> "" or GetLong(.Fields("FinisherID")) <> 0 then
							response.write "��"
						else
							ttlCount = ttlCount + 1
							response.write "<input type=checkbox name=nos value=" & ResetBizNo(ChargeNo) & ">"
						end if	%>
<%end if%>
					<TD nowrap class=line><%=status%><BR>
<%
				if GetLong(.Fields("ChargeTax")) = 0 then 
					ttlTaxFree = ttlTaxFree + GetLong(.Fields("ChargeAmount")) 
				else
					ttlTax = ttlTax + GetLong(.Fields("ChargeTax"))
					ttlAmount = ttlAmount + GetLong(.Fields("ChargeAmount"))
				end if
				.movenext
			loop
			if cnt > 0 then
%>
				<TR align=right height=20>
					<TD colspan=3 class=pt9>�������v
					<TD colspan=2 class=line><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
					<TD colspan=4><%if ttlCount > 0 and myLevel > 1 then%>
						�����<INPUT class=si maxlength=6 size=6 name="PrintNo" VALUE="" onkeydown="ResetEnter()">
						<INPUT style="width:60px;height:25px;" TYPE=button name=btnProc VALUE="���s" onclick="DoConfirm()">
					<%end if%>
<%
			end if
%>
	</TABLE>
<%
			if cnt > 0 then
%>
<%
			end if
%>
  </form>
<%		else
			response.write "<font class=pt9r>�Y���������͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>
<%
		set recset = nothing
		CloseDB Conn
		
	end if
%>	