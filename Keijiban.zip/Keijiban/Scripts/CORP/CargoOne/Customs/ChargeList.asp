<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim JobBelong
dim JobBroker
dim JobInvoice
dim JobReferNo

	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	myLevel = CheckUserLevel(JobBelong, JobBroker)
	
	ChargeNo = GetPost(request("ChargeNo"))
if JobCode <> "" and ChargeNo <> "" then
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")

	with Recset
		strSql = "SELECT * FROM TBL_CTM_CHARGE WHERE JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
		.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if not .eof then
			ChargeType = GetLong(.fields("ChargeType"))
			ChargeDate = Str2Date(.fields("ChargeDate"))
			ChargeClient = GetString(.fields("ChargeClient"))
			ChargePic = GetString(.fields("ChargePic"))
			ChargeAmount = GetLong(.fields("ChargeAmount"))
			ChargeTax = GetLong(.fields("ChargeTax"))
			ChargePayDay = Str2Date(.fields("ChargePayDay"))
			ChargeMemo = GetString(.fields("ChargeMemo"))
			Remarks = GetString(.fields("Remarks"))
			
			ChargeCheck = GetLong(.fields("ChargeCheck"))
			ConfirmerID = GetLong(.fields("ConfirmerID"))
			ConfirmDate = GetDate(.fields("ConfirmDate"))
			FinisherID = GetLong(.fields("FinisherID"))
			FinishDate = GetDate(.fields("FinishDate"))
		end if
		.close
	end with
	
	select case GetLong(ChargeType)
	case 1:		myLine = "black"
	case 2:		myLine = "#228b22"
	case 3:		myLine = "blue"
	case else:	myLine = "black"
	end select
	
	Kenshu = 0
	if CheckJobType(JobCode) = gsImport and left(ChargeClient, 3) = "690" then
		if ChargeType <> gsStand then Kenshu = 1
	end if
%>
<HTML>
<HEAD>
	<TITLE>���������׏Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=javaScript>
		function ShowHead() {
			window.location.href = "ChargeHead.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>"
		}
		
		function ShowDetail(myNo) {
			var win = window.open("ChargeDetail.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>&seq="+myNo,"ChargeDetail","scrollbars=no,width=600,height=400");
			win.focus();
		}
		
		function ShowPattern(myNo) {
			var win = window.open("ChargePattern.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>","ChargePattern","scrollbars=yes,width=800,height=500");
			win.focus();
		}
		
		function ShowSales(myNo) {
			var win = window.open("SalesDetail.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>&seq="+myNo,"ChargeDetail","scrollbars=no,width=600,height=400");
			win.focus();
		}

		function DoConfirm() {
			if (confirm("���͊������Ă�낵���ł����H")) {
				window.location.href = "ChargeConfirm.asp?type=<%=ChargeType%>&JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>"
			}
		}
		
		function DoDelete(myNo) {
			if (confirm("�Y�����֐������ڂ��폜���Ă�낵���ł����H")) {
				window.location.href = "StandRemove.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>&Seq="+myNo;
			}
		}
		
		function DoRemark() {
			var win = window.open("ChargeRemarks.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>","ChargeRemarks","scrollbars=no,width=600,height=400");
			win.focus();
		}
		
		function DoPrint() {
<%if ConfirmerID = 0 then%>
			alert("�m��{�^������������A������s�\�ł��B");
<%else%>
			var win = window.open("BillPrint.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>","BillPrint","resizable=1,scrollbars=1,width=800,height=600");
			win.focus();
<%end if%>
		}
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsSalesBackColor%>" topmargin=3 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=30%>������������&nbsp;
	  		<img style="cursor:hand" src=img/back.gif alt="�������w�b�_��" onmousedown="ShowHead()">
	  	<td width=60% class=pt9 valign=bottom>
	  		�����ԍ��F<font class=pt9n><%=ChargeNo%></font>
		�@	INV No.<font class=pt9b><%=StringCut(JobInvoice, 20)%></font>
	  	<td width=10% align=right>
<%	if ConfirmerID <> 0 then %>
<%		if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�����ς�<%=GetEraseInfo(ChargeNo, 0)%>">
<%		else %>
	  	  <img style="cursor:hand" src=img/note.jpg alt="�Г����l" onmousedown="DoRemark()">
<%		end if %>
	  	  	<img style="cursor:hand" src=img/print.jpg alt="���������" onmousedown="DoPrint()">
<!--	  		<img style="cursor:help" src=img/security.gif alt="�m�F�ҁF<%=GetEmployName(ConfirmerID, "F") & " (" & ShowDateTimeShort(ConfirmDate) & ")"%>"> -->
<%	elseif ChargeType <> gsStand then %>
	  		<%if CheckTopLevel() > 0 or myLevel > 0 then %>
	  			<img style="cursor:hand" src=img/new.gif alt="�������ڐV�K�ǉ�" onmousedown="ShowDetail('');">
	  			<img style="cursor:hand" src=img/cover.jpg alt="�����p�^�[���ďo" onmousedown="ShowPattern('');">
	  		<%end if%>
<%	end if %>
	</table>
	<hr width=96% size=1 color="<&=myLine&>"><%=JobHeader%><br>
	
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>����
		<TD class=line nowrap>��������
		<TD class=line nowrap>���ڔ��l
		<TD class=line nowrap>�P��
		<TD class=line nowrap>����
		<TD class=line nowrap>�P��
		<TD class=line nowrap>�����
		<TD class=line nowrap>�Ŕ����z
<%if Kenshu <> 0 then%><TD class=line nowrap>��<%end if%>
<%
	cnt = 0
	myNull = 0
	ttlTax = 0
	ttlAmount = 0
	ttlTaxFree = 0
	sumKensyu = 0
	strShortCut = ""
	with recset
		strSql = "SELECT SeqNo, ExpenseType, ExpenseAttr, ExpenseCost, COST_ID, COST_CD, COST_NAME, ExpenseTaxName"
		strSql = strSql & ",ExpenseQuantity, ExpenseUnit, ExpensePrice, ExpenseAmount, ExpenseTax, ExpenseMemo"
		strSql = strSql & " FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
		strSql = strSql & " ORDER BY ExpenseType DESC, COST_CD, SeqNo"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		do while not .eof
			cnt = cnt + 1
			CostName = GetString(.Fields("COST_NAME"))
			myMemo = GetString(.Fields("ExpenseMemo"))
			if ConfirmerID <> 0 then
				ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(cnt)) & ") ShowSales('" & .Fields("SeqNo") & "');"
			else
				if GetLong(.Fields("ExpenseType")) = gsStand then
					ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(cnt)) & ") DoDelete('" & .Fields("SeqNo") & "');"
					if cnt < 10 then ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + cnt) & ") DoDelete('" & .Fields("SeqNo") & "');"
				else
					ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(cnt)) & ") ShowDetail('" & .Fields("SeqNo") & "');"
					if cnt < 10 then ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + cnt) & ") ShowDetail('" & .Fields("SeqNo") & "');"
				end if
			end if
%>
	<TR align=right height=20  style="cursor:hand" onmouseover="this.bgColor='<%=gsSalesForeColor%>';" onmouseout="this.bgColor='<%=gsSalesBackColor%>';" 
<%if ConfirmerID <> 0 then%>
		 onclick="ShowSales('<%=.Fields("SeqNo")%>');"
<%else%>
	<%if GetLong(.Fields("ExpenseType")) = gsStand then %>
		 onclick="DoDelete('<%=.Fields("SeqNo")%>');"
	<%else%>
		 onclick="ShowDetail('<%=.Fields("SeqNo")%>');"
	<%end if%>
<%end if%>>
		<TD class=line align=center>[<%=Num2Code(cnt)%>]
		<TD class=line align=center><%=ShowExpenseType(.Fields("ExpenseType"))%><BR>
<%if GetLong(.Fields("COST_ID")) = 123 then %>
		<TD class=line nowrap align=left colspan=5><%=StringCut(myMemo,25)%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, false)%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, false)%><BR>
<%else%>
<%	if GetLong(.Fields("COST_ID")) <> 113 then %>
		<TD class=line nowrap align=left <%=ShowTitle(CostName, 10)%>><%=StringCut(CostName,10)%><BR>
		<TD class=line nowrap align=left <%=ShowTitle(myMemo, 8)%>><%=StringCut(myMemo,8)%><BR>
<%	else %>
		<TD class=line nowrap align=left colspan=2 <%=ShowTitle(myMemo, 16)%>><%=StringCut(myMemo,16)%><BR>
<%	end if %>
		<TD class=line nowrap><%=FitZero(formatnumber(GetDouble(.Fields("ExpensePrice")), 2, true))%><BR>
		<TD class=line nowrap><%=GetDouble(.Fields("ExpenseQuantity"))%><BR>
		<TD class=line nowrap align=center><%=GetString(.Fields("ExpenseUnit"))%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, true)%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%><BR>
<%end if%>
<%if Kenshu <> 0 then
		if GetLong(.Fields("ExpenseAttr")) then 
			sumKensyu = sumKensyu + GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax"))
		end if
%>
		<TD class=line style="color:tomato"><%if GetLong(.Fields("ExpenseAttr")) then%>��<%end if%><br>
<%end if%>
<%			if GetLong(.Fields("ExpenseTax")) = 0 then 
				ttlTaxFree = ttlTaxFree + GetLong(.Fields("ExpenseAmount")) 
			else
				ttlTax = ttlTax + GetLong(.Fields("ExpenseTax"))
				ttlAmount = ttlAmount + GetLong(.Fields("ExpenseAmount"))
			end if
			if GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax")) = 0 then 
				if CostName <> "RANDOM" then myNull = 1
			end if
			.movenext
		loop
		if cnt > 0 then
%>
	<TR align=right height=20>
		<TD rowspan=2 colspan=6 align=left valign=bottom>
		<TD class=line colspan=2 valign=top><font class=pt9><br>��ېŊz<br>�ېŋ��z<br>�� �� ��</font>
		<TD class=line valign=top><br><%=formatnumber(ttlTaxFree, 0, true)%><br><%=formatnumber(ttlAmount, 0, true)%><br>
<%if fix(ttlAmount * gsTaxRate) = ttlTax then%>
			<%=formatnumber(ttlTax, 0, true)%>
<%else%>
			<font class=pt9t><%=formatnumber(ttlTax, 0, true)%></font>
<%end if%>
	<TR align=right height=20>
		<TD colspan=2 class=pt9>�� �� �z<TD nowrap><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%
		end if
	end with
%>
	</TABLE>
<%
	if cnt = 0 and ChargeType <> gsStand then
		response.write "<script language=javascript>ShowPattern('')</script>"
	end if
	if myNull <> 0 then
%>
	<div align=center>
		<font class=pt12r>�������z���[���̐������ڂ͌�����܂����B</font>
	</div>
<%
	elseif cnt > 0 and ChargeCheck = 0 then
%>
	<div align=right>
		<INPUT style="width:60px;height:25px;" TYPE=button VALUE="����" onclick="DoConfirm()">
	</div>
<%
	elseif ConfirmerID <> 0 then 
%>
	<div align=center>
		<br><font class=pt12r>���b�N��</font>
	</div>
<%
	end if
%>
<script language=javascript>		
function DoShortCut() {
if (window.event.keyCode==38) ShowHead();
<%if ConfirmerID = 0 then%>
if (window.event.keyCode==119) ShowDetail('');
if (window.event.keyCode==120) ShowPattern('');
<%else%>
if (window.event.keyCode==80) DoPrint();
<%end if%>
<%if cnt > 0 then response.write ShortCut%>
}
</script>
</BODY>
</HTML>
<% 
end if
	
set recset = nothing
CloseDB Conn
%>

