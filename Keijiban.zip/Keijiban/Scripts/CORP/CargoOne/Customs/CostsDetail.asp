<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobCode
dim SubCode
dim JobClient
dim JobSalesman
dim ExpenseClient

	myType = GetLong(request("type"))
		
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	myLevel = CheckUserLevel(JobBelong, JobBroker)
	if myLevel < 3 and JobSalesman = WebUserID then myLevel = 3
	
	CostsNo = GetPost(request("CostsNo"))
	SeqNo = GetLong(request("seq"))
	if JobCode <> "" then
	
		mode = 0
		ExpenseCost = 113		'���̑�
		ConfirmerID = 0	
		ExpenseQuantity = 1
		ExpenseUnit = "��"
		
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset")
		with Recset
			strSql = "SELECT CostsClient, CostsClientName, CostsDate, CostsPayDay, CostsType FROM TBL_CTM_COSTS"
			strSql = strSql & " WHERE Deleted = 0 AND CostsNo = '" & CostsNo & "'" ' AND JobCode = '" & JobCode & "'
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then 
				 ExpenseClient = GetString(.fields("CostsClient"))
				 ExpenseClientName = GetString(.fields("CostsClientName"))
				 CostsDate = Str2Date(.fields("CostsDate"))
				 CostsPayDay = Str2Date(.fields("CostsPayDay"))
				 CostsType = GetLong(.fields("CostsType"))
			end if
			.close
		end with
		
		if SeqNo <> 0 then
			with Recset
				strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE SeqNo = " & SeqNo ' AND JobCode = '" & JobCode & "'
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					SubCode = GetString(.fields("JobCode"))
				'	ExpenseClient = GetString(.fields("ExpenseClient"))
					ExpenseCost = GetLong(.fields("ExpenseCost"))
					ExpenseType = GetLong(.fields("ExpenseType"))
					ExpenseAttr = GetLong(.fields("ExpenseAttr"))
					ExpenseDate = Str2Date(.fields("ExpenseDate"))
					ExpenseMemo = GetString(.fields("ExpenseMemo"))
				
					ExpenseQuantity = GetDouble(.fields("ExpenseQuantity"))
					ExpenseUnit = GetString(.fields("ExpenseUnit"))
					ExpensePrice = GetDouble(.fields("ExpensePrice"))
					ExpenseAmount = GetLong(.fields("ExpenseAmount"))
					ExpenseTaxName = GetString(.fields("ExpenseTaxName"))
					ExpenseTax = GetLong(.fields("ExpenseTax"))
					Remarks = GetString(.fields("Remarks"))
					
					ConfirmerID = GetLong(.fields("ConfirmerID"))
					ConfirmDate = GetDate(.fields("ConfirmDate"))
					ExpenseBill = GetString(.fields("ExpenseBill"))
				'	ExpensePay = GetString(.fields("ExpensePay"))
				
					Creater = GetLong(.fields("Creater"))
					Created = GetDate(.fields("Created"))
					Updater = GetLong(.fields("Updater"))
					Updated = GetDate(.fields("Updated"))
				end if
				.close
			end with
			Count = GetDivideCount(JobCode)
		else
			Count = 0
			SubCode = JobCode
			if CostsType = 0 and UserShop <> gsSokoInit then 
				ExpenseType = gsStand
			else
				ExpenseType = gsPayment
			end if
		end if
%>
<html>
<HEAD>
	<TITLE>�x���ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoSearch()
			dim win
			set win = window.open("ClientSearch.asp?mode=1&cd=" & frmInput.Shipper.value,"ClientSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		sub DoDivide()
		dim cnt
			cnt = "1"
			do while GetLong(cnt) < 2
				cnt = inputbox("����������͂��Ă��������B", "����������", <%=Count%>)
				if cnt = "" then exit do
			loop
			if GetLong(cnt) > 1 then
				window.location.href = "CostsDivide.asp?JobCode=<%=JobCode%>&seq=<%=SeqNo%>&count=<%=Count%>&cnt=" & cnt
			end if
		end sub
				
		sub Shipper_OnChange()
			frmInput.JobShipper.value = ""
			frmInput.ShipperName.value = ""
		end sub
		
		sub ExpenseCode_OnBlur()
			if frmInput.ExpenseCode.value <> "" then
				buf = len(frmInput.ExpenseCode.value)
				for each obj in frmInput.ExpenseCost.options
					if left(obj.text, buf) = ucase(frmInput.ExpenseCode.value) then
						obj.selected = true
						exit for
					end if
				next
			end if
		end sub
		
		sub ExpensePrice_OnBlur()
			frmInput.ExpensePrice.value = FitZero(formatnumber(GetDouble(frmInput.ExpensePrice.value),2,true))
			Call CalculateSales()
		end sub
		sub ExpenseQuantity_OnBlur()
			frmInput.ExpenseQuantity.value = GetDouble(frmInput.ExpenseQuantity.value)
			Call CalculateSales()
		end sub
		sub CalculateSales()
		dim buf
			if frmInput.ExpenseCost.options(frmInput.ExpenseCost.selectedIndex).value <> "123" then
				buf = GetDouble(frmInput.ExpensePrice.value) * GetDouble(frmInput.ExpenseQuantity.value)
				frmInput.ExpenseAmount.value = formatnumber(ResetDigital(buf, 0, 0), 0, true)
				Call CalculateTax()
			end if
		end sub
		
		sub ExpenseTax_OnBlur()
			frmInput.ExpenseTax.value = formatnumber(GetLong(frmInput.ExpenseTax.value),0,true)
		end sub
		sub ExpenseAmount_OnBlur()
			frmInput.ExpenseAmount.value = formatnumber(GetLong(frmInput.ExpenseAmount.value),0,true)
			Call CalculateTax()
		end sub
		sub ExpenseTaxName_OnChange()
			Call CalculateTax()
		end sub
		sub CalculateTax()
		dim buf
			if frmInput.ExpenseCost.options(frmInput.ExpenseCost.selectedIndex).value <> "123" then
				buf = frmInput.ExpenseTaxName.options(frmInput.ExpenseTaxName.selectedIndex).text
				buf = GetLong(frmInput.ExpenseAmount.value) * GetTaxRate(buf)
				frmInput.ExpenseTax.value = formatnumber(ResetDigital(buf, 0, -1), 0, true)	
			end if
		end sub
		
		sub DataSave()
		dim buf
			buf = frmInput.ExpenseCost.options(frmInput.ExpenseCost.selectedIndex).value
			if checkText("JobShipper","�x����",1) = false then exit sub
			if buf = "123" or buf = "113" then
				if checkText("ExpenseMemo","���ڔ��l",1) = false then exit sub
			else
				if checkText("ExpenseMemo","���ڔ��l",0) = false then exit sub
			end if
			if checkDouble("ExpensePrice","�x���P��",3) = false then exit sub
			if checkDouble("ExpenseQuantity","�x������",1) = false then exit sub
			if checkNum("ExpenseAmount","�Ŕ����z",3) = false then exit sub
			if checkNum("ExpenseTax","����Ŋz",3) = false then exit sub
			if checkText("Remarks","�x������", 0) = false then exit sub
			if checkLen("Remarks","�x������", 250) = false then exit sub
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub InitForm()
<%if ConfirmerID <> 0 then%>
			call LockAll()
<%else%>
	<%if mode = 0 then%>
			frmInput.ExpenseCode.focus()
	<%else%>
			frmInput.ExpenseMemo.focus()
	<%end if%>	
<%end if%>
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
<%if ConfirmerID = 0 then%>	
					call DataSave() 
<%end if%>
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
		
		sub ExpenseType_OnChange()
			if frmInput.ExpenseType.selectedindex = 1 then
				ShowExpenseAttr(0)
			else
				ShowExpenseAttr(1)
			end if
		end sub
		
		sub ShowExpenseAttr(mode)
		dim buf
			if mode = 0 then
				AttrTitle.InnerHtml = "<font class=pt9n>���ڋ敪</font>"
				buf = "<select name=ExpenseAttr onkeydown=""ResetEnter()"" <%if ConfirmerID <> 0 then response.write "disabled" %>>"
<%for i = 0 to ubound(costType) %>
				buf = buf & "<option value=<%=i%> <%if ExpenseAttr = i then response.write " selected"%>><%=costType(i)%>"
<%next%>
				buf = buf & "</select>"
			else
				AttrTitle.InnerHtml = "<font class=pt9r>��������</font>"
				buf = "<select name=ExpenseAttr onkeydown=""ResetEnter()"" <%if ConfirmerID <> 0 then response.write "disabled" %>>"
				buf = buf & "<option value=0 <%if ExpenseAttr = 0 then response.write " selected"%>>����"
				buf = buf & "<option value=1 <%if ExpenseAttr = 1 then response.write " selected"%>>����</select>"
			end if
			AttrSel.InnerHtml = buf
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsCostsBackColor%>" topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()"  <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CostsUpdate.asp" method="post">
  	<input type=hidden name="type" value="<%=myType%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="CostsNo" value="<%=CostsNo%>">
  	<input type=hidden name="ExpenseDate" value="<%=CostsDate%>">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="mode" value="<%=mode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22><td width=40%>
	  	��<%if myType = 0 then%>����<%elseif myType = 1 then%>����<%else%>�x��<%end if%>�ڍ׏��&nbsp;
<%if mode = 1 and ConfirmerID = 0 then %>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
		<td width=40% class=pt9t><%if JobCode <> SubCode or instr(Remarks, "��") <> 0 then%>�䒠�ԍ��F<%=SubCode%><%else%>
<%if ExpenseBill = "" then%>
	<%if myLevel > 2 then%>	<a class=bar href="javascript:DoDivide()">�y�������z</a><%end if%>
<%end if%><%end if%>
		<td width=20% align=right>
<%	if ConfirmerID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�m��ς�">
<%	elseif ExpenseType <> gsStand and ExpenseAttr = 2 then%>
	  	  <img style="cursor:help" src=img/security.gif alt="���ς�">
<%	else %>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
<%	end if %><br>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=28>
<!--JobShipper�͌�����ʂ𗬗p���邽��-->
		<TD align=center class=pt9g>�x����<input type=hidden name="JobShipper" value="<%=ExpenseClient%>" readonly>
		<TD colspan=5>(<input class=si name="Shipper" size=8 maxlength=10 value="<%=GetRefName(ExpenseClient)%>" onkeydown="ResetEnter()" readonly>)
			<input class=si name="ShipperName" size=45 value="<%=ExpenseClientName%>" onkeydown="ResetEnter()" readonly>
		<TD align=center>�x���敪
<%if mode = 0 or ExpenseBill = "" then%>
		<TD align=center>
		  <select name="ExpenseType" onkeydown="ResetEnter()" <%if ConfirmerID <> 0 then response.write "disabled" %>>
			<option value="<%=gsStand%>" <%if ExpenseType = gsStand then response.write " selected"%>>����
			<option value="<%=gsPayment%>" <%if ExpenseType = gsPayment then response.write " selected"%>>����</SELECT>
<%else%>
		<TD align=center class=gline>
			<input type=hidden name="ExpenseType" value="<%=ExpenseType%>"><%=ShowExpenseType(ExpenseType)%>
<%end if%>
	  <TR height=28>
		<TD align=center>����<%if ConfirmerID = 0 then%><input class=si name="ExpenseCode" size=3 maxlength=3 value="" onkeydown="ResetEnter()"><%end if%>
		<TD colspan=3><select name="ExpenseCost" onkeydown="ResetEnter()" <%if ConfirmerID <> 0 then response.write "disabled" %>>
						<%=ShowExpenseList(ExpenseCost)%></select>
		<TD align=center class=pt9g>�퐿����<TD class=gline align=center><%=CostsDate%><br>
		<TD align=center class=pt9g>�x���ԍ�<TD class=gline align=center><%=CostsNo%><br>
	  <TR height=28>
		<TD align=center class=pt9>���ڔ��l
		<TD colspan=5><input class=sj name="ExpenseMemo" size=58 maxlength=250 value="<%=ExpenseMemo%>" onkeydown="ResetEnter()">
		<TD align=center><div id=AttrTitle><%if ExpenseType = gsStand then%>��������<%else%>���ڋ敪<%end if%></div>
		<TD class=gline align=center>
<%if mode = 0 or ExpenseBill = "" then%>
			<div id=AttrSel></div>
<%else%>
	<%if ExpenseType = gsStand then%>
			<input type=hidden name="ExpenseAttr" value="<%=ExpenseAttr%>"><%=ShowExpenseAttr(ExpenseAttr)%>
	<%else%>
			<input type=hidden name="ExpenseAttr" value="<%=ExpenseAttr%>"><%=ShowExpenseAttrFull(ExpenseAttr)%>
	<%end if%>
<%end if%>
	  <TR height=28>
		<TD align=center width=60 nowrap>�x���P��
		<TD><input class=sn name="ExpensePrice" size=10 maxlength=8 value="<%=FitZero(formatnumber(ExpensePrice, 2, true))%>" onkeydown="ResetEnter()">
		<TD align=center width=60 nowrap>�x������
		<TD><input class=sn name="ExpenseQuantity" size=8 maxlength=8 value="<%=ExpenseQuantity%>" onkeydown="ResetEnter()">
		<TD align=center width=60 nowrap>�x���P��
		<TD><select name="ExpenseUnit" onkeydown="ResetEnter()" <%if ConfirmerID <> 0 then response.write "disabled" %>>
				<%=ShowCategoryList("ChargeUnit", ExpenseUnit, 1)%></select>
		<TD align=center width=60 nowrap>�Ŕ����z
		<TD><input class=sn name="ExpenseAmount" size=12 maxlength=10 value="<%=formatnumber(ExpenseAmount, 0, true)%>" onkeydown="ResetEnter()">
	  <TR height=28>
		<TD align=center>�ېŋ敪
		<TD><select name="ExpenseTaxName" onkeydown="ResetEnter()" <%if ConfirmerID <> 0 then response.write "disabled" %>>
				<%=ShowCategoryList("TaxCode", ExpenseTaxName, 1)%></select>
		<TD align=center class=pt9>�����
		<TD><input class=sn name="ExpenseTax" size=8 maxlength=8 value="<%=formatnumber(ExpenseTax, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=GetEmployName(ConfirmerID, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=formatDate(ConfirmDate)%><br>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=28>
		<TD class=pt9 align=center>����
		<TD colspan=5><textarea name="Remarks" rows=4 style="width:350"><%=Remarks%></textarea>
		<TD colspan=2 align=center>
<%if gsSaveButton = 1 and ConfirmerID = 0 and ExpenseBill = "" then%>
			<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" name=btnClose value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  	<input style="width:0;height:0" name="COST_TAX" value="">
  	<input style="width:0;height:0" name="COST_TYPE" value="">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
  </FORM>
<center>
<%if mode = 0 or ExpenseBill = "" then%>
<script language=vbscript>
	call ShowExpenseAttr(<%=GetLong(ExpenseType = gsStand)%>)
</script>
<%end if%>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function ShowExpenseList(myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT COST_ID, COST_CD, COST_NAME FROM MST_COST"
	mySql = mySql & " WHERE COST_DELETED = 0"
	if ExpenseClient = gsCorpSoko then mySql = mySql & " AND SUBSTRING(COST_ATTR,3,1) = '1'"
	mySql = mySql & " ORDER BY COST_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("COST_ID")
		if myDft = myRec.fields("COST_ID") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("COST_CD") & " " & myRec.fields("COST_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowExpenseList = buf	
end function

function GetDivideCount(myJob)
dim mySql
dim myRec
	GetDivideCount = 0
	set myRec = Server.CreateObject ("ADODB.Recordset")
	mySql = "SELECT COUNT(JobCode) AS CNT FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobNo IN"
	mySql = mySql & " (SELECT CASE JobNo WHEN '' THEN JobCode ELSE JobNo END FROM TBL_CTM_JOB"
	mySql = mySql & " WHERE JobCode = '" & myJob & "')"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetDivideCount = GetLong(myRec.fields("CNT"))
	myRec.close
	set myRec = nothing
end function
%>