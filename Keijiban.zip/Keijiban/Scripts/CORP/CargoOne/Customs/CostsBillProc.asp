<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�x���`�[�ꗗ�Ɖ���
'----------------------------------------------

'on error resume next
dim JobSeq
dim myMode
		
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	myLevel = CheckUserLevel(UserShop, JobBroker)
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		CostsCheck = 1
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		PayDayFrom = GetPost(request("PayDayFrom"))
		PayDayTo = GetPost(request("PayDayTo"))
		JobCode = GetPost(request("JobCode"))
		CostsBatch = GetPost(request("CostsBatch"))
		CostsNo = GetPost(request("CostsNo"))
		CostsBillNo = GetPost(request("CostsBillNo"))
		CostsCheck = GetLong(request("CostsCheck"))
		
		'�ꊇ�m�菈��
		if myMode = 2 then	
			msg = ""
			JobSeq = split(GetPost(request("JobSeq")), ",")
			
			for i = 0 to ubound(JobSeq)
				myJob = trim(GetLeft(JobSeq(i), "."))
				myNo = trim(GetRight(JobSeq(i), "."))
				
				if CheckCostsMatched(Conn, myJob, myNo) = false then
					msg = "�Y���x���`�[���z�Ɩ��׍��v���z�͈�v�ł͂���܂���I(" & "�x���ԍ��F" & myNo & "�䒠�ԍ��F" & myJob & ")"
					exit for
				end if
			next
			
			if msg = "" then
				Conn.BeginTrans
				
				for i = 0 to ubound(JobSeq)
					myJob = trim(GetLeft(JobSeq(i), "."))
					myNo = trim(GetRight(JobSeq(i), "."))
					
					'��p���ڊm��
					strSql = "UPDATE TBL_CTM_EXPENSE SET ConfirmDate = GETDATE()"
					strSql = strSql & ", ConfirmerID = " & WebUserID
					strSql = strSql & " WHERE JobCode = '" & myJob & "'"
					strSql = strSql & " AND ExpensePay = '" & myNo & "'"
					Conn.execute strSql
					
					'�x���`�[�m��
					strSql = "UPDATE TBL_CTM_COSTS SET ConfirmDate = GETDATE()"
					strSql = strSql & ", ConfirmerID = " & WebUserID
					strSql = strSql & " WHERE JobCode = '" & myJob & "'"
					strSql = strSql & " AND CostsNo = '" & myNo & "'"
					Conn.execute strSql
					
					call Payment2Biz(1, Conn, myNo, myJob)		'�d��쐬
					
					if err.number <> 0 then exit for
				next
				
				if err.number = 0 then
					Conn.CommitTrans
					msg = "�m�菈���͖����������܂����B"
				else
					Conn.RollbackTrans
					msg = "�m�菈�������L�̃G���[���N����܂����B(" & err.number & ":" & err.description & ")"
				end if
			end if
		end if
	end if

%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�x���`�[�m�菈��</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function DoCheck()
			Call CheckAll("JobSeq", frmInput.CheckAll.Checked)
		end function 
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
	
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 6) = "JobSeq" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�m�肷��x���`�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "ClientRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=2&JobCode=" & myJob & "&CostsNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
						
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub PayDayFrom_OnBlur()
			frmInput.PayDayFrom.value = setdate(frmInput.PayDayFrom.value)
		end sub
		sub PayDayTo_OnBlur()
			frmInput.PayDayTo.value = setdate(frmInput.PayDayTo.value)
		end sub
		sub CostsBatch_OnBlur()
			frmInput.CostsBatch.value = FitBatchNo(frmInput.CostsBatch.value)
		end sub
		sub CostsNo_OnBlur()
<%if WebUserID <> 1 then%>
			frmInput.CostsNo.value = FitCostsNo(frmInput.CostsNo.value)
<%end if%>
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = UCASE(frmInput.JobCode.value)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
<%if myMode = 2 then%>
	<%if gsMsgBatch = 1 then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
	<%end if%>
<%else%>
			frmInput.DateFrom.focus()
<%end if%>
			window.parent.parent.result.location.href = "CostsBatchList.asp"
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CostsBillProc.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�퐿����<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�x����<input class=si name="PayDayFrom" value="<%=PayDayFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="PayDayTo" value="<%=PayDayTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�x����<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
			<TR><TD nowrap>
				�ޯ��� <input class=sn name="CostsBatch" value="<%=CostsBatch%>" maxlength=6 size=6 onkeydown="ResetEnter()">
				�`�[�ԍ�<input class=si name="CostsNo" value="<%=CostsNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				���臂<input class=si name="CostsBillNo" value="<%=CostsBillNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">		
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="CostsCheck" value="1" <%if CostsCheck then response.write " checked"%>>
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if ClientRef <> "" then	strSel = strSel & " AND (ClientRef = '" & FitSel(ClientRef) & "' OR CostsClientName LIKE '% " & FitSel(ClientRef) & "%')"
	if DateFrom <> "" then strSel = strSel & " AND CostsDate >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND CostsDate <= '" & Date2Str(DateTo) & "'"	
	if PayDayFrom <> "" then strSel = strSel & " AND CostsPayDay >= '" & Date2Str(PayDayFrom) & "'"
	if PayDayTo <> "" then strSel = strSel & " AND CostsPayDay <= '" & Date2Str(PayDayTo) & "'"	
	if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'"
	if CostsBillNo <> "" then strSel = strSel & " AND CostsBillNo LIKE '%" & FitSel(CostsBillNo) & "%'"	
	if CostsBatch <> "" then strSel = strSel & " AND CostsBatch = '" & FitSel(CostsBatch) & "'"
	if CostsNo <> "" then strSel = strSel & " AND CostsNo LIKE '" & FitSel(CostsNo) & "%'"	
	if CostsCheck <> 0 then strSel = strSel & " AND CostsCheck = 1"
		
	with recset
		strSql = "SELECT JobCode, CostsNo, CostsBatch, CostsType, CostsClient, ClientRef, JobBelong, CostsClientName, COST_NAME, ETYP, ATTR"
		strSql = strSql & ", CostsDate, CostsAmount, CostsTax, CostsPayDay, CostsCheck, CTM_REF, CTM_NAME FROM TBL_CTM_Costs AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT ExpensePay, MIN(ExpenseCost) AS CID, MAX(ExpenseType) AS ETYP, MIN(ExpenseAttr) AS ATTR"
		strSql = strSql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 GROUP BY ExpensePay) AS E ON T.CostsNo = E.ExpensePay"
		strSql = strSql & " INNER JOIN (SELECT COST_ID, COST_NAME FROM MST_COST) AS M ON E.CID = M.COST_ID"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, JobClient, CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit
		strSql = strSql & "' ELSE JobBelong END AS JobBelong FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF, CTM_NAME FROM CUSTOMER) AS S ON J.JobClient = S.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID = 0 AND CostsBatch = ''"	'���폜�@�������@���m��@���ޯ�
		if CheckTopLevel() = 0 then strSql = strSql & " AND CostsClient <> '" & gsCorpSoko & "' AND CostsClient <> '" & gsCorpTruck & "' AND JobBelong = '" & UserShop & "'"
		if CheckUserLevel(UserShop, "") < 2 then strSql = strSql & " AND CostsType = 0"
		if strSel <> "" then strSQL = strSQL & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY CTM_REF, JobCode"
		case 1:		strSql = strSql & " ORDER BY JobCode"
		case 2:		strSql = strSql & " ORDER BY ETYP, CostsPayDay"
		case 3:		strSql = strSql & " ORDER BY CostsPayDay, JobCode"
		case 4:		strSql = strSql & " ORDER BY COST_NAME, JobCode"
		case 5:		strSql = strSql & " ORDER BY ClientRef, JobCode"
		case 6:		strSql = strSql & " ORDER BY CostsAmount+CostsTax"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			lngCount = 0
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		  <TR align=center height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�����׎�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">��\��ږ���
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">���z���v
			<TD class=line nowrap colspan=2><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S
<%
			cnt = 0
			ttlTax = 0
			ttlAmount = 0
			Do Until .EOF
				lngCount = lngCount + 1
				JobCode = GetString(.Fields("JobCode"))	
				CostsNo = GetString(.Fields("CostsNo"))
				CostName = GetString(.Fields("COST_NAME"))
				CTM_REF = GetString(.Fields("CTM_REF"))	
%>
		<TR align=center height=20>
			<TD class=line><%=lngCount%><BR>
			<TD class=line><%=replace(ShowCostsType(.Fields("CostsType")),"��","")%><BR>
			<TD class=line nowrap align=left title="<%=GetString(.Fields("CTM_NAME"))%>"><%=StringCut(GetString(.Fields("CTM_REF")),7)%><BR>
			<TD class=line nowrap align=left><%=ShowJobCode(JobCode)%><BR>
			<TD class=line nowrap align=left <%=ShowTitle(CostName, 7)%>><%=StringCut(CostName,7)%><BR>
			<TD class=line><%=ShowDivision(.Fields("ETYP"), .Fields("ATTR"))%>
			<TD class=line nowrap align=left title="<%=GetString(.Fields("CostsClientName"))%>"><%=StringCut(GetString(.Fields("ClientRef")),7)%><BR>
			<TD class=line style="color:blue"><%=Str2MD(.Fields("CostsPayDay"))%><BR>
			<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax")), 0, true)%><BR>
			<TD class=line style="color:gray"><%if .Fields("CostsCheck") then%>
				<input type=checkbox name="JobSeq" value="<%=JobCode%>.<%=CostsNo%>"><%else%>��<%end if%>
			<TD class=line><IMG SRC='img/search.jpg' STYLE='cursor:hand' onclick="ShowDetail('<%=JobCode%>', '<%=CostsNo%>')">
<%
				if .Fields("CostsCheck") then cnt = cnt + 1
				ttlTax = ttlTax + GetLong(.Fields("CostsTax"))
				ttlAmount = ttlAmount + GetLong(.Fields("CostsAmount"))
				.movenext
			loop
			if lngCount > 1 then
%>			
		<TR align=right height=20>
			<TD colspan=6>
			<TD class=line>�� �v
			<TD class=line colspan=2><%=formatnumber(ttlAmount + ttlTax, 0, true)%>
		
<%
			end if
%>
		</TABLE>
<%if myLevel > 1 then%>
		<div align=right>
			<%if cnt > 0 then%><INPUT style="width:60px;height:25px;" TYPE=button VALUE="�m��" onclick="DoConfirm()"><%end if%>
		</div>
<%end if
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowDivision(myType, myAttr)
dim buf
	buf = ""
	if GetLong(myType) = gsStand then
		if GetLong(myAttr) = 0 then
			buf = "<font class=pt9g>����</font>"
		else
			buf = "<font class=pt9g>��</font><font class=pt9b>��</font>"
		end if
	else
		buf = "<font class=pt9>���</font>"
	end if
	ShowDivision = buf
end function
%>