<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myJob()
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		if instr(Session("Depart"), "�A�o") = 0 then 
			JobType = gsImport
		else
			JobType = gsExport
		end if
		BrokerRef = "HONSHA"
	else
		JobType = GetPost(request("JobType"))
		JobNo = GetPost(request("JobNo"))
		ClientRef = GetPost(request("ClientRef"))
		EtdEta = GetPost(request("EtdEta"))
		Vessel = GetPost(request("Vessel"))
		BrokerRef = GetPost(request("BrokerRef"))
		
		if myMode > 1 then
			SelJob = GetPost(request("SelJob"))
			if SelJob <> "" then
				myStr = "'" & SelJob & "'"
				cnt = GetLong(request("cnt"))
				for i = 1 to cnt
					if GetPost(request("JobCode" & i)) <> "" then
						myStr = myStr & ",'" & GetPost(request("JobCode" & i)) & "'"
					end if
				next
				strSql = "UPDATE TBL_CTM_JOB SET JobNo = '" & SelJob & "'"
				strSql = strSql & ", Updated = GETDATE(), Updater = " & WebUserID
				strSql = strSql & " WHERE JobCode IN (" & myStr & ")"
				Conn.Execute strSql
			end if
		end if
	end if

	myLevel = CheckUserLevel(UserShop, "")

%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoCheck()
			Call CheckAll("JobCode", frmInput.CheckAll.Checked)
		end function
		
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function DoConfirm()
			myCnt = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 7) = "JobCode" and obj.Checked then
						myCnt = myCnt + 1
					end if
				end if
			next
			if myCnt < 2 then
				msgbox "�l�ߍ��킹�䒠�ԍ���񌏈ȏ�I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
<%if gsPolite = 1 then%>
			if msgbox ("����Ŏ��s���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.mode.value = 2
			frmInput.submit()
		end function
		
		function ShowList(mode)
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & cd, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
		
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub EtdEta_OnBlur()
			frmInput.EtdEta.value = setdate(frmInput.EtdEta.value)
		end sub
		sub JobNo_OnBlur()
			frmInput.JobNo.value = FitJobCode(frmInput.JobNo.value)
		end sub
		
		sub DoSearch()
			if checkText("ClientRef","�����׎�",0) = false then exit sub
			if checkText("JobNo","��\�ԍ�",0) = false then exit sub
			if frmInput.JobNo.value = "" then
				if checkText("Vessel","�D��",1) = false then exit sub
				if checkDate("EtdEta","���o�`��",1) = false then exit sub
				if checkText("BrokerRef","�ʊ֋Ǝ�",1) = false then exit sub
			end if
			frmInput.submit()
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then DoSearch()
		end sub
		
		sub FormInit()
			frmInput.ClientRef.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="FormInit()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CustomsAssort.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�敪&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><%=ShowJobType(JobType)%></select>
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�D��&nbsp;<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=10 onkeydown="ResetEnter()">
				���o�`��&nbsp;<input class=si name="EtdEta" value="<%=EtdEta%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�ʊ֋Ǝ�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(6)">
					<input class=si name="BrokerRef" value="<%=BrokerRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				��\�ԍ�<input class=si name="JobNo" value="<%=JobNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=BUTTON name=btnSearch VALUE="����" onclick="DoSearch()">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'"
		if JobNo <> "" then strSel = strSel & " AND JobNo = '" & FitSel(JobNo) & "'" 
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)
		if EtdEta <> "" then strSel = strSel & " AND ETAETD = '" & Date2Str(EtdEta) & "'"
		if Vessel <> "" then strSel = strSel & " AND Vessel LIKE '%" & FitSel(Vessel) & "%'"
		if BrokerRef <> "" then	strSel = strSel & " AND BrokerRef = '" & FitSel(BrokerRef) & "'"
		
		strSQL = "SELECT * FROM (SELECT JobCode, ClientRef, BrokerRef, JobSalesman, JobBelong, Created, InvoiceNo"
		strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD"
		strSQL = strSQL & ", POL, POD, Vessel, Voy, Quantity, GW, CBM, DeliveryDate, JobNo FROM TBL_CTM_JOB AS T "
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON T.CustomBroker = B.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0) AS TMP"
		if myLevel < 4 then
			if UserShop <> gsCorpInit then
				strSQL = strSQL & " WHERE JobBelong = '" & UserShop & "' AND " & mid(strSel, 5)
			else
				strSQL = strSQL & " WHERE (JobBelong = '" & UserShop & "' OR BrokerRef= 'HONSHA') AND " & mid(strSel, 5)
			end if
		else
			if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel, 5)
		end if
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY JobNo, Vessel"
		case 1:		strSQL = strSQL & " ORDER BY JobNo, JobCode"
		case 2:		strSQL = strSQL & " ORDER BY JobNo, ClientRef"
		case 3:		strSQL = strSQL & " ORDER BY JobNo, POL, POD"
		case 4:		strSQL = strSQL & " ORDER BY JobNo, DeliveryDate"
		case 5:		strSQL = strSQL & " ORDER BY JobNo, JobSalesman"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=2 align=center>
			<colgroup span=5 align=left>
			<colgroup span=3 align=right>
			<colgroup span=3 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD colspan=2 nowrap>�I��
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����׎�
			<TD width=15% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�D��
			<TD width=15% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">���H
			<TD width=15%>Inv ��
			<TD width=5%>��
			<TD width=6%>G.W.
			<TD width=6%>CBM
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">������
			<TD width=4% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�c��
			<TD width=8% nowrap>��\�ԍ�
<%
				cnt = 0:	qty = 0
				gw = 0:		cbm = 0
				Do While not .EOF	
					ClientRef = GetString(.Fields("ClientRef"))
					BrokerRef = GetString(.Fields("BrokerRef"))
					Vessel = GetString(.Fields("Vessel"))
					if GetString(.Fields("Voy")) = "" then Vessel = Vessel & " V." & GetString(.Fields("Voy"))
					InvoiceNo = GetString(.Fields("InvoiceNo"))
					'if InvoiceNo = "" then InvoiceNo = GetString(.Fields("ReferNo"))
					Port = GetString(.Fields("POL")) & "��" & GetString(.Fields("POD"))
					JobNo = GetString(.Fields("JobNo"))
					if JobNo = "" then cnt = cnt + 1
%>
					<TR><TD nowrap class=line><%if JobNo <> "" then%>�~<%else%>
							<input type=checkbox name="JobCode<%=cnt%>" value="<%=GetString(.Fields("JobCode"))%>"><%end if%>
						<TD nowrap class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=GetString(.Fields("JobCode"))%>')">
						<TD nowrap class=line><%=ShowJobCode(.Fields("JobCode"))%><BR>
						<TD nowrap class=line><%=ClientRef%><BR>
						<TD nowrap class=line><%=Vessel%><BR>
						<TD nowrap class=line><%=Port%>
						<TD nowrap class=line <%=ShowTitle(InvoiceNo, 16)%>><%=stringCut(InvoiceNo, 16)%><BR>
						<TD nowrap class=line><%=GetDouble(.Fields("Quantity"))%>
						<TD nowrap class=line><%=formatnumber(GetDouble(.Fields("GW")), 0, true)%>
						<TD nowrap class=line><%=formatnumber(GetDouble(.Fields("CBM")), 3, true)%>
						<TD nowrap class=line><%=Str2YMD(.Fields("DeliveryDate"))%><BR>
						<TD nowrap class=line><%=GetEmployName(.Fields("JobSalesman"), "F")%>
						<TD nowrap class=line><%if JobNo <> "" then%><%=JobNo%><%else%>
							<input type=radio name="SelJob" value="<%=GetString(.Fields("JobCode"))%>" <%if cnt = 1 then response.write "checked"%>><%end if%>
					</TR>
<%
					qty = qty + GetDouble(.Fields("Quantity"))
					gw = gw + GetDouble(.Fields("GW"))
					cbm = cbm + GetDouble(.Fields("CBM"))
					.MoveNext
				Loop
%>
				<TR><TD colspan=2 nowrap><%if cnt > 1 then%><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S��<%end if%>
					<TD colspan=5 align=right class=pt9>���v
					<TD nowrap class=line><%=GetDouble(qty)%>
					<TD nowrap class=line><%=formatnumber(gw, 0, true)%>
					<TD nowrap class=line><%=formatnumber(cbm, 3, true)%>
<%
				if cnt > 1 then
%>
					
				<TR><TD colspan=12 align=right><INPUT TYPE=hidden name="cnt" VALUE="<%=cnt%>">
					<INPUT style="width:90px;height:30px;" TYPE=BUTTON name=btnSearch VALUE="���s" onclick="DoConfirm()">
<%
				end if
%>
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>