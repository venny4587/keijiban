<!-- #include file="../common/common.asp" -->
<%
	select case webUserID 
	case 1, 43, 57, 62, 88
		myStock = 1
	case else
		myStock = 0 
	end select
%>
<html>
<head>
	<title>Main Menu Bar</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)			
		btnCheck.style.color = "black"
		btnHonsha.style.color = "black"
		btnStand.style.color = "black"
		btnView.style.color = "black"
		btnCarry.style.color = "black"
		btnCustom.style.color = "black"
		btnPermit.style.color = "black"
<%if myStock = 1 then %>
		btnStock.style.color = "black"
<%end if%>
		select case mySel 
		case 0
			url = "CustomsCheck.asp"
			btnCheck.style.color = "red"
		case 1
			url = "CustomsHonsha.asp"
			btnHonsha.style.color = "red"
		case 2
			url = "CustomsStand.asp"
			btnStand.style.color = "red"
		case 3
			url = "CustomsView.asp"
			btnView.style.color = "red"
		case 4
			url = "DeliveryView.asp"
			btnCarry.style.color = "red"
		case 5
			url = "CustomsInput.asp"
			btnCustom.style.color = "red"
		case 6
			url = "PermitView.asp"
			btnPermit.style.color = "red"
		case 7
			url = "StockInView.asp"
			btnStock.style.color = "red"
		case else
			url = "../common/blank.htm"
		end select
		window.parent.cbody.location.href = url
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnCheck value="�{�Ў�t�҂�" onclick="DoAct(0)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnHonsha value="�{�Д��s�ꗗ" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnStand value="�������Ɖ�" onclick="DoAct(2)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnView value="�Ɩ����Ɖ�" onclick="DoAct(3)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnCarry value="�[�i���Ɖ�" onclick="DoAct(4)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnCustom value="�{�Вʊ֐�p" onclick="DoAct(5)"></TD>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnPermit value="�����Ɖ�" onclick="DoAct(6)"></TD>
<%if myStock = 1 then %>
		    <TD width=120>
		    	<INPUT type=button style="WIDTH: 110px; HEIGHT: 30px;" name=btnStock value="�S�ύ݌ɊǗ�" onclick="DoAct(7)"></TD>
<%end if%>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
