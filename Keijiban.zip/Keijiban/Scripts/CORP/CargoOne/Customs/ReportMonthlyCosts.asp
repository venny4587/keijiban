<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�Ǝҕʎx�����ʐ��ڕ\
'----------------------------------------------
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobType = GetPost(request("JobType"))
	JobBelong = GetPost(request("JobBelong"))
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 4  then JobBelong = UserShop
	
	mySort = GetLong(request("sort"))
	if mySort = 0 then mySort = 1
	
	SelName = GetString(request("SelName"))
	if SelName = "" then SelName = "jp"
	
	SelYear = GetLong(request("SelYear"))
	if SelYear = 0 then 
		if month(date) > 4 then 
			SelYear = year(date)
		else
			SelYear = year(date) - 1
		end if
	end if
		
	call GetAccountYear(SelYear, AccountFrom, AccountTo)

%>

<HTML>
<HEAD>
	<TITLE>�Ǝҕʎx�����ʐ��ڕ\</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		sub DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.Submit()
		end sub
			
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ReportMonthlyCosts.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="AccountBelong" VALUE='<%=AccountBelong%>'>
		<INPUT TYPE="HIDDEN" NAME="AccountMonth" VALUE='<%=AccountMonth%>'>
		<input type=hidden name="sort" value="<%=mySort%>">
		<table class=pt9>
			<TR><TD nowrap>�Ɩ�����
<%if myLevel > 3 then%>
	  			<select name=JobBelong onkeydown="ResetEnter()"><option value="">�S��<%=ShowShopList(JobBelong)%></select>&nbsp;
<%else%>
					<input type=hidden name="JobBelong" value="<%=JobBelong%>">
					<u>&nbsp;<font color=green><%=GetShopName(JobBelong)%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�Ɩ��敪&nbsp;
					<select name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>&nbsp;
				<TD nowrap>�׎喼��&nbsp;
					<select name="SelName" onkeydown="ResetEnter()">
						<option value="jp" <%if SelName = "jp" then response.write "selected"%>>�a������
						<option value="en" <%if SelName = "en" then response.write "selected"%>>�p������
						<option value="ref" <%if SelName = "ref" then response.write "selected"%>>��������
						<option value="abr" <%if SelName = "abr" then response.write "selected"%>>�a������
					</select>					
				<TD nowrap>�Ώ۔N�x&nbsp;
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
<div id=list>
�Ώ۔N�x�F<%=ShowJpnYear(left(AccountFrom,4))%><%=GetJapanNo(right(AccountFrom,2))%>���`<%=ShowJpnYear(left(AccountTo,4))%><%=GetJapanNo(right(AccountTo,2))%>��
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup span=3 align=left>
		<colgroup span=13 align=right>
		<TR>
			<TD>��
<%select case SelName%>
<%case "jp"%><TD style="cursor:hand;" onmousedown="DoSort(1)" <%if mySort=1 then%>style="color:blue"<%end if%>>�a������
<%case "en"%><TD style="cursor:hand;" onmousedown="DoSort(2)" <%if mySort=2 then%>style="color:blue"<%end if%>>�p������
<%case "ref"%><TD style="cursor:hand;" onmousedown="DoSort(3)" <%if mySort=3 then%>style="color:blue"<%end if%>>��������
<%case "abr"%><TD style="cursor:hand;" onmousedown="DoSort(4)" <%if mySort=4 then%>style="color:blue"<%end if%>>�a������
<%end select%>
			<TD nowrap>����
<%for i = 1 to 12%>
			<TD nowrap><%if gsSysCloseMonth + i > 12 then%><%=(gsSysCloseMonth + i - 12)%>����<%else%><%=(gsSysCloseMonth + i)%>����<%end if%>
<%next%>	
			<TD nowrap>���v
		
<%
	cnt = 0
	redim sumCount(12)
	redim sumCosts(12)
	redim sumBenefit(12)	
	for i = 0 to 12 
		sumCount(i) = 0:		sumCosts(i) = 0
	next
	with recset
		strSql = "SELECT B.*, ISNULL(CTM_REF, 'UNKNOWN') AS ref, ISNULL(CTM_NAME, '���o�^') AS jp, ISNULL(CTM_ENAME, 'UNKNOWN') AS en, ISNULL(CTM_ABR, '���o�^') AS abr "
		strSql = strSql & " FROM (SELECT BIZ_BROKER_CD, BIZ_MONTH, COUNT(BIZ_JOBCODE) AS Total, SUM(BIZ_TTL) AS Costs FROM ("
		strSql = strSql & " SELECT BIZ_BROKER_CD, BIZ_MONTH, BIZ_JOBCODE, SUM(BIZ_AMOUNT + BIZ_TAX) AS BIZ_TTL FROM TBL_CTM_BIZ"
		strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_TYPE = "  & bizCosts
		strSql = strSql & " AND BIZ_MONTH BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if JobBelong <> "" then strSql = strSql & " AND BIZ_BELONG = '" & JobBelong & "'" 
		if JobType <> "" then strSql = strSql & " AND SUBSTRING(BIZ_JOBCODE,2,1) = '" & JobType & "'"
		strSql = strSql & " GROUP BY BIZ_BROKER_CD, BIZ_MONTH, BIZ_JOBCODE) AS TMP GROUP BY BIZ_BROKER_CD, BIZ_MONTH) AS B " 
		strSql = strSql & "  LEFT JOIN (SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_ENAME, CTM_ABR FROM CUSTOMER) AS C ON B.BIZ_BROKER_CD = C.CTM_CD"
		select case mySort
		case 1:		strSql = strSql & " ORDER BY jp"
		case 2:		strSql = strSql & " ORDER BY en"
		case 3:		strSql = strSql & " ORDER BY ref"
		case 4:		strSql = strSql & " ORDER BY abr"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		myClient = ""
		fromMonth = Str2Date(AccountFrom & "01")
		do while not .EOF
			myName = ResetCorpName(.fields(SelName))			
			if myClient <> myName then
				if myClient <> "" then
					cnt = cnt + 1
%>
		<TR>
			<TD rowspan=2><%=cnt%>
			<TD rowspan=2><%=myClient%>
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(myCount(i), 0, true)%>
<%	next%>
		<TR bgcolor="F0FFF0">
			<TD>���z
<%for i = 0 to 12%>
			<TD><%=formatnumber(myCosts(i), 0, true)%>
<%	next%>
<%
					for i = 0 to 12
						sumCount(i) = sumCount(i) + myCount(i)
						sumCosts(i) = sumCosts(i) + myCosts(i)
					next
				end if
				myClient = myName
				redim myCount(12)
				redim myCosts(12)			
				for i = 0 to 12 
					myCount(i) = 0:		myCosts(i) = 0
				next
			end if
			
			curMonth = Str2Date(GetString(.fields("BIZ_MONTH")) & "01")
			idx = datediff("m",fromMonth, curMonth)
			
			myCount(idx) = myCount(idx) + GetLong(.fields("Total"))
			myCosts(idx) = myCosts(idx) + GetLong(.fields("Costs"))
			
			myCount(12) = myCount(12) + GetLong(.fields("Total"))
			myCosts(12) = myCosts(12) + GetLong(.fields("Costs"))
			
			.movenext
		loop
		.Close
	end with
	
	if myClient <> "" then
		cnt = cnt + 1
%>
		<TR>
			<TD rowspan=2><%=cnt%>
			<TD rowspan=2><%=myClient%>
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(myCount(i), 0, true)%>
<%	next%>
		<TR bgcolor="F0FFF0">
			<TD>�x��
<%for i = 0 to 12%>
			<TD><%=formatnumber(myCosts(i), 0, true)%>
<%	next%>
<%
		for i = 0 to 12
			sumCount(i) = sumCount(i) + myCount(i)
			sumCosts(i) = sumCosts(i) + myCosts(i)
		next
	end if
	if cnt > 0 then		
%>
		<TR>
			<TD colspan=2 rowspan=2 align=center>���@�v
			<TD>����
<%for i = 0 to 12%>
			<TD><%=formatnumber(sumCount(i), 0, true)%>
<%	next%>
		<TR bgcolor="F0FFF0">
			<TD>�x��
<%for i = 0 to 12%>
			<TD><%=formatnumber(sumCosts(i), 0, true)%>
<%	next%>
<%end if%>
	</TABLE>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>