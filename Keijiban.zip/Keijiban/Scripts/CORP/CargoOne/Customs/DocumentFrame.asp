<HTML>
<HEAD>
<TITLE>��������</TITLE>
</HEAD>
	<FRAMESET cols="550,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="DocumentMain.asp" NAME="search" MARGINWIDTH="0" MARGINHEIGHT="0">
		<FRAME SRC="" NAME="result" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>