<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim ExpenseID
	
	blnDelete = True
	ExpenseID = GetLong(request("ExpenseID"))
	PatternID = GetLong(request("PatternID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName

	strSQL = "DELETE FROM PTN_EXPENSE WHERE ExpenseID = " & ExpenseID
	Conn.Execute strSQL
	
	strURL = "ExpenseDetail.asp?PatternID=" & PatternID & "&p=" & Request("p") & "&s=" & Request("s")
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing

	Response.Redirect strURL
%>