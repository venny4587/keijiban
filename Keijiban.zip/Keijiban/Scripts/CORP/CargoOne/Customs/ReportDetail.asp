<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�q�ʎc���ꗗ�Ɖ���
'----------------------------------------------
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobType = GetPost(request("JobType"))
	JobBelong = GetPost(request("JobBelong"))
	JobSalesman = GetLong(request("JobSalesman"))
	myLevel = CheckUserLevel(UserShop, "")
	if myLevel < 4  then JobBelong = UserShop
	
	mySort = GetLong(request("sort"))
	SelName = GetString(request("SelName"))
	if SelName = "" then SelName = "jp"
		
	SelYear = GetLong(request("SelYear"))
	SelMonth = GetLong(request("SelMonth"))
	if SelYear = 0 or SelMonth = 0 then
		SelDate = date
		if day(SelDate) <= 31 then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
		if myLevel < 4  then JobSalesman = WebUserID
	end if	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
%>

<HTML>
<HEAD>
	<TITLE>�q�ʎc���ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		sub DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.Submit()
		end sub
			
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="ReportDetail.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="AccountMonth" VALUE='<%=AccountMonth%>'>
		<input type=hidden name="sort" value="<%=mySort%>">
		<table class=pt9>
			<TR><TD nowrap>�Ɩ�����
<%if myLevel > 3 then%>
	  			<select name=JobBelong onkeydown="ResetEnter()"><option value="">�S��<%=ShowShopList(JobBelong)%></select>&nbsp;
<%else%>
					<input type=hidden name="JobBelong" value="<%=JobBelong%>">
					<u>&nbsp;<font color=green><%=GetShopName(JobBelong)%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�c�ƒS��
<%if myLevel > 2 then%>
					<select name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��<%=ShowEmployList(DepartSales, JobSalesman)%></select>&nbsp;
<%else%>
					<input type=hidden name="JobSalesman" value="<%=JobSalesman%>">
					<u>&nbsp;<font color=green><%=GetEmployName(JobSalesman, "F")%></font>&nbsp;</u>&nbsp;&nbsp;
<%end if%>
				<TD nowrap>�Ɩ��敪
					<select name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>&nbsp;
				<TD nowrap>�׎喼��
					<select name="SelName" onkeydown="ResetEnter()">
						<option value="jp" <%if SelName = "jp" then response.write "selected"%>>�a������
						<option value="en" <%if SelName = "en" then response.write "selected"%>>�p������
						<option value="ref" <%if SelName = "ref" then response.write "selected"%>>��������
						<option value="abr" <%if SelName = "abr" then response.write "selected"%>>�a������
					</select>&nbsp;
				<TD nowrap>�Ώ۔N��
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;��&nbsp;
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
<div id=list>
�Ώ۔N���F<%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup span=2 align=center>
		<colgroup align=left>
		<colgroup align=center>
		<colgroup span=5 align=right>
		<colgroup align=center>
		<TR style="cursor:hand;">
			<TD>��
			<TD onmousedown="DoSort(0)" <%if mySort=0 then%>style="color:blue"<%end if%>>�䒠�ԍ�
<%select case SelName%>
<%case "jp"%><TD onmousedown="DoSort(1)" <%if mySort=1 then%>style="color:blue"<%end if%>>�a������
<%case "en"%><TD onmousedown="DoSort(2)" <%if mySort=2 then%>style="color:blue"<%end if%>>�p������
<%case "ref"%><TD onmousedown="DoSort(3)" <%if mySort=3 then%>style="color:blue"<%end if%>>��������
<%case "abr"%><TD onmousedown="DoSort(4)" <%if mySort=4 then%>style="color:blue"<%end if%>>�a������
<%end select%>
			<TD onmousedown="DoSort(5)" <%if mySort=5 then%>style="color:blue"<%end if%>>������
			<TD onmousedown="DoSort(6)" <%if mySort=6 then%>style="color:blue"<%end if%>>���֋��z
			<TD onmousedown="DoSort(7)" <%if mySort=7 then%>style="color:blue"<%end if%>>�������z
			<TD onmousedown="DoSort(8)" <%if mySort=8 then%>style="color:blue"<%end if%>>�x�����z
			<TD onmousedown="DoSort(9)" <%if mySort=9 then%>style="color:blue"<%end if%>>�e��
			<TD onmousedown="DoSort(10)" <%if mySort=10 then%>style="color:blue"<%end if%>>�e����
			<TD onmousedown="DoSort(11)" <%if mySort=10 then%>style="color:blue"<%end if%>>�Ɩ�
		
<%
	cnt = 0
	with recset
		strSql = "SELECT J.*, ISNULL(CTM_REF, 'UNKNOWN') AS ref, ISNULL(CTM_NAME, '���o�^') AS jp, ISNULL(CTM_ENAME, 'UNKNOWN') AS en, ISNULL(CTM_ABR, '���o�^') AS abr "
		strSql = strSql & ", UserName FROM (SELECT JobCode, JobClient, SalesDate, Sales, Stand, Costs, JobOperator, (Sales - Costs) AS Interests"
		strSql = strSql & ", CASE Sales WHEN 0 THEN 0 ELSE ((Sales - Costs) * 100 / Sales) END AS Rate FROM TBL_CTM_JOB LEFT JOIN (SELECT JobCode AS JOB"
		strSql = strSql & ", ISNULL(SUM(CASE ExpenseType WHEN " & gsCharge & " THEN ExpenseAmount ELSE 0 END), 0) AS Sales"
		strSql = strSql & ", ISNULL(SUM(CASE ExpenseType WHEN " & gsStand & " THEN ExpenseAmount ELSE 0 END), 0) AS Stand"
		strSql = strSql & ", ISNULL(SUM(CASE ExpenseType WHEN " & gsPayment & " THEN ExpenseAmount ELSE 0 END), 0) AS Costs"
		strSql = strSql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 GROUP BY JobCode) AS E ON TBL_CTM_JOB.JobCode = E.JOB"
		strSql = strSql & " WHERE Deleted = 0 AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		if JobBelong <> "" then strSql = strSql & " AND JobBelong = '" & JobBelong & "'"
		if JobType <> "" then strSql = strSql & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if JobSalesman <> 0 then strSql = strSql & " AND JobSalesman = " & JobSalesman
		if JobBelong = "" then strSql = strSql & " AND SUBSTRING(JobCode,1,1) <> '" & gsSokoInit & "'"
		strSql = strSql & " ) AS J INNER JOIN (SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_ENAME, CTM_ABR FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
		strSql = strSql & " LEFT JOIN (SELECT UserID, UserName FROM _Employee) AS U ON J.JobOperator = U.UserID"
		select case mySort
		case 0:		strSql = strSql & " ORDER BY JobCode"
		case 1:		strSql = strSql & " ORDER BY jp"
		case 2:		strSql = strSql & " ORDER BY en"
		case 3:		strSql = strSql & " ORDER BY ref"
		case 4:		strSql = strSql & " ORDER BY abr"
		case 5:		strSql = strSql & " ORDER BY SalesDate"
		case 6:		strSql = strSql & " ORDER BY Stand DESC"
		case 7:		strSql = strSql & " ORDER BY Sales DESC"
		case 8:		strSql = strSql & " ORDER BY Costs DESC"
		case 9:		strSql = strSql & " ORDER BY Interests DESC"
		case 10:	strSql = strSql & " ORDER BY Rate DESC"
		case 11:	strSql = strSql & " ORDER BY JobOperator"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		sumSales = 0
		sumCosts = 0
		sumStand = 0
		do while not .EOF
			cnt = cnt + 1
			myName = ResetCorpName(.fields(SelName))
			JobCode = GetString(.Fields("JobCode"))
			myColor = ""
			if GetLong(.Fields("Interests")) < 0 then
				myColor = "style=""color:red"""
			else
				select case CheckJobType(JobCode) 
				case gsExport:	myColor = "style=""color:black""" 
				case gsImport:	myColor = "style=""color:black""" 
				case gsOther:	myColor = "style=""color:maroon""" 
				end select
			end if
%>
		<TR <%=myColor%>>
			<TD nowrap><%=cnt%>
			<TD nowrap><%=JobCode%>
			<TD><%=myName%>
			<TD nowrap><%=Str2YMD(.Fields("SalesDate"))%>
			<TD nowrap><%=formatnumber(GetLong(.Fields("Stand")), 0, true)%>
			<TD nowrap><%=formatnumber(GetLong(.Fields("Sales")), 0, true)%>
			<TD nowrap><%=formatnumber(GetLong(.Fields("Costs")), 0, true)%>
			<TD nowrap><%=formatnumber(GetLong(.Fields("Interests")), 0, true)%>
			<TD nowrap><%=formatnumber(GetDouble(.Fields("Rate")), 2, true)%>%
			<TD nowrap><%=ShowUserName(.Fields("UserName"))%>
<%
			sumStand = sumStand + GetLong(.Fields("Stand"))
			sumSales = sumSales + GetLong(.Fields("Sales"))
			sumCosts = sumCosts + GetLong(.Fields("Costs"))
			.movenext
		loop
		.Close
	end with
	if cnt > 0 then
		sumRate = 0
		sumInterest = sumSales - sumCosts
		if sumSales <> 0 then sumRate = sumInterest * 100 / sumSales
		
%>
		<TR>
			<TD colspan=4 align=center>���@�v
			<TD nowrap><%=formatnumber(sumStand, 0, true)%>
			<TD nowrap><%=formatnumber(sumSales, 0, true)%>
			<TD nowrap><%=formatnumber(sumCosts, 0, true)%>
			<TD nowrap><%=formatnumber(sumInterest, 0, true)%>
			<TD nowrap><%=formatnumber(sumRate, 2, true)%>%
			<TD nowrap><br>
<%end if%>
	</TABLE>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowUserName(myName)
dim buf, pos
	buf = GetString(myName)
	pos = instr(buf, " ")
	if pos = 0 then pos = instr(buf, "�@")
	if pos <> 0 then
		buf = left(buf, pos - 1)
	end if
	ShowUserName = GetString(buf)
end function 
%>
