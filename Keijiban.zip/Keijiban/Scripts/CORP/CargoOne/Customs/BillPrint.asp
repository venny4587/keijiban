<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim PageSize
dim ChargeNo
	
	PageSize = 16
	ChargeNo = GetPost(request("ChargeNo"))
	if ChargeNo <> "" then
		OpenSql Conn, SqlServerName, DataBaseName
		strSql = "UPDATE TBL_CTM_CHARGE SET ChargePrinted = 1 WHERE Deleted = 0 AND ChargeNo = '" & FitSel(ChargeNo) & "'"
		Conn.Execute strSql
		
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
		
			strSql = "SELECT JobCode, ChargeClient, ChargeClientName, ChargePic, ChargeDate, ChargeType, ChargeMemo"
			strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeNo = '" & FitSel(ChargeNo) & "'"
'response.write strSql
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then 
				 JobCode = GetString(.fields("JobCode"))
				 ChargePic = GetString(.fields("ChargePic"))
				 ChargeClient = GetString(.fields("ChargeClient"))
				 ChargeClientName = GetString(.fields("ChargeClientName"))
				 ChargeDate = Str2Date(.fields("ChargeDate"))
				 ChargeType = GetLong(.fields("ChargeType"))
				 ChargeMemo = GetMark(.fields("ChargeMemo"))
			end if
			.close
		
			strSql = "SELECT JobClient, Vessel, Voy, Quantity, Package, MBL, HBL, ETD, ETA, POL, POD, GW, CBM, Commodity, ReferNo" 
			strSql = strSql & ", JobShipper, JobManager, InvoiceNo, PermitNo, PermitDate, CarryPlace, JobSalesman, JobOperator, Marks"
			strSql = strSql & " FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then 
				JobShipper = GetString(.fields("JobShipper"))
				JobClient = GetString(.fields("JobClient"))
				JobManager = GetString(.fields("JobManager"))
				Vessel = GetString(.fields("Vessel"))
				Voy = GetString(.fields("Voy"))
				ETD = Str2Date(.fields("ETD"))
				ETA = Str2Date(.fields("ETA"))
				POL = GetString(.fields("POL"))
				POD = GetString(.fields("POD"))
				MBL = GetString(.fields("MBL"))
				HBL = GetString(.fields("HBL"))
				GW = GetDouble(.fields("GW"))
				CBM = GetDouble(.fields("CBM"))
				Quantity = GetDouble(.fields("Quantity"))
				Package = GetString(.fields("Package"))
				Commodity = GetString(.fields("Commodity"))
				InvoiceNo = GetString(.fields("InvoiceNo"))
				ReferNo = GetString(.fields("ReferNo"))
				PermitNo = GetString(.fields("PermitNo"))
				PermitDate = Str2Date(.fields("PermitDate"))
				CarryPlace = GetString(.fields("CarryPlace"))
				JobSalesman = GetLong(.fields("JobSalesman"))
				JobOperator = GetLong(.fields("JobOperator"))
				Marks = GetMark(.fields("Marks"))
				CTM_SALESMNGR = GetString(.fields("JobSalesman"))
			end if
			.close
			
			'NACCS
			pos = instrrev(CarryPlace, "(") 
			if pos = 0 then
				CarryPlace = ""
			else
				CarryPlace = mid(CarryPlace, pos)
				pos = instr(CarryPlace, ")") 
				if pos > 0 then CarryPlace = left(CarryPlace, pos)
			end if
			
			strSql = "SELECT CTM_NAME, CTM_REF, CTM_FAX, CTM_ZIP, CTM_ADDR1, CTM_ADDR2 FROM CUSTOMER WHERE CTM_CD = '" & ChargeClient & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then 
				 CTM_NAME = GetString(.fields("CTM_NAME"))
				 CTM_REF = GetString(.fields("CTM_REF"))
				 CTM_ZIP = GetString(.fields("CTM_ZIP"))
				 CTM_ADDR1 = GetString(.fields("CTM_ADDR1"))
				 CTM_ADDR2 = GetString(.fields("CTM_ADDR2"))
				 CTM_FAX = GetString(.fields("CTM_FAX"))
			end if
			.close
		end with
		
		myDivision = CheckJobType(JobCode)
		select case myDivision
		case gsExport
			myTitle = "�A �o"
			myShipper = "(EXPORTER)"
		case gsImport
			myTitle = "�A ��"
			myShipper = "(IMPORTER)"
		case gsOther
			myTitle = ""
		end select
		
		if ChargeType = 2 then myTitle = myTitle & " �� ��"
%>
<HTML>
<HEAD>
	<TITLE>���������</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.gline { BORDER-bottom: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r ����; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r ����; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: �l�r ����; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; }
		.pth { FONT-FAMILY: HG�ۺ޼��M-PRO; FONT-SIZE: 14pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT language=vbscript>		
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			'if window.event.keyCode=80 then window.Print()
			if window.event.keyCode=80 then window.location.href = "BillPrint.asp?print=1&ChargeNo=<%=ChargeNo%>"
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=ptm <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
  <table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
  <tr><td height=860 valign=top align=center>
	<table Border=0 Cellspacing=0 CellPadding=0>
	  <tr><td width=150 class=pts>(<%=ChargeClient%>)
	 	<td width=320 class=pth align=center><u>&nbsp;&nbsp;<%=myTitle%> �� �� ��&nbsp;&nbsp;</u>
	  	<td width=150 class=ptm align=right><%=formatDateJP(ChargeDate)%>
	</table>
	<br>
	<table width=660 cellspacing=5 cellpadding=5>
	  <tr height=40>
		<td width=360 valign=top>
			<table width=100% Cellspacing=0 CellPadding=0 class=pts>
		  	  <tr height=20><td class=ptl><%=CTM_NAME%> �䒆<br>
		  	  <tr height=20><td><hr size=1 color=black>
<%if ChargeType = 2 AND CTM_FAX <> "" then%>
		  	  <tr height=20><td class=ptm>FAX: <%=CTM_FAX%>
<%end if%>
 			</table>
		<td width=300 valign=top align=right rowspan=2>
		  <table Cellspacing=0 CellPadding=0 class=ptm>
			<tr align=right>
				<td width=130><img src=img/logo.jpg>
				<td nowrap><font class=pth><b><%=gsPrintHead%></b></font>
		  	<tr align=right>
		  		<td colspan=2 class=ptt nowrap align=right><%=gsPrintAddr%>
<%if left(JobCode, 1) = gsSokoInit then%>
					<br>�ېőq��  �q�ɏZ�� TEL: (01)1111-1111
<%end if%>
 		  </table>
 		  
		<TR height=40><td valign=bottom>
<%if JobShipper <> JobClient then %>
			<table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
		  	  <tr height=20><td><%=myShipper%><br><%=GetCtmName(JobShipper)%>
 			</table>
<%end if%>
<%if ReferNo <> "" then%>
			<br><font class=pts>�_�� <%=ReferNo%></font>
<%end if%>
<%if myDivision <> gsOther then%>
	  <TR><td colspan=2><hr color=black size=1>
	</table>
	<table width=660 Border=0 cellspacing=3 cellpadding=3 class=ptm>
	  <colgroup align=center>
	  <colgroup align=left>
	  <colgroup align=center>
	  <colgroup align=left>
	  <colgroup align=center>
	  <colgroup align=left>
	  <TR height=20 valign=bottom>
		<TD nowrap>�D�֖�<TD class=gline> <%=Vessel%><%if Voy <> "" then response.write " V." & Voy%><br>
<%if myDivision = gsExport then%>
		<TD nowrap>�o�`��<TD class=gline nowrap> <%=ETD%><br>
<%else%>
		<TD nowrap>���`��<TD class=gline nowrap> <%=ETA%><br>
<%end if%>
<%if POL = "NULL" and POD = "NULL" then%>
		<TD nowrap>�q�@�H<TD class=gline nowrap><br>
<%else%>
		<TD nowrap>�q�@�H<TD class=gline nowrap> <%=POL%> �� <%=POD%><br>
<%end if%>
	  <TR height=20 valign=bottom>
		<TD nowrap>�i�@��<TD class=gline> <%=Commodity%><br>
		<TD nowrap>�d�@��<TD class=gline nowrap> <%if GW <> 0 then%><%=formatnumber(GW,0)%> KGS<%end if%><br>
		<TD nowrap>�@��<TD class=gline nowrap> <%=Quantity & " " & Package%><br>
	  <TR height=20 valign=bottom>
		<TD nowrap>B/L ��<TD class=gline> <%=HBL%><%if HBL="" then response.write MBL%><br>
		<TD nowrap>�e�@��<TD class=gline nowrap> <%if CBM <> 0 then%><%=CBM%> M<sup>3<%end if%><br>
		<TD nowrap>INV ��<TD class=gline> <%=InvoiceNo%><br><TD>
<%end if%>
	</table>
	<TABLE width=650 Cellspacing=2 CellPadding=2 class=ptm>
		<colgroup align=center>
		<colgroup span=3 align=left>
		<colgroup span=2 align=right>
		<colgroup align=left>
		<colgroup span=2 align=right>
  	  <TR><td colspan=10><hr color=black size=1>
	  <TR align=right height=20>
		<TD nowrap class=gline colspan=2>��
		<TD nowrap class=gline width=130>��������
		<TD nowrap class=gline width=150>���ڔ��l
		<TD nowrap class=gline width=70>�����P��
		<TD nowrap class=gline width=40>����
		<TD nowrap class=gline width=50>�P��
		<TD nowrap class=gline width=50>�����
		<TD nowrap class=gline width=80>�Ŕ����z
<%if left(ChargeClient, 3) = "690" and myDivision = gsImport then%>
		<TD nowrap class=gline>��
<%end if%>
<%
		cnt = 0
		ttlTax = 0
		ttlAmount = 0
		ttlTaxFree = 0
		sumKensyu = 0
		with recset
			strSql = "SELECT SeqNo, ExpenseType, ExpenseAttr, ExpenseDate, ExpensePrice, ExpenseQuantity, ExpenseUnit, ExpenseAmount, ExpenseTax"
			strSql = strSql & ",ExpenseMemo, COST_ID,COST_CD,COST_NAME FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
			strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
			strSql = strSql & " ORDER BY ExpenseType Desc, COST_CD, SeqNo"
			recset.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not .eof
				cnt = cnt + 1
				if cnt = PageSize + 1 then
%>
	  <TR><td colspan=9 height=140 align=left>��������܂�...
  	  <TR><td colspan=9><hr color=black size=1>
	  <TR align=right height=20>
		<TD nowrap class=gline colspan=2>��
		<TD nowrap class=gline width=110>��������
		<TD nowrap class=gline width=150>���ڔ��l
		<TD nowrap class=gline width=70>�����P��
		<TD nowrap class=gline width=40>����
		<TD nowrap class=gline width=60>�P��
		<TD nowrap class=gline width=60>�����
		<TD nowrap class=gline width=80>�Ŕ����z
<%if left(ChargeClient, 3) = "690" and myDivision = gsImport then%>
		<TD nowrap class=gline>��
<%end if%>
<%
				end if
				if GetLong(.Fields("ExpenseAttr")) <> 0 then
					sumKensyu = sumKensyu + GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax"))
				end if
				if GetLong(.Fields("ExpenseTax")) = 0 then 
					myMark = ""
				else
					myMark = "*"
				end if
%>
	  <TR align=right height=30 valign=top>
<%if GetLong(.Fields("COST_ID")) <> 123 then %>
		<TD><%=cnt%><BR>
		<TD><%=myMark%><BR>
<%	select case GetLong(.Fields("COST_ID"))
  	case 113 %>
		<TD colspan=2><%=GetString(.Fields("ExpenseMemo"))%><BR>
<%	case 36 %>
	<%if CheckKeepExist(.Fields("SeqNo")) <> 0 then%>
		<TD colspan=2 nowrap><%=replace(GetString(.Fields("ExpenseMemo")), "����", "�ۊǗ�")%><BR>
	<%else%>
		<TD><%=GetString(.Fields("COST_NAME"))%><BR>
		<TD><%=GetString(.Fields("ExpenseMemo"))%><BR>
	<%end if%>
<%	case else %>
		<TD><%=GetString(.Fields("COST_NAME"))%><BR>
		<TD><%=GetString(.Fields("ExpenseMemo"))%><BR>
<%	end select %>
<%	if GetString(.Fields("ExpenseUnit")) = "M/M" then %>
		<TD colspan=2>
<%	else %>
		<TD nowrap><%if GetDouble(.Fields("ExpensePrice")) <> 0 then%>\<%=FitZero(formatnumber(GetDouble(.Fields("ExpensePrice")), 2, false))%><%end if%>
		<TD nowrap><%if GetDouble(.Fields("ExpenseQuantity")) <> 0 then%><%=GetDouble(.Fields("ExpenseQuantity"))%><%end if%>
<%	end if %>
		<TD><%=GetString(.Fields("ExpenseUnit"))%><BR>
		<TD nowrap><%if GetLong(.Fields("ExpenseTax")) <> 0 then%>\<%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, true)%><%end if%>
		<TD nowrap>\<%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%><BR>
<%else%>
		<TD><%=cnt%><TD><TD colspan=5><%=GetString(.Fields("ExpenseMemo"))%><BR>
		<TD nowrap><%if GetLong(.Fields("ExpenseTax")) <> 0 then%>\<%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, true)%><%end if%>
		<TD nowrap><%if GetLong(.Fields("ExpenseAmount")) <> 0 then%>\<%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%><%end if%>
<%end if
if left(ChargeClient, 3) = "690" and myDivision = gsImport then%>
		<TD nowrap><%if GetLong(.Fields("ExpenseAttr")) <> 0 then%>��<%end if%>
<%end if%>
<%
				if GetLong(.Fields("ExpenseTax")) = 0 then 
					ttlTaxFree = ttlTaxFree + GetLong(.Fields("ExpenseAmount")) 
				else
					ttlTax = ttlTax + GetLong(.Fields("ExpenseTax"))
					ttlAmount = ttlAmount + GetLong(.Fields("ExpenseAmount"))
				end if
				.movenext
			loop
			.Close
		end with
%>
<%		if cnt < 10 then%>
		  <TR align=right height=20>
			<TD colspan=6><TD colspan=3 class=gline><br>
<%		end if%>

<%if ChargeClient = "8014" then%>
		  <TR align=right>
			<TD colspan=6><TD colspan=2 align=right>��ېŊz<TD>\<%=formatnumber(ttlTaxFree, 0, true)%>
		  <TR align=right>
			<TD colspan=6><TD colspan=2 align=right>�ېŋ��z<TD>\<%=formatnumber(ttlAmount, 0, true)%>
		  <TR align=right>
			<TD colspan=6><TD colspan=2 align=right>����Ŋz<TD>\<%=formatnumber(ttlTax, 0, true)%>
		  <TR align=right height=20>
			<TD colspan=6><TD colspan=2 align=right>���v���z<TD>\<%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%end if%>
<%if left(ChargeClient, 3) = "690" and myDivision = gsImport then%>
		  <TR align=right height=20>
			<TD colspan=6><TD colspan=2 align=right>�����v<TD>\<%=formatnumber(sumKensyu, 0, true)%>
<%end if%>
	</TABLE>
	<br>
	<TABLE width=640 class=pts>
<%if Marks <> "" and Marks <> "N/M" then%>
		<tr><td width=300 valign=top>
				<table width=320><tr><td class=pts>
				�@�@MARKS &amp; NUMBERS<br>-----------------------<br>
					<%=Marks%></table>
			<td width=340 valign=top>
				<table width=320><tr><td class=pts><%if ChargeMemo <> "" then%>
				�@�@��������<br>-----------------------<br>
				�@�@<%=ChargeMemo%><%end if%></table>
<%elseif ChargeMemo <> "" then%>
		<tr><td class=pts><%=ChargeMemo%>
<%end if%>
	</TABLE>
<%if Marks <> "" and cnt > 13 and cnt <= PageSize then%>
  <tr><td height=120 valign=top><br>��������܂�...
<%end if%>
  <tr><td>
	<TABLE width=650 border=0 Cellspacing=0 CellPadding=0 class=pts>
	  <TR height=10><td colspan=3><hr color=black size=1>
	  <TR class=pts valign=top>
		<td width=200>
		  <table class=pts>
			<tr><td width=60 nowrap>�����ԍ�<td nowrap><%=ChargeNo%>
			<tr><td>�䒠�ԍ�<td nowrap><%=JobCode%>
			<tr><td>�Ə�ԍ�<td><%if PermitDate<>"" then response.write formatShortDate(PermitDate) & " "%><%=PermitNo%>
			<tr><td>�S �� ��<td nowrap><%=GetEmployName(CTM_SALESMNGR, "U")%>
			<tr><td colspan=2><%=CarryPlace%>
		  </table>
		<td width=300>
		  <table class=pts>
			<tr><td nowrap>�U����s
			<tr><td>�@�@<b>�f����s�@�f���x�X�@������ 88888888</b>
		  </table>
		<td width=145 class=bline>
		  <table width=145 border=0 class=pts Cellspacing=2 CellPadding=2>
			<tr><td nowrap>��ېŊz<td align=right>\<%=formatnumber(ttlTaxFree, 0, true)%>
			<tr><td nowrap>�ېŋ��z<td align=right>\<%=formatnumber(ttlAmount, 0, true)%>
			<tr><td nowrap>����Ŋz<td align=right>\<%=formatnumber(ttlTax, 0, true)%>
			<tr><td class=ptm align=center><b>�� �v</b>
				<td align=right class=ptl nowrap><b>\<%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%></b>
		  </table>
		<TD width=5><br>
	</TABLE>
  </table>
</center>
<%if GetLong(request("print")) = 1 then%>
	<script languange=vbscript>
		window.print()
	</script>
<%end if%>
</BODY>
</HTML>
<% 
		set recset = nothing
		CloseDB Conn
	end if
%>

<%
function CheckKeepExist(myNo)
dim mySql
dim myRec
	CheckKeepExist = 0
	mySql = "SELECT SeqNo FROM TBL_CTM_KEEP WHERE Deleted = 0 "
	mySql = mySql & " AND JobCode = '" & JobCode & "' AND ExpenseNo = " & myNo
	set myRec = Server.CreateObject("adodb.recordset") 
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if not myRec.eof then CheckKeepExist = 1
	myRec.Close
	set myRec = nothing
end function

function GetMark(myMark)
dim idx, buf
	buf = split(GetString(myMark), vbCrlf)
	if ubound(buf) < 6 then
		GetMark = replace(myMark, vbCrlf, "<br>")
	else
		GetMark = buf(0)
		for idx = 1 to 5
			GetMark = GetMark & "<br>" & buf(idx)
		next
	end if
end function
%>