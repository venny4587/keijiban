<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CostsType = GetLong(request("type"))
	CostsSort = GetLong(request("sort"))
	if CostsType = 1 then
		BatchNo = session("CTM_CostsBatch")
	else
		CostsDate = GetDate(request("CostsDate"))
		if CostsDate = "" then CostsDate = formatDate(date)
	end if
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�x���`�[�ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>
		function ShowDetail(myJob, myNo)
		dim win
			set win = window.open("MainFrame.asp?mode=2&JobCode=" & myJob & "&CostsNo=" & myNo,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
<%if CostsType = 1 then%>
		function DoSort(myNo)
			window.location.href = "CostsResult.asp?type=1&sort=" & myNo
		end function
		
		function ShowHead(myJob, myNo)
			window.parent.input.cbody.dtl.location.href = "CloseHead.asp?JobCode=" & myJob & "&CostsNo=" & myNo
		end function

		function DoModify()
		dim win
			set win = window.open("CostsBatchModify.asp","CostsBatchModify","resizable=1,scrollbars=1,width=600,height=600")
			win.focus()
		end function

		function DoPrint()
			set win = window.open("CostsCheck.asp?BatchNo=<%=BatchNo%>","CostsCheck","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
<%else%>
		sub CostsDate_OnBlur()
			CostsDate.value = setdate(CostsDate.value)
		end sub
	
		function DoSelect()
			window.location.href = "CostsResult.asp?type=<%=CostsType%>&CostsDate=" & cstr(CostsDate.value)
		end function
		
		function DoSort(myNo)
			window.location.href = "CostsResult.asp?type=<%=CostsType%>&sort=" & myNo & "&CostsDate=" & cstr(CostsDate.value)
		end function
		
	<%if CostsType = 0 then%>	
'		function ShowDetail(myJob, myNo)
'			window.parent.input.cbody.location.href = "CostsList.asp?JobCode=" & myJob & "&CostsNo=" & myNo
'		end function
	<%end if%>
<%end if%>
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
<%select case CostsType
case 0%>
	  <TR><td nowrap width=40%>�������`�[�ꗗ&nbsp;
	  	  <td nowrap width=60%>�퐿����
			<input class=si name="CostsDate" size=10 maxlength=10 value="<%=CostsDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<img style="cursor:hand" src=img/search.jpg alt="���t�I��" onmousedown="DoSelect()">
<%case 1%>
	  <TR><td nowrap width=40%>�������`�[�ꗗ&nbsp;
	  	  <td nowrap width=30%>�ޯ���&nbsp;<input class=si value="<%=BatchNo%>" size=6 readonly>
	  	  <td nowrap width=30%>�@
	 		<%if CheckBatchModify(BatchNo) then%>
	  	  		<img style="cursor:hand" src=img/open.gif alt="�������ҏW" onmousedown="DoModify()">�@
	  	  �@<%end if%>
	 		<%if CheckBatchClient(BatchNo) then%>
	  	 		<img style="cursor:hand" src=img/cover.jpg alt="���׈ꗗ���" onmousedown="DoPrint()">
	  	  �@<%end if%>
<%case 2%>
	  <TR><td nowrap width=40%>���x���ψꗗ&nbsp;
	  	  <td nowrap width=60%>�x����
			<input class=si name="CostsDate" size=10 maxlength=10 value="<%=CostsDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<img style="cursor:hand" src=img/search.jpg alt="���t�I��" onmousedown="DoSelect()">
<%end select%>
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT JobCode, CostsType, ClientRef, CostsClientName, CostsPic, CostsCheck, JobBelong, ConfirmerID, CostsBillNo"
		strSql = strSql & ", CostsNo, CostsDate, CostsAmount, CostsTax, CostsPayDay, FinisherID FROM TBL_CTM_COSTS AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " INNER JOIN (SELECT JobCode AS CD, CASE WHEN CustomBroker='" & gsCorpCode & "' THEN '" & gsCorpInit
		strSql = strSql & "' ELSE JobBelong END AS JobBelong FROM TBL_CTM_JOB) AS J ON T.JobCode = J.CD WHERE Deleted = 0"
		if CostsType <> 1 and CheckTopLevel() = 0 then strSql = strSql & " AND JobBelong = '" & UserShop & "'"
		select case CostsType
		case 0:		strSql = strSql & " AND CostsType = 0 AND CostsDate = '" & Date2Str(CostsDate) & "'"
		case 1:		strSql = strSql & " AND CostsBatch = '" & BatchNo & "'"
		case 2:		strSql = strSql & " AND CONVERT(VARCHAR(10), FinishDate, 111) = '" & CostsDate & "'"
		end select
		select case CostsSort
		case 0:		strSql = strSql & " ORDER BY CostsNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, CostsNo"
		case 2:		strSql = strSql & " ORDER BY CostsDate, CostsNo"
		case 3:		strSql = strSql & " ORDER BY (CostsAmount+CostsTax), CostsNo"
		case 4:		strSql = strSql & " ORDER BY CostsBillNo"
		end select
if WebUserID = gsAdmin then response.write strSql
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		<colgroup span=2 align=center>
<%if CostsType = 1 then%>
		<colgroup align=right>
<%end if%>
		<colgroup align=left>
		<colgroup align=center>
		<colgroup align=right>
		<colgroup align=left>
		<colgroup span=2 align=center>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>��
<%if CostsType = 1 then%>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">���臂
<%end if%>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">������
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x�����z
		<TD class=line nowrap>�x����
		<TD class=line nowrap>����
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�`�[�ԍ�
		<TD class=line nowrap>�m��
<%if CostsType = 1 then%>
		<TD class=line nowrap>�Ŕ����z
<%end if%>
<%
			cnt = 0:	SeqNo = 0
			ttlAmount = 0:	ttlTax = 0:	ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				JobCode = GetString(.Fields("JobCode"))
				CostsNo = GetString(.Fields("CostsNo"))
				CostsBillNo = GetString(.Fields("CostsBillNo"))
				
				ClientRef = GetString(.Fields("ClientRef"))
				ClientName = GetString(.Fields("CostsClientName"))
				if GetLong(.Fields("CostsCheck")) <> 0 then
					check = "<font color=black>��</font>"
				else
					check = "<font color=red>��</font>"
				end if
				if GetLong(.Fields("ConfirmerID")) <> 0 then
					status = "<font color=black>��</font>"
				else
					status = "<font color=gray>��</font>"
				end if
%>
				<TR height=20>
					<TD class=line><IMG SRC=img/search.jpg STYLE="cursor:hand" onclick="ShowDetail('<%=JobCode%>','<%=CostsNo%>')"><%=cnt%>
					<TD class=line><%=replace(ShowCostsType(.Fields("CostsType")),"��","")%><BR>
<%if CostsType = 1 then%>
					<TD class=line nowrap><%=CostsBillNo%><BR>
<%end if%>
					<TD class=line nowrap><%=ShowJobCode(JobCode)%><BR>
					<TD class=line style="color:#228b22"><%=Str2MD(.Fields("CostsDate"))%><BR>
					<TD class=line nowrap><%=formatnumber(GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax")), 0, true)%><BR>
					<TD class=line nowrap style="cursor:help" title="<%=ClientName%>"><%=StringCut(ClientRef,8)%><BR>
					<TD class=line><%=check%><BR>
					<TD class=line><%=ShowVoucherNo(CostsNo)%><BR>
					<TD class=line><%=status%><BR>
<%if CostsType = 1 then%>
					<TD class=line nowrap align=right><%=formatnumber(GetLong(.Fields("CostsAmount")), 0, true)%><BR>
<%end if%>
<%
				if GetLong(.Fields("CostsTax")) = 0 then 
					ttlTaxFree = ttlTaxFree + GetLong(.Fields("CostsAmount")) 
				else
					ttlTax = ttlTax + GetLong(.Fields("CostsTax"))
					ttlAmount = ttlAmount + GetLong(.Fields("CostsAmount"))
				end if
				.movenext
			loop
			if cnt > 1 then
				myCol = 3
				if CostsType = 1 then myCol = myCol + 1
%>
<%if ttlTax <> 0 then%>
				<TR height=20>
					<TD colspan=<%=myCol%> align=right class=pt9>�Ŕ����z
					<TD class=line align=right colspan=2><%=formatnumber(ttlAmount + ttlTaxFree, 0, true)%>
				<TR height=20>
					<TD colspan=<%=myCol%> align=right class=pt9>�� �� ��
					<TD class=line align=right colspan=2><%=formatnumber(ttlTax, 0, true)%>
<%end if%>
				<TR height=20>
					<TD colspan=<%=myCol%> align=right class=pt9>���v���z
					<TD class=line align=right colspan=2><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y���x���`�[�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>


<%
function CheckBatchClient(myNo)
dim buf
	buf = ""
	strSql = "SELECT BatchClient FROM TBL_CTM_BATCH WHERE BatchNo = '" & myNo & "'" 
	recset.Open strSql,conn,adOpenStatic,adLockReadOnly
	if not recset.eof then buf = GetString(recset.Fields("BatchClient"))
	recset.Close

	select case buf
	case "G9", "G40", "G41", "1453A"			'���q��E�v�c�^���E���S�^�A�E�ېŗ��^
		CheckBatchClient = 1
	case else
		CheckBatchClient = 0
	end select
end function

function CheckBatchModify(myNo)
dim buf
	strSql = "SELECT BatchNo FROM TBL_CTM_BATCH WHERE Deleted = 0 AND FinisherID = 0 AND BatchNo = '" & myNo & "'"
	if UserShop <> gsInitShop then strSql = strSql & " AND BatchBelong = '" & UserShop & "'"
	recset.Open strSql,conn,adOpenStatic,adLockReadOnly
	if not recset.eof then CheckBatchModify = 1
	recset.Close
end function
%>