<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next
dim JobCode
dim JobClient
		
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 0)
	
	SeqNo = GetLong(request("seq"))
	if JobCode <> "" and SeqNo <> 0 then		
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
			strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				mode = 1
				ExpenseClient = GetString(.fields("ExpenseClient"))
				ExpenseCost = GetLong(.fields("ExpenseCost"))
				ExpenseType = GetLong(.fields("ExpenseType"))
				ExpenseAttr = GetLong(.fields("ExpenseAttr"))
				ExpenseDate = Str2Date(.fields("ExpenseDate"))
				ExpenseMemo = GetString(.fields("ExpenseMemo"))
				
				ExpenseQuantity = GetDouble(.fields("ExpenseQuantity"))
				ExpenseUnit = GetString(.fields("ExpenseUnit"))
				ExpensePrice = GetDouble(.fields("ExpensePrice"))
				ExpenseAmount = GetLong(.fields("ExpenseAmount"))
				ExpenseTaxName = GetString(.fields("ExpenseTaxName"))
				ExpenseTax = GetLong(.fields("ExpenseTax"))
				Remarks = GetString(.fields("Remarks"))
				
				ConfirmerID = GetLong(.fields("ConfirmerID"))
				ConfirmDate = GetDate(.fields("ConfirmDate"))
				ExpenseBill = GetString(.fields("ExpenseBill"))
				ExpensePay = GetString(.fields("ExpensePay"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
			
			strSql = "SELECT CostsNo, CostsClient, CostsClientName, FinisherID FROM TBL_CTM_COSTS WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & ExpensePay & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then 
				CostsNo = GetString(.Fields("CostsNo"))
				CostsClient = GetString(.Fields("CostsClient"))
				CostsClientName = GetString(.Fields("CostsClientName"))
				FinisherID = GetLong(.fields("FinisherID"))
			end if
			.close
		end with
		
		myCheck = CheckBillLocked(Conn, JobCode, ExpenseBill)
		
		myLevel = 0
		if CheckTopLevel() > 0 or WebUserID = ConfirmerID or CheckUserLevel(UserShop, "") > 2 then myLevel = 1
%>
<html>
<HEAD>
	<TITLE>�x���ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
		end sub
		
		sub DoDivide()
			window.location.href = "PaymentDivide.asp?JobCode=<%=JobCode%>&seq=<%=SeqNo%>"
		end sub
		
		sub DoSave()
<%if myLevel <> 0 then%>
		dim buf
			buf = frmInput.ExpenseCost.options(frmInput.ExpenseCost.selectedIndex).value
			if checkText("ShipperName","������",1) = false then exit sub
			if buf = "123" or buf = "113" then
				if checkText("ExpenseMemo","���ڔ��l",1) = false then exit sub
			else
				if checkText("ExpenseMemo","���ڔ��l",0) = false then exit sub
			end if
<%end if%>
			if msgbox ("�ύX���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then frmInput.submit()
		end sub
	</script>
</Head>
<body bgcolor="<%=gsCostsBackColor%>" onkeydown="DoShortCut()"  topmargin=10 class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="PaymentUpdate.asp" method="post">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=18>
	  	<td width=50%>���x���ڍ׏��
	  	<td width=50%><%if myLevel <> 0 and ExpenseType = gsStand and ExpenseAttr <> 2 then%>
	  		<a class=bar href="javascript:DoDivide()">�y���ڕ����z</a><%end if%>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=28>
		<TD align=center class=pt9g>�x����
		<TD colspan=5>(<%=GetRefName(CostsClient)%>)
			<input class=si name="ClientName" size=45 value="<%=CostsClientName%>" onkeydown="ResetEnter()" readonly>
		<TD align=center>�x���敪
		<TD class=gline align=center><%=ShowExpenseType(ExpenseType)%><br>
	  <TR height=28>
		<TD align=center>�x������
<%if myLevel = 0 then%>
		<TD class=gline colspan=3><%=GetExpenseName(ExpenseCost)%><br><input type=hidden name="ExpenseCost" value="<%=ExpenseCost%>">
<%else%>
		<TD colspan=3><select name="ExpenseCost" onkeydown="ResetEnter()"><%=ShowExpenseList(ExpenseCost)%></select>
<%end if%>
		<TD align=center class=pt9g>�퐿����<TD class=gline align=center><%=ExpenseDate%><br>
		<TD align=center class=pt9g>�x���ԍ�<TD class=gline align=center><%=CostsNo%><br>
	  <TR height=28>
		<TD align=center class=pt9>���ڔ��l
		<TD colspan=5><input class=sj name="ExpenseMemo" size=50 maxlength=250 value="<%=ExpenseMemo%>" onkeydown="ResetEnter()" 
			<%if myLevel = 0 then response.write "readonly"%>>
<%if ExpenseType = gsStand then%>
		<TD align=center>��������
		<TD class=gline align=center>
		<%if myCheck then%>
			<%=ShowExpenseAttr(ExpenseAttr)%><br>
		<%else%>
			<select name=ExpenseAttr>
			<option value=0 <%if ExpenseAttr = 0 then response.write " selected"%>>����
			<option value=1 <%if ExpenseAttr = 1 then response.write " selected"%>>����</select>
	<%end if%>
<%else%>
		<TD align=center>���ڋ敪
		<TD class=gline align=center><%=ShowExpenseAttrFull(ExpenseAttr)%><br>
<%end if%>
	  <TR height=28>
		<TD align=center width=60 nowrap>�x���P��
		<TD><input class=sn name="ExpensePrice" size=10 maxlength=8 value="<%=FitZero(formatnumber(ExpensePrice, 2, true))%>" onkeydown="ResetEnter()" readonly>
		<TD align=center width=60 nowrap>�x������
		<TD><input class=sn name="ExpenseQuantity" size=8 maxlength=8 value="<%=ExpenseQuantity%>" onkeydown="ResetEnter()" readonly>
		<TD align=center width=60 nowrap>�x���P��
		<TD class=gline align=center><%=ExpenseUnit%><br>
		<TD align=center width=60 nowrap>�Ŕ����z
		<TD><input class=sn name="ExpenseAmount" size=12 maxlength=8 value="<%=formatnumber(ExpenseAmount, 0, true)%>" onkeydown="ResetEnter()" readonly>
	  <TR height=28>
		<TD align=center>�ېŋ敪
		<TD class=gline align=center><%=ExpenseTaxName%><br>
		<TD align=center class=pt9>�����
		<TD><input class=sn name="ExpenseTax" size=8 maxlength=8 value="<%=formatnumber(ExpenseTax, 0, true)%>" onkeydown="ResetEnter()" readonly>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=GetEmployName(ConfirmerID, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=formatDate(ConfirmDate)%><br>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=28>
		<TD class=pt9 align=center>����
		<TD colspan=5><textarea name="Remarks" rows=4 style="width:350" <%if myLevel = 0 then response.write "readonly"%>><%=Remarks%></textarea>
		<TD colspan=2 align=center>
<%if ExpenseType = gsStand then%>
		<%if myCheck then%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
		<%else%>
			������������<br>
			<input class=si name="ExpenseBill" size=10 maxlength=10 value="<%=ExpenseBill%>"><br>
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DoSave()">
		<%end if%>
<%elseif myLevel > 0 and ExpenseAttr <> 2 then%>
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DoSave()">
<%else%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
<%end if%>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	</TABLE>
  </FORM>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=24 align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=12% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=15% class=pt9g>�ŏI�X�V��<TD width=12% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
'�ďo��F PaymentDetail.asp �x�����׏��Ɖ�
function GetExpenseName(myDft)
	GetExpenseName = ""	
	with Recset			
		strSql = "SELECT COST_NAME FROM MST_COST WHERE COST_ID = " & myDft
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then GetExpenseName = GetString(.Fields("COST_NAME"))
		.close
	end with
end function

function ShowExpenseList(myDft)
dim mySql
dim myRec
dim buf

	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT COST_ID, COST_CD, COST_NAME FROM MST_COST"
	mySql = mySql & " WHERE COST_DELETED = 0"	' AND COST_TYPE = 2
	mySql = mySql & " ORDER BY COST_CD"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("COST_ID")
		if myDft = myRec.fields("COST_ID") then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("COST_CD") & " " & myRec.fields("COST_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	
	ShowExpenseList = buf	
end function
%>
