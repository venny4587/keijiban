<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim JobBelong
dim JobBroker
dim JobLocker

	myType = GetLong(request("Type"))			'0:���� 1:���� 2:���� 3:�ې�
	JobCode = GetPost(request("JobCode"))
	CostsNo = GetPost(request("CostsNo"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	if JobBroker = gsCorpCode then			'�{�Јϑ�
		myLevel = CheckUserLevel(gsCorpInit, JobBroker)
		if UserShop <> gsCorpInit and UserShop = left(JobCode, 1) then 
			myLevel = CheckUserLevel(JobBelong, JobBroker)
		end if
	else
		myLevel = CheckUserLevel(JobBelong, JobBroker)
	end if
	
if JobCode <> "" and CostsNo <> "" then
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
		
	with Recset
		strSql = "SELECT JobBelong, JobClient, JobManager, CTM_TYPE, CTM_NAME FROM CUSTOMER INNER JOIN TBL_CTM_JOB ON CUSTOMER.CTM_CD = TBL_CTM_JOB.JobClient"
		strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then
			JobBelong = GetString(.fields("JobBelong"))
			JobClient = GetString(.fields("JobClient"))
			JobManager = GetString(.fields("JobManager"))
			CTM_TYPE = GetLong(.fields("CTM_TYPE"))
		end if
		.Close
	
		strSql = "SELECT * FROM TBL_CTM_COSTS WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
		.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if not .eof then
			CostsBelong = GetString(.fields("CostsBelong"))
			CostsType = GetLong(.fields("CostsType"))
			CostsDate = Str2Date(.fields("CostsDate"))
			CostsClient = GetString(.fields("CostsClient"))
			CostsPic = GetString(.fields("CostsPic"))
			CostsAmount = GetLong(.fields("CostsAmount"))
			CostsTax = GetLong(.fields("CostsTax"))
			CostsPayDay = Str2Date(.fields("CostsPayDay"))
			CostsMemo = GetString(.fields("CostsMemo"))
			Remarks = GetString(.fields("Remarks"))
			
			CostsCheck = GetLong(.fields("CostsCheck"))
			ConfirmerID = GetLong(.fields("ConfirmerID"))
			ConfirmDate = GetDate(.fields("ConfirmDate"))
			FinisherID = GetLong(.fields("FinisherID"))
			FinishDate = GetDate(.fields("FinishDate"))
		end if
		.close
	end with
	
	select case GetLong(CostsType)
	case 0:		myLine = "#228b22"
	case 1:		myLine = "blue"
	case else:	myLine = "black"
	end select
	
	if CostsClient = gsCorpSoko then
		if UserShop = gsSokoInit then 
			myLevel = 2
			if WebUserID = gsSokoID then myLevel = 3
		else
			myLevel = 1
		end if
	end if
%>
<HTML>
<HEAD>
	<TITLE>�x���`�[���׏Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=javaScript>
		function ShowHead() {
<%	select case myType
	case 0					'�����@%>
			window.location.href = "CostsHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>"
<%	case 1					'�����@%>
			window.location.href = "CloseHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>"
<%	case else				'���ʁ@%>
			window.location.href = "PaymentHead.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&type=<%=myType%>"
<%	end select%>
		}
		
		function ShowDetail(myNo) {
			var win = window.open("CostsDetail.asp?type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&seq="+myNo,"CostsDetail","scrollbars=no,width=600,height=400");
			win.focus();
		}
		
		function ShowPattern(myNo) {
			var win = window.open("CostsPattern.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&type=<%=myType%>","CostsPattern","scrollbars=yes,width=800,height=500");
			win.focus();
		}
		
		function DoConfirm() {
			if (confirm("���͊������Ă�낵���ł����H")) {
				window.location.href = "CostsConfirm.asp?type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>"
			}
		}
		
		function DoCharge(myAmount) {
			if (confirm("���͊������Đ������쐬���܂����H")) {
				window.location.href = "CostsConfirm.asp?mode=1&type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&JobBelong=<%=JobBelong%>&JobClient=<%=JobClient%>&ChargeAmount=" + myAmount
			}
		}
		
		function DataUnLock() {
			if (confirm("�Y���x���`�[�m����������Ă�낵���ł����H")) {
				window.location.href = "CostsSave.asp?mode=3&type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>";
			}
		}
		
		function DoCombine(myNo) {
			window.location.href = "CostsCombine.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&type=<%=myType%>";
		}
		
		function GetChargeInfo() {
			window.location.href = "StandFetch.asp?JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>&type=<%=myType%>&mode=<%=CTM_TYPE%>";
		}
	</SCRIPT>
</HEAD>
<BODY bgcolor="<%=gsCostsBackColor%>" topmargin=3 leftmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=30%>
	  		��<%if myType = 0 then%>����<%elseif myType = 1 then%>����<%else%>�x��<%end if%>�`�[����&nbsp;
	  		<img style="cursor:hand" src=img/back.gif alt="�x���`�[��" onmousedown="ShowHead();">
	  	<td width=60% class=pt9 valign=bottom>
	  		�䒠�ԍ��F<font class=pt9b><%=JobCode%></font>
	  		�`�[�ԍ��F<font class=pt9n><%=CostsNo%></font>
	  	<td width=10% align=right nowrap>
<%	if ConfirmerID <> 0 then %>
<%		if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�x���ς�<%=GetEraseInfo(CostsNo, 1)%>">
<%		else %>
 		  <img style="cursor:help" src=img/security.gif alt="�m�F�ҁF<%=GetEmployName(ConfirmerID, "F") & " (" & ShowDateTimeShort(ConfirmDate) & ")"%>">
<%		end if %>
<%	else %>
		<%if ConfirmerID = 0 AND CostsType = 0 AND left(CostsClient, 4) = "7013" AND CostsAmount = 0 then%>
			<a class=bar href="javascript:GetChargeInfo()">�yDC�捞�z</a>
		<%end if%>
	  	<%if CheckTopLevel() > 0 or myLevel > 0 then %>
	  		<img style="cursor:hand" src=img/new.gif alt="�x�����ڐV�K�ǉ�" onmousedown="ShowDetail('');">
	  		<img style="cursor:hand" src=img/cover.jpg alt="�x���p�^�[���ďo" onmousedown="ShowPattern('');">
	  	<%end if%>
<%	end if %>
	</table>
	<hr size=1 color="<%=myLine%>"><%=JobHeader%><br>
	
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>����
		<TD class=line nowrap>�x������
		<TD class=line nowrap>���ڔ��l
		<TD class=line nowrap>�P��
		<TD class=line nowrap>����
		<TD class=line nowrap>�P��
		<TD class=line nowrap>�����
		<TD class=line nowrap>�Ŕ����z
<%
	cbo = 0
	cnt = 0
	myNull = 0
	ttlTax = 0
	ttlAmount = 0
	ttlTaxFree = 0
	ShortCut = ""
	with recset
		strSql = "SELECT SeqNo, ExpenseType, ExpenseAttr, ExpenseCost, COST_ID, COST_CD, COST_NAME, ExpenseTaxName"
		strSql = strSql & ",ExpenseQuantity, ExpenseUnit, ExpensePrice, ExpenseAmount, ExpenseTax, ExpenseMemo"
		strSql = strSql & " FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
		strSql = strSql & " WHERE Deleted = 0 AND ExpensePay = '" & CostsNo & "'" ' AND JobCode = '" & JobCode & "'
		strSql = strSql & " ORDER BY ExpenseType, COST_CD, SeqNo"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		do while not .eof
			cnt = cnt + 1
			CostName = GetString(.Fields("COST_NAME"))
			myMemo = GetString(.Fields("ExpenseMemo"))
			ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(cnt)) & ") ShowDetail('" & .Fields("SeqNo") & "');"
			if cnt < 10 then ShortCut = ShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + cnt) & ") ShowDetail('" & .Fields("SeqNo") & "');"
			if GetLong(.Fields("ExpenseType")) = gsStand then cbo = cbo + 1
%>
	<TR align=right height=20 style="cursor:hand" onmouseover="this.bgColor='<%=gsCostsForeColor%>';" onmouseout="this.bgColor='<%=gsCostsBackColor%>';" onclick="ShowDetail(<%=.Fields("SeqNo")%>);">
		<TD class=line align=center>[<%=Num2Code(cnt)%>]
		<TD class=line align=center><%=ShowExpenseType(.Fields("ExpenseType"))%><BR>
<%if GetLong(.Fields("COST_ID")) = 123 then %>
		<TD class=line nowrap align=left colspan=5><%=StringCut(myMemo,25)%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, false)%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, false)%><BR>
<%else%>
<%	if GetLong(.Fields("COST_ID")) <> 113 then %>
		<TD class=line nowrap align=left <%=ShowTitle(CostName, 10)%>><%=StringCut(CostName,10)%><BR>
		<TD class=line nowrap align=left <%=ShowTitle(myMemo, 8)%>><%=StringCut(myMemo,8)%><BR>
<%	else %>
		<TD class=line nowrap align=left colspan=2 <%=ShowTitle(myMemo, 16)%>><%=StringCut(myMemo,16)%><BR>
<%	end if %>
		<TD class=line nowrap><%=FitZero(formatnumber(GetDouble(.Fields("ExpensePrice")), 2, true))%><BR>
		<TD class=line nowrap><%=GetDouble(.Fields("ExpenseQuantity"))%><BR>
		<TD class=line nowrap align=center><%=GetString(.Fields("ExpenseUnit"))%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseTax")), 0, true)%><BR>
		<TD class=line nowrap><%=formatnumber(GetLong(.Fields("ExpenseAmount")), 0, true)%><BR>
<%end if
			if GetLong(.Fields("ExpenseTax")) = 0 then
				ttlTaxFree = ttlTaxFree + GetLong(.Fields("ExpenseAmount")) 
			else
				ttlTax = ttlTax + GetLong(.Fields("ExpenseTax"))
				ttlAmount = ttlAmount + GetLong(.Fields("ExpenseAmount"))
			end if
			select case CostsClient
			case gsCorpCode, gsCorpSoko
			case else
				if GetLong(.Fields("ExpenseAmount")) + GetLong(.Fields("ExpenseTax")) = 0 then 
					if CostName <> "RANDOM" then myNull = 1
				end if
			end select 
			.movenext
		loop
		if cnt > 0 then
%>
	<TR height=20>
		<TD colspan=6><%if JobLocker = 0 and myType = 2 and cbo > 1 and myLevel > 1 then%>
			<input type=button style="width:90;height:30" name=btnCombine value="���֌���" onclick="DoCombine()"><%end if%>
		<TD class=line colspan=2 align=right><font class=pt9><br>��ېŊz<br>�ېŋ��z<br>�� �� ��</font>
		<TD class=line align=right><br><%=formatnumber(ttlTaxFree, 0, true)%><br><%=formatnumber(ttlAmount, 0, true)%><br><%=formatnumber(ttlTax, 0, true)%>
	<TR align=right height=20>
		<TD colspan=8 class=pt9>�� �� �z<TD nowrap><%=formatnumber(ttlAmount + ttlTax + ttlTaxFree, 0, true)%>
<%
		end if
	end with
%>
	</TABLE>
<%
	if cnt = 0 then
		if CostsType <> 0 OR left(CostsClient, 4) <> "7013" then
			response.write "<script language=javascript>ShowPattern('')</script>"
		end if
	end if
	if myNull <> 0 then
%>
	<div align=center>
		<font class=pt12r>�������z���[���̐������ڂ͌�����܂����B</font>
	</div>
<%	
	elseif cnt > 0 and CostsCheck = 0 then
%>
	<div align=right><br>
<%		if (myType = 0) AND CTM_TYPE then %>
		<INPUT style="width:120px;height:30px;" TYPE=button VALUE="���֐���" onclick="DoCharge('<%=ttlAmount + ttlTax + ttlTaxFree%>')">
<%		end if %>
		<INPUT style="width:120px;height:30px;" TYPE=button VALUE="���͊���" onclick="DoConfirm()">
	</div>
<%
	elseif ConfirmerID <> 0 then 
%>
	<div align=center>
		<br><font class=pt12r>���b�N��</font>
	</div>
<%
	end if
%>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==38) ShowHead();
<%if ConfirmerID = 0 then%>
if (window.event.keyCode==119) ShowDetail('');
if (window.event.keyCode==120) ShowPattern('');
<%end if%>
<%if cnt > 0 then response.write ShortCut%>
}
</script>
</BODY>
</HTML>
<% 
end if

set recset = nothing
CloseDB Conn
%>
