<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobClient
dim JobClientName
dim JobBelong
dim JobBroker
dim JobMemo
dim JobSalesman
dim JobFinisher
dim JobLocker

dim CloseSales
dim CloseStand
dim CloseCosts
dim SightSales
dim SightStand
dim SightCosts

	myType = GetLong(request("type"))		'0:���� 1:���� 2:���� 3:�ې�
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	if JobBroker = gsCorpCode then			'�{�Јϑ�
		myLevel = CheckUserLevel(gsCorpInit, JobBroker)
		if UserShop <> gsCorpInit and UserShop = left(JobCode, 1) then 
			myLevel = CheckUserLevel(JobBelong, JobBroker)
		end if
	else
		myLevel = CheckUserLevel(JobBelong, JobBroker)
	end if
	if myLevel < 2 and JobSalesman = WebUserID then myLevel = 2
	
	CostsNo = GetPost(request("CostsNo"))
	if JobCode <> "" then
		mode = 0
		
		CostsType = 0
		CostsBillNo = "KARI"
		CostsDate = formatDate(date)
		ConfirmerID = 0
		FinisherID = 0
		CostsMemo = JobMemo
		
		OpenSql Conn, SqlServerName, DataBaseName
		
		if CostsNo <> "" then
			set Recset = Server.CreateObject("adodb.recordset") 
			with Recset
				strSql = "SELECT * FROM TBL_CTM_COSTS WHERE JobCode = '" & JobCode & "' AND CostsNo = '" & CostsNo & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					CostsType = GetLong(.fields("CostsType"))
					CostsDate = Str2Date(.fields("CostsDate"))
					
					CostsBillNo = GetString(.fields("CostsBillNo"))
					CostsClient = GetString(.fields("CostsClient"))
					CostsClientName = GetString(.fields("CostsClientName"))
					CostsPic = GetString(.fields("CostsPic"))
					CostsAmount = GetLong(.fields("CostsAmount"))
					CostsTax = GetLong(.fields("CostsTax"))
					CostsCloseDay = Str2Date(.fields("CostsCloseDay"))
					CostsPayDay = Str2Date(.fields("CostsPayDay"))
					CostsBatch = GetString(.fields("CostsBatch"))
					
					CostsMemo = GetString(.fields("CostsMemo"))
					CostsCheck = GetLong(.fields("CostsCheck"))
					Remarks = GetString(.fields("Remarks"))
					
					Creater = GetLong(.fields("Creater"))
					Created = GetDate(.fields("Created"))
					Updater = GetLong(.fields("Updater"))
					Updated = GetDate(.fields("Updated"))
					
					ConfirmerID = GetLong(.fields("ConfirmerID"))
					ConfirmDate = GetDate(.fields("ConfirmDate"))
					FinisherID = GetLong(.fields("FinisherID"))
					FinishDate = GetDate(.fields("FinishDate"))
				end if
				.close
			end with
		end if
		
		if CostsClient <> "" AND CostsPic = "" then CostsPic = GetDftManager(CostsClient)
		if GetCtmClose(CostsClient, CloseSales, CloseStand, CloseCosts) then
			CostsClose = ShowClose(CloseCosts)
			StandClose = ShowClose(CloseStand)
		end if
		if GetCtmSight(CostsClient, SightSales, SightStand, SightCosts) then
			CostsSight = ctmCredit(SightCosts \ 1000) & ShowPayDay(SightCosts mod 1000)
			StandSight = ctmCredit(SightStand \ 1000) & ShowPayDay(SightStand mod 1000)
		end if
		
		if mode = 0 then
			if CostsType = 0 and left(JobCode, 1) <> gsSokoInit then
				CostsCloseDay = Close2Date(CloseStand, CostsDate)
				CostsPayDay = Sight2Date(SightStand, CostsCloseDay)
			else
				CostsCloseDate = Close2Date(CloseCosts, CostsDate)
				CostsSightDate = Sight2Date(SightCosts, CostsCloseDay)
			end if
		end if

		if CostsClient = gsCorpSoko then
			if UserShop = gsSokoInit then 
				myLevel = 2
				if WebUserID = 60 or WebUserID = 87 then myLevel = 3
			elseif CheckTopLevel() = 0 then
				myLevel = 1
			end if
		end if
		
%>
<html>
<HEAD>
	<TITLE>�x���`�[�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>				
		sub DoSearch()
		dim cd, tp, dt
<%if left(JobCode, 1) = gsSokoInit then%>
			tp = 3
<%else%>
			tp = 4 - frmInput.CostsType.selectedIndex
<%end if%>
			cd = frmInput.ChargeRef.value
			dt = frmInput.CostsDate.value
		dim win
			set win = window.open("ChargerSearch.asp?type=" & tp & "&cd=" & cd & "&dt=" & dt,"ChargerSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub
		
		function ShowDetail()
			window.location.href = "CostsList.asp?type=<%=myType%>&JobCode=<%=JobCode%>&CostsNo=<%=CostsNo%>"
		end function
		
		sub DataLock()
			call DataSave(2)
		end sub
		
		sub DoRevise()
		dim cd
			cd = frmInput.Revise.value
			if len(cd) = 10 and cd <> frmInput.JobCode.value then 
				if msgbox ("�Y���x���`�[��ؑւ��Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "PaymentRevise.asp?CostsNo=<%=CostsNo%>&JobCode=" & cd
				end if
			else
				msgbox "�ؑ֐�䒠�ԍ��͕s���ł��B", 48, "���b�Z�[�W"
			end if
		end sub
		
		sub DataUnLock()
<%if JobLocker <> 0 then%>
			msgbox "�Y���䒠�ԍ��͊��ɑe�����b�N����܂����B", 48, "�m�F���b�Z�[�W"
<%elseif CheckBatchLocked(CostsBatch) <> 0 then %>
			msgbox "�Y���x���`�[�̃o�b�`���͊��Ɋm�肳��܂����B", 48, "�m�F���b�Z�[�W"
<%else%>
			if msgbox ("�Y���x���`�[�m����������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
<%end if%>
		end sub
		
		sub DoDelete()
			if msgbox ("�Y���x���`�[���폜���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DataSave(mode)
			if checkText("ChargeClient","�x����R�[�h",1) = false then exit sub
			if checkText("ChargeName","�x���於",1) = false then exit sub
			'if checkText("ChargePic","�x����S��",1) = false then exit sub
			if checkDate("CostsDate","�퐿����", 1) = false then exit sub
			if checkDate("CostsCloseDay","���ߓ�", 1) = false then exit sub
			if frmInput.CostsDate.value > frmInput.CostsCloseDay.value then
				if msgbox("�퐿�����͒��ߓ��ȍ~�ɂȂ��Ă�낵���ł����H", 49, "�m�F���b�Z�[�W") <> 1 then exit sub
			end if
			if checkDate("CostsPayDay","�x����", 1) = false then exit sub
			if checkText("CostsBillNo","���萿�����ԍ�", 1) = false then exit sub
			if checkText("CostsBatch", "�x���o�b�`�ԍ�", 0) = false then exit sub
			if checkText("CostsMemo","�x������", 0) = false then exit sub
			if checkLen("CostsMemo","�x������", 250) = false then exit sub
			if checkText("Remarks","�x�����l", 0) = false then exit sub
			if checkLen("Remarks","�x�����l", 250) = false then exit sub
			if mode = 2 then
<%if CostsClient = gsCorpSoko and UserShop <> gsSokoInit then%>
				if msgbox ("�Y���x���`�[�͎Г�������p�ł��B" & vbcrlf & _
							"�ېł̑���Ɋm�肵�Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") <> 1 then exit sub
<%else%>
				if msgbox ("�Y���x���`�[���m�肵�Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
				
		sub CostsRef_OnChange()
			frmInput.CostsClient.value = ""
			frmInput.CostsName.value = ""
		end sub
		sub CostsType_OnChange()
			ResetClosePayDay(0)
		end sub
		sub CostsDate_OnBlur()
			frmInput.CostsDate.value = setdate(frmInput.CostsDate.value)
			ResetClosePayDay(0)
		end sub
		sub CostsCloseDay_OnBlur()
			frmInput.CostsCloseDay.value = setdate(frmInput.CostsCloseDay.value)
			ResetClosePayDay(1)
		end sub
		sub CostsPayDay_OnBlur()
			frmInput.CostsPayDay.value = setdate(frmInput.CostsPayDay.value)
		end sub
		sub CostsBatch_OnBlur()
			frmInput.CostsBatch.value = FitBatchNo(frmInput.CostsBatch.value)
		end sub
		
		sub ResetClosePayDay(myMode)
		dim tp, dt
		dim cls, pay
			tp = frmInput.CostsType.options(frmInput.CostsType.selectedIndex).value
			dt = frmInput.CostsDate.value
			
			if tp = 0 then
				cls = frmInput.CloseStand.value
				pay = frmInput.SightStand.value
			else
				cls = frmInput.CloseCosts.value
				pay = frmInput.SightCosts.value
			end if
			
			if myMode = 0 then
				frmInput.CostsCloseDay.value = Close2Date(cls, dt)
			end if
			frmInput.CostsPayDay.value = Sight2Date(pay, frmInput.CostsCloseDay.value)
		end sub
		
		sub NewJobCode_OnBlur()
			frmInput.NewJobCode.value = FitJobCode(frmInput.NewJobCode.value)
		end sub	
		
		sub InitForm()
<%if ConfirmerID <> 0 or myLevel < 1 then %>
			call LockAll()
<%else%>
	<%if mode = 0 then%>
			frmInput.ChargeRef.focus()
	<%else%>
			frmInput.CostsBillNo.focus()
	<%end if%>
<%end if%>
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=40 then ShowDetail()
<%if ConfirmerID = 0 then%>	if window.event.keyCode=120 then call DataSave(<%=mode%>) <%end if%>
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsCostsBackColor%>" leftmargin=0 topmargin=3 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CostsSave.asp" method="post">
  	<input type=hidden name="JobBelong" value="<%=JobBelong%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="CostsNo" value="<%=CostsNo%>">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="Type" value="<%=myType%>">
  	<input type=hidden name="CloseCosts" value="<%=CloseCosts%>">
  	<input type=hidden name="CloseStand" value="<%=CloseStand%>">
  	<input type=hidden name="SightCosts" value="<%=SightCosts%>">
  	<input type=hidden name="SightStand" value="<%=SightStand%>">
  	<input type=hidden name="ChargePic" value="<%=ChargePic%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=30%>���x���`�[<%if mode=0 then%>�쐬<%else%>���<%end if%>&nbsp;
<%if mode = 1 then
	if myType <> 3 and ConfirmerID = 0 then %>
		  <%if myLevel > 0 then %><img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DoDelete()"><%end if%>
<%	else%>
		  <img style="cursor:hand" src=img/next.gif alt="���ׂ�" onmousedown="ShowDetail()">
<%	end if	
end if%>
	  	<td width=60% class=pt9 valign=bottom>�䒠�ԍ��F
<%if JobLocker = 0 and myLevel > 2 then%>
			<input class=si name="Revise" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
			<img style="cursor:hand" src=img/fetch.gif alt="�ؑ�" onmousedown="DoRevise()">
<%else%>
			<font class=pt9b><%=JobCode%></font>
<%end if%>
		<td width=10% align=right>
<%	if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�x���ς�<%=GetEraseInfo(CostsNo, 1)%>">
<%	elseif ConfirmerID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�m�F�ς�" <%if CheckTopLevel() > 0 or myLevel > 2 then %>onmousedown="DataUnLock()"<%end if%>>
<%	else %>
	<%	if mode = 1 and (CostsAmount <> 0 or CostsTax <> 0) then %>
	 	  <%if myLevel > 0 then %><img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DataLock()">&nbsp;<%end if%>
	<%	end if %>
	  	  <%if myLevel > 0 then %><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave(<%=mode%>)"><%end if%>
<%	end if %>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=28><!--�x���׎匟���𗬗p���邽�߁@Charge-->
		<TD align=center>�x����<input type=hidden name="ChargeClient" value="<%=CostsClient%>">
		<TD colspan=5><input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(CostsClient)%>" onkeydown="ResetEnter()">
			<%if ConfirmerID = 0 then %><a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a><%end if%>
			<input class=sj name="ChargeName" size=38 maxlength=50 value="<%=CostsClientName%>" onkeydown="ResetEnter()">
		<TD align=center class=pt9r>�x���敪
		<TD align=center><select name="CostsType" onkeydown="ResetEnter()" <%if ConfirmerID <> 0 then response.write "disabled"%>><%
			for i = 0 to ubound(payType)
				response.write "<option value=" & i
				if CostsType = i then response.write " selected" 
				response.write ">" & payType(i)
			next%></SELECT>
	  <TR height=28>
		<TD width=60 align=center nowrap><%if myType=3 then%>���o�ɇ�<%else%>���臂<%end if%>
		<TD><input class=si name="CostsBillNo" size=10 maxlength=50 value="<%=CostsBillNo%>" onkeydown="ResetEnter()">
		<TD width=60 align=center nowrap>�퐿����
		<TD><input class=si name="CostsDate" size=10 maxlength=10 value="<%=CostsDate%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9g nowrap>�x����
		<TD><input class=si name="CostsClose" size=10 maxlength=10 value="<%=CostsClose%>" onkeydown="ResetEnter()" readonly>
		<TD width=60 align=center class=pt9g nowrap>�x�����
		<TD><input class=si name="CostsSight" size=10 maxlength=10 value="<%=CostsSight%>" onkeydown="ResetEnter()" readonly>
	  <TR height=28>
		<TD width=60 align=center class=pt9g nowrap>���ߓ�
		<TD><input class=si name="CostsCloseDay" size=10 maxlength=10 value="<%=CostsCloseDay%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9g nowrap>�x����
		<TD><input class=si name="CostsPayDay" size=10 maxlength=10 value="<%=CostsPayDay%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9g nowrap>���֒�
		<TD><input class=si name="StandClose" size=10 maxlength=10 value="<%=StandClose%>" onkeydown="ResetEnter()" readonly>
		<TD width=60 align=center class=pt9g nowrap>���֎x��
		<TD><input class=si name="StandSight" size=10 maxlength=10 value="<%=StandSight%>" onkeydown="ResetEnter()" readonly>
	  <tr>
	  	<td><img src=img/spacer.gif height=3>
	  <TR>
		<TD align=center>�x��<br>����
		<TD colspan=5><textarea name="CostsMemo" rows=5 style="width:320"><%=CostsMemo%></textarea>
		<TD colspan=2 align=center class=pt12b>���͊���<br>
			<input type=checkbox name="CostsCheck" value=1 <%if CostsCheck then response.write " checked"%>>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR>
		<TD class=pt9 align=center>�Г�<br>���l
		<TD colspan=5><textarea class=sz name="Remarks" rows=5 style="width:320"><%=Remarks%></textarea>
<%	if mode = 1 and ConfirmerID <> 0 then %>
		<TD colspan=2 align=center class=pt12r>���b�N��
<%	end if %>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD nowrap width=60 align=center class=pt9g>�`�[�ԍ�
		<TD nowrap class=gline align=center><%=CostsNo%><br>
		<TD nowrap width=60 align=center class=pt9g>�ޯ��ԍ�
<%if myLevel > 1 then %>
		<TD nowrap align=center><input class=si name="CostsBatch" size=10 maxlength=6 value="<%=CostsBatch%>" onkeydown="ResetEnter()"><br>
<%else%>
		<TD nowrap class=gline align=center><%=CostsBatch%><input type=hidden name="CostsBatch" value="<%=CostsBatch%>"><br>
<%end if%>
		<TD nowrap width=60 align=center class=pt9g>�Ŕ����z
		<TD nowrap class=gline align=right><%=formatnumber(CostsAmount, 0, true)%>
		<TD nowrap width=60 align=center class=pt9g>�����
		<TD nowrap class=gline align=right><%=formatnumber(CostsTax, 0, true)%>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD align=center class=pt9g>�쐬��<TD class=gline align=center><%=GetEmployName(Creater, "F")%><br>
		<TD align=center class=pt9g>�쐬��<TD class=gline align=center><%=formatDate(Created)%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=GetEmployName(ConfirmerID, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=formatDate(ConfirmDate)%><br>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
function GetCostsManager(myCD)
dim mySql
dim myRec
	set myRec = Server.CreateObject ("ADODB.Recordset")	
	mySql = "SELECT PIC_NAME FROM CTM_PIC WHERE PIC_DELETED = 0 AND PIC_DFT = 1 AND CTM_CD = '" & myCD & "'"
	myRec.Open mySql, Conn, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetCostsManager = myRec.fields("PIC_NAME")
	myRec.close
	set myRec = nothing	
end function
%>