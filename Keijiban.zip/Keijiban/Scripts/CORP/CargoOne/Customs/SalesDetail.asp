<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'on error resume next
dim JobCode
dim JobBelong
dim JobBroker
dim JobClient
dim JobSalesman
		
	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 0)
	
	myLevel = CheckUserLevel(JobBelong, JobBroker)
	if myLevel < 3 and JobSalesman = WebUserID then myLevel = 3
	
	ChargeNo = GetPost(request("ChargeNo"))
	SeqNo = GetLong(request("seq"))
	if JobCode <> "" and SeqNo <> 0 then		
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
			strSql = "SELECT ChargeNo, ChargeClient, ChargeClientName, ChargeDate, ChargePayDay, ChargeType, FinisherID"
			strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then 
				 ChargeNo = GetString(.fields("ChargeNo"))
				 ExpenseClient = GetString(.fields("ChargeClient"))
				 ExpenseClientName = GetString(.fields("ChargeClientName"))
				 ChargeDate = Str2Date(.fields("ChargeDate"))
				 FinisherID = GetLong(.fields("FinisherID"))
			end if
			.close
			
			strSql = "SELECT * FROM TBL_CTM_EXPENSE WHERE JobCode = '" & JobCode & "' AND SeqNo = " & SeqNo
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				mode = 1
			'	ExpenseClient = GetString(.fields("ExpenseClient"))
				ExpenseCost = GetLong(.fields("ExpenseCost"))
				ExpenseType = GetLong(.fields("ExpenseType"))
				ExpenseAttr = GetLong(.fields("ExpenseAttr"))
				ExpenseDate = Str2Date(.fields("ExpenseDate"))
				ExpenseMemo = GetString(.fields("ExpenseMemo"))
				
				ExpenseQuantity = GetDouble(.fields("ExpenseQuantity"))
				ExpenseUnit = GetString(.fields("ExpenseUnit"))
				ExpensePrice = GetDouble(.fields("ExpensePrice"))
				ExpenseAmount = GetLong(.fields("ExpenseAmount"))
				ExpenseTaxName = GetString(.fields("ExpenseTaxName"))
				ExpenseTax = GetLong(.fields("ExpenseTax"))
				Remarks = GetString(.fields("Remarks"))
				
				ConfirmerID = GetLong(.fields("ConfirmerID"))
				ConfirmDate = GetDate(.fields("ConfirmDate"))
				ExpenseBill = GetLong(.fields("ExpenseBill"))
				ExpensePay = GetLong(.fields("ExpensePay"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
		end with
		
		if FinisherID = 0 and myLevel > 2 and left(ExpenseClient, 3) = "690" then
			Kenshu = 1
		else
			Kenshu = 0
		end if
%>
<html>
<HEAD>
	<TITLE>�����ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=vbscript>
		sub ShowKeepDetail()
			dim win
			set win = window.open("KeepDetail.asp?JobCode=<%=JobCode%>&No=<%=ChargeNo%>&Seq=<%=SeqNo%>","KeepDetail","resizable=0,StatusBar=0,scrollbars=1,width=600,height=400")
			win.focus()
		end sub
		
		sub DoDivide()
			window.location.href = "SalesDivide.asp?JobCode=<%=JobCode%>&seq=<%=SeqNo%>"
		end sub
		
		sub DataSave()
		dim buf
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
		end sub
	</script>
</Head>
<body bgcolor="<%=gsSalesBackColor%>" onkeydown="DoShortCut()"  topmargin=10 class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="SalesUpdate.asp" method="post">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="ChargeNo" value="<%=ChargeNo%>">
  	<input type=hidden name="SeqNo" value="<%=SeqNo%>">
  	<input type=hidden name="mode" value="1">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=18><td width=50%>�������ڍ׏��
	  	<td width=50%>
	  	<%if JobBroker = gsCorpCode and ExpenseCost = 67 and ExpenseAttr <> 2 then%>
	  		<%select case WebUserID%>
	  		<%case 1, 36, 47%>
	  			<a class=bar href="javascript:DoDivide()">�y���ڕ����z</a>
	  		<%end select%>
	  	<%end if%>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=28>
		<TD align=center class=pt9g>������
		<TD colspan=5>(<%=GetRefName(ExpenseClient)%>)
			<input class=si name="ClientName" size=45 value="<%=ExpenseClientName%>" readonly>
		<TD align=center>�����敪
		<TD class=gline align=center><%=ShowExpenseType(ExpenseType)%><br>
	  <TR height=28>
		<TD align=center>��������
		<TD class=gline colspan=3><%=GetExpenseName(ExpenseCost)%><br>
		<TD align=center class=pt9g>������<TD class=gline align=center><%=ChargeDate%><br>
		<TD align=center class=pt9g>�����ԍ�<TD class=gline align=center><%=ChargeNo%><br>
	  <TR height=28>
		<TD align=center class=pt9>���ڔ��l
<%if left(ExpenseClient, 3) = "690" then%>
		<TD colspan=5><input class=sj name="ExpenseMemo" size=35 maxlength=35 value="<%=ExpenseMemo%>">
			(��p���󎚐�������)
<%else%>
		<TD colspan=5><input class=sj name="ExpenseMemo" size=58 maxlength=100 value="<%=ExpenseMemo%>">
<%end if%>
<%if ExpenseType = gsStand then%>
		<TD align=center>��������
		<TD class=gline align=center><%=ShowExpenseAttr(ExpenseAttr)%><br>
<%else%>
		<TD align=center>���ڋ敪
		<TD class=gline align=center>
	<%if Kenshu <> 0 then%>
			<select name="ExpenseAttr" onkeydown="ResetEnter()"><%
			for i = 0 to ubound(sendType)
				response.write "<option value=" & i
				if ExpenseAttr = i then response.write " selected" 
				response.write ">" & sendType(i)
			next%></SELECT>
	<%else%>
			<input type=hidden name="ExpenseAttr" value="<%=ExpenseAttr%>"><%=ShowExpenseAttrFull(ExpenseAttr)%>
	<%end if%>
<%end if%>
	  <TR height=28>
		<TD align=center width=60 nowrap>�����P��
		<TD><input class=sn name="ExpensePrice" size=10 maxlength=8 value="<%=FitZero(formatnumber(ExpensePrice, 2, true))%>" onkeydown="ResetEnter()" readonly>
		<TD align=center width=60 nowrap>��������
		<TD><input class=sn name="ExpenseQuantity" size=8 maxlength=8 value="<%=ExpenseQuantity%>" onkeydown="ResetEnter()" readonly>
		<TD align=center width=60 nowrap>�����P��
		<TD class=gline align=center><%=ExpenseUnit%><br>
		<TD align=center width=60 nowrap>�Ŕ����z
		<TD><input class=sn name="ExpenseAmount" size=12 maxlength=8 value="<%=formatnumber(ExpenseAmount, 0, true)%>" onkeydown="ResetEnter()" readonly>
	  <TR height=28>
		<TD align=center>�ېŋ敪
		<TD class=gline align=center><%=ExpenseTaxName%><br>
		<TD align=center class=pt9>�����
		<TD><input class=sn name="ExpenseTax" size=8 maxlength=8 value="<%=formatnumber(ExpenseTax, 0, true)%>" onkeydown="ResetEnter()" readonly>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=GetEmployName(ConfirmerID, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=formatDate(ConfirmDate)%><br>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=28>
		<TD class=pt9 align=center>����
		<TD colspan=5><textarea name="Remarks" rows=4 style="width:350" readonly><%=Remarks%></textarea>
		<TD colspan=2 align=center>
		<%if ExpenseCost = 36 or ExpenseCost = 37 then%>
			<a href="javascript:ShowKeepDetail()"><img src=img/table.JPG border=0 alt="�ۊǏڍ�"></a><br>
		<%end if%>
		<%if Kenshu <> 0 then%>
			<input type=button style="width:90;height:30" name=btnSave value="F9:�ۑ�" onclick="DataSave()">
		<%else%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
		<%end if%>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	</TABLE>
  </FORM>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=24 align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(Creater, "F")%><br>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=formatDate(Created)%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=GetEmployName(Updater, "F")%><br>
		<TD width=10% class=pt9g>�X�V��<TD width=15% class=gline><%=formatDate(Updated)%><br>
	</TABLE>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>

<%
'�ďo��F PaymentDetail.asp �x�����׏��Ɖ�
function GetExpenseName(myDft)
	GetExpenseName = ""	
	with Recset			
		strSql = "SELECT COST_NAME FROM MST_COST WHERE COST_ID = " & myDft
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then GetExpenseName = GetString(.Fields("COST_NAME"))
		.close
	end with
end function
%>
