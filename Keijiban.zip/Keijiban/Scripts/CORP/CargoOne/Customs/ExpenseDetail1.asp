<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim PatternID
	dim ExpenseCost
	dim ExpenseType
	dim ExpenseUnit
	dim Remarks
	
	ExpenseID = GetLong(Request("ExpenseID"))
	PatternID = GetLong(Request("PatternID"))
	ExpenseCost = GetLong(Request("ExpenseCost"))
	ExpenseType = GetLong(Request("ExpenseType"))
	ExpenseUnit = GetPost(Request("ExpenseUnit"))
	ExpensePrice = GetDouble(Request("ExpensePrice"))
	ExpenseTaxName = GetPost(Request("ExpenseTaxName"))
	ExpenseMemo = GetPost(Request("ExpenseMemo"))
	ExpenseMin = GetLong(Request("ExpenseMin"))
	Remarks = GetPost(Request("Remarks"))
	if ExpenseMin <> 0 then Remarks = "����" & ExpenseMin & "�~" & Remarks

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If false Then			'�����d���\
		With Recset
			strSql = "SELECT ExpenseCost FROM PTN_EXPENSE WHERE ExpenseID <> " & ExpenseID & " AND PatternID = " & PatternID & " AND ExpenseCost = " & ExpenseCost
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����p���ڂ͊����ł��B"
			End If
			.Close 
		End With 
	End If
	
	If blnEdit Then	
			
		if ExpenseID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "EXPN_ID"
			cmdSQL.Execute
			ExpenseID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
		
		strSQL = "SELECT * FROM PTN_EXPENSE WHERE ExpenseID = " & ExpenseID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.Fields("PatternID") = PatternID
				.fields("ExpenseID") = ExpenseID
				.fields("Creater") = WebUserID
				.fields("Created") = now
				
			End If
			.Fields("ExpenseCost") = ExpenseCost
			.Fields("ExpenseType") = ExpenseType
			.Fields("ExpenseUnit") = ExpenseUnit
			.Fields("ExpensePrice") = ExpensePrice
			.Fields("ExpenseTaxName") = ExpenseTaxName
			.Fields("ExpenseMemo") = ExpenseMemo
			.Fields("Remarks") = Remarks
			
			.fields("Updater") = WebUserID
			.fields("Updated") = now		
			.Update 
			.Close 
		End With

'		if (Request("s") = "cd" or Request("s") = "") then
'			strURL = "ExpenseDetail.asp?PatternID=" & PatternID & "&p=" & GetCurrentPage(Conn, "PTN_EXPENSE", "ExpenseCost", 0, ExpenseCost, " AND PatternID = " & PatternID) & "&s=" & Request("s")
'		elseif (Request("s") = "en") then
'			strURL = "ExpenseDetail.asp?PatternID=" & PatternID & "&p=" & GetCurrentPage(Conn, "PTN_EXPENSE", "ExpensePrice", 0, ExpenseUnit, " AND PatternID = " & PatternID) & "&s=" & Request("s")
'		elseif (Request("s") = "jp") then
'			strURL = "ExpenseDetail.asp?PatternID=" & PatternID & "&p=" & GetCurrentPage(Conn, "PTN_EXPENSE", "ExpenseType", 0, ExpensePrice, " AND PatternID = " & PatternID) & "&s=" & Request("s")
'		end if 
		strURL = "ExpenseDetail.asp?PatternID=" & PatternID & "&p=" &  Request("p") & "&s=" & Request("s")
		Response.redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
