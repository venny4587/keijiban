<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		StockType = 1
		StockFrom = formatDate(date)
		ClientRef = GetPost(request("ClientRef"))
	else
		StockType = GetLong(request("StockType"))
		ClientRef = GetPost(request("ClientRef"))
		StockPlace = GetPost(request("StockPlace"))
		StockCode = GetPost(request("StockCode"))
		StockName = GetPost(request("StockName"))
		StockFrom = GetPost(request("StockFrom"))
		StockTo = GetPost(request("StockTo"))
		PkgFrom = GetPost(request("PkgFrom"))
		PkgTo = GetPost(request("PkgTo"))
		StockReferNo = GetPost(request("StockReferNo"))
		StockDelivery = GetPost(request("StockDelivery"))
		StockCustomer = GetPost(request("StockCustomer"))
		
		if PkgFrom <> "" then PkgFrom = GetLong(PkgFrom)
		if PkgTo <> "" then PkgTo = GetLong(PkgTo)		
	end if

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�݌ɏ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(no)
		dim win
			set win = window.open("StockOutDetail.asp?SeqNo=" & no, no, "scrollbars=1,width=800,height=500")
			win.focus()
		end function
		
		function ShowCharge()
		dim win
			if frmInput.ClientRef.value = "" then
				frmInput.ClientRef.focus()
				msgbox "�׎�̌���������͂��Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			else
				set win = window.open("StockOutCharge.asp?ref=" & frmInput.ClientRef.value, "StockOutCharge", "scrollbars=1,width=800,height=600")
				win.focus()
			end if
		end function
				
		function ShowReport()
		dim win
			if frmInput.ClientRef.value = "" then
				frmInput.ClientRef.focus()
				msgbox "�׎�̌���������͂��Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			else
				select case ucase(frmInput.ClientRef.value)
				case "ENAJI"
					set win = window.open("StockInPrint1.asp?ref=" & frmInput.ClientRef.value, "StockInPrint", "scrollbars=1,width=800,height=600")
				case else
					set win = window.open("StockInPrint2.asp?ref=" & frmInput.ClientRef.value, "StockInPrint", "scrollbars=1,width=800,height=600")
				end select
				win.focus()
			end if
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		function DoSort(mySort)
			frmInput.sort.value = mySort
			frmInput.submit()
		end function
		
		sub StockFrom_OnBlur()
			frmInput.StockFrom.value = setdate(frmInput.StockFrom.value)
		end sub
		sub StockTo_OnBlur()
			frmInput.StockTo.value = setdate(frmInput.StockTo.value)
		end sub		
		sub PkgFrom_OnBlur()
			if frmInput.PkgFrom.value = "" then exit sub
			frmInput.PkgFrom.value = GetLong(frmInput.PkgFrom.value)
		end sub		
		sub PkgTo_OnBlur()
			if frmInput.PkgTo.value = "" then exit sub
			frmInput.PkgTo.value = GetLong(frmInput.PkgTo.value)
		end sub
		sub StockType_OnChange()
			if frmInput.StockType.selectedIndex < 1 then
				window.location.href = "StockInView.asp?ClientRef=" & frmInput.ClientRef.value
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=119 then DoImport()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.ClientRef)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="StockOutView1.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">
				�q��<input class=sj name="StockPlace" value="<%=StockPlace%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�^���Ǝ�<input class=sj name="StockDelivery" value="<%=StockDelivery%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				�i��<input class=si name="StockCode" value="<%=StockCode%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				�i��<input class=sj name="StockName" value="<%=StockName%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				���臂<input class=si name="StockReferNo" value="<%=StockReferNo%>" maxlength=10 size=8 onkeydown="ResetEnter()">
			<TD rowspan=2 nowrap>
				<INPUT style="width:80px;height:30px;" TYPE=Button VALUE="�݌Ɉꗗ" onclick="ShowReport()">
				<INPUT style="width:80px;height:30px;" TYPE=Button VALUE="���ɕۊ�" onclick="ShowCharge()">
			<TR><TD nowrap>
				�敪&nbsp;<SELECT name="StockType" onkeydown="ResetEnter()">
						<option value="0" <%if StockType=0 then response.write "selected"%>>����
						<option value="1" <%if StockType=1 then response.write "selected"%>>�o��</select>
				�o�ɓ�<input class=si name="StockFrom" value="<%=StockFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="StockTo" value="<%=StockTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�o�ɐ�<input class=sn name="PkgFrom" value="<%=PkgFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="PkgTo" value="<%=PkgTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				�[�i��<input class=sj name="StockCustomer" value="<%=StockCustomer%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if StockCode <> "" OR StockName <> "" OR StockReferNo <> "" then
			strSel = " AND SeqNo IN (SELECT DISTINCT ExportNo FROM TBL_CTM_STOCK_LINK AS L INNER JOIN"
			strSel = strSel & " TBL_CTM_STOCK AS I ON I.SeqNo = L.ImportNo WHERE Deleted = 0 AND StockType = 0"
			if StockCode <> "" then strSel = strSel & " AND StockCode LIKE '%" & FitSel(StockCode) & "%'"
			if StockName <> "" then strSel = strSel & " AND StockName LIKE '%" & FitSel(StockName) & "%'"
			if StockReferNo <> "" then strSel = strSel & " AND StockReferNo LIKE '%" & FitSel(StockReferNo) & "%'"
			strSel = strSel & ")"
		end if
		strSQL = "SELECT * FROM TBL_CTM_STOCK AS S INNER JOIN"
		strSQL = strSQL & " (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON S.StockClient = C.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0 AND StockType = 1" & strSel
		if ClientRef <> "" then	strSQL = strSQL & " AND ClientRef = '" & FitSel(ClientRef) & "'"
		if StockPlace <> "" then strSel = strSel & " AND StockPlace LIKE '%" & FitSel(StockPlace) & "%'"
		if StockCustomer <> "" then strSQL = strSQL & " AND StockName LIKE '%" & FitSel(StockCustomer) & "%'"
		if StockDelivery <> "" then strSQL = strSQL & " AND StockDelivery LIKE '%" & FitSel(StockDelivery) & "%'"
		if StockFrom <> "" then strSQL = strSQL & " AND StockDate >= '" & Date2Str(StockFrom) & "'"
		if StockTo <> "" then strSQL = strSQL & " AND StockDate <= '" & Date2Str(StockTo) & "'"
		if PkgFrom <> "" then strSQL = strSQL & " AND StockPkgCnt >= " & PkgFrom
		if PkgTo <> "" then strSQL = strSQL & " AND StockPkgCnt <= " & PkgTo
		
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY ClientRef"
		case 1:		strSQL = strSQL & " ORDER BY StockDate"
		case 2:		strSQL = strSQL & " ORDER BY StockPlace"
		case 3:		strSQL = strSQL & " ORDER BY StockDelivery"
		case 4:		strSQL = strSQL & " ORDER BY StockName"
		case 5:		strSQL = strSQL & " ORDER BY StockMark"
		case 6:		strSQL = strSQL & " ORDER BY StockPkgCnt"
		end select
		strSQL = strSQL & " , SeqNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				myFlag = 1
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=4 align=center>
			<colgroup span=3 align=left>
			<colgroup span=3 align=right>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD width=4% nowrap>��
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�׎�
			<TD width=8% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�o�ɓ�
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�o�ɇ�
			<TD width=12% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�^���Ǝ�
			<TD width=20% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�[�i��
			<TD width=26% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�Z��
			<TD width=6% nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">�o�ɐ�
			<TD width=6% nowrap>KGS
			<TD width=6% nowrap>CBM
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else						
						StockPlace = GetString(.Fields("StockPlace"))
						StockDelivery = GetString(.Fields("StockDelivery"))
						StockName = GetString(.Fields("StockName"))
						StockMark = GetString(.Fields("StockMark"))
%>
					<TR style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("SeqNo")%>');">
						<TD nowrap class=line><%=lngCount%>
						<TD nowrap class=line><%=GetString(.Fields("ClientRef"))%><br>
						<TD nowrap class=line><%=Str2YMD(.Fields("StockDate"))%><br>
						<TD nowrap class=line><%=GetString(.Fields("StockNo"))%><br>
						<TD nowrap class=line <%=ShowTitle(StockDelivery, 8)%>><%=stringCut(StockDelivery, 8)%><br>
						<TD nowrap class=line <%=ShowTitle(StockName, 15)%>><%=stringCut(StockName, 15)%><br>
						<TD nowrap class=line <%=ShowTitle(StockMark, 20)%>><%=stringCut(StockMark, 20)%><br>
						<TD nowrap class=line style="color:green"><%=GetLong(.Fields("StockPkgCnt"))%><br>
						<TD nowrap class=line><%=formatnumber(GetDouble(.Fields("StockGW")), 0, true)%><br>
						<TD nowrap class=line><%=formatnumber(GetDouble(.Fields("StockCBM")),3,true)%><br>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
		</TABLE>
<%
			else
				myFlag = 0
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>