<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim JobClient
dim JobClientName
dim JobBelong
dim JobBroker
dim JobMemo
dim JobType
dim JobFinisher
dim JobDelivery
dim JobLocker
dim JobSalesman
dim JobInvoice

dim CloseSales
dim CloseStand
dim CloseCosts
dim SightSales
dim SightStand
dim ChargeCosts

	JobCode = GetPost(request("JobCode"))
	JobHeader = ShowCstmJobHead(JobCode, 1)
	myLevel = CheckUserLevel(JobBelong, JobBroker)
	if myLevel < 2 then
		if JobSalesman = WebUserID then myLevel = 2						'�c��
	end if
	
	Stand = date
	if JobDelivery <> "" then Stand = cdate(JobDelivery)
	
	ChargeNo = GetPost(request("ChargeNo"))
	if JobCode <> "" then
		mode = 0
		ChargeClient = JobClient
		ChargeClientName = GetFullName(ChargeClient)
		ConfirmerID = 0
		FinisherID = 0
		ChargeMemo = JobMemo
		
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		
		if ChargeNo <> "" then
			with Recset
				strSql = "SELECT * FROM TBL_CTM_CHARGE WHERE JobCode = '" & JobCode & "' AND ChargeNo = '" & ChargeNo & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					ChargeType = GetLong(.fields("ChargeType"))
					ChargeDate = Str2Date(.fields("ChargeDate"))
					
					ChargeClient = GetString(.fields("ChargeClient"))
					ChargeClientName = GetString(.fields("ChargeClientName"))
					ChargePic = GetString(.fields("ChargePic"))
					ChargeAmount = GetLong(.fields("ChargeAmount"))
					ChargeTax = GetLong(.fields("ChargeTax"))
					ChargeCloseDay = Str2Date(.fields("ChargeCloseDay"))
					ChargePayDay = Str2Date(.fields("ChargePayDay"))
					ChargeBatch = GetString(.fields("ChargeBatch"))
					
					ChargeMemo = GetString(.fields("ChargeMemo"))
					ChargeCheck = GetLong(.fields("ChargeCheck"))
					Remarks = GetString(.fields("Remarks"))
					
					Creater = GetLong(.fields("Creater"))
					Created = GetDate(.fields("Created"))
					Updater = GetLong(.fields("Updater"))
					Updated = GetDate(.fields("Updated"))
					
					ConfirmerID = GetLong(.fields("ConfirmerID"))
					ConfirmDate = GetDate(.fields("ConfirmDate"))
					FinisherID = GetLong(.fields("FinisherID"))
					FinishDate = GetDate(.fields("FinishDate"))
				end if
				.close
			end with
		end if
		
		if ChargeClient <> "" AND ChargePic = "" then ChargePic = GetDftManager(ChargeClient)
		if GetCtmClose(ChargeClient, CloseSales, CloseStand, CloseCosts) then
			SalesClose = ShowClose(CloseSales)
			StandClose = ShowClose(CloseStand)
		end if
		if GetCtmSight(ChargeClient, SightSales, SightStand, ChargeCosts) then
			SalesSight = ctmCredit(SightSales \ 1000) & ShowPayDay(SightSales mod 1000)
			StandSight = ctmCredit(SightStand \ 1000) & ShowPayDay(SightStand mod 1000)
		end if

		if mode = 0 then
			ChargeType = 0
			ChargeDate = formatDate(Stand)
			with Recset
				strSql = "SELECT CTM_TYPE FROM CUSTOMER WHERE CTM_CD = '" & ChargeClient & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then ChargeType = GetLong(.Fields("CTM_TYPE"))
				.close
			end with
			if JobBelong = gsSokoInit then ChargeType = 0
			if ChargeType = 0 then
				ChargeCloseDay = Close2Date(CloseSales, Stand)
				ChargePayDay = Sight2Date(SightSales, ChargeCloseDay)
			else
				ChargeType = gsStand
				ChargeCloseDay = Close2Date(CloseStand, Stand)
				ChargePayDay = Sight2Date(SightStand, ChargeCloseDay)
			end if
			if ChargePayDay <= ChargeCloseDay then ChargePayDay = dateadd("d", 7, ChargePayDay)
		end if
		
		AccountMonth = CheckAccountMonth()
		AccountMonth = left(AccountMonth, 4) & "/" & right(AccountMonth, 2)
		
		if WebUserID = 1 then AccountMonth = "2006/04"
%>
<html>
<HEAD>
	<TITLE>�������ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>				
		sub DoSearch()
		dim cd, tp, dt
			cd = frmInput.ChargeRef.value
<%if ChargeNo = "" then%>
			tp = frmInput.ChargeType.options(frmInput.ChargeType.selectedIndex).value
<%else%>
			tp = <%=ChargeType%>
<%end if%>
			dt = frmInput.ChargeDate.value
			dim win
			set win = window.open("ChargerSearch.asp?cd=" & cd & "&type=" & tp & "&dt=" & dt,"ChargerSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub	
				
		sub DoPrint()
<%if ConfirmerID = 0 then%>
			msgbox "�m��{�^������������A������s�\�ł��B", 48, "�m�F���b�Z�[�W"
<%else%>
			set win = window.open("BillPrint.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>","BillPrint","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
<%end if%>
		end sub
		
		function ShowDetail()
			window.location.href = "ChargeList.asp?JobCode=<%=JobCode%>&ChargeNo=<%=ChargeNo%>"
		end function
		
		sub DataLock()
			Call DataSave(2)
		end sub
		
		sub DataUnLock()
<%if JobLocker <> 0 then%>
			msgbox "�Y���䒠�ԍ��͊��ɑe�����b�N����܂����B", 48, "�m�F���b�Z�[�W"
<%elseif CheckBatchLocked(ChargeBatch) <> 0 then %>
			msgbox "�Y���������̈���ԍ��͊��ɑ��t����܂����B", 48, "�m�F���b�Z�[�W"
<%else%>
			if msgbox ("�Y���������m����������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
<%end if%>
		end sub
				
		sub DoDelete()
			if msgbox ("�Y�����������폜���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DataSave(mode)
			if checkText("ChargeClient","�����׎�",1) = false then exit sub
			if checkText("ChargeName","�����׎�",1) = false then exit sub
			if checkDate("ChargeDate","������", 1) = false then exit sub
			if datediff("d",date,cdate(frmInput.ChargeDate.value)) > 30 then
				frmInput.ChargeDate.focus()
				msgbox "��������30���ȓ��ɐݒ肵�Ă��������B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkDate("ChargeCloseDay","���ߓ�", 1) = false then exit sub
			if frmInput.ChargeDate.value > frmInput.ChargeCloseDay.value then
				if msgbox("�������͒��ߓ��ȍ~�ɂȂ��Ă�낵���ł����H", 48, "�m�F���b�Z�[�W") <> 1 then exit sub
			end if
			if checkDate("ChargePayDay","������", 1) = false then exit sub
			if datediff("d",cdate(frmInput.ChargeCloseDay.value),cdate(frmInput.ChargePayDay.value)) > 90 then
				frmInput.ChargePayDay.focus()
				msgbox "�������͒�������90���ȓ��ɐݒ肵�Ă��������B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkText("ChargeMemo","��������", 0) = false then exit sub
			if checkLen("ChargeMemo","��������", 250) = false then exit sub
			if checkText("Remarks","�������l", 0) = false then exit sub
			if checkLen("Remarks","�������l", 250) = false then exit sub
			if left(frmInput.ChargeDate.value, 7) <= "<%=AccountMonth%>" then
				frmInput.ChargeDate.focus()
				msgbox "�Y�����x�͊��Ɍ����߂���Ă��܂��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if mode = 1 then
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			elseif mode = 2 then
				if msgbox ("�Y�����������m�肵�Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
				frmInput.submit()
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
				
		sub ChargeRef_OnChange()
			frmInput.ChargeClient.value = ""
			frmInput.ChargeName.value = ""
		end sub
		sub ChargeType_OnChange()
			ResetClosePayDay(0)
		end sub
		sub ChargeDate_OnBlur()
			frmInput.ChargeDate.value = setdate(frmInput.ChargeDate.value)
			ResetClosePayDay(0)
		end sub
		sub ChargeCloseDay_OnBlur()
			frmInput.ChargeCloseDay.value = setdate(frmInput.ChargeCloseDay.value)
			ResetClosePayDay(1)
		end sub
		sub ChargePayDay_OnBlur()
			frmInput.ChargePayDay.value = setdate(frmInput.ChargePayDay.value)
		end sub
		
		sub ResetClosePayDay(myMode)
		dim tp, dt
		dim cls, pay
<%if ChargeNo = "" then%>
			tp = frmInput.ChargeType.options(frmInput.ChargeType.selectedIndex).value
<%else%>
			tp = <%=ChargeType%>
<%end if%>
			dt = frmInput.ChargeDate.value
			
			if tp = <%=gsStand%> then
				cls = frmInput.CloseStand.value
				pay = frmInput.SightStand.value
			else
				cls = frmInput.CloseSales.value
				pay = frmInput.SightSales.value
			end if
			
			if myMode = 0 then
				frmInput.ChargeCloseDay.value = Close2Date(cls, dt)
			end if
			frmInput.ChargePayDay.value = Sight2Date(pay, frmInput.ChargeCloseDay.value)
			if frmInput.ChargePayDay.value <= frmInput.ChargeCloseDay.value then
				frmInput.ChargePayDay.value = formatDate(dateadd("d", 7, cdate(frmInput.ChargePayDay.value)))
			end if
		end sub
		
		sub InitForm()
<%if ConfirmerID <> 0 or myLevel < 1 then %>
			call LockAll()
<%else%>
	<%if mode = 0 then%>
			frmInput.ChargeType.focus()
	<%else%>
			frmInput.ChargeMemo.focus()
	<%end if%>
<%end if%>
		end sub	
		
		sub DoShortCut()
<%if mode <> 0 then%>
			if window.event.keyCode=40 then ShowDetail()
<%end if%>
<%if ConfirmerID = 0 then%>
			if window.event.keyCode=120 then call DataSave(<%=mode%>)
<%else%>
			if window.event.keyCode=80 then DoPrint()
<%end if%>
		end sub
	</SCRIPT>
</Head>
<body bgcolor="<%=gsSalesBackColor%>" leftmargin=0 topmargin=3 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="ChargeSave.asp" method="post">
  	<input type=hidden name="JobBelong" value="<%=JobBelong%>">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="ChargeNo" value="<%=ChargeNo%>">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="CloseSales" value="<%=CloseSales%>">
  	<input type=hidden name="CloseStand" value="<%=CloseStand%>">
  	<input type=hidden name="SightSales" value="<%=SightSales%>">
  	<input type=hidden name="SightStand" value="<%=SightStand%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=30%>��������<%if mode=0 then%>�쐬<%else%>���<%end if%>&nbsp;
<%if mode = 1 then
	if ConfirmerID = 0 then %>
		  <%if myLevel > 0 then %><img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DoDelete()"><%end if%>
<%	else%>
		  <img style="cursor:hand" src=img/next.gif alt="���ׂ�" onmousedown="ShowDetail()">
<%	end if	
end if%>
	  	<td width=60% class=pt9 valign=bottom>
	  		�䒠�ԍ��F<font class=pt9b><%=JobCode%></font>
		�@	INV No.<font class=pt9b><%=StringCut(JobInvoice, 20)%></font>
		<td width=10% align=right>
<%	if FinisherID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�����ς�<%=GetEraseInfo(ChargeNo, 0)%>">
<%	elseif ConfirmerID <> 0 then %>
	  	  <img style="cursor:help" src=img/security.gif alt="�m�F�ς�" <%if myLevel > 2 then %>onmousedown="DataUnLock()"<%end if%>>
<%	else %>
	<%	if mode = 1 and (ChargeAmount <> 0 or ChargeTax <> 0 or CheckTopLevel() > 0) then %>
	 	  <%if myLevel > 1 then %><img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DataLock()">&nbsp;<%end if%>
	 	  <%if (myLevel = 1 and ChargeType = 2) then %><img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DataLock()">&nbsp;<%end if%>
	<%	end if %>
	  	  <%if myLevel > 0 then %><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave(<%=mode%>)"><%end if%>
<%	end if %>
<%	if ConfirmerID <> 0 then %>
	  	  <img style="cursor:hand" src=img/print.jpg alt="���������" onmousedown="DoPrint()">
<%	end if %>
	</table>
	<hr width=96% size=1><%=JobHeader%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR>
	  	<TD><img src=img/spacer.gif height=20>
	  <TR height=28>
		<TD align=center>������<input type=hidden name="ChargeClient" value="<%=ChargeClient%>">
		<TD colspan=5><input class=si name="ChargeRef" size=8 maxlength=10 value="<%=GetRefName(ChargeClient)%>" onkeydown="ResetEnter()">
			<%if ConfirmerID = 0 then %><a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a><%end if%>
			<input class=sj name="ChargeName" size=38 maxlength=50 value="<%=ChargeClientName%>" onkeydown="ResetEnter()">
		<TD align=center class=pt9r>�����敪
<%if mode = 0 then%>
		<TD><select name="ChargeType" onkeydown="ResetEnter()"><%
			for i = 0 to ubound(billType)
				response.write "<option value=" & i
				if ChargeType = i then response.write " selected" 
				response.write ">" & billType(i)
			next%></SELECT>
<%else%>
		<TD><%=billType(ChargeType)%><input type=hidden name="ChargeType" value="<%=ChargeType%>">
<%end if%>
	  <TR height=28>
		<TD align=center>�S����
		<TD><input class=sj name="ChargePic" size=10 maxlength=50 value="<%=ChargePic%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9r nowrap>������</TD>
		<TD><input class=si name="ChargeDate" size=10 maxlength=10 value="<%=ChargeDate%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9g nowrap>������
		<TD><input class=si name="SalesClose" size=10 maxlength=10 value="<%=SalesClose%>" onkeydown="ResetEnter()" readonly>
		<TD width=60 align=center class=pt9g nowrap>�����x��
		<TD><input class=si name="SalesSight" size=10 maxlength=10 value="<%=SalesSight%>" onkeydown="ResetEnter()" readonly>
	  <TR height=28>
		<TD width=60 align=center class=pt9g nowrap>���ߓ�</TD>
		<TD><input class=si name="ChargeCloseDay" size=10 maxlength=10 value="<%=ChargeCloseDay%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9g nowrap>������</TD>
		<TD><input class=si name="ChargePayDay" size=10 maxlength=10 value="<%=ChargePayDay%>" onkeydown="ResetEnter()">
		<TD width=60 align=center class=pt9g nowrap>���֒�
		<TD><input class=si name="StandClose" size=10 maxlength=10 value="<%=StandClose%>" onkeydown="ResetEnter()" readonly>
		<TD width=60 align=center class=pt9g nowrap>���֎x��
		<TD><input class=si name="StandSight" size=10 maxlength=10 value="<%=StandSight%>" onkeydown="ResetEnter()" readonly>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR>
		<TD class=pt9 align=center>����<br>����
		<TD colspan=5><textarea name="ChargeMemo" rows=5 style="width:320"><%=ChargeMemo%></textarea>
		<TD colspan=2 align=center class=pt12b>���͊���<br>
			<input type=checkbox name="ChargeCheck" value=1 <%if ChargeCheck then response.write " checked"%>>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR>
		<TD class=pt9 align=center>�Г�<br>���l
		<TD colspan=5><textarea class=sz name="Remarks" rows=5 style="width:320"><%=Remarks%></textarea>
<%	if ConfirmerID <> 0 then %>
		<TD colspan=2 align=center class=pt12r>���b�N��
<%	elseif CheckJobType(JobCode) = gsExport then%>
		<TD colspan=2 align=center class=pt12r>��ƌ`��<br><select name="JobType" class=pt9n onkeydown="ResetEnter()" <%if FinisherID <> 0 then response.write "disabled" %>>
		  	<%for i = 1 to ubound(expType)%><option value="<%=expType(i)%>" <%if JobType = expType(i) then response.write "selected"%>><%=expType(i)%><%next%></select>
<%	end if%>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD nowrap width=60 align=center class=pt9g>�����ԍ�
		<TD nowrap class=gline align=center><%=ChargeNo%><br>
		<TD nowrap width=60 align=center class=pt9g>����ԍ�
<%if myLevel > 2 then %>
		<TD nowrap align=center><input class=si name="ChargeBatch" size=10 maxlength=6 value="<%=ChargeBatch%>" onkeydown="ResetEnter()"><br>
<%else%>
		<TD nowrap class=gline align=center><%=ChargeBatch%><input type=hidden name="ChargeBatch" value="<%=ChargeBatch%>"><br>
<%end if%>
		<TD nowrap width=60 align=center class=pt9g>�Ŕ����z
		<TD nowrap class=gline align=right><%=formatnumber(ChargeAmount, 0, true)%>
		<TD nowrap width=60 align=center class=pt9g>�����
		<TD nowrap class=gline align=right><%=formatnumber(ChargeTax, 0, true)%>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD align=center class=pt9g>�쐬��<TD class=gline align=center><%=GetEmployName(Creater, "F")%><br>
		<TD align=center class=pt9g>�쐬��<TD class=gline align=center><%=formatDate(Created)%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=GetEmployName(ConfirmerID, "F")%><br>
		<TD align=center class=pt9g>�m�F��<TD class=gline align=center><%=formatDate(ConfirmDate)%><br>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
		set Recset = nothing
		CloseDB Conn
	end if
%>