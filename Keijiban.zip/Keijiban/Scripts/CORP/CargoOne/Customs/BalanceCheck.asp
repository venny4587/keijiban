<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

mode = GetLong(request("mode"))
JobCode = GetPost(request("JobCode"))
if JobCode <> "" then
	FinisherID = 0
	FinishDate = ""
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	if mode <> 0 then
		
		if mode = 1 then
			myMsg = CheckJobBillConfirmed(Conn, JobCode)
			if myMsg <> "" then
				ShowMessage myMsg
			else
				'�ŐV�f�[�^�擾
				SalesSum = 0
				SalesTax = 0
				CostsSum = 0
				CostsTax = 0
				StandSum = 0
				
				with Recset
					strSql = "SELECT ExpenseType, Sum(ExpenseAmount) AS AMNT, Sum(ExpenseTax) AS TAX"
					strSql = strSql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
					strSql = strSql & " GROUP BY ExpenseType"
if WebUserID = gsAdmin then response.write strSql
					.Open strSql,conn,adOpenStatic,adLockReadOnly 
					do while not .eof
						select case GetLong(.fields("ExpenseType"))
						case gsCharge					'����
							SalesSum = GetLong(.fields("AMNT"))
							SalesTax = GetLong(.fields("TAX"))
						case gsStand					'����
							StandSum = GetLong(.fields("AMNT")) + GetLong(.fields("TAX"))
						case gsPayment					'�x��
							CostsSum = GetLong(.fields("AMNT"))
							CostsTax = GetLong(.fields("TAX"))
						end select
						.movenext
					Loop
					.close			
					Interests = (SalesSum + SalesTax) - (CostsSum + CostsTax)							
				end with
			
				'�e�����b�N���s
				strSql = "UPDATE TBL_CTM_JOB SET LockDate = GETDATE()"
				strSql = strSql & ",LockerID = " & WebUserID
				strSql = strSql & ",SalesSum = " & SalesSum
				strSql = strSql & ",SalesTax = " & SalesTax
				strSql = strSql & ",CostsSum = " & CostsSum
				strSql = strSql & ",CostsTax = " & CostsTax
				strSql = strSql & ",StandSum = " & StandSum
				strSql = strSql & ",Interests = " & Interests
				strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
if WebUserID = gsAdmin then response.write strSql
				Conn.Execute strSql
				
			end if
		else
			'�e�����b�N����
			strSql = "UPDATE TBL_CTM_JOB SET LockDate = NULL, LockerID = 0"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
			Conn.Execute strSql
		end if
		
	else
	
		with Recset
			'�����f�[�^�擾
			strSql = "SELECT SalesSum, SalesTax, CostsSum, CostsTax, StandSum, Interests, SalesDate"
			strSql = strSql & " , FinisherID, FinishDate, LockerID, LockDate, AccountDate"
			strSql = strSql & " FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				FinisherID = GetLong(.fields("FinisherID"))
				FinishDate = GetDate(.fields("FinishDate"))
				LockerID = GetLong(.fields("LockerID"))
				LockDate = GetDate(.fields("LockDate"))
				SalesSum = GetLong(.fields("SalesSum"))
				SalesTax = GetLong(.fields("SalesTax"))
				CostsSum = GetLong(.fields("CostsSum"))
				CostsTax = GetLong(.fields("CostsTax"))
				StandSum = GetString(.fields("StandSum"))
				Interests = GetLong(.fields("Interests"))
				SalesDate = GetString(.fields("SalesDate"))
				AccountDate = GetString(.fields("AccountDate"))
			end if
			.close
			
			'�������m��
			ChargeAmount = 0
			strSql = "SELECT SUM(ChargeAmount+ChargeTax) AS ChargeAmount FROM TBL_CTM_CHARGE"
			strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0 AND JobCode = '" & JobCode & "'"
if WebUserID = gsAdmin then response.write strSql
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then ChargeAmount = GetLong(.fields("ChargeAmount"))
			.close
			
			'�Г�������
			CostsAmount = 0
			strSql = "SELECT SUM(CostsAmount+CostsTax) AS CostsAmount FROM TBL_CTM_COSTS"
			strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
			strSql = strSql & " AND CostsClient IN ('CH000001', 'CH000002')"	
if WebUserID = gsAdmin then response.write strSql
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then CostsAmount = GetLong(.fields("CostsAmount"))
			.close
			
			if LockerID = 0 then
				
				'�ŐV�f�[�^�擾
				SalesSum = 0
				SalesTax = 0
				CostsSum = 0
				CostsTax = 0
				StandSum = 0
				
				strSql = "SELECT ExpenseType, Sum(ExpenseAmount) AS AMNT, Sum(ExpenseTax) AS TAX"
				strSql = strSql & " FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
				strSql = strSql & " GROUP BY ExpenseType"
if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				do while not .eof
					select case GetLong(.fields("ExpenseType"))
					case gsCharge					'����
						SalesSum = GetLong(.fields("AMNT"))
						SalesTax = GetLong(.fields("TAX"))
					case gsStand					'����
						StandSum = GetLong(.fields("AMNT")) + GetLong(.fields("TAX"))
					case gsPayment					'�x��
						CostsSum = GetLong(.fields("AMNT"))
						CostsTax = GetLong(.fields("TAX"))
					end select
					.movenext
				Loop
				.close
				Interests = (SalesSum + SalesTax) - (CostsSum + CostsTax)
				
				'�e���f�[�^�X�V
				strSql = "UPDATE TBL_CTM_JOB SET"
				strSql = strSql & " SalesSum = " & SalesSum
				strSql = strSql & ",SalesTax = " & SalesTax
				strSql = strSql & ",CostsSum = " & CostsSum
				strSql = strSql & ",CostsTax = " & CostsTax
				strSql = strSql & ",StandSum = " & StandSum
				strSql = strSql & ",Interests = " & Interests
				strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
				Conn.Execute strSql
				
			end if
			
		end with
		
	end if
	set Recset = nothing
	CloseDB Conn
		
	if mode <> 0 then
%>
<HTML><script language=javascript>
	window.parent.location.href = "ExpenseInfo.asp?JobCode=<%=JobCode%>"
</script></html>
<%
	else
%>
<HTML>
<HEAD>
	<TITLE>�e���������</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT LANGUAGE=vbscript>
		sub ShowChargeList()
			window.parent.parent.ctms.location.href = "ChargeInfo.asp?JobCode=<%=JobCode%>"
		end sub
		
		sub DataLock()
			if msgbox ("�Y����p�f�[�^�����b�N���Ă�낵���ł����B", <%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.submit()
			end if
		end sub
		
		sub DataUnLock()
<%if AccountDate = "" then%>
			if msgbox ("�Y����p���b�N���������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 2
				frmInput.submit()
			end if
<%else%>
			msgbox "�Y���f�[�^�͊��Ɍ����߂���܂����B", 48, "�m�F���b�Z�[�W"
<%end if%>
		end sub
	</SCRIPT>
</HEAD>
</Head>
<body bgcolor="<%=gsSalesBackColor%>" topmargin=5 class=pt9 <%=gsBodyControl%>>
  <FORM NAME="frmInput" action="BalanceCheck.asp" method="post">
  	<input type=hidden name="JobCode" value="<%=JobCode%>">
  	<input type=hidden name="mode" value="1">
	<table Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=24>
	  	<td nowrap class=redline width=160>���o�����X(�ō����z)&nbsp;
			<img style="cursor:hand" src=img/search.jpg alt="�������Ɖ�" onmousedown="ShowChargeList()">
		<td class=redline width=160 align=right>
<%	if LockerID <> 0 then %>
	  		<img style="cursor:hand" src=img/security.gif alt="�m�F�ҁF<%=GetEmployName(LockerID, "F") & " (" & ShowDateTimeShort(LockDate) & ")"%>"
	  	 <%if CheckUserLevel(left(JobCode,1), "") > 2 then %>onmousedown="DataUnLock()"<%end if%>>
<%	else%>
		<%if FinisherID <> 0 and SalesDate <> "" then %>
			<%if CheckUserLevel(left(JobCode,1), "") > 2 then %><img style="cursor:hand" src=img/check.jpg alt="�m�F" onmousedown="DataLock()"><%end if%>
		<%end if%>
<%	end if%><br>
	</table>				
	<table Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22 align=right>
		<TD nowrap width=60>������z</TD>
		<TD nowrap width=80>\<%=formatnumber(SalesSum+SalesTax, 0, true)%>
		<TD width=20><br>
		<TD nowrap width=80>�������z���v</TD>
		<TD nowrap width=80>\<%=formatnumber(SalesSum+SalesTax+StandSum, 0, true)%>&nbsp;
	  <TR height=22 align=right>
		<TD class=pt9g>���֋��z</TD>
		<TD>\<%=formatnumber(StandSum, 0, true)%>
		<TD><br>
		<TD class=pt9b>�������m���</TD>
		<TD <%if ChargeAmount <> SalesSum+SalesTax+StandSum then response.write " style=""color:red"""%>>\<%=formatnumber(ChargeAmount, 0, true)%>&nbsp;
	  <TR height=22 align=right>
		<TD class=gline>�O�����z</TD>
		<TD class=gline>\<%=formatnumber(CostsSum+CostsTax, 0, true)%>
		<TD class=gline><br>
		<TD class=gline>�Г��������z</TD>
		<TD class=gline>\<%=formatnumber(CostsAmount, 0, true)%>&nbsp;
	  <TR height=22 align=right>
		<TD class=pt9n align=center>�e���v</TD>
		<TD <%if Interests < 0 then%>style="color:red"<%end if%>>\<%=formatnumber(Interests, 0, true)%>
		<TD><br>
		<TD>�e����</TD>
		<TD><%if SalesSum <> 0 then response.write formatnumber(Interests * 100 / (SalesSum+SalesTax) , 2, true)%>%
	</TABLE>
  </FORM>
</body></html>
<%
	end if
end if
%>
