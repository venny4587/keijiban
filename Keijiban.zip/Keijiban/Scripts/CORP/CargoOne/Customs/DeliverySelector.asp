<%
	Dim l
	Dim lngFrames
	Dim strCalc
	
	lngFrames = clng(Request("lngFrames"))
%>
<HTML>
	<HEAD>
		<SCRIPT LANGUAGE="VBScript">
			<!--
			Sub ChangeWidth(intNumber)
				Dim l
				Dim s
				
				For l = 1 To <%=lngFrames%>
					If l = intNumber Then
						s = s & "100%,"
					Else
						s = s & "0,"
					End If
				Next
				s = Left(s, Len(s) - 1)
				parent.fraCalc.cols = s
			End Sub
			
			sub PrintAll()
				top.print
			end sub
			-->
		</SCRIPT>
	</HEAD>
	<BODY>
		<%
		For l = 1 To lngFrames
			Response.Write "<INPUT TYPE=BUTTON OnClick='ChangeWidth(" & l & ")' VALUE=" & l & " STYLE='width:50px;border-width:1px;background-color:#E0E0E0'>" & vbCrLf
		Next
		%>
		<INPUT TYPE=BUTTON OnClick='PrintAll()' value="Print" STYLE='width:50px;border-width:1px;background-color:#E0E0E0'>
	</BODY>
</HTML>

