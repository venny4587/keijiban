<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
		
	myPageSize = GetUserPageSize(15)
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then	
		JobType = ""				'�q�ɔ��p
		'JobOperator = WebUserID
		JobSalesman = WebUserID
		if instr(session("Depart"), "�A��") <> 0 then JobType = gsImport
		if instr(session("Depart"), "�A�o") <> 0 then JobType = gsExport
		JobFinish = 1
		'JobCode = "DC" & Num2Code(year(date)-2000) & Num2Code(Month(date)) & GetInitJobType()
	else
		JobType = GetPost(request("JobType"))		
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		JobOperator = GetLong(request("JobOperator"))
		JobSalesman = GetLong(request("JobSalesman"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		Port = GetPost(request("Port"))
		Vessel = GetPost(request("Vessel"))
		JobFinish = GetLong(request("JobFinish"))
	end if

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�ʊ֋Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd)
		dim win
			set win = window.open("MainFrame.asp?mode=1&JobCode=" & cd,"CustomsJob","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
				
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
				
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
		
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub		
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="SetEndFocus(frmInput.ClientRef)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="ChargeBillExec.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				������<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�Ɩ�&nbsp;<SELECT name="JobType" onkeydown="ResetEnter()"><option value="">�S��<%=ShowJobType(JobType)%></select>
				�c��&nbsp;<SELECT name="JobSalesman" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartSales, JobSalesman)%></select>					
				�S��&nbsp;<SELECT name="JobOperator" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartCustoms, JobOperator)%></select>
			<TR><TD nowrap>
				�`<input class=si name="Port" value="<%=Port%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				���o�`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�D��<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=10 onkeydown="ResetEnter()">
				�����̂�<input type=checkbox name="JobFinish" value="1" onkeydown="ResetEnter()" <%if JobFinish then response.write " checked"%>>
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
		</table>
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND SUBSTRING(JobCode,2,1) = '" & JobType & "'" 
		if JobCode <> "" then strSel = strSel & " AND JobCode LIKE '%" & FitSel(JobCode) & "%'" 
		if ClientRef <> "" then	strSel = strSel & GetClientSel(ClientRef, 0)
		if JobOperator <> 0 then strSel = strSel & " AND JobOperator = " & JobOperator
		if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if Port <> "" then strSel = strSel & " AND (POL LIKE '%" & FitSel(Port) & "%' OR POD LIKE '%" & FitSel(Port) & "%')"
		if Vessel <> "" then strSel = strSel & " AND VesselVoy LIKE '%" & FitSel(Vessel) & "%'"	
		if JobFinish = 1 then strSel = strSel & " AND FinisherID <> 0"
		
		strSQL = "SELECT * FROM ("
		strSQL = strSQL & "SELECT JobCode, CTM_CD, ClientRef, JobOperator, JobSalesman, MBL+' '+HBL AS BLNO, Vessel+' '+Voy AS VesselVoy, POL, POD, DeliveryDate"
		strSQL = strSQL & ", CASE SUBSTRING(JobCode,2,1) WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD, Created, SalesDate, StandDate, CustomBroker"
		strSQL = strSQL & ", FinisherID FROM TBL_CTM_JOB AS J INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
		strSQL = strSQL & " WHERE Deleted = 0 AND LockerID = 0) AS TMP"			'���폜�@�����b�N
		if CheckTopLevel() = 0 then 
			if UserShop = gsCorpInit then
				strSql = strSql & " WHERE (SUBSTRING(JobCode,1,1) = '" & UserShop & "' OR CustomBroker = '" & gsCorpCode & "')"
				strSql = strSql & strSel
			else
				strSql = strSql & " WHERE SUBSTRING(JobCode,1,1) = '" & UserShop & "'" & strSel
			end if
		else
			if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel,5)
		end if
		select case mySort
		case 0:		strSql = strSql & " ORDER BY SalesDate, DeliveryDate, JobCode"
		case 1:		strSql = strSql & " ORDER BY ETAETD, JobCode"
		case 2:		strSql = strSql & " ORDER BY JobCode"
		case 3:		strSql = strSql & " ORDER BY StandDate, JobCode"
		case 4:		strSql = strSql & " ORDER BY DeliveryDate, JobCode"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr>
				<td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%></td>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
				</td>
			</TR>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		  <TR align=center height=20>
			<TD nowrap class=line width=4%>��
			<TD nowrap class=line width=12% style="cursor:hand;color:blue" onmousedown="DoSort(2)">�䒠�ԍ�
			<TD nowrap class=line width=10%>�����׎�
			<TD nowrap class=line width=12%>POL
			<TD nowrap class=line width=12%>POD
			<TD nowrap class=line width=10% style="cursor:hand;color:blue" onmousedown="DoSort(1)">���o�`
			<TD nowrap class=line width=8%>�Ɩ�
			<TD nowrap class=line width=8% style="cursor:hand;color:blue" onmousedown="DoSort(0)">������
			<TD nowrap class=line width=8% style="cursor:hand;color:blue" onmousedown="DoSort(3)">���֓�
			<TD nowrap class=line width=8%>�c��
			<TD nowrap class=line width=8% style="cursor:hand;color:blue" onmousedown="DoSort(4)">����
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						ClientRef = GetString(.Fields("ClientRef"))
						VesselVoy = GetString(.Fields("VesselVoy"))
						BLNO = GetString(.Fields("BLNO"))
						POL = GetString(.Fields("POL"))
						POD = GetString(.Fields("POD"))
						if GetLong(.Fields("FinisherID")) <> 0 then
							status = Str2MD(.Fields("DeliveryDate"))
						else
							status = "<font color=red>��</font>"
						end if
%>
		  <TR align=center style="cursor:hand;" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("JobCode")%>');">
			<TD nowrap class=line><%=lngCount%><BR>
			<TD nowrap class=line align=left><%=ShowJobCode(.Fields("JobCode"))%><BR>
			<TD nowrap class=line align=left <%=ShowTitle(ClientRef, 7)%>><%=stringCut(ClientRef, 7)%><BR>
			<TD nowrap class=line <%=ShowTitle(POL, 8)%>><%=stringCut(POL, 8)%><BR>
			<TD nowrap class=line <%=ShowTitle(POD, 8)%>><%=stringCut(POD, 8)%><BR>
			<TD nowrap class=line><%=Str2MD(.Fields("ETAETD"))%><BR>
			<TD nowrap class=line><%=GetEmployName(.Fields("JobOperator"), "F")%><BR>
			<TD nowrap class=line><%=Str2MD(.Fields("SalesDate"))%><BR>
			<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("StandDate"))%><BR>
			<TD nowrap class=line><%=GetEmployName(.Fields("JobSalesman"), "F")%><BR>
			<TD nowrap class=line><%=status%><BR>
<%
						.MoveNext
					End If
				Loop
%>
		</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
		
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>