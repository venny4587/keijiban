<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
		
dim mode
dim myCode
dim myType

	mode = GetLong(request("mode"))
	myCode = GetPost(request("cd"))
	selCode = replace(myCode, "'", "''")
	myType = GetPost(request("type"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	CTM_CD = ""
	if myCode <> "" then
		with Recset	
			StrSql = "SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_ENAME, CTM_ABR, CTM_BELONG, CTM_SALESMNGR, CTM_EXPORT_MNGR, CTM_IMPORT_MNGR FROM CUSTOMER"
			StrSql = StrSql & " WHERE CTM_DELETED = 0 AND CTM_REF <> '' AND (CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "')"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				CTM_CD = GetString(.fields("CTM_CD"))
				CTM_NAME = GetString(.fields("CTM_NAME"))
				CTM_ENAME = GetString(.fields("CTM_ENAME"))
				CTM_ABR = GetString(.fields("CTM_ABR"))
				CTM_REF = GetString(.fields("CTM_REF"))
				CTM_BELONG = GetString(.fields("CTM_BELONG"))
				CTM_SALESMNGR = GetString(.fields("CTM_SALESMNGR"))
				CTM_EXPORT_MNGR = GetString(.fields("CTM_EXPORT_MNGR"))
				CTM_IMPORT_MNGR = GetString(.fields("CTM_IMPORT_MNGR"))
				.movenext
				if not .eof then CTM_CD = ""
			end if
			.close
			
			StrSql = "SELECT CTM_NACCS_CD, CTM_ETC_CODE, CTM_ETC_DATA FROM CUSTOMER WHERE CTM_CD = '" & CTM_CD & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				CTM_NACCS_CD = GetString(.fields("CTM_NACCS_CD"))
				CTM_ETC_CODE = GetString(.fields("CTM_ETC_CODE"))
				CTM_ETC_DATA = GetString(.fields("CTM_ETC_DATA"))
			end if 
			.close
		end with
	end if

	if CTM_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
<%if mode = 0 then %>
	window.opener.frmInput.JobClient.value = "<%=CTM_CD%>";
	window.opener.frmInput.Client.value = "<%=CTM_REF%>";
	if (window.opener.frmInput.EName != null) window.opener.frmInput.EName.value = "<%=CTM_ENAME%>";
	if (window.opener.frmInput.AName != null) window.opener.frmInput.AName.value = "<%=CTM_ABR%>";
	if (window.opener.frmInput.JName != null) window.opener.frmInput.JName.value = "<%=CTM_NAME%>";
	if (window.opener.frmInput.JobManager != null) window.opener.frmInput.JobManager.value = "<%=CTM_SALESMNGR%>";
	if (window.opener.frmInput.JobExport != null) window.opener.frmInput.JobExport.value = "<%=CTM_EXPORT_MNGR%>";
	if (window.opener.frmInput.JobImport != null) window.opener.frmInput.JobImport.value = "<%=CTM_IMPORT_MNGR%>";
	if (window.opener.frmInput.JobBelong != null) {
		  var obj = window.opener.frmInput.JobBelong;
		  for (var i=0;i<obj.options.length;i++){
		    if (obj.options[i].value=='<%=CTM_BELONG%>') obj.options[i].selected = true;
		  }
	};
	if (window.opener.frmInput.Shipper != null) window.opener.frmInput.Shipper.focus();				//�Ɩ��o�^
<%end if %>
	if (window.opener.frmInput.JobShipper != null) window.opener.frmInput.JobShipper.value = "<%=CTM_CD%>";
	if (window.opener.frmInput.Shipper != null) window.opener.frmInput.Shipper.value = "<%=CTM_REF%>";
	if (window.opener.frmInput.ShipperName != null) window.opener.frmInput.ShipperName.value = "<%=CTM_ENAME%>";
	if (window.opener.frmInput.btnCreate != null) window.opener.frmInput.btnCreate.focus();			//�Ɩ��o�^	
<%if mode = 1 then %>
	if (window.opener.frmInput.CTM_NACCS_CD != null) window.opener.frmInput.CTM_NACCS_CD.value = "<%=CTM_NACCS_CD%>";
	if (window.opener.frmInput.CTM_ETC_CODE != null) window.opener.frmInput.CTM_ETC_CODE.value = "<%=CTM_ETC_CODE%>";
	if (window.opener.frmInput.CTM_ETC_DATA != null) window.opener.frmInput.CTM_ETC_DATA.value = "<%=CTM_ETC_DATA%>";
<%end if %>
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�׎匟��</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "ClientSearch.asp?mode=<%=mode%>&cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("�׎�R�[�h�܂��͉׎喼�̈ꕔ����͂��Ă��������B")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="ClientSearch.asp" NAME=frmInput>
		<input type=hidden name="mode" value="<%=mode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD width=80>�׎匟�� :</TD>
				<TD nowrap><input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=20 onkeydown="ResetEnter()"></TD>
				<TD width=80 align=right><INPUT TYPE=button style="cursor:hand; width:60; height:25" VALUE="����" onclick="DoSearch()"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then
			With Recset
				'StrSql = "SELECT COUNT(CTM_CD) AS CTM_CNT FROM CUSTOMER WHERE CTM_CLIENT = 1 AND ("
				StrSql = "SELECT COUNT(CTM_CD) AS CTM_CNT FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_REF <> '' AND  ("
				StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF LIKE '" & selCode & "%' OR CTM_ABR = '" & selCode & "'"
				StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
				if UserShop <> gsCorpInit then StrSql = StrSql & " AND CTM_BELONG = '" & UserShop & "'"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if GetLong(.fields("CTM_CNT")) = 0 then
					response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
				elseif GetLong(.fields("CTM_CNT")) > 30 then
					response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
				else
					.close
					
					'StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_ABR, CTM_NAME FROM CUSTOMER WHERE CTM_CLIENT = 1 AND ("
					StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_ABR, CTM_NAME FROM CUSTOMER WHERE CTM_DELETED = 0 AND ("
					StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF LIKE '" & selCode & "%' OR CTM_ABR = '" & selCode & "'"
					StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
					if UserShop <> gsCorpInit then StrSql = StrSql & " AND CTM_BELONG = '" & UserShop & "'"
					strSQL = strSQL + " ORDER BY CTM_ENAME"
if WebUserID = gsAdmin then response.write StrSql
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>�R�[�h
					<TD nowrap>��������
					<TD nowrap>�p������
					<TD nowrap>�a������
					<TD nowrap>�a������
<%
						myCnt = 0
						myShortCut = ""
						Do Until .EOF	
							myCnt = myCnt + 1		
							myEName = GetString(.Fields("CTM_ENAME"))	
							myJName = GetString(.Fields("CTM_NAME"))		
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("CTM_CD") & "');"
							if myCnt < 10 then myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("CTM_CD") & "');"
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("CTM_CD")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_CD"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_REF"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myEName, 40)%>><%=StringCut(myEName,40)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_ABR"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myJName, 20)%>><%=StringCut(myJName,20)%><BR>
<%							
							.MoveNext
						Loop
					end if				
%>
			</table>
<%
				end if	
				.Close 
			End With
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>