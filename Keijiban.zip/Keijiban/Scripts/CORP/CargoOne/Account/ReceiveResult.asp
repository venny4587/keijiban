<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

	if CheckAccountLevel() < 2 then FIN_BANK_ID = GetDefaultBank()
	
'on error resume next
		
	SearchDate = GetDate(request("SearchDate"))
	if SearchDate = "" then SearchDate = formatDate(date)
	
	myType = GetLong(request("type"))
	SalesManager = GetLong(request("SalesManager"))
	
		
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�����`�[�ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></SCRIPT>
	<SCRIPT language=vbscript>	
		sub SearchDate_OnBlur()
			SearchDate.value = setdate(SearchDate.value)
		end sub
	
		function DoSelect()
			window.location.href = "ReceiveResult.asp?type=<%=myType%>&SearchDate=" & setdate(SearchDate.value)
		end function
		
		function ShowDetail(myNo, myCode)
<%if myType < 2 then%>
			window.parent.search.cbody.location.href = "ReceiveInput.asp?FIN_NO=" & myNo
<%else%>
		dim win
			if myCode <> "" then
				set win = window.open("ReceiveErase0.asp?FIN_NO=" & myNo, myNo, "resizable=1,scrollbars=1,width=960,height=640")
			else
				set win = window.open("ReceiveErase1.asp?FIN_NO=" & myNo, myNo, "resizable=1,scrollbars=1,width=960,height=640")
			end if
			win.focus()
<%end if%>
		end function
		
<%if myType = 2 then%>
		sub SalesManager_OnChange()
		dim myID
			myID = SalesManager.options(SalesManager.SelectedIndex).value
			window.location.href = "ReceiveResult.asp?type=<%=myType%>&SalesManager=" & myID
		end sub
<%end if%>

		sub DoJump()
			window.location.href = "../Customs/ReceiveResult.asp"
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=30 valign=bottom>
	  	  <td nowrap width=40% valign=bottom>��
<%select case myType
case 0:		response.write "�����ꗗ"
case 1:		response.write "�m��ꗗ"
case 2:		response.write "�c�ƔC���ꗗ"
case 3:		response.write "�����ꗗ"
end select%>&nbsp;
	  	  <td nowrap width=60%>
<%if myType <> 2 then
	  	  	select case myType 
	  	  	case 0:		response.write "�쐬��"
	  	  	case 1:		response.write "�m���"
	  	  	case 3:		response.write "������"
	  	  	end select%>
			<input class=si name="SearchDate" size=10 maxlength=10 value="<%=SearchDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<a href="javascript:DoSelect()"><img src=img/searchs.jpg border=0 alt="����"></a>
<%else%>
			�c�ƒS��&nbsp;<SELECT class=pt9n name="SalesManager" onkeydown="ResetEnter()"><option value=0>�S��<%=ShowEmployList(DepartSales, SalesManager)%></select>
			<%if CheckTopLevel() > 0 then%><img src=img/return.jpg border=0 alt="�c�Ə�����" style="cursor:hand" onmousedown="DoJump()"><%end if%>
<%end if%>
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT FIN_NO, FIN_TYPE, FIN_CLIENT_CD, ClientRef, ClientName, SalesManager, FIN_AMOUNT, FIN_DATE, FIN_SECURITIES, CONFIRM_ID, ERASE_ID, FIN_BATCH, FIN_JOBCODE, FIN_BILLNO"
		strSql = strSql & " FROM TBL_CTM_FIN AS F INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME AS ClientName, CTM_SALESMNGR AS SalesManager FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0 AND SUBSTRING(FIN_NO,3,1) = 'R'"
		if FIN_BANK_ID <> 0 then strSql = strSql & " AND FIN_BANK_ID = " & FIN_BANK_ID
		select case myType
		case 0
			strSql = strSql & " AND CONVERT(VARCHAR(10), FIN_CREATED, 111) = '" & SearchDate & "'"
		case 1
			strSql = strSql & " AND CONFIRM_ID <> 0 AND CONVERT(VARCHAR(10), CONFIRM_DATE, 111) = '" & SearchDate & "'"
		case 2
			strSql = strSql & " AND ERASE_ID = 0 AND FIN_CURRENT = 1"
			if SalesManager <> 0 then strSql = strSql & " AND SalesManager = " & SalesManager 
		case 3
			strSql = strSql & " AND ERASE_ID <> 0 AND CONVERT(VARCHAR(10), ERASE_DATE, 111) = '" & SearchDate & "'"
		end select
		strSql = strSql & " ORDER BY FIN_NO"
if WebUserID = gsAdmin then response.write strSQL
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>�����ԍ�
		<TD class=line nowrap align=center>������
		<TD class=line nowrap align=left>������
		<TD class=line nowrap>�����z
<%if myType = 0 then%>
		<TD class=line nowrap>�m��
<%elseif myType = 2 then%>
		<TD class=line nowrap>�c��
<%else%>
		<TD class=line nowrap>����
<%end if%>
		<TD class=line nowrap>����
<%
			cnt = 0
			ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				FIN_NO = GetString(.Fields("FIN_NO"))
				myCode = GetString(.Fields("FIN_BATCH")) & GetString(.Fields("FIN_JOBCODE")) & GetString(.Fields("FIN_BILLNO"))
				ClientRef = GetString(.Fields("ClientRef"))
				ClientName = GetString(.Fields("ClientName"))
				if myType = 0 then
					if GetLong(.Fields("CONFIRM_ID")) <> 0 then
						status = "<font color=blue>��</font>"
					else
						status = "<font color=red>��</font>"
					end if
				elseif myType = 2 then
					status = GetEmployName(GetSalesManager(GetString(.Fields("FIN_CLIENT_CD"))), "F")
				else
					if GetLong(.Fields("ERASE_ID")) <> 0 then
						status = "<font color=green>��</font>"
					else
						status = "<font color=red>��</font>"
					end if
				end if
%>
				<TR align=center style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
					 onclick="ShowDetail('<%=FIN_NO%>', '<%=myCode%>')">
					<TD nowrap class=line><%=cnt%><BR>
					<TD nowrap class=line align=left><%=ShowVoucherNo(FIN_NO)%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("FIN_DATE"))%><BR>
					<TD nowrap class=line align=left style="cursor:help" title="<%=ClientName%>"><%=StringCut(ClientRef,7)%><BR>
					<TD nowrap class=line align=right><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
					<TD nowrap class=line><%=status%><BR>
					<TD nowrap class=line><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
<%
				ttlAmount = ttlAmount + GetLong(.Fields("FIN_AMOUNT"))
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=2>
					<TD class=line>�� �v
					<TD colspan=2 class=line nowrap><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y�������`�[�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
