<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�o���`�[�����Ɖ���
'----------------------------------------------

myCheck = 1
select case  session("WebUserID")
case 36, 88
    myCheck = 0
end select

'on error resume next
dim FinStr
dim myMode
dim myPageSize
dim lngPageNumber
		
	myPageSize = GetUserPageSize(10)
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Confirmed = 0
		DateTo = formatDate(date)
		if CheckAccountLevel() < 2 then FIN_BANK_ID = GetDefaultBank()
	else
		ClientRef = GetPost(request("ClientRef"))
		JobCode = GetPost(request("JobCode"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		CheckFrom = GetPost(request("CheckFrom"))
		CheckTo = GetPost(request("CheckTo"))
		FIN_NO = GetPost(request("FIN_NO"))
		CheckType = GetPost(request("CheckType"))
		CheckNo = GetPost(request("CheckNo"))
		CostsNo = GetPost(request("CostsNo"))
		BatchNo = GetPost(request("BatchNo"))
		FIN_BANK_ID = GetLong(request("FIN_BANK_ID"))		
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�o���`�[�����Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		function ShowList() 
		dim win
			set win = window.open("ClientSearch.asp?cd=" & frmInput.ClientRef.value,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myNo, myBatch)
		dim win, url
			if myBatch = "" then
				url = "PaymentErase0.asp?FIN_NO=" & myNo
			else
				url = "PaymentErase1.asp?FIN_NO=" & myNo
			end if
			set win = window.open(url,"PaymentErase","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
		
		function DoPrint()
			set win = window.open("PaymentPrint.asp?type=1&print=1&dt=<%=DateFrom%>", "PaymentPrint", "resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
			
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
			
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub CheckFrom_OnBlur()
			frmInput.CheckFrom.value = setdate(frmInput.CheckFrom.value)
		end sub
		sub CheckTo_OnBlur()
			frmInput.CheckTo.value = setdate(frmInput.CheckTo.value)
		end sub	
		sub FIN_NO_OnBlur()
			frmInput.FIN_NO.value = FitPaymentNo(frmInput.FIN_NO.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		sub CostsNo_OnBlur()
			frmInput.CostsNo.value = FitCostsNo(frmInput.CostsNo.value)
		end sub
		sub BatchNo_OnBlur()
			frmInput.BatchNo.value = FitBatchNo(frmInput.BatchNo.value)
		end sub
				
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
			window.parent.parent.result.location.href = "../common/blank.htm"
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="PaymentView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>��s����&nbsp;
<%if myCheck then%>
				<select name="FIN_BANK_ID" class=pt9n onkeydown="ResetEnter()" style="width:240"><%=ShowBankListAll(FIN_BANK_ID)%></select>
<%else%>
				<select name="FIN_BANK_ID" onkeydown="ResetEnter()"><option value="3"><%=GetBankName(3)%></select>
<%end if%>
				����&nbsp;<select name="CheckType" class=pt9n onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowCategoryList("Securities", CheckType, 0)%></select>
				<TD rowspan=3 width=100 align=right>
					<INPUT class=pt9n style="width:80px;height:40px;" TYPE=SUBMIT VALUE="����">	
			<TR><TD nowrap>
				�x����<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList()">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�o����&nbsp;<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				���퇂&nbsp;<input class=si name="CheckNo" value="<%=CheckNo%>" maxlength=20 size=10 onkeydown="ResetEnter()">
			<TR><TD nowrap>
				�o���ԍ�&nbsp;<input class=si name="FIN_NO" value="<%=FIN_NO%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�䒠�ԍ�&nbsp;<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=9 onkeydown="ResetEnter()">					
				�ޯ���&nbsp;<input class=si name="BatchNo" value="<%=BatchNo%>" maxlength=6 size=6 onkeydown="ResetEnter()">
				�x����&nbsp;<input class=si name="CostsNo" value="<%=CostsNo%>" maxlength=10 size=9 onkeydown="ResetEnter()">
<!--
				�T�C�g&nbsp;<input class=si name="CheckFrom" value="<%=CheckFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="CheckTo" value="<%=CheckTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
--->
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if FIN_BANK_ID <> 0 then strSel = strSel & " AND FIN_BANK_ID = " & FIN_BANK_ID
	if ClientRef <> "" then	strSel = strSel & " AND (ClientRef = '" & FitSel(ClientRef) & "' OR FIN_CLIENT_NAME LIKE '% " & FitSel(ClientRef) & "%')"
	if DateFrom <> "" then strSel = strSel & " AND FIN_DATE >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND FIN_DATE <= '" & Date2Str(DateTo) & "'"	
	if CheckType <> "" then strSel = strSel & " AND FIN_SECURITIES = '" & FitSel(CheckType) & "'"
	if CheckNo <> "" then strSel = strSel & " AND FIN_SECURITIES_NO LIKE '%" & FitSel(CheckNo) & "%'"
	if CheckFrom <> "" then strSel = strSel & " AND FIN_SECURITIES_DATE >= '" & Date2Str(CheckFrom) & "'"
	if CheckTo <> "" then strSel = strSel & " AND FIN_SECURITIES_DATE <= '" & Date2Str(CheckTo) & "'"	
	if FIN_NO <> "" then strSel = strSel & " AND FIN_NO = '" & FitSel(FIN_NO) & "'"	
	if CostsNo <> "" then strSel = strSel & " AND FIN_BILLNO LIKE '%" & FitSel(CostsNo) & "%'"	
	if BatchNo <> "" then strSel = strSel & " AND FIN_BATCH LIKE '%" & FitSel(BatchNo) & "%'"	
	if JobCode <> "" then strSel = strSel & " AND FIN_NO IN (SELECT DISTINCT BIZ_FIN_NO FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0 AND BIZ_JOBCODE LIKE '" & FitSel(JobCode) & "')"

	with recset
		myTotalAmount = 0
		strSql = "SELECT SUM(CAST(FIN_AMOUNT AS float)) AS TotalAmount FROM TBL_CTM_FIN AS F INNER JOIN  "
		strSql = strSql & " (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'P' AND FIN_ORIGINAL = 1 AND FIN_DELETED = 0"
		if CheckAccountLevel() < 2 then strSql = strSql & " AND FIN_CURRENT <> 0 AND FIN_REMARKS = '" & UserShop & "'"
		if strSel <> "" then strSQL = strSQL & strSel
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then myTotalAmount = GetDouble(.Fields("TotalAmount"))	
		.Close
		
		strSql = "SELECT FIN_NO, FIN_TYPE, ClientRef, FIN_CLIENT_NAME, FIN_DATE, FIN_AMOUNT, FIN_BATCH, FIN_BILLNO, FIN_SECURITIES, FIN_SECURITIES_NO, ERASE_ID, CONFIRM_ID"
		strSql = strSql & ",FIN_SECURITIES_DATE, FIN_CURRENT FROM TBL_CTM_FIN AS F INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'P' AND FIN_ORIGINAL = 1 AND FIN_DELETED = 0"
		if CheckAccountLevel() < 2 then strSql = strSql & " AND FIN_CURRENT <> 0 AND FIN_REMARKS = '" & UserShop & "'"
		if strSel <> "" then strSQL = strSQL & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY FIN_NO"
		case 1:		strSql = strSql & " ORDER BY FIN_SECURITIES_NO, FIN_NO"
		case 2:		strSql = strSql & " ORDER BY FIN_BATCH, FIN_BILLNO"
		case 3:		strSql = strSql & " ORDER BY ClientRef, FIN_NO"
		case 4:		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
		case 5:		strSql = strSql & " ORDER BY FIN_SECURITIES_DATE, FIN_NO"
		case 6:		strSql = strSql & " ORDER BY ERASE_ID, FIN_DATE, FIN_NO"
		case 7:		strSql = strSql & " ORDER BY CONFIRM_ID, FIN_DATE, FIN_NO"
		case 8:		strSql = strSql & " ORDER BY FIN_AMOUNT, FIN_DATE, FIN_NO"
		end select			
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			.PageSize = myPageSize
			lngPageCount = .PageCount
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * myPageSize					
%>
		<table width=100% class=pt9n>
			<tr>
				<td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%></td>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:30px;height:20px" value="GO">
				<%end if%>
				</td>
			</TR>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=4 align=center>
			<colgroup span=3 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=3 align=center>
		  <TR align=center height=24 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�o���ԍ�
			<TD class=line nowrap>����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">���퇂
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�x���ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�o����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">�o���z
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�T�C�g
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">�m��
<%	
			Do Until .EOF
				lngCount = lngCount + 1			
				If lngCount > lngPageNumber * myPageSize Then
					Exit Do
				Else
					FIN_NO = GetString(.Fields("FIN_NO"))	
					FIN_BATCH = GetString(.Fields("FIN_BATCH"))
					FIN_BILLNO = GetString(.Fields("FIN_BILLNO")) & FIN_BATCH
%>
		<TR height=30 style="cursor:hand;<%=myColor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
			 onclick="ShowDetail('<%=FIN_NO%>', '<%=FIN_BATCH%>')">
			<TD class=line><%=lngCount%><BR>
			<TD class=line nowrap><%if GetLong(.fields("FIN_CURRENT")) then%><font color=blue>��</font><%else%>��<%end if%><BR>
			<TD class=line nowrap><%=ShowVoucherNo(FIN_NO)%><BR>
			<TD class=line nowrap><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
			<TD class=line nowrap><%=GetString(.Fields("FIN_SECURITIES_NO"))%><BR>
			<TD class=line nowrap><%=ShowVoucherNo(FIN_BILLNO)%><BR>
			<TD class=line nowrap title="<%=GetString(.Fields("FIN_CLIENT_NAME"))%>"><%=StringCut(GetString(.Fields("ClientRef")),7)%><BR>
			<TD class=line nowrap style="color:blue"><%=Str2MD(.Fields("FIN_Date"))%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
			<TD class=line nowrap style="color:blue"><%=Str2MD(.Fields("FIN_SECURITIES_DATE"))%><BR>
			<TD class=line nowrap><%=GetEmployName(GetLong(.Fields("ERASE_ID")), "F")%><BR>
			<TD class=line nowrap><%=GetEmployName(GetLong(.Fields("CONFIRM_ID")), "F")%><BR>
<%
				end if
				.movenext
			loop
%>
			<TR height=30>
				<TD colspan=6 align=left><%if lngCount > lngPageNumber * myPageSize then response.write "<font color=red>��������܂�...</font>"%>
				<TD class=line align=right>�� �v
				<TD class=line align=right colspan=2><%=formatnumber(myTotalAmount, 0, true)%><BR>
				<TD colspan=3 align=left><%if DateFrom <> "" and DateFrom = DateTo then%>
					<input type=button style="width:80px;height:30px;" name=btnPrint value="���" onclick="DoPrint()"><%end if%>
		</TABLE>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%

function ShowBankListAll(myDft)
dim mySql
dim myRec
dim myCon
dim myBank
dim buf
	buf = "<option value=0>���ׂ�"
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT BANK_ID, BANK_CD, BANK_NAME, BANK_BRANCH, BANK_ACCOUNT_NO, BANK_ACCOUNT_TYPE"
		mySql = mySql & " FROM MST_BANK WHERE BANK_DELETED = 0" 
		if CheckAccountLevel() < 2 then mySql = mySql & " AND (BANK_DIVISION = 0 or BANK_DIVISION = " & finPayment & ")"
		mySql = mySql & " ORDER BY BANK_DIVISION, BANK_CD"
'response.write mySql
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		do while not .eof		
			myBank = GetString(.fields("BANK_NAME")) & " " & GetString(.fields("BANK_BRANCH"))
			myBank = myBank & " " & left(GetString(.fields("BANK_ACCOUNT_TYPE")), 2)
			myBank = myBank & " "  & GetString(.fields("BANK_ACCOUNT_NO"))
			buf = buf & "<option value=" & chr(34) & GetLong(.fields("BANK_ID")) & chr(34)
			if GetLong(.fields("BANK_ID")) = myDft then buf = buf & " selected"
			buf = buf & ">" & myBank
			.movenext
		loop
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
	
	ShowBankListAll = buf	
end function
%>