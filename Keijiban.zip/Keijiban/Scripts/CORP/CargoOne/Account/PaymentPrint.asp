<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
		
dim BookDate
dim BookCnt
dim BookType()
dim BookAmount()

	BookDate = GetPost(request("dt"))

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	with Recset
		strSql = "SELECT FIN_SECURITIES AS TYP, Sum(FIN_AMOUNT) AS TTL FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
		strSql = strSql & " AND FIN_TYPE = " & acntBank & " AND FIN_DATE = '" & Date2Str(BookDate) & "'"
		strSQL = strSQL & " AND ERASE_ID = " & WebUserID
		strSQL = strSQL & " GROUP BY FIN_SECURITIES"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		BookCnt = 0
		do while not .eof
			BookCnt = BookCnt + 1
			redim preserve BookType(BookCnt)
			redim preserve BookAmount(BookCnt)
			BookType(BookCnt) = GetString(.fields("TYP"))
			BookAmount(BookCnt) = GetLong(.fields("TTL"))
			.movenext
		loop
		.close
	end with
%>
<HTML>
<HEAD>
	<TITLE>�o�����ו\��</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<style>
		TD.line { BORDER-TOP: gray 1px solid; }
		TD.bline { BORDER-top: rgb(0,0,0) 1px groove; BORDER-bottom: rgb(0,0,0) 1px groove; BORDER-left: rgb(0,0,0) 1px groove; BORDER-right: rgb(0,0,0) 1px groove; }

		.pts { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptm { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptl { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 16pt; LINE-HEIGHT: 1.2em; color: black; }
		.ptx { FONT-FAMILY: �l�r ����; FONT-SIZE: 20pt; LINE-HEIGHT: 1.2em; color: black; }
	</style>
	<SCRIPT language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 onkeydown="DoShortCut()" class=pts <%=gsBodyControl%>>
<center>
<!--�w�b�_-->
  <table Border=0 Cellspacing=0 CellPadding=0 class=pts>
  <tr><td valign=top height=880>
	<table width=660 Border=0 Cellspacing=0 CellPadding=0 class=ptm>
	  <TR height=40>
	  	<td width=180><hr size=1 color=black>
	  	<td class=ptx nowrap align=center>�o �� �� �� �� ��
	  	<td width=180><hr size=1 color=black>
	</table>
	<table width=660 cellspacing="10" cellpadding="10">
	  <tr align=center height=80>
		<td width=420 class=bline>
			<table Border=0 Cellspacing=0 CellPadding=0 class=ptm>
<%for i = 1 to BookCnt%>
		  	  <tr height=24>
		  	  	<td nowrap width=80><%if i = 1 then response.write "�o���v"%>
		  	  	<td nowrap width=80><b><%=BookType(i)%></b>
		  	  	<td nowrap width=160 align=right><b>\<%=formatnumber(BookAmount(i), 0, true)%></b>
		  	  	<td nowrap width=100>
<%next%>
		  	</table>
		<td width=220 class=bline>
			<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=ptm>
		  	  <tr height=24><td nowrap>�o����<td nowrap><b><%=BookDate%></b>
		  	  <tr height=3><td nowrap><img src=img/spacer.gif>
		  	  <tr height=24><td nowrap>�S����<td nowrap><b><%=GetEmployName(WebUserID, "F")%></b>
		  	</table>
	</table>	
	<TABLE width=660 Cellspacing=0 CellPadding=0 class=pts>
	  <tr><td>
		<TABLE width=660 Cellspacing=0 CellPadding=3 class=pts>
		  <colgroup span=3 align=left>
		  <colgroup align=center>
		  <colgroup align=right>
		  <colgroup align=center>
		  <TR class=pt9 valign=bottom>
			<TD width=30>��
			<TD width=80 nowrap>�o����
			<TD width=250 nowrap>�o����
			<TD width=80 nowrap>Job ��
			<TD width=80 nowrap align=right>�o�����z
			<TD width=60 nowrap>����
			<TD width=60 nowrap>���퇂
<%
	with Recset
		cnt = 0
		ttlAmount = 0
		strSql = "SELECT FIN_NO, FIN_CLIENT_NAME, FIN_AMOUNT, FIN_SECURITIES, FIN_JOBCODE, FIN_SECURITIES_NO"
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_TYPE = " & acntBank
		strSql = strSql & " AND FIN_DATE = '" & Date2Str(BookDate) & "' AND ERASE_ID = " & WebUserID
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .eof
			cnt = cnt + 1
			JobCodes = GetString(.fields("FIN_JOBCODE"))
%>
			<TR valign=top>
				<TD class=line><%=cnt%>
				<TD class=line nowrap><%=GetString(.Fields("FIN_NO"))%><BR>
				<TD class=line><%=GetString(.Fields("FIN_CLIENT_NAME"))%><BR>
				<TD class=line nowrap><%=JobCodes%><BR>
				<TD class=line nowrap>\<%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
				<TD class=line nowrap><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
				<TD class=line nowrap><%=GetString(.Fields("FIN_SECURITIES_NO"))%><BR>
<%
			ttlAmount = ttlAmount + GetLong(.Fields("FIN_AMOUNT"))
			.movenext
		loop
		if cnt > 1 then
%>
				<TR valign=bottom>
					<TD class=line colspan=4 align=right>���v
					<TD class=line><b>\<%=formatnumber(ttlAmount, 0, true)%><b>
					<TD class=line colspan=2><br>
<%
		end if
	end with
%>
	  	  <TR><td colspan=7><hr color=black size=1>
		</TABLE>
	</TABLE>
  </table>
</BODY>
</HTML>
<%
	set recset = nothing
	CloseDB Conn
%>
