<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�c�Ɠ����`�[�ۑ�����
'
'	mode:	1 -- �c�ƔC��
'			2 -- �c�Ə���
'			3 -- �o���m�F
'			4 -- ��������
'
'	mode	2			3
'			�c�Ə���	�o���m�F
'	�`�[	�|�|		Finish
'	�Ɩ�	Confirm		Erase
'	����	�|�|		Erase
'----------------------------------------------

'on error resume next
dim myNos
dim myBatchNos
dim myChargeNos

	FIN_NO = GetPost(request("FIN_NO"))	
	ChargeNos = GetPost(request("ChargeNos")) 
	ChargeTotal = GetPost(request("ChargeTotal"))
	if instr(ChargeNos, ",") = 0 then
		if left(ChargeNos, 1) = gsBatchPrint then			'�ޯ��ԍ�
			EraseType = 1
			FIN_BATCH = ChargeNos
		else												'�����ԍ�
			EraseType = 2
			FIN_BILLNO = ChargeNos
		end if
	else													'����
		EraseType = 3
		myNos = split(ChargeNos, ",")
		for i = 0 to ubound(myNos)
			if left(myNos(i), 1) = gsBatchPrint then
				myBatchNos = myBatchNos & ",'" & trim(myNos(i)) & "'"		'�ޯ�
			else
				myChargeNos = myChargeNos & ",'" & trim(myNos(i)) & "'"		'����
			end if
		next
		'��ϐ���
		if myBatchNos <> "" then myBatchNos = mid(myBatchNos, 2)	
		if myChargeNos <> "" then myChargeNos = mid(myChargeNos, 2)	
	end if 

	OpenSQL Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
		
	msg = ""
	mode = GetLong(request("mode"))
	if CheckFinanceClosed(Conn, FIN_NO) then
	
		msg = "�Y�������`�[�͊��ɒ��߂���܂����B"
	
	elseif mode < 4 and CheckFinanceErased(Conn, FIN_NO) then	'�������݉���
			
		msg = "�Y�������`�[�͊��ɏ�������܂����B"

	else
					
		'���̓`�F�b�N
		FIN_AMOUNT = GetLong(request("FIN_AMOUNT"))		'�����z
		ChargeAmount = GetLong(request("ChargeAmount"))	'�������z
		
		FromReceive = GetLong(request("FromReceive"))	'�a������
		OverReceive = GetLong(request("OverReceive"))	'�a�����
			
		MassLoss = GetLong(request("MassLoss"))			'�G����
		MassProfit = GetLong(request("MassProfit"))		'�G�v��
		
		FromDraft = GetLong(request("FromDraft"))		'��`����
		OverDraft = GetLong(request("OverDraft"))		'��`��
		
		BankPostage = GetLong(request("BankPostage"))	'�ʐM��

		DebitAmount = FIN_AMOUNT + FromReceive + MassLoss + FromDraft
		CreditAmount = ChargeAmount + OverReceive + MassProfit + OverDraft
		DebitAmount = DebitAmount + BankPostage

		if mode <> 1 and  DebitAmount <> CreditAmount then
		
			msg = "�ؕ����z�͑ݕ����z�ƈ�v�ł͂���܂���B"
		
		elseif BankPostage > gsMaxPostage then
		
			msg = "���͂����ʐM��͑������ł��B"
			
		else
					
			if ChargeAmount <> 0 then

				'�d����z�K���`�F�b�N
				select case EraseType
				case 1						'�o�b�`�ԍ�
			
					strSql = "SELECT SUM(BIZ_AMOUNT + BIZ_TAX) AS TTL FROM TBL_CTM_BIZ WHERE BIZ_NO IN "
					strSql = strSql & " (SELECT ChargeNo FROM TBL_CTM_CHARGE WHERE Deleted = 0"									'���폜
					strSql = strSql & " AND ConfirmerID <> 0 AND ChargePrinted <> 0 AND ChargeBatch = '" & FIN_BATCH & "')"		'�m��ρ@�����
					
				case 2						'�����ԍ�
					
					strSql = "SELECT SUM(BIZ_AMOUNT + BIZ_TAX) AS TTL FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0 AND BIZ_NO = '" & FIN_BILLNO & "'"
					
				case 3						'����
				
					mySel = ""
					if myBatchNos <> "" then mySel = " OR BIZ_BATCH IN (" & myBatchNos & ")" 
					if myChargeNos <> "" then mySel = mySel & " OR BIZ_NO IN (" & myChargeNos & ")" 
					strSql = "SELECT SUM(BIZ_AMOUNT + BIZ_TAX) AS TTL FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0 AND "
					strSql = strSql & " (" & mid(mySel, 4) & ")"
					
				end select
			
				BizAmount = 0		
				with Recset
					.Open strSql, Conn, adOpenKeyset, adLockReadOnly
					if not .eof then BizAmount = GetLong(.Fields("TTL"))
					.close
				end with
				
				if BizAmount <> ChargeAmount then
				
if WebUserID = 1 then 
	response.write "ChargeAmount=" & ChargeAmount
	response.write "BizAmount=" & BizAmount
	response.write "strSql=" & strSql
	response.end
end if
					
					msg = "�������̋��z:(" & ChargeAmount & ")�͐����d��:(" & BizAmount & ")�ƈ�v���܂���B�������̊m�����蒼���Ă��������B"	
					
					response.write 	"<table border=1><tr><td>�`�[��<td>�Ŕ����z<td>�����<td>���v���z<td>�d����z"
					strSql = "SELECT ChargeNo, ChargeAmount, ChargeTax, TTL from TBL_CTM_CHARGE AS C INNER JOIN ("
					strSql = strSql & "SELECT BIZ_NO, SUM(BIZ_AMOUNT + BIZ_TAX) AS TTL FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0"
					select case EraseType
					case 1						'�o�b�`�ԍ�
						strSql = strSql & " AND BIZ_BATCH = '" & FIN_BATCH & "'"
					case 2						'�����ԍ�
						strSql = strSql & " AND BIZ_NO = '" & FIN_BILLNO & "'"
					case 3						'����
						strSql = strSql & " (" & mid(mySel, 4) & ")"
					end select
					strSql = strSql & " GROUP BY BIZ_NO) AS B ON C.ChargeNo = B.BIZ_NO"
					strSql = strSql & " WHERE ChargeAmount + ChargeTax <> TTL ORDER BY ChargeNo"
	
					with Recset
						.Open strSql, Conn, adOpenKeyset, adLockReadOnly
						do while not .eof
							response.write 	"<tr align=right><td align=left><font color=red>" & .fields("ChargeNo") & "</font><td>" & .fields("ChargeAmount")
							response.write 	"<td>" & .fields("ChargeTax") & "<td>" & .fields("ChargeAmount") + .fields("ChargeTax") & "<td>" & .fields("TTL") 
							.movenext
						loop
						.close
					end with
					response.write "</table>"
				end if
				
			end if			'ChargeAmount <> 0
			
		end if				'DebitAmount <> CreditAmount / BankPostage > gsMaxPostage
	
	end if			'StatusCheck	
	
	'�����폜
	if msg = "" then
		 
		Conn.BeginTrans		
			
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		with Recset	
			strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_ORIGINAL <> 0 AND FIN_NO = '" & FIN_NO & "'"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if not .eof then
				select case mode
				case 1, 2			'�c�ƔC��/�c�Ɗm��
					.fields("FIN_CURRENT") = mode
					if mode = 1 then msg = "�Y�������`�[�͉c�Ƃɓ]������܂����I"	
				case else
					.fields("FIN_CURRENT") = 0	
				end select
				.fields("FIN_MEMO") = GetPost(request("FIN_MEMO"))
				.fields("FIN_REMARKS") = GetPost(request("FIN_REMARKS"))
				
				.fields("FIN_UPDATER") = WebUserID
				.fields("FIN_UPDATED") = now
				.update
							
			else
				msg = "�Y�������`�[�ԍ��͌�����܂���ł����B"
			end if
			.close
		end with
		
		if msg = "" then
			'�ޯ����������݉���
			strSql = "UPDATE TBL_CTM_BATCH SET FinishDate = NULL, FinisherID = 0 WHERE BatchNo IN "
			strSql = strSql & "(SELECT ERASE_BATCH FROM TBL_CTM_ERASE WHERE ERASE_FIN_NO = '" & FIN_NO & "')"
			Conn.execute strSql
			
			'�������������݉���(�ޯ�)
			strSql = "UPDATE TBL_CTM_CHARGE SET FinishDate = NULL, FinisherID = 0 WHERE ChargeBatch <> '' AND ChargeBatch IN "
			strSql = strSql & "(SELECT ERASE_BATCH FROM TBL_CTM_ERASE WHERE ERASE_BATCH <> '' AND ERASE_FIN_NO = '" & FIN_NO & "')"
			Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
			
			'�������������݉���(�P�[)
			strSql = "UPDATE TBL_CTM_CHARGE SET FinishDate = NULL, FinisherID = 0 WHERE ChargeNo IN "
			strSql = strSql & "(SELECT ERASE_BIZ_NO FROM TBL_CTM_ERASE WHERE ERASE_BIZ_NO <> '' AND ERASE_FIN_NO = '" & FIN_NO & "')"
			Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
		
			'�����d��������݉���(�ޯ�)
			strSql = "UPDATE TBL_CTM_BIZ SET CONFIRM_DATE = NULL, CONFIRM_ID = 0, ERASE_DATE = NULL, ERASE_ID = 0, BIZ_FIN_NO = '' WHERE BIZ_BATCH <> '' AND BIZ_BATCH IN "
			strSql = strSql & "(SELECT ERASE_BATCH FROM TBL_CTM_ERASE WHERE ERASE_BATCH <> '' AND ERASE_FIN_NO = '" & FIN_NO & "')"
			Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
			
			'�����d��������݉���(�P�[)
			strSql = "UPDATE TBL_CTM_BIZ SET CONFIRM_DATE = NULL, CONFIRM_ID = 0, ERASE_DATE = NULL, ERASE_ID = 0, BIZ_FIN_NO = '' WHERE BIZ_NO IN "
			strSql = strSql & "(SELECT ERASE_BIZ_NO FROM TBL_CTM_ERASE WHERE ERASE_BIZ_NO <> '' AND ERASE_FIN_NO = '" & FIN_NO & "')"
			Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
		
			'�������ݓ���폜
			strSql = "DELETE FROM TBL_CTM_ERASE WHERE ERASE_FIN_NO = '" & FIN_NO & "'"
			Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
		
			'�������ݎd��폜
			strSql = "DELETE FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 0 AND FIN_NO = '" & FIN_NO & "'"
			Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
							
			'�o���d��������݉���		
			strSql = "UPDATE TBL_CTM_FIN SET ERASE_DATE = NULL, ERASE_ID = 0 WHERE FIN_NO = '" & FIN_NO & "'"
			Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
		
			if mode = 4 then msg = "�Y�������`�[�͏������݉�������܂����I"
	
		end if
	
		'�X�V�ۑ�
		if msg = "" then
			
			'�Ɩ��d�󏈗�
			select case EraseType
			case 1						'�o�b�`�ԍ�
			
				'�����d���������
				strSql = "UPDATE TBL_CTM_BIZ SET CONFIRM_DATE = GETDATE(), CONFIRM_ID = " & WebUserID
				strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_BATCH = '" & FIN_BATCH & "'"
				Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
			
				'�������ݓ���쐬
				strSql = "INSERT INTO TBL_CTM_ERASE (ERASE_FIN_NO, ERASE_BATCH, ERASE_DATE, ERASE_AMOUNT, ERASE_OPR) "
				strSql = strSql & " VALUES ('" & FIN_NO & "','" & FIN_BATCH & "', GETDATE()," & ChargeAmount & "," & WebUserID & ")"
				Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
	
			case 2						'�����ԍ�
						
				'�����d���������
				strSql = "UPDATE TBL_CTM_BIZ SET CONFIRM_DATE = GETDATE(), CONFIRM_ID = " & WebUserID
				strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_NO = '" & FIN_BILLNO & "'"
				Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
				
				'�������ݓ���쐬
				strSql = "INSERT INTO TBL_CTM_ERASE (ERASE_FIN_NO, ERASE_BIZ_NO, ERASE_DATE, ERASE_AMOUNT, ERASE_OPR) "
				strSql = strSql & " VALUES ('" & FIN_NO & "','" & FIN_BILLNO & "', GETDATE()," & ChargeAmount & "," & WebUserID & ")"
				Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
			
			case 3						'����
			
				if myBatchNos <> "" then
													
					'�����d���������
					strSql = "UPDATE TBL_CTM_BIZ SET CONFIRM_DATE = GETDATE(), CONFIRM_ID = " & WebUserID
					strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_BATCH IN (" & myBatchNos & ")"
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
				
				end if
				
				if myChargeNos <> "" then 
								
					'�����d���������
					strSql = "UPDATE TBL_CTM_BIZ SET CONFIRM_DATE = GETDATE(), CONFIRM_ID = " & WebUserID
					strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_NO IN (" & myChargeNos & ")"
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
				end if
				
				'�������ݓ���쐬
				ChargeNo = split(ChargeNos, ",")
				ChargeAmnt = split(ChargeTotal, ",")
				for i = 0 to ubound(ChargeNo)
					if left(ChargeNo(i), 1) = gsBatchPrint then
						strSql = "INSERT INTO TBL_CTM_ERASE (ERASE_FIN_NO, ERASE_BATCH, ERASE_DATE, ERASE_AMOUNT, ERASE_OPR) "
						strSql = strSql & " VALUES ('" & FIN_NO & "','" & ChargeNo(i) & "', GETDATE()," & ChargeAmnt(i) & "," & WebUserID & ")"
					else
						strSql = "INSERT INTO TBL_CTM_ERASE (ERASE_FIN_NO, ERASE_BIZ_NO, ERASE_DATE, ERASE_AMOUNT, ERASE_OPR) "
						strSql = strSql & " VALUES ('" & FIN_NO & "','" & ChargeNo(i) & "', GETDATE()," & ChargeAmnt(i) & "," & WebUserID & ")"
					end if
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
				next			
			end select
			
			'�Ɩ��d�󍇌v�擾
			PreSales = 0:	PreSalesTax = 0:	StandReceive = 0:	StandTax = 0
			select case EraseType
			case 1						'�o�b�`�ԍ�
				strSql = "SELECT BIZ_TYPE, SUM(BIZ_AMOUNT) AS TotalAmount, SUM(BIZ_TAX) AS TotalTax FROM TBL_CTM_BIZ"
				strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_BATCH = '" & FIN_BATCH & "'"
				strSql = strSql & " GROUP BY BIZ_TYPE"
				Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not Recset.eof 
					select case GetLong(Recset.fields("BIZ_TYPE"))
					case bizStandR
						StandReceive = GetLong(Recset.fields("TotalAmount"))
						StandTax = GetLong(Recset.fields("TotalTax"))
					case bizSales
						PreSales = GetLong(Recset.fields("TotalAmount"))
						PreSalesTax = GetLong(Recset.fields("TotalTax"))
					end select
					Recset.movenext
				loop
				Recset.Close
			case 2						'�����ԍ�
				strSql = "SELECT BIZ_TYPE, SUM(BIZ_AMOUNT) AS TotalAmount, SUM(BIZ_TAX) AS TotalTax FROM TBL_CTM_BIZ"
				strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_NO = '" & FIN_BILLNO & "'"
				strSql = strSql & " GROUP BY BIZ_TYPE"
				Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not Recset.eof 
					select case GetLong(Recset.fields("BIZ_TYPE"))
					case bizStandR
						StandReceive = GetLong(Recset.fields("TotalAmount"))
						StandTax = GetLong(Recset.fields("TotalTax"))
					case bizSales
						PreSales = GetLong(Recset.fields("TotalAmount"))
						PreSalesTax = GetLong(Recset.fields("TotalTax"))
					end select
					Recset.movenext
				loop
				Recset.Close
			case 3						'����
				if myBatchNos <> "" then
					strSql = "SELECT BIZ_TYPE, SUM(BIZ_AMOUNT) AS TotalAmount, SUM(BIZ_TAX) AS TotalTax FROM TBL_CTM_BIZ"
					strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_BATCH IN (" & myBatchNos & ")"
					strSql = strSql & " GROUP BY BIZ_TYPE"
					Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
					do while not Recset.eof 
						select case GetLong(Recset.fields("BIZ_TYPE"))
						case bizStandR
							StandReceive = GetLong(Recset.fields("TotalAmount"))
							StandTax = GetLong(Recset.fields("TotalTax"))
						case bizSales
							PreSales = GetLong(Recset.fields("TotalAmount"))
							PreSalesTax = GetLong(Recset.fields("TotalTax"))
						end select
						Recset.movenext
					loop
					Recset.Close
				end if
				if myChargeNos <> "" then 
					strSql = "SELECT BIZ_TYPE, SUM(BIZ_AMOUNT) AS TotalAmount, SUM(BIZ_TAX) AS TotalTax FROM TBL_CTM_BIZ"
					strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_NO IN (" & myChargeNos & ")"
					strSql = strSql & " GROUP BY BIZ_TYPE"
					Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
					do while not Recset.eof 
						select case GetLong(Recset.fields("BIZ_TYPE"))
						case bizStandR
							StandReceive = StandReceive + GetLong(Recset.fields("TotalAmount"))
							StandTax = StandTax + GetLong(Recset.fields("TotalTax"))
						case bizSales
							PreSales = PreSales + GetLong(Recset.fields("TotalAmount"))
							PreSalesTax = PreSalesTax + GetLong(Recset.fields("TotalTax"))
						end select
						Recset.movenext
					loop
					Recset.Close
				end if
			end select
			
			'�����d�󏈗�
			with Recset
				strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_NO = '" & FIN_NO & "'"
				.Open strSql, Conn, adOpenStatic, adLockReadOnly
				if not .eof then
					'���֔��|�֎d��
					if StandReceive <> 0 then call Biz2Fin(finReceive, Conn, Recset, acntStandReceive, StandReceive, StandTax)	
					'���|���֎d��
					if PreSales <> 0 then call Biz2Fin(finReceive, Conn, Recset, acntPreSales, PreSales, PreSalesTax)
					'�a����֎d��
					if OverReceive <> 0 then call Erase2Fin(finReceive, Conn, Recset, acntOverReceive, OverReceive)
					'�a�������d��
					if FromReceive <> 0 then call Erase2Fin(finReceive, Conn, Recset, acntOverReceive, 0 - FromReceive)
					'�G���֎d��
					if MassLoss <> 0 then call Erase2Fin(finReceive, Conn, Recset, acntMassLoss, MassLoss)
					'�G�v�֎d��
					if MassProfit <> 0 then call Erase2Fin(finReceive, Conn, Recset, acntMassProfit, MassProfit)
					'��`�֎d��
					if OverDraft <> 0 then call Erase2Fin(finReceive, Conn, Recset, acntOverDraft, OverDraft)
					'��`����d��
					if FromDraft <> 0 then call Erase2Fin(finReceive, Conn, Recset, acntFromDraft, FromDraft)
					'�ʐM��d��
					if BankPostage <> 0 then call Erase2Fin(finReceive, Conn, Recset, acntPostage, BankPostage)
				end if
				.close
			end with
													
			if mode = 3 then	'�o���������ݎ��s�E�c�Ə������݊m�F		
			
			
				'�Ɩ��d�󏈗�
				select case EraseType
				case 1						'�o�b�`�ԍ�
				
					'�o�b�`��������
					strSql = "UPDATE TBL_CTM_BATCH SET FinishDate = GETDATE(), FinisherID = " & WebUserID
					strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND BatchNo = '" & FIN_BATCH & "'"
					Conn.execute strSql
					
					'��������������
					strSql = "UPDATE TBL_CTM_CHARGE SET FinishDate = GETDATE(), FinisherID = " & WebUserID
					strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ChargeBatch = '" & FIN_BATCH & "'"
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
			
					'�����d���������
					strSql = "UPDATE TBL_CTM_BIZ SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID & ", BIZ_FIN_NO = '" & FIN_NO & "'"
					strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_BATCH = '" & FIN_BATCH & "'"
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
					
				case 2						'�����ԍ�
				
					'��������������
					strSql = "UPDATE TBL_CTM_CHARGE SET FinishDate = GETDATE(), FinisherID = " & WebUserID
					strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ChargeNo = '" & FIN_BILLNO & "'"
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
				
					'�����d���������
					strSql = "UPDATE TBL_CTM_BIZ SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID & ", BIZ_FIN_NO = '" & FIN_NO & "'"
					strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_NO = '" & FIN_BILLNO & "'"
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
				
					'�������ݓ���쐬
					strSql = "INSERT INTO TBL_CTM_ERASE (ERASE_FIN_NO, ERASE_BIZ_NO, ERASE_DATE, ERASE_AMOUNT, ERASE_OPR) "
					strSql = strSql & " VALUES ('" & FIN_NO & "','" & FIN_BILLNO & "', GETDATE()," & ChargeAmount & "," & WebUserID & ")"
					Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
			
				case 3						'���̑�
			
					if myBatchNos <> "" then
										
						'�o�b�`��������
						strSql = "UPDATE TBL_CTM_BATCH SET FinishDate = GETDATE(), FinisherID = " & WebUserID
						strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND BatchNo IN (" & myBatchNos & ")"
						Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
					
						'��������������
						strSql = "UPDATE TBL_CTM_CHARGE SET FinishDate = GETDATE(), FinisherID = " & WebUserID
						strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ChargeBatch IN (" & myBatchNos & ")"
						Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
					
						'�����d���������
						strSql = "UPDATE TBL_CTM_BIZ SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID & ", BIZ_FIN_NO = '" & FIN_NO & "'"
						strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_BATCH IN (" & myBatchNos & ")"
						Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
				
					end if
				
					if myChargeNos <> "" then 
					
						'��������������
						strSql = "UPDATE TBL_CTM_CHARGE SET FinishDate = GETDATE(), FinisherID = " & WebUserID
						strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ChargeNo IN (" & myChargeNos & ")"
						Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
					
						'�����d���������
						strSql = "UPDATE TBL_CTM_BIZ SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID & ", BIZ_FIN_NO = '" & FIN_NO & "'"
						strSql = strSql & " WHERE BIZ_DELETED = 0 AND ERASE_ID = 0 AND BIZ_NO IN (" & myChargeNos & ")"
						Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
					end if
					
				end select
				
				'�����d���������
				strSql = "UPDATE TBL_CTM_FIN SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID
				strSql = strSql & " WHERE FIN_DELETED = 0 AND ERASE_ID = 0 AND FIN_NO = '" & FIN_NO & "'"
				Conn.execute strSql
if WebUserID = gsAdmin then response.write strSql & "<br>"
		
				msg = "�Y�������`�[�͏�������܂����I"
							
			end if		'mode = 3
	
		end if			'msg = ""
					
		if err.number = 0 then 
			Conn.CommitTrans
		else
			Conn.CommitTrans
			msg = "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
		end if
		
	end if		'Begin Trans
%>

<html>
	<script language=javascript>
<%if msg <> "" then%>
		alert("<%=msg%>");
<%end if%>
<%if WebUserID <> gsAdmin then%>

<%if mode = 2 then%>
		window.location.href = "ReceiveErase.asp?FIN_NO=<%=FIN_NO%>";
		window.opener.location.href = "../Customs/ReceiveResult.asp";
<%else%>
		if (window.opener.frmInput != null) {
			window.opener.frmInput.submit();
			if (window.opener.frmInput.action == "ReceiveProc.asp") window.opener.parent.parent.result.location.href = "ReceiveResult.asp?type=2";
			if (window.opener.frmInput.action == "ReceiveView.asp") window.opener.parent.parent.result.location.href = "ReceiveResult.asp?type=3";
		} else {
			window.opener.location.href = "ReceiveResult.asp?type=3";
		}
		window.close();
<%end if%>

<%end if%>
	</script>
</html>
<%
	Set Recset = Nothing
	CloseDB Conn
%>
