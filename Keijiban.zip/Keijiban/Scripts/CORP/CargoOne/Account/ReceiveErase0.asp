<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�ȒP�����`�[�������
'
'	mode:	1 -- �c�ƔC��
'			2 -- �c�Ə���
'			3 -- �������s
'			4 -- ��������
'
'	FIN_CURRENT		0:����/1:�c��/2:����
'----------------------------------------------

'on error resume next
dim mode
dim myType

	myType = 0
	FIN_NO = GetPost(request("FIN_NO"))	
	if FIN_NO <> "" then
		
		OpenSql Conn, SqlServerName, DataBaseName
		
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
			strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 1 AND FIN_NO = '" & FitSel(FIN_NO) & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				FIN_No = GetString(.fields("FIN_NO"))
				FIN_DATE = Str2Date(.fields("FIN_DATE"))
				FIN_CLIENT_CD = GetString(.fields("FIN_CLIENT_CD"))		
				FIN_CLIENT_NAME = GetString(.fields("FIN_CLIENT_NAME"))					
				FIN_CLIENT_PIC = GetString(.fields("FIN_CLIENT_PIC"))
				FIN_BANK_ID = GetLong(.fields("FIN_BANK_ID"))
				FIN_AMOUNT = GetLong(.fields("FIN_AMOUNT"))
				FIN_SECURITIES = GetString(.fields("FIN_SECURITIES"))
				FIN_SECURITIES_NO = GetString(.fields("FIN_SECURITIES_NO"))
				FIN_SECURITIES_DATE = Str2Date(.fields("FIN_SECURITIES_DATE"))
				
				FIN_BATCH = GetString(.fields("FIN_BATCH"))
				FIN_BILLNO = GetString(.fields("FIN_BILLNO"))
				FIN_JOBCODE = GetString(.fields("FIN_JOBCODE"))
				FIN_DESCRIPTION = GetString(.fields("FIN_DESCRIPTION"))
				FIN_MEMO = GetString(.fields("FIN_MEMO"))
				FIN_REMARKS = GetString(.fields("FIN_REMARKS"))
				FIN_CURRENT = GetLong(.fields("FIN_CURRENT"))
				
				FIN_CREATER = GetLong(.fields("FIN_CREATER"))
				FIN_CREATED = GetDate(.fields("FIN_CREATED"))
				CONFIRM_ID = GetLong(.fields("CONFIRM_ID"))
				CONFIRM_DATE = GetDate(.fields("CONFIRM_DATE"))
				ERASE_ID = GetLong(.fields("ERASE_ID"))
				ERASE_DATE = GetDate(.fields("ERASE_DATE"))
				FIN_MONTH = GetString(.fields("FIN_MONTH"))
				FIN_CURRENT = GetLong(.fields("FIN_CURRENT"))
			end if
			.close
			
			if FIN_BATCH <> "" then 
				myType = 1					'�o�b�`������
			elseif FIN_BILLNO <> "" then 
				myType = 2					'�����ԍ�����
			elseif FIN_JOBCODE <> "" then 
				myType = 3 					'�䒠�ԍ�����
			end if
		end with
	end if
	
	if CONFIRM_ID = 0 then
		response.write "�Y�������`�[�͂܂��m�肳��Ă��܂���B"	
	else
%>
<html>
<HEAD>
	<TITLE>�����`�[�����Ɖ�</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		sub DoUnErase()
			if msgbox ("�Y�������`�[�̏������������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 4
			frmInput.submit()
		end sub
						
		sub DoShortCut()
			if window.event.keyCode=27 then window.close() 
		end sub		
		
		sub DoReset()
		dim sum, nos, ttl
			sum = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then
					if left(obj.name,4) = "DATA" and obj.checked then
						nos = nos & "," & GetLeft(obj.value, ".")
						ttl = ttl & "," & GetRight(obj.value, ".")
						sum = sum + GetLong(GetRight(obj.value, ".")) 	
					end if
				end if
			next
			frmInput.ChargeNos.value = mid(nos, 2)
			frmInput.ChargeTotal.value = mid(ttl, 2)
			frmInput.ChargeAmount.value = formatnumber(sum, 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub
		
		sub DataSave(mode)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'				exit sub
'			end if 
			if GetLong(frmInput.BankPostage.value) > <%=gsMaxPostage%> then 
				msgbox "���͂����ʐM��͑������ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if GetLong(frmInput.FromReceive.value) <> 0 and _
			   GetLong(frmInput.OverReceive.value) <> 0 then
				msgbox "�u�a������v�Ɓu�a����ցv�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if 
			if GetLong(frmInput.MassProfit.value) <> 0 and _
			   GetLong(frmInput.MassLoss.value) <> 0 then
				msgbox "�u�G���v�Ɓu�G���v�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if 
			if checkText("FIN_MEMO","��������", 0) = false then exit sub
			if checkLen("FIN_MEMO","��������", 250) = false then exit sub
			if checkText("Remarks","�c�ƃ���", 0) = false then exit sub
			if checkLen("Remarks","�c�ƃ���", 250) = false then exit sub
			if mode = 3 then
				if clng(frmInput.EraseResult.value) <> 0 then 
					msgbox "�ؕ����z�͑ݕ����z�ƍ���Ȃ��ł��B", 48, "�m�F���b�Z�[�W"
					exit sub
				end if
				if msgbox ("�Y�������`�[���������݂��Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub OverReceive_OnBlur()
			frmInput.OverReceive.value = formatnumber(GetLong(frmInput.OverReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub FromReceive_OnBlur()
			frmInput.FromReceive.value = formatnumber(GetLong(frmInput.FromReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'			end if 
		end sub		
		sub MassProfit_OnBlur()
			frmInput.MassProfit.value = formatnumber(GetLong(frmInput.MassProfit.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub MassLoss_OnBlur()
			frmInput.MassLoss.value = formatnumber(GetLong(frmInput.MassLoss.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub			
		sub FromDraft_OnBlur()
			frmInput.FromDraft.value = formatnumber(GetLong(frmInput.FromDraft.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub OverDraft_OnBlur()
			frmInput.OverDraft.value = formatnumber(GetLong(frmInput.OverDraft.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub BankPostage_OnBlur()
			frmInput.BankPostage.value = formatnumber(GetLong(frmInput.BankPostage.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub	
		function DoCalculate()
		dim debit, credit 
			debit = GetLong(frmInput.FIN_AMOUNT.value) + GetLong(frmInput.FromReceive.value) + GetLong(frmInput.MassLoss.value)
			debit = debit + GetLong(frmInput.BankPostage.value) + GetLong(frmInput.FromDraft.value)
			credit = GetLong(frmInput.ChargeAmount.value) + GetLong(frmInput.OverReceive.value) + GetLong(frmInput.MassProfit.value)
			credit = credit + GetLong(frmInput.OverDraft.value)
			DoCalculate = debit - credit
		end function	
		
		function DoUseDeposit(myAmount)
<%if ERASE_ID = 0 then%>
			frmInput.FromReceive.value = formatnumber(GetLong(myAmount), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
<%end if%>
		end function
	</SCRIPT>
</Head>
<body leftmargin=10 topmargin=10 class=pt12 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
<FORM name=frmInput action="ReceiveSave0.asp" method=post>
	<input type=hidden name="mode" value="0">
<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
  <tr><td width=50% valign=top>
  <!--�����F�����`�[���-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>�������`�[���&nbsp;
	  	<td width=50% nowrap>�����ԍ��F<%=FIN_NO%><input type=hidden name="FIN_NO" value="<%=FIN_NO%>">
	</table>
	<hr width=98% size=1 color=blue>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
	  <TR height=30>
		<TD nowrap colspan=2>
			������&nbsp;<input class=mi name="FIN_CLIENT_NAME" size=42 value="<%=FIN_CLIENT_NAME%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
			����S��&nbsp;<input class=mj name="FIN_CLIENT_PIC" size=20 value="<%=FIN_CLIENT_PIC%>" onkeydown="ResetEnter()" readonly>
			������&nbsp;<input class=mi name="FIN_DATE" size=10 value="<%=FIN_DATE%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
			������s&nbsp;<input class=mi name="FIN_BANK_ID" size=40 value="<%=GetBankName(FIN_BANK_ID)%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
			�����K�v&nbsp;<input class=mz name="FIN_DESCRIPTION" size=40 value="<%=FIN_DESCRIPTION%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap>
			�o�b�`�ԍ�&nbsp;<input class=mi name="FIN_BATCH" size=6 value="<%=FIN_BATCH%>" onkeydown="ResetEnter()" readonly>
		<TD nowrap class=pt12b>
			�����z&nbsp;<input class=mn name="FIN_AMOUNT" size=12 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap>
			�䒠�ԍ�&nbsp;<input class=mi name="FIN_JOBCODE" size=10 value="<%=FIN_JOBCODE%>" onkeydown="ResetEnter()" readonly>
		<TD nowrap>
			�����ԍ�&nbsp;<input class=mi name="FIN_BILLNO" size=10 value="<%=FIN_BILLNO%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
	  		����&nbsp;<input class=mi name="FIN_SECURITIES" size=6 value="<%=FIN_SECURITIES%>" onkeydown="ResetEnter()" readonly>
			����ԍ�&nbsp;<input class=mi name="FIN_SECURITIES_NO" size=10 value="<%=FIN_SECURITIES_NO%>" onkeydown="ResetEnter()" readonly>
			�T�C�g&nbsp;<input class=mi name="FIN_DATE" size=5 value="<%=right(FIN_SECURITIES_DATE, 5)%>" onkeydown="ResetEnter()" readonly>
	  <TR>
		<TD colspan=2>��������<br><textarea class=pt12n name="FIN_MEMO" rows=3 style="width:400"><%=FIN_MEMO%></textarea>
	  <TR>
		<TD colspan=2>��������<br><textarea class=pt12n name="FIN_REMARKS" rows=3 style="width:400"><%=FIN_REMARKS%></textarea>
	</TABLE>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=30 align=center valign=bottom>
		<TD width=10% class=pt12g>�쐬��<TD width=15% class=gline><%=GetEmployName(FIN_CREATER, "F")%><br>
		<TD width=10% class=pt12g>�m�F��<TD width=15% class=gline><%=GetEmployName(CONFIRM_ID, "F")%><br>
		<TD width=10% class=pt12g>������<TD width=15% class=gline><%=GetEmployName(ERASE_ID, "F")%><br>
	  <TR height=30 align=center valign=bottom>
		<TD class=pt12g>�쐬��<TD class=gline><%=formatDate(FIN_CREATED)%><br>
		<TD class=pt12g>�m�F��<TD class=gline><%=formatDate(CONFIRM_DATE)%><br>
		<TD class=pt12g>������<TD class=gline><%=formatDate(ERASE_DATE)%><br>
	</TABLE>
	<br>
<%
dim FIN_DEPOSIT

	myList = ShowAccountDetail(finPayment, Conn, FIN_NO, FIN_CLIENT_CD, FIN_DEPOSIT)
%>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>���a����c���F&nbsp;<input type=hidden name="FIN_DEPOSIT" value="<%=FIN_DEPOSIT%>">
<%if FIN_DEPOSIT >= 0 then%>
	  	<td width=50% nowrap align=right>\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%else%>
	  	<td width=50% nowrap align=right style="color:blue">\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%end if%>
	</table>
	<HR width=100% size=1 color=green>
  <!--�����F�c�����׏��-->
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
	<TR align=center height=20 class=pt12>
		<TD class=line nowrap>��
		<TD class=line nowrap>�`�[�ԍ�
		<TD class=line nowrap>���o����
		<TD class=line nowrap>�a�����
		<TD class=line nowrap>�a������
		<TD class=line nowrap>�c��
	<%=myList%>
	</TABLE>
	
  <td width=50% valign=top>
  <!--�E���F�Ɩ��������-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>���Ɩ��������&nbsp;
	  	<td width=50% nowrap><%
	  		select case myType
	  		case 1:
	  			response.write "�o�b�`���F" & FIN_BATCH
	  		case 2:
	  			response.write "�����ԍ��F" & FIN_BILLNO
			case 3:
	  			response.write "�䒠�ԍ��F" & FIN_JOBCODE
			end select%>
	</table>
	<hr width=98% size=1 color=blue>
<%
	if FIN_CURRENT = 9 then
		cnt = 9
	else
		myEraseNo = ""
		with recset
			if myType = 1 then 	'�o�b�`�ԍ�
				strSql = "SELECT ERASE_BATCH AS ERASE_NO FROM TBL_CTM_ERASE WHERE ERASE_FIN_NO = '" & FIN_NO & "'"
			else				'�����ԍ�/�䒠�ԍ�
				strSql = "SELECT ERASE_BIZ_NO AS ERASE_NO FROM TBL_CTM_ERASE WHERE ERASE_FIN_NO = '" & FIN_NO & "'"
			end if
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not .eof
				myEraseNo = myEraseNo & "," & GetString(.Fields("ERASE_NO"))
				.movenext
			loop
			.Close
		end with

		select case myType
		case 1:				'�o�b�`�ԍ�
		
			strSql = "SELECT BatchNo AS ChargeNo, BatchClient AS ChargeClient, BatchBillDay AS ChargeDate, BatchPayDay AS ChargePayDay"
			strSql = strSql & ", ConfirmerID, FinisherID, AMNT + TAX AS ChargeTotal FROM TBL_CTM_BATCH AS B INNER JOIN"
			strSql = strSql & " (SELECT MAX(ChargeBatch) AS BNO, SUM(ChargeAmount) AS AMNT, SUM(ChargeTax) AS TAX FROM TBL_CTM_CHARGE"
			strSql = strSql & " WHERE Deleted = 0 AND ChargeBatch = '" & FIN_BATCH & "') AS C ON B.BatchNo = C.BNO WHERE Deleted = 0"
			
		case 2:				'�����ԍ�
		
			strSql = "SELECT ChargeNo, ChargeDate, ChargeClient, ChargeAmount + ChargeTax AS ChargeTotal, ChargePayDay, ConfirmerID, FinisherID"
			strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeNo = '" & FIN_BILLNO & "' ORDER BY ChargeNo"
			
		case 3:				'�䒠�ԍ�
		
			strSql = "SELECT ChargeNo, ChargeDate, ChargeClient, ChargeAmount + ChargeTax AS ChargeTotal, ChargePayDay, ConfirmerID, FinisherID"
			strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND JobCode = '" & FIN_JOBCODE & "' ORDER BY ChargeClient, ChargeNo"
			
		end select
if WebUserID = gsAdmin then response.write strSQL
	
	
dim ChargeClient()
dim ChargeClientName()

		ClientNo = 0
		redim ChargeClient(0)
		redim ChargeClientName(0)
		ChargeClient(0) = ""
		ChargeClientName(0) = ""
		
		cnt = 0
		ChargeAmount = 0
		ChargeAmountAll = 0
		
		ChargeNos = ""
		ChargeTotal = ""
		with recset
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .EOF then
				myAmount = 0
				do while not .eof
				
					if ChargeClient(ClientNo) <> GetString(.Fields("ChargeClient")) then

						ClientNo = ClientNo + 1
						redim preserve ChargeClient(ClientNo)
						redim preserve ChargeClientName(ClientNo)
						ChargeClient(ClientNo) = GetString(.Fields("ChargeClient"))
						ChargeClientName(ClientNo) = GetFullName(GetString(.Fields("ChargeClient")))
						
						if ClientNo > 1 then response.write "</TABLE>"
					
%>
	<TABLE width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
	  <TR height=30>
		<TD nowrap>
			������&nbsp;<input class=mi name="ClientName" size=48 value="<%=ChargeClientName(ClientNo)%>" onkeydown="ResetEnter()" readonly>
	</TABLE>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
	  <TR align=center height=20 class=pt12>
		<TD class=line nowrap>��
		<TD class=line nowrap>�����ԍ�
		<TD class=line nowrap>������
		<TD class=line nowrap>������
		<TD class=line nowrap>�������z
		<TD class=line nowrap>�I��
<%
					end if
					
					cnt = cnt + 1
					ChargeNo = GetString(.Fields("ChargeNo"))
					myAmount = GetLong(.Fields("ChargeTotal"))
					status = ""
					if GetLong(.Fields("ConfirmerID")) = 0 then
						status = "<font color=gray>��</font>"
					else
						myChargeNo = CheckEtcErased(Conn, FIN_NO, ChargeNo, 2)
						if myChargeNo <> "" then
							status = ResetBizNo(myChargeNo)
						elseif instr(myEraseNo, ChargeNo) <> 0 then
							status = "<img src=img/checked.jpg><br>"
							ChargeAmount = ChargeAmount + myAmount
							ChargeTotal = ChargeTotal & "," & myAmount
							ChargeNos = ChargeNos & "," & ResetBizNo(ChargeNo)
						end if
					end if
					mycolor = "black"
					mycolor = "black"
					if left(ChargeNo, 1) = gsBatchPrint then
						if GetBatchType(ChargeNo) = 0 then mycolor = "blue"
					else
						if CheckVoucherType(ChargeNo) = "S" then mycolor = "green"
					end if 
%>
			<TR align=center height=20>
				<TD class=line><%=cnt%><BR>
				<TD class=line nowrap align=left style="color:<%=mycolor%>"><%=ShowVoucherNo(ChargeNo)%><BR>
				<TD class=line><%=Str2MD(.Fields("ChargeDate"))%><BR>
				<TD class=line style="color:blue"><%=Str2MD(.Fields("ChargePayDay"))%><BR>
				<TD class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
<%					if status <> "" then %>
				<TD class=line><%=status%>
<%					else %>
				<TD class=line><input type=checkbox name="DATA<%=cnt%>" value="<%=ResetBizNo(ChargeNo)%>.<%=myAmount%>" onclick="DoReset()"
					<%if myEraseNo = "" AND GetString(.Fields("ChargeClient")) = FIN_CLIENT_CD and myAmount = FIN_AMOUNT then response.write " checked"%>>
<%					
						if myEraseNo = "" AND GetString(.Fields("ChargeClient")) = FIN_CLIENT_CD and myAmount = FIN_AMOUNT then
							ChargeAmount = ChargeAmount + myAmount
							ChargeTotal = ChargeTotal & "," & myAmount
							ChargeNos = ChargeNos & "," & ResetBizNo(ChargeNo)
						end if
					end if
					ChargeAmountAll = ChargeAmountAll + myAmount
					.movenext
				loop
				if cnt > 1 then
%>
		<TR align=right height=20>
			<TD colspan=3>
			<TD class=line>�� �v
			<TD class=line><%=formatnumber(ChargeAmountAll, 0, true)%>
<%
				end if
%>
	</TABLE>
<%
			else
				if FIN_BILLNO <> "" then
					msg = "�����ԍ�"
				else
					msg = "�䒠�ԍ�"
				end if
				response.write "<br><div align=center class=pt12r>�Y������f�[�^�͌�����܂���ł����B</div>"
				response.write "<br><div align=center class=pt12b>" & msg & "����꒼���Ă��������B</div>"
				response.write "<br><div align=left class=pt12n>������F" & FIN_CLIENT_NAME & "</div>"								
				response.write "<br><div align=left class=pt12n>�c�ƒS���F" & GetSalesManager(FIN_CLIENT_CD) & "</div>"
			end if
			.Close
		end with
	end if
	
	if cnt > 0 then
%>
	<BR>
	<HR width=100% size=1 color=green>
  <!--�����F�����������-->
<%
		if ChargeAmount = 0 and myType <> 3 and FIN_CURRENT <> 9 then
			myMode = -1
			response.write "<br><div align=center class=pt12b>�Y�������ԍ��͏����s�ł��A�S���҂ɂ��A�����������B</div>"	
			select case myType
			case 1, 2
				response.write "<br><div align=left class=pt12n>������F" & ChargeClientName(1) & "</div>"								
				response.write "<br><div align=left class=pt12n>�c�ƒS���F" & GetSalesManager(ChargeClient(1)) & "</div>"
			case 3
				for i = 1 to ubound(ChargeClient)
					response.write "<br><div align=left class=pt12n>������F" & ChargeClientName(i) & "</div>"								
					response.write "<br><div align=left class=pt12n>�c�ƒS���F" & GetSalesManager(ChargeClient(i)) & "</div>"	
				next 
			end select
		else			
			FromReceive = 0
			OverReceive = 0
			MassProfit = 0
			MassLoss = 0
			FromDraft = 0
			OverDraft = 0
			BankPostage = 0	
			FromExpense = 0
			OverExpense = 0
			with Recset
				strSql = "SELECT FIN_NO, FIN_TYPE, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_BANK_ID FROM TBL_CTM_FIN"
				strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_NO = '" & FIN_NO & "'"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof
					select case GetLong(.Fields("FIN_DEBIT"))
					case acntOverReceive
						FromReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a������
					case acntMassLoss
						MassLoss = GetLong(.Fields("FIN_AMOUNT"))						'�G����
					case acntFromDraft
						FromDraft = GetLong(.Fields("FIN_AMOUNT"))						'��`����
					case acntPostage
						BankPostage = GetLong(.Fields("FIN_AMOUNT"))					'�ʐM��
					case acntExpense
						FromExpense = GetLong(.Fields("FIN_AMOUNT"))					'�o��
					end select
					
					select case GetLong(.Fields("FIN_CREDIT"))
					case acntOverReceive
						OverReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a�����
					case acntMassProfit
						MassProfit = GetLong(.Fields("FIN_AMOUNT"))						'�G�v��
					case acntOverDraft
						OverDraft = GetLong(.Fields("FIN_AMOUNT"))						'��`��
					case acntPostage
						BankPostage = 0 - GetLong(.Fields("FIN_AMOUNT"))				'�ʐM��
					case acntExpense
						OverExpense = GetLong(.Fields("FIN_AMOUNT"))					'�o��
					end select
					.movenext
				loop
				.close
			end with
			
			EraseResult = FIN_AMOUNT + FromReceive + MassLoss - ChargeAmount - OverReceive - MassProfit
			EraseResult = EraseResult + BankPostage + FromDraft - OverDraft + FromExpense - OverExpense
%>
	<TABLE width=98% Cellspacing=3 CellPadding=3 class=pt12n>
	  <TR align=center height=20>
		<TD class=line colspan=2>�ؕ�
		<TD class=line colspan=2>�ݕ�	
			
	  <TR align=center height=20>
		<TD class=line>���z
		<TD class=line>�Ȗ�
		<TD class=line>�Ȗ�
		<TD class=line>���z
		
	  <TR align=right height=20>
		<TD><input class=mn name="ReceiveAmount" size=9 maxlength=10 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" onkeydown="ResetEnter()" Readonly>
		<TD align=left>�@����
		<TD><font color=blue>(����)���|</font>
		<TD><input class=mn name="ChargeAmount" size=9 maxlength=10 value="<%=formatnumber(ChargeAmount,0,true)%>" onkeydown="ResetEnter()" Readonly>
		
	  <TR align=right height=20>
		<TD><input class=mn name="FromReceive" size=9 maxlength=10 value="<%=formatnumber(FromReceive, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left nowrap>�@�a������
		<TD>�a����
		<TD><input class=mn name="OverReceive" size=9 maxlength=10 value="<%=formatnumber(OverReceive, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20 class=pt12>
		<TD><input class=mn name="MassLoss" size=9 maxlength=10 value="<%=formatnumber(MassLoss, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@�G��
		<TD>�G��
		<TD><input class=mn name="MassProfit" size=9 maxlength=10 value="<%=formatnumber(MassProfit, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20 class=pt12>
		<TD><input class=mn name="FromDraft" size=9 maxlength=10 value="<%=formatnumber(FromDraft, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@��`����
		<TD>��`��
		<TD><input class=mn name="OverDraft" size=9 maxlength=10 value="<%=formatnumber(OverDraft, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20>
		<TD><input class=mn name="BankPostage" size=9 maxlength=10 value="<%=formatnumber(BankPostage, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left style="cursor:help" title="<%=GetClientPostage(FIN_CLIENT_CD)%>">�@�ʐM��
		<TD nowrap class=pt12r>�������z
		<TD><input class=mn name="EraseResult" size=9 maxlength=10 value="<%=formatnumber(EraseResult, 0, true)%>" onkeydown="ResetEnter()" Readonly>

<%if FIN_CURRENT = 9 then %>
	  <TR align=right height=20 class=pt12t>
		<TD><input class=mn name="FromExpense" size=9 maxlength=10 value="<%=formatnumber(FromExpense, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@�o���
		<TD>�o���
		<TD><input class=mn name="OverExpense" size=9 maxlength=10 value="<%=formatnumber(OverExpense, 0, true)%>" onkeydown="ResetEnter()">
<%end if%>

	  <TR align=right height=49>
	  	<TD>
	  	
	  <TR align=center height=20>
	  	<TD colspan=4 align=center>
	  		<HR width=100% size=1 color=green>
	  	
	  <TR align=center height=20>
	  	<TD colspan=4 align=center>
<%if ERASE_ID <> 0 then%>
	<%if FIN_MONTH = "" and CheckAccountLevel() > 1 and FIN_CURRENT <> 9 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnUnLock value="������������" onclick="DoUnErase()">
	<%end if%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnClose value="��ʂ����" onclick="window.close()">
<%else%>
	<%select case FIN_CURRENT
	  case 0%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnSave value="�c�ƂɔC����" onclick="DataSave(1)">
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnLock value="�����������s" onclick="DataSave(3)">
	<%case 1%>
			<font color=pt12b>�Y�������`�[�͂������܉c�ƂɔC���Ă��܂��B</font>
	<%case 2%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnLock value="�����������s" onclick="DataSave(3)">
	<%end select%>
<%end if%>
	</TABLE>
<%	
		end if
	end if
%>
<input type=hidden name="ChargeNos" value="<%=mid(ChargeNos, 2)%>">
<input type=hidden name="ChargeTotal" value="<%=mid(ChargeTotal, 2)%>">
<input type=hidden name="EraseType" value="<%=myType%>">
</FORM>
<center>
<%if ERASE_ID <> 0 then %>
<script language=vbscript>
	call LockAll
</script>
<%end if%>
</body></html>
<%	
	end if
	
	set Recset = nothing
	CloseDB Conn
%>
