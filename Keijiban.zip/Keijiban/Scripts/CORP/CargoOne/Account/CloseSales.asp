<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�q�ʎc���ꗗ�Ɖ���
'----------------------------------------------
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
		
	mode = GetLong(request("mode"))
	select case mode
	case 0
		SelDate = date
		if day(SelDate) <= gsSysCloseDay then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
			
		AccountMonth = SelYear & right("00" & SelMonth, 2)
		
		'���R���ȊO�̏ꍇ�Ή�
		call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	case 1 
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
		if SelYear = 0 or SelMonth = 0 then
			SelDate = date
			if day(SelDate) <= gsSysCloseDay then 
				SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
			end if
			SelYear = year(SelDate)
			SelMonth = month(SelDate)
		end if	
		AccountMonth = SelYear & right("00" & SelMonth, 2)
		
		'���R���ȊO�̏ꍇ�Ή�
		call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
		'if AccountTo > Date2Str(date) then AccountTo = Date2Str(date)

		'���߃`�F�b�N
		myCheck = 0
		strSql = "SELECT CHECK_ID FROM CTM_ACCOUNT WHERE ACCOUNT_MONTH = '" & AccountMonth & "'"
		Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not Recset.eof then myCheck = 1
		Recset.Close
		
		if myCheck = 1 then
			strSql = "SELECT CHECK_ID FROM CTM_ACCOUNT WHERE CHECK_ID = 0 AND ACCOUNT_MONTH = '" & AccountMonth & "'"
			Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not Recset.eof then myCheck = 0
			Recset.Close
		end if

		if myCheck = 0 then
		
			'----------------------------------------------
			'	�N���A
			'----------------------------------------------
			Conn.BeginTrans
			
			strSql = "DELETE FROM CTM_ACCOUNT WHERE ACCOUNT_MONTH = '" & AccountMonth & "'"
			Conn.Execute strSql
if WebUserID = gsAdmin then response.write strSql
			
			strSql = "INSERT INTO CTM_ACCOUNT (CTM_CD, CTM_BELONG, ACCOUNT_MONTH)"
			strSql = strSql & " SELECT DISTINCT BIZ_BROKER_CD, '', '" & AccountMonth & "'"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0"
			Conn.Execute strSql
if WebUserID = gsAdmin then response.write strSql
			
			'RANDOM �⑫
			strSql = "SELECT * FROM CTM_ACCOUNT WHERE CTM_CD = 'RANDOM' AND ACCOUNT_MONTH = '" & AccountMonth & "'"
			Recset.Open strSql, Conn, adOpenKeyset , adLockOptimistic 
			if Recset.eof then
				Recset.AddNew
				Recset.Fields("CTM_CD") = "RANDOM"
				Recset.Fields("CTM_BELONG") = ""
				Recset.Fields("ACCOUNT_MONTH") = AccountMonth
			end if
			Recset.Update
			Recset.Close
			
			'----------------------------------------------
			'	�����ߌJ�z�擾
			'----------------------------------------------
			PreMonth = left(Date2Str(dateadd("m", -1, Str2Date(AccountMonth & "01"))), 6)
			
			Set myRec = Server.CreateObject ("ADODB.Recordset")
			strSql = "SELECT * FROM CTM_ACCOUNT WHERE ACCOUNT_MONTH = '" & PreMonth & "'"
			strSql = strSql & " ORDER BY CTM_BELONG, ACCOUNT_MONTH, CTM_CD"
			Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not Recset.eof
				with myRec
					strSql = "SELECT * FROM CTM_ACCOUNT WHERE ACCOUNT_MONTH = '" & AccountMonth & "'"
					strSql = strSql & " AND CTM_CD = '" & GetString(Recset.Fields("CTM_CD")) & "'"
					.Open strSql, Conn, adOpenKeyset , adLockOptimistic 
					if .eof then
						.AddNew
						.Fields("CTM_BELONG") = ""
						.Fields("ACCOUNT_MONTH") = NextMonth
						.Fields("CTM_CD") = GetString(Recset.Fields("CTM_CD"))
						.fields("CHECK_ID") = 0
					end if
					.fields("INITIAL_SALES") = GetLong(Recset.fields("BALANCE_SALES"))
					.fields("INITIAL_COSTS") = GetLong(Recset.fields("BALANCE_COSTS"))
					.fields("INITIAL_STANDR") = GetLong(Recset.fields("BALANCE_STANDR"))
					.fields("INITIAL_STANDP") = GetLong(Recset.fields("BALANCE_STANDP"))
					.fields("INITIAL_DEPOSIT") = GetLong(Recset.fields("BALANCE_DEPOSIT"))
					.fields("INITIAL_DRAFT") = GetLong(Recset.fields("BALANCE_DRAFT"))
					.Update
					.Close
				end with
				Recset.MoveNext
			loop
			Recset.Close
			
			'----------------------------------------------
			'	�����f�[�^�Z�b�g
			'----------------------------------------------
			'������
			strSql = "UPDATE CTM_ACCOUNT SET CHECK_ID = 0" 
			strSql = strSql & ",BALANCE_SALES = 0, AMOUNT_SALES = 0, RECEIVE_SALES = 0"
			strSql = strSql & ",BALANCE_COSTS = 0, AMOUNT_COSTS = 0, PAYMENT_COSTS = 0"
			strSql = strSql & ",BALANCE_STANDR = 0, AMOUNT_STANDR = 0, RECEIVE_STANDR = 0"
			strSql = strSql & ",BALANCE_STANDP = 0, AMOUNT_STANDP = 0, PAYMENT_STANDP = 0"
			strSql = strSql & ",BALANCE_DEPOSIT = 0, RECEIVE_DEPOSIT = 0, PAYMENT_DEPOSIT = 0"
			strSql = strSql & ",BALANCE_DRAFT = 0, RECEIVE_DRAFT = 0, PAYMENT_DRAFT = 0"
			strSql = strSql & " WHERE ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql

			'���|���̎擾
			strSql = "UPDATE CTM_ACCOUNT SET AMOUNT_SALES = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizSales & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND BIZ_DELETED = 0 AND BIZ_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql

			'���֔��|���̎擾
			strSql = "UPDATE CTM_ACCOUNT SET AMOUNT_STANDR = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizStandR & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND BIZ_DELETED = 0 AND BIZ_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'���|�����̎擾
			strSql = "UPDATE CTM_ACCOUNT SET RECEIVE_SALES = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizSales & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND CTM_ACCOUNT.CHECK_ID = 0 AND BIZ_DELETED = 0 AND BIZ_FIN_NO IN (SELECT DISTINCT FIN_NO FROM TBL_CTM_FIN WHERE FIN_MONTH = '" & AccountMonth & "'))"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'���֔��|�����̎擾
			strSql = "UPDATE CTM_ACCOUNT SET RECEIVE_STANDR = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizStandR & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND BIZ_DELETED = 0 AND BIZ_FIN_NO IN (SELECT DISTINCT FIN_NO FROM TBL_CTM_FIN WHERE FIN_MONTH = '" & AccountMonth & "'))"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'�a��������̎擾
			strSql = "UPDATE CTM_ACCOUNT SET RECEIVE_DEPOSIT = (SELECT ISNULL(SUM(CASE FIN_CREDIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_FIN WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_FIN.FIN_CLIENT_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND FIN_DELETED = 0 AND FIN_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_FIN"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'�a����o���̎擾
			strSql = "UPDATE CTM_ACCOUNT SET PAYMENT_DEPOSIT = (SELECT ISNULL(SUM(CASE FIN_DEBIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_FIN WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_FIN.FIN_CLIENT_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND FIN_DELETED = 0 AND FIN_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_FIN"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'�x����`����̎擾
			strSql = "UPDATE CTM_ACCOUNT SET RECEIVE_DRAFT = (SELECT ISNULL(SUM(CASE FIN_CREDIT WHEN " & acntOverDraft & " THEN FIN_AMOUNT ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_FIN WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_FIN.FIN_CLIENT_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND FIN_DELETED = 0 AND FIN_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_FIN"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'�x����`�ւ̎擾
			strSql = "UPDATE CTM_ACCOUNT SET PAYMENT_DRAFT = (SELECT ISNULL(SUM(CASE FIN_DEBIT WHEN " & acntFromDraft & " THEN FIN_AMOUNT ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_FIN WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_FIN.FIN_CLIENT_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND FIN_DELETED = 0 AND FIN_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_FIN"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'���|���̎擾
			strSql = "UPDATE CTM_ACCOUNT SET AMOUNT_COSTS = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizCosts & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND BIZ_DELETED = 0 AND BIZ_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'���|���x���̎擾
			strSql = "UPDATE CTM_ACCOUNT SET PAYMENT_COSTS = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizCosts & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND BIZ_DELETED = 0 AND BIZ_FIN_NO IN (SELECT DISTINCT FIN_NO FROM TBL_CTM_FIN WHERE FIN_MONTH = '" & AccountMonth & "'))"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'���֔��|���̎擾
			strSql = "UPDATE CTM_ACCOUNT SET AMOUNT_STANDP = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizStandP & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND BIZ_DELETED = 0 AND BIZ_MONTH = '" & AccountMonth & "')"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'���֔��|���x���̎擾
			strSql = "UPDATE CTM_ACCOUNT SET PAYMENT_STANDP = (SELECT ISNULL(SUM(CASE BIZ_TYPE WHEN " & bizStandP & " THEN BIZ_AMOUNT + BIZ_TAX ELSE 0 END), 0)"
			strSql = strSql & " FROM TBL_CTM_BIZ WHERE CTM_ACCOUNT.CTM_CD = TBL_CTM_BIZ.BIZ_BROKER_CD AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND BIZ_DELETED = 0 AND BIZ_FIN_NO IN (SELECT DISTINCT FIN_NO FROM TBL_CTM_FIN WHERE FIN_MONTH = '" & AccountMonth & "'))"
			strSql = strSql & " FROM CTM_ACCOUNT, TBL_CTM_BIZ"
			strSql = strSql & " WHERE CTM_ACCOUNT.CHECK_ID = 0 AND CTM_ACCOUNT.ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
			
			'----------------------------------------------
			'	RANDOM �a����⑫
			'----------------------------------------------			
			'�a������o���̎擾
			strSql = "SELECT SUM(CASE FIN_CREDIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0 END) AS AddedDeposit,"
			strSql = strSql  & " SUM(CASE FIN_DEBIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0 END) AS UsedDeposit FROM TBL_CTM_FIN"
			strSql = strSql & " WHERE FIN_CLIENT_CD NOT IN (SELECT CTM_CD FROM CTM_ACCOUNT) AND FIN_DELETED = 0 AND FIN_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not Recset.eof then
				AddedDeposit = GetLong(Recset.Fields("AddedDeposit"))
				UsedDeposit = GetLong(Recset.Fields("UsedDeposit"))
			end if
			Recset.Close
			
			'RANDOM �L��
			strSql = "UPDATE CTM_ACCOUNT SET "
			strSql = strSql & " RECEIVE_DEPOSIT = RECEIVE_DEPOSIT + " &  AddedDeposit
			strSql = strSql & ",PAYMENT_DEPOSIT = PAYMENT_DEPOSIT + " &  UsedDeposit
			strSql = strSql & " WHERE CHECK_ID = 0 AND CTM_CD = 'RANDOM' AND ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
	
			'----------------------------------------------
			'	�o�����X�v�Z
			'----------------------------------------------
				
			'�]�v���̍폜
			strSql = "DELETE FROM CTM_ACCOUNT WHERE CHECK_ID = 0 AND ACCOUNT_MONTH = '" & AccountMonth & "'"
			strSql = strSql & " AND INITIAL_SALES = 0 AND AMOUNT_SALES = 0 AND RECEIVE_SALES = 0"
			strSql = strSql & " AND INITIAL_COSTS = 0 AND AMOUNT_COSTS = 0 AND PAYMENT_COSTS = 0"
			strSql = strSql & " AND INITIAL_STANDR = 0 AND AMOUNT_STANDR = 0 AND RECEIVE_STANDR = 0"
			strSql = strSql & " AND INITIAL_STANDP = 0 AND AMOUNT_STANDP = 0 AND PAYMENT_STANDP = 0"
			strSql = strSql & " AND INITIAL_DEPOSIT = 0 AND RECEIVE_DEPOSIT = 0 AND PAYMENT_DEPOSIT = 0"
			strSql = strSql & " AND INITIAL_DRAFT = 0 AND RECEIVE_DRAFT = 0 AND PAYMENT_DRAFT = 0"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql	
			
			'�e�c���̌v�Z
			strSql = "UPDATE CTM_ACCOUNT SET "
			strSql = strSql & " BALANCE_SALES = INITIAL_SALES + AMOUNT_SALES - RECEIVE_SALES"
			strSql = strSql & ",BALANCE_COSTS = INITIAL_COSTS + AMOUNT_COSTS - PAYMENT_COSTS"
			strSql = strSql & ",BALANCE_STANDR = INITIAL_STANDR + AMOUNT_STANDR - RECEIVE_STANDR"
			strSql = strSql & ",BALANCE_STANDP = INITIAL_STANDP + AMOUNT_STANDP - PAYMENT_STANDP"
			strSql = strSql & ",BALANCE_DEPOSIT = INITIAL_DEPOSIT + PAYMENT_DEPOSIT - RECEIVE_DEPOSIT"
			strSql = strSql & ",BALANCE_DRAFT = INITIAL_DRAFT + PAYMENT_DRAFT - RECEIVE_DRAFT"
			strSql = strSql & " WHERE CHECK_ID = 0 AND ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
			Conn.Execute strSql
	
			Conn.CommitTrans
		end if
		
	case 2, 3
		AccountMonth = GetPost(request("AccountMonth"))
		
		if mode = 2 then
			myCheck = WebUserID 
		else
			myCheck = 0			
		end if
		
		strSql = "UPDATE CTM_ACCOUNT SET CHECK_DATE = GETDATE(), CHECK_ID = " & myCheck
		strSql = strSql & " WHERE ACCOUNT_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSQL & "<br><br>"
		conn.execute strSql	
		
		if myCheck <> 0 then
			msg = "�q�ʎc���f�[�^�͊m�肳��܂����B"
		else
			msg = "�q�ʎc���f�[�^�͉�������܂����B"
		end if
		SelYear = clng(left(AccountMonth, 4))
		SelMonth = clng(right(AccountMonth, 2))	
	end select
%>

<HTML>
<HEAD>
	<TITLE>�q�ʎc���ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoClose()
			if msgbox ("���Ӑ�ʃf�[�^�������߂��Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 2
			frmInput.submit()
		end sub	
		
		sub DoUnClose()
			if msgbox ("���Ӑ�ʃf�[�^���������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 3
			frmInput.submit()
		end sub
		
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CloseSales.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="AccountBelong" VALUE='<%=AccountBelong%>'>
		<INPUT TYPE="HIDDEN" NAME="AccountMonth" VALUE='<%=AccountMonth%>'>
		<input type=hidden name="mode" value="1">
		<table class=pt9n>
			<TR><TD nowrap class=pt9>��v���x&nbsp;
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;��
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
<div id=list>
�Ώی��x�F<%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup align=left>
		<colgroup span=4 align=right bgcolor="#FFF0F0">
		<colgroup span=4 align=right>
		<colgroup span=4 align=right bgcolor="#F0FFF0">
		<colgroup span=4 align=right>
		<colgroup span=4 align=right bgcolor="#F0F0FF">
		<colgroup span=4 align=right>
		<colgroup align=right>
		<TR bgcolor="#E0E0E0">
			<TD rowspan=2 align=center>�׎喼
			<TD colspan=4 align=center>���@�|
			<TD colspan=4 align=center>���ւq
			<TD colspan=4 align=center>���@�|
			<TD colspan=4 align=center>���ւo
			<TD colspan=4 align=center>�a�@��
			<TD colspan=4 align=center>��@�`
		<TR>
<%for i = 1 to 4%>
			<TD nowrap>�J�z
			<TD nowrap>����
			<TD nowrap>����
			<TD nowrap>�c��
<%next%>
			<TD nowrap>�J�z
			<TD nowrap>����
			<TD nowrap>�a��
			<TD nowrap>�c��
			<TD nowrap>�J�z
			<TD nowrap>����
			<TD nowrap>��`
			<TD nowrap>�c��
<%

	InitSales = 0:		AmntSales = 0:		RecvSales = 0:		BalnSales = 0
	InitStandR = 0:		AmntStandR = 0:		RecvStandR = 0:		BalnStandR = 0
	InitCosts = 0:		AmntCosts = 0:		PayCosts = 0:		BalnCosts = 0
	InitStandP = 0:		AmntStandP = 0:		PayStandP = 0:		BalnStandP = 0
	InitDeposit = 0:	AddedDeposit = 0:	UsedDeposit = 0:	BalnDeposit = 0
	InitDraft = 0:		AddedDraft = 0:		UsedDraft = 0:		BalnDraft = 0
	with recset
		strSql = "SELECT * FROM CTM_ACCOUNT AS A INNER JOIN (SELECT BIZ_BROKER_CD AS CTM_CD, MAX(BIZ_BROKER_NAME) AS CTM_NAME"
		strSql = strSql & " FROM TBL_CTM_BIZ GROUP BY BIZ_BROKER_CD) AS B  ON A.CTM_CD = B.CTM_CD"
		strSql = strSql & " WHERE ACCOUNT_MONTH = '" & AccountMonth & "'"
		strSql = strSql & " ORDER BY CTM_NAME"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		do while not .EOF
		  if GetString(.fields("CTM_CD")) = gsCorpCode OR _
		  	 GetString(.fields("CTM_CD")) = gsCorpSoko  then
		  else
			if GetString(.fields("CTM_CD")) = gsDummy then
				myName = "RANDOM"
			else
				myName = ResetCorpName(.fields("CTM_NAME"))	
			end if
%>
		<TR <%if GetString(.fields("CTM_CD")) = gsDummy then%>bgcolor=#E0E0E0<%end if%>>
			<TD nowrap><%=StringCut(myName, 20)%>
			<TD><%=formatnumber(GetLong(.Fields("INITIAL_SALES")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_SALES")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("RECEIVE_SALES")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_SALES")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("INITIAL_STANDR")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_STANDR")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("RECEIVE_STANDR")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_STANDR")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("INITIAL_COSTS")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_COSTS")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("PAYMENT_COSTS")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_COSTS")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("INITIAL_STANDP")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("AMOUNT_STANDP")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("PAYMENT_STANDP")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_STANDP")), 0, true)%>
			<TD><%=formatnumber(0-GetLong(.Fields("INITIAL_DEPOSIT")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("PAYMENT_DEPOSIT")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("RECEIVE_DEPOSIT")), 0, true)%>
			<TD><%=formatnumber(0-GetLong(.Fields("BALANCE_DEPOSIT")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("INITIAL_DRAFT")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("PAYMENT_DRAFT")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("RECEIVE_DRAFT")), 0, true)%>
			<TD><%=formatnumber(GetLong(.Fields("BALANCE_DRAFT")), 0, true)%>
<%			
			InitSales = InitSales + GetLong(.Fields("INITIAL_SALES"))
			AmntSales = AmntSales + GetLong(.Fields("AMOUNT_SALES"))
			RecvSales = RecvSales + GetLong(.Fields("RECEIVE_SALES"))
			BalnSales = BalnSales + GetLong(.Fields("BALANCE_SALES"))
			InitStandR = InitStandR + GetLong(.Fields("INITIAL_STANDR"))
			AmntStandR = AmntStandR + GetLong(.Fields("AMOUNT_STANDR"))
			RecvStandR = RecvStandR + GetLong(.Fields("RECEIVE_STANDR"))
			BalnStandR = BalnStandR + GetLong(.Fields("BALANCE_STANDR"))
			InitCosts = InitCosts + GetLong(.Fields("INITIAL_COSTS"))
			AmntCosts = AmntCosts + GetLong(.Fields("AMOUNT_COSTS"))
			PayCosts = PayCosts + GetLong(.Fields("PAYMENT_COSTS"))
			BalnCosts = BalnCosts + GetLong(.Fields("BALANCE_COSTS"))
			InitStandP = InitStandP + GetLong(.Fields("INITIAL_STANDP"))
			AmntStandP = AmntStandP + GetLong(.Fields("AMOUNT_STANDP"))
			PayStandP = PayStandP + GetLong(.Fields("PAYMENT_STANDP"))
			BalnStandP = BalnStandP + GetLong(.Fields("BALANCE_STANDP"))
			InitDeposit = InitDeposit + GetLong(.Fields("INITIAL_DEPOSIT"))
			UsedDeposit = UsedDeposit + GetLong(.Fields("PAYMENT_DEPOSIT"))
			AddedDeposit = AddedDeposit + GetLong(.Fields("RECEIVE_DEPOSIT"))
			BalnDeposit = BalnDeposit + GetLong(.Fields("BALANCE_DEPOSIT"))
			InitDraft = InitDraft + GetLong(.Fields("INITIAL_DRAFT"))
			UsedDraft = UsedDraft + GetLong(.Fields("PAYMENT_DRAFT"))
			AddedDraft = AddedDraft + GetLong(.Fields("RECEIVE_DRAFT"))
			BalnDraft = BalnDraft + GetLong(.Fields("BALANCE_DRAFT"))
		end if
			.movenext
		loop
		.Close
	end with
%>
		<TR>
			<TD align=center>���@�v
			<TD nowrap><%=formatnumber(InitSales, 0, true)%>
			<TD nowrap><%=formatnumber(AmntSales, 0, true)%>
			<TD nowrap><%=formatnumber(RecvSales, 0, true)%>
			<TD nowrap><%=formatnumber(BalnSales, 0, true)%>
			<TD nowrap><%=formatnumber(InitStandR, 0, true)%>
			<TD nowrap><%=formatnumber(AmntStandR, 0, true)%>
			<TD nowrap><%=formatnumber(RecvStandR, 0, true)%>
			<TD nowrap><%=formatnumber(BalnStandR, 0, true)%>
			<TD nowrap><%=formatnumber(InitCosts, 0, true)%>
			<TD nowrap><%=formatnumber(AmntCosts, 0, true)%>
			<TD nowrap><%=formatnumber(PayCosts, 0, true)%>
			<TD nowrap><%=formatnumber(BalnCosts, 0, true)%>
			<TD nowrap><%=formatnumber(InitStandP, 0, true)%>
			<TD nowrap><%=formatnumber(AmntStandP, 0, true)%>
			<TD nowrap><%=formatnumber(PayStandP, 0, true)%>
			<TD nowrap><%=formatnumber(BalnStandP, 0, true)%>
			<TD nowrap><%=formatnumber(0-InitDeposit, 0, true)%>
			<TD nowrap><%=formatnumber(UsedDeposit, 0, true)%>
			<TD nowrap><%=formatnumber(AddedDeposit, 0, true)%>
			<TD nowrap><%=formatnumber(0-BalnDeposit, 0, true)%>
			<TD nowrap><%=formatnumber(InitDraft, 0, true)%>
			<TD nowrap><%=formatnumber(UsedDraft, 0, true)%>
			<TD nowrap><%=formatnumber(AddedDraft, 0, true)%>
			<TD nowrap><%=formatnumber(BalnDraft, 0, true)%>
	</TABLE>
</div>
	<BR>
	<TABLE Cellspacing=3 CellPadding=3 class=pt12n width=100%>
		<tr><td align=right>
<%if myCheck = 0 then%>
	<%if AccountMonth < left(Date2Str(date), 6) and CheckAccountLevel() > 1 then%>
			<INPUT class=pt12n style="width:120px;height:50px;" TYPE=button VALUE="���ߎ��s" onclick="DoClose()">
	<%end if%>
<%else%>
			<font class=pt12r>�����ߍ�</font>	
	<%if CheckAccountLevel() > 2 then%>
			<INPUT class=pt12n style="width:120px;height:50px;" TYPE=button VALUE="���߉���" onclick="DoUnClose()">
	<%end if%>
<%end if%>
	</TABLE>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>