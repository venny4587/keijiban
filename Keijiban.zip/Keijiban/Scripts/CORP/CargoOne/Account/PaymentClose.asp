<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����o���`�[�Ɖ���
'----------------------------------------------

'on error resume next
dim FinStr
dim myMode
dim PageSize
	
	PageSize = GetUserPageSize(10)
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		mySort = 2
		'DateFrom = GetInitDate()
		DateTo = formatDate(date)
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		BillNo = GetPost(request("BillNo"))
		BatchNo = GetPost(request("BatchNo"))
		CostsNo = GetPost(request("CostsNo"))
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�o���`�[�쐬����</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowList(mode) 
		dim win
			set win = window.open("ClientSearch.asp?mode=1&cd=" & frmInput.ClientRef.value,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function DoPayment(myNo)
<%if CheckAccountLevel() > 1 or WebUserID = 73 then%>
		dim win
			set win = window.open("PaymentErase1.asp?FIN_BATCH=" & myNo,"PaymentErase","resizable=1,scrollbars=1,width=900,height=640")
			win.focus()
<%else%>
			msgbox "������������ɂ͊Y���������K�v�ł��B", 48, "�m�F���b�Z�[�W"
<%end if%>
		end function
		
		function DoAddNew()
<%if CheckAccountLevel() > 1 or WebUserID = 73 then%>
		dim win
			set win = window.open("PaymentErase0.asp","PaymentErase","resizable=1,scrollbars=1,width=900,height=640")
			win.focus()
<%else%>
			msgbox "������������ɂ͊Y���������K�v�ł��B", 48, "�m�F���b�Z�[�W"
<%end if%>
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub CostsNo_OnBlur()
			frmInput.CostsNo.value = FitCostsNo(frmInput.CostsNo.value)
		end sub
		sub BatchNo_OnBlur()
			frmInput.BatchNo.value = FitBatchNo(frmInput.BatchNo.value)
		end sub
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
				
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
			window.parent.parent.result.location.href = "PaymentResult.asp?type=1"
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="PaymentClose.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�x����<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=9 onkeydown="ResetEnter()">					
				�x����&nbsp;<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				�ޯ���<input class=sn name="BatchNo" value="<%=BatchNo%>" maxlength=6 size=5 onkeydown="ResetEnter()">
				<TD nowrap>
					<INPUT class=pt9n style="width:60px;height:30px;" TYPE=SUBMIT VALUE="����">
					<INPUT class=pt9n style="width:60px;height:30px;" TYPE=Button VALUE="�ǉ�" onclick="DoAddNew()">
		</table>
		
	<!----------��������--------->
<%
	strSel = ""
	if ClientRef <> "" then	strSel = strSel & " AND ClientRef = '" & FitSel(ClientRef) & "'"
	if DateFrom <> "" then strSel = strSel & " AND BatchPayDay >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND BatchPayDay <= '" & Date2Str(DateTo) & "'"
	if BatchNo <> "" then strSel = strSel & " AND BatchNo = '" & FitSel(BatchNo) & "'"
	if CostsNo <> "" OR BillNo <> "" then
		strTmp = ""
		if CostsNo <> "" then strTmp = strTmp & " AND CostsNo = '" & FitSel(CostsNo) & "'"
		if BillNo <> "" then strTmp = strTmp & " AND BillNo LIKE '%" & FitSel(BillNo) & "%'"
		strSel = strSel & " AND BatchNo IN (SELECT DISTINCT CostsBatch FROM TBL_CTM_COSTS WHERE " & mid(strTmp, 5) & ")"
	end if
	if WebUserID = 73 then strSel = strSel & " AND ClientRef LIKE 'MARUMA%'"
	
	myBatchCnt = 0
	with recset		
		myTotalAmount = 0
		strSql = "SELECT SUM(BatchAmount) AS TotalAmount FROM TBL_CTM_BATCH AS B INNER JOIN"
		strSql = strSql & " (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME AS ClientName FROM CUSTOMER) AS C ON B.BatchClient = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(BatchNo, 1, 1) = '" & gsBatchBill & "' AND Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0"		'���폜�@�������@�m���
		strSql = strSql & " AND BatchNo NOT IN (SELECT DISTINCT ERASE_BATCH FROM TBL_CTM_ERASE)"
		if strSel <> "" then strSql = strSql & strSel
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then myTotalAmount = GetLong(.Fields("TotalAmount"))
		.Close
		
		strSql = "SELECT BatchNo, BatchBelong, BatchType, ClientRef, ClientName, BatchPayDay, BatchCount, BatchAmount, ConfirmerID, ConfirmDate FROM TBL_CTM_BATCH AS B"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME AS ClientName FROM CUSTOMER) AS C ON B.BatchClient = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(BatchNo, 1, 1) = '" & gsBatchBill & "' AND Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0"		'���폜�@�������@�m���
		strSql = strSql & " AND BatchNo NOT IN (SELECT DISTINCT ERASE_BATCH FROM TBL_CTM_ERASE)"
		if strSel <> "" then strSql = strSql & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY BatchNo"
		case 1:		strSql = strSql & " ORDER BY ClientRef, BatchNo"
		case 2:		strSql = strSql & " ORDER BY BatchPayDay, BatchNo"
		case 3:		strSql = strSql & " ORDER BY ConfirmDate, BatchNo"
		end select			
if WebUserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			if myMode > 0 then response.write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"
		else
			.PageSize = PageSize
			lngPageCount = .PageCount
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * PageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=4 align=center>
			<colgroup span=2 align=left>
			<colgroup align=center>
			<colgroup span=2 align=right>
			<colgroup span=3 align=center>
		  <TR align=center height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>�敪
			<TD class=line nowrap>�戵
			<TD class=line nowrap>����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�ޯ���
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�x����
			<TD class=line nowrap align=right>����
			<TD class=line nowrap align=right>���v���z
			<TD class=line nowrap>�m�F
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�m�F��
<%
			ttlAmount = 0
			do while not .eof
				lngCount = lngCount + 1
				If lngCount > lngPageNumber * PageSize Then
					Exit Do
				Else
					myBatchNo = GetString(.Fields("BatchNo"))
					ttlAmount = ttlAmount + GetLong(.Fields("BatchAmount"))
					select case GetBatchType(GetString(.Fields("BatchNo"))) 
					case 0 
						status = "<font color=blue>����</font>"
					case 1
						status = "����"
					case else
						status = "<font color=red>����</font>"
					end select
%>
			<TR height=30 align=center style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
				 onclick="DoPayment('<%=myBatchNo%>')">
				<TD class=line><%=lngCount%><BR>
				<TD class=line><%=status%><BR>
				<TD class=line><%=GetShopName(GetString(.Fields("BatchBelong")))%><BR>
				<TD class=line nowrap><%=GetJobDivision(.Fields("BatchType"))%><BR>
				<TD class=line><%=ShowBatchNo(myBatchNo)%><BR>
				<TD class=line nowrap title="<%=GetString(.Fields("ClientName"))%>"><%=StringCut(GetString(.Fields("ClientRef")),7)%><BR>
				<TD class=line nowrap style="color:blue"><%=Str2YMD(.Fields("BatchPayDay"))%><BR>
				<TD class=line nowrap><%=formatnumber(GetLong(.Fields("BatchCount")), 0, true)%><BR>
				<TD class=line nowrap><%=formatnumber(GetLong(.Fields("BatchAmount")), 0, true)%><BR>
				<TD class=line nowrap><%=GetEmployName(.Fields("ConfirmerID"), "F")%><BR>
				<TD class=line nowrap><%=right(formatDate(.Fields("ConfirmDate")),8)%><BR>
<%
					.movenext
				end if
			loop
			if lngCount > 1 then 
%>
				<TR align=right height=20>
					<TD colspan=5><%if lngCount > lngPageNumber * PageSize then%><font color=red>��������܂�...</font><%end if%>
					<TD class=line>�� �v
					<TD class=line><%=formatnumber(myTotalAmount, 0, true)%>
<%
			end if
%>
		</TABLE>
<%	
		end if
		.close
	end with
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>


<%
function GetBatchType(myBatch)
dim mySql
dim myRec
dim myCnt
	myCnt = 0
	GetBatchType = -1 
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT DISTINCT CostsType FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsBatch = '" & myBatch & "'"
		.Open mySql,conn,adOpenStatic,adLockReadOnly
		do while not .eof
			myCnt = myCnt + 1
			GetBatchType = GetLong(.fields("CostsType"))
			.movenext
		loop
		.Close
	end with
	set myRec = nothing
	if myCnt > 1 then GetBatchType =  -1
end function
%>