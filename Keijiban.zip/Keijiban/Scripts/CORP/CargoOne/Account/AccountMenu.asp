<html>
<head>
	<title>�����������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		btnBank.style.color = "black"
		btnSales.style.color = "black"
		btnStandR.style.color = "black"
		btnCosts.style.color = "black"
		btnStandP.style.color = "black"
		btnDeposit.style.color = "black"
		btnDraft.style.color = "black"
		select case mySel
		case 1
			url = "AccountBank.asp"
			btnBank.style.color = "red"
		case 2
			url = "AccountSales.asp"	
			btnSales.style.color = "red"
		case 3
			url = "AccountStandR.asp"
			btnStandR.style.color = "red"
		case 4
			url = "AccountCosts.asp"	
			btnCosts.style.color = "red"
		case 5
			url = "AccountStandP.asp"	
			btnStandP.style.color = "red"
		case 6
			url = "AccountDeposit.asp"	
			btnDeposit.style.color = "red"
		case 7
			url = "AccountDraft.asp"
			btnDraft.style.color = "red"
		end select
		window.parent.abody.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnBank value="��s�o�[��" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnDraft value="��`���ώc��" onclick="DoAct(7)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnDeposit value="�a����c��" onclick="DoAct(6)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnSales value="���|���c��" onclick="DoAct(2)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnStandR value="���֔��|�c��" onclick="DoAct(3)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnCosts value="���|���c��" onclick="DoAct(4)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnStandP value="���֔��|�c��" onclick="DoAct(5)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
