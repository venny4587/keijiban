<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	��s�����ꗗ�Ɖ���
'----------------------------------------------

'on error resume next
dim myMode
dim myPageSize
	
	myPageSize = 2000
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		if gsSysAccountDay = 99 then 
			DateFrom = Str2Date(left(Date2Str(date),6) & "01")
		else
			myDate = dateadd("m", -1, date)
			DateFrom = cdate(year(myDate) & gsDateSign & month(myDate) & gsDateSign & (gsSysAccountDay + 1))
		end if
		DateTo = formatDate(date)
	else
		BankID = GetLong(request("BankID"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
	end if
%>
<HTML>
<HEAD>
	<TITLE>��s�����ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>						
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub InitForm()
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="AccountBank.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<TABLE class=pt9>
			<TR><TD nowrap>
				�����ԍ�&nbsp;<select name="BankID" class=pt9n onkeydown="ResetEnter()"><%=ShowBankList(BankID, 0, 0)%></select>
				�Ɖ���t&nbsp;<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</TABLE>
	</FORM>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if DateFrom <> "" then strSel = strSel & " AND FIN_DATE >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND FIN_DATE <= '" & Date2Str(DateTo) & "'"	
		if BankID <> "" then strSel = strSel & " AND FIN_BANK_ID = " & BankID
			
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		
		with recset
			TotalCount = 0
			strSql = "SELECT COUNT(FIN_BANK_ID) AS TotalCount FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 1 AND FIN_DELETED = 0 AND CONFIRM_ID <> 0"
			strSql = strSql & " AND (FIN_DEBIT =" & acntBank & " OR FIN_CREDIT = " & acntBank & ")"
			if strSel <> "" then strSQL = strSQL & strSel
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then TotalCount = GetLong(.Fields("TotalCount"))
			.Close
			
			if TotalCount = 0 then 
				Response.Write "<br><div align=center class=pt12r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			elseif TotalCount > myPageSize then 
				Response.Write "<br><div align=center class=pt12r>�Y������f�[�^�� <b>" & myPageSize & "</b> ���ȏ�z���܂����B</div>"	
			else
				cnt = 0
				myReceive = 0
				myPayment = 0
				myDate = ""
				myBalance = GetBankInitAmount(BankID, DateFrom)
%>
<div id=list>
�Ώۊ��ԁF<%=DateFrom%>�`<%=DateTo%>
		<TABLE width=720 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=3 align=center>
			<colgroup align=left>
			<colgroup span=3 align=right>
			<colgroup align=left>
			<TR class=pt9>
				<TD class=line width=4%>��
				<TD class=line width=10% nowrap>�`�[�ԍ�
				<TD class=line width=6% nowrap>����
				<TD class=line width=20% nowrap align=center>���o����
				<TD class=line width=15% nowrap>�����z
				<TD class=line width=15% nowrap>�o���z
				<TD class=line width=15% nowrap>�c��
				<TD class=line width=15% nowrap align=center>�E�v				
<%
				strSql = "SELECT FIN_NO, FIN_DATE, FIN_BELONG, FIN_CLIENT_NAME, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_DESCRIPTION, CONFIRM_ID"
				strSql = strSql & ", ERASE_ID, FIN_SECURITIES, FIN_SECURITIES_DATE, FIN_MEMO, FIN_REMARKS, FIN_CREATED FROM TBL_CTM_FIN"
				strSql = strSql & " WHERE FIN_ORIGINAL = 1 AND FIN_DELETED = 0 AND (FIN_DEBIT =" & acntBank & " OR FIN_CREDIT = " & acntBank & ")"
				if strSel <> "" then strSQL = strSQL & strSel
				strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .EOF
					if myDate <> GetString(.Fields("FIN_Date"))  then
						if (myReceive + myPayment) <> 0 then
%>
			<TR bgcolor="#E0E0FF">
				<TD class=line colspan=3><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line align=center>�������v
				<TD class=line><%=formatnumber(myReceive, 0, true)%><BR>
				<TD class=line><%=formatnumber(myPayment, 0, true)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%><BR>
				<TD class=line><BR>
<%						else 	%>
			<TR bgcolor="#E0E0FF">
				<TD class=line colspan=3><%=Str2Date(.Fields("FIN_Date"))%>�i<%=GetWeekDay(weekday(Str2Date(.Fields("FIN_Date"))))%>�j
				<TD class=line align=center>�J�z�c��
				<TD class=line colspan=2><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%><BR>
				<TD class=line><BR>
<%	
						end if
						cnt = 0
						myReceive = 0
						myPayment = 0
						myDate = GetString(.Fields("FIN_Date"))
					end if			
					
					cnt = cnt + 1			
					myName = ResetCorpName(.fields("FIN_CLIENT_NAME"))
					myAmount = GetLong(.Fields("FIN_AMOUNT"))	
					myDebit = "":	myCredit = ""
					if GetLong(.fields("FIN_DEBIT")) = acntBank then
						myDebit = formatnumber(myAmount, 0, true)
						myReceive = myReceive + myAmount
						myBalance = myBalance + myAmount
					elseif GetLong(.fields("FIN_CREDIT")) = acntBank then
						myCredit = formatnumber(myAmount, 0, true)
						myPayment = myPayment + myAmount
						myBalance = myBalance - myAmount
					end if
					myMemo = GetString(.Fields("FIN_DESCRIPTION"))
					if GetString(.Fields("FIN_SECURITIES")) = "���؎�" then 
						myMemo = Str2Date(.Fields("FIN_SECURITIES_DATE"))
					end if
%>
			<TR>
				<TD class=line><%=cnt%><BR>
				<TD class=line nowrap><%=ShowVoucherNo(.Fields("FIN_NO"))%><BR>
				<TD class=line nowrap><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
				<TD class=line nowrap "<%=ShowTitle(myName,10)%>"><%=StringCut(myName,10)%><BR>
				<TD class=line nowrap><%=myDebit%><BR>
				<TD class=line nowrap><%=myCredit%><BR>
				<TD class=line nowrap><%=formatnumber(myBalance, 0, true)%><BR>
				<TD class=line nowrap "<%=ShowTitle(myMemo,10)%>"><%=StringCut(myMemo,10)%><BR>
<%	
					.movenext
				loop
				.Close
				
				sumUnCheck = 0
				CheckDate = Date2Str(DateTo)
				if CheckDate = "" OR CheckDate > Date2Str(date) then CheckDate = Date2Str(date)
				
				strSql = "SELECT SUM(FIN_AMOUNT) AS TTL FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 1 AND FIN_DELETED = 0"
				strSql = strSql & " AND FIN_BANK_ID = " & BankID & " AND SUBSTRING(FIN_NO, 3, 1) = 'P'"
				strSql = strSql & " AND FIN_SECURITIES = '���؎�' AND FIN_DATE <= '" & CheckDate & "'"
				strSql = strSql & " AND (ISNULL(FIN_SECURITIES_DATE, '') = '' OR FIN_SECURITIES_DATE > '" & CheckDate & "')"
'if WebUserID = 1 then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then sumUnCheck = GetLong(.Fields("TTL"))
				.Close
%>
			<TR bgcolor="#E0E0FF">
				<TD class=line colspan=3><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line align=center>�������v
				<TD class=line nowrap><%=formatnumber(myReceive, 0, true)%><BR>
				<TD class=line nowrap><%=formatnumber(myPayment, 0, true)%><BR>
				<TD class=line nowrap><%=formatnumber(myBalance, 0, true)%><BR>
				<TD class=line nowrap>(<%=formatnumber(myBalance + sumUnCheck, 0, true)%>)<BR>
		</TABLE>
</div>
<%
			end if
		end with
		
		set Recset = nothing
		CloseDB Conn
		
	end if
%>
</BODY></HTML>

<%
function GetBankInitAmount(myBank, myDate)
dim mySql
dim myRec
	GetBankInitAmount = 0
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT BankDate, BankReceive, BankPayment, BankSecurities, BankBalance FROM TBL_CTM_BANK"
		mySql = mySql & " WHERE BankID = " & myBank & " AND BankDate < '" & Date2Str(myDate) & "' ORDER BY BankDate DESC"
		.Open mySql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then GetBankInitAmount = GetLong(.Fields("BankBalance"))
		.Close
	end with
	set myRec = Nothing
end function
%>