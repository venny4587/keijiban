
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<TITLE>�����˗��`�[</TITLE>
	<style>
		.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 9pt }
		.pt12 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; LINE-HEIGHT: 11pt }
		.pt16 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 16pt; LINE-HEIGHT: 16pt }	
		.so12{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; BACKGROUND: #FFF0F0; BORDER-RIGHT: #FFF0F0 1px solid; BORDER-TOP: #FFF0F0 1px solid; BORDER-LEFT: #FFF0F0 1px solid; BORDER-BOTTOM: #FFF0F0 1px solid;}
		.sn12{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; BACKGROUND: #FFF0F0; BORDER-RIGHT: #FFF0F0 1px solid; BORDER-TOP: #FFF0F0 1px solid; BORDER-LEFT: #FFF0F0 1px solid; BORDER-BOTTOM: #FFF0F0 1px solid; TEXT-ALIGN:right}
		.nm12{ime-mode:active; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; BACKGROUND: #FFF0F0; BORDER-RIGHT: #FFF0F0 1px solid; BORDER-TOP: #FFF0F0 1px solid; BORDER-LEFT: #FFF0F0 1px solid; BORDER-BOTTOM: #FFF0F0 1px solid;}
	</style>
<SCRIPT language=Javascript>
<!--		
	function ResetEnter() {
		if (event.keyCode == 13) {
			window.event.keyCode = 9;
		}
	}
-->
</SCRIPT>
<script language = vbscript>
	function DoDetail(myID)
		window.parent.detail.location.href="DP_Detail.asp?id=" & myID
	end function
	
	function DoDelete(myID)
		If msgbox("�폜���Ă���낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 Then
			window.location.href="DP_Delete.asp?id=" & myID
		End If
	end function
	
	function DoSave()
	dim buf
	dim msg 
		msg = "�m�F���b�Z�[�W" 
		if not isdate(frmInput.IMPORTDATE.value) then
			frmInput.IMPORTDATE.focus
			msgbox "���ɓ��𐳂������͂��Ă�������",48, msg
			exit function
		end if
		if	trim(frmInput.PKG_NO.value) = "" then
			frmInput.PKG_NO.focus
			msgbox "�}�[�N������͂��Ă�������",48, msg
			exit function
		end if
		if trim(frmInput.PKG_NW.value)  = "" then
			frmInput.PKG_NW.focus
			msgbox "N.W.����͂��Ă�������",48, msg
			exit function
		elseif not isNumeric(frmInput.PKG_NW.value) then
			frmInput.PKG_NW.focus
			msgbox "N.W.�𐳂������͂��Ă�������",48, msg
			exit function
		else
			frmInput.PKG_NW.value = cdbl(frmInput.PKG_NW.value)
		end if
		if trim(frmInput.EXPORTDATE.value) <> "" then
			if not isdate(frmInput.EXPORTDATE.value) then
				frmInput.EXPORTDATE.focus
				msgbox "�o�`���𐳂������͂��Ă�������",48, msg
				exit function
			end if
		end if
		if msgbox("�Y���f�[�^��ۑ����Ă�낵���ł����H", 289, msg) = 1 then 
			frmInput.mode.value = 1
			frmInput.id.value = 0
			frmInput.submit()
		end if	
	end function
</script>
</HEAD>

<BODY LEFTMARGIN=0 TOPMARGIN=0 LINK=#000000 ALINK=#000000 VLINK=#0000FF>

<!--Main Body-->
<TABLE cellSpacing=0 cellPadding=0 width=787>
  <TBODY><TR>
    <TD><IMG height=2 alt="" src=img/spacer.gif width=3></TD>
    <TD align=middle>
    
      <!--Head Graph-->
      <TABLE cellSpacing=0 cellPadding=0 width=100% border=0>
        <TBODY><TR>
          <TD><IMG height=5 src=img/spacer.gif width=5></TD></TR></TBODY></TABLE>
            
      <!--Body Frame-->
      <TABLE cellSpacing=0 cellPadding=0 border=0>
        <TBODY>
        <TR>
          <TD><IMG height=5 src=img/dtl_img02.gif width=5></TD>
          <TD background=img/dtl_bg01.gif><IMG height=5 src=img/spacer.gif width=700></TD>
          <TD><IMG height=5 src=img/dtl_img03.gif width=23></TD></TR>
        <TR>
          <TD background=img/dtl_bg02.gif><IMG height=12 src=img/spacer.gif width=5></TD>
          <TD valign=top align=center height=400>
	
			<!----------��������--------->
			<FORM ID=frmInput NAME=frmInput METHOD=POST ACTION=Denpyou.asp>
			  <table width=98% CELLPADDING=0 CELLSPACING=0>
				<tr><td width=320>
					<table border=0 width=100% style="filter:progid:DXImageTransform.Microsoft.Shadow(Color=#E0E0E0,Direction=120,strength=3)">
						<tr height=30><td class=pt12>�f����p�������<td><tr>
						<tr height=45><td class=pt16 align=center><b>���@���@�ˁ@���@�`�@�[</b><td><tr>
					</table>
				</td>
				<td>
					<table width=300 BORDER=1 bordercolor=#640000 CELLPADDING=2 CELLSPACING=0>
						<TR align=center height=25 class=pt9>
							<TD nowrap>��@��</TD>
							<TD nowrap>�Ё@��</TD>
							<TD nowrap>���F��</TD>
							<TD nowrap>�o�[��</TD>
							<TD nowrap>�L�@�[</TD>
						</TR>
						<TR align=center height=55 class=pt16>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
						</TR>
					</table>
				</td>
				<td width=60 align=right>
					<table width=60 BORDER=1 bordercolor=#640000 CELLPADDING=2 CELLSPACING=0 class=pt9>
						<TR align=center height=25>
							<TD nowrap>������</TD>
						</TR>
						<TR align=center height=55>
							<TD nowrap><BR></TD>
						</TR>
					</table>
				</td></tr>
			  </table>
			  <table width=98% border=1 bordercolor=#640000 CELLPADDING=0 CELLSPACING=0>
				<tr><td colspan=2>
					<table width=100% border=1 frame=void bordercolor=#640000 CELLPADDING=2 CELLSPACING=0 class=pt12>
						<TR ALIGN=CENTER height=25>
							<TD nowrap>�x�XCD</TD>
							<TD nowrap>�x�����ԍ�</TD>
							<TD colspan=2 nowrap>�` �[ �� ��</TD>
							<TD>�L �[ ��</TD>
							<TD BGCOLOR=#8b2222 style="color:white">�퐿����</TD>
						</TR>
						<TR ALIGN=CENTER height=30>
							<TD width=10% nowrap class=pt12>00-21<BR></TD>
							<TD width=20%><input class=so12 maxlength=20 size=15 name="JOB_NO" value="<%=JOB_NO%>" OnKeyDown="ResetEnter()"></TD>
							<TD width=6%><input class=so12 maxlength=2 size=2 name="BILL_TYPE" value="B" OnKeyDown="ResetEnter()"></TD>
							<TD width=20%><input class=so12 maxlength=20 size=15 name="BILL_NO" value="<%=BILL_NO%>" OnKeyDown="ResetEnter()"></TD>
							<TD width=12%>2006/07/07</TD>
							<TD width=12%><input class=sn12 maxlength=10 size=10 name="ACCOUNT_DATE" value="<%=ACCOUNT_DATE%>" OnKeyDown="ResetEnter()"></TD>
						</TR>
					</table>
				</td></tr>
				<tr><td colspan=2>
					<table width=100% border=1 frame=void bordercolor=#640000 CELLPADDING=2 CELLSPACING=0 class=pt12>
						<TR ALIGN=CENTER height=25>
							<TD nowrap BGCOLOR=#8b2222 style="color:white">�؁@���@�ȁ@��</TD>
							<TD nowrap BGCOLOR=#8b2222 style="color:white">�݁@���@�ȁ@��</TD>
							<TD nowrap BGCOLOR=#8b2222 style="color:white">�ݕ�</TD>
							<TD nowrap BGCOLOR=#8b2222 style="color:white">���@�@�z</TD>
							<TD nowrap BGCOLOR=#8b2222 style="color:white">�~�@�@�z</TD>
						</TR>
						<TR ALIGN=CENTER height=40>
							<TD width=25%>
								<table width=90%>
									<tr><td align=right><input type=hidden name="DEBIT_CD" value="<%=DEBIT_CD%>">002</td>
										<td width=80%>�@�O��</td></tr>
								</table></TD>
							<TD width=25%>
								<table width=90%>
									<tr><td align=right><input type=hidden name="CREDIT_CD" value="<%=CREDIT_CD%>">200</td>
										<td width=80%>�@���|</td></tr>
								</table></TD>
							<TD width=10%><input class=so12 maxlength=3 size=3 name="CURRENCY" value="JPY" OnKeyDown="ResetEnter()"></TD>
							<TD width=20%><input class=sn12 maxlength=10 size=12 name="AMOUNT" value="<%=AMOUNT%>" OnKeyDown="ResetEnter()"></TD>
							<TD width=20%><input class=sn12 maxlength=10 size=12 name="AMOUNT" value="<%=AMOUNT%>" OnKeyDown="ResetEnter()"></TD>
						</TR>
					</table>
				</td></tr>
				<tr><td width=55%>
					<table width=100% border=1 frame=void bordercolor=#640000 CELLPADDING=2 CELLSPACING=0 class=pt12>
						<TR height=30><TD nowrap align=center>&nbsp;�x �� ��&nbsp;</TD>
							<TD>&nbsp;<input class=so12 maxlength=10 size=6 name="BROKER_CD" value="<%=BROKER_CD%>" OnKeyDown="ResetEnter()">
								<input class=nm12 maxlength=100 size=20 name="BROKER_NAME" value="<%=BROKER_NAME%>" OnKeyDown="ResetEnter()"></TD></TR>
						<TR height=30><TD nowrap align=center>�䒠�ԍ�</TD>
							<TD>&nbsp;<input class=so12 maxlength=20 size=20 name="SOKEY" value="<%=SOKEY%>" OnKeyDown="ResetEnter()"></TD></TR>
						<TR height=30><TD nowrap align=center>�� �� ��</TD>
							<TD>&nbsp;SHIPPER�@OR�@CONSIGNEE</TD></TR>
						<TR height=30><TD nowrap align=center>�D���֖�</TD>
							<TD>&nbsp;VESSEL�@VOY</TD></TR>
						<TR height=85><TD nowrap align=center>���@�l<br><br><br><br></TD>
							<TD>&nbsp;<input class=nm12 maxlength=100 size=30 name="MEMO1" value="<%=MEMO1%>" OnKeyDown="ResetEnter()"><BR>
							&nbsp;<input class=nm12 maxlength=100 size=30 name="MEMO2" value="<%=MEMO2%>" OnKeyDown="ResetEnter()"><BR>
							&nbsp;<input class=nm12 maxlength=100 size=30 name="MEMO3" value="<%=MEMO3%>" OnKeyDown="ResetEnter()"></TD></TR>
					</table>
				</td><td width=45%>
					<table width=100% border=1 frame=void bordercolor=#640000 CELLPADDING=2 CELLSPACING=0 class=pt12>
						<TR height=30 align=center><TD nowrap colspan=2>�o���\���</TD>
							<TD colspan=3><input class=so12 maxlength=10 size=12 name="PAYEE_PLAN" value="<%=PAYEE_PLAN%>" OnKeyDown="ResetEnter()"></TD></TR>
						<TR height=30 align=center><TD nowrap colspan=2>�o���I����</TD>
							<TD colspan=3><input class=so12 maxlength=10 size=12 name="PAYEE_END" value="<%=PAYEE_END%>" OnKeyDown="ResetEnter()"></TD></TR>
						<TR height=30 align=center><TD nowrap colspan=2>INV ��</TD>
							<TD colspan=3><input class=so12 maxlength=50 size=16 name="REFER_NO" value="<%=REFER_NO%>" OnKeyDown="ResetEnter()"></TD></TR>
						<TR height=30 align=center><TD nowrap colspan=2>MB/L ��</TD>
							<TD colspan=3>MB/L OR HB/L No.</TD></TR>
						<TR height=30 align=center CLASS=PT9>
							<TD width=60>�x�X��</TD>
							<TD width=60>���@��</TD>
							<TD width=60>�ہ@��</TD>
							<TD width=60>�W�@��</TD>
							<TD width=60>�S����</TD></TR>
						<TR height=55 align=center>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
							<TD nowrap><BR></TD>
						</TR>
					</table>
				</td></tr>
			  </table>
			</FORM>
			
		  </TD>
		  <TD background="img/dtl_bg03.gif"><IMG height=5 src="img/spacer.gif" width=23></TD></TR>
		<TR>
			<TD><IMG height=7 src="img/dtl_img04.gif" width=5></TD>
			<TD background="img/dtl_bg04.gif"><IMG height=7 src="img/spacer.gif" width=5></TD>
	        <TD><IMG height=7 src="img/dtl_img05.gif" width=23></TD></TR>
		</TBODY></TABLE></TD></TR>

	  <TR>
	    <TD><IMG height=2 alt="" 
	      src="img/spacer.gif" 
	      width=3></TD>
	    <TD><IMG height=2 alt="" 
	      src="img/spacer.gif" 
	      width=784></TD></TR></TBODY></TABLE>
		</TD>
	</tr>
</TABLE>

</BODY></HTML>
