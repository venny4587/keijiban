<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�U�֓`�[����
'----------------------------------------------

'on error resume next

	mode = GetLong(request("mode"))
	FIN_NO = GetPost(request("FIN_NO"))
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Conn.BeginTrans

	select case mode
	case 0, 1, 2					'�o�^�E�ۑ��E�m��
	
		msg = ""
		if FIN_NO = "" and mode <> 1 then
		
			SeqNo = GetNewAcntNo(Conn, 5)			'�U��
			FIN_NO = GetAccountNo(SeqNo, 5)			
		
		elseif CheckFinanceLocked(Conn, FIN_NO) then
		
			msg = "�Y���U�֓`�[�͊��Ɋm�肳��܂����B"
			
		end if
		
		if msg = "" then
			Set Recset = Server.CreateObject ("ADODB.Recordset")
			with Recset
							
				strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 1 AND FIN_NO = '" & FIN_NO & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("FIN_NO") = FIN_NO
					.fields("FIN_TYPE") = GetLong(request("FIN_TYPE"))
					.fields("FIN_BELONG") = GetPost(request("FIN_BELONG"))
					.fields("FIN_CURRENT") = 0
					.fields("FIN_ORIGINAL") = 1
					
					.fields("FIN_CREATER") = WebUserID
					.fields("FIN_CREATED") = now
					.fields("FIN_DELETED") = 0
				end if
								
				.fields("FIN_CLIENT_CD") = GetPost(request("ClientCode"))
				.fields("FIN_CLIENT_NAME") = GetPost(request("ClientName"))
				.fields("FIN_CLIENT_PIC") = GetPost(request("ClientPic"))
				.fields("FIN_BANK_ID") = GetLong(request("FIN_BANK_ID"))		
				
				.fields("FIN_DEBIT") = GetLong(request("FIN_DEBIT"))
				.fields("FIN_CREDIT") = GetLong(request("FIN_CREDIT"))
				
				.fields("FIN_DATE") = Date2Str(request("FIN_DATE"))
				.fields("FIN_AMOUNT") = GetLong(request("FIN_AMOUNT"))
				.fields("FIN_DESCRIPTION") = GetPost(request("FIN_DESCRIPTION"))
				.fields("FIN_BATCH") = GetPost(request("FIN_BATCH"))
				.fields("FIN_BILLNO") = GetPost(request("FIN_BILLNO"))
				.fields("FIN_JOBCODE") = GetPost(request("FIN_JOBCODE"))
				
				.fields("FIN_SECURITIES") = GetPost(request("FIN_SECURITIES"))
				.fields("FIN_SECURITIES_DATE") = Date2Str(request("FIN_SECURITIES_DATE"))
				.fields("FIN_SECURITIES_NO") = GetPost(request("FIN_SECURITIES_NO"))
				.fields("FIN_MEMO") = GetPost(request("FIN_MEMO"))
				.fields("FIN_REMARKS") = GetPost(request("FIN_REMARKS"))
					
				.fields("FIN_UPDATER") = WebUserID
				.fields("FIN_UPDATED") = now
				.update
				.close
			end with
			
			if mode = 0 then
				if mid(gsMsgAccount,1,1) <> "0" then msg = "�Y���U�֓`�[�͍쐬����܂����I"
			else
				if mid(gsMsgAccount,2,1) <> "0" then msg = "�Y���U�֓`�[�͕ۑ�����܂����I"
			end if
			
		end if
		
		if mode = 2	then	'�U�֓`�[�m��
									
			strSql = "UPDATE TBL_CTM_FIN SET CONFIRM_DATE = GETDATE()"
			strSql = strSql & ", CONFIRM_ID = " & WebUserID
			strSql = strSql & " WHERE FIN_NO = '" & FIN_NO & "'"
			Conn.execute strSql
			
			if mid(gsMsgAccount,3,1) <> "0" then msg = "�Y���U�֓`�[�͊m�肳��܂����I"
			
		end if		
		
	case 3		'�m�����
		
		if CheckFinanceErased(Conn, FIN_NO) = true then
		
			msg = "�Y���U�֓`�[�͊��ɏ�������܂����I"
					
		else
		
			strSql = "UPDATE TBL_CTM_FIN SET CONFIRM_DATE = NULL"
			strSql = strSql & ", CONFIRM_ID = 0"
			strSql = strSql & " WHERE FIN_NO = '" & FIN_NO & "'"
			Conn.execute strSql
			
			if mid(gsMsgAccount,4,1) <> "0" then msg = "�Y���U�֓`�[�̊m��͉�������܂����I"
			
			if CheckFinanceCurrent(Conn, FIN_NO) = true then
				msg = msg & "\n\n�c�ƔC���܂����̂ŁA���m�点�Ă��������B"
			end if
			
		end if

	case -1			'�폜
	
		if CheckFinanceLocked(Conn, FIN_NO) then
		
			msg = "�Y���U�֓`�[�͊��Ɋm�肳��܂����B"
			
		else
		
			strSql = "UPDATE TBL_CTM_FIN SET FIN_DELETED = 1"
			strSql = strSql & ", FIN_UPDATER = " & WebUserID
			strSql = strSql & ", FIN_UPDATED = GETDATE()"
			strSql = strSql & " WHERE FIN_NO = '" & FIN_NO & "'"
			Conn.execute strSql
			
			if mid(gsMsgAccount,5,1) <> "0" then msg = "�Y���U�֓`�[�͍폜����܂����I"
		
		end if
		
	end select
	
	if err.number = 0 then 
		Conn.CommitTrans
%>

<html>
	<script language=javascript>
		alert("<%=msg%>");
		window.parent.parent.result.location.href = "TransferResult.asp";
<%	select case mode
	case -1 %>
		window.location.href = "../common/blank.htm";
<%	case 0 %>
		window.location.href = "TransferInput.asp";		
<%	case else %>
		window.location.href = "TransferInput.asp?FIN_NO=<%=FIN_NO%>";
<%	end select %>
	</script>
</html>
<%
	else
		Conn.CommitTrans
		ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
	end if		
	CloseDB Conn
%>
