<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�o���`�[�ꗗ�Ɖ���
'----------------------------------------------

'on error resume next
dim FinStr
dim myMode
dim myPageSize
dim lngPageNumber
		
	myPageSize = GetUserPageSize(15)
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		mySort = 4
		'DateFrom = GetInitDate()
		if CheckAccountLevel() < 2 then FIN_BANK_ID = GetDefaultBank()
	else
		ClientRef = GetPost(request("ClientRef"))
		JobCode = GetPost(request("JobCode"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		Fin_No = GetPost(request("Fin_No"))
		ChargeNo = GetPost(request("ChargeNo"))
		AmountFrom = GetPost(request("AmountFrom"))
		AmountTo = GetPost(request("AmountTo"))
		FIN_BANK_ID = GetLong(request("FIN_BANK_ID"))
		FIN_SECURITIES = GetPost(request("FIN_SECURITIES"))
		ClientBelong = GetPost(request("ClientBelong"))
		ClientSales = GetLong(request("ClientSales"))
		
		if AmountFrom <> "" then AmountFrom = GetLong(AmountFrom)
		if AmountTo <> "" then AmountTo = GetLong(AmountTo)
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����`�[�����Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList() 
		dim win
			set win = window.open("ClientSearch.asp?cd=" & frmInput.ClientRef.value,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function ShowDetail(myNo, myData)
			if myData = 9 then 
				set win = window.open("ReceiveErase0.asp?FIN_NO=" & myNo,"ReceiveErase","resizable=1,scrollbars=1,width=960,height=640")
			else
				set win = window.open("ReceiveErase1.asp?FIN_NO=" & myNo,"ReveiveErase","resizable=1,scrollbars=1,width=960,height=640")
			end if
			win.focus()
		end function
				
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
			
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub AmountFrom_OnBlur()
			if cstr(frmInput.AmountFrom.value) <> "" then frmInput.AmountFrom.value = GetLong(frmInput.AmountFrom.value)
		end sub
		sub AmountTo_OnBlur()
			if cstr(frmInput.AmountTo.value) <> "" then	frmInput.AmountTo.value = GetLong(frmInput.AmountTo.value)
		end sub
		sub Fin_No_OnBlur()
			frmInput.Fin_No.value = FitReceiveNo(frmInput.Fin_No.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="ReceiveView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap colspan=2>������s&nbsp;
				<select name="FIN_BANK_ID" class=pt9n onkeydown="ResetEnter()" style="width:240"><%=ShowBankListAll(FIN_BANK_ID)%></select>
				������<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList()">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">					
				�戵&nbsp;<SELECT name="ClientBelong" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowShopList(ClientBelong)%></select>
			<TR><TD nowrap>
				�䒠�ԍ�&nbsp;<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">			
				������&nbsp;<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�c��&nbsp;<select name="ClientSales" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowEmployList(DepartSales, ClientSales)%></select>
				<TD rowspan=2 width=100 align=right>
					<INPUT class=pt9n style="width:80px;height:40px;" TYPE=SUBMIT VALUE="����">					
			<TR><TD nowrap>
				�����ԍ�&nbsp;<input class=si name="Fin_No" value="<%=Fin_No%>" maxlength=10 size=10 onkeydown="ResetEnter()">			
				�����z&nbsp;<input class=sn name="AmountFrom" value="<%=AmountFrom%>" maxlength=10 size=10 onkeydown="ResetEnter()">		
				�`<input class=sn name="AmountTo" value="<%=AmountTo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				����&nbsp;<select name="FIN_SECURITIES" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowCategoryList("Securities", FIN_SECURITIES, 0)%></select>
		</table>
		<br>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if ClientRef <> "" then	strSel = strSel & " AND (ClientRef = '" & FitSel(ClientRef) & "' OR FIN_CLIENT_NAME LIKE '% " & FitSel(ClientRef) & "%')"
	if DateFrom <> "" then strSel = strSel & " AND FIN_DATE >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND FIN_DATE <= '" & Date2Str(DateTo) & "'"
	if Fin_No <> "" then strSel = strSel & " AND FIN_NO = '" & FitSel(Fin_No) & "'"
	if AmountFrom <> "" then strSel = strSel & " AND FIN_AMOUNT >= " & AmountFrom
	if AmountTo <> "" then strSel = strSel & " AND FIN_AMOUNT <= " & AmountTo
	if FIN_BANK_ID <> 0 then strSel = strSel & " AND FIN_BANK_ID = " & FIN_BANK_ID
	if FIN_SECURITIES <> "" then strSel = strSel & " AND FIN_SECURITIES = '" & FIN_SECURITIES & "'"
	if ClientBelong <> "" then strSel = strSel & " AND CTM_BELONG = '" & ClientBelong & "'"
	if ClientSales <> 0 then strSel = strSel & " AND CTM_SALESMNGR = " & ClientSales
	if JobCode <> "" then strSel = strSel & " AND FIN_NO IN (SELECT DISTINCT BIZ_FIN_NO FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0 AND BIZ_JOBCODE LIKE '" & FitSel(JobCode) & "')"
		
	with recset
		TotalAmount = 0
		strSql = "SELECT SUM(CAST(FIN_AMOUNT AS float)) AS TotalAmount FROM TBL_CTM_FIN AS F INNER JOIN"
		strSql = strSql & " (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_BELONG, CTM_SALESMNGR FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'R' AND FIN_ORIGINAL = 1 AND FIN_DELETED = 0 AND CONFIRM_ID <> 0"		'���폜�@�m���
		if strSel <> "" then strSQL = strSQL & strSel
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then TotalAmount = GetDouble(.Fields("TotalAmount"))
		.Close
		
		strSql = "SELECT FIN_NO, FIN_TYPE, ClientRef, CTM_BELONG, CTM_SALESMNGR, FIN_CLIENT_NAME, FIN_DATE, FIN_AMOUNT, FIN_SECURITIES, FIN_DESCRIPTION, FIN_CURRENT, ERASE_ID"
		strSql = strSql & " FROM TBL_CTM_FIN AS F INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_BELONG, CTM_SALESMNGR FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'R' AND FIN_ORIGINAL = 1 AND FIN_DELETED = 0 AND CONFIRM_ID <> 0"		'���폜�@�m���
		if strSel <> "" then strSQL = strSQL & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY FIN_NO"
		case 1:		strSql = strSql & " ORDER BY ClientRef, FIN_NO"
		case 2:		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
		case 3:		strSql = strSql & " ORDER BY FIN_AMOUNT, FIN_DATE, FIN_NO"
		end select			
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			.PageSize = myPageSize
			lngPageCount = .PageCount

			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr>
				<td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%></td>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:30px;height:20px" value="GO">
				<%end if%>
				</td>
			</TR>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup align=center>
			<colgroup span=4 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=2 align=center>
		  <TR align=center class=pt9 height=24>
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�����ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">������
			<TD class=line nowrap>�戵
			<TD class=line nowrap>�c��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">������
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�����z
			<TD class=line nowrap>����
			<TD class=line nowrap>����
<%
			sumAmount = 0
			Do Until .EOF
				lngCount = lngCount + 1			
				If lngCount > lngPageNumber * myPageSize Then
					Exit Do
				Else
					FIN_NO = GetString(.Fields("FIN_NO"))
					FIN_MEMO = GetString(.Fields("FIN_DESCRIPTION"))
					if GetLong(.Fields("ERASE_ID"))	= 0 then
						if GetLong(.Fields("FIN_CURRENT")) = 0 then
							status = "<font color=red>��</font>"
						else
							status = "<font color=blue>�C</font>"
						end if
					else
						status = "<font color=black>��</font>"
					end if
					FIN_CURRENT = GetLong(.Fields("FIN_CURRENT"))
%>
			<TR height=24 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
				 onclick="ShowDetail('<%=FIN_NO%>', <%=FIN_CURRENT%>)">
				<TD class=line><%=lngCount%><BR>
				<TD class=line><%=ShowVoucherNo(.Fields("FIN_NO"))%><BR>
				<TD class=line nowrap title="<%=GetString(.Fields("FIN_CLIENT_NAME"))%>"><%=GetString(.Fields("ClientRef"))%><BR>
				<TD class=line><%=GetShopName(.Fields("CTM_BELONG"))%><BR>
				<TD class=line><%=GetEmployName(.fields("CTM_SALESMNGR"), "F")%><BR>
				<TD class=line style="color:green"><%=Str2Date(.Fields("FIN_Date"))%><BR>
				<TD class=line nowrap><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
				<TD class=line nowrap><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
				<TD class=line><%=status%>
<%	
					sumAmount = sumAmount + GetLong(.Fields("FIN_AMOUNT"))
				end if
				.movenext
			loop
%>
			<TR height=24>
				<TD colspan=4 align=left><%if lngCount > lngPageNumber * myPageSize then response.write "<font color=red>��������܂�...</font>"%>
				<TD class=line align=right>�� �v
				<TD class=line align=right colspan=2><%=formatnumber(TotalAmount, 0, true)%><BR>
		</TABLE>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%

function ShowBankListAll(myDft)
dim mySql
dim myRec
dim myCon
dim myBank
dim buf
	buf = "<option value=0>���ׂ�"
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT BANK_ID, BANK_CD, BANK_NAME, BANK_BRANCH, BANK_ACCOUNT_NO, BANK_ACCOUNT_TYPE"
		mySql = mySql & " FROM MST_BANK WHERE BANK_DELETED = 0" 
		if CheckAccountLevel() < 2 then mySql = mySql & " AND (BANK_DIVISION = 0 or BANK_DIVISION = " & finReceive & ")"
		mySql = mySql & " ORDER BY BANK_DIVISION, BANK_CD"
'response.write mySql
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		do while not .eof		
			myBank = GetString(.fields("BANK_NAME")) & " " & GetString(.fields("BANK_BRANCH"))
			myBank = myBank & " " & left(GetString(.fields("BANK_ACCOUNT_TYPE")), 2)
			myBank = myBank & " "  & GetString(.fields("BANK_ACCOUNT_NO"))
			buf = buf & "<option value=" & chr(34) & GetLong(.fields("BANK_ID")) & chr(34)
			if GetLong(.fields("BANK_ID")) = myDft then buf = buf & " selected"
			buf = buf & ">" & myBank
			.movenext
		loop
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
	
	ShowBankListAll = buf	
end function
%>