<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�a����ꗗ�Ɖ���
'----------------------------------------------

'on error resume next
dim myMode
dim myPage
dim myPageSize

	AccountBelong = GetPost(request("AccountBelong"))
	'if AccountBelong = "" then AccountBelong = "O"
	
	myPageSize = GetUserPageSize(500)
	myPageSize = 2000
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		SelDate = date
		if day(SelDate) <= gsSysCloseDay then 
			SelDate = dateadd("m", -1, SelDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
	else
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
		ClientRef = GetPost(request("ClientRef"))
		ClientCode = GetCtmCode(ClientRef, 0) 	
	end if
	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
%>
<HTML>
<HEAD>
	<TITLE>�a����ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		sub InitForm()
			frmInput.btnSearch.focus()
		end sub
		
		function ShowDetail() 
		dim win
			set win = window.open("AccountDetail.asp","AccountDetail","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<!----------��������--------->
	<FORM METHOD="POST" ACTION="AccountDeposit.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<TABLE class=pt9>
			<TR><TD nowrap><font class=pt9g>�a����c��</font>�@
				���Ӑ於<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�Ɖ�x&nbsp;
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;��
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</TABLE>
	</FORM>
		
	<!----------��������--------->
<%
	if myMode > 0 then
%>
<div id=list>
<font color=gray>�Ώی��x�F</font><%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��
<%if ClientCode <> "" then response.write "<font color=gray>���Ӑ�F</font>" & getFullName(ClientCode)%>
<%			
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		
		with recset
			myBalance = 0
			if ClientCode = "" then
				'����J�z�擾
				strSql = "SELECT SUM(CASE FIN_CREDIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE (0 - FIN_AMOUNT) END) AS TTL_AMOUNT FROM TBL_CTM_FIN"
				strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_DATE < '" & AccountFrom & "'"
				strSql = strSql & " AND (FIN_DEBIT = " & acntOverReceive & " OR FIN_CREDIT = " & acntOverReceive & ")"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then myBalance = GetLong(.Fields("TTL_AMOUNT"))
				.Close
%>
		<TABLE width=800 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup align=left>
			<colgroup span=3 align=right>
			<colgroup align=left>
			<TR class=pt9>
				<TD class=line width=4%>��				
				<TD class=line width=15% nowrap>���t
				<TD class=line width=12% nowrap>�`�[�ԍ�
				<TD class=line width=12% nowrap>�a�����
				<TD class=line width=12% nowrap>�a�������
				<TD class=line width=15% nowrap>�c��
				<TD class=line width=30% nowrap>���Ӑ�
			<TR>
				<TD class=line colspan=2>
				<TD class=line align=center>�J�z
				<TD class=line colspan=2>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
<%
			
				strSql = "SELECT FIN_NO, FIN_BELONG, FIN_DATE, FIN_CLIENT_NAME, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_DESCRIPTION FROM TBL_CTM_FIN "
				strSql = strSql & " WHERE FIN_DELETED = 0 AND (FIN_DEBIT =" & acntOverReceive & " OR FIN_CREDIT = " & acntOverReceive & ")"
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
				strSql = strSql & " ORDER BY FIN_DATE, FIN_CLIENT_NAME"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if .EOF then
					response.write "<TR><TD colspan=6><font class=pt9r>�Y������f�[�^�͌�����܂���ł����B</font>"
				else
					cnt = 1
					myDebit = 0
					myCredit = 0
					sumDebit = 0
					sumCredit = 0
					myDate = GetString(.Fields("FIN_DATE"))
					myName = GetString(.fields("FIN_CLIENT_NAME"))
					do while not .EOF
						if cnt > myPageSize then exit do
						
						if myDate <> GetString(.Fields("FIN_DATE")) or myName <> GetString(.Fields("FIN_CLIENT_NAME")) then
							sumDebit = sumDebit + myDebit
							sumCredit = sumCredit + myCredit
%>
			<TR>
				<TD class=line align=center><%=cnt%>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line <%=ShowTitle(myNo, 10)%>><%=StringCut(myNo, 13)%>
				<TD class=line><%=formatnumber(myDebit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myCredit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
				<TD class=line><%=ResetCorpName(myName)%>
<%	
							myDebit = 0
							myCredit = 0
							myDate = GetString(.Fields("FIN_DATE"))
							myName = GetString(.fields("FIN_CLIENT_NAME"))
							myNo = GetString(.Fields("FIN_NO"))
							
							cnt = cnt + 1
						else
							if myNo <> "" then myNo = myNo & vbcrlf
							myNo = myNo & GetString(.Fields("FIN_NO"))
						end if
					
						myAmount = GetLong(.Fields("FIN_AMOUNT"))	
						if GetLong(.fields("FIN_CREDIT")) = acntOverReceive then
							myDebit = myDebit + myAmount
							myBalance = myBalance + myAmount
						elseif GetLong(.fields("FIN_DEBIT")) = acntOverReceive then
							myCredit = myCredit + myAmount
							myBalance = myBalance - myAmount
						end if
						.movenext
					loop
					.Close
					
					if cnt > myPageSize then
						response.write "<TR><TD colspan=6><font class=pt9r>�Y���f�[�^�� " & myPageSize & " ���ȏ㒴���܂����B</font>"
					else
%>
			<TR>
				<TD class=line align=center><%=cnt%>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line <%=ShowTitle(myNo, 10)%>><%=StringCut(myNo, 10)%>
				<TD class=line><%=formatnumber(myDebit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myCredit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
				<TD class=line><%=ResetCorpName(myName)%>
<%
						if cnt > 0 then
							sumDebit = sumDebit + myDebit
							sumCredit = sumCredit + myCredit
%>
			<TR>
				<TD colspan=3 align=center>���z���v
				<TD class=line><%=formatnumber(sumDebit, 0, true)%>
				<TD class=line><%=formatnumber(sumCredit, 0, true)%>
				<TD class=line>(<%=formatnumber(sumDebit - sumCredit, 0, true)%>)
<%if left(myDate, 6) >= left(Date2Str(date), 6) then %>
				<TD class=line style="cursor:hand;color:blue" onmousedown="ShowDetail()">�a����c�蕪����
<%end if%>
<%
						end if
					end if
%>			
		</TABLE>
<%
				end if
			else			
				'����J�z�擾
				strSql = "SELECT SUM(CASE FIN_CREDIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE (0 - FIN_AMOUNT) END) AS TTL_AMOUNT FROM TBL_CTM_FIN"
				strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_CLIENT_CD = '" & ClientCode & "' AND FIN_DATE < '" & AccountFrom & "'"
				strSql = strSql & " AND (FIN_DEBIT = " & acntOverReceive & " OR FIN_CREDIT = " & acntOverReceive & ")"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then myBalance = GetLong(.Fields("TTL_AMOUNT"))
				.Close
%>
		<TABLE width=800 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup align=left>
			<colgroup span=3 align=right>
			<colgroup align=left>
			<TR class=pt9>
				<TD class=line width=4%>��				
				<TD class=line width=15% nowrap>���t
				<TD class=line width=12% nowrap>�`�[�ԍ�
				<TD class=line width=12% nowrap>�a�����
				<TD class=line width=12% nowrap>�a�������
				<TD class=line width=15% nowrap>�c��
				<TD class=line width=30% nowrap>�E�v
			<TR>
				<TD class=line colspan=2>
				<TD class=line align=center>�J�z
				<TD class=line colspan=2>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
<%
			
				strSql = "SELECT FIN_DATE, FIN_NO, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_DESCRIPTION FROM TBL_CTM_FIN "
				strSql = strSql & " WHERE FIN_DELETED = 0  AND (FIN_DEBIT =" & acntOverReceive & " OR FIN_CREDIT = " & acntOverReceive & ")"
				strSql = strSql & " AND FIN_CLIENT_CD = '" & ClientCode & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
				strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if .EOF then
					response.write "<TR><TD colspan=6><font class=pt9r>�Y������f�[�^�͌�����܂���ł����B</font>"
				else
					cnt = 1
					do while not .EOF
						if cnt > myPageSize then exit do
						
						myDate = GetString(.Fields("FIN_Date"))
						myAmount = GetLong(.Fields("FIN_AMOUNT"))	
						myDebit = 0:		myCredit = 0
						if GetLong(.fields("FIN_CREDIT")) = acntOverReceive then
							myDebit = GetLong(.Fields("FIN_AMOUNT"))	
							myBalance = myBalance + myAmount	
						elseif GetLong(.fields("FIN_DEBIT")) = acntOverReceive then
							myCredit = GetLong(.Fields("FIN_AMOUNT"))
							myBalance = myBalance - myAmount
						end if
							
						sumDebit = sumDebit + myDebit
						sumCredit = sumCredit + myCredit
%>
			<TR>
				<TD class=line align=center><%=cnt%>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line><%=GetString(.fields("FIN_NO"))%>
				<TD class=line><%=formatnumber(myDebit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myCredit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
				<TD class=line><%=StringCut(GetString(.fields("FIN_DESCRIPTION")), 10)%><br>
<%	
						cnt = cnt + 1
						.movenext
					loop
					.Close

					if cnt > myPageSize then
						response.write "<TR><TD colspan=6><font class=pt9r>�Y���f�[�^�� " & myPageSize & " ���ȏ㒴���܂����B</font>"
					elseif cnt > 1 then
%>
			<TR>
				<TD colspan=3 align=center>���z���v
				<TD class=line><%=formatnumber(sumDebit, 0, true)%>
				<TD class=line><%=formatnumber(sumCredit, 0, true)%>
				<TD class=line>(<%=formatnumber(sumDebit - sumCredit, 0, true)%>)
<%
					end if
%>
		</TABLE>
<%
				end if
			end if
		end with
		
		set Recset = nothing
		CloseDB Conn
%>		
</div>
<%
	end if
%>
</BODY></HTML>
