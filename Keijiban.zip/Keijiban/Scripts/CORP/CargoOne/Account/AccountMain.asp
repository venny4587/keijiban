<HTML>
<HEAD>
<TITLE>���茳��</TITLE>
</HEAD>
	<FRAMESET rows="60,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="AccountMenu.asp" NAME="amenu" MARGINWIDTH="0" MARGINHEIGHT="0" scrolling=no>
		<FRAME SRC="" NAME="abody" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>