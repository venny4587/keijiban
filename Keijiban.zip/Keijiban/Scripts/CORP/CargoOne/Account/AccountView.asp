<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����茳���ꗗ�Ɖ���
'----------------------------------------------

'on error resume next
dim FinStr
dim myMode
dim myPageSize
dim lngPageNumber
		
	'myPageSize = GetUserPageSize(500)
	myPageSize = 2000
		
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		ClientRef = ""
		if gsSysAccountDay = 99 then 
			DateFrom = Str2Date(left(Date2Str(date),6) & "01")
		else
			myDate = dateadd("m", -1, date)
			DateFrom = cdate(year(myDate) & gsDateSign & month(myDate) & gsDateSign & (gsSysAccountDay + 1))
		end if
		DateTo = formatDate(date)
		ClientCode = ""
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		ClientCode = GetCtmCode(ClientRef, 0) 
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����茳���ꗗ�Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowList() 
		dim win
			set win = window.open("ClientSearch.asp?cd=" & frmInput.ClientRef.value,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
				
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="AccountView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<table class=pt9>
			<TR><TD nowrap><font class=pt9g>���茳��</font>�@
				���Ӑ�<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList()">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�Ɖ���t&nbsp;<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">	
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">					
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if ClientCode <> "" then 
		strSel = strSel & " AND FIN_CLIENT_CD = '" & ClientCode & "'"
	elseif ClientRef <> "" then	
		strSel = strSel & " AND FIN_CLIENT_NAME LIKE '% " & FitSel(ClientRef) & "%'"
	end if
	if DateFrom <> "" then strSel = strSel & " AND FIN_DATE >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND FIN_DATE <= '" & Date2Str(DateTo) & "'"	
	
	with recset
		strSql = "SELECT FIN_DATE, FIN_NO, FIN_TYPE, FIN_CLIENT_CD, FIN_CLIENT_NAME, DebitName, CreditName, FIN_AMOUNT, FIN_TAX, FIN_ORIGINAL, BankName FROM TBL_CTM_FIN"
		strSql = strSql & " INNER JOIN (SELECT ACNT_ID, ACNT_NAME AS DebitName FROM MST_ACCOUNT) AS D ON TBL_CTM_FIN.FIN_DEBIT = D.ACNT_ID"
		strSql = strSql & " INNER JOIN (SELECT ACNT_ID, ACNT_NAME AS CreditName FROM MST_ACCOUNT) AS C ON TBL_CTM_FIN.FIN_CREDIT = C.ACNT_ID"
		strSql = strSql & " INNER JOIN (SELECT BANK_ID, BANK_NAME+BANK_BRANCH+' '+BANK_ACCOUNT_TYPE+BANK_ACCOUNT_NO AS BankName FROM MST_BANK) AS B"
		strSql = strSql & "  ON TBL_CTM_FIN.FIN_BANK_ID = B.BANK_ID"
		strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_DATE <= '" & Date2Str(date) & "' AND ERASE_ID <> 0 " & strSel
		strSql = strSql & " ORDER BY FIN_DATE, FIN_CLIENT_NAME, FIN_NO, FIN_ORIGINAL DESC, FIN_TYPE"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
			
%>
<div id=list>
		<TABLE width=800 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=3 align=center>
			<colgroup align=right>
			<colgroup span=2 align=center>
			<colgroup align=right>
			<colgroup align=left>
		  <TR class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>���t
			<TD class=line nowrap>�`�[�ԍ�
			<TD class=line colspan=2 align=center>�ؕ�
			<TD class=line colspan=2 align=center>�ݕ�
			<TD class=line nowrap>�����
<%
			cnt = 0
			sumDebit = 0
			sumCredit = 0
			ttlDebit = 0
			ttlCredit = 0
			myDate = ""
			myName = ""
			myNo = ""
			Do Until .EOF	
				if cnt > myPageSize then exit do
					
				If myDate <> GetString(.Fields("FIN_DATE")) or myName <> GetString(.Fields("FIN_CLIENT_NAME")) Then
					cnt = cnt + 1
					ttlDebit = ttlDebit + sumDebit
					ttlCredit = ttlCredit + sumCredit
					if myDate <> "" then 
%>
		  <TR>
			<TD colspan=3>
			<TD class=line nowrap><%=formatnumber(sumDebit, 0, true)%>
			<TD colspan=2>
			<TD class=line nowrap><%=formatnumber(sumCredit, 0, true)%>
			<%if sumDebit <> sumCredit then %><TD bgcolor=red>(<%=sumDebit - sumCredit%>)<%end if%>
<%
					end if
					
					sumDebit = 0
					sumCredit = 0
					myDate = GetString(.Fields("FIN_DATE"))
					myName = GetString(.Fields("FIN_CLIENT_NAME"))
					myNo = GetString(.Fields("FIN_NO"))
%>
			<TR bgcolor="#E0E0FF">
				<TD class=line><%=cnt%><BR>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line nowrap><%=ShowVoucherNo(myNo)%><BR>
				<TD class=line style="color:gray">���z
				<TD class=line style="color:gray">�Ȗ�
				<TD class=line style="color:gray">�Ȗ�
				<TD class=line style="color:gray">���z
				<TD class=line nowrap <%=ShowTitle(myName, 20)%>><%=StringCut(myName,20)%><BR>
<%
				end if
				
				myDebit = 0:	myDebitTax = 0
				if GetString(.fields("DebitName")) <> "����" then
					myDebit = getLong(.fields("FIN_AMOUNT"))
					myDebitTax = getLong(.fields("FIN_TAX"))					
					sumDebit = sumDebit + myDebit + myDebitTax
				end if
					
				myCredit = 0:	myCreditTax = 0
				if GetString(.fields("CreditName")) <> "����" then
					myCredit = getLong(.fields("FIN_AMOUNT"))
					myCreditTax = getLong(.fields("FIN_TAX"))
					sumCredit = sumCredit + myCredit + myCreditTax
				end if
%>
			<TR>
				<TD colspan=2>
<%
				if myNo = GetString(.Fields("FIN_NO")) then
					response.write "<TD>"
				else	
					myNo = GetString(.Fields("FIN_NO"))	%>
					<TD class=line nowrap bgcolor="#E0E0FF"><%=ShowVoucherNo(myNo)%><BR>
<%				end if %>
				<TD class=line nowrap align=right><%=formatnumber(GetLong(myDebit), 0, false)%><BR>
				<%if myDebitTax <> 0 then response.write "(" & formatnumber(myDebitTax, 0, true) & ")"%>
				<TD class=line nowrap><%=ShowAccountName(.fields("DebitName"))%>
				<TD class=line nowrap><%=ShowAccountName(.fields("CreditName"))%>
				<TD class=line nowrap align=right><%=formatnumber(GetLong(myCredit), 0, false)%><BR>
				<%if myCreditTax <> 0 then response.write "(" & formatnumber(myCreditTax, 0, true) & ")"%>
<%	
				if GetString(.fields("DebitName")) = "��s" or GetString(.fields("CreditName")) = "��s" then
					response.write "<td>(" & GetString(.fields("BankName")) & ")"
				end if
				.movenext
			loop
			ttlDebit = ttlDebit + sumDebit
			ttlCredit = ttlCredit + sumCredit
%>
		  <TR>
			<TD colspan=3>
			<TD class=line nowrap><%=formatnumber(sumDebit, 0, true)%>
			<TD colspan=2>
			<TD class=line nowrap><%=formatnumber(sumCredit, 0, true)%>
			<%if sumDebit <> sumCredit then %><TD bgcolor=red>(<%=sumDebit - sumCredit%>)<%end if%>
		  <TR bgcolor="#E0E0FF">
			<TD class=line colspan=3>���v
			<TD class=line nowrap><%=formatnumber(ttlDebit, 0, true)%>
			<TD class=line>�ؕ�
			<TD class=line>�ݕ�
			<TD class=line nowrap><%=formatnumber(ttlCredit, 0, true)%>
			<TD class=pt12r>�@<b><%=formatnumber(ttlDebit - ttlCredit, 0, false)%></b><BR>
		</TABLE>
</div>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowAccountName(myName)
	if myName = "����" then
		ShowAccountName = "<font color=gray>" & myName & "</font>"
	else
		ShowAccountName = myName
	end if
end function
%>