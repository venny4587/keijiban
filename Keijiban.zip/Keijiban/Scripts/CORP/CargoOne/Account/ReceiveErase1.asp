<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�c�Ɠ����`�[�m�F���
'
'	mode:	1 -- �c�ƔC��
'			2 -- �c�Ə���
'			3 -- �o���m�F
'			4 -- ��������
'
'	FIN_CURRENT		0:����/1:�c��/2:����
'----------------------------------------------

'on error resume next
dim mode
dim ChargeNos

	FIN_NO = GetPost(request("FIN_NO"))	
	if FIN_NO <> "" then
		
		OpenSql Conn, SqlServerName, DataBaseName
		
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
			strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 1 AND FIN_NO = '" & FitSel(FIN_NO) & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				FIN_No = GetString(.fields("FIN_NO"))
				FIN_DATE = Str2Date(.fields("FIN_DATE"))
				FIN_CLIENT_CD = GetString(.fields("FIN_CLIENT_CD"))		
				FIN_CLIENT_NAME = GetString(.fields("FIN_CLIENT_NAME"))					
				FIN_CLIENT_PIC = GetString(.fields("FIN_CLIENT_PIC"))
				FIN_BANK_ID = GetLong(.fields("FIN_BANK_ID"))
				FIN_BANK_NAME = GetBankName(FIN_BANK_ID)
				FIN_AMOUNT = GetLong(.fields("FIN_AMOUNT"))
				FIN_SECURITIES = GetString(.fields("FIN_SECURITIES"))
				FIN_SECURITIES_NO = GetString(.fields("FIN_SECURITIES_NO"))
				FIN_SECURITIES_DATE = Str2Date(.fields("FIN_SECURITIES_DATE"))
				
				FIN_BATCH = GetString(.fields("FIN_BATCH"))
				FIN_BILLNO = GetString(.fields("FIN_BILLNO"))
				FIN_JOBCODE = GetString(.fields("FIN_JOBCODE"))
				FIN_DESCRIPTION = GetString(.fields("FIN_DESCRIPTION"))				
				FIN_MEMO = GetString(.fields("FIN_MEMO"))
				FIN_REMARKS = GetString(.fields("FIN_REMARKS"))	
				
				FIN_CREATER = GetLong(.fields("FIN_CREATER"))
				FIN_CREATED = GetDate(.fields("FIN_CREATED"))
				CONFIRM_ID = GetLong(.fields("CONFIRM_ID"))
				CONFIRM_DATE = GetDate(.fields("CONFIRM_DATE"))
				ERASE_ID = GetLong(.fields("ERASE_ID"))
				ERASE_DATE = GetDate(.fields("ERASE_DATE"))
				FIN_MONTH = GetString(.fields("FIN_MONTH"))
				FIN_CURRENT = GetLong(.fields("FIN_CURRENT"))
				
			end if
			.close
		end with
		
		if CONFIRM_ID = 0 then
			response.write "�Y�������`�[�͂܂��m�肳��Ă��܂���B"	
		else
%>
<html>
<HEAD>
	<TITLE>�����`�[�d��Ɖ�</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		sub DoUnErase()
			if msgbox ("�Y�������`�[�̏������������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 4
			frmInput.submit()
		end sub
				
		sub DoShortCut()
			if window.event.keyCode=27 then window.close() 
		end sub
		
		sub DoReset()
		dim sum, nos, ttl
			sum = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then
					if left(obj.name,4) = "DATA" and obj.checked then
						nos = nos & "," & GetLeft(obj.value, ".")
						ttl = ttl & "," & GetRight(obj.value, ".")
						sum = sum + GetLong(GetRight(obj.value, ".")) 	
					end if
				end if
			next
			frmInput.ChargeNos.value = mid(nos, 2)
			frmInput.ChargeTotal.value = mid(ttl, 2)
			frmInput.ChargeAmount.value = formatnumber(sum, 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub
		
		sub DataSave(mode)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'				exit sub
'			end if 
			if GetLong(frmInput.BankPostage.value) > <%=gsMaxPostage%> then 
				msgbox "���͂����ʐM��͑������ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if GetLong(frmInput.FromReceive.value) <> 0 and _
			   GetLong(frmInput.OverReceive.value) <> 0 then
				msgbox "�u�a������v�Ɓu�a����ցv�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if 
			if GetLong(frmInput.MassProfit.value) <> 0 and _
			   GetLong(frmInput.MassLoss.value) <> 0 then
				msgbox "�u�G���v�Ɓu�G���v�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if
			if checkText("FIN_MEMO","��������", 0) = false then exit sub
			if checkLen("FIN_MEMO","��������", 250) = false then exit sub
			if checkText("FIN_REMARKS","�c�ƃ���", 0) = false then exit sub
			if checkLen("FIN_REMARKS","�c�ƃ���", 250) = false then exit sub
			if mode = 3 then
				if clng(frmInput.EraseResult.value) <> 0 then 
					msgbox "�ؕ����z�͑ݕ����z�ƍ���Ȃ��ł��B", 48, "�m�F���b�Z�[�W"
					exit sub
				end if
				if msgbox ("�Y�������`�[���������݂��Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub OverReceive_OnBlur()
			frmInput.OverReceive.value = formatnumber(GetLong(frmInput.OverReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub FromReceive_OnBlur()
			frmInput.FromReceive.value = formatnumber(GetLong(frmInput.FromReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'			end if 
		end sub		
		sub MassProfit_OnBlur()
			frmInput.MassProfit.value = formatnumber(GetLong(frmInput.MassProfit.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub MassLoss_OnBlur()
			frmInput.MassLoss.value = formatnumber(GetLong(frmInput.MassLoss.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub			
		sub FromDraft_OnBlur()
			frmInput.FromDraft.value = formatnumber(GetLong(frmInput.FromDraft.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub OverDraft_OnBlur()
			frmInput.OverDraft.value = formatnumber(GetLong(frmInput.OverDraft.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub BankPostage_OnBlur()
			frmInput.BankPostage.value = formatnumber(GetLong(frmInput.BankPostage.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub	
		function DoCalculate()
		dim debit, credit 
			debit = GetLong(frmInput.FIN_AMOUNT.value) + GetLong(frmInput.FromReceive.value) + GetLong(frmInput.MassLoss.value)
			debit = debit + GetLong(frmInput.BankPostage.value) + GetLong(frmInput.FromDraft.value)
			credit = GetLong(frmInput.ChargeAmount.value) + GetLong(frmInput.OverReceive.value) + GetLong(frmInput.MassProfit.value)
			credit = credit + GetLong(frmInput.OverDraft.value)
			DoCalculate = debit - credit
		end function
		
		function DoUseDeposit(myAmount)
<%if ERASE_ID = 0 then%>
			frmInput.FromReceive.value = formatnumber(GetLong(myAmount), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
<%end if%>
		end function	
	</SCRIPT>
</Head>
<body leftmargin=10 topmargin=10 class=pt12 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
<FORM name=frmInput action="ReceiveSave1.asp" method=post>
	<input type=hidden name="mode" value="0">
<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
  <tr><td width=50% valign=top>
  <!--�����F�����`�[���-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>�������`�[���&nbsp;
	  	<td width=50% nowrap>�����ԍ��F<%=FIN_NO%><input type=hidden name="FIN_NO" value="<%=FIN_NO%>">
	</table>
	<hr width=98% size=1 color=blue>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
	  <TR height=30>
		<TD nowrap colspan=2>
			������&nbsp;<input class=mi name="FIN_CLIENT_NAME" size=42 value="<%=FIN_CLIENT_NAME%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
			����S��&nbsp;<input class=mj name="FIN_CLIENT_PIC" size=20 value="<%=FIN_CLIENT_PIC%>" onkeydown="ResetEnter()" readonly>
			������&nbsp;<input class=mi name="FIN_DATE" size=10 value="<%=FIN_DATE%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
			������s&nbsp;<input class=mi name="FIN_BANK_ID" size=40 value="<%=FIN_BANK_NAME%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
			�����K�v&nbsp;<input class=mz name="FIN_DESCRIPTION" size=40 value="<%=FIN_DESCRIPTION%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap>
			�o�b�`�ԍ�&nbsp;<input class=mi name="FIN_BATCH" size=6 value="<%=FIN_BATCH%>" onkeydown="ResetEnter()" readonly>
		<TD nowrap class=pt12b>
			�����z&nbsp;<input class=mn name="FIN_AMOUNT" size=12 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap>
			�䒠�ԍ�&nbsp;<input class=mi name="FIN_JOBCODE" size=10 value="<%=FIN_JOBCODE%>" onkeydown="ResetEnter()" readonly>
		<TD nowrap>
			�����ԍ�&nbsp;<input class=mi name="FIN_BILLNO" size=10 value="<%=FIN_BILLNO%>" onkeydown="ResetEnter()" readonly>
	  <TR height=30>
		<TD nowrap colspan=2>
	  		����&nbsp;<input class=mi name="FIN_SECURITIES" size=6 value="<%=FIN_SECURITIES%>" onkeydown="ResetEnter()" readonly>
			����ԍ�&nbsp;<input class=mi name="FIN_SECURITIES_NO" size=10 value="<%=FIN_SECURITIES_NO%>" onkeydown="ResetEnter()" readonly>
			�T�C�g&nbsp;<input class=mi name="FIN_DATE" size=5 value="<%=right(FIN_SECURITIES_DATE, 5)%>" onkeydown="ResetEnter()" readonly>
	  <TR>
		<TD colspan=2>��������<br><textarea class=pt12n name="FIN_MEMO" rows=3 style="width:400"><%=FIN_MEMO%></textarea>
	  <TR>
		<TD colspan=2>��������<br><textarea class=mz name="FIN_REMARKS" rows=3 style="width:400"><%=FIN_REMARKS%></textarea>
	</TABLE>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=30 align=center valign=bottom>
		<TD width=10% class=pt12g>�쐬��<TD width=15% class=gline><%=GetEmployName(FIN_CREATER, "F")%><br>
		<TD width=10% class=pt12g>�m�F��<TD width=15% class=gline><%=GetEmployName(CONFIRM_ID, "F")%><br>
		<TD width=10% class=pt12g>������<TD width=15% class=gline><%=GetEmployName(ERASE_ID, "F")%><br>
	  <TR height=30 align=center valign=bottom>
		<TD class=pt12g>�쐬��<TD class=gline><%=formatDate(FIN_CREATED)%><br>
		<TD class=pt12g>�m�F��<TD class=gline><%=formatDate(CONFIRM_DATE)%><br>
		<TD class=pt12g>������<TD class=gline><%=formatDate(ERASE_DATE)%><br>
	</TABLE>
	<br>
<%
dim FIN_DEPOSIT

	myList = ShowAccountDetail(finPayment, Conn, FIN_NO, FIN_CLIENT_CD, FIN_DEPOSIT)
%>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>���a����c���F&nbsp;<input type=hidden name="FIN_DEPOSIT" value="<%=FIN_DEPOSIT%>">
<%if FIN_DEPOSIT >= 0 then%>
	  	<td width=50% nowrap align=right>\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%else%>
	  	<td width=50% nowrap align=right style="color:blue">\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%end if%>
	</table>
	<HR width=100% size=1 color=green>
  <!--�����F�c�����׏��-->
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
	<TR align=center height=20 class=pt12>
		<TD class=line nowrap>��
		<TD class=line nowrap>�`�[�ԍ�
		<TD class=line nowrap>���o����
		<TD class=line nowrap>�a�����
		<TD class=line nowrap>�a������
		<TD class=line nowrap>�c��
	<%=myList%>
	</TABLE>
	
  <td width=50% valign=top>
  <!--�E���F�Ɩ��������-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>���Ɩ��������&nbsp;
	  	<td width=50% nowrap>
	</table>
	<hr width=98% size=1 color=blue>
<%
		myEraseNo = ""
		FIN_BATCHS = ""
		FIN_BILLNOS = ""
		with recset
			strSql = "SELECT ERASE_BATCH, ERASE_BIZ_NO FROM TBL_CTM_ERASE WHERE ERASE_FIN_NO = '" & FIN_NO & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not .eof
				if GetString(.Fields("ERASE_BATCH")) <> "" then FIN_BATCHS = FIN_BATCHS & "," & GetString(.Fields("ERASE_BATCH"))
				if GetString(.Fields("ERASE_BIZ_NO")) <> "" then FIN_BILLNOS = FIN_BILLNOS & "," & GetString(.Fields("ERASE_BIZ_NO"))
				.movenext
			loop
			.Close
		end with
		myEraseNo = FIN_BATCHS & FIN_BILLNOS

		strSql = ""
		if myEraseNo <> "" then			'���������ݎ擾
			if FIN_BATCHS <> "" then					'�o�b�`�ԍ�
				FIN_BATCHS = ResetEraseNos(mid(FIN_BATCHS, 2))
				strSql = "SELECT BatchNo AS ChargeNo, BatchClient AS ChargeClient, BatchBillDay AS ChargeDate, BatchPayDay AS ChargePayDay, ConfirmerID, FinisherID"
				strSql = strSql & ", BatchAmount AS ChargeTotal, '�o�b�`' AS JobCode FROM TBL_CTM_BATCH WHERE Deleted = 0 AND BatchNo IN (" & FIN_BATCHS & ")"
			end if
				
			if FIN_BILLNOS <> "" then					'�����ԍ�	
				FIN_BILLNOS = ResetEraseNos(mid(FIN_BILLNOS, 2))
				if strSql <> "" then strSql = strSql & " UNION "
				strSql = strSql & "SELECT ChargeNo, ChargeClient, ChargeDate, ChargePayDay, ConfirmerID, FinisherID, ChargeAmount + ChargeTax AS ChargeTotal, JobCode"
				strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeNo IN (" & FIN_BILLNOS & ") ORDER BY ChargeClient, JobCode, ChargeNo"
			end if
		elseif FIN_CURRENT = 0 and ERASE_ID = 0 then	'�o���ȒP������
			strSql = "SELECT BatchNo AS ChargeNo, BatchClient AS ChargeClient, BatchBillDay AS ChargeDate, BatchPayDay AS ChargePayDay, ConfirmerID, FinisherID"
			strSql = strSql & ", BatchAmount AS ChargeTotal, '�o�b�`' AS JobCode FROM TBL_CTM_BATCH WHERE Deleted = 0 AND BatchClient = '" & FIN_CLIENT_CD & "'"
			strSql = strSql & " AND BatchAmount Between " & (FIN_AMOUNT - gsMinPostage) & " AND " & FIN_AMOUNT  & " AND FinisherID = 0 UNION "
			strSql = strSql & "SELECT ChargeNo, ChargeClient, ChargeDate, ChargePayDay, ConfirmerID, FinisherID, ChargeAmount + ChargeTax AS ChargeTotal, JobCode"
			strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND (ChargeAmount + ChargeTax) Between " & (FIN_AMOUNT - gsMinPostage) & " AND " & FIN_AMOUNT
			strSql = strSql & " AND ChargeClient = '" & FIN_CLIENT_CD & "' AND FinisherID = 0 AND ChargeBatch = '' ORDER BY ChargeDate"
		end if
if WebUserID = gsAdmin then response.write strSQL
		
		if strSql = "" then
			response.write "<br><div align=center class=pt12r>�Y������������ݏ��͌�����܂���ł����B</div>"
		else
		
dim ChargeClient()
dim ChargeClientName()

			ClientNo = 0
			redim ChargeClient(0)
			redim ChargeClientName(0)
			ChargeClient(0) = ""
			ChargeClientName(0) = ""
			
			cnt = 0		
			ChargeNos = ""
			ChargeTotal = ""
			ChargeAmount = 0
			with recset
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .EOF then
					myAmount = 0
					do while not .eof
					
						if ChargeClient(ClientNo) <> GetString(.Fields("ChargeClient")) then

							ClientNo = ClientNo + 1
							redim preserve ChargeClient(ClientNo)
							redim preserve ChargeClientName(ClientNo)
							ChargeClient(ClientNo) = GetString(.Fields("ChargeClient"))
							ChargeClientName(ClientNo) = GetFullName(GetString(.Fields("ChargeClient")))
							if ClientNo > 1 then response.write "</table>"
%>
	<TABLE width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
	  <TR height=30>
		<TD nowrap>
			������&nbsp;<input class=mi name="ClientName" size=38 value="<%=ChargeClientName(ClientNo)%>" onkeydown="ResetEnter()" readonly>
			(<%=ChargeClient(ClientNo)%>)
	</TABLE>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
	  <TR align=center height=20 class=pt12>
		<TD class=line nowrap>��
		<TD class=line nowrap>�䒠�ԍ�
		<TD class=line nowrap>�����ԍ�
		<TD class=line nowrap>������
		<TD class=line nowrap>�������z
		<TD class=line nowrap>������
		<TD class=line nowrap>�I��
<%
						end if
						
						cnt = cnt + 1
						ChargeNo = GetString(.Fields("ChargeNo"))
						mycolor = "black"
						if left(ChargeNo, 1) = gsBatchPrint then
							if GetBatchType(ChargeNo) = 0 then mycolor = "blue"
						else
							if CheckVoucherType(ChargeNo) = "S" then mycolor = "green"
						end if 
						myAmount = GetLong(.Fields("ChargeTotal"))
						status = ""
						if GetLong(.Fields("ConfirmerID")) = 0 then
							status = "<font color=gray>��</font>"
						else
							myChargeNo = CheckEtcErased(Conn, FIN_NO, ChargeNo, 2)
							if myChargeNo <> "" then
								status = ResetBizNo(myChargeNo)
							elseif instr(myEraseNo, ChargeNo) <> 0 then					'�O�̂���
								status = "<img src=img/checked.jpg><br>"
								ChargeAmount = ChargeAmount + myAmount
								ChargeNos = ChargeNos & "," & ChargeNo
								ChargeTotal = ChargeTotal & "," & myAmount
							end if
						end if
%>
				<TR align=center height=20>
					<TD class=line><%=cnt%><BR>
					<TD class=line nowrap><%=GetString(.Fields("JobCode"))%><BR>
					<TD class=line nowrap align=left style="color:<%=mycolor%>"><%=ShowVoucherNo(ChargeNo)%><BR>
					<TD class=line><%=Str2MD(.Fields("ChargeDate"))%><BR>
					<TD class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
					<TD class=line style="color:blue"><%=Str2MD(.Fields("ChargePayDay"))%><BR>
					<%	if status <> "" then %>
					<TD class=line><%=status%>
					<%	else %>
					<TD class=line><input type=checkbox name="DATA<%=cnt%>" value="<%=ChargeNo%>.<%=myAmount%>" onclick="DoReset()"
						<%if myEraseNo = "" AND GetString(.Fields("ChargeClient")) = FIN_CLIENT_CD and myAmount = FIN_AMOUNT then response.write " checked"%>>
<%				
							if myEraseNo = "" AND GetString(.Fields("ChargeClient")) = FIN_CLIENT_CD and myAmount = FIN_AMOUNT then
								ChargeAmount = ChargeAmount + myAmount
								ChargeTotal = ChargeTotal & "," & myAmount
								ChargeNos = ChargeNos & "," & ChargeNo
							end if

						end if
						ChargeAmountAll = ChargeAmountAll + myAmount
						.movenext
					loop
%>
			<TR align=right height=20>
				<TD colspan=2>
				<TD class=line>�� �v
				<TD class=line><%=formatnumber(ChargeAmountAll, 0, true)%>
	</TABLE>
<%
				else
					response.write "<br><div align=center class=pt12r>�Y������f�[�^�͌�����܂���ł����B</div>"
				end if
				.Close
			end with
		end if
%>
	<BR>
	<HR width=100% size=1 color=green>
  <!--�����F�����������-->
<%		
		FromReceive = 0
		OverReceive = 0
		MassProfit = 0
		MassLoss = 0
		FromDraft = 0
		OverDraft = 0
		BankPostage = 0	
		FromExpense = 0
		OverExpense = 0
		with Recset
			strSql = "SELECT FIN_NO, FIN_TYPE, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_BANK_ID FROM TBL_CTM_FIN"
			strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_NO = '" & FIN_NO & "'"
if WebUserID = gsAdmin then response.write strSQL
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not .eof
				select case GetLong(.Fields("FIN_DEBIT"))
				case acntOverReceive
					FromReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a������
				case acntMassLoss
					MassLoss = GetLong(.Fields("FIN_AMOUNT"))						'�G����
				case acntFromDraft
					FromDraft = GetLong(.Fields("FIN_AMOUNT"))						'��`����
				case acntPostage
					BankPostage = GetLong(.Fields("FIN_AMOUNT"))					'�ʐM��
				case acntExpense
					FromExpense = GetLong(.Fields("FIN_AMOUNT"))					'�o��
				end select
				
				select case GetLong(.Fields("FIN_CREDIT"))
				case acntOverReceive
					OverReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a�����
				case acntMassProfit
					MassProfit = GetLong(.Fields("FIN_AMOUNT"))						'�G�v��
				case acntOverDraft
					OverDraft = GetLong(.Fields("FIN_AMOUNT"))						'��`��
				case acntPostage
					BankPostage = 0 - GetLong(.Fields("FIN_AMOUNT"))				'�ʐM��
				case acntExpense
					OverExpense = GetLong(.Fields("FIN_AMOUNT"))					'�o��
				end select
				.movenext
			loop
			.close
		end with
		
		EraseResult = FIN_AMOUNT + FromReceive + MassLoss - ChargeAmount - OverReceive - MassProfit
		EraseResult = EraseResult + BankPostage + FromDraft - OverDraft + FromExpense - OverExpense
%>
	<TABLE width=98% Cellspacing=3 CellPadding=3 class=pt12n>
	  <TR align=center height=20>
		<TD class=line colspan=2>�ؕ�
		<TD class=line colspan=2>�ݕ�	
			
	  <TR align=center height=20>
		<TD class=line>���z
		<TD class=line>�Ȗ�
		<TD class=line>�Ȗ�
		<TD class=line>���z
		
	  <TR align=right height=20>
		<TD><input class=mn name="ReceiveAmount" size=9 maxlength=10 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" onkeydown="ResetEnter()" Readonly>
		<TD align=left>�@����
		<TD><font color=blue>(����)���|</font>
		<TD><input class=mn name="ChargeAmount" size=9 maxlength=10 value="<%=formatnumber(ChargeAmount,0,true)%>" onkeydown="ResetEnter()" Readonly>
		
	  <TR align=right height=20>
		<TD><input class=mn name="FromReceive" size=9 maxlength=10 value="<%=formatnumber(FromReceive, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left nowrap>�@�a������
		<TD>�a����
		<TD><input class=mn name="OverReceive" size=9 maxlength=10 value="<%=formatnumber(OverReceive, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20 class=pt12>
		<TD><input class=mn name="MassLoss" size=9 maxlength=10 value="<%=formatnumber(MassLoss, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@�G��
		<TD>�G��
		<TD><input class=mn name="MassProfit" size=9 maxlength=10 value="<%=formatnumber(MassProfit, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20 class=pt12>
		<TD><input class=mn name="FromDraft" size=9 maxlength=10 value="<%=formatnumber(FromDraft, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@��`����
		<TD>��`��
		<TD><input class=mn name="OverDraft" size=9 maxlength=10 value="<%=formatnumber(OverDraft, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20>
		<TD><input class=mn name="BankPostage" size=9 maxlength=10 value="<%=formatnumber(BankPostage, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left style="cursor:help" title="<%=GetClientPostage(FIN_CLIENT_CD)%>">�@�ʐM��
		<TD nowrap class=pt12r>�������z
		<TD><input class=mn name="EraseResult" size=9 maxlength=10 value="<%=formatnumber(EraseResult, 0, true)%>" onkeydown="ResetEnter()" Readonly>

<%if FIN_CURRENT = 9 then %>
	  <TR align=right height=20 class=pt12t>
		<TD><input class=mn name="FromExpense" size=9 maxlength=10 value="<%=formatnumber(FromExpense, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@�o���
		<TD>�o���
		<TD><input class=mn name="OverExpense" size=9 maxlength=10 value="<%=formatnumber(OverExpense, 0, true)%>" onkeydown="ResetEnter()">
<%end if%>

	  <TR align=right height=49>
	  	<TD>
	  	
	  <TR align=center height=20>
	  	<TD colspan=4 align=center>
	  		<HR width=100% size=1 color=green>
	  	
	  <TR align=center height=20>
	  	<TD colspan=4 align=center>
<%if ERASE_ID <> 0 then%>
	<%if FIN_MONTH = "" and CheckAccountLevel() > 1 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnUnLock value="������������" onclick="DoUnErase()">
	<%end if%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnClose value="��ʂ����" onclick="window.close()">
<%else%>
	<%select case FIN_CURRENT
	  case 0%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnSave value="�c�ƂɔC����" onclick="DataSave(1)">
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnLock value="�����������s" onclick="DataSave(3)">
	<%case 1%>
			<font color=pt12b>�Y�������`�[�͂������܉c�ƂɔC���Ă��܂��B</font>
	<%case 2
		if EraseResult <> 0 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnSave value="�c�ƂɔC����" onclick="DataSave(1)">
	<%	elseif CheckAccountLevel() > 0 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnLock value="���������m�F" onclick="DataSave(3)">
		<%if CheckAccountLevel() > 1 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnUnLock value="������������" onclick="DoUnErase()">
		<%end if%>
	<%	end if 
	end select%>
<%end if%>
	</TABLE>
<input type=hidden name="ChargeNos" value="<%=mid(ChargeNos, 2)%>">
<input type=hidden name="ChargeTotal" value="<%=mid(ChargeTotal, 2)%>">
</FORM>
<center>
<%if ERASE_ID <> 0 then %>
<script language=vbscript>
	call LockAll()
</script>
<%end if%>
</body></html>
<%	
	end if
end if
	
	set Recset = nothing
	CloseDB Conn
%>
