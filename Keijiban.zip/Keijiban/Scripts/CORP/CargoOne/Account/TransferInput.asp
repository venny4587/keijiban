<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�U�֓`�[�쐬���
'----------------------------------------------

'on error resume next
	
	FIN_NO = GetPost(request("FIN_NO"))
	
	mode = 0
	if FIN_NO = "" then		
		FIN_TYPE = acntBank
		FIN_DATE = formatDate(date)
		FIN_DEBIT = 33			'�a�����
		FIN_CREDIT = 23			'��s�o��
		CONFIRM_ID = 0
	else
		OpenSql Conn, SqlServerName, DataBaseName
		
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
			strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 1 AND FIN_NO = '" & FIN_NO & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				mode = 1
				FIN_No = GetString(.fields("FIN_NO"))
				FIN_TYPE = GetLong(.fields("FIN_TYPE"))					
				FIN_BELONG = GetString(.fields("FIN_BELONG"))
				FIN_DEBIT = GetLong(.fields("FIN_DEBIT"))	
				FIN_CREDIT = GetLong(.fields("FIN_CREDIT"))	
				FIN_DATE = Str2Date(.fields("FIN_DATE"))
				FIN_CLIENT_CD = GetString(.fields("FIN_CLIENT_CD"))
				FIN_CLIENT_NAME = GetString(.fields("FIN_CLIENT_NAME"))					
				FIN_CLIENT_PIC = GetString(.fields("FIN_CLIENT_PIC"))
				FIN_BANK_ID = GetLong(.fields("FIN_BANK_ID"))
				FIN_AMOUNT = GetLong(.fields("FIN_AMOUNT"))
				
				FIN_BATCH = GetString(.fields("FIN_BATCH"))
				FIN_BILLNO = GetString(.fields("FIN_BILLNO"))
				FIN_JOBCODE = GetString(.fields("FIN_JOBCODE"))
				FIN_DESCRIPTION = GetString(.fields("FIN_DESCRIPTION"))
				FIN_SECURITIES = GetString(.fields("FIN_SECURITIES"))
				FIN_SECURITIES_NO = GetString(.fields("FIN_SECURITIES_NO"))
				FIN_SECURITIES_DATE = Str2Date(.fields("FIN_SECURITIES_DATE"))
				
				FIN_CURRENT = GetLong(.fields("FIN_CURRENT"))
				FIN_MEMO = GetString(.fields("FIN_MEMO"))
				FIN_REMARKS = GetString(.fields("FIN_REMARKS"))					
	
				FIN_CREATER = GetLong(.fields("FIN_CREATER"))
				FIN_CREATED = GetDate(.fields("FIN_CREATED"))
				CONFIRM_ID = GetLong(.fields("CONFIRM_ID"))
				CONFIRM_DATE = GetDate(.fields("CONFIRM_DATE"))
				ERASE_ID = GetLong(.fields("ERASE_ID"))
				ERASE_DATE = GetDate(.fields("ERASE_DATE"))
			end if
			.close
		end with
	end if
%>
<html>
<HEAD>
	<TITLE>�U�֓`�[�ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>				
		sub DoSearch()
			dim win
			set win = window.open("ClientSearch.asp?cd=" & frmInput.ClientRef.value,"ClientSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub	
		
		sub DoErase()
			dim win
			set win = window.open("ReceiveErase.asp?FIN_NO=<%=FIN_NO%>","ReceiveErase","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end sub
				
		sub DataLock()
			call DataSave(2)
		end sub
		
		sub DataUnLock()
			if msgbox ("�Y���U�֓`�[�m����������Ă�낵���ł����H",289, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
		end sub
				
		sub DoDelete()
			if msgbox ("�Y���U�֓`�[���폜���Ă�낵���ł����H",289, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DataSave(mode)
			if frmInput.FIN_DEBIT.selectedIndex = frmInput.FIN_CREDIT.selectedIndex then
				msgbox "�؂���݂͑����ƈ�v�ɂȂ�܂����B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkText("ClientCode","�U�֐�R�[�h",1) = false then exit sub
			if checkText("ClientName","�U�֐於",1) = false then exit sub
			if checkText("ClientPic","�U�֐�S����",0) = false then exit sub
			if checkDate("FIN_DATE","�U�֓�", 1) = false then exit sub
			if checkNum("FIN_AMOUNT","�U�֊z", 2) = false then exit sub
			if checkText("FIN_DESCRIPTION","�U�֓K�v", 0) = false then exit sub
			if checkText("FIN_BATCH","�o�b�`�ԍ�", 0) = false then exit sub
			if checkText("FIN_BILLNO","�����ԍ�", 0) = false then exit sub
			if checkText("FIN_JOBCODE","�䒠�ԍ�", 0) = false then exit sub
			if checkDate("FIN_SECURITIES_DATE","��`���", 0) = false then exit sub
			if checkText("FIN_SECURITIES_NO","��`�ԍ�", 0) = false then exit sub
			if checkText("FIN_MEMO","�U�փ���", 0) = false then exit sub
			if checkLen("FIN_MEMO","�U�փ���", 250) = false then exit sub
			if checkText("Remarks","�U�֔��l", 0) = false then exit sub
			if checkLen("Remarks","�U�֔��l", 250) = false then exit sub
			if mode = 2 then
				if msgbox ("�Y���U�֓`�[���m�肵�Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
				
		sub ClientRef_OnChange()
			frmInput.ClientCode.value = ""
			frmInput.ClientName.value = ""
		end sub
		sub FIN_AMOUNT_Onblur()
			frmInput.FIN_AMOUNT.value = formatnumber(GetLong(frmInput.FIN_AMOUNT.value), 0, true)
		end sub		
		sub FIN_DATE_Onblur()
			frmInput.FIN_DATE.value = setdate(frmInput.FIN_DATE.value)
		end sub		
		sub FIN_SECURITIES_DATE_Onblur()
			frmInput.FIN_SECURITIES_DATE.value = setdate(frmInput.FIN_SECURITIES_DATE.value)
		end sub		
<%if CheckInputNo() > 0 then %>
		sub FIN_BATCH_Onblur()
			frmInput.FIN_BATCH.value = FitPrintNo(frmInput.FIN_BATCH.value)
		end sub
		sub FIN_BILLNO_Onblur()
			frmInput.FIN_BILLNO.value = FitChargeNo(frmInput.FIN_BILLNO.value)
		end sub
		sub FIN_JOBCODE_Onblur()
			frmInput.FIN_JOBCODE.value = FitJobCode(frmInput.FIN_JOBCODE.value)
			if len(frmInput.FIN_JOBCODE.value) <> 10 then frmInput.FIN_JOBCODE.value = ""
		end sub
<%end if %>
		
		sub InitForm()
<%if CONFIRM_ID <> 0 then%>
			Call LockAll()
<%else%>
	<%if mode = 0 then%>
			frmInput.ClientRef.focus()
	<%else%>	
			frmInput.FIN_DESCRIPTION.focus()
	<%end if%>
<%end if%>
		end sub
		
		sub DoShortCut()
<%if CONFIRM_ID = 0 then%>	
			if window.event.keyCode=120 then call DataSave(<%=mode%>) 
<%end if%>
		end sub
	</SCRIPT>
</Head>
<body leftmargin=0 topmargin=0 class=pt12 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22><td width=40% nowrap valign=bottom>���U�֓`�[<%if mode=0 then%>�쐬<%else%>���<%end if%>&nbsp;
<%if mode = 1 and CONFIRM_ID = 0 then%>
		<img style="cursor:hand" src=img/waste.jpg alt="�폜" onmousedown="DoDelete()">
<%end if%>
		<td width=40% valign=bottom><%if mode = 1 then response.write "�U�֔ԍ�:<font color=blue>" & FIN_NO & "</font>"%>
		<td width=20% align=right>
<%if ERASE_ID <> 0 then %>
	  	  <img style="cursor:help" src=img/key.jpg alt="�����ς�">
<%elseif CONFIRM_ID <> 0 then %>
	<%if CheckAccountLevel() > 1 then %>
	  	  <img style="cursor:help" src=img/unlock.jpg alt="�m�F����" onmousedown="DataUnLock()">
	<%else%>
	  	  <img style="cursor:help" src=img/lock.jpg alt="�m�F�ς�">
	<%end if%>
<%else %>
	 	  <%if CheckAccountLevel() > 0 then %><img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DataLock()"><%end if%>
	  	  <img style="cursor:hand" src=img/save.jpg alt="�ۑ�" onmousedown="DataSave(<%=mode%>)">
<%end if %>
	</table>
	<hr width=96% size=1 color=red>
  <FORM NAME="frmInput" action="TransferSave.asp" method="post">
  	<input type=hidden name="FIN_TYPE" value="<%=FIN_TYPE%>">
  	<input type=hidden name="FIN_NO" value="<%=FIN_NO%>">
  	<input type=hidden name="mode" value="<%=mode%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
	  <TR height=30>
		<TD width=80 align=center nowrap>�U�֎ؕ�
		<TD colspan=5><select name="FIN_DEBIT" class=pt12n onkeydown="ResetEnter()" <%if CONFIRM_ID <> 0 then response.write "Disabled"%>>
						<%=GetAccountList(FIN_DEBIT)%></select>
	  <TR height=30>
		<TD width=80 align=center nowrap>�U�֑ݕ�
		<TD colspan=5><select name="FIN_CREDIT" class=pt12n onkeydown="ResetEnter()" <%if CONFIRM_ID <> 0 then response.write "Disabled"%>>
						<%=GetAccountList(FIN_CREDIT)%></select>
	  <TR height=30>
		<TD width=80 align=center nowrap>�U�֋�s
		<TD colspan=5><select name="FIN_BANK_ID" class=pt12n onkeydown="ResetEnter()" <%if CONFIRM_ID <> 0 then response.write "Disabled"%>>
						<%=ShowBankList(FIN_BANK_ID, finReceive)%><option value="0">�Ȃ�</select>
	  <TR height=30><!--�U�։׎匟���𗬗p���邽�߁@Client-->
		<TD align=center>�U�֐�<input type=hidden name="ClientCode" value="<%=FIN_CLIENT_CD%>">
		<TD colspan=5 nowrap><input class=mi name="ClientRef" size=8 maxlength=10 value="<%=GetRefName(FIN_CLIENT_CD)%>" onkeydown="ResetEnter()">
			<%if CONFIRM_ID = 0 then%><a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a><%end if%>
			<input class=mj name="ClientName" size=38 maxlength=50 value="<%=FIN_CLIENT_NAME%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD width=80 align=center>�U�֒S��<input type=hidden name="FIN_BELONG" value="<%=FIN_BELONG%>">
		<TD><input class=mj name="ClientPic" size=10 maxlength=50 value="<%=FIN_CLIENT_PIC%>" onkeydown="ResetEnter()">
		<TD width=80 align=center nowrap>�U�֓�
		<TD><input class=mi name="FIN_DATE" size=10 maxlength=10 value="<%=FIN_DATE%>" onkeydown="ResetEnter()" 
			<%if CONFIRM_ID = 0 then%>onclick="setday(this)"<%end if%>>
		<TD width=80 align=center nowrap>�U�֊z
		<TD><input class=mn name="FIN_AMOUNT" size=10 maxlength=10 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD width=80 align=center nowrap>�U�֓K�v
		<TD colspan=5><input class=mz name="FIN_DESCRIPTION" size=52 maxlength=250 value="<%=FIN_DESCRIPTION%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD width=80 align=center nowrap>�o�b�`��
		<TD><input class=mi name="FIN_BATCH" size=8 maxlength=6 value="<%=FIN_BATCH%>" onkeydown="ResetEnter()">
		<TD width=80 align=center nowrap>�����ԍ�
		<TD><input class=mi name="FIN_BILLNO" size=10 maxlength=10 value="<%=FIN_BILLNO%>" onkeydown="ResetEnter()">
		<TD width=80 align=center nowrap>�䒠�ԍ�
		<TD><input class=mi name="FIN_JOBCODE" size=10 maxlength=10 value="<%=FIN_JOBCODE%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD width=80 align=center>����
		<TD width=80 align=center><select name="FIN_SECURITIES" class=pt12n onkeydown="ResetEnter()" <%if CONFIRM_ID <> 0 then response.write "Disabled"%>>
									<%=ShowCategoryList("Securities", FIN_SECURITIES, 0)%></select>
		<TD width=80 align=center nowrap>�������
		<TD><input class=mi name="FIN_SECURITIES_DATE" size=10 maxlength=10 value="<%=FIN_SECURITIES_DATE%>" onkeydown="ResetEnter()" 
			<%if CONFIRM_ID = 0 then%>onclick="setday(this)"<%end if%>>
		<TD width=80 align=center nowrap>����ԍ�
		<TD><input class=mi name="FIN_SECURITIES_NO" size=10 maxlength=50 value="<%=FIN_SECURITIES_NO%>" onkeydown="ResetEnter()">
	  <tr>
	  	<td><img src=img/spacer.jpg height=3>
	  <TR>
		<TD align=center>�U�փ���
		<TD colspan=5><textarea class=pt12n name="FIN_MEMO" rows=5 style="width:420"><%=FIN_MEMO%></textarea>
	  <TR>
	  	<TD><img src=img/spacer.jpg height=3>
<!--
	  <TR>
		<TD class=pt12 align=center>����<br>���l
		<TD colspan=5><textarea class=mz name="Remarks" rows=5 style="width:400"><%=Remarks%></textarea>
-->
<%if mode = 1 then%>
	  <TR>
	  	<TD><img src=img/spacer.jpg height=3>
	  <TR height=24>
		<TD align=center class=pt12g>�쐬��<TD class=gline align=center><%=GetEmployName(FIN_CREATER, "F")%><br>
		<TD align=center class=pt12g>�m�F��<TD class=gline align=center><%=GetEmployName(CONFIRM_ID, "F")%><br>
		<TD align=center class=pt12g>������<TD class=gline align=center><%=GetEmployName(ERASE_ID, "F")%><br>
	  <TR height=24>
		<TD align=center class=pt12g>�쐬��<TD class=gline align=center><%=formatDate(FIN_CREATED)%><br>
		<TD align=center class=pt12g>�m�F��<TD class=gline align=center><%=formatDate(CONFIRM_DATE)%><br>
		<TD align=center class=pt12g>������<TD class=gline align=center><%=formatDate(ERASE_DATE)%><br>
<%end if%>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
%>
