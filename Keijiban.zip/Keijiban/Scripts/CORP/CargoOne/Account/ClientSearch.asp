<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
		
dim mode
dim myCode

	mode = GetLong(request("mode"))
	myCode = GetPost(request("cd"))
	selCode = replace(myCode, "'", "''")
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	CTM_CD = ""
	if myCode <> "" then
		with Recset	
			StrSql = "SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_ENAME, CTM_BELONG, CTM_SALESMNGR FROM CUSTOMER"
			StrSql = StrSql & " WHERE CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "' OR CTM_ABR = '" & selCode & "'"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				CTM_CD = GetString(.fields("CTM_CD"))
				CTM_REF = GetString(.fields("CTM_REF"))
				CTM_NAME = GetString(.fields("CTM_NAME"))
				CTM_BELONG = GetString(.fields("CTM_BELONG"))
				ClientBelong = GetShopName(.fields("CTM_BELONG"))
				ClientSales = GetEmployName(.fields("CTM_SALESMNGR"), "F")
			end if
			.close			
		end with
	end if

	if CTM_CD <> "" then
		with Recset	
			StrSql = "SELECT PIC_NAME FROM CTM_PIC WHERE PIC_DFT = 1 AND CTM_CD = '" & CTM_CD & "'"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then PIC_NAME = GetString(.fields("PIC_NAME"))
			.close		
		end with
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
	if (window.opener.frmInput.ClientCode != null) window.opener.frmInput.ClientCode.value = "<%=CTM_CD%>";
	if (window.opener.frmInput.ClientRef != null) window.opener.frmInput.ClientRef.value = "<%=CTM_REF%>";
	if (window.opener.frmInput.ClientName != null) window.opener.frmInput.ClientName.value = "<%=CTM_NAME%>";
	if (window.opener.frmInput.ClientPic != null) window.opener.frmInput.ClientPic.value = "<%=PIC_NAME%>";
	if (window.opener.frmInput.FIN_BELONG != null) window.opener.frmInput.FIN_BELONG.value = "<%=CTM_BELONG%>";
	if (window.opener.frmInput.ClientBelong != null) window.opener.frmInput.ClientBelong.value = "<%=ClientBelong%>";
	if (window.opener.frmInput.ClientSales != null) window.opener.frmInput.ClientSales.value = "<%=ClientSales%>";
	if (window.opener.frmInput.FIN_AMOUNT != null) {
		window.opener.frmInput.FIN_AMOUNT.focus();	
		var range = window.opener.frmInput.FIN_AMOUNT.createTextRange();
		var rtn1 = range.moveStart("character", 0);
		var rtn2 = range.moveEnd("character", 999);
		range.select();
	}
	window.close();
</SCRIPT>
</HTML>
<%
	else
		if mode = 0 then 
			myTitle = "������"
		else
			myTitle = "�x����"
		end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE><%=myTitle%>����</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "ClientSearch.asp?mode=<%=mode%>&cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("<%=myTitle%>�R�[�h�܂���<%=myTitle%>���̈ꕔ����͂��Ă��������B")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="ClientSearch.asp" NAME=frmInput>
		<input type=hidden name="mode" value="<%=mode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD>�@<%=myTitle%>���� :
					<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=20 onkeydown="ResetEnter()">
					<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a>
		</table>
<center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then 
			With Recset
				StrSql = "SELECT COUNT(CTM_CD) AS CTM_CNT FROM CUSTOMER WHERE ("
				StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "' OR CTM_ABR = '" & selCode & "'"
				StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if GetLong(.fields("CTM_CNT")) = 0 then
					response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
				elseif GetLong(.fields("CTM_CNT")) > 30 then
					response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
				else
					.close
					
					StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_ABR, CTM_NAME FROM CUSTOMER WHERE ("
					StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "' OR CTM_ABR = '" & selCode & "'"
					StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
					strSQL = strSQL + " ORDER BY CTM_ENAME"
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>��������
					<TD nowrap>�p������
					<TD nowrap>�a������
<%
						myCnt = 0
						myShortCut = ""
						Do Until .EOF	
							myCnt = myCnt + 1		
							myEName = GetString(.Fields("CTM_ENAME"))	
							myJName = GetString(.Fields("CTM_NAME"))	
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("CTM_CD") & "');"
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("CTM_CD")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_REF"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myEName, 30)%>><%=StringCut(myEName,30)%><BR>
					<TD class=line nowrap <%=ShowTitle(myJName, 20)%>><%=StringCut(myJName,20)%><BR>
<%							
							.MoveNext
						Loop
					end if				
%>
			</table>
<%
				end if	
				.Close 
			End With
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>
