<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�o���`�[�ꊇ�m����
'----------------------------------------------

myCheck = 1
select case  session("WebUserID")
case 36, 88
    myCheck = 0
end select

'on error resume next
dim FinStr
dim myMode
dim myPageSize
dim lngPageNumber
		
	myPageSize = GetUserPageSize(10)
	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		mySort = 4
		'DateFrom = GetInitDate()			'���؎�̂���
		if CheckAccountLevel() < 2 then FIN_BANK_ID = GetDefaultBank()
		if myCheck = 0 then CheckType = "���؎�"
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		CheckType = GetPost(request("CheckType"))
		FIN_NO = GetPost(request("FIN_NO"))
		CostsNo = GetPost(request("CostsNo"))
		BatchNo = GetPost(request("BatchNo"))
		FIN_BANK_ID = GetLong(request("FIN_BANK_ID"))
		
		'�ꊇ��������
		if myMode = 2 then	
			msg = ""
			FinStr = split(GetPost(request("FinNo")), ",")
			
			Conn.BeginTrans
				
			for i = 0 to ubound(FinStr)
				FinNo = trim(FinStr(i))
				
				'�Ɩ��d���������(����)
				strSql = "UPDATE TBL_CTM_BIZ SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID & ", BIZ_FIN_NO = '" & FinNo & "'"
				strSql = strSql & " WHERE BIZ_NO IN (SELECT ERASE_BIZ_NO FROM TBL_CTM_ERASE WHERE ERASE_BIZ_NO <> '' AND ERASE_FIN_NO = '" & FinNo & "')"
				Conn.execute strSql
				
				'�Ɩ��d���������(����)
				strSql = "UPDATE TBL_CTM_BIZ SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID & ", BIZ_FIN_NO = '" & FinNo & "'"
				strSql = strSql & " WHERE BIZ_BATCH IN (SELECT ERASE_BATCH FROM TBL_CTM_ERASE WHERE ERASE_BATCH <> '' AND ERASE_FIN_NO = '" & FinNo & "')"
				Conn.execute strSql
				
				'�x���`�[��������(����)
				strSql = "UPDATE TBL_CTM_COSTS SET FinishDate = GETDATE(), FinisherID = " & WebUserID
				strSql = strSql & " WHERE CostsNo IN (SELECT ERASE_BIZ_NO FROM TBL_CTM_ERASE WHERE ERASE_BIZ_NO <> '' AND ERASE_FIN_NO = '" & FinNo & "')"
				Conn.execute strSql
				
				'�x���`�[��������(����)
				strSql = "UPDATE TBL_CTM_COSTS SET FinishDate = GETDATE(), FinisherID = " & WebUserID
				strSql = strSql & " WHERE CostsBatch IN (SELECT ERASE_BATCH FROM TBL_CTM_ERASE WHERE ERASE_BATCH <> '' AND ERASE_FIN_NO = '" & FinNo & "')"
				Conn.execute strSql
				
				'�o�b�`����������
				strSql = "UPDATE TBL_CTM_BATCH SET FinishDate = GETDATE(), FinisherID = " & WebUserID
				strSql = strSql & " WHERE BatchNo IN (SELECT ERASE_BATCH FROM TBL_CTM_ERASE WHERE ERASE_BATCH <> '' AND ERASE_FIN_NO = '" & FinNo & "')"
				Conn.execute strSql
				
				'�o���`�[��������
				strSql = "UPDATE TBL_CTM_FIN SET ERASE_DATE = GETDATE(), ERASE_ID = " & WebUserID
				strSql = strSql & " WHERE FIN_NO = '" & FinNo & "'"
				Conn.execute strSql
				
				if err.number <> 0 then exit for
			next
				
			if err.number = 0 then
				Conn.CommitTrans
				msg = "�������ݏ����͖����������܂����B"
			else
				Conn.RollbackTrans
				msg = "�������ݏ��������L�̃G���[���N����܂����B(" & vbcrlf & err.number & ":" & err.description & ")"
			end if
		end if
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�o���`�[��������</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoCheck()
			Call CheckAll("FinNo", frmInput.CheckAll.Checked)
		end function 
	
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 5) = "FinNo" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�m�肷��o���`�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^���m�肵�Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList() 
		dim win
			set win = window.open("ClientSearch.asp?cd=" & frmInput.ClientRef.value,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
						
		function ShowDetail(myNo, myBatch)
		dim win, url
			if myBatch = "" then
				url = "PaymentErase0.asp?FIN_NO=" & myNo
			else
				url = "PaymentErase1.asp?FIN_NO=" & myNo
			end if
			set win = window.open(url,"PaymentErase","resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function
						
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
<%if CheckInputNo() > 0 then %>
		sub BatchNo_OnBlur()
			frmInput.BatchNo.value = FitBatchNo(frmInput.BatchNo.value)
		end sub
		sub CostsNo_OnBlur()
			frmInput.CostsNo.value = FitCostsNo(frmInput.CostsNo.value)
		end sub
<%end if %>
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
			
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
			
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
<%if myMode = 2 then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%else%>
			frmInput.ClientRef.focus()
<%end if%>
			window.parent.parent.result.location.href = "PaymentResult.asp?type=2"
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="PaymentProc.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>��s����
<%if myCheck then%>
<%if CheckAccountLevel() > 1 then %>
					<select name="FIN_BANK_ID" onkeydown="ResetEnter()"><%=ShowBankList(FIN_BANK_ID, finReceive, 0)%></select>
<%else%>
					<select name="FIN_BANK_ID" onkeydown="ResetEnter()"><%=ShowBankList(FIN_BANK_ID, finPayment, 1)%></select>
<%end if%>
<%else%>
					<select name="FIN_BANK_ID" onkeydown="ResetEnter()"><option value="3"><%=GetBankName(3)%></select>
<%end if%>
				����&nbsp;<select name="CheckType" class=pt9n onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowCategoryList("Securities", CheckType, 0)%></select>
<!--				�ޯ���&nbsp;<input class=si name="BatchNo" value="<%=BatchNo%>" maxlength=6 size=6 onkeydown="ResetEnter()">	-->
				<TD rowspan=2 width=100 align=right>
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT VALUE="����">	
			<TR><TD nowrap>
				�x����<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList()">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�o����&nbsp;<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�x���ԍ�&nbsp;<input class=si name="CostsNo" value="<%=CostsNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">&nbsp;
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if FIN_BANK_ID <> 0 then strSel = strSel & " AND FIN_BANK_ID = " & FIN_BANK_ID
	if BatchNo <> "" then strSel = strSel & " AND FIN_BATCH = '" & FitSel(BatchNo) & "'"
	if CheckType <> "" then strSel = strSel & " AND FIN_SECURITIES = '" & FitSel(CheckType) & "'"
	if ClientRef <> "" then	strSel = strSel & " AND (ClientRef = '" & FitSel(ClientRef) & "' OR FIN_CLIENT_NAME LIKE '% " & FitSel(ClientRef) & "%')"
	if DateFrom <> "" then strSel = strSel & " AND FIN_DATE >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND FIN_DATE <= '" & Date2Str(DateTo) & "'"
	if CostsNo <> "" then strSel = strSel & " AND FIN_BILLNO = '" & FitSel(CostsNo) & "'"
	with recset
		myTotalAmount = 0
		strSql = "SELECT SUM(FIN_AMOUNT) AS TotalAmount FROM TBL_CTM_FIN AS F "
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'P' AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND ERASE_ID = 0 AND CONFIRM_ID = 0"		'���폜�@�������@���m��
		'if CheckAccountLevel() < 2 then strSql = strSql & " AND FIN_CURRENT <> 0"
		if strSel <> "" then strSQL = strSQL & strSel
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then myTotalAmount = GetLong(.Fields("TotalAmount"))	
		.Close
	
		strSql = "SELECT FIN_NO, FIN_TYPE, ClientRef, FIN_CLIENT_NAME, FIN_DATE, FIN_AMOUNT, FIN_BILLNO, FIN_SECURITIES, FIN_CREATER, FIN_BATCH, FIN_SECURITIES_NO "
		strSql = strSql & ",FIN_CURRENT FROM TBL_CTM_FIN AS F INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'P' AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND ERASE_ID = 0 AND CONFIRM_ID = 0"		'���폜�@�������@���m��
		'if CheckAccountLevel() < 2 then strSql = strSql & " AND FIN_CURRENT <> 0"
		if strSel <> "" then strSQL = strSQL & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY FIN_NO"
		case 1:		strSql = strSql & " ORDER BY FIN_SECURITIES_NO, FIN_NO"
		case 2:		strSql = strSql & " ORDER BY FIN_BATCH, FIN_BILLNO"
		case 3:		strSql = strSql & " ORDER BY ClientRef, FIN_NO"
		case 4:		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
		case 5:		strSql = strSql & " ORDER BY FIN_AMOUNT DESC, FIN_NO"
		case 6:		strSql = strSql & " ORDER BY FIN_CREATER, FIN_NO"
		end select			
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		else
			.PageSize = myPageSize
			lngPageCount = .PageCount
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * myPageSize					
%>
		<table width=100% class=pt9n>
			<tr>
				<td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%></td>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:30px;height:20px" value="GO">
				<%end if%>
				</td>
			</TR>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=4 align=center>
			<colgroup span=3 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup span=3 align=center>
		  <TR align=center height=20 class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�o���ԍ�
			<TD class=line nowrap>����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">���퇂
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�x���ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�o����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�o���z
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">�L�[
			<TD class=line nowrap colspan=2><input type=checkbox name="CheckAll" value="" onclick="DoCheck()">�S��
<%
			cnt = 0
			ttlAmount = 0
			Do Until .EOF
				lngCount = lngCount + 1			
				If lngCount > lngPageNumber * myPageSize Then
					Exit Do
				Else
					FIN_NO = GetString(.Fields("FIN_NO"))
					FIN_BATCH = GetString(.Fields("FIN_BATCH"))
					FIN_BILLNO = GetString(.Fields("FIN_BILLNO")) & FIN_BATCH
					ttlAmount = ttlAmount + GetLong(.Fields("FIN_AMOUNT"))
%>
		<TR>
			<TD class=line><%=lngCount%><BR>
			<TD class=line><%if GetLong(.fields("FIN_CURRENT")) then%><font color=blue>��</font><%else%>��<%end if%><BR>
			<TD class=line><%=ShowVoucherNo(FIN_NO)%><BR>
			<TD class=line><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
			<TD class=line><%=GetString(.Fields("FIN_SECURITIES_NO"))%><BR>
			<TD class=line><%=ShowVoucherNo(FIN_BILLNO)%><BR>
			<TD class=line nowrap title="<%=GetString(.Fields("FIN_CLIENT_NAME"))%>"><%=StringCut(GetString(.Fields("ClientRef")),7)%><BR>
			<TD class=line nowrap style="color:blue"><%=Str2MD(.Fields("FIN_Date"))%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
			<TD class=line nowrap><%=GetEmployName(GetLong(.Fields("FIN_CREATER")), "F")%><BR>
			<TD class=line><input type=checkbox name="FinNo" value="<%=GetString(.Fields("FIN_NO"))%>">
			<TD class=line><img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowDetail('<%=FIN_NO%>','<%=FIN_BATCH%>')">
<%
				end if
				.movenext
			loop
			if cnt > 1 then 
%>
			<TR height=20>
				<TD colspan=6 align=left><%if cnt > PageSize then response.write "<font color=red>��������܂�...</font>"%>
				<TD class=line align=right>�� �v
				<TD class=line align=right colspan=2><%=formatnumber(myTotalAmount, 0, true)%>
<%
			end if
%>
		</TABLE>
		<div align=right>
			<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button VALUE="����" onclick="DoConfirm()">
		</div>
<%
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>