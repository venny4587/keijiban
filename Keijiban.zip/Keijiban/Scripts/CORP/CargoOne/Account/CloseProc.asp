<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����ߏ������
'----------------------------------------------

'on error resume next
dim mode
dim AccountBelong
dim AccountMonth
dim AccountFrom
dim AccountTo
dim myRec
dim myType
	
	myType = GetLong(request("type"))
	AccountMonth = GetPost(request("AccountMonth"))
	
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
if WebUserID = gsAdmin then response.write AccountMonth & ":" & AccountFrom & "-" & AccountTo & "<br><br>"

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

if myType > 0 then

	Conn.BeginTrans
	
	'���ߌ��ʃ��b�N
	strSql = "UPDATE TBL_CTM_ACCOUNT SET Finished = 1, Updated = GETDATE(), Updater = " & WebUserID
	strSql = strSql & " WHERE AccountMonth = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql
	
	'------------------------------------------------------	
	
	'�Ɩ��f�[�^����
	strSql = "UPDATE TBL_CTM_JOB SET AccountDate = '" & AccountMonth & "' WHERE Deleted = 0 AND Canceled = 0 AND LockerID <> 0"
	strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"	' AND AccountDate = ''"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql

	'�Ɩ��d�����
	strSql = "UPDATE TBL_CTM_BIZ SET BIZ_MONTH = '" & AccountMonth & "' FROM TBL_CTM_BIZ, TBL_CTM_JOB"
	strSql = strSql & " WHERE TBL_CTM_BIZ.BIZ_JOBCODE = TBL_CTM_JOB.JobCode AND BIZ_DELETED = 0 AND Deleted = 0 AND Canceled = 0"		' AND LockerID <> 0
	strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql

	'�����d�����
	strSql = "UPDATE TBL_CTM_FIN SET FIN_MONTH = '" & AccountMonth & "' WHERE FIN_DELETED = 0 AND ERASE_ID <> 0"
	strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql

	'�����ߌJ�z�⑫	
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	strSql = "SELECT * FROM TBL_CTM_ACCOUNT WHERE AccountMonth = '" & AccountMonth & "'"
	Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
	if not Recset.eof then
		with myRec
			NextMonth = left(Date2Str(dateadd("m", 1, Str2Date(AccountMonth & "01"))), 6)
			strSql = "SELECT * FROM TBL_CTM_ACCOUNT WHERE AccountMonth = '" & NextMonth & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
			.Open strSql, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then
				.AddNew
				.fields("AccountBelong") = ""
				.fields("AccountMonth") = NextMonth
				.fields("Finished") = 0
				
				.fields("Creater") = WebUserID
				.fields("Created") = now
			end if
			.fields("BankInit") = Recset.fields("BankBalance")
			.fields("SalesInit") = Recset.fields("SalesBalance")
			.fields("CostsInit") = Recset.fields("CostsBalance")
			.fields("DepositInit") = Recset.fields("DepositBalance")
			.fields("DraftInit") = Recset.fields("DraftBalance")
			.fields("StandRInit") = Recset.fields("StandRBalance")
			.fields("StandPInit") = Recset.fields("StandPBalance")
			
			.fields("Updater") = WebUserID
			.fields("Updated") = now()
			.Update
			.Close
		end with
	end if 
	Recset.Close
			
	msg = ""
	if err.number = 0 then
		Conn.CommitTrans
	else
		Conn.RollbackTrans
		msg = "�����ߏ��������L�̃G���[���N����܂����B" & vbcrlf & err.number & ":" & err.description
	end if
	
	if msg <> "" then
		ShowMessage msg
	else
		if WebUserID <> gsAdmin then
%>
<html>
<script language=javascript>
alert("�����ߏ����͖����������܂����I");
window.location.href = "CloseView.asp?SelBranch=<%=AccountBelong%>&SelYear=<%=left(AccountMonth, 4)%>&SelMonth=<%=right(AccountMonth,2)%>"
</script>
</html>
<%
		end if
	end if
else
	
	'�Ɩ��f�[�^����
	strSql = "UPDATE TBL_CTM_JOB SET AccountDate = '' WHERE AccountDate = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql

	'�Ɩ��d�����
	strSql = "UPDATE TBL_CTM_BIZ SET BIZ_MONTH = '' WHERE BIZ_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql

	'�����d�����
	strSql = "UPDATE TBL_CTM_FIN SET FIN_MONTH = '' WHERE FIN_MONTH = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql
	
	'���߃��b�N�̉���
	strSql = "UPDATE TBL_CTM_ACCOUNT SET Finished = 0, Updated = GETDATE(), Updater = " & WebUserID
	strSql = strSql & " WHERE AccountMonth = '" & AccountMonth & "'"
if WebUserID = gsAdmin then response.write strSql & "<br><br>"
	Conn.Execute strSql

	if WebUserID <> gsAdmin then
%>
<html>
<script language=javascript>
alert("�����ߏ����͉������܂����I");
window.location.href = "CloseView.asp?SelBranch=<%=AccountBelong%>&SelYear=<%=left(AccountMonth, 4)%>&SelMonth=<%=right(AccountMonth,2)%>"
</script>
</html>
<%
	end if
end if

	set Recset = nothing
	set myRec = nothing
	CloseDB Conn
	
%>