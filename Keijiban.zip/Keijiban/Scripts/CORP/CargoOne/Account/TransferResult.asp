<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'====================================
'
'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
'
'====================================

'on error resume next
		
	SearchDate = GetDate(request("SearchDate"))
	if SearchDate = "" then SearchDate = formatDate(date)
	
	myType = GetLong(request("type"))
	BankID = GetLong(request("BankID"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�U�֓`�[�ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></SCRIPT>
	<SCRIPT language=vbscript>	
		sub SearchDate_OnBlur()
			SearchDate.value = setdate(SearchDate.value)
		end sub
	
		function DoSelect()
			window.location.href = "TransferResult.asp?type=<%=myType%>&SearchDate=" & setdate(SearchDate.value)
		end function
		
		function ShowDetail(myNo, myCode)
<%if myType < 2 then%>
			window.parent.search.cbody.location.href = "TransferInput.asp?FIN_NO=" & myNo
<%else%>
		dim win
			if myCode <> "" then
				set win = window.open("TransferErase0.asp?FIN_NO=" & myNo, myNo, "resizable=1,scrollbars=1,width=960,height=640")
			else
				set win = window.open("TransferErase1.asp?FIN_NO=" & myNo, myNo, "resizable=1,scrollbars=1,width=960,height=640")
			end if
			win.focus()
<%end if%>
		end function
		
<%if myType = 2 then%>
		sub BankID_OnChange()
		dim myID
			myID = BankID.options(BankID.SelectedIndex).value
			window.location.href = "TransferResult.asp?type=<%=myType%>&BankID=" & myID
		end sub
<%end if%>

		sub DoJump()
			window.location.href = "../Customs/TransferResult.asp"
		end sub
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=30 valign=bottom>
<%if myType < 3 then%>
	  	  <td nowrap width=40% valign=bottom>��
<%select case myType
case 0:		response.write "�쐬�ꗗ"
case 1:		response.write "�m��ꗗ"
case 2:		response.write "�����ꗗ"
end select%>&nbsp;
	  	  <td nowrap width=60%>
<%	select case myType
	case 0:		response.write "�쐬��"
	case 1:		response.write "�m���"
	case 2:		response.write "������"
	end select
%>
			<input class=mi name="SearchDate" size=10 maxlength=10 value="<%=SearchDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<a href="javascript:DoSelect()"><img src=img/search.jpg border=0 alt="����"></a>
<%else%>
		<td><SELECT class=pt12n name="BankID" onkeydown="ResetEnter()"><option value=0>���ׂ�<%=ShowBankList(FIN_BANK_ID, finReceive)%></select>
<%end if%>
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT FIN_NO, FIN_TYPE, FIN_CLIENT_CD, ClientRef, ClientName, FIN_BANK_ID, FIN_AMOUNT, FIN_DATE, FIN_SECURITIES, CONFIRM_ID, ERASE_ID"
		strSql = strSql & " FROM TBL_CTM_FIN AS F INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_NAME AS ClientName FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0 AND SUBSTRING(FIN_NO,3,1) = 'T'"
		select case myType
		case 0
			strSql = strSql & " AND CONVERT(VARCHAR(10), FIN_CREATED, 111) = '" & SearchDate & "'"
		case 1
			strSql = strSql & " AND CONFIRM_ID <> 0 AND CONVERT(VARCHAR(10), CONFIRM_DATE, 111) = '" & SearchDate & "'"
		case 2
			strSql = strSql & " AND ERASE_ID <> 0 AND CONVERT(VARCHAR(10), ERASE_DATE, 111) = '" & SearchDate & "'"
		case 3
			if BankID <> 0 then strSql = strSql & " AND FIN_BANK_ID = " & BankID 
		end select
		strSql = strSql & " ORDER BY FIN_NO"
if WebUserID = gsAdmin then response.write strSQL
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
	  <TR align=center height=20 class=pt12>
		<TD class=line nowrap>��
		<TD class=line nowrap>�U�֔ԍ�
		<TD class=line nowrap align=center>�U�֓�
		<TD class=line nowrap align=left>�U�֐�
		<TD class=line nowrap>�U�֊z
<%if myType = 0 then%>
		<TD class=line nowrap>�m��
<%else%>
		<TD class=line nowrap>����
<%end if%>
		<TD class=line nowrap>����
<%
			cnt = 0
			ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				FIN_NO = GetString(.Fields("FIN_NO"))
				ClientRef = GetString(.Fields("ClientRef"))
				ClientName = GetString(.Fields("ClientName"))
				if myType = 0 then
					if GetLong(.Fields("CONFIRM_ID")) <> 0 then
						status = "<font color=blue>��</font>"
					else
						status = "<font color=red>��</font>"
					end if
				else
					if GetLong(.Fields("ERASE_ID")) <> 0 then
						status = "<font color=green>��</font>"
					else
						status = "<font color=red>��</font>"
					end if
				end if
%>
				<TR align=center height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
					 onclick="ShowDetail('<%=FIN_NO%>', '<%=myCode%>')">
					<TD nowrap class=line><%=cnt%><BR>
					<TD nowrap class=line align=left><%=ShowVoucherNo(FIN_NO)%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("FIN_DATE"))%><BR>
					<TD nowrap class=line align=left style="cursor:help" title="<%=ClientName%>"><%=StringCut(ClientRef,7)%><BR>
					<TD nowrap class=line align=right><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
					<TD nowrap class=line><%=status%><BR>
					<TD nowrap class=line><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
<%
				ttlAmount = ttlAmount + GetLong(.Fields("FIN_AMOUNT"))
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=2>
					<TD class=line>�� �v
					<TD colspan=2 class=line nowrap><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt12r>�Y���U�֓`�[�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
