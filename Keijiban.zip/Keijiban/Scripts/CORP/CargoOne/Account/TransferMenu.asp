<html>
<head>
	<title>�U�֏������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		select case mySel
		case 1
			url = "TransferInput.asp"
			rst = "TransferResult.asp?type=0"
		case 2
			url = "TransferCheck.asp"
			rst = "TransferResult.asp?type=1"
		case 3
			url = "TransferProc.asp"
			rst = "TransferResult.asp?type=2"
		case 4
			url = "TransferView.asp"	
			rst = "TransferResult.asp?type=3"
		end select
		window.parent.cbody.location.href = url 
		window.parent.parent.result.location.href = rst
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=140>
		    	<INPUT type=button class=pt12n style="WIDTH: 120px; HEIGHT: 40px;" name=btnCreate value="�U�֓`�[" onclick="DoAct(1)"></TD>
		    <TD width=140>
		    	<INPUT type=button class=pt12n style="WIDTH: 120px; HEIGHT: 40px;" name=btnCheck value="�U�֊m��" onclick="DoAct(2)"></TD>
		    <TD width=140>
		    	<INPUT type=button class=pt12n style="WIDTH: 120px; HEIGHT: 40px;" name=btnProc value="�U�֏���" onclick="DoAct(3)"></TD>
		    <TD width=140>
				<INPUT type=button class=pt12n style="WIDTH: 120px; HEIGHT: 40px;" name=btnView value="�U�֏Ɖ�" onclick="DoAct(4)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
