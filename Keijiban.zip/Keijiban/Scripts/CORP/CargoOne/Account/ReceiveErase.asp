<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�c�Ɠ����`�[�������
'
'	mode:	1 -- �c�ƔC��
'			2 -- �c�Ə���
'			3 -- �o���m�F
'			4 -- ��������
'
'	FIN_CURRENT		0:����/1:�c��/2:����
'----------------------------------------------

'on error resume next

dim CloseSales
dim CloseStand
dim CloseCosts
dim ChargeSales
dim ChargeStand
dim ChargeCosts

	FIN_NO = GetPost(request("FIN_NO"))	
	if FIN_NO <> "" then
		
		OpenSql Conn, SqlServerName, DataBaseName		
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset
			strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_ORIGINAL = 1 AND FIN_NO = '" & FitSel(FIN_NO) & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				FIN_NO = GetString(.fields("FIN_NO"))
				FIN_DATE = Str2Date(.fields("FIN_DATE"))
				FIN_CLIENT_CD = GetString(.fields("FIN_CLIENT_CD"))		
				FIN_CLIENT_NAME = GetString(.fields("FIN_CLIENT_NAME"))					
				FIN_CLIENT_PIC = GetString(.fields("FIN_CLIENT_PIC"))
				FIN_BANK_ID = GetLong(.fields("FIN_BANK_ID"))
				FIN_AMOUNT = GetLong(.fields("FIN_AMOUNT"))
				FIN_SECURITIES = GetString(.fields("FIN_SECURITIES"))
				FIN_SECURITIES_NO = GetString(.fields("FIN_SECURITIES_NO"))
				FIN_SECURITIES_DATE = Str2Date(.fields("FIN_SECURITIES_DATE"))
				
				FIN_BATCH = GetString(.fields("FIN_BATCH"))
				FIN_BILLNO = GetString(.fields("FIN_BILLNO"))
				FIN_JOBCODE = GetString(.fields("FIN_JOBCODE"))
				FIN_DESCRIPTION = GetString(.fields("FIN_DESCRIPTION"))				
				FIN_MEMO = GetString(.fields("FIN_MEMO"))
				FIN_REMARKS = GetString(.fields("FIN_REMARKS"))	
				
				FIN_CREATER = GetLong(.fields("FIN_CREATER"))
				FIN_CREATED = GetDate(.fields("FIN_CREATED"))
				CONFIRM_ID = GetLong(.fields("CONFIRM_ID"))
				CONFIRM_DATE = GetDate(.fields("CONFIRM_DATE"))
				ERASE_ID = GetLong(.fields("ERASE_ID"))
				ERASE_DATE = GetDate(.fields("ERASE_DATE"))
				FIN_MONTH = GetString(.fields("FIN_MONTH"))
				FIN_CURRENT = GetLong(.fields("FIN_CURRENT"))
			end if
			.close
			
			if FIN_CLIENT_CD <> "" then
				CTM_FINANCE_CD = FIN_CLIENT_CD
				strSql = "SELECT CTM_FINANCE_CD FROM CUSTOMER WHERE CTM_CD = '" & FitSel(FIN_CLIENT_CD) & "'"
				Recset.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not Recset.eof then CTM_FINANCE_CD = GetString(Recset.fields("CTM_FINANCE_CD"))
				Recset.Close
				
				if GetCtmClose(FIN_CLIENT_CD, CloseSales, CloseStand, CloseCosts) then
					SalesCloseDate = Close2Date(CloseSales, Stand)
					StandCloseDate = Close2Date(CloseStand, Stand)
					SalesClose = ShowClose(CloseSales)
					StandClose = ShowClose(CloseStand)
				end if
				if GetCtmSight(FIN_CLIENT_CD, ChargeSales, ChargeStand, ChargeCosts) then
					SalesSightDate = FitDatePlus(Sight2Date(ChargeSales, SalesCloseDate))
					if Date2Str(SalesSightDate) = Date2Str(SalesCloseDate) then SalesSightDate = FitDatePlus(dateadd("d", 7, SalesSightDate))
					StandSightDate = FitDatePlus(Sight2Date(ChargeStand, StandCloseDate))
					if Date2Str(StandSightDate) = Date2Str(StandCloseDate) then StandSightDate = FitDatePlus(dateadd("d", 7, StandSightDate))
					SalesSight = ctmCredit(ChargeSales \ 1000) & ShowPayDay(ChargeSales mod 1000)
					StandSight = ctmCredit(ChargeStand \ 1000) & ShowPayDay(ChargeStand mod 1000)
				end if
			end if
		end with
	end if

	if ERASE_ID <> 0 then
		response.write "�Y�������`�[�͊��ɏ������݂���܂����B"	
	elseif CONFIRM_ID = 0 then
		response.write "�Y�������`�[�͂܂��m�肳��Ă��܂���B"	
	elseif FIN_CURRENT = 2 then
%>
<html>
<script language=javascript>
alert("�Y�������`�[�͊��Ɍo���ɑ���܂����B");
window.close();
</script>
</html>
<%
	else		
%>
<html>
<HEAD>
	<TITLE>�����`�[����</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoSort(myNo)
			window.location.href = "ReceiveErase.asp?FIN_NO=<%=FIN_NO%>&sort=" & myNo
		end function
		
		sub DoReset()
		dim sum, nos, ttl
			sum = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then
					if left(obj.name,4) = "DATA" and obj.checked then
						nos = nos & "," & GetLeft(obj.value, ".")
						ttl = ttl & "," & GetRight(obj.value, ".")
						sum = sum + GetLong(GetRight(obj.value, ".")) 	
					end if
				end if
			next
			frmInput.ChargeNos.value = mid(nos, 2)
			frmInput.ChargeTotal.value = mid(ttl, 2)
			frmInput.ChargeAmount.value = formatnumber(sum, 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close() 
		end sub
		
		sub DataSave(mode)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'				exit sub
'			end if 
			if GetLong(frmInput.BankPostage.value) > <%=gsMaxPostage%> then 
				msgbox "���͂����ʐM��͑������ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if GetLong(frmInput.FromReceive.value) <> 0 and _
			   GetLong(frmInput.OverReceive.value) <> 0 then
				msgbox "�u�a������v�Ɓu�a����ցv�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if 
			if GetLong(frmInput.MassProfit.value) <> 0 and _
			   GetLong(frmInput.MassLoss.value) <> 0 then
				msgbox "�u�G���v�Ɓu�G���v�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if 
			if checkText("FIN_MEMO","��������", 0) = false then exit sub
			if checkLen("FIN_MEMO","��������", 250) = false then exit sub
			if checkLen("FIN_REMARKS","�c�ƃ���", 250) = false then exit sub
			if mode = 2 then
				if checkText("FIN_REMARKS","�c�ƃ���", 0) = false then exit sub
				if clng(frmInput.EraseResult.value) <> 0 then 
					msgbox "�ؕ����z�͑ݕ����z�ƍ���Ȃ��ł��B", 48, "�m�F���b�Z�[�W"
					exit sub
				end if
				if msgbox ("�Y���������݌��ʂ��o���ɑ����Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			else
				if checkText("FIN_REMARKS","�c�ƃ���", 0) = false then exit sub
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub OverReceive_OnBlur()
			frmInput.OverReceive.value = formatnumber(GetLong(frmInput.OverReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub FromReceive_OnBlur()
			frmInput.FromReceive.value = formatnumber(GetLong(frmInput.FromReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'			end if 
		end sub		
		sub MassProfit_OnBlur()
			frmInput.MassProfit.value = formatnumber(GetLong(frmInput.MassProfit.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub MassLoss_OnBlur()
			frmInput.MassLoss.value = formatnumber(GetLong(frmInput.MassLoss.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub FromDraft_OnBlur()
			frmInput.FromDraft.value = formatnumber(GetLong(frmInput.FromDraft.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub OverDraft_OnBlur()
			frmInput.OverDraft.value = formatnumber(GetLong(frmInput.OverDraft.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub BankPostage_OnBlur()
			frmInput.BankPostage.value = formatnumber(GetLong(frmInput.BankPostage.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub	
		function DoCalculate()
		dim debit, credit 
			debit = GetLong(frmInput.FIN_AMOUNT.value) + GetLong(frmInput.FromReceive.value) + GetLong(frmInput.MassLoss.value)
			debit = debit + GetLong(frmInput.BankPostage.value) + GetLong(frmInput.FromDraft.value)
			credit = GetLong(frmInput.ChargeAmount.value) + GetLong(frmInput.OverReceive.value) + GetLong(frmInput.MassProfit.value)
			credit = credit + GetLong(frmInput.OverDraft.value)
			DoCalculate = debit - credit
		end function
		
		function DoUseDeposit(myAmount)
<%if ERASE_ID = 0 then%>
			frmInput.FromReceive.value = formatnumber(GetLong(myAmount), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
<%end if%>
		end function	
	</SCRIPT>
</Head>
<body leftmargin=10 topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
<FORM name=frmInput action="ReceiveSave1.asp" method=post>
	<input type=hidden name="mode" value="0">
<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
  <tr><td width=50% valign=top>
  <!--�����F�����`�[���-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>�������`�[���&nbsp;
	  	<td width=50% nowrap>�����ԍ��F<%=FIN_NO%><input type=hidden name="FIN_NO" value="<%=FIN_NO%>">
	</table>
	<hr width=98% size=1 color=blue>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=24>
		<TD nowrap colspan=6>
			������&nbsp;(<input class=si name="FIN_CLIENT_REF" size=7 value="<%=GetRefName(FIN_CLIENT_CD)%>" readonly>)
				<input class=si name="FIN_CLIENT_NAME" size=48 value="<%=FIN_CLIENT_NAME%>" readonly>
	  <TR height=24>
		<TD nowrap colspan=6 class=pt9g>
			������ <input class=si name="ChargeClose" size=8 maxlength=10 value="<%=SalesClose%>" onkeydown="ResetEnter()" readonly>
			���� <input class=si name="ChargeSight" size=10 maxlength=10 value="<%=SalesSight%>" onkeydown="ResetEnter()" readonly>
	 		���֒� <input class=si name="StandClose" size=8 maxlength=10 value="<%=StandClose%>" onkeydown="ResetEnter()" readonly>
			���� <input class=si name="StandSight" size=10 maxlength=10 value="<%=StandSight%>" onkeydown="ResetEnter()" readonly>
	  <TR height=24>
		<TD nowrap colspan=6>
			����S��&nbsp;<input class=sj name="FIN_CLIENT_PIC" size=20 value="<%=FIN_CLIENT_PIC%>" readonly>
			������&nbsp;<input class=si name="FIN_DATE" size=9 value="<%=FIN_DATE%>" readonly>
			�����z&nbsp;<input class=sn name="FIN_AMOUNT" size=9 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" readonly>
	  <TR height=24>
		<TD nowrap colspan=6>
			������s&nbsp;<input class=si name="FIN_BANK_ID" size=55 value="<%=GetBankName(FIN_BANK_ID)%>" readonly>
	  <TR height=24>
		<TD nowrap colspan=6>
			�����K�v&nbsp;<input class=sz name="FIN_DESCRIPTION" size=55 value="<%=FIN_DESCRIPTION%>" readonly>
	  <TR height=24>
		<TD nowrap>�ޯ���<TD><input class=si name="FIN_BATCH" size=6 value="<%=FIN_BATCH%>" readonly>
		<TD nowrap>�䒠�ԍ�<TD><input class=si name="FIN_JOBCODE" size=10 value="<%=FIN_JOBCODE%>" readonly>
		<TD nowrap>�����ԍ�<TD><input class=si name="FIN_BILLNO" size=10 value="<%=FIN_BILLNO%>" readonly>
	  <TR height=24>
	  	<TD nowrap>����<TD><input class=si name="FIN_SECURITIES" size=6 value="<%=FIN_SECURITIES%>" readonly>
		<TD nowrap>����ԍ�<TD><input class=si name="FIN_SECURITIES_NO" size=10 value="<%=FIN_SECURITIES_NO%>" readonly>
		<TD nowrap>����T�C�g<TD><input class=si name="FIN_DATE" size=10 value="<%=FIN_SECURITIES_DATE%>" readonly>
	  <TR>
		<TD colspan=6>��������<br><textarea class=pt9n name="FIN_MEMO" rows=4 style="width:400" readonly><%=FIN_MEMO%></textarea>
	  <TR>
		<TD colspan=6 class=pt9n>��������<br><textarea class=pt9n name="FIN_REMARKS" rows=4 style="width:400"><%=FIN_REMARKS%></textarea>
	</TABLE>
	<table width=90% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=24 align=center>
		<TD width=10% class=pt9g>�쐬��<TD width=15% class=gline><%=GetEmployName(FIN_CREATER, "F")%><br>
		<TD width=10% class=pt9g>�m�F��<TD width=15% class=gline><%=GetEmployName(CONFIRM_ID, "F")%><br>
		<TD width=10% class=pt9g>������<TD width=15% class=gline><%=GetEmployName(ERASE_ID, "F")%><br>
	  <TR height=24 align=center>
		<TD class=pt9g>�쐬��<TD class=gline><%=formatDate(FIN_CREATED)%><br>
		<TD class=pt9g>�m�F��<TD class=gline><%=formatDate(CONFIRM_DATE)%><br>
		<TD class=pt9g>������<TD class=gline><%=formatDate(ERASE_DATE)%><br>
	</TABLE>
	<br>
<%
dim FIN_DEPOSIT
	myList = ShowAccountDetail(finReceive, Conn, FIN_NO, FIN_CLIENT_CD, FIN_DEPOSIT)
%>
	<table width=90% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>���a����c���F&nbsp;<input type=hidden name="FIN_DEPOSIT" value="<%=FIN_DEPOSIT%>">
<%if FIN_DEPOSIT >= 0 then%>
	  	<td width=50% nowrap align=right>\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%else%>
	  	<td width=50% nowrap align=right style="color:red">\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%end if%>
	</table>
	<HR width=95% size=1 color=green align=left>
  <!--�����F�c�����׏��-->	
	<TABLE width=96% Cellspacing=3 CellPadding=3 class=pt9n>
	<TR height=20 class=pt9>
		<TD class=line width=30>��
		<TD class=line width=80>���o���ԍ�
		<TD class=line width=60>���o����
		<TD class=line width=80>�a�����
		<TD class=line width=80>�a������
		<TD class=line width=80>�a����c��
		<TD class=line width=20>
	<%=myList%>
	</TABLE>
	
  <td width=50% valign=top align=center>
  <!--�E���F�Ɩ��������-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>���Ɩ��������&nbsp;
	  	<td width=50% nowrap>
	</table>
	<hr width=98% size=1 color=blue>
	<TABLE width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=24>
		<TD nowrap>
			������&nbsp;<input class=si name="ClientName" size=48 value="<%=GetFullName(FIN_CLIENT_CD)%>" onkeydown="ResetEnter()" readonly>
			(<%=FIN_CLIENT_CD%>)
			<INPUT class=pt9n TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
	</TABLE>
<div id=list>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>�����
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�����ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">������
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�������z
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">������
		<TD class=line nowrap>�I��
<%		
		cnt = 0
		ChargeAmount = 0
		ChargeAmountAll = 0
		ChargeNos = ""
		ChargeTotal = ""
		
		with recset
			'�����������ݏ��擾
			myEraseNo = ""
			FIN_BATCHS = ""
			FIN_BILLNOS = ""
			strSql = "SELECT ERASE_BATCH, ERASE_BIZ_NO FROM TBL_CTM_ERASE WHERE ERASE_FIN_NO = '" & FIN_NO & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not .eof
				if GetString(.Fields("ERASE_BATCH")) <> "" then FIN_BATCHS = FIN_BATCHS & "," & GetString(.Fields("ERASE_BATCH"))
				if GetString(.Fields("ERASE_BIZ_NO")) <> "" then FIN_BILLNOS = FIN_BILLNOS & "," & GetString(.Fields("ERASE_BIZ_NO"))
				.movenext
			loop
			.Close
			myEraseNo = FIN_BATCHS & FIN_BILLNOS
			if myEraseNo <> "" then myEraseNo = ResetEraseNos(mid(myEraseNo, 2))
			
			'�Y����������擾
			if true then
				strSql = "SELECT BatchNo, '' AS JobCode, '' AS ChargeNo, BatchClient AS ChargeClient, BatchBillDay AS ChargeDate, BatchPayDay AS ChargePayDay"
				strSql = strSql & ", Remarks, BatchAmount AS ChargeTotal, ConfirmerID, FinisherID FROM TBL_CTM_BATCH INNER JOIN (SELECT CTM_CD, CTM_FINANCE_CD"
				strSql = strSql & " FROM CUSTOMER WHERE CTM_FINANCE_CD = '" & CTM_FINANCE_CD & "') AS C ON TBL_CTM_BATCH.BatchClient = C.CTM_CD"
				strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND SUBSTRING(BatchNo, 1, 1) = '" & gsBatchPrint & "'"
				strSql = strSql & " UNION ALL "
				strSql = strSql & " SELECT '' AS BatchNo, JobCode, ChargeNo, ChargeClient, ChargeDate, ChargePayDay, Remarks"
				strSql = strSql & ", (ChargeAmount + ChargeTax) AS ChargeTotal, ConfirmerID, FinisherID FROM TBL_CTM_CHARGE"
				strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_FINANCE_CD FROM CUSTOMER WHERE CTM_FINANCE_CD = '" & CTM_FINANCE_CD
				strSql = strSql & "') AS C ON TBL_CTM_CHARGE.ChargeClient = C.CTM_CD"
				strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ChargeBatch = ''"
				select case GetLong(request("sort"))
				case 0:		strSql = strSql & " ORDER BY ChargeDate"
				case 1:		strSql = strSql & " ORDER BY JobCode"
				case 2:		strSql = strSql & " ORDER BY ChargeNo"
				case 3:		strSql = strSql & " ORDER BY ChargeTotal"
				case 4:		strSql = strSql & " ORDER BY ChargePayDay"
				end select				
if WebUserID = gaAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof
					cnt = cnt + 1
					BatchNo = GetString(.Fields("BatchNo"))
					ChargeNo = GetString(.Fields("ChargeNo"))
					if BatchNo <> "" then myMemo = GetString(.Fields("Remarks"))
					myCheckNo = GetString(.Fields("BatchNo")) & GetString(.Fields("ChargeNo"))
					myAmount = GetLong(.Fields("ChargeTotal"))
					mycolor = "black"
					if CheckVoucherType(GetString(.Fields("ChargeNo"))) = "S" then mycolor = "green"
					status = ""
					if GetLong(.Fields("ConfirmerID")) = 0 then
						status = "<font color=gray>��</font>"
					else
						myChargeNo = CheckEtcErased(Conn, FIN_NO, myCheckNo, 2)
						if myChargeNo <> "" then
							status = ResetBizNo(myChargeNo)
						elseif instr(myEraseNo, myCheckNo) <> 0 then
							ChargeAmount = ChargeAmount + myAmount	
							ChargeTotal = ChargeTotal & "," & myAmount
							ChargeNos = ChargeNos & "," & myCheckNo
						end if
					end if
%>
				<TR height=20>
					<TD class=line><%=cnt%><BR>
					<TD class=line nowrap><%=ShowBatchNo(BatchNo)%><BR>
				<%if BatchNo <> "" then%>
					<TD class=line nowrap colspan=2><%=myMemo%><BR>
				<%else%>
					<TD class=line nowrap style="color:<%=mycolor%>"><%=ShowVoucherNo(ChargeNo)%><BR>
					<TD class=line nowrap><%=ShowJobCode(GetString(.Fields("JobCode")))%><BR>
				<%end if%>
					<TD class=line align=center><%=Str2YMD(.Fields("ChargeDate"))%><BR>
					<TD class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
					<TD class=line align=center style="color:blue"><%=Str2YMD(.Fields("ChargePayDay"))%><BR>
					<%if status <> "" then %>
					<TD class=line align=center><%=status%>
					<%else %>
					<TD class=line align=center><input type=checkbox name="DATA<%=cnt%>" value="<%=myCheckNo%>.<%=myAmount%>" onclick="DoReset()" 
						<%if instr(myEraseNo, myCheckNo) <> 0 then response.write "checked"%>>
<%				
					end if
					ChargeAmountAll = ChargeAmountAll + myAmount
					.movenext
				loop
				.Close
			end if
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD class=pt9 colspan=4>���v���z
					<TD class=line  colspan=2 align=right><%=formatnumber(ChargeAmountAll, 0, true)%><BR>
			
<%			end if %>

		</TABLE>
</div>
<%
			if cnt = 0 then 
%>
			<br>
			<div>
				<font class=pt9r>�Y��������̖������������͌�����܂���ł����B</font>
			</div>
			<br>
			<hr width=98% size=1 color=gray>
			<br>
			<TABLE width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
			  <TR height=24>
				<TD nowrap>
					�������z&nbsp;<input class=sn name="ClientAmount" size=20 value="<%=formatnumber(FIN_AMOUNT,0,true) & "�`" & formatnumber(FIN_AMOUNT + gsMinPostage,0,true)%>" onkeydown="ResetEnter()" readonly>
			</TABLE>
			<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			  <TR height=20 class=pt9>
				<TD class=line nowrap>��
				<TD class=line nowrap>������
				<TD class=line nowrap>�����ԍ�
				<TD class=line nowrap>�䒠�ԍ�
				<TD class=line nowrap>������
				<TD class=line nowrap>�������z
				<TD class=line nowrap>������
				<TD class=line nowrap>�I��
<%
				'�Y���������z���擾
				if FIN_CLIENT_CD = gsCorpSoko then
					strSql = "SELECT ClientRef, ChargeNo, JobCode, ChargeClientName, ChargeDate, ChargePayDay, (ChargeAmount + ChargeTax) AS ChargeTotal, ConfirmerID, FinisherID"
					strSql = strSql & " FROM TBL_CTM_CHARGE AS T INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
					strSql = strSql & " WHERE Deleted = 0 AND ChargeBatch = '' AND FinisherID = 0 AND ChargeClient = '" & gsDummy & "'"
					strSql = strSql & " ORDER BY (ChargeAmount + ChargeTax)"
				else
					strSql = "SELECT ClientRef, ChargeNo, JobCode, ChargeClientName, ChargeDate, ChargePayDay, (ChargeAmount + ChargeTax) AS ChargeTotal, ConfirmerID, FinisherID"
					strSql = strSql & " FROM TBL_CTM_CHARGE AS T INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.ChargeClient = C.CTM_CD"
					strSql = strSql & " WHERE Deleted = 0 AND ChargeBatch = '' AND FinisherID = 0 AND (ChargeAmount + ChargeTax) between " & FIN_AMOUNT & " AND " & FIN_AMOUNT + gsMinPostage
					strSql = strSql & " ORDER BY (ChargeAmount + ChargeTax)"
				end if
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof
					cnt = cnt + 1
					ClientRef = GetString(.Fields("ClientRef"))
					ClientName = GetString(.Fields("ChargeClientName"))
					ChargeNo = GetString(.Fields("ChargeNo"))
					myAmount = GetLong(.Fields("ChargeTotal"))
					status = ""
					if GetLong(.Fields("ConfirmerID")) = 0 then
						status = "<font color=gray>��</font>"
					else
						myChargeNo = CheckEtcErased(Conn, FIN_NO, ChargeNo, 2)
						if myChargeNo <> "" then
							status = ResetBizNo(myChargeNo)
						elseif instr(myEraseNo, myCheckNo) <> 0 then
							ChargeAmount = ChargeAmount + myAmount
							ChargeTotal = ChargeTotal & "," & myAmount
							ChargeNos = ChargeNos & "," & ChargeNo
						end if
					end if
%>
				<TR height=20>
					<TD class=line><%=cnt%><BR>
					<TD class=line nowrap align=left title="<%=ClientName%>"><%=StringCut(ClientRef, 7)%><BR>
					<TD class=line nowrap align=left><%=ShowVoucherNo(ChargeNo)%><BR>
					<TD class=line nowrap align=left><%=ShowJobCode(GetString(.Fields("JobCode")))%><BR>
					<TD class=line><%=Str2Date(.Fields("ChargeDate"))%><BR>
					<TD class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
					<TD class=line style="color:blue"><%=Str2Date(.Fields("ChargePayDay"))%><BR>
					<%if status <> "" then %>
					<TD class=line><%=status%>
					<%else %>
					<TD class=line><input type=checkbox name="DATA<%=cnt%>" value="<%=ChargeNo%>.<%=myAmount%>" onclick="DoReset()"
						<%if instr(myEraseNo, ChargeNo) <> 0 then response.write "checked"%>>
<%				
					end if
					ChargeAmountAll = ChargeAmountAll + myAmount
					.movenext
				loop
				.Close
%>	
			</TABLE>
<%
				if cnt = 0 then 
%>
			<br>
			<div>
				<font class=pt9r>�Y���������z�̖������������͌�����܂���ł����B</font>
			</div>
<%
				end if
			end if
		end with
%>
	<BR>
	<HR width=100% size=1 color=green>
  <!--�����F�����������-->
<%		
		FromReceive = 0
		OverReceive = 0
		MassProfit = 0
		MassLoss = 0
		FromDraft = 0
		OverDraft = 0
		BankPostage = 0	
		with Recset
			strSql = "SELECT FIN_NO, FIN_TYPE, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_BANK_ID FROM TBL_CTM_FIN"
			strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_NO = '" & FIN_NO & "'"
if WebUserID = gsAdmin then response.write strSQL
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not .eof
				select case GetLong(.Fields("FIN_DEBIT"))
				case acntOverReceive
					FromReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a������
				case acntMassLoss
					MassLoss = GetLong(.Fields("FIN_AMOUNT"))						'�G����
				case acntFromDraft
					FromDraft = GetLong(.Fields("FIN_AMOUNT"))						'��`����
				case acntPostage
					BankPostage = GetLong(.Fields("FIN_AMOUNT"))					'�ʐM��
				end select
				
				select case GetLong(.Fields("FIN_CREDIT"))
				case acntOverReceive
					OverReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a�����
				case acntMassProfit
					MassProfit = GetLong(.Fields("FIN_AMOUNT"))						'�G�v��
				case acntOverDraft
					OverDraft = GetLong(.Fields("FIN_AMOUNT"))						'��`��
				case acntPostage
					BankPostage = 0 - GetLong(.Fields("FIN_AMOUNT"))				'�ʐM��
				end select
				.movenext
			loop
			.close
		end with
		EraseResult = FIN_AMOUNT + FromReceive + MassLoss - ChargeAmount - OverReceive - MassProfit
		EraseResult = EraseResult + BankPostage + FromDraft - OverDraft
%>
	<TABLE width=80% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20 align=center>
		<TD class=line colspan=2>�ؕ�
		<TD class=line colspan=2>�ݕ�	
			
	  <TR height=20 align=center>
		<TD class=line>���z
		<TD class=line>�Ȗ�
		<TD class=line>�Ȗ�
		<TD class=line>���z
		
	  <TR align=right height=20>
		<TD><input class=sn name="ReceiveAmount" size=9 maxlength=10 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" onkeydown="ResetEnter()" Readonly>
		<TD align=left>�@����
		<TD><font color=blue>(����)���|</font>
		<TD><input class=sn name="ChargeAmount" size=9 maxlength=10 value="<%=formatnumber(ChargeAmount,0,true)%>" onkeydown="ResetEnter()" Readonly>
		
	  <TR align=right height=20>
		<TD><input class=sn name="FromReceive" size=9 maxlength=10 value="<%=formatnumber(FromReceive, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left nowrap>�@�a������
		<TD>�a����
		<TD><input class=sn name="OverReceive" size=9 maxlength=10 value="<%=formatnumber(OverReceive, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20 class=pt9>
		<TD><input class=sn name="MassLoss" size=9 maxlength=10 value="<%=formatnumber(MassLoss, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@�G��
		<TD>�G��
		<TD><input class=sn name="MassProfit" size=9 maxlength=10 value="<%=formatnumber(MassProfit, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20 class=pt9>
		<TD><input class=sn name="FromDraft" size=9 maxlength=10 value="<%=formatnumber(FromDraft, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@��`����
		<TD>��`��
		<TD><input class=sn name="OverDraft" size=9 maxlength=10 value="<%=formatnumber(OverDraft, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20>
		<TD><input class=sn name="BankPostage" size=9 maxlength=10 value="<%=formatnumber(BankPostage, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left style="cursor:help" title="<%=GetClientPostage(FIN_CLIENT_CD)%>">�@�ʐM��
		<TD nowrap class=pt9r>�������z
		<TD><input class=sn name="EraseResult" size=9 maxlength=10 value="<%=formatnumber(EraseResult, 0, true)%>" onkeydown="ResetEnter()" Readonly>
	</TABLE>
	<TABLE width=98% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20>
	  	<TD colspan=4>
	  		<HR width=100% size=1 color=green>
	  	
	  <TR height=20>
	  	<TD colspan=4 align=center>
<%if ERASE_ID = 0 and FIN_CURRENT = 1 and (GetSalesManager(FIN_CLIENT_CD) = WebUserID or CheckUserLevel(UserShop, "") > 2) then%>
			<INPUT type=button class=pt9n style="WIDTH: 140px; HEIGHT: 40px;" name=btnSave value="���������m��" onclick="DataSave(2)">�@
<%end if%>
			<INPUT type=button class=pt9n style="WIDTH: 140px; HEIGHT: 40px;" name=btnClose value="��ʂ����" onclick="window.close()">
	</TABLE>
<input type=hidden name="ChargeNos" value="<%=mid(ChargeNos, 2)%>">
<input type=hidden name="ChargeTotal" value="<%=mid(ChargeTotal, 2)%>">
</FORM>
<center>
</body></html>
<%	
	end if
	
	set Recset = nothing
	CloseDB Conn
%>
