<!-- #include file="../common/common.asp" -->
<html>
<head>
	<title>�����������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		btnCreate.style.color = "black"
		btnCheck.style.color = "black"
		btnErase.style.color = "black"
		btnView.style.color = "black"
		btnBalance.style.color = "black"
		select case mySel
		case 1
			url = "ReceiveInput.asp"
			rst = "ReceiveResult.asp?type=0"
			btnCreate.style.color = "red"
		case 2
			url = "ReceiveCheck.asp"
			rst = "ReceiveResult.asp?type=1"
			btnCheck.style.color = "red"
		case 3
			url = "ReceiveProc.asp"
			rst = "ReceiveResult.asp?type=2"
			btnErase.style.color = "red"
		case 4
			url = "ReceiveView.asp"	
			rst = "ReceiveResult.asp?type=3"
			btnView.style.color = "red"
		case 5
			url = "ReceiveBalance.asp"
			btnBalance.style.color = "red"
		end select
		window.parent.cbody.location.href = url 
		window.parent.parent.result.location.href = rst
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px" name=btnCreate value="�����`�[" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px" name=btnCheck value="�����m��" onclick="DoAct(2)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px" name=btnErase value="��������" onclick="DoAct(3)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px" name=btnView value="�����Ɖ�" onclick="DoAct(4)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px" name=btnBalance value="�c���Ɖ�" onclick="DoAct(5)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
