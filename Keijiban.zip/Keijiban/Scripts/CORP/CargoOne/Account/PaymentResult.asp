<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%

'----------------------------------------------
'	�o���`�[�ꗗ�Ɖ���
'----------------------------------------------

myCheck = 1
select case  session("WebUserID")
case 36, 88
    myCheck = 0
end select



'	�q�ɂ̏ꍇ�͎x�X�ʏ����K�v
	if CheckAccountLevel() < 2 then FIN_BANK_ID = GetDefaultBank()

'on error resume next
		
	SearchDate = GetDate(request("SearchDate"))
	if SearchDate = "" then SearchDate = formatDate(date)
	
	myType = GetLong(request("type"))
	SalesManager = GetLong(request("SalesManager"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�o���`�[�ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language=vbscript src="../common/css/function.vbs"></SCRIPT>
	<SCRIPT language=vbscript>	
		sub SearchDate_OnBlur()
			SearchDate.value = setdate(SearchDate.value)
		end sub
	
		function DoSelect()
			window.location.href = "PaymentResult.asp?type=<%=myType%>&SearchDate=" & setdate(SearchDate.value)
		end function
		
		function ShowDetail(myNo, myBatch)
		dim win, url
			if myBatch = "" then
				set win = window.open("PaymentErase0.asp?type=<%=myType%>&FIN_NO=" & myNo,myNo,"resizable=1,scrollbars=1,width=960,height=640")
			else
				set win = window.open("PaymentErase1.asp?type=<%=myType%>&FIN_NO=" & myNo,myNo,"resizable=1,scrollbars=1,width=960,height=640")
			end if
			win.focus()
		end function		
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR valign=bottom>
	  	  <td nowrap width=40% valign=bottom>��<%
select case myType
case 0, 1:	response.write "�o���ꗗ"
case 2:		response.write "�����ꗗ"
case 3:		response.write "�m��ꗗ"
end select%>&nbsp;
	  	  <td nowrap width=60%><%
select case myType 
case 0, 1:	response.write "�쐬��"
case 2:		response.write "������"
case 3:		response.write "�m���"
end select%><input class=si name="SearchDate" size=10 maxlength=10 value="<%=SearchDate%>" onclick="setday(this)" onkeydown="ResetEnter()">
			<a href="javascript:DoSelect()"><img src=img/searchs.jpg border=0 alt="����"></a>
	</table>
	<hr size=1 color=blue>
<%
	with recset
		strSql = "SELECT FIN_NO, FIN_BATCH, FIN_TYPE, FIN_CLIENT_CD, ClientRef, SalesManager, FIN_CLIENT_PIC, FIN_BELONG, FIN_AMOUNT, FIN_DATE, FIN_SECURITIES, CONFIRM_ID, ERASE_ID"
		strSql = strSql & " FROM TBL_CTM_FIN AS F INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef, CTM_SALESMNGR AS SalesManager FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND SUBSTRING(FIN_NO,3,1) = 'P'"
		if myCheck then
			if FIN_BANK_ID <> 0 then strSql = strSql & " AND FIN_BANK_ID = " & FIN_BANK_ID
		else
			strSql = strSql & " AND FIN_CREATER IN (36, 88)"
		end if
		select case myType
		case 0, 1
			if myType = 0 then
				strSql = strSql & " AND FIN_BATCH = ''"
			else
				strSql = strSql & " AND FIN_BATCH <> ''"
			end if
			strSql = strSql & " AND CONVERT(VARCHAR(10), FIN_CREATED, 111) = '" & SearchDate & "'"
		case 2
			strSql = strSql & "AND FIN_ORIGINAL = 1 AND ERASE_ID <> 0 AND CONVERT(VARCHAR(10), ERASE_DATE, 111) = '" & SearchDate & "'"
		case 3
			strSql = strSql & "AND FIN_ORIGINAL = 1 AND CONFIRM_ID <> 0 AND CONVERT(VARCHAR(10), CONFIRM_DATE, 111) = '" & SearchDate & "'"
		end select
		strSql = strSql & " ORDER BY FIN_NO"
if WebUserID = gsAdmin then response.write strSQL
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR align=center height=20 class=pt9>
		<TD class=line nowrap>��
		<TD class=line nowrap>�o���ԍ�
		<TD class=line nowrap align=center>�o����
		<TD class=line nowrap align=left>�o����
		<TD class=line nowrap>�o���z
<%if myType < 2 then%>
		<TD class=line nowrap>����
<%else%>
		<TD class=line nowrap>�m��
<%end if%>
		<TD class=line nowrap>����
<%
			cnt = 0
			ttlAmount = 0
			do while not .eof
				cnt = cnt + 1
				FIN_NO = GetString(.Fields("FIN_NO"))
				FIN_BATCH = GetString(.Fields("FIN_BATCH"))
				RefName = GetString(.Fields("ClientRef"))
				PicName = GetString(.Fields("FIN_CLIENT_PIC"))
				if myType < 2 then
					if GetLong(.Fields("ERASE_ID")) <> 0 then
						status = "<font color=green>��</font>"
					else
						status = "<font color=gray>��</font>"
					end if
				else
					if GetLong(.Fields("CONFIRM_ID")) <> 0 then
						status = "<font color=black>��</font>"
					else
						status = "<font color=red>��</font>"
					end if
				end if
%>
				<TR align=center height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
					 onclick="ShowDetail('<%=FIN_NO%>', '<%=FIN_BATCH%>')">
					<TD nowrap class=line align=right><%=cnt%><BR>
					<TD nowrap class=line align=left><%=ShowVoucherNo(FIN_NO)%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("FIN_DATE"))%><BR>
					<TD nowrap class=line nowrap align=left <%=ShowTitle(RefName, 7)%>><%=StringCut(RefName,7)%><BR>
					<TD nowrap class=line nowrap align=right><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
					<TD nowrap class=line><%=status%><BR>
					<TD nowrap class=line><%=GetString(.Fields("FIN_SECURITIES"))%><BR>
<%
				ttlAmount = ttlAmount + GetLong(.Fields("FIN_AMOUNT"))
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=2>
					<TD class=line>�� �v
					<TD colspan=2 class=line nowrap><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "<font class=pt9r>�Y���o���`�[�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
