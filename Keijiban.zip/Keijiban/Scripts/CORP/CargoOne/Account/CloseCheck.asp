<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����ߏ������
'----------------------------------------------

'on error resume next
dim mode
dim AccountMonth
dim AccountFrom
dim AccountTo
dim ShowCount	
	
	ShowCount = 10
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	SelType = GetLong(request("type"))
	SelYear = GetLong(request("SelYear"))
	SelMonth = GetLong(request("SelMonth"))
	if SelYear = 0 or SelMonth = 0 then
		SelDate = date
		if day(SelDate) <= 31 then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
	end if
	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����ߎd��΍�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub InitForm()
			frmInput.SelYear.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY class=pt9 onload="InitForm()" <%=gsBodyControl%>>
<!--�d��΍����x�ݒ�-->
  <FORM METHOD="POST" ACTION="CloseCheck.asp" ID=frmInput NAME=frmInput>
	<input type=hidden name="type" value="0">
	<table class=pt9>
		<TR><TD nowrap>			
			��v���x&nbsp;
				<select name="SelYear" onkeydown="ResetEnter()"><%
				for i = year(date) to year(gsSysStart) step -1
					response.write "<option value=" & i
					if i = SelYear then response.write " selected"
					response.write ">" & i
				next%></select>&nbsp;�N
				<select name="SelMonth" onkeydown="ResetEnter()"><%
				for i = 1 to 12
					response.write "<option value=" & i
					if i = SelMonth then response.write " selected"
					response.write ">" & i
				next%></select>&nbsp;��
			<TD nowrap>	
				<INPUT style="width:80px;height:30px;" TYPE=SUBMIT VALUE="���s">					
	</table>

	<table class=pt9n cellspacing=3>
	  <tr height=24 align=center bgcolor="#E0E0E0"><td rowspan=2 width=50>���m��
	  	<td width=170>����<td width=170>�x��<td width=170>�ޯ�<td width=170>�e��
	  <tr height=24 align=center><td valign=top>
<%
	'���������m��ꗗ
	with Recset
		strSql = "SELECT ChargeNo, (ChargeAmount+ChargeTax) AS ChargeTotal FROM TBL_CTM_CHARGE"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID = 0"
		strSql = strSql & " AND ChargeDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY ChargeNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>������<td>�������z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("ChargeNo") & "<td>" & .fields("ChargeTotal")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("ChargeTotal")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�x���`�[���m��ꗗ
	with Recset
		strSql = "SELECT CostsNo, C.JobCode, (C.CostsAmount+C.CostsTax) AS CostsTotal"
		strSql = strSql & " FROM TBL_CTM_COSTS AS C INNER JOIN TBL_CTM_JOB AS J ON C.JobCode = J.JobCode"
		strSql = strSql & " WHERE J.Deleted = 0 AND C.Deleted = 0 AND C.ConfirmerID = 0"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "' ORDER BY CostsNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�x����<td>�x�����z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("CostsNo") & "<td>" & .fields("CostsTotal")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("CostsTotal")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�ޯ��ԍ����m��ꗗ
	with Recset
		strSql = "SELECT BatchNo, BatchAmount FROM TBL_CTM_BATCH WHERE Deleted = 0 AND ConfirmerID = 0"
		strSql = strSql & " AND BatchBillDay BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BatchNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�ޯ���<td>�ޯ����z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("BatchNo") & "<td>" & .fields("BatchAmount")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("BatchAmount")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�e�����m��ꗗ
	with Recset
		strSql = "SELECT JobCode, Interests FROM TBL_CTM_JOB WHERE Deleted = 0 AND LockerID = 0"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>���m��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�䒠�ԍ�<td>�e��"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("JobCode") & "<td>" & .fields("Interests")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("Interests")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	</table>
	

	<table class=pt9n cellspacing=3>
	  <tr height=24 align=center bgcolor="#E0E0E0"><td rowspan=2 width=50>������
	  	<td width=170>����<td width=170>�x��<td width=170>����<td width=170>�o��
	  <tr height=24 align=center><td valign=top>
<%
	'�������������ꗗ
	with Recset
		strSql = "SELECT BIZ_NO, SUM(BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0"
		strSql = strSql & " AND BIZ_FIN_NO = '' AND BIZ_TYPE IN (" & bizSales & "," & bizStandR & ")"
'		strSql = strSql & " AND BIZ_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_NO IN (SELECT ChargeNo FROM TBL_CTM_CHARGE "
		strSql = strSql & " WHERE ChargePayday BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "')"
		strSql = strSql & " GROUP BY BIZ_NO ORDER BY BIZ_NO"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>������<td>�������z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("BIZ_NO") & "<td>" & .fields("BIZ_TOTAL")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("BIZ_TOTAL")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�x���`�[�������ꗗ
	with Recset
		strSql = "SELECT BIZ_NO, (BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0 AND BIZ_FIN_NO = ''"
		strSql = strSql & " AND BIZ_TYPE IN (" & bizCosts & "," & bizStandP & ")"
'		strSql = strSql & " AND BIZ_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_NO IN (SELECT CostsNo FROM TBL_CTM_COSTS"
		strSql = strSql & " WHERE CostsPayDay BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "')"
		strSql = strSql & " ORDER BY BIZ_NO"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�x����<td>�x�����z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("BIZ_NO") & "<td>" & .fields("BIZ_TOTAL")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("BIZ_TOTAL")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�����`�[�������ꗗ
	with Recset
		strSql = "SELECT FIN_NO, (FIN_AMOUNT+FIN_TAX) AS FIN_TOTAL FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
		strSql = strSql & " AND (ERASE_ID = 0 OR CONFIRM_ID = 0) AND FIN_DEBIT = " & acntBank
		strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY FIN_NO"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�����ԍ�<td>�����z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("FIN_NO") & "<td>" & .fields("FIN_TOTAL")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("FIN_TOTAL")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�o���`�[�������ꗗ
	with Recset
		strSql = "SELECT FIN_NO, (FIN_AMOUNT+FIN_TAX) AS FIN_TOTAL FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
		strSql = strSql & " AND (ERASE_ID = 0 OR CONFIRM_ID = 0) AND FIN_CREDIT = " & acntBank
		strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY FIN_NO"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�������[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�o���ԍ�<td>�o���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("FIN_NO") & "<td>" & .fields("FIN_TOTAL")
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=3 class=pt9r>��������܂�..."
				end if
				total = total + .fields("FIN_TOTAL")
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td>���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	</table>
	
	<table class=pt9n cellspacing=3>
	  <tr height=24 align=center bgcolor="#E0FFE0"><td rowspan=2 width=50>��p<td width=350>��������<td width=350>�x������
	  <tr height=24 align=center><td valign=top>
<%
	'�������Ɣ�p���v�s��v�ꗗ
	with Recset
		strSql = "SELECT ChargeNo, JobCode, (ChargeAmount+ChargeTax) AS ChargeTotal, ExpenseTotal FROM TBL_CTM_CHARGE AS C"
		strSql = strSql & " INNER JOIN (SELECT ExpenseBill, SUM(ExpenseAmount+ExpenseTax) AS ExpenseTotal FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseBill <> '' GROUP BY ExpenseBill) AS E ON C.ChargeNo = E.ExpenseBill"
		strSql = strSql & " WHERE Deleted = 0 AND (ChargeAmount+ChargeTax) <> ExpenseTotal"
		strSql = strSql & " AND ChargeDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY ChargeNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>������<td>�䒠�ԍ�<td>�������z<td>���׍��v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("ChargeNo") & "<td>" & .fields("JobCode")
					response.write "<td>" & .fields("ChargeTotal") & "<td>" & .fields("ExpenseTotal")
					response.write "<td color=red>" & (.fields("ChargeTotal") - .fields("ExpenseTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("ChargeTotal") - .fields("ExpenseTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�x���`�[�Ɣ�p���v�s��v�ꗗ
	with Recset
		strSql = "SELECT CostsNo, JobCode, (CostsAmount+CostsTax) AS CostsTotal, ExpenseTotal FROM TBL_CTM_COSTS AS C"
		strSql = strSql & " INNER JOIN (SELECT ExpenseBill, SUM(ExpenseAmount+ExpenseTax) AS ExpenseTotal FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseBill <> '' GROUP BY ExpenseBill) AS E ON C.CostsNo = E.ExpenseBill"
		strSql = strSql & " WHERE Deleted = 0 AND (CostsAmount+CostsTax) <> ExpenseTotal"
		strSql = strSql & " AND CostsDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY CostsNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�x����<td>�䒠�ԍ�<td>�x�����z<td>���׍��v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("CostsNo") & "<td>" & .fields("JobCode")
					response.write "<td>" & .fields("CostsTotal") & "<td>" & .fields("ExpenseTotal")
					response.write "<td color=red>" & (.fields("CostsTotal") - .fields("ExpenseTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("CostsTotal") - .fields("ExpenseTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	  <tr height=24 align=center bgcolor="#FFE0E0"><td rowspan=2>�Ɩ�<td>�������v<td>�x�����v
	  <tr height=24 align=center><td valign=top>
<%
	'�Ɩ������Ɛ��������v�s��v�ꗗ
	with Recset
		strSql = "SELECT SalesDate, J.JobCode, (SalesSum+SalesTax+StandSum) AS JobTotal, ChargeTotal FROM TBL_CTM_JOB AS J"
		strSql = strSql & " INNER JOIN (SELECT JobCode, SUM(ExpenseAmount+ExpenseTax) AS ChargeTotal FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseType <> "& gsPayment & " GROUP BY JobCode) AS C ON J.JobCode = C.JobCode"
		strSql = strSql & " WHERE Deleted = 0 AND (SalesSum+SalesTax+StandSum) <> ChargeTotal"
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY J.JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�䒠�ԍ�<td>������<td>�������z<td>�������v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("JobCode") & "<td>" & Str2Date(.fields("SalesDate"))
					response.write "<td>" & .fields("JobTotal") & "<td>" & .fields("ChargeTotal")
					response.write "<td color=red>" & (.fields("JobTotal") - .fields("ChargeTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("JobTotal") - .fields("ChargeTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�Ɩ��x���Ǝx���`�[���v�s��v�ꗗ
	with Recset
		strSql = "SELECT SalesDate, J.JobCode, (CostsSum+CostsTax+StandSum) AS JobTotal, CostsTotal FROM TBL_CTM_JOB AS J"
		strSql = strSql & " INNER JOIN (SELECT JobCode, SUM(ExpenseAmount+ExpenseTax) AS CostsTotal FROM TBL_CTM_EXPENSE"
		strSql = strSql & " WHERE Deleted = 0 AND ExpenseType <> " & gsCharge & " GROUP BY JobCode) AS C ON J.JobCode = C.JobCode"
		strSql = strSql & " WHERE Deleted = 0 AND (CostsSum+CostsTax+StandSum) <> CostsTotal"
		strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY J.JobCode"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�䒠�ԍ�<td>������<td>�x�����z<td>�x�����v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("JobCode") & "<td>" & Str2Date(.fields("SalesDate"))
					response.write "<td>" & .fields("JobTotal") & "<td>" & .fields("CostsTotal")
					response.write "<td color=red>" & (.fields("JobTotal") - .fields("CostsTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("JobTotal") - .fields("CostsTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	  <tr height=24 align=center bgcolor="#FFFFE0"><td rowspan=2>�ޯ�<td>����ԍ�<td>�ޯ��ԍ�
	  <tr height=24 align=center><td valign=top>
<%
	'��������Ɛ��������v�s��v�ꗗ
	with Recset
		strSql = "SELECT BatchNo, BatchCount, BatchAmount, ChargeTotal FROM TBL_CTM_BATCH AS B INNER JOIN"
		strSql = strSql & " (SELECT ChargeBatch, SUM(ChargeAmount+ChargeTax) AS ChargeTotal FROM TBL_CTM_CHARGE"
		strSql = strSql & " WHERE Deleted = 0 AND ChargeBatch <> '' GROUP BY ChargeBatch) AS C ON B.BatchNo = C.ChargeBatch"
		strSql = strSql & " WHERE Deleted = 0 AND BatchAmount <> ChargeTotal"
		strSql = strSql & " AND BatchBillDay BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BatchNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>����ԍ�<td>����<td>�������z<td>�������v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("BatchNo") & "<td>" & .fields("BatchCount")
					response.write "<td>" & .fields("BatchAmount") & "<td>" & .fields("ChargeTotal")
					response.write "<td color=red>" & (.fields("BatchAmount") - .fields("ChargeTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("BatchAmount") - .fields("ChargeTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�ޯ��ԍ��Ǝx���`�[���v�s��v�ꗗ
	with Recset
		strSql = "SELECT BatchNo, BatchCount, BatchAmount, CostsTotal FROM TBL_CTM_BATCH AS B INNER JOIN"
		strSql = strSql & " (SELECT CostsBatch, SUM(CostsAmount+CostsTax) AS CostsTotal FROM TBL_CTM_COSTS"
		strSql = strSql & " WHERE Deleted = 0 AND CostsBatch <> '' GROUP BY CostsBatch) AS C ON B.BatchNo = C.CostsBatch"
		strSql = strSql & " WHERE Deleted = 0 AND ConfirmerID <> 0 AND BatchAmount <> CostsTotal"
		strSql = strSql & " AND BatchBillDay BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BatchNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�ޯ��ԍ�<td>����<td>�������z<td>�������v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("BatchNo") & "<td>" & .fields("BatchCount")
					response.write "<td>" & .fields("BatchAmount") & "<td>" & .fields("CostsTotal")
					response.write "<td color=red>" & (.fields("BatchAmount") - .fields("CostsTotal"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("BatchAmount") - .fields("CostsTotal"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	  <tr height=24 align=center bgcolor="#E0FFFF"><td rowspan=2>�d��<td>�����d��<td>�x���d��
	  <tr height=24 align=center><td valign=top>
<%
	'�������Ɛ����d��s��v�ꗗ
	with Recset
		strSql = "SELECT ChargeNo, JobCode, (ChargeAmount+ChargeTax) AS ChargeTotal, BIZ_TOTAL FROM TBL_CTM_CHARGE AS C"
		strSql = strSql & " INNER JOIN (SELECT BIZ_NO, SUM(BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ"
		strSql = strSql & " WHERE BIZ_DELETED = 0 GROUP BY BIZ_NO) AS B ON C.ChargeNo = B.BIZ_NO"
		strSql = strSql & " WHERE Deleted = 0 AND (ChargeAmount+ChargeTax) <> BIZ_TOTAL"
		strSql = strSql & " AND ChargeDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY ChargeNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>������<td>�䒠�ԍ�<td>�������z<td>�d�󍇌v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("ChargeNo") & "<td>" & .fields("JobCode")
					response.write "<td>" & .fields("ChargeTotal") & "<td>" & .fields("BIZ_TOTAL")
					response.write "<td color=red>" & (.fields("ChargeTotal") - .fields("BIZ_TOTAL"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("ChargeTotal") - .fields("BIZ_TOTAL"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�x���`�[�Ǝx���d��s��v�ꗗ
	with Recset
		strSql = "SELECT CostsNo, JobCode, (CostsAmount+CostsTax) AS CostsTotal, BIZ_TOTAL FROM TBL_CTM_COSTS AS C"
		strSql = strSql & " INNER JOIN (SELECT BIZ_NO, SUM(BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ"
		strSql = strSql & " WHERE BIZ_DELETED = 0 GROUP BY BIZ_NO) AS B ON C.CostsNo = B.BIZ_NO"
		strSql = strSql & " WHERE Deleted = 0 AND (CostsAmount+CostsTax) <> BIZ_TOTAL"
		strSql = strSql & " AND CostsDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY CostsNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�x����<td>�䒠�ԍ�<td>�x�����z<td>�d�󍇌v<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("CostsNo") & "<td>" & .fields("JobCode")
					response.write "<td>" & .fields("CostsTotal") & "<td>" & .fields("BIZ_TOTAL")
					response.write "<td color=red>" & (.fields("CostsTotal") - .fields("BIZ_TOTAL"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("CostsTotal") - .fields("BIZ_TOTAL"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	  <tr height=24 align=center bgcolor="#E0E0FF"><td rowspan=2>����<td>�����d��<td>�o���d��
	  <tr height=24 align=center><td valign=top>
<%
	'�����d��Ɛ����d��s��v�ꗗ
	with Recset
		strSql = "SELECT FIN_NO, FIN_DATE, FIN_TOTAL, ISNULL(BIZ_TOTAL, 0) AS BIZ_TOTAL FROM ( SELECT FIN_NO, FIN_DATE, "
		strSql = strSql & " SUM(CASE FIN_DEBIT WHEN " & acntAlter & " THEN (FIN_AMOUNT+FIN_TAX) ELSE (0-FIN_AMOUNT-FIN_TAX) END) AS FIN_TOTAL"
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND SUBSTRING(FIN_NO, 3, 1) = 'R'"
		strSql = strSql & " AND FIN_TYPE IN (" & acntPreSales & "," & acntStandReceive & ") GROUP BY FIN_NO, FIN_DATE)"
		strSql = strSql & " AS F INNER JOIN (SELECT BIZ_FIN_NO, SUM(BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ"
		strSql = strSql & " WHERE BIZ_DELETED = 0 GROUP BY BIZ_FIN_NO) AS B ON F.FIN_NO = B.BIZ_FIN_NO"
		strSql = strSql & " WHERE FIN_TOTAL <> ISNULL(BIZ_TOTAL, 0)"
		strSql = strSql & " ORDER BY FIN_NO"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�����ԍ�<td>������<td>�����z<td>�������z<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("FIN_NO") & "<td>" & Str2Date(.fields("FIN_DATE"))
					response.write "<td>" & .fields("FIN_TOTAL") & "<td>" & .fields("BIZ_TOTAL")
					response.write "<td color=red>" & (.fields("FIN_TOTAL") - .fields("BIZ_TOTAL"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("FIN_TOTAL") - .fields("BIZ_TOTAL"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
		<td valign=top>
<%
	'�o���d��Ǝx���d��s��v�ꗗ
	with Recset
		strSql = "SELECT FIN_NO, FIN_DATE, FIN_TOTAL, ISNULL(BIZ_TOTAL, 0) AS BIZ_TOTAL FROM ( SELECT FIN_NO, FIN_DATE,"
		strSql = strSql & " SUM(CASE FIN_CREDIT WHEN " & acntAlter & " THEN (FIN_AMOUNT+FIN_TAX) ELSE (0-FIN_AMOUNT-FIN_TAX) END) AS FIN_TOTAL"
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND SUBSTRING(FIN_NO, 3, 1) = 'P'"
		strSql = strSql & " AND FIN_TYPE IN (" & acntPreCosts & "," & acntStandPayment & ") GROUP BY FIN_NO, FIN_DATE)"
		strSql = strSql & " AS F INNER JOIN (SELECT BIZ_FIN_NO, SUM(BIZ_AMOUNT+BIZ_TAX) AS BIZ_TOTAL FROM TBL_CTM_BIZ"
		strSql = strSql & " WHERE BIZ_DELETED = 0 GROUP BY BIZ_FIN_NO) AS B ON F.FIN_NO = B.BIZ_FIN_NO"
		strSql = strSql & " WHERE FIN_TOTAL <> ISNULL(BIZ_TOTAL, 0)"
		strSql = strSql & " ORDER BY FIN_NO"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<font class=pt9b>�΍����ʁD�D�D�s��[�����ł��B</font>"
		else
			cnt = 0:	total = 0
			response.write "<table class=pt9n border=1 cellspacing=0 width=90%  bordercolorlight=#FFFFFF>"
			response.write "<tr align=center><td>��<td>�o���ԍ�<td>�o����<td>�o���z<td>�x�����z<td>���z"
			do while not .eof
				cnt = cnt + 1
				if cnt < ShowCount then
					response.write "<tr align=right><td>" & cnt & "<td>" & .fields("FIN_NO") & "<td>" & Str2Date(.fields("FIN_DATE"))
					response.write "<td>" & .fields("FIN_TOTAL") & "<td>" & .fields("BIZ_TOTAL")
					response.write "<td color=red>" & (.fields("FIN_TOTAL") - .fields("BIZ_TOTAL"))
				elseif cnt = ShowCount then
					response.write "<tr><td colspan=6 class=pt9r>��������܂�..."
				end if
				total = total + (.fields("FIN_TOTAL") - .fields("BIZ_TOTAL"))
				.movenext
			loop
			if cnt > 1 then response.write "<tr align=right><td>" & cnt & "<td colspan=4>���z���v<td>" & total
			response.write "</table>"
		end if
		.close
	end with
%>
	</table>
  </FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>