<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
	BatchNo = GetPost(request("BatchNo"))
	BatchSort = GetLong(request("Sort"))
	if BatchNo <> "" then

		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�o�b�`���׈ꗗ�Ɖ�</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT language=vbscript>		
		function DoSort(myNo)
			window.location.href = "BatchList.asp?BatchNo=<%=BatchNo%>&sort=" & myNo 
		end function
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
	  <TR align=center height=20 class=pt12>
		<TD class=line nowrap>��
<%if left(BatchNo, 1) = gsBatchPrint then %>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�����ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap align=center>������
		<TD class=line nowrap>�������z
<%elseif left(BatchNo, 1) = gsBatchBill then %>
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�x���ԍ�
		<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
		<TD class=line nowrap align=center>������
		<TD class=line nowrap>�x�����z
<%end if%>
<%
	with recset
		if left(BatchNo, 1) = gsBatchPrint then
			strSql = "SELECT JobCode, ChargeNo, ChargeType, ChargeAmount, ChargeTax, ChargeDate, ChargePayDay"
			strSql = strSql & " FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ChargeBatch = '" & BatchNo & "'"
			select case BatchSort
			case 0:		strSql = strSql & " ORDER BY ChargeNo"
			case 1:		strSql = strSql & " ORDER BY JobCode, ChargeNo"
			end select
		elseif left(BatchNo, 1) = gsBatchBill then
			strSql = "SELECT JobCode, CostsNo, CostsType, CostsAmount, CostsTax, CostsDate, CostsPayDay"
			strSql = strSql & " FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsBatch = '" & BatchNo & "'"
			select case BatchSort
			case 0:		strSql = strSql & " ORDER BY CostsNo"
			case 1:		strSql = strSql & " ORDER BY JobCode, CostsNo"
			end select
		end if
if WebUserID = gsAdmin then response.write strSQL
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .EOF then	
			cnt = 0
			ttlAmount = 0:	ttlTax = 0:	ttlTaxFree = 0
			do while not .eof
				cnt = cnt + 1
				if left(BatchNo, 1) = gsBatchPrint then
					myAmount = GetLong(.Fields("ChargeAmount")) + GetLong(.Fields("ChargeTax"))
%>
				<TR align=center height=20>
					<TD class=line><%=cnt%>
					<TD nowrap class=line align=left><%=ShowVoucherNo(GetString(.Fields("ChargeNo")))%><BR>
					<TD nowrap class=line align=left><%=ShowJobCode(GetString(.Fields("JobCode")))%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("ChargeDate"))%><BR>
					<TD nowrap class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
<%
				elseif left(BatchNo, 1) = gsBatchBill then
					myAmount = GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax"))
%>
				<TR align=center height=20>
					<TD class=line><%=cnt%>
					<TD nowrap class=line align=left><%=ShowVoucherNo(GetString(.Fields("CostsNo")))%><BR>
					<TD nowrap class=line align=left><%=ShowJobCode(GetString(.Fields("JobCode")))%><BR>
					<TD nowrap class=line style="color:green"><%=Str2MD(.Fields("CostsDate"))%><BR>
					<TD nowrap class=line nowrap align=right><%=formatnumber(myAmount, 0, true)%><BR>
<%
				end if
				ttlAmount = ttlAmount + myAmount
				.movenext
			loop
			if cnt > 1 then
%>
				<TR align=right height=20>
					<TD colspan=3 class=pt12>�������v
					<TD colspan=2 class=line><%=formatnumber(ttlAmount, 0, true)%>
<%
			end if
%>
	</TABLE>
<%		else
			response.write "</TABLE><font class=pt12r>�Y���f�[�^�͌�����܂���ł����B</font>"
		end if
	end with
%>  
</BODY>
</HTML>
<%
		set recset = nothing
		CloseDB Conn
		
	end if
%>	