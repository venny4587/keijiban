
gsDateSign = "/"

sub ResetEnter()
	if window.event.keyCode = 13 then window.event.keyCode = 9
end sub

function SetEndFocus(obj)
	set range = obj.createTextRange()
	call range.moveStart("character", 999)
	'call range.moveEnd("character", 0)
	range.select()
end function

function SetSelFocus(obj)
	set range = obj.createTextRange()
	call range.moveStart("character", 0)
	call range.moveEnd("character", 999)
	range.select()
end function

function DoCopy(id)
	set doc = document.body.createTextRange()
	call doc.moveToElementText(document.all(id))
	call doc.execCommand("copy")
end function

function checkCode(myName, myTitle, myMode)				
on error resume next
dim idx
	checkCode = true	
	for each obj in frmInput.elements
		if obj.type = "text" and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox myTitle & "����͂��Ă��������B",48,"�m�F���b�Z�[�W" 	
					checkCode = false
				end if 
			else
				for idx = 1 to len(obj.value)
					ascii = asc(mid(obj.value,idx,1))
					if (ascii >= 48 and ascii <= 57) or _
					   (ascii >= 65 and ascii <= 90) or _
					   (ascii >= 97 and ascii <= 122) then
					else
						checkCode = false
						exit for
					end if
				next
				if checkCode = false then
					obj.focus
					msgbox myTitle & "�ɉp�����ȊO�̕����͓��͋֎~�ł��B",48,"�m�F���b�Z�[�W" 
				end if
			end if
			exit for	
		end if
	next 	
end function

function checkText(myName, myTitle, myMode)				
on error resume next
	checkText = true	
	for each obj in frmInput.elements
		if (obj.type = "text" or obj.type = "textarea") and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox myTitle & "����͂��Ă��������B",48,"�m�F���b�Z�[�W" 	
					checkText = false
				end if 
			else
				if obj.type = "textarea" then
					chk1=0
				else
					chk1 = instr(obj.value, chr(34))
				end if
				chk2 = instr(obj.value, "<")
				chk3 = instr(obj.value, ">")
				chk4 = instr(obj.value, "@@")
				if chk1 + chk2 + chk3 + chk4 > 0 then
					obj.focus
					msgbox myTitle & "�ɉ��L�̕����͓��͋֎~�ł��B" & vbcrlf & " " & chr(34) & " < > @@",48,"�m�F���b�Z�[�W" 
					checkText = false
				end if
			end if
			exit for	
		end if
	next 	
end function

'0:		��������
'1:�@	�[���\�@	�}�C�i�X�s��
'2:		�[���s��	�}�C�i�X�\
'3:		�[���\	�}�C�i�X�\
function checkNum(myName, myTitle, myMode)				
on error resume next
	checkNum = true	
	for each obj in frmInput.elements
		if obj.type = "text" and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox myTitle & "����͂��Ă��������B",48,"�m�F���b�Z�[�W" 	
					checkNum = false
				end if
			else
				if not isnumeric(obj.value) then
					obj.focus
					msgbox myTitle & "�ɐ����ȊO�͓��͋֎~�ł��B",48,"�m�F���b�Z�[�W" 	
					checkNum = false
				elseif myMode = 1 then
					if GetLong(obj.value) < 0 then
						obj.focus
						msgbox myTitle & "�Ƀ}�C�i�X�͓��͋֎~�ł��B",48,"�m�F���b�Z�[�W" 	
						checkNum = false
					end if
				end if					
			end if
			if checkNum = true then
				obj.value = GetLong(obj.value)
				if obj.value = 0 and myMode = 2 then
					obj.focus
					msgbox myTitle & "�ɐ��l����͂��Ă��������B",48,"�m�F���b�Z�[�W" 	
					checkNum = false
				end if
			end if
			exit for
		end if
	next 	
end function

'0:		��������
'1:�@	�[���\�@	�}�C�i�X�s��
'2:		�[���s��	�}�C�i�X�\
'3:		�[���\	�}�C�i�X�\
function checkDouble(myName, myTitle, myMode)				
on error resume next
	checkDouble = true	
	for each obj in frmInput.elements
		if obj.type = "text" and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox myTitle & "����͂��Ă��������B",48,"�m�F���b�Z�[�W" 
					checkDouble = false
				end if
			else
				if not isnumeric(obj.value) then
					msgbox obj.value & isnumeric(obj.value)
					obj.focus
					msgbox myTitle & "�ɐ����ȊO�͓��͋֎~�ł��B",48,"�m�F���b�Z�[�W" 	
					checkDouble = false
				elseif myMode = 1 then
					if GetDouble(obj.value) < 0 then
						obj.focus
						msgbox myTitle & "�Ƀ}�C�i�X�͓��͋֎~�ł��B",48,"�m�F���b�Z�[�W" 	
						checkDouble = false
					end if
				end if
			end if
			if checkDouble = true then
				obj.value = GetDouble(obj.value)
				if obj.value = 0 and myMode = 2 then
					obj.focus
					msgbox myTitle & "�ɐ��l����͂��Ă��������B",48,"�m�F���b�Z�[�W" 	
					checkDouble = false
				end if
			end if
			exit for
		end if
	next 	
end function

function checkLen(myName, myTitle, myLen)				
on error resume next
	checkLen = true	
	for each obj in frmInput.elements
		if (obj.type = "text" or obj.type = "textarea") and obj.name = myName then
			if len(trim(obj.value)) > myLen then
				msgbox myTitle & "��" & myLen & "�����ȓ����͂��Ă��������B",48,"�m�F���b�Z�[�W" 	
				checkLen = false
			end if
			exit for
		end if
	next 	
end function

function checkDate(myName, myTitle, myMode)				
on error resume next
	checkDate = true	
	for each obj in frmInput.elements
		if obj.type = "text" and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox myTitle & "����͂��Ă��������B",48,"�m�F���b�Z�[�W" 	
					checkDate = false
				end if 
			else
				obj.value = setDate(obj.value)
				if not isdate(obj.value) then
					obj.focus
					msgbox myTitle & "�𐳂������͂��Ă��������B",48,"�m�F���b�Z�[�W" 
					checkDate = false
				end if
			end if
			exit for
		end if
	next 	
end function

function GetLong(myData)
on error resume next
	GetLong = 0
	if isnumeric(myData) then
		GetLong = clng(myData)
	end if
end function

function GetDouble(myData)
	GetDouble = 0
	if isnumeric(myData) then
		GetDouble = cdbl(myData)
	end if
end function

function ResetInput()
on error resume next
	ResetInput = true
	for each obj in frmInput.elements
		if obj.type = "text" then
			obj.value = trim(obj.value)
		end if
	next 	
end function


function formatDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDate = ""
		exit function
	end if		
	formatDate = year(myDate) & gsDateSign & right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function

function setDate(myData)
dim tmp, pos
	setDate = ""
	tmp = trim(myData & "")
	pos = instr(tmp, gsDateSign)
	if pos = 0 then
		if len(tmp) = 4 then tmp = year(date) & tmp
		if len(tmp) = 6 then tmp = "20" & tmp
		if len(tmp) = 8 then
			tmp = left(tmp,4) & gsDateSign & mid(tmp,5,2) &  gsDateSign &  mid(tmp,7,2)
			if isdate(tmp) then
				setDate = tmp
			end if
		elseif len(tmp) = 10 then
			tmp = left(tmp,4) & gsDateSign & mid(tmp,6,2) &  gsDateSign &  mid(tmp,9,2)
			if isdate(tmp) then
				setDate = tmp
			end if
		end if
	else
		if len(tmp) <= 5 then tmp = year(date) & gsDateSign & tmp
		if isdate(tmp) then
			setDate = tmp
		end if
	end if
	if setDate <> "" then
		setDate = year(tmp) & gsDateSign & right("00" & month(tmp),2) & gsDateSign & right("00" & day(tmp),2)
	end if
end function

function setDateTime(myData)
dim tmp
dim pos
dim myDate
dim myTime
	setDateTime = ""
	tmp = trim(myData & "")
	if len(tmp) = 8 then tmp = tmp & "0000"
	if len(tmp) < 12 then exit function
	pos = instrrev(tmp," ")
 	if pos = 0 then
		myDate = setDate(left(tmp,8))
		myTime = setTime(mid(tmp,9))
	else
		myDate = setDate(left(tmp,pos-1))
		myTime = setTime(mid(tmp,pos+1))
	end if
	if myDate <> "" AND myTime <> "" then
		setDateTime = myDate & " " & myTime
	end if
end function

function setTime(myData)
dim tmp
dim pos
dim hh
dim mm
	setTime = ""
	tmp = trim(myData & "")
	if len(tmp) < 4 then exit function
	hh = left(tmp,2)
	mm = right(tmp,2)	
	if isnumeric(hh) AND isnumeric(mm) then
		hh = cint(hh)
		mm = cint(mm)
		if hh >= 24 or mm >= 60 then exit function
		setTime = right("00" & hh,2) & ":" & right("00" & mm,2)
	end if
end function


Function GetLeft(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeft = buf
End Function

Function GetLeftRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeftRev = buf
End Function

Function GetRight(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRight = buf
End Function

Function GetRightRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRightRev = buf
End Function


function DoClickCheck(nm)
dim obj
	for each obj in frmInput.elements
		if obj.type="checkbox" and obj.name=nm then
			if obj.checked then
				obj.checked = false
			else
				obj.checked = true
			end if
      		exit for
		end if
	next
end function

function DoClickRadio(nm,va)
dim obj
	for each obj in frmInput.elements
		if obj.type="radio" and obj.name=nm and obj.value=va then
      		obj.checked = true
      		exit for
		end if
	next
end function

function GetElementVal(nm)
dim obj
	GetElementVal = ""	
	for each obj in frmInput.elements
		if obj.name=nm then
			select case obj.type
			case "text", "textarea", "hidden"
				GetElementVal = obj.value
			case "radio", "checkbox"
				if obj.checked then GetElementVal = obj.value
			case "select"
				 GetElementVal = obj.options(obj.selectedIndex).value
			end select
			if obj.type <> "radio" then exit for
		end if
	next
end function

function ClearAll()
dim obj
	for each obj in frmInput.elements
		select case obj.type
		case "text", "textarea", "hidden"
			obj.value = ""
		case "checkbox"
			obj.checked = false
		case "radio"
			if obj.value = 0 then obj.checked = true
		case "select"
			 obj.selectedIndex = 0
		end select
	next
end function

function CheckAll(nm, val)
dim obj
	for each obj in frmInput.elements
		if obj.type = "checkbox" then 
			if ucase(left(obj.name, len(nm))) = ucase(nm) then
				obj.checked = val
			end if
		end if
	next
end function

Function ResetDigital(myData, myDigital, myMode)
Dim pos, buf
    buf = CDbl(myData)
    If buf <> 0 Then
        For pos = 1 To myDigital
            buf = buf * 10
        Next
        Select Case myMode
        Case -1             '�؂�̂�
            buf = Fix(buf)
        Case 0              '�l�̌ܓ�
            buf = CLng(FormatNumber(buf, 0, True))
        Case 1              '�؂�グ
            If buf <> Fix(buf) Then
                buf = Fix(buf) + 1
            End If
        End Select
        For pos = 1 To myDigital
            buf = buf / 10
        Next
    End If
    ResetDigital = buf
End Function

'�ďo��		ChargeDetail.asp	�������׉��
'			CostsDetail.asp		�x�����׉��
function GetTaxRate(myStr)
dim pos, idx, cnt
	GetTaxRate = 0
	cnt = 0
	for idx = 1 to len(myStr)
		if asc(mid(mystr,idx,1)) >= 48 and asc(mid(mystr,idx,1)) <=57 then
			if cnt = 0 then pos = idx
			cnt = cnt + 1
		elseif cnt > 0 then					
			exit for
		end if
	next 
	if cnt > 0 then
		GetTaxRate = clng(mid(myStr,pos,cnt)) / 100
	end if
end function
		
'�ďo��		CustomsEdit.asp		�ʊ֋Ɩ����׉��
function GetRTON(myGW, myCBM)
dim rt
	rt = GetLong(GetDouble(myCBM) * 1000) '* 0.8837
	if rt < GetLong(myGW) then rt = GetLong(myGW)
	GetRTON = formatnumber(rt / 1000, 3, true)
end function

'�ďo��		CustomsEdit.asp		�ʊ֋Ɩ����׉��
function GetKGS(myGW, myCBM)
dim kg
	kg = GetDouble(myCBM) * 8 / 0.027
	if kg < GetDouble(myGW) then kg = GetDouble(myGW)
	GetKGS = formatnumber(kg, 3, true)
end function


Function Date2Code(myDate)
Dim y, m, d
    y = Num2Code(Year(myDate) - 2000)
    m = Num2Code(Month(myDate))
    d = Num2Code(Day(myDate))
    Date2Code = y & m & d
End Function

Function Num2Code(myNum)
    If myNum < 10 Then
        Num2Code = myNum
    Else
        Num2Code = Chr(myNum + 55)
    End If
End Function

function FitZero(myStr)
dim buf, pos
	buf = cstr(myStr & "")
	pos = instr(buf, ".")
	if pos > 0 then
		do while right(buf, 1) = "0"
			buf = left(buf, len(buf)-1)
		loop 
		if right(buf, 1) = "." then buf = left(buf, len(buf)-1)
	end if
	FitZero = buf
end function	

function FitJobCode(myNo)
dim buf, pos
	buf = ucase(trim(myNo & ""))
	if len(buf) < 10 then
		pos = instr(buf, "-")
		if pos = 0 then
			if GetLong(mid(buf, 5)) <> 0 then
				buf = left(buf, 4) & "-" & right("00000" & clng(mid(buf, 5)), 5)
			end if
		else
			if GetLong(mid(buf, pos + 1)) <> 0 then
				buf = left(buf, pos) & right("00000" & clng(mid(buf, pos + 1)), 5)
			end if
		end if
	end if
	FitJobCode = buf
end function

function FitPrintNo(myNo)
dim buf
	buf = trim(myNo & "")
	if buf <> "" then
		if isnumeric(buf) then
			buf = "P" & right("00000" & GetLong(buf), 5)
		elseif ucase(left(buf, 1)) = "P" then
			buf = "P" & right("00000" & GetLong(mid(buf, 2)), 5)
		else
			buf = ""
		end if
	end if
	FitPrintNo = buf
end function

function FitBatchNo(myNo)
dim buf
	buf = trim(myNo & "")
	if buf <> "" then
		if isnumeric(buf) then
			buf = "B" & right("00000" & GetLong(buf), 5)
		elseif ucase(left(buf, 1)) = "B" then
			buf = "B" & right("00000" & GetLong(mid(buf, 2)), 5)
		else
			buf = ""
		end if
	end if
	FitBatchNo = buf
end function

function FitCostsNo(myNo)
dim buf
	buf = trim(myNo & "")
	if buf <> "" then
		if isnumeric(buf) then
			buf = "CHE" & right("0000000" & GetLong(buf), 7)
		elseif ucase(left(buf, 1)) = "E" then
			buf = "CHE" & right("0000000" & GetLong(mid(buf, 2)), 7)
		elseif ucase(left(buf, 3)) = "CHE" then
			buf = "CHE" & right("0000000" & GetLong(mid(buf, 4)), 7)
		else
			buf = ""
		end if
	end if
	FitCostsNo = buf
end function

function FitChargeNo(myNo)
dim buf
	buf = trim(myNo & "")
	if buf <> "" then
		if ucase(left(buf, 3)) = "CHC" then
			buf = "CHC" & right("0000000" & GetLong(mid(buf, 4)), 7)
		elseif ucase(left(buf, 3)) = "CHS" then
			buf = "CHS" & right("0000000" & GetLong(mid(buf, 4)), 7)
		elseif ucase(left(buf, 1)) = "C" then
			buf = "CHC" & right("0000000" & GetLong(mid(buf, 2)), 7)
		elseif ucase(left(buf, 1)) = "S" then
			buf = "CHS" & right("0000000" & GetLong(mid(buf, 2)), 7)
		else
			buf = ucase(buf)
		end if
	end if
	FitChargeNo = buf
end function

function FitReceiveNo(myNo)
dim buf 
	buf = trim(myNo & "")
	if buf <> "" then
		if isnumeric(buf) then
			buf = "CHR" & right("0000000" & GetLong(buf), 7)
		elseif ucase(left(buf, 1)) = "R" then
			buf = "CHR" & right("0000000" & GetLong(mid(buf, 2)), 7)
		elseif ucase(left(buf, 3)) = "CHR" then
			buf = "CHR" & right("0000000" & GetLong(mid(buf, 4)), 7)
		else
			buf = ""
		end if
	end if
	FitReceiveNo = buf
end function

function FitPaymentNo(myNo)
dim buf 
	buf = trim(myNo & "")
	if buf <> "" then
		if isnumeric(buf) then
			buf = "CHP" & right("0000000" & GetLong(buf), 7)
		elseif ucase(left(buf, 1)) = "P" then
			buf = "CHP" & right("0000000" & GetLong(mid(buf, 2)), 7)
		elseif ucase(left(buf, 3)) = "CHP" then
			buf = "CHP" & right("0000000" & GetLong(mid(buf, 4)), 7)
		else
			buf = ""
		end if
	end if
	FitPaymentNo = buf
end function

function FitZero(myStr)
dim buf, pos
	buf = cstr(myStr & "")
	if isnumeric(myStr) then 
		pos = instr(buf, ".")
		if pos > 0 then
			do while right(buf, 1) = "0"
				buf = left(buf, len(buf)-1)
			loop 
			if right(buf, 1) = "." then buf = left(buf, len(buf)-1)
		end if
	end if
	FitZero = buf
end function

function LockAll()
dim obj
	for each obj in frmInput.elements
		select case lcase(obj.type)
		case "text", "textarea"
			if obj.name <> "Revise" then obj.readonly = true
		case "checkbox", "radio", "select" 
			obj.disabled = true
		case "button"
			if obj.name <> "btnClose" and obj.name <> "btnUnLock" then obj.disabled = true
		end select
	next
end function

function Close2Date(myClose, myDate)
dim dte, num, buf, dt
	if isdate(myDate) then 
		dte = cdate(myDate)
	else
		dte = date
	end if
	num = GetLong(myClose)
	if num = 0 then
		buf = dte
	elseif num < 31 then
		if day(dte) <= num then
			buf = dte
		else
			buf = dateadd("m", 1, dte)
		end if
		buf = cdate(year(buf) & gsDateSign & month(buf) & gsDateSign & num)	
	elseif num = 70 then
		if weekday(dte) <= 6 then
			buf = dateadd("d", 6 - weekday(dte), dte)
		else
			buf = dateadd("d", 6, dte)
		end if
	elseif num = 99 then
		buf = GetMonthLastDay(dte)
	elseif num = 100 then
		dt = (day(dte) \ 10) * 10
		if (day(dte) <> 31) and (day(dte) mod 10 > 0) then dt = dt + 10
		if dt = 30 then
			buf = GetMonthLastDay(dte)
		else
			buf = cdate(year(dte) & gsDateSign & month(dte) & gsDateSign & dt)
		end if
	elseif num = 150 then
		dt = (day(dte) \ 15) * 15
		if (day(dte) <> 31) and (day(dte) mod 15 > 0) then dt = dt + 15
		if dt = 30 then
			buf = GetMonthLastDay(dte)
		else
			buf = cdate(year(dte) & gsDateSign & month(dte) & gsDateSign & dt)
		end if
	else
		buf = dte
	end if
	Close2Date = formatDate(buf)
end function

function Sight2Date(mySight, myDate)
dim st, dte, num, buf, dt
	if isdate(myDate) then
		dte = cdate(myDate)
	else
		dte = date
	end if
	st = GetLong(mySight) \ 1000
	num = GetLong(mySight) mod 1000
	if num = 0 then
		buf = dte
	elseif num < 31 then
		buf = dateadd("m", st, dte)
		if st = 0 and day(dte) >= num then buf = dateadd("m", 1, dte)
		buf = cdate(year(buf) & gsDateSign & month(buf) & gsDateSign & num)
	elseif num = 70 then
		if weekday(dte) <= 6 then
			buf = dateadd("d", st * 7 + 6 - weekday(dte), dte)
		else
			buf = dateadd("d", st * 7 + 6, dte)
		end if
	elseif num = 99 then
		buf = GetMonthLastDay(dateadd("m", st, dte))
	elseif num = 100 then
		buf = dateadd("d", st * 10, dte)
		dt = day(buf) - (day(buf) \ 10) * 10
		if dt < 5 then
			buf = dateadd("d", 0 - dt, buf)
		else
			buf = dateadd("d", 10 - dt, buf)
		end if
	elseif num = 150 then
		buf = dateadd("d", st * 15, dte)
		dt = day(buf) - (day(buf) \ 15) * 15
		if dt < 5 then
			buf = dateadd("d", 0 - dt, buf)
		else
			buf = dateadd("d", 15 - dt, buf)
		end if
	else
		buf = dte
	end if
	Sight2Date = formatDate(buf)
end function

function GetMonthLastDay(dt)
dim tpDate
	GetMonthLastDay = ""
	if isdate(dt) then
		tpDate = cdate(dt)
		tpDate = cdate(year(dt) & gsDateSign & month(dt) & gsDateSign & "1")
		GetMonthLastDay = dateAdd("d", -1, dateAdd("m",1,tpDate))
	end if
end function