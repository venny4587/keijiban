<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
		
dim myCode
dim myText
dim myMode
dim myField

	myCode = GetString(request("cd"))
	selCode = replace(myCode, "'", "''")
	myText = GetString(request("txt"))
	myMode = GetLong(request("mode"))
	
	select case myMode
	case 1:		myField = "CTM_CLIENT"
	case 2:		myField = "CTM_SHIPPER"
	case 3:		myField = "CTM_CONSIGNEE"
	case 4:		myField = "CTM_NOTIFY"
	case 5:		myField = "CTM_BROKER"
	case 6:		myField = "CTM_CUSTOM"
	case 7:		myField = "CTM_CARRIER"
	case 8:		myField = "CTM_AIRLINER"
	case 9:		myField = "CTM_TRUCKER"
	case 10:	myField = "CTM_WAREHOUSE"
	case 11:	myField = "CTM_AGENT"
	case 12:	myField = "CTM_OTHER"
	case else:	myField = "CTM_CLIENT"
	end select
	myField = 0

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	CTM_CD = ""
	if myCode <> "" then
		with Recset	
			StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME FROM CUSTOMER WHERE CTM_DELETED = 0"
			if myField <> 0 then StrSql = StrSql & " AND " & myField & " = 1"
			StrSql = StrSql & " AND (CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "' OR CTM_ABR = '" & selCode & "')"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				CTM_CD = GetString(.fields("CTM_CD"))
				CTM_REF = GetString(.fields("CTM_REF"))
			end if
			.close
		end with
	end if

	if CTM_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
	if (window.opener.frmInput.<%=myText%> != null) window.opener.frmInput.<%=myText%>.value = "<%=CTM_REF%>";
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE><%=ctmDivision(myMode)%>����</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "CustomerSearch.asp?mode=<%=myMode%>&txt=<%=myText%>&cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("<%=ctmDivision(myMode)%>�R�[�h�܂���<%=ctmDivision(myMode)%>���̈ꕔ����͂��Ă��������B")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM NAME=frmInput ACTION="CustomerSearch.asp" METHOD="POST">
		<input type=hidden name="txt" value="<%=myText%>">
		<input type=hidden name="mode" value="<%=myMode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD nowrap><%=ctmDivision(myMode)%>���� :</TD>
				<TD nowrap><input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=20 onkeydown="ResetEnter()"></TD>
				<TD width=80 align=right><INPUT TYPE=button style="cursor:hand; width:60; height:25" VALUE="����" onclick="DoSearch()"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
	if myCode <> "" then 
		With Recset
			StrSql = "SELECT COUNT(CTM_CD) AS CTM_CNT FROM CUSTOMER WHERE CTM_DELETED = 0 AND ("
			StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "' OR CTM_ABR = '" & selCode & "'"
			StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
			if myField <> 0 then StrSql = StrSql & " AND " & myField & " = 1"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if GetLong(.fields("CTM_CNT")) = 0 then
				response.write "<br>�Y���f�[�^��������܂���ł����B"
			elseif GetLong(.fields("CTM_CNT")) > 30 then
				response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
			else
				.close
				
				StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_ABR, CTM_NAME FROM CUSTOMER WHERE CTM_DELETED = 0 AND ("
				StrSql = StrSql & " CTM_CD = '" & selCode & "' OR CTM_REF = '" & selCode & "' OR CTM_ABR = '" & selCode & "'"
				StrSql = StrSql & " OR CTM_NAME LIKE '%" & selCode & "%' OR CTM_ENAME LIKE '%" & selCode & "%')"
				if myField <> 0 then StrSql = StrSql & " AND " & myField & " = 1"
				strSQL = strSQL + " ORDER BY CTM_ENAME"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>�R�[�h
					<TD nowrap>��������
					<TD nowrap>�p������
					<TD nowrap>�a������
					<TD nowrap>�a������
<%
					myCnt = 0
					myShortCut = ""
					Do Until .EOF	
						myCnt = myCnt + 1		
						myEName = GetString(.Fields("CTM_ENAME"))	
						myJName = GetString(.Fields("CTM_NAME"))	
						myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("CTM_CD") & "');"
						if myCnt < 10 then myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("CTM_CD") & "');"
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("CTM_CD")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_CD"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_REF"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myEName, 40)%>><%=StringCut(myEName,40)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_ABR"))%><BR>
					<TD class=line nowrap <%=ShowTitle(myJName, 20)%>><%=StringCut(myJName,20)%><BR>
<%							
						.MoveNext
					Loop
				end if				
%>
			</table>
<%
			end if	
			.Close 
		End With
	end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
end if
	set Recset = nothing
	CloseDB Conn
	
function fitStr(myStr)
	fitStr = replace(myStr, "'", "~")
end function
%>