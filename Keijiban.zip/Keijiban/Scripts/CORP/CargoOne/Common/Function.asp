<%
dim Conn
dim strSql
dim Recset
dim i
dim j

'=============================
'	���ʕ�
'=============================

Sub ShowMessage(myMsg)
	Response.Write ("<HTML><SCRIPT LANGUAGE=JavaScript>alert(" & chr(34) & myMsg & chr(34) & ");window.history.back();</SCRIPT></HTML>")
	Response.End 
End Sub

Function GetPost(myData)
on error resume next
dim buf
	GetPost = "ERROR"
	buf = lcase(GetString(myData))
	if instr(buf, " ") = 0 then
	   	GetPost = GetString(myData)
	elseif instr(buf, "exec") = 0 and _
	   instr(buf, "update") = 0 and _
	   instr(buf, "insert") = 0 and _
	   instr(buf, "delete") = 0 and _
	   instr(buf, "<script>") = 0 then
	   	GetPost = GetString(myData)
	end if
End Function

Function FitSel(myData)
on error resume next
dim buf
	buf = GetString(myData)
	FitSel = replace(buf, "'", "''")
End Function

function GetClientIP()
	GetClientIP = request.servervariables("HTTP_X_FORWARDED_FOR")
	if GetClientIP = "" then
		GetClientIP = request.servervariables("REMOTE_ADDR")
	end if
end function

Function GetLong(myData)
on error resume next
	GetLong = 0
	if isnumeric(myData) then GetLong = clng(myData)
End Function

Function GetDouble(myData)
on error resume next
	GetDouble = 0
'	if isnumeric(myData) then GetDouble = cdbl(myData)
	GetDouble = cdbl(myData)
End Function

Function GetString(myData)
on error resume next
	GetString = trim(cstr(myData & ""))
End Function

Function GetDate(myData)
on error resume next
	GetDate = ""
	if isdate(myData) then	GetDate = cdate(myData)
End Function

Function ResetString(myStr)
on error resume next
	ResetString = replace(myStr, "'", "''")
End Function

Function ResetBoolean(myBln)
on error resume next
	if myBln = true then
		ResetBoolean = 1
	else
		ResetBoolean = 0
	end if
End Function


Function GetLeft(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeft = buf
End Function

Function GetLeftRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeftRev = buf
End Function

Function GetRight(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRight = buf
End Function

Function GetRightRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRightRev = buf
End Function

function Str2Date(myData)
	if GetString(myData) <> "" then Str2Date = mid(myData,1,4) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2YMD(myData)
	if GetString(myData) <> "" then Str2YMD = mid(myData,3,2) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2MD(myData)
	if GetString(myData) <> "" then Str2MD = mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Date2Str(myData)
dim dt
	Date2Str = ""
	if not isDate(myData) then exit function
	dt = cdate(myData)
	Date2Str = year(dt) & right("00" & month(dt),2) & right("00" & day(dt),2) 
end function 



Function Time2Code(myTime)
Dim h, n, s
    h = Num2Code(Hour(myTime))
    n = Right("00" & Minute(myTime), 2)
    s = Right("00" & Second(myTime), 2)
    Time2Code = Date2Code(myTime) & h & n & s
End Function

Function Date2Code(myDate)
Dim y, m, d
    y = Num2Code(Year(myDate) - 2000)
    m = Num2Code(Month(myDate))
    d = Num2Code(Day(myDate))
    Date2Code = y & m & d
End Function

Function Num2Code(myNum)
    If myNum < 10 Then
        Num2Code = myNum
    Else
        Num2Code = Chr(myNum + 55)
    End If
End Function

function stringCut(myStr,myLen)
on error resume next
	stringCut = trim(myStr & "")
	if len(stringCut) > myLen then
		stringCut = left(stringCut,myLen - 3) & "..."
	end if	
end function

function StringCutRev(myStr,myLen)
on error resume next
	StringCutRev = trim(myStr & "")
	if len(StringCutRev) > myLen then
		StringCutRev = "..." & right(StringCutRev,myLen - 3)
	end if	
end function

function ShowTitle(myStr,myLen)
on error resume next	
	ShowTitle = trim(myStr & "")
	if len(ShowTitle) > myLen then
		ShowTitle = " title='" & stringReset(ShowTitle) & "'"
	else
		ShowTitle = ""
	end if
end function

function stringReset(myStr)
on error resume next	
	stringReset = replace(myStr, "'", "�f")
end function


function formatDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDate = ""
		exit function
	end if		
	formatDate = year(myDate) & gsDateSign & right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function

function formatShortDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatShortDate = ""
		exit function
	end if
	formatShortDate = right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function


function FmtDateTime(myDate)
on error resume next
	FmtDateTime = ""
	if isdate(myDate) then
		FmtDateTime = year(myDate) & gsDateSign & _
					  right("00" & month(myDate),2) & gsDateSign & _
					  right("00" & day(myDate),2) & " " & _
					  right("00" & hour(myDate),2) & ":" & _
					  right("00" & minute(myDate),2)
	end if
end function

function FmtTime(myDate)
on error resume next
	FmtTime = ""
	if isdate(myDate) then
		FmtTime = year(myDate) & gsDateSign & _
					  month(myDate) & gsDateSign & _
					  day(myDate) & " " & _
					  hour(myDate) & ":" & _
					  minute(myDate)
	end if
end function

function ShowDateTimeShort(myDate)
on error resume next
	ShowDateTimeShort = ""
	if isdate(myDate) then
		ShowDateTimeShort = right("00" & month(myDate),2) & gsDateSign & _
					  		right("00" & day(myDate),2) & " " & _
					  		right("00" & hour(myDate),2) & ":" & _
					  		right("00" & minute(myDate),2)
	end if
end function

function GetMonthLastDay(dt)
on error resume next
dim tpDate
	GetMonthLastDay = ""

	if not isdate(dt) then exit function
	
	if len(dt) = 10 then
		y = left(dt,4)
		m = mid(dt,6,2)
		tpDate = dateAdd("m",1,y & gsDateSign & m & gsDateSign & "01")			
		GetMonthLastDay = dateAdd("d",-1,tpDate)
	end if

end function

Function GetCurrentPage(myConn, table, field, myType, data, sWhere)
dim myRec
dim mySql
	GetCurrentPage = 0
	if myType = 1 then data = "'" & replace(data,"'","''") & "'"	
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT Count(" & field & ") FROM " & table & _
				" WHERE " & field & " < " & data & sWhere
		.Open mySql, myConn, adOpenKeyset , adLockOptimistic
		GetCurrentPage = (CLng (.Fields(0)) \ lngPageSize) + 1
		.Close
	end with
	set myRec = Nothing
end Function

Function CheckDBRepeat(myConn, table, field, data, myType, keyfield, key)
dim myRec
dim mySql
	if myType = 1 then data = "'" & replace(data,"'","''") & "'"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT " & field & " FROM " & table & _
				" WHERE QDEL = 0" & _
				" AND " & field & " = " & data
		if key <> 0 then mySql = mySql & " AND " & keyfield & " <> " & key
		.Open mySql, myConn, adOpenKeyset , adLockOptimistic
		if .eof then
			CheckDBRepeat = false
		else
			CheckDBRepeat = true
		end if
		.Close
	end with
	set myRec = Nothing
end Function

function formatDateJP(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDateJP = ""
		exit function
	end if		
	formatDateJP = year(myDate) & "�N" & month(myDate) & "��" & day(myDate) & "��"
end function


function formatDateEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateEng = ""
		exit function
	end if
	formatDateEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate)) & ", " & year(myDate)
end function

function formatEngDate(myDate)
on error resume next
	if not isdate(myDate) then
		formatEngDate = ""
		exit function
	end if
	formatEngDate = GetMonth(month(myDate)) & "." & GetDay(day(myDate)) & "." & year(myDate)
end function

function formatDateShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateShortEng = ""
		exit function
	end if
	formatDateShortEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate))
end function

function ShowDateTimeShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		ShowDateTimeShortEng = ""
		exit function
	end if
	ShowDateTimeShortEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate)) & ", " & _
					       right("00" & hour(myDate),2) & ":" & right("00" & minute(myDate),2)
end function

function GetDay(myNo)
	select case myNo
	case 1, 21, 31:	GetDay = right("  " & myNo, 2) & "st"
	case 2, 22:		GetDay = right("  " & myNo, 2) & "nd"
	case 3, 23:		GetDay = right("  " & myNo, 2) & "rd"
	case else:		GetDay = right("  " & myNo, 2) & "th"
	end select
end function

function GetMonth(myNo)
	select case myNo
	case 1:		GetMonth = "Jan"
	case 2:		GetMonth = "Feb"
	case 3:		GetMonth = "Mar"
	case 4:		GetMonth = "Apr"
	case 5:		GetMonth = "May"
	case 6:		GetMonth = "Jun"
	case 7:		GetMonth = "Jul"
	case 8:		GetMonth = "Aug"
	case 9:		GetMonth = "Sep"
	case 10:	GetMonth = "Oct"
	case 11:	GetMonth = "Nov"
	case 12:	GetMonth = "Dec"
	end select
end function

Function ResetDigital(myData, myDigital, myMode)
Dim pos, buf
    buf = GetDouble(myData)
    If buf <> 0 Then
        For pos = 1 To GetLong(myDigital)
            buf = buf * 10
        Next
        Select Case GetLong(myMode)
        Case -1             '�؂�̂�
            buf = Fix(buf + 0.00001)
        Case 0              '�l�̌ܓ�
            buf = CLng(FormatNumber(buf, 0, True))
        Case 1              '�؂�グ
            If abs(buf - Fix(buf)) < 0.00001 Then
                buf = Fix(buf) + 1
            End If
        End Select
        For pos = 1 To GetLong(myDigital)
            buf = buf / 10
        Next
    End If
    ResetDigital = buf
End Function


'=============================
'	��{�}�X�^��
'=============================
function ShowShopList(myCode)
dim mySql
dim myRec
dim myCon
dim buf

	buf = ""
	OpenSQL myCon, SqlServerName, "WebMaster"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT ShopID, ShopCode, ShopName FROM MstShop WHERE Deleted = 0 AND ShopGroupID = 2 ORDER BY ShopID"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("ShopCode")
		if myRec.fields("ShopCode") = myCode then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("ShopName")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
	ShowShopList = buf	
end function

dim DepartSales
	DepartSales = 1		'�c�ƕ�
dim DepartCustoms
	DepartCustoms = 2	'�ʊ֕�
dim DepartAccount
	DepartAccount = 4	'�o����
dim DepartImport
	DepartImport = 8	'�A����
dim DepartExport
	DepartExport = 16	'�A�o��
dim DepartGeneral
	DepartGeneral = 32	'������

function ShowEmployList(myDpt, myID)
dim mySql
dim myRec
dim myCon
dim myDepart
dim buf
dim hama

	buf = ""
	OpenSQL myCon, SqlServerName, "WebMaster"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	spec = ""
	select case myDpt
	case DepartSales					'�c�ƕ�
		spec = "'�c',' '"
		myDepart = "�c��"
	case DepartCustoms					'�ʊ֕�
		spec = "'��','�c',' '"
		myDepart = "�ʊ�"
	case DepartAccount					'�o����
		spec = "'�o',' '"
		myDepart = "�o��"
	case DepartImport					'�ʊ֗A����
		spec = "'��','�c'"
		myDepart = "�ʊ֗A��"
	case DepartExport					'�ʊ֗A�o��
		spec = "'��','�c'"
		myDepart = "�ʊ֗A�o"
	case else
		myDepart = ""
	end select
	
	mySql = "SELECT WebUserID, UserCode, FamilyName, ShopID FROM MstWebUser"
	mySql = mySql & " WHERE Deleted = 0 AND ShopGroupID = 2"
	select case WebUserID
	case 1, 2, 18, 30, 31, 32, 68, 70
		mySql = mySql & " AND ((ShopID > " & gsCorpID & " AND SUBSTRING(Depart,1, 1) IN (" & spec & "))"
		mySql = mySql & " OR (ShopID = " & gsCorpID & " AND SUBSTRING(Depart,1, " & len(myDepart) &") = '" & myDepart & "'))"
	case else
		mySql = mySql & " AND ShopID = " & session("ShopID")
		select case session("ShopID") 
		case gsCorpID
			mySql = mySql & " AND SUBSTRING(Depart,1, " & len(myDepart) &") = '" & myDepart & "'"
		case 3
			mySql = mySql & " AND SUBSTRING(Depart,1, 1) IN (" & spec & ")"
		end select
	end select
	mySql = mySql & " ORDER BY ShopID, Depart, UserCode"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("WebUserID")
		if myRec.fields("WebUserID") = myID then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("FamilyName")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
	if UserShop <> gsSokoInit then
		if myDpt = DepartSales then
			buf = buf & "<option value=60"
			if myID = 60 then buf = buf & " selected"
			buf = buf & ">�R��"
		end if
	end if
	ShowEmployList = buf	
end function

function GetEmployName(myID, myMode)
dim myRec
dim myCon
	GetEmployName = ""
	select case GetLong(myID) 
	case 0 
	case 999
		select case myMode
		case "F":		GetEmployName = "����"
		case else:		GetEmployName = "SYSTEM"
		end select
	case else
		Opensql myCon, SqlWMServerName, "WebMaster"
		set myRec = Server.CreateObject ("ADODB.Recordset")
		myRec.Open "SELECT UserName, FamilyName, EnglishName, NickName FROM MstWebUser WHERE WebUserID = " & myID, myCon, adOpenKeyset, adLockReadOnly
		if not myRec.eof then
			select case myMode
			case "E":		GetEmployName = GetString(myRec.fields("EnglishName"))
			case "F":		GetEmployName = GetString(myRec.fields("FamilyName"))
			case "N":		GetEmployName = GetString(myRec.fields("NickName"))
			case "U":		GetEmployName = GetString(myRec.fields("UserName"))
			end select
		end if
		myRec.close
		set myRec = nothing	
		CloseDB myCon
	end select
end function

function GetEmployTelFax(myID, myTel, myFax, myMail)
dim myRec
dim myCon
	Opensql myCon, SqlWMServerName, "WebMaster"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	myRec.Open "SELECT Cell, TEL, FAX, Email, Kmail, MSN FROM MstWebUser WHERE WebUserID = " & GetLong(myID) , myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then
		myTel = GetString(myRec.fields("TEL"))
		myFax = GetString(myRec.fields("FAX"))
		myMail = GetString(myRec.fields("Email"))
	end if
	myRec.close
	set myRec = nothing	
	CloseDB myCon
end function

function GetCountryName(myCD)
dim myRec
dim myCon

	GetCountryName = ""
	OpenSQL myCon, SqlServerName, DataBaseName

	set myRec = Server.CreateObject ("ADODB.Recordset")
	myRec.Open "SELECT CN_ENAME FROM MST_COUNTRY WHERE CN_CD = '" & myCD & "'", myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetCountryName = GetString(myRec.fields("CN_ENAME"))
	myRec.close
	set myRec = nothing	
	CloseDB myCon
end function


'=============================
'	�׎�}�X�^��
'=============================

function ShowCustomHead(myCode)
dim mySql
dim myRec
dim myCon
dim buf

	buf = "<table width=95% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>"
	buf = buf & "<TR><TD><img src=img/spacer.gif height=3>"
	
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
				
	mySql = "SELECT CTM_REF, CTM_ABR, CTM_NAME, CTM_ENAME FROM CUSTOMER" 
	mySql = mySql & " WHERE CTM_DELETED = 0 AND CTM_CD = '" & myCode & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then
		buf = buf & "<TR height=25><TD class=pt9>��������<TD class=gline>&nbsp;" & myRec.fields("CTM_REF")
		buf = buf & "<TD align=center class=pt9>�p������<TD class=gline>&nbsp;" & myRec.fields("CTM_ENAME")
		buf = buf & "<TR height=25><TD class=pt9>�a������<TD class=gline>&nbsp;" & myRec.fields("CTM_ABR")
		buf = buf & "<TD align=center class=pt9>�a������<TD class=gline>&nbsp;" & myRec.fields("CTM_NAME")
	end if
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
	buf = buf & "</TABLE>"
	ShowCustomHead = buf	
end function

function GetCtmCode(myStr, myMode)
dim mySql
dim myRec
dim myCon
	
	GetCtmCode = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	select case GetLong(myMode)
	case 0
		mySql = "SELECT CTM_CD FROM CUSTOMER WHERE CTM_REF = '" & myStr & "'"
	case 1
		mySql = "SELECT CTM_CD FROM CUSTOMER WHERE CTM_ENAME = '" & myStr & "'"
	case 2
		mySql = "SELECT CTM_CD FROM CUSTOMER WHERE CTM_ABR = '" & myStr & "'"
	case 3
		mySql = "SELECT CTM_CD FROM CUSTOMER WHERE CTM_NAME = '" & myStr & "'"
	case 4
		mySql = "SELECT CTM_FINANCE_CD AS CTM_CD FROM CUSTOMER WHERE CTM_REF = '" & myStr & "'"
	end select	
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetCtmCode = GetString(myRec.fields("CTM_CD"))
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
end function


function GetCtmName(myCode)
dim mySql
dim myRec
dim myCon
dim buf
	
	GetCtmName = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
				
	mySql = "SELECT CTM_ENAME FROM CUSTOMER WHERE CTM_CD = '" & myCode & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetCtmName = GetString(myRec.fields("CTM_ENAME"))
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
end function

function GetRefName(myCode)
dim mySql
dim myRec
dim myCon
dim buf
	
	GetRefName = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
				
	mySql = "SELECT CTM_REF FROM CUSTOMER WHERE CTM_CD = '" & myCode & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetRefName = GetString(myRec.fields("CTM_REF"))
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
end function

function GetFullName(myCode)
dim mySql
dim myRec
dim myCon
dim buf
	
	GetFullName = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
				
	mySql = "SELECT CTM_NAME FROM CUSTOMER WHERE CTM_CD = '" & myCode & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetFullName = GetString(myRec.fields("CTM_NAME"))
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
end function

function GetCtmLinkName(myCode, myID)
dim mySql
dim myRec
dim myCon
dim buf
	
	GetCtmLinkName = ""
	if GetLong(myID) <> 0 then
		OpenSQL myCon, SqlServerName, DataBaseName
		set myRec = Server.CreateObject ("ADODB.Recordset")				
		mySql = "SELECT LINK_NAME FROM CTM_LINK WHERE LINK_ID = " & myID
		myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not myRec.eof then GetCtmLinkName = GetString(myRec.fields("LINK_NAME"))
		myRec.close
		set myRec = nothing	
		CloseDB myCon	
	end if
	if GetCtmLinkName = "" then GetCtmLinkName = GetFullName(myCode)	
end function

function GetCtmType(myCode)
dim mySql
dim myRec
dim myCon
	GetCtmType = 0
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec	
		mySql = "SELECT CTM_TYPE FROM CUSTOMER WHERE CTM_CD = '" & myCode & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then GetCtmType = GetLong(.fields("CTM_TYPE"))
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

'�ďo��		PaymentErase1.asp	�o�b�`�o���������
function GetCtmBelong(myCode)
dim mySql
dim myRec
dim myCon
dim buf
	
	GetCtmBelong = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
				
	mySql = "SELECT CTM_BELONG FROM CUSTOMER WHERE CTM_CD = '" & myCode & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetCtmBelong = GetString(myRec.fields("CTM_BELONG"))
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
end function


'�ďo��		ReceiveErase.asp	���������������
'			ReceiveResult.asp	�����ꗗ�Ɖ���
function GetSalesManager(myCode)
dim mySql
dim myRec
dim myCon
dim buf
	
	buf = 0
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
				
	mySql = "SELECT CTM_SALESMNGR FROM CUSTOMER WHERE CTM_CD = '" & myCode & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then buf = GetLong(myRec.fields("CTM_SALESMNGR"))
	myRec.close
	set myRec = nothing
	CloseDB myCon
	
	GetSalesManager = buf
end function

function GetDftManager(myCD)
dim mySql
dim myRec
dim myCon

	GetDftManager = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")	
	
	mySql = "SELECT PIC_NAME FROM CTM_PIC WHERE PIC_DELETED = 0 AND PIC_DFT = 1 AND CTM_CD = '" & myCD & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetDftManager = myRec.fields("PIC_NAME")
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
end function

function GetCtmClose(myCode, mySales, myStand, myCosts)
dim mySql
dim myRec
dim myCon
dim buf
	
	GetCtmClose = false
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec	
		mySql = "SELECT CTM_SALES_CLOSE, CTM_STAND_CLOSE, CTM_COSTS_CLOSE"
		mySql = mySql & " FROM CTM_CONTACT WHERE CTM_CD = '" & myCode & "' ORDER BY CONTACT_DATE DESC"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then 
			GetCtmClose = true
			mySales = GetLong(.fields("CTM_SALES_CLOSE"))
			myStand = GetLong(.fields("CTM_STAND_CLOSE"))
			myCosts = GetLong(.fields("CTM_COSTS_CLOSE"))
		end if
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

function GetCtmSight(myCode, mySales, myStand, myCosts)
dim mySql
dim myRec
dim myCon
dim buf
	
	GetCtmSight = false
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec	
		mySql = "SELECT CTM_SALES_CREDIT, CTM_SALES_PAYDAY, CTM_STAND_CREDIT, CTM_STAND_PAYDAY, CTM_COSTS_CREDIT, CTM_COSTS_PAYDAY"
		mySql = mySql & " FROM CTM_CONTACT WHERE CTM_CD = '" & myCode & "' ORDER BY CONTACT_DATE DESC"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then
			GetCtmSight = true
			mySales = GetLong(.fields("CTM_SALES_CREDIT")) * 1000 + GetLong(.fields("CTM_SALES_PAYDAY"))
			myStand = GetLong(.fields("CTM_STAND_CREDIT")) * 1000 + GetLong(.fields("CTM_STAND_PAYDAY"))
			myCosts = GetLong(.fields("CTM_COSTS_CREDIT")) * 1000 + GetLong(.fields("CTM_COSTS_PAYDAY"))
		end if
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

function ShowCloseList(myClose)
dim idx
dim buf
	buf = buf & "<option value=0":	if myClose = 0 then buf = buf & " selected"
	buf = buf & ">������"
	for idx = 1 to 27 
		buf = buf & "<option value=" & idx
		if myClose = idx then buf = buf & " selected"
		buf = buf & ">" & right(" " & idx, 2) & "����"
	next 
	buf = buf & "<option value=70":		if myClose = 70 then buf = buf & " selected"
	buf = buf & ">������"
	buf = buf & "<option value=99":		if myClose = 99 then buf = buf & " selected"
	buf = buf & ">������"
	buf = buf & "<option value=100":	if myClose = 100 then buf = buf & " selected"
	buf = buf & ">10����"
	buf = buf & "<option value=150":	if myClose = 150 then buf = buf & " selected"
	buf = buf & ">15����"
	ShowCloseList = buf	
end function

function ShowCreditList(myCredit)
dim idx
dim buf
	for idx = 0 to ubound(ctmCredit) 
		buf = buf & "<option value=" & idx
		if myCredit = idx then buf = buf & " selected"
		buf = buf & ">" & ctmCredit(idx)
	next 
	ShowCreditList = buf
end function


function ShowPayDayList(myPayDay)
dim idx
dim buf
	buf = buf & "<option value=0":	if myPayDay = 0 then buf = buf & " selected"
	buf = buf & ">����"
	for idx = 1 to 27 
		buf = buf & "<option value=" & idx
		if myPayDay = idx then buf = buf & " selected"
		buf = buf & ">" & right(" " & idx, 2) & "��"
	next 	
	buf = buf & "<option value=70":		if myPayDay = 70 then buf = buf & " selected"
	buf = buf & ">����"
	buf = buf & "<option value=99":		if myPayDay = 99 then buf = buf & " selected"
	buf = buf & ">����"
	buf = buf & "<option value=100":	if myPayDay = 100 then buf = buf & " selected"
	buf = buf & ">10����"
	buf = buf & "<option value=150":	if myPayDay = 150 then buf = buf & " selected"
	buf = buf & ">15����"
	ShowPayDayList = buf	
end function

function ShowClose(myClose)
dim num
	num = GetLong(myClose)
	if num = 0 then 
		ShowClose = "������"
	elseif num < 31 then 
		ShowClose = num & "����"
	elseif num = 70 then 
		ShowClose = "������"
	elseif num = 99 then 
		ShowClose = "������"
	elseif num = 100 then 
		ShowClose = "10����"
	elseif num = 150 then 
		ShowClose = "15����"
	else
		ShowClose = "���s��"
	end if
end function

function ShowPayDay(myPayDay)
dim num
	num = GetLong(myPayDay)
	if num <= 0 then 
		ShowPayDay = "����"
	elseif num < 31 then 
		ShowPayDay = "��" & num & "��"
	elseif num = 70 then 
		ShowPayDay = "����"
	elseif num = 99 then 
		ShowPayDay = "����"
	elseif num = 100 then 
		ShowPayDay = "10����"
	elseif num = 150 then 
		ShowPayDay = "15����"
	else
		ShowPayDay = "����"
	end if
end function

'�ďo��F 	ChargerSearch.asp 	�׎匟������
'			ChargeHead.asp 		����ͯ�ޏ���
'			PaymentHead.asp 	�x��ͯ�ޏ���
function Close2Date(myClose, myDate)
dim dte, num, buf, dt
	dte = GetDate(myDate)
	if dte = "" then dte = date
	
	num = GetLong(myClose)
	if num = 0 then 					'��������
		buf = dte
		
	elseif num < 31 then				'�w�����
	
		if day(dte) <= num then
			buf = dte
		else
			buf = dateadd("m", 1, dte)
		end if
		buf = cdate(year(buf) & gsDateSign & month(buf) & gsDateSign & num)
		
	elseif num = 70 then 				'������
	
		if weekday(dte) <= 6 then				'���`��
			buf = dateadd("d", 6 - weekday(dte), dte)
		else									'�y����
			buf = dateadd("d", 6, dte)
		end if
		
	elseif num = 99 then 				'������
	
		buf = GetMonthLastDay(dte)
		
	elseif num = 100 then 				'10����
	
		dt = (day(dte) \ 10) * 10
		if (day(dte) <> 31) and (day(dte) mod 10 > 0) then dt = dt + 10
		if dt = 30 then
			buf = GetMonthLastDay(dte)
'			if day(buf) = 31 then buf = cdate(year(dte) & gsDateSign & month(dte) & gsDateSign & "30")
		else
			buf = cdate(year(dte) & gsDateSign & month(dte) & gsDateSign & dt)
		end if
		
	elseif num = 150 then  				'15����
	
		dt = (day(dte) \ 15) * 15
		if (day(dte) <> 31) and (day(dte) mod 15 > 0) then dt = dt + 15
		if dt = 30 then
			buf = GetMonthLastDay(dte)
'			if day(buf) = 31 then buf = cdate(year(dte) & gsDateSign & month(dte) & gsDateSign & "30")
		else
			buf = cdate(year(dte) & gsDateSign & month(dte) & gsDateSign & dt)
		end if
		
	else								'���̑�
		buf = dte
	end if
	
	Close2Date = formatDate(buf)
end function


'�ďo��F 	ChargerSearch.asp 	�׎匟������
'			ChargeHead.asp 		����ͯ�ޏ���
'			PaymentHead.asp 	�x��ͯ�ޏ���
function Sight2Date(mySight, myDate)
dim st, dte, num, buf, dt
	dte = GetDate(myDate)
	if dte = "" then dte = date
	
	st = GetLong(mySight) \ 1000
	num = GetLong(mySight) mod 1000
	
	if num = 0 then 					'��������	
		buf = dte
		
	elseif num < 31 then				'�w�����
		
		buf = dateadd("m", st, dte)
		if st = 0 and day(dte) >= num then buf = dateadd("m", 1, dte)
		buf = cdate(year(buf) & gsDateSign & month(buf) & gsDateSign & num)
		
	elseif num = 70 then 				'������
		
		if weekday(dte) <= 6 then				'���`��
			buf = dateadd("d", st * 7 + 6 - weekday(dte), dte)
		else									'�y����
			buf = dateadd("d", st * 7 + 6, dte)
		end if		
		
	elseif num = 99 then 				'������
		
		buf = GetMonthLastDay(dateadd("m", st, dte))
		
	elseif num = 100 then 				'10����
		
		buf = dateadd("d", st * 10, dte)
		dt = day(buf) - (day(buf) \ 10) * 10
		if dt < 5 then
			buf = dateadd("d", 0 - dt, buf)
		else
			buf = dateadd("d", 10 - dt, buf)
		end if
		
	elseif num = 150 then  				'15����
		
		buf = dateadd("d", st * 15, dte)
		dt = day(buf) - (day(buf) \ 15) * 15
		if dt < 5 then
			buf = dateadd("d", 0 - dt, buf)
		else
			buf = dateadd("d", 15 - dt, buf)
		end if				
		
	else								'���̑�
		buf = dte
	end if
	Sight2Date = formatDate(buf)
end function

function GetTelFaxIndex(myStr)
on error resume next
dim i
dim buf
dim tmp	
	buf = trim(myStr)
	for i = 1 to len(buf)
		tmp = mid(buf,i,1)
		if asc(tmp) > 57 or asc(tmp) < 47 then
			buf = replace(buf,tmp,"@")
		end if
	next
	GetTelFaxIndex = replace(buf,"@","")
end function

Function Init2City(myInit)
	select case ucase(myInit)
	case "K":	Init2City = "KOBE"
	case "O":	Init2City = "OSAKA"
	case "T":	Init2City = "TOKYO"
	case else:	Init2City = ""
	end select
End Function


Function GetHornor(myName)
dim buf
	buf = GetString(myName)
	if buf <> "" and right(buf, 1) <> "�l" then buf = buf & " �l"
	GetHornor = buf
End Function



'=============================
'	�ʊ֋Ɩ���
'=============================
'�ďo��F 	DeliveryDetail.asp 	�[�i�z�ԏ���
'			CostsDetail.asp 	�x�����׏���
'			ChargeDetail.asp 	�������׏���
function ShowCstmJobHead(myCode, myMode)
dim mySql
dim myRec
dim myCon
dim buf

	buf = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT JobNo, JobBelong, JobClient, JobShipper, CustomBroker, JobType, JobCountry, Vessel, Voy, Quantity, Package, ViaPlace, CarryPlace, Inspection, DeliveryDate, InvoiceNo, ReferNo, Remarks" 
		mySql = mySql & ", JobOperator, MBL, HBL, ETD, ETA, POL, POD, CBM, GW, JobSalesman, FinisherID, LockerID, SalesDate, AccountDate FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobCode = '" & myCode & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then
			JobNo = GetString(.fields("JobNo"))
			JobBelong = GetString(.fields("JobBelong"))
			JobShipper = GetString(.fields("JobShipper"))
			JobBroker = GetString(.fields("CustomBroker"))
			JobClient = GetString(.fields("JobClient"))
			JobClientName = GetFullName(JobClient)
			JobCarryPlace = GetString(.fields("ViaPlace"))
			if JobCarryPlace = "" then JobCarryPlace = GetString(.fields("CarryPlace"))
			JobMemo = GetString(.fields("Remarks"))
			JobFinisher = GetLong(.fields("FinisherID"))
			JobDelivery = Str2Date(.fields("DeliveryDate"))
			JobLocker = GetLong(.fields("LockerID"))
			JobType = GetString(.fields("JobType"))
			JobInvoice = GetString(.fields("InvoiceNo"))
			JobReferNo = GetString(.fields("ReferNo"))
			JobInspection = GetString(.fields("Inspection"))
			JobAccountDate = GetString(.fields("AccountDate"))
			JobSalesman = GetLong(.fields("JobSalesman"))
			JobOperator = GetLong(.fields("JobOperator"))
			
			JobCountry = GetCountryName(GetString(.fields("JobCountry")))
			JobLine = GetString(.fields("POL"))
			if CheckJobType(myCode) = gsImport and JobCountry <> GetString(.fields("POL")) then JobLine = JobLine & ", " & JobCountry
			JobLine = JobLine & " �� " & GetString(.fields("POD"))
			if CheckJobType(myCode) = gsExport and JobCountry <> GetString(.fields("POD")) then JobLine = JobLine & ", " & JobCountry
			
			buf = "<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>"
			buf = buf & "<TR height=25 align=center>"
			if myMode = 0 then
				buf = buf & "<TD width=10% class=pt9>�����׎�<TD width=35% class=gline align=left>&nbsp;" & ResetCorpName(JobClientName)
			else
				buf = buf & "<TD width=10% class=pt9>�q�H<TD width=35% class=gline align=left>&nbsp;" & JobLine
			end if
			buf = buf & "<TD width=10% class=pt9>����<TD width=15% class=gline>&nbsp;" & ShowInspection(JobInspection)
			buf = buf & "<TD width=10% class=pt9>��<TD width=20% class=gline>&nbsp;" & GetDouble(.fields("Quantity")) & " " & GetString(.fields("Package"))
			buf = buf & "<TR height=25 align=center>"		
			buf = buf & "<TD class=pt9>�q�֖�<TD class=gline align=left>&nbsp;" & GetString(.fields("Vessel")) & "&nbsp;V." & GetString(.fields("Voy"))
			if CheckJobType(myCode) = gsImport then
				buf = buf & "<TD class=pt9>���`��<TD class=gline>&nbsp;" & Str2Date(.fields("ETA"))
			else
				mySalesDate = GetString(.fields("SalesDate"))
				if mySalesDate <> "" and mySalesDate < Date2Str(date) then
					buf = buf & "<TD class=pt9r>�o�`��<TD class=gline>&nbsp;" & Str2Date(.fields("ETD"))
				else
					buf = buf & "<TD class=pt9>�o�`��<TD class=gline>&nbsp;" & Str2Date(.fields("ETD"))
				end if
			end if
			if myMode = 0 then
				buf = buf & "<TD class=pt9>B/L ��<TD class=gline>&nbsp;" & GetString(.fields("HBL"))
				if GetString(.fields("HBL")) = "" then buf = buf & GetString(.fields("MBL"))
			else
				buf = buf & "<TD class=pt9>�e��<TD class=gline>&nbsp;" & GetString(.fields("CBM")) & " M<sup>3</sup>"
				buf = buf & "<TR height=25 align=center>"
				buf = buf & "<TD class=pt9>B/L ��<TD class=gline align=left>&nbsp;" & GetString(.fields("HBL")) & " " & GetString(.fields("MBL"))
				buf = buf & "<TD class=pt9>�_��<TD class=gline>&nbsp;" & GetString(.fields("ReferNo"))
				buf = buf & "<TD class=pt9>�d��<TD class=gline>&nbsp;" & GetString(.fields("GW")) & " KGS"
			end if
			buf = buf & "</TABLE>"
		end if
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
	
	ShowCstmJobHead = buf	
end function

function ShowInspection(myInspect)
dim pos, buf
	ShowInspection = "����"
	for pos = 1 to ubound(ctmInspect)
		if mid(myInspect, pos, 1) = "1" then
			buf = buf & "+" & ctmInspect(pos)
		end if
	next
	if buf <> "" then ShowInspection = "<font color=red>" & mid(buf, 2) & "</font>"
end function

'�ďo��F 	CustomsSave.asp 	�ʊ֋Ɩ�����
function CheckJobLocked(myCode)
dim mySql
dim myRec
dim myCon
	CheckJobLocked = false
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT JobCode FROM TBL_CTM_JOB WHERE LockerID <> 0 AND JobCode = '" & myCode & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckJobLocked = true
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

'�ďo��F 	CustomsSave.asp 	�ʊ֋Ɩ�����
'			DeliveryUpdate.asp 	�[�i�z�ԏ���
function CheckJobFinished(myCode)
dim mySql
dim myRec
dim myCon
	CheckJobFinished = false
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT JobCode FROM TBL_CTM_JOB WHERE FinisherID <> 0 AND JobCode = '" & JobCode & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckJobFinished = true
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

function GetJobStatus(myCode)
dim mySql
dim myRec
dim myCon
dim buf
		
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT * FROM TBL_CTM_STATUS WHERE JobCode = '" & JobCode & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then
			
		end if
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
	
	GetJobStatus = buf	
end function

function GetRTON(myGW, myCBM)
dim rt
	rt = GetLong(GetDouble(myCBM) * 1000) '* 0.8837
	if rt < GetLong(myGW) then rt = GetLong(myGW)
	GetRTON = formatnumber(rt / 1000, 3, true)
end function

'�ďo��		CustomsEdit.asp		�ʊ֋Ɩ����׉��
'			CustomsSI.asp		�ʊ�SI������
function GetKGS(myGW, myCBM)
dim kg
	kg = GetDouble(myCBM) * 8 / 0.027
	if kg < GetDouble(myGW) then kg = GetDouble(myGW)
	GetKGS = formatnumber(kg, 3, true)
end function

function ShowCategoryList(myCode, myDft, myMode)
dim mySql
dim myRec
dim myCon
dim myBCD
dim buf

	buf = ""
	select case myCode
	case "ChargeType":		myBCD = "001"			'�����敪
	case "ChargeUnit": 		myBCD = "002"			'�����P��
	case "TaxCode": 		myBCD = "003"			'�ېŋ敪
	case "Delivery": 		myBCD = "004"			'�[�i���@
	case "JobType": 		myBCD = "005"			'��ƌ`��
	case "ChargeBelong":	myBCD = "006"			'����敪
	case "VoucherType":		myBCD = "007"			'�`�[�敪
	case "Securities":		myBCD = "008"			'�x�����@
	case "ExpenseAttr":		myBCD = "009"			'��p�敪
	case else: 				myBCD = "000"			'�s��
	end select 
	
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT CTGR_CD, CTGR_NAME, CTGR_ENAME, CTGR_NUM, CTGR_FLAG FROM MST_CATEGORY" 
	mySql = mySql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = '" & myBCD & "'"
	if myMode <> 0 then mySql = mySql & " AND CTGR_FLAG = 1"
	mySql = mySql & " ORDER BY CTGR_CD"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & chr(34) & myRec.fields("CTGR_NAME") & chr(34)
		if myRec.fields("CTGR_NAME") = myDft then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("CTGR_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
	ShowCategoryList = buf	
end function
			
function GetPaymentDate(myCTM, myMode)
dim buf
	buf = ""
	
	GetPaymentDate = buf
end function
	
function GetPortName(myName)
dim buf, pos
	buf = GetString(myName)
	pos = instr(myName, "(") 
	if pos <> 0 then buf = left(buf, pos-1)
	pos = instr(myName, "-") 
	if pos <> 0 then buf = left(buf, pos-1)
	GetPortName = trim(buf)
end function

'�ďo��F 	ChargeUpdate.asp 	�������׏���
'			ChargeSave.asp 		�������X�V�E�폜����
function CheckBillLocked(myCon, myCode, myNo)
dim mySql
dim myRec
	CheckBillLocked = false
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT JobCode FROM TBL_CTM_CHARGE WHERE ConfirmerID <> 0 AND JobCode = '" & myCode & "' AND ChargeNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckBillLocked = true
		.close
	end with
	set myRec = nothing	
end function

'�ďo��F 	ChargeSave.asp �������m�菈��
function CheckBillMatched(myCon, myCode, myNo)
dim mySql
dim myRec
dim myAmount
dim myTax
dim mySumAmount
dim mySumTax

	CheckBillMatched = false
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT ChargeAmount, ChargeTax FROM TBL_CTM_CHARGE WHERE JobCode = '" & myCode & "' AND ChargeNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then 
			myAmount = GetLong(.fields("ChargeAmount"))
			myTax = GetLong(.fields("ChargeTax"))
		end if
		.close
		
		mySql = "SELECT SUM(ExpenseAmount) AS SumAmount, SUM(ExpenseTax) AS SumTax FROM TBL_CTM_EXPENSE"
		mySql = mySql & " WHERE Deleted= 0 AND JobCode = '" & myCode & "' AND ExpenseBill = '" & myNo & "'"
		.Open mySql, Conn, adOpenStatic, adLockReadOnly
		if not .eof then
			mySumAmount = GetLong(.Fields("SumAmount"))
			mySumTax = GetLong(.Fields("SumTax"))
		end if
		.Close
	end with
	set myRec = nothing	
	
	if myAmount = mySumAmount and myTax = mySumTax then CheckBillMatched = true
end function

'�ďo��F 	ChargeSave.asp 		�������m�����
'			StandRemove.asp 	���������֍폜
function CheckBillFinished(myCon, myCode, myNo)
dim mySql
dim myRec
	CheckBillFinished = false
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT JobCode FROM TBL_CTM_CHARGE WHERE FinisherID <> 0 AND JobCode = '" & myCode & "' AND ChargeNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckBillFinished = true
		.close
	end with
	set myRec = nothing	
end function

'�ďo��F 	BalanceCheck.asp 		�o�����X�m�F���
'		 	BalanceView.asp 		�Ɩ����b�N����
function CheckJobBillConfirmed(myCon, myCode)
dim mySql
dim myRec
dim buf
	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		'���֖������`�F�b�N
		if buf = "" then	
			mySql = "SELECT SeqNo FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND ExpenseType = 2 AND ExpenseBill = '' AND JobCode = '" & myCode & "'"
			.Open mySql, myCon, adOpenKeyset, adLockReadOnly
			if not .eof then buf = "��������ĂȂ����֋��͂���܂��B�䒠�ԍ��F" & myCode
			.close
		end if
		
		'���������m�F�`�F�b�N
		if buf = "" then	
			mySql = "SELECT ChargeNo FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ConfirmerID = 0 AND JobCode = '" & myCode & "'"
			.Open mySql, myCon, adOpenKeyset, adLockReadOnly
			if not .eof then buf = "�m�肳��ĂȂ��������͂���܂��B�䒠�ԍ��F" & myCode & "�@�����ԍ��F" & GetString(.fields("ChargeNo"))
			.close
		end if
		
		'�x���`�[���m�F�`�F�b�N	
		if buf = "" then
			mySql = "SELECT CostsNo FROM TBL_CTM_COSTS WHERE Deleted = 0 AND ConfirmerID = 0 AND JobCode = '" & myCode & "'"
			.Open mySql, myCon, adOpenKeyset, adLockReadOnly
			if not .eof then buf = "�m�肳��ĂȂ��x���`�[�͂���܂��B�䒠�ԍ��F" & myCode & "�@�x���ԍ��F" & GetString(.fields("CostsNo"))
			.close
		end if
	end with
	set myRec = nothing	
	CheckJobBillConfirmed = buf
end function

'�ďo��F	CostsUpdate.asp 	�x���`�[���׏���
'			CostsSave.asp 		�x���`�[�X�V�E�폜����
function CheckCostsLocked(myCon, myCode, myNo)
dim mySql
dim myRec
	CheckCostsLocked = false
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT JobCode FROM TBL_CTM_COSTS WHERE ConfirmerID <> 0 AND JobCode = '" & myCode & "' AND CostsNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckCostsLocked = true
		.close
	end with
	set myRec = nothing	
end function

'�ďo��F CostsSave.asp �x���`�[�m�菈��
function CheckCostsMatched(myCon, myCode, myNo)
dim mySql
dim myRec
dim myAmount
dim myTax
dim mySumAmount
dim mySumTax

	CheckCostsMatched = false
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT CostsAmount, CostsTax FROM TBL_CTM_COSTS WHERE JobCode = '" & myCode & "' AND CostsNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then
			myAmount = GetLong(.fields("CostsAmount"))
			myTax = GetLong(.fields("CostsTax"))
		end if
		.close
		
		mySql = "SELECT SUM(ExpenseAmount) AS SumAmount, SUM(ExpenseTax) AS SumTax FROM TBL_CTM_EXPENSE"
		mySql = mySql & " WHERE Deleted= 0 AND ExpensePay = '" & myNo & "'" ' AND JobCode = '" & myCode & "'
		.Open mySql, Conn, adOpenStatic, adLockReadOnly
		if not .eof then
			mySumAmount = GetLong(.Fields("SumAmount"))
			mySumTax = GetLong(.Fields("SumTax"))
		end if
		.Close
	end with
	set myRec = nothing	
	
	if myAmount = mySumAmount and myTax = mySumTax then CheckCostsMatched = true
end function

'�ďo��F 	CostsSave.asp 		�x���`�[�m�����
function CheckCostsFinished(myCon, myCode, myNo)
dim mySql
dim myRec
	CheckCostsFinished = false
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT JobCode FROM TBL_CTM_COSTS WHERE FinisherID <> 0 AND JobCode = '" & myCode & "' AND CostsNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckCostsFinished = true
		.close
	end with
	set myRec = nothing	
end function

'�ďo��F 	CostsSave.asp 		�x���`�[�X�V����
function CheckBillRepeat(myCode, myNo, myClient, myClientName, myBill)
dim mySql
dim myRec
dim myCon
	CheckBillRepeat = ""
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT CostsNo FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsBillNo = '" & myBill & "' AND JobCode = '" & JobCode & "' AND CostsNo <> '" & myNo & "'"
		mySql = mySql & " AND CostsClient = '" & myClient & "' AND CostsClientName = '" & myClientName & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckBillRepeat = GetString(.fields("CostsNo"))
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

'�ďo��F 	ChargeSave.asp 		�������ۑ�����
'			CostsSave.asp 		�x���`�[�ۑ�����
function GetTaxRate(myStr)
dim pos, idx, cnt
	GetTaxRate = 0
	cnt = 0
	for idx = 1 to len(myStr)
		if asc(mid(mystr,idx,1)) >= 48 and asc(mid(mystr,idx,1)) <=57 then
			if cnt = 0 then pos = idx
			cnt = cnt + 1
		elseif cnt > 0 then					
			exit for
		end if
	next 
	if cnt > 0 then
		GetTaxRate = clng(mid(myStr,pos,cnt)) / 100
	end if
end function

'�ďo��F 	CostsHead.asp 		�����x���`�[�w�b�_���
'			CloseHead.asp 		�����x���`�[�w�b�_���
'			PaymentHead.asp 	�ʏ�x���`�[�w�b�_���
function CheckBatchLocked(myBatch)
dim mySql
dim myRec
dim myCon
	CheckBatchLocked = 0
	if GetString(myBatch) = "" then exit function
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT BatchNo FROM TBL_CTM_BATCH WHERE Deleted = 0 AND ConfirmerID = 0 AND BatchNo = '" & myBatch & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if .eof then CheckBatchLocked = 1
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

'�ďo��F 	ChargerSearch.asp 	�ڋq��񌟍����
'			ChargeHead.asp 		�������`�[�w�b�_���
function FitDatePlus(myDate)
dim buf	
	buf = GetDate(myDate)
	if isdate(buf) then
		do while CheckHoliday(buf)
			buf = dateadd("d", 1, buf)
		loop
	end if
	FitDatePlus = buf
end function

'�ďo��F 	ChargerSearch.asp 	�ڋq��񌟍����
'			PaymentHead.asp 	�x���`�[�w�b�_���
function FitDateMinus(myDate)
dim buf
	buf = GetDate(myDate)
	if isdate(buf) then
		do while CheckHoliday(buf)
			buf = dateadd("d", -1, buf)
		loop
	end if
	FitDateMinus = buf
end function

'�ďo��F 	��L
function CheckHoliday(myDate)
dim mySql
dim myRec
dim myCon
dim buf
	CheckHoliday = 0
	buf = GetDate(myDate)
	if not isdate(buf) then exit function
	
	if weekday(buf) = 1 or weekday(buf) = 7 then
		CheckHoliday = 1 
	else
		OpenSQL myCon, SqlServerName, DatabaseName
		set myRec = Server.CreateObject ("ADODB.Recordset")
		with myRec				
			mySql = "SELECT Holiday FROM MST_HOLIDAY WHERE Deleted = 0 AND Holiday = '" & Date2Str(buf) & "'"
			.Open mySql, myCon, adOpenKeyset, adLockReadOnly
			if not .eof then CheckHoliday = 1
			.close
		end with
		set myRec = nothing	
		CloseDB myCon
	end if
end function

function GetEraseInfo(myBizNo, myMode)
dim mySql
dim myRec
dim myCon
dim buf
	GetEraseInfo = ""
	if myBizNo = "" then exit function
	
	buf = " ����"
	if myMode then buf = " �x��"
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN AS F INNER JOIN TBL_CTM_BIZ AS B ON F.FIN_NO = B.BIZ_FIN_NO"
		mySql = mySql & " WHERE FIN_DELETED = 0 AND BIZ_DELETED = 0 AND FIN_ORIGINAL <> 0 AND BIZ_NO = '" & myBizNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then 
			GetEraseInfo = "(" & buf & "��" & GetString(.fields("FIN_NO")) & buf
			GetEraseInfo = GetEraseInfo & "��" & Str2Date(.fields("FIN_DATE")) & ")"
		end if
		.close
	end with
	set myRec = nothing	
	CloseDB myCon

end function

'�ďo��F 	ChargeHead.asp
function CheckAccountMonth()
dim mySql
dim myRec
dim myCon
	CheckAccountMonth = ""
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT AccountMonth FROM TBL_CTM_ACCOUNT WHERE Finished <> 0 ORDER BY AccountMonth DESC"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckAccountMonth = GetString(.fields("AccountMonth"))
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function



'�ďo��F 	CustomsUpdate.asp 	�ʊ֐ŋ��ۑ�����
'			CostsSave.asp 		�x���`�[�X�V�E�폜����
function CheckChargeConfirm(myCon, myCode, myNo)
dim mySql
dim myRec
	CheckChargeConfirm = false
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT JobCode FROM TBL_CTM_CHARGE WHERE Deleted = 0 AND ConfirmerID <> 0  AND ChargeNo IN ("
		mySql = mySql & "SELECT ExpenseBill FROM TBL_CTM_EXPENSE WHERE Deleted = 0 AND JobCode = '" & myCode & "'"
		mySql = mySql & " AND ExpenseType = " & gsStand & " AND ExpenseBill <> '' AND ExpensePay = '" & myNo & "')"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckChargeConfirm = true
		.close
	end with
	set myRec = nothing
end function

'�ďo��F 	CustomsUpdate.asp 	�ʊ֐ŋ��ۑ�����
function CheckCostsAmount(myCon, myCode, myNo)
dim mySql
dim myRec
	CheckCostsAmount = 0
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT CostsAmount+CostsTax AS TTL FROM TBL_CTM_COSTS WHERE Deleted = 0"
		mySql = mySql & " AND JobCode = '" & myCode & "' AND CostsNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckCostsAmount = GetLong(.fields("TTL"))
		.close
	end with
	set myRec = nothing
end function
%>