<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
		
dim PORT_CN

dim mode
dim myCode
dim myName
dim myNaccs

	PORT_CN = GetPost(request("cn"))

	mode = GetLong(request("mode"))
	myCode = GetPost(request("cd"))
	if myCode = "" then myCode = GetPost(request("nm"))
	if myCode = "" then myCode = GetPost(request("ncs"))
	selCode = replace(myCode, "'", "''")
	
	ShowAll = GetLong(request("ShowAll"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	PORT_CD = ""
	if myCode = gsDummy then 
		PORT_CD = gsDummy
		PORT_ENAME = "NULL"
	elseif myCode <> "" then
		with Recset	
			StrSql = "SELECT PORT_CD, PORT_ENAME, PORT_NACCS FROM MST_PORT WHERE PORT_DELETED = 0"
			StrSql = StrSql & " AND PORT_CN = '" & PORT_CN & "' AND (PORT_CD = '" & selCode & "' OR PORT_NACCS = '" & selCode & "')"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				PORT_CD = GetString(.fields("PORT_CD"))
				PORT_ENAME = GetString(.fields("PORT_ENAME"))
				PORT_NACCS = GetString(.fields("PORT_NACCS"))
			end if
			.close
		end with
	end if

	if PORT_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
<%if mode = 0 then %>
	if (window.opener.frmInput.POLCD !=null) window.opener.frmInput.POLCD.value = "<%=PORT_CD%>";
	if (window.opener.frmInput.POL !=null) window.opener.frmInput.POL.value = "<%=PORT_ENAME%>";
	if (window.opener.frmInput.POLN !=null) window.opener.frmInput.POLN.value = "<%=PORT_NACCS%>";
	if (window.opener.frmInput.PODCD !=null) window.opener.frmInput.PODCD.focus();
<%else %>
	if (window.opener.frmInput.PODCD !=null) window.opener.frmInput.PODCD.value = "<%=PORT_CD%>";
	if (window.opener.frmInput.POD !=null) window.opener.frmInput.POD.value = "<%=PORT_ENAME%>";
	if (window.opener.frmInput.PODN !=null) window.opener.frmInput.PODN.value = "<%=PORT_NACCS%>";
	if (window.opener.frmInput.Client !=null) window.opener.frmInput.Client.focus();
<%end if %>
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�`������</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "PortSearch.asp?mode=<%=mode%>&cn=<%=PORT_CN%>&cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("�`���R�[�h�܂��͍`�����̈ꕔ����͂��Ă��������B")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="PortSearch.asp" NAME=frmInput>
		<input type=hidden name="cn" value="<%=PORT_CN%>">
		<input type=hidden name="mode" value="<%=mode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD>�`������:<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=10 onkeydown="ResetEnter()">
					�S�\��<input type=checkbox name="ShowAll" value="1" onkeydown="ResetEnter()" <%if ShowAll then response.write " checked"%>>
				<TD><INPUT TYPE=button style="cursor:hand; width:60; height:25" VALUE="����" onclick="DoSearch()"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then 
			cnt = 0
			With Recset
				StrSql = "SELECT COUNT(PORT_CD) AS PORT_CNT FROM MST_PORT WHERE PORT_DELETED = 0 AND PORT_CN = '" & PORT_CN & "'"
				StrSql = StrSql & " AND (PORT_CD LIKE '%" & selCode & "%' OR PORT_ENAME LIKE '%" & selCode & "%' OR PORT_NAME LIKE '%" & selCode & "%')"
				if ShowAll = 0 then StrSql = StrSql & "  AND PORT_ACTIVE = 1"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if GetLong(.fields("PORT_CNT")) = 0 then
					response.write "<br>�Y���f�[�^��������܂���ł����B"
				elseif GetLong(.fields("PORT_CNT")) > 30 then
					response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
				else
					.close
					
					StrSql = "SELECT PORT_CD, PORT_ENAME, PORT_NAME, PORT_NACCS FROM MST_PORT WHERE PORT_DELETED = 0 AND PORT_CN = '" & PORT_CN & "'"
					StrSql = StrSql & " AND (PORT_CD LIKE '%" & selCode & "%' OR PORT_ENAME LIKE '%" & selCode & "%' OR PORT_NAME LIKE '%" & selCode & "%')"
					if ShowAll = 0 then StrSql = StrSql & "  AND PORT_ACTIVE = 1"
					strSQL = strSQL + " ORDER BY PORT_ENAME"
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>����
					<TD nowrap>�p������
					<TD nowrap>�a������
					<TD nowrap>NACCS
<%
						myCnt = 0
						myShortCut = ""
						Do Until .EOF	
							myCnt = myCnt + 1
							myCode = GetString(.Fields("PORT_CD"))	
							myEName = GetString(.Fields("PORT_ENAME"))	
							myJName = GetString(.Fields("PORT_NAME"))	
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("PORT_CD") & "');"
							if myCnt < 10 then myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("PORT_CD") & "');"
%>
				<TR ALIGN=center style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("PORT_CD")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("PORT_CD"))%><BR>
					<TD class=line nowrap ALIGN=left <%=ShowTitle(myEName, 12)%>><%=StringCut(myEName,12)%><BR>
					<TD class=line nowrap <%=ShowTitle(myJName, 6)%>><%=StringCut(myJName,6)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("PORT_NACCS"))%><BR>
<%
							.MoveNext
						Loop
					end if
%>
			</table>
<%
				end if
				.Close
			End With
			if cnt = 1 then
				response.write "<script language=javascript>clickLine('" & myCode & "');</script>"
			end if
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>