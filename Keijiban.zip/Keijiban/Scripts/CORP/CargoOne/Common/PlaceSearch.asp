<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
dim myCode

	mode = GetLong(request("mode"))
	myCode = GetPost(request("cd"))
	selCode = replace(myCode, "'", "''")
		
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	PLC_CD = ""
	if myCode <> "" then
		with Recset	
			StrSql = "SELECT PLC_CD, PLC_NAME, PLC_NACCS, PLC_TEL FROM MST_PLACE WHERE PLC_DELETED = 0"
			StrSql = StrSql & " AND (PLC_CD = '" & selCode & "' OR PLC_NACCS = '" & selCode & "')"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				PLC_CD = GetString(.fields("PLC_CD"))
				PLC_NAME = GetString(.fields("PLC_NAME")) & " (" & GetString(.fields("PLC_NACCS")) & ") " ' & GetString(.fields("PLC_TEL"))
			end if
			.close
		end with
	end if

	if PLC_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
<%select case mode
  case 1%>
	if (window.opener.frmInput.CarryPlace !=null) window.opener.frmInput.CarryPlace.value = "<%=PLC_NAME%>";
<%case 2%>
	if (window.opener.frmInput.ViaPlace !=null) window.opener.frmInput.ViaPlace.value = "<%=PLC_NAME%>";
<%end select%>
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>���u�ꏊ����</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "PlaceSearch.asp?mode=<%=mode%>&cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("�����R�[�h�܂��͑��u�ꏊ�̈ꕔ����͂��Ă��������B")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="PlaceSearch.asp" NAME=frmInput>
		<input type=hidden name="cn" value="<%=PLC_CN%>">
		<input type=hidden name="mode" value="<%=mode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD>���u�ꏊ:<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				<TD><INPUT TYPE=button style="cursor:hand; width:60; height:25" VALUE="����" onclick="DoSearch()"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then 
			cnt = 0
			With Recset
				StrSql = "SELECT COUNT(PLC_CD) AS PLC_CNT FROM MST_PLACE WHERE PLC_DELETED = 0"
				StrSql = StrSql & " AND (PLC_CD LIKE '%" & selCode & "%' OR PLC_NACCS LIKE '%" & selCode & "%' OR PLC_NAME LIKE '%" & selCode & "%')"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if GetLong(.fields("PLC_CNT")) = 0 then
					response.write "<br>�Y���f�[�^��������܂���ł����B"
				elseif GetLong(.fields("PLC_CNT")) > 30 then
					response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
				else
					.close
					
					StrSql = "SELECT PLC_CD, PLC_NAME, PLC_NACCS FROM MST_PLACE WHERE PLC_DELETED = 0"
					StrSql = StrSql & " AND (PLC_CD LIKE '%" & selCode & "%' OR PLC_NACCS LIKE '%" & selCode & "%' OR PLC_NAME LIKE '%" & selCode & "%')"
					strSQL = strSQL + " ORDER BY PLC_CD"
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>��������
					<TD nowrap>���u�ꏊ
					<TD nowrap>NACCS
<%
						myCnt = 0
						myShortCut = ""
						Do Until .EOF	
							myCnt = myCnt + 1
							myCode = GetString(.Fields("PLC_CD"))		
							myName = GetString(.Fields("PLC_NAME"))
							PLC_NACCS = GetString(.Fields("PLC_NACCS"))	
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("PLC_CD") & "');"
							if myCnt < 10 then myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("PLC_CD") & "');"
%>
				<TR ALIGN=center style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("PLC_CD")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("PLC_CD"))%><BR>
					<TD class=line nowrap ALIGN=left <%=ShowTitle(myName, 30)%>><%=StringCut(myName,30)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("PLC_NACCS"))%><BR>
<%
							.MoveNext
						Loop
					end if
%>
			</table>
<%
				end if
				.Close
			End With
			if cnt = 1 then
				response.write "<script language=javascript>clickLine('" & myCode & "');</script>"
			end if
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>