<%
	Private Const adOpenForwardOnly = 0
	Private Const adOpenKeyset = 1
	Private Const adOpenDynamic = 2
	Private Const adOpenStatic = 3
					
	Private Const adLockReadOnly = 1
	Private Const adLockPessimistic = 2
	Private Const adLockOptimistic = 3
	Private Const adLockBatchOptimistic = 4
		
	Private Const adCmdText = 1

	Private Const intConnectionTimeout = 60
	Private Const intCommandTimeout = 60
	
	Private Const lngCommandTimeout = -2147217865
	Private Const lngPageSize = 20
	
	'QueryTypeConstants
	Private Const GyoushaQueryByID = 0
	Private Const SyainMasterQueryByShopCodeSyainCode = 1
	Private Const SystemDefQueryAll = 2
	
	Function OpenSQL(Conn, strSQLServerName, strDBName)
	
'		On Error Resume Next
		
		Set Conn = Server.CreateObject ("ADODB.Connection")
		Conn.ConnectionTimeout = intConnectionTimeout
		Conn.CommandTimeout = intCommandTimeout
		
		Conn.Provider = "SQLOLEDB"
		Conn.Open "Data Source=" & strSQLServerName & ";Initial Catalog=" & strDBName, "sa","pass"
		
		If Err.number = 0 Then
			OpenSQL = True
		Else
			OpenSQL = False
		End If
		
	End Function

	Function OpenMDB(Conn)
	
'		On Error Resume Next
		
		Set Conn = Server.CreateObject ("ADODB.Connection")
		Conn.ConnectionTimeout = intConnectionTimeout
		Conn.CommandTimeout = intCommandTimeout
		
		Conn.Provider = "Microsoft.Jet.OLEDB.4.0"
		Conn.Open "Data Source=C:\�Ɩ��Ǘ�\CDATA.mdb"

		If Err.number = 0 Then
			OpenMDB = True
		Else
			OpenMDB = False
		End If
		
	End Function

	Function CloseDB(objDB)
		
		On Error Resume Next

		objDB.Close
		Set objDB = Nothing
		
		If Err.number = 0 Then
			CloseDB = True
		Else
			CloseDB = False
		End If

	End Function
	
	Function DBExecute(Conn, strSQL)

        Dim cmdCnt
		Dim cmdSQL

		'On Error Resume Next
	
		Set cmdSQL = Server.CreateObject ("ADODB.Command")
		cmdSQL.ActiveConnection = Conn
		cmdSQL.CommandType = adCmdText
		cmdSQL.CommandText = strSQL
		cmdSQL.CommandTimeout = intCommandTimeout
		
        cmdCnt = 0
        Do While cmdCnt < 3
            cmdSQL.Execute 
            If Err.Number <> lngCommandTimeout Then
                cmdCnt = 3
            Else
                cmdCnt = cmdCnt + 1
            End If
        Loop
		Set cmdSQL = Nothing
		
		If Err.number = 0 Then
			DBExecute = True
		Else
			DBExecute = False
		End If
		
	End Function
	
	Function DBExecute(Conn, strSQL)
        Dim cmdCnt
		Dim cmdSQL

		'On Error Resume Next
		
		Set cmdSQL = Server.CreateObject("ADODB.Command")
		Set cmdSQL.ActiveConnection = Conn
		cmdSQL.CommandType = 4
		cmdSQL.CommandText = strSQL
'		With cmdSQL
'			.Parameters.Refresh
'			.Parameters("@EntryMode").Value = Mode
'		End With
		
		DBExecute = CSQL.Execute			
		
	End Function	
%>
