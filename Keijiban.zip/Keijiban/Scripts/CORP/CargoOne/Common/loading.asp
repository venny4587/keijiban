<%
dim myURL
dim myParam

	myParam = "?Xtbh1=" & request("Xtbh1") & _
			  "&xtbh2=" & request("Xtbh2") & _
			  "&output=" & request("output") & _
			  "&printall=" & request("printall") & _
			  "&last=" & request("last") & _
			  "&xtbh=" & request("Xtbh")

	select case request("rptNo")
	case 1
		myURL = "ShowAgentTdqr.asp" & myParam
	case 2
		myURL = "ShowAgentList.asp" & myParam
	end select	
%>

<HTML>
<HEAD>
	<TITLE>Now Loading!!...</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		var m_lngCount = 0;
		function ShowTime() {
			m_lngCount++;
			spanCount.innerHTML = "Now Loading!!��<FONT COLOR=#FFFF00>" + m_lngCount + "</FONT>";
		}
	-->
	</SCRIPT>
</HEAD>

<BODY OnLoad="window.setInterval('ShowTime()', 1000);window.location.href='<%=myURL%>'" STYLE="cursor:wait">
<FONT SIZE=-1 FACE="MS UI GOTHIC">
<TABLE HEIGHT=100% WIDTH=100% BORDER=0>
	<TR><TD HEIGHT=40%>��</TD></TR>
	<TR>
		<TD ALIGN=CENTER HEIGHT=10% STYLE="filter:glow(color=0,strength=10">
		<FONT FACE="Impact" COLOR=#8080FF SIZE=+2><B><SPAN ID=spanCount NAME=spanCount>Now Loading!!</SPAN></B></FONT>       
		</TD>
	</TR>
	<TR>
		<TD ALIGN=CENTER HEIGHT=10% STYLE="filter:dropshadow(color=#000000,offx=1,offy=1"><MARQUEE><B><FONT COLOR=#E0E0E0>WAIT ...</FONT></B></MARQUEE></TD>       
	</TR>
	<TR><TD HEIGHT=40%>��</TD></TR>
	<TR><TD><SPAN ID=spanTime NAME=spanTime></SPAN></TD></TR>
</TABLE>
</FONT>
</BODY>
</HTML>