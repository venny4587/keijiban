<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%	
	strSql = ""
	mode = cstr(request("mode") & "")
	select case lcase(mode)
	case "picinfo"
	
		CTM_CD = GetString(request("CTM_CD"))
		PIC_ID = GetString(request("PIC_ID"))
		
		if instr(CTM_CD, " ") = 0 and instr(PIC_CD, " ") = 0 then
			strSql = strSql & "SELECT PIC_CELL, PIC_TEL, PIC_FAX"
			strSql = strSql & "  FROM CTM_PIC"
			strSql = strSql & " WHERE CTM_CD = '" & CTM_CD & "' AND PIC_ID = " & PIC_ID
		else
			strSql = strSql & "SELECT '' AS PIC_CELL, '' AS PIC_TEL, '' AS PIC_FAX"
		end if
		
	case "doorinfo"
	
		DOOR_ID = GetLong(request("DOOR_ID"))
		
		if instr(CTM_CD, " ") = 0 and DOOR_ID <> 0 then
			strSql = strSql & "SELECT DOOR_PIC, DOOR_TEL, DOOR_FAX, DOOR_ADDR1 + ' ' + DOOR_ADDR2 AS DOOR_ADDR, DOOR_REMARKS AS Remarks"
			strSql = strSql & "  FROM CTM_DOOR WHERE DOOR_ID = " & DOOR_ID
		else
			strSql = strSql & "SELECT '' AS DOOR_PIC, '' AS DOOR_TEL, '' AS DOOR_FAX, '' AS DOOR_ADDR"
		end if
		
	case "costinfo"
	
		COST_ID = GetLong(request("COST_ID"))
		
		if COST_ID <> 0 then
			strSql = strSql & "SELECT COST_TAX, COST_TYPE"
			strSql = strSql & "  FROM MST_COST"
			strSql = strSql & " WHERE COST_ID = " & COST_ID
		else
			strSql = strSql & "SELECT '' AS COST_TAX, '' AS COST_TYPE"
		end if
			
	end select
	
	if strSql = "" then
		response.end 
	else
		strXml = ""
		
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")	
		with Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				cnt = 0
				for each fld in .Fields	
					cnt = cnt + 1
					strXml = strXml & "<objname>" & fld.name & "</objname>"
					strXml = strXml & "<objvalue>" & GetString(fld.value) & "</objvalue>"
				next
			end if
			.close
		end with
		set Recset = nothing
		CloseDB Conn
		
		Response.Charset = "shift-jis" 
		Response.ContentType = "text/xml"
		Response.Write "<?xml version=""1.0"" encoding=""Shift_JIS""?>" 
		Response.Write "<response>" & strXml & "</response>" 
	end if
%>

