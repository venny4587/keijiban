<%Session("UserID_CORP") = "999"%>
<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	'�ʊ֗��֓`�[	�������捞�p
	
	myType = GetLong(request("type"))
	JobCode = GetPost(request("JobCode"))
	
	strXml = ""
	if myType <> 0 and JobCode <> "" then
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		
		ChargeNo = ""
		with Recset
			strSql = "SELECT ChargeNo, ReferNo FROM TBL_CTM_JOB AS J INNER JOIN TBL_CTM_CHARGE AS C ON J.JobCode = C.JobCode"
			strSql = strSql & " WHERE J.Deleted = 0 AND C.Deleted = 0 AND C.ConfirmerID <> 0 AND ChargeClient = '7013'"
			strSql = strSql & " AND J.JobCode = '" & FitSel(JobCode) & "'"
			if myType = gsStand then
				strSql = strSql & " AND ChargeType = " & gsStand
			else
				strSql = strSql & " AND ChargeType <> " & gsStand
			end if
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then 
				ReferNo = GetString(.fields("ReferNo"))
				ChargeNo = GetString(.fields("ChargeNo"))
			end if
			.Close
			
			if ChargeNo <> "" then
				strSql = "SELECT SeqNo, ExpenseType, ExpenseCost, COST_CD, COST_NAME, ExpenseMemo"
				strSql = strSql & ",ExpenseQuantity, ExpenseUnit, ExpensePrice, ExpenseAmount, ExpenseTax"
				strSql = strSql & " FROM TBL_CTM_EXPENSE E INNER JOIN MST_COST C ON E.ExpenseCost = C.COST_ID"
				strSql = strSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "' AND ExpenseBill = '" & ChargeNo & "'"
				strSql = strSql & " ORDER BY ExpenseType DESC, COST_CD, SeqNo"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof
					strXml = strXml & "<records>"
					strXml = strXml & "<ReferNo>" & ReferNo & "</ReferNo>"
					strXml = strXml & "<ChargeNo>" & ChargeNo & "</ChargeNo>"
					strXml = strXml & "<ExpenseCost>" & GetLong(.fields("ExpenseCost")) & "</ExpenseCost>"
					strXml = strXml & "<ExpenseName>" & replace(GetString(.fields("COST_NAME")), "&", "��") & "</ExpenseName>"
					strXml = strXml & "<ExpenseMemo>" & replace(GetString(.fields("ExpenseMemo")), "&", "��") & "</ExpenseMemo>"
					strXml = strXml & "<ExpenseTax>" & GetLong(.fields("ExpenseTax")) & "</ExpenseTax>"
					strXml = strXml & "<ExpenseUnit>" & GetString(.fields("ExpenseUnit")) & "</ExpenseUnit>"
					strXml = strXml & "<ExpenseUnit>" & ExpenseUnit & "</ExpenseUnit>"
					strXml = strXml & "<ExpensePrice>" & GetDouble(.fields("ExpensePrice")) & "</ExpensePrice>"
					strXml = strXml & "<ExpenseAmount>" & GetLong(.fields("ExpenseAmount")) & "</ExpenseAmount>"
					strXml = strXml & "<ExpenseQuantity>" & GetDouble(.fields("ExpenseQuantity")) & "</ExpenseQuantity>"
					strXml = strXml & "</records>"
					.Movenext
				loop
				.close
			end if
		end with
		set Recset = nothing
		CloseDB Conn
	end if
		
	Response.Charset = "shift-jis" 
	Response.ContentType = "text/xml"
	Response.Write "<?xml version=""1.0"" encoding=""Shift_JIS""?>" 
	Response.Write "<response>" & strXml & "</response>" 
%>

