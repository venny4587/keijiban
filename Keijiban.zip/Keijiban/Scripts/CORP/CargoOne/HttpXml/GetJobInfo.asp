<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%	
	strSql = ""
	mode = cstr(request("mode") & "")
	select case lcase(mode)
	case "jobmemo"
	
		JobCode = trim(cstr(request("JobCode") & ""))
		fldName = trim(cstr(request("txt") & ""))
		
		if instr(JobCode, " ") = 0 then
			strSql = strSql & "SELECT Remarks AS " & fldName
			strSql = strSql & "  FROM TBL_CTM_JOB"
			strSql = strSql & " WHERE JobCode = '" & JobCode & "'"
		end if
		
	case "jobinfo"
	
		JobCode = trim(cstr(request("JobCode") & ""))
		
		if instr(JobCode, " ") = 0 then
			strSql = strSql & "SELECT JobNo, EdaNo, Vessel, Voy, POL, POD, POLN, PODN,"
			strSql = strSql & " ETD, ETA, MBL, HBL, GW, CBM, RTON, Marks, Commodity,"
			strSql = strSql & " Quantity, Package, Container, InvoiceNo, ReferNo "
			strSql = strSql & "  FROM TBL_CTM_JOB WHERE JobCode = '" & JobCode & "'"
		end if
		
	end select
	
	if strSql = "" then
		response.end 
	else
		strXml = ""
		
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")	
		with Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				cnt = 0
				for each fld in .Fields	
					cnt = cnt + 1
					strXml = strXml & "<objname>" & fld.name & "</objname>"
					strXml = strXml & "<objvalue>" & fld.value & "</objvalue>"
				next
			end if
			.close
		end with
		set Recset = nothing
		CloseDB Conn
		
		Response.Charset = "shift-jis" 
		Response.ContentType = "text/xml"
		Response.Write "<?xml version=""1.0"" encoding=""Shift_JIS""?>" 
		Response.Write "<response>" & strXml & "</response>" 
	end if
%>

