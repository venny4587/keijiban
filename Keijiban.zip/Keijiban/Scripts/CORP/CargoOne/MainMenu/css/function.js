function DoAction(myAct) {
	frmInput.act.value = myAct;
	frmInput.submit();
}

function overbutton(btn) {
	btn.style.background = "#C0FFB0";
}

function outbutton(btn) {
	btn.style.background = "#F0F0F0";
}

function DoClickCheck(nm) {	
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='checkbox' && e.name==nm) {
      if (e.checked) {
        e.checked = false;	
      } else {
        e.checked = true;	
      }
    }
  }
}

function DoClickRadio(nm,va) {	
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='radio' && e.name==nm && e.value==va) {
      e.checked = true;	
    }
  }
}

function ClearAll(){
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='text')
        e.value = "";
    if (e.type=='checkbox')
        e.checked = false;
    if (e.type=='radio')
	if (e.value==0)
          e.checked = true;   
  }
}

function CheckAll(val){
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='checkbox')
        e.checked = val;
  }
}



function ResetEnter() {
	if (event.keyCode == 13) {
		window.event.keyCode = 9;
	}
}
