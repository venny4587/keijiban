<!-- #include file="../../common/common.asp" -->
<!-- #include file="../../Cashier/Cashier.asp" -->
<%
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
%>
<html>
	<head>
		<Title>SOKO MENU</Title>
		<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<link rel="stylesheet" href="../css/style.css" type="text/css">	
		<style type="text/css">
			.pt13 { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 13pt; LINE-HEIGHT: 14pt }
		</style>
		<script language=javascript>
		
		function SetMenu(no) {
			var url = "";
			switch (no) {
				case 0: {
					url = "../../Billboard/main.asp";
					break;
				}
				case 1: {
					url = "../../Cashier/CashierInput.asp";
					break;
				}
				case 2: {
					url = "../../Cashier/CashierDetail.asp";
					break;
				}
				case 3: {
					url = "../../Cashier/CashierView.asp";
					break;
				}
				case 4: {
					url = "../../Cashier/CashierMain.asp";
					break;
				}
				case 5: {
					url = "../../baseinfo/mstCategory.asp?CTGR_BASE=12"
					break;
				}
				case 6: {
					url = "../../baseinfo/mstCategory.asp?CTGR_BASE=13"
					break;
				}
				case 7: {
					url = "../../baseinfo/mstCategory.asp?CTGR_BASE=11"
					break;
				}
				case 8: {
					url = "../../baseinfo/mstCategory.asp?CTGR_BASE=10"
					break;
				}
				default: {
					alert("�H�����ł��B");
					url = "blank.html";
				}
			}
			parent.main.location.href = url;
		}
		</script>
		
		
	</head>
	<body topmargin="0" marginheight="0" rightmargin="0" leftmargin="0" marginwidth="0">	
		<table border="0" cellpadding="0" cellspacing="0" height="100%" bgcolor="LightGreen">
				<TR height="38">
					<TD width="120" height="70" bgcolor="#003300" align=center class=pt13>
						<FONT COLOR="#ffffff">�Г���p<BR>��v�`�[</FONT>
				</TR>
				<TR height="80%">
					<TD valign="top">
						<table width="121" border="0" cellspacing="0" cellpadding="1" bgcolor="LightGreen">
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(1)"><TD align="middle" width=40%><IMG SRC="../img/ico/regist.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�Г��o��`�[�̐V�K�o�^">�o��`�[</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
<%if myCashier > 0 then%>
							<TR><A href="javascript:SetMenu(2)"><TD align="middle" width=40%><IMG SRC="../img/ico/winrar.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�Г���v�`�[�̐V�K�o�^">��v�`�[</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
<%end if%>
							<TR><A href="javascript:SetMenu(3)"><TD align="middle" width=40%><IMG SRC="../img/ico/report.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�Г���v�`�[�̈ꗗ�Ɖ�">�`�[�Ɖ�</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
<%if myLevel > 0 or myCashier > 0 then%>
							<TR><A href="javascript:SetMenu(4)"><TD align="middle" width=40%><IMG SRC="../img/Excel.gif"></TD><TD height="20" align="middle" style="CURSOR: hand" title="��v�`�[�̏W�v���|�[�g">��v�W�v</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
							<TR><A href="javascript:SetMenu(5)"><TD align="middle" width=40%><IMG SRC="../img/ico/mess.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="��v�`�[�̎x����ꗗ">�x���於</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
							<TR><A href="javascript:SetMenu(6)"><TD align="middle" width=40%><IMG SRC="../img/ico/pwd.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="��v�`�[�̓E�v�ꗗ">�E�v�ꗗ</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
<%end if%>
<%if myLevel > 2 or myCashier > 1 then%>
							<TR><A href="javascript:SetMenu(7)"><TD align="middle" width=40%><IMG SRC="../img/ico/lhaz2.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="��v�`�[�̊e����Ǘ�">��v����</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
							<TR><A href="javascript:SetMenu(8)"><TD align="middle" width=40%><IMG SRC="../img/Help.gif"></TD><TD height="20" align="middle" style="CURSOR: hand" title="��v�`�[�̊e�ȖڊǗ�">��v�Ȗ�</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
<%end if%>
						</table>
					</TD>
				</TR>
				<TR><TD>
					<TABLE width="121" border="0" cellspacing="0" cellpadding="1" bgcolor="DarkGreen">
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
						<TR><A href="" onclick="window.parent.close()"><TD align="middle" width=40%><IMG SRC="../img/ico/eudora.ico"></TD><TD height="40" align="middle" style="CURSOR: hand; color:white" title="�ʊ֋Ɩ�������ʂ����">�����I��</TD></A></TR>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
					</TABLE>
				</TD></TR>
			<TR height="70">
				<TD width="120" bgcolor="#003300" align=center>
					<FONT COLOR="#ffffff">Copyright &copy; 2006<br>SOKO Warehouse Co., Ltd.</FONT></TD>
			</TR>
		</table>
	</body>
</html>


