<!-- #include file="../../common/common.asp" -->
<%
	select case WebUserID
	case 1
		myLevel = 5
	case 2
		myLevel = 4
	case 3
		myLevel = 3
	case else
		myLevel = 0
	end select
%>
<html>
	<head>
		<Title>SOKO MENU</Title>
		<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<link rel="stylesheet" href="../css/style.css" type="text/css">	
		<style type="text/css">
			.pt13 { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 13pt; LINE-HEIGHT: 14pt }
		</style>
		<script language=javascript>
		
		function SetMenu(no) {
		  var url1 = "";
		  var url2 = "";
		  var mode = "0";
		  var frm = document.frmInput;
		  for (var i=0;i<frm.elements.length;i++){
		    var e = frm.elements[i];
		    if (e.type=="radio" && e.name=="mode") {
		      if (e.checked) mode = e.value;	
		    }
		  }
		  if (mode=="0") {
		  	url1 = "http://127.0.0.1/";
		  	url2 = "http://127.0.0.1/CORP/CargoOne/Customs/";
		  } else {
		  	url1 = "http://127.0.0.1/";
		  	url2 = "http://127.0.0.1/CORP/CargoOne/Customs/";
		  }
			  
			switch (no) {
				case 0: {
					url = url2 + "SokoNew.asp";
					break;
				}
				case 1: {
					url = url1 + "ImportDaily.asp";
					break;
				}
				case 2: {
					url = url1 + "ExportDaily.asp";
					break;
				}
				case 3: {
					url = url1 + "StockView.asp";
					break;
				}
				case 4: {
					url = url2 + "SokoView.asp";
					break;
				}
				case 5: {
					url = url2 + "SokoList.asp";
					break;
				}
				case 6: {
					url = url1 + "Stock/StockFrame.asp";
					break;
				}
				default: {
					alert("�H�����ł��B");
					alert(no);
					url = "blank.html";
				}
			}
			parent.main.location.href = url;
		}
		</script>
		
		
	</head>
	<body topmargin="0" marginheight="0" rightmargin="0" leftmargin="0" marginwidth="0"
		  OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
	  <form name=frmInput>	
		<table border="0" cellpadding="0" cellspacing="0" height="100%" bgcolor=LightBlue>
				<TR height="38">
					<TD width="120" height="70" bgcolor=MediumBlue align=center class=pt13>
						<FONT COLOR="#ffffff">�ېőq�ɂ�<BR>�悤�����I</FONT>
				</TR>
				<TR height="80%">
					<TD valign="top">
						<table width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=LightBlue>					
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><TD colspan=2><input type=radio name="mode" value="0" checked>�n�c�m�@<input type=radio name="mode" value="1">�v�d�a
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
							<TR><A href="javascript:SetMenu(1)"><TD align="middle" width=40%><IMG SRC="../img/ico/regist.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="���ɓ�����̏Ɖ�">���ɓ���</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(2)"><TD align="middle" width=40%><IMG SRC="../img/ico/house.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�o�ɖ��׏��̏Ɖ�">�o�ɓ���</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(3)"><TD align="middle" width=40%><IMG SRC="../img/ico/sakura.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�݌ɖ��׏��̌���">�݌ɏƉ�</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
<%if myLevel > 2 then%>
							<TR><A href="javascript:SetMenu(6)"><TD align="middle" width=40%><IMG SRC="../img/new/sea.png"></TD><TD height="20" align="middle" style="CURSOR: hand" title="CORP�Ɩ����̎捞">CORP�捞</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
<%end if%>
<%if UserShop = gsSokoInit or myLevel > 3 then%>
							<TR><A href="javascript:SetMenu(4)"><TD align="middle" width=40%><IMG SRC="../img/Application.gif"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ېŎГ������̏���">�Г�����</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
							<TR><A href="javascript:SetMenu(0)"><TD align="middle" width=40%><IMG SRC="../img/ico/terapad.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ېő䒠�ԍ��̔��s">�V�K�o�^</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
							<TR><A href="javascript:SetMenu(5)"><TD align="middle" width=40%><IMG SRC="../img/ico/report.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ېŎЊO�����̏���">�ЊO����</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
<%end if%>
						</table>
					</TD>
				</TR>
				<TR><TD>
					<TABLE width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=RoyalBlue>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
						<TR><A href="" onclick="window.parent.close()"><TD align="middle" width=40%><IMG SRC="../img/ico/eudora.ico"></TD><TD height="40" align="middle" style="CURSOR: hand" title="�ېŋƖ�������ʂ����"><FONT COLOR="#ffffff">�����I��</FONT></TD></A></TR>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
					</TABLE>
				</TD></TR>
			<TR height="70">
				<TD width="120" bgcolor=MediumBlue align=center>
					<FONT COLOR="#ffffff">Copyright &copy; 2006<br>SOKO Warehouse Co., Ltd.</FONT></TD>
			</TR>
		</table>
	  </form>
	</body>
</html>


