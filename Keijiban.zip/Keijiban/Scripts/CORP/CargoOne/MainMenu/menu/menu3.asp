<!-- #include file="../../common/common.asp" -->
<html>
	<head>
		<Title>SOKO MENU</Title>
		<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<link rel="stylesheet" href="../css/style.css" type="text/css">	
		<style type="text/css">
			.pt13 { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 13pt; LINE-HEIGHT: 14pt }
		</style>
		<script language=javascript>
		
		function SetMenu(no) {
			var url = "../../";
			switch (no) {
				case 0: {
					url = "../../Billboard/main.asp";
					break;
				}
				case 1: {
					url = "../../Customs/mainframe.asp";
					break;
				}
				case 2: {
					url = "../../Customs/CustomsFrame.asp";
					break;
				}
				case 3: {
					url = "../../Customs/CostsFrame.asp";
					break;
				}
				case 4: {
					url = "../../Customs/ChargeFrame.asp";
					break;
				}
				case 5: {
					url = "../../Customs/CloseFrame.asp";
					break;
				}
				case 6: {
					url = "../../Customs/DocumentFrame.asp";
					break;
				}
				case 7: {
					url = "../../Customs/ReportFrame.asp";
					break;
				}
				case 9: {
					url = "../../Customs/ToolFrame.asp";
					break;
				}
				default: {
					alert("�H�����ł��B");
					url = "../../blank.html";
				}
			}
			parent.main.location.href = url;
			//window.parent.document.all("switchPoint").innerText=4;
			//window.parent.document.all("frmTitle").style.display="none";
		}
		</script>
		
		
	</head>
	<body topmargin="0" marginheight="0" rightmargin="0" leftmargin="0" marginwidth="0"
		  OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>	
		<table border="0" cellpadding="0" cellspacing="0" height="100%" bgcolor=#FFF0F0>
				<TR height="38">
					<TD width="120" height="70" bgcolor=Crimson align=center class=pt13>
						<FONT COLOR="#ffffff">�ېőq��<br>�ʊ֋Ɩ�</FONT>
				</TR>
				<TR height="80%">
					<TD valign="top">
						<table width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=#FFF0F0>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(1)"><TD align="middle" width=40%><IMG SRC="../img/ico/regist.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̐V�K�o�^����">�Ɩ��o�^</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(2)"><TD align="middle" width=40%><IMG SRC="../img/Application.gif"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̖��׏�񏈗�">�Ɩ�����</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(3)"><TD align="middle" width=40%><IMG SRC="../img/ico/chart.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̎x����p����������">�x������</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(4)"><TD align="middle" width=40%><IMG SRC="../img/ico/report.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̐��������m�肷��">��������</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(5)"><TD align="middle" width=40%><IMG SRC="../img/new/lock.gif"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̃o�����X���m�肷��">��������</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(6)"><TD align="middle" width=40%><IMG SRC="../img/ico/winrar.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̊e���ނ��Ǘ�����">���ފǗ�</TD></A></TR>
<%if CheckTopLevel() > 0 or CheckUserLevel(UserShop, "") > 1 then%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>
							<TR><A href="javascript:SetMenu(7)"><TD align="middle" width=40%><IMG SRC="../img/new/view.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̊e�W�v�\���Ɖ��">�Ɩ����\</TD></A></TR>
<%end if%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(9)"><TD align="middle" width=40%><IMG SRC="../img/HardMente.gif"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�ʊ֋Ɩ��̕⏕�c�[�����Ǘ�����">�⏕�c�[��</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
						</table>
					</TD>
				</TR>
				<TR><TD>
					<TABLE width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=#FF6666>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
						<TR><A href="" onclick="window.parent.close()"><TD align="middle" width=40%><IMG SRC="../img/ico/eudora.ico"></TD><TD height="40" align="middle" style="CURSOR: hand; color:white" title="�ʊ֋Ɩ�������ʂ����">�����I��</TD></A></TR>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
					</TABLE>
				</TD></TR>
			<TR height="70">
				<TD width="120" bgcolor=Crimson align=center>
					<FONT COLOR="#ffffff">Copyright &copy; 2006<br>SOKO<br>WAREHOUSE Co., Ltd.</FONT></TD>
			</TR>
		</table>
	</body>
</html>


