<%
myCheck = 1
select case  session("WebUserID")
case 36, 88
    myCheck = 0
end select
%>
<html>
	<head>
		<Title>FINANCE MENU</Title>
		<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<link rel="stylesheet" href="../css/style.css" type="text/css">	
		<style type="text/css">
			.pt13 { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 13pt; LINE-HEIGHT: 14pt }
		</style>
		<script language=javascript>
		
		function SetMenu(no) {
			var url = "../../";
			switch (no) {
				case 0: {
					url = "../../Billboard/main.asp";
					break;
				}
				case 1: {
					url = "../../Account/ReceiveFrame.asp";
					break;
				}
				case 2: {
					url = "../../Account/PaymentFrame.asp";
					break;
				}
				case 3: {
					url = "../../Account/TransferFrame.asp";
					break;
				}
				case 4: {
					url = "../../Account/AccountMain.asp";
					break;
				}
				case 5: {
					url = "../../Account/CloseMain.asp";
					break;
				}
				case 6: {
					url = "../../Account/ReportFrame.asp";
					break;
				}
				default: {
					alert("�H�����ł��B");
					url = "../../blank.html";
				}
			}
			parent.main.location.href = url;
			//window.parent.document.all("switchPoint").innerText=4;
			//window.parent.document.all("frmTitle").style.display="none";
		}
		</script>
		
		
	</head>
	<body topmargin="0" marginheight="0" rightmargin="0" leftmargin="0" marginwidth="0"
		  OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>	
		<table border="0" cellpadding="0" cellspacing="0" height="100%">
				<TR height="38">
					<TD width="120" height="70" bgcolor=#330066 align=center class=pt13>
						<FONT COLOR="#ffffff">�ېőq��<br>�o���Ɩ�</FONT>
				</TR>
				<TR height="80%">
					<TD valign="top">
						<table width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=white>
<%if myCheck = 0 then%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(2)"><TD align="middle" width=40%><IMG SRC="../img/new/payment.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�o���`�[�̍쐬�E��������">�o������</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
<%else%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(1)"><TD align="middle" width=40%><IMG SRC="../img/new/recieve.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�����`�[�̍쐬�E��������">��������</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(2)"><TD align="middle" width=40%><IMG SRC="../img/new/payment.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�o���`�[�̍쐬�E��������">�o������</TD></A></TR>
<!--
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(3)"><TD align="middle" width=40%><IMG SRC="../img/new/alter.gif"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�U�֓`�[�̍쐬�E�m�菈��">�U�֏���</TD></A></TR>
-->
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(4)"><TD align="middle" width=40%><IMG SRC="../img/new/report.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="���茳���̏Ɖ�E�o�͏���">���茳��</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
							<TR><A href="javascript:SetMenu(5)"><TD align="middle" width=40%><IMG SRC="../img/new/Unlock.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="��v���x���̒��ߏ���">��������</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
<!--
							<TR><A href="javascript:SetMenu(6)"><TD align="middle" width=40%><IMG SRC="../img/new/view.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�c���E���ׁE�W�v���|�[�g">�������\</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>						
-->
<%end if%>
						</table>
					</TD>
				</TR>
				<TR><TD>
					<TABLE width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=#6633FF>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
						<TR><A href="" onclick="window.parent.close()"><TD align="middle" width=40%><IMG SRC="../img/ico/eudora.ico"></TD><TD height="40" align="middle" style="CURSOR: hand; color:white" title="�o���Ɩ�������ʂ����">�����I��</TD></A></TR>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
					</TABLE>
				</TD></TR>
			<TR height="70">
				<TD width="120" bgcolor=#330066 align=center>
					<FONT COLOR="#ffffff">Copyright &copy; 2006<br>SOKO<br>WAREHOUSE Co., Ltd.</FONT></TD>
			</TR>
		</table>
	</body>
</html>


