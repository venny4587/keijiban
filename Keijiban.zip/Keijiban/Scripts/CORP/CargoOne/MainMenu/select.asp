<!-- #include file="common/dbconst.asp" -->
<!-- #include file="common/sessionget.asp" -->
<!-- #include file="common/function.asp" -->
<%
	dim myMode
	myMode = trim(cstr("" & Request("Mode")))
	if myMode = "1" then
		strSql = GetString(cstr("" & Request("strSql")))
		
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		opensql conn, Session("GAP_ServerName"), Session("GAP_DBName")
	end if
%>
<html>
<head>
<META http-equiv="Content-Type" content="text/html; charset=shift-jis">
<TITLE>EBE</TITLE>
	<script language=vbscript>
	<!--
	sub doSearch()
		frmInput.Mode.value = 1
		frmInput.submit()
	end sub

	sub clearPage()
		window.location.href = "select.asp"
	end sub
	'-->
	</script>
</HEAD>
<BODY>

<table width="100%" border="0" cellpadding=0 cellspacing=0>
  <tr>
    <td valign="top">
      <form name="frmInput" method="post" action="select.asp">
         <table width="850" BORDER=1 BGCOLOR="<%=bgColor_Common%>" bordercolorlight=<%=bColorLight%> bordercolordark=<%=bColorDark%> CELLPADDING=2 CELLSPACING=0 STYLE="font-family:'Arial';font-size:12px">
          <tr bgcolor="<%=bgColor_Title%>" align="center">
            <td align="left"><textarea NAME="strSql" style="width:600px;height:30px"><%=strSql%></textarea></td>
            <td align=right>
				<input name="storeInSel" type=button onclick="doSearch()" style="width:80px;height:25px;" value="go">
				<input name="storeInRes" type=button onclick="clearPage()" style="width:80px;height:25px;"  value="clear"></td>
		  </tr>
		  <input type=hidden name="Mode" value='<%=myMode%>'>

		</table>
	  </form>
<%
if myMode = "1" then
	Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
	if not recset.EOF then
	%>
	 <table BORDER=1 BGCOLOR="<%=bgColor_Common%>" bordercolorlight=<%=bColorLight%> bordercolordark=<%=bColorDark%> CELLPADDING=2 CELLSPACING=0 STYLE="font-family:'Arial';font-size:12px">
		<tr bgcolor="<%=bgColor_Title%>" align="center">	
<%	for each fld in Recset.Fields	
		cnt = cnt + 1%>				
			<TD nowrap><%=fld.name%></TD>
<%	next%>
		</TR>
<%		Do Until recset.EOF %>		
		<TR>		
<%	for i = 0 to cnt-1%>
			<TD nowrap><%=recset.Fields(i)%><br></TD>
<%	next%>
		</TR>
<%
			recset.MoveNext
		Loop
%>				
	</TABLE>
<%					
	else
		Response.Write "<br><div align=center>no record</div>"	
	end if
	recset.Close 
end if
%>
    </td>
  </tr>
</table>

</BODY>
</HTML>
<%
if myMode = "1" then
	Set Recset = Nothing
	CloseDB Conn
end if
%>
