<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
dim mySql
dim myRec
dim myCon

	mode = GetLong(request("mode"))
	code = GetPost(request("code"))
	if len(code) < 8 or right(code, 3) <> Date2Code(date) then 
		WebUserID = 0
	else
		WebUserID = GetLong(mid(code, 6, len(code)-8))
	end if

	OpenSQL myCon, "localhost", "WebMaster"
	set myRec = Server.CreateObject ("ADODB.Recordset")	
	with myRec
		mySql = "SELECT MstWebUser.*, ShopCode FROM MstWebUser INNER JOIN MstShop ON MstWebUser.ShopID = MstShop.ShopID"
		mySql = mySql & " WHERE WebUserID = " & WebUserID 
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if .eof then 
			mode = 0
		else
			session("WebUserID") = WebUserID 
			session("ShopCode") = GetString(.Fields("ShopCode"))
			Session("UserID_CORP") = GetString(.Fields("UserID"))
			Session("UserName") = GetString(.Fields("UserName"))
			Session("ShopID") = GetLong(.Fields("ShopID"))
			Session("ShopGroupID") = GetLong(.Fields("ShopGroupID"))
			Session("SecurityLevel") = GetLong(.Fields("SecurityLevel"))
			
			Session("Depart") = GetString(.Fields("Depart"))
			Session("FamilyName") = GetString(.Fields("FamilyName"))
			Session("EnglishName") = GetString(.Fields("EnglishName"))
			Session("NickName") = GetString(.Fields("NickName"))
			Session("User_Email") = GetString(.Fields("Email"))
			Session("User_TEL") = GetString(.Fields("TEL"))
			Session("User_FAX") = GetString(.Fields("FAX"))
			Session("User_MSN") = GetString(.Fields("MSN"))
			Session("User_CellNo") = GetString(.Fields("Cell"))
			Session("User_Kmail") = GetString(.Fields("Kmail"))
		end if
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
	
	if WebUserID = 16 then			'�y��
		Session("ShopID") = 5
	end if
	
	select case mode 
	case 1				'�Ɩ�
		title = "�q�ɒʊփV�X�e���ւ悤����"
		url_l = "menu/menu3.asp"
		url_r = "../common/blank.htm"
	case 2				'�o��
		title = "�q�Ɍo���V�X�e���ւ悤����"
		url_l = "menu/menu8.asp"
		url_r = "../common/blank.htm"
	case 3				'�ې�
		title = "�q�ɕېŃV�X�e���ւ悤����"
		url_l = "menu/menu5.asp"
		url_r = "../Customs/SokoView.asp"
	case 4				'�o��
		title = "�q�Ɍo��V�X�e���ւ悤����"
		url_l = "menu/menu9.asp"
		url_r = "../Cashier/CashierView.asp"
	case else
		title = "�f���V�X�e���ւ悤����"
		response.write "�Y���y�[�W�̓A�N�Z�X�s�ł��B"
		response.end
	end select
%>
<HTML>
<HEAD>
<TITLE><%=title%></TITLE>
<SCRIPT type="text/javascript">
var spoint = 3;
if (spoint==4){
	document.all("switchPoint").innerText=4;
	document.all("frmTitle").style.display="none";
}
function switchSysBar(){
	if (document.all("switchPoint").innerText==3){
		document.all("switchPoint").innerText=4;
		document.all("frmTitle").style.display="none";
	}else{
		document.all("switchPoint").innerText=3;
		document.all("frmTitle").style.display="";
	}
}
</SCRIPT>
<STYLE type=text/css>
	.navPoint {COLOR: FF0000; CURSOR: hand; FONT-FAMILY: Webdings; FONT-SIZE: 9pt}
</STYLE>
</head>
<BODY scroll='no' style="MARGIN: 0px" id='all'  oncontextmenu="return false">
	<TABLE border='0' cellPadding='0' cellSpacing='0' height="100%" width="100%">
		<TBODY>
		<TR>
			<TD height="100%" align='middle' vAlign=center noWrap id=frmTitle name="frmTitle">
				<IFRAME frameBorder='0' id='menu' name='menu' scrolling='no' src="<%=url_l%>" style="HEIGHT: 100%; VISIBILITY: inherit; WIDTH: 120px; Z-INDEX: 2"></IFRAME>
			</TD>
			<TD class="T2"  style="WIDTH: 9pt">
				<TABLE border='0' cellPadding='0' cellSpacing='0' height="100%">
				<TBODY>
				<tr>
					<TD onclick='switchSysBar()' style="HEIGHT: 100%;background-color: #FFF7DC;"><SPAN class='navPoint' id='switchPoint'>3</SPAN>
					</td></tr>
				</TBODY>
				</TABLE>
			</TD>
	
			<TD style="WIDTH: 100%"><IFRAME frameBorder='0' id='main' name='main' scrolling='auto' src="<%=url_r%>" style="HEIGHT: 100%; VISIBILITY: inherit; WIDTH: 100%; Z-INDEX: 1"></IFRAME>
			</TD>
		</TR>
	</TBODY>
	</TABLE>
</body>
</html>
<%
Function GetString(myData)
on error resume next
	GetString = trim(cstr(myData & ""))
End Function

Function GetLong(myData)
on error resume next
	GetLong = 0
	if isnumeric(myData) then GetLong = clng(myData)
End Function
%>