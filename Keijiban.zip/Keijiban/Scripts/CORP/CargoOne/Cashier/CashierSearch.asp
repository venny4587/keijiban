<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'on error resume next
dim myCode

	mode = GetPost(request("mode"))
	select case mode
	case "12"
		myTitle = "�x����"
	case "13"
		myTitle = "�E�v"
	end select
	
	myCode = GetPost(request("cd"))
	selCode = replace(myCode, "'", "''")
		
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	CTGR_CD = ""
	if myCode <> "" then
		with Recset	
			StrSql = "SELECT CTGR_CD, CTGR_NAME FROM MST_CATEGORY WHERE CTGR_DELETED = 0 AND CTGR_BASE = '" & mode & "'"
			StrSql = StrSql & " AND (CTGR_CD = '" & selCode & "' OR CTGR_NAME LIKE '%" & selCode & "%')"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				CTGR_CD = GetString(.fields("CTGR_CD"))
				CTGR_NAME = GetString(.fields("CTGR_NAME"))
				.movenext
			end if
			if not .eof then CTGR_CD = ""
			.close
		end with
	end if

	if CTGR_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
<%select case mode
  case "12"%>
	if (window.opener.frmInput.CashPayTo !=null) window.opener.frmInput.CashPayTo.value = "<%=CTGR_NAME%>";
<%case "13"%>
	if (window.opener.frmInput.Description !=null) window.opener.frmInput.Description.value = "<%=CTGR_NAME%>";
<%end select%>
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE><%=myTitle%>���͕⏕����</TITLE>		
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "CashierSearch.asp?mode=<%=mode%>&cd=" + cd;
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="CashierSearch.asp" NAME=frmInput>
		<input type=hidden name="cn" value="<%=PLC_CN%>">
		<input type=hidden name="mode" value="<%=mode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD><%=myTitle%>����:<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				<TD><INPUT TYPE=submit style="cursor:hand; width:60; height:25" VALUE="����"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		cnt = 0
		With Recset
			StrSql = "SELECT COUNT(CTGR_CD) AS CTGR_CNT FROM MST_CATEGORY WHERE CTGR_DELETED = 0 AND CTGR_BASE = '" & mode & "'"
			if selCode <> "" then StrSql = StrSql & " AND (CTGR_CD LIKE '%" & selCode & "%' OR CTGR_NAME LIKE '%" & selCode & "%')"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if GetLong(.fields("CTGR_CNT")) = 0 then
				response.write "<br>�Y���f�[�^��������܂���ł����B"
			elseif GetLong(.fields("CTGR_CNT")) > 30 then
				response.write "<br>�Y���f�[�^��30���ȏ�z���܂����B"
			else
				.close
				
				StrSql = "SELECT CTGR_CD, CTGR_NAME FROM MST_CATEGORY WHERE CTGR_DELETED = 0 AND CTGR_BASE = '" & mode & "'"
				if selCode <> "" then StrSql = StrSql & " AND (CTGR_CD LIKE '%" & selCode & "%' OR CTGR_NAME LIKE '%" & selCode & "%')"
				strSQL = strSQL + " ORDER BY CTGR_CD"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap><%=myTitle%>����
					<TD nowrap><%=myTitle%>����
<%
					myCnt = 0
					myShortCut = ""
					Do Until .EOF	
						myCnt = myCnt + 1
						myCode = GetString(.Fields("CTGR_CD"))
						myName = GetString(.Fields("CTGR_NAME"))
						myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("CTGR_CD") & "');"
						if myCnt < 10 then
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("CTGR_CD") & "');"
						end if		
%>
				<TR ALIGN=center style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("CTGR_CD")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=GetString(.Fields("CTGR_CD"))%><BR>
					<TD class=line nowrap ALIGN=left <%=ShowTitle(myName, 30)%>><%=StringCut(myName,30)%><BR>
<%
						.MoveNext
					Loop
				end if
%>
			</table>
<%
			end if
			.Close
		End With
		if cnt = 1 then
			response.write "<script language=javascript>clickLine('" & myCode & "');</script>"
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>