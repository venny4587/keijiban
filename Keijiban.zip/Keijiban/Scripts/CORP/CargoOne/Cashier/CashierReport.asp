<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'on error resume next

dim myMode
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		CashDepart = GetDepartCode()
		DateTo = GetMonthLastDay(date)
		DateFrom = dateadd("m", -1, dateadd("d", 1, DateTo))
	else
		CashDepart = GetPost(request("CashDepart"))
		CashAccount = GetPost(request("CashAccount"))
		DateFrom = GetDate(request("DateFrom"))
		DateTo = GetDate(request("DateTo"))
		CashPayTo = GetPost(request("CashPayTo"))
	end if

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>��v�`�[�Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CashierReport.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
<%if myCashier > 1 or myLevel > 2 then%>
				�������� <SELECT name="CashDepart" onkeydown="ResetEnter()"><option value="">�S��<%=ShowDepartList(CashDepart)%></select>&nbsp;
<%else%>
	<%if UserShop = "K" then%>
				�������� <select name="CashDepart" OnKeyDown="ResetEnter()">
						<option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o
						<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
						<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
						<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
					</select>
	<%else%>
				�������� <font class=pt9g><%=Code2Depart(CashDepart)%></font><input type=hidden name="CashDepart" value="<%=CashDepart%>">
	<%end if%>
<%end if%>
				����Ȗ� <SELECT name="CashAccount" onkeydown="ResetEnter()"><option value="">�S��<%=ShowCategory("CashAccount", CashAccount, (myCashier=0 and myLevel < 2))%></select>&nbsp;
				���Z��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�x����<input class=sj name="CashPayTo" value="<%=CashPayTo%>" maxlength=20 size=16 onkeydown="ResetEnter()">
				<INPUT class=pt9n style="width:60px;height:25px;" TYPE=SUBMIT name=btnSearch VALUE="����">
				<INPUT class=pt9n style="width:60px;height:25px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		
		strSel = ""
		if CashDepart <> "" then strSel = strSel & " AND (CashDepart = '" & CashDepart & "' OR CreditDepart = '" & CashDepart & "')" 
		if CashAccount <> "" then	strSel = strSel & " AND (CashDebit = '" & CashAccount & "' OR CashCredit = '" & CashAccount & "')"
		if DateFrom <> "" then strSel = strSel & " AND CashDate >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND CashDate <= '" & Date2Str(DateTo) & "'"
		if CashPayTo <> "" then strSel = strSel & " AND CashPayTo LIKE '%" & CashPayTo & "%'"
		
		strSQL = "SELECT CashNo, CashDate, CashAmount, CashTax, CashPayTo, Description"
		strSQL = strSQL & ", CashDepart, Debit, CashDebit, CreditDepart, Credit, CashCredit"
		strSQL = strSQL & " FROM TBL_CORP_CASHIER AS C INNER JOIN (SELECT CTGR_CD, CTGR_NAME AS Debit "
		strSQL = strSQL & " FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS A ON C.CashDebit = A.CTGR_CD LEFT JOIN"
		strSQL = strSQL & " (SELECT CTGR_CD, CTGR_NAME AS Credit FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS B"
		strSQL = strSQL & " ON C.CashCredit = B.CTGR_CD WHERE Deleted = 0 AND CashPayer <> '' " & strSel
		strSQL = strSQL & " ORDER BY CashDate, CashNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
<div id=list>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=4 align=center>
			<colgroup span=2 align=left>
			<colgroup align=center>
			<colgroup span=2 align=right>
			<colgroup span=2 align=left>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap>���Z��
			<TD nowrap>�`�[�ԍ�
			<TD nowrap>�ؕ�����
			<TD nowrap>�ؕ��Ȗ�
			<TD nowrap>�ݕ��Ȗ�
			<TD nowrap>�ݕ�����
			<TD nowrap>�ō����z
			<TD nowrap>�����
			<TD nowrap>�x����
			<TD nowrap>�E�v
<%
				lngCount = 0
				sumDebit = 0:	taxDebit = 0
				sumCredit = 0:	taxCredit = 0
				Do while not .EOF
					lngCount = lngCount + 1
					myPayTo = GetString(.Fields("CashPayTo"))
					myMemo = GetString(.Fields("Description"))
					myDebit = ""
					myCredit = ""
					if CashDepart <> "" then
						if CashDepart <> GetString(.Fields("CashDepart")) then myDebit = "style='color:gray'"
						if CashDepart <> GetString(.Fields("CreditDepart")) then myCredit = "style='color:gray'"
					end if
					if CashAccount <> "" then
						if CashAccount <> GetString(.Fields("CashDebit")) then myDebit = "style='color:gray'"
						if CashAccount <> GetString(.Fields("CashCredit")) then myCredit = "style='color:gray'"
					end if
					if myDebit = "" then 
						sumDebit = sumDebit + GetLong(.Fields("CashAmount"))
						taxDebit = taxDebit + GetLong(.Fields("CashTax"))
					end if
					if myCredit = "" then 
						sumCredit = sumCredit + GetLong(.Fields("CashAmount"))
						taxCredit = taxCredit + GetLong(.Fields("CashTax"))
					end if
%>
					<TR><TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("CashDate"))%>
						<TD nowrap class=line><%=GetString(.Fields("CashNo"))%>
						<TD nowrap class=line <%=myDebit%>><%=Code2Depart(.Fields("CashDepart"))%>
						<TD nowrap class=line <%=myDebit%>><%=GetString(.Fields("Debit"))%>
						<TD nowrap class=line <%=myCredit%>><%=GetString(.Fields("Credit"))%>
						<TD nowrap class=line <%=myCredit%>><%=Code2Depart(.Fields("CreditDepart"))%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("CashAmount")), 0, true)%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("CashTax")), 0, true)%>
						<TD nowrap class=line <%=ShowTitle(myPayTo, 8)%>><%=StringCut(myPayTo, 8)%>
						<TD nowrap class=line <%=ShowTitle(myMemo, 8)%>><%=StringCut(myMemo, 8)%><br>
<%
					.MoveNext
				Loop
				if CashDepart <> "" or CashAccount <> "" then
%>
					<TR><TD colspan=6>
						<TD align=center bgcolor=#E0E0E0>�ؕ����v
						<TD nowrap bgcolor=#E0E0E0><%=formatnumber(sumDebit, 0, true)%>
						<TD nowrap bgcolor=#E0E0E0><%=formatnumber(taxDebit, 0, true)%>
					<TR><TD colspan=6>
						<TD align=center bgcolor=#E0E0E0>�ݕ����v
						<TD nowrap bgcolor=#E0E0E0><%=formatnumber(sumCredit, 0, true)%>
						<TD nowrap bgcolor=#E0E0E0><%=formatnumber(taxCredit, 0, true)%>
<%
				end if
%>
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>