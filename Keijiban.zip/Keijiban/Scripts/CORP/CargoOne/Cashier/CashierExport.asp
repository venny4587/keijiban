<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'on error resume next

dim myMode

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	myMode = GetLong(request("mode"))
	if myMode = 0 then
		DateTo = GetMonthLastDay(date)
		DateFrom = dateadd("m", -1, dateadd("d", 1, DateTo))
	else
		DateFrom = GetDate(request("DateFrom"))
		DateTo = GetDate(request("DateTo"))
		
		if myMode = 2 then
			myDate = now
			filename = right(year(myDate),2) & right("00" & month(myDate),2) & right("00" & day(myDate),2) & _
					   right("00" & hour(myDate),2) & right("00" & minute(myDate),2) & right("00" & second(myDate),2)
			filename = filename & "_" & WebUserID & ".csv"
			
			Conn.BeginTrans
			
			Set FSO = Server.CreateObject ("Scripting.FileSystemObject") 
			Set FileOut = FSO.CreateTextFile(Server.MapPath("Export") & "\" & filename) 
			
			with Recset
				strSQL = "SELECT * FROM TBL_CORP_CASHIER WHERE Deleted = 0 AND SendFlag = 0"
				strSQL = strSQL & " AND Permiter <> '' AND CashDebit > '100'"
				if DateFrom <> "" then strSQL = strSQL & " AND CashDate >= '" & Date2Str(DateFrom) & "'"
				if DateTo <> "" then strSQL = strSQL & " AND CashDate <= '" & Date2Str(DateTo) & "'"
				strSQL = strSQL & " ORDER BY CashDate, CashNo"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
				
				do while not .EOF
					buf = formatDate(Str2Date(.fields("CashDate")))
					'buf = buf & "," & (datediff("m", cdate("2006/12/31"), Str2Date(.fields("CashDate"))) + 37)
					'buf = buf & "," & (datediff("m", cdate("2007/03/31"), Str2Date(.fields("CashDate"))))
					buf = buf & "," & (datediff("m", cdate("2007/03/31"), Str2Date(.fields("CashDate"))) + 7)
					buf = buf & "," & mid(GetString(.fields("CashNo")), 6)
					buf = buf & "," & chr(34) & GetString(.fields("CashCode")) & chr(34)
					buf = buf & ",0,1"
					buf = buf & "," & FitAccount(.fields("CashDebit"))
					if GetLong(.fields("CashDebit")) = 997 then
						buf = buf & "," & chr(34) & chr(34)
					else
						buf = buf & "," & chr(34) & GetString(.fields("CashDepart")) & chr(34)
					end if
					buf = buf & "," & chr(34) & chr(34) & "," & FitTaxCode(.fields("CashDebit"), .fields("CashTax"))
					buf = buf & ",0," & chr(34) & chr(34) & ",0," & chr(34) & chr(34)
					buf = buf & "," & FitAccount(.fields("CashCredit"))
					if GetLong(.fields("CashCredit")) = 997 then
						buf = buf & "," & chr(34) & chr(34)
					else
						buf = buf & "," & chr(34) & GetString(.fields("CreditDepart")) & chr(34)
					end if
					if GetLong(.fields("CashCredit")) = 914 then		'�ݕ��Ŋ֘A�m�F�K�v
						buf = buf & "," & chr(34) & chr(34) & ",1,1,1"		'�G����
					else
						'buf = buf & "," & chr(34) & chr(34) & ",0,0,0"
						buf = buf & "," & chr(34) & chr(34) & "," & FitTaxCode(.fields("CashCredit"), .fields("CashTax"))
					end if
					buf = buf & ",0," & chr(34) & chr(34) & ",0," & chr(34) & chr(34)
					buf = buf & "," & GetLong(.fields("CashAmount"))
					buf = buf & "," & GetLong(.fields("CashTax"))
					buf = buf & "," & FitTaxType(.fields("CashDebit"), .fields("CashCredit"), .fields("CashTax"))
					buf = buf & ",0,0,0"		'�O�ŁE�J�敪�E�J����
					buf = buf & "," & chr(34) & SetDescription(.fields("CashPayTo"), .fields("Description")) & chr(34)
					buf = buf & ",0,0,0,0,0,,0," & chr(34) & chr(34)
					FileOut.WriteLine buf
					
					.fields("SendFlag") = 1
					.Update
					.movenext
				loop
				.Close
			end with
			
			FileOut.Close 
			Set FSO = Nothing 
			
			strSql = "INSERT TBL_CORP_HISTORY (FileName, Creater, Created)"
			strSql = strSql & " VALUES ('" & filename & "','" & GetEmployName(WebUserID, "F") & "',GETDATE())"
			Conn.Execute strSql
			
			if err.number = 0 then
				Conn.CommitTrans
			else
				Conn.RollbackTrans
				ShowMessage "�f�[�^�������G���[���N����܂����B" & err.number & ":" & err.description
			end if
		end if
	end if

	myCashier = CheckCashierLevel()
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>��v�`�[�Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoHistory()
			set win = window.open("CashierHistory.asp", "CashierHistory", "resizable=0,scrollbars=1,width=300,height=400")
			win.focus()
		end sub
		
		sub DoExport()
			if msgbox ("�Y���o��d����o�͂��Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 2
			frmInput.Submit()
		end sub
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CashierExport.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<table class=pt9>
			<TR><TD nowrap>
				�Ώۓ��t <input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				<INPUT class=pt9n style="width:60px;height:25px;" TYPE=SUBMIT name=btnSearch VALUE="����">
				<INPUT class=pt9n style="width:60px;height:25px;" TYPE=button name=btnHistory VALUE="����" onclick="DoHistory()">
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		
		strSel = ""
		if DateFrom <> "" then strSel = strSel & " AND CashDate >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND CashDate <= '" & Date2Str(DateTo) & "'"
		
		strSQL = "SELECT CashNo, CashDate, CashAmount, CashTax, CashPayTo, CashDepart, Debit, CreditDepart, Credit"
		strSQL = strSQL & " FROM TBL_CORP_CASHIER AS C INNER JOIN (SELECT CTGR_CD, CTGR_NAME AS Debit "
		strSQL = strSQL & " FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS A ON C.CashDebit = A.CTGR_CD INNER JOIN"
		strSQL = strSQL & " (SELECT CTGR_CD, CTGR_NAME AS Credit FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS B"
		strSQL = strSQL & " ON C.CashCredit = B.CTGR_CD WHERE Deleted = 0 AND SendFlag = 0 AND Permiter <> '' " & strSel
		strSQL = strSQL & " AND CashDebit > '100'"
		strSQL = strSQL & " ORDER BY CashDate, CashNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
<div id=list>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=4 align=center>
			<colgroup span=2 align=left>
			<colgroup align=center>
			<colgroup span=2 align=right>
			<colgroup span=2 align=left>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap>���Z��
			<TD nowrap>�`�[�ԍ�
			<TD nowrap>�ؕ�����
			<TD nowrap>�ؕ��Ȗ�
			<TD nowrap>�ݕ��Ȗ�
			<TD nowrap>�ݕ�����
			<TD nowrap>�ō����z
			<TD nowrap>�����
			<TD nowrap>�x����
<%
				lngCount = 0
				Do while not .EOF
					lngCount = lngCount + 1
					myPayTo = GetString(.Fields("CashPayTo"))
%>
					<TR><TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("CashDate"))%>
						<TD nowrap class=line><%=GetString(.Fields("CashNo"))%>
						<TD nowrap class=line><%=Code2Depart(.Fields("CashDepart"))%>
						<TD nowrap class=line><%=GetString(.Fields("Debit"))%>
						<TD nowrap class=line><%=GetString(.Fields("Credit"))%>
						<TD nowrap class=line><%=Code2Depart(.Fields("CreditDepart"))%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("CashAmount")), 0, true)%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("CashTax")), 0, true)%>
						<TD nowrap class=line <%=ShowTitle(myPayTo, 8)%>><%=StringCut(myPayTo, 8)%>
<%
					.MoveNext
				Loop
				if lngCount > 0 and myCashier > 1 then
%>
					<TR><TD colspan=13 align=right>
							<input type=button style="width:80;height:30" name=btnExport value="�o��" onclick="DoExport()">
<%
				end if
%>
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
<%if myMode = 2 then%>
	<script language=javascript>
		window.location.href = "CashierDownload.asp?file=<%=filename%>";
	</script>
<%end if%>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function SetDescription(myPay, myDesc)
dim buf
	buf = GetString(myPay)
	select case buf
	case "�Ȃ�", "����", "�i�V", "��"
		buf = GetString(myDesc)
	case else
		buf = buf & " " & GetString(myDesc)
	end select
	SetDescription = FitSel(buf)
end function 

function FitAccount(myAccount)
dim buf
	buf = GetString(myAccount)
	if len(buf) < 4 then
		select case GetLong(myAccount)
		case 846, 853, 863, 914, 921
			FitAccount = GetLong(buf) & ",0"
		case else
			FitAccount = GetLong(buf) & ","
		end select
	else
		FitAccount = GetLong(left(buf, 3)) & "," & GetLong(mid(buf, 4))
	end if
end function

function FitTaxCode(myDebit, myTax)
	if left(GetString(myDebit), 1) = "8" then	'�o��ΏۉȖ�
		if GetLong(myTax) <> 0 then
			FitTaxCode = "2,0,1"		'����ŁE�Ǝ�E�ō�
		else
			FitTaxCode = "2,0,0"
		end if
	elseif GetString(myDebit) = "912" then
		FitTaxCode = "1,0,0"
	else
		FitTaxCode = "0,0,0"
	end if
end function 

function FitTaxType(myDebit, myCredit, myTax)
dim buf
	if left(GetString(myDebit), 1) = "8" or left(GetString(myCredit), 1) = "8" then
		if GetLong(myTax) = 0 then
			FitTaxType = "30,0"		'��ې�
		else
			FitTaxType = "10,2"		'�ېŁE�ŗ�
		end if
	elseif GetLong(myCredit) = 912 then					'���z����
		FitTaxType = "40,0"			'�s�ېŁE�ŗ�
	elseif GetLong(myCredit) = 914 then					'�G����
		FitTaxType = "10,2"			'�ېŁE�ŗ�
	elseif GetLong(myDebit) = 921 then					'�x������
		FitTaxType = "30,2"			'��ېŁE�ŗ�
	else
		FitTaxType = "0,0"			'�ΏۊO
	end if
	
end function

'-------------------------------------------------
'��������:ReadTextFile
'��p:���pAdoDb.Stream����UTF-8�i���I���{����
'----------------------------------------------------
function ReadFromTextFile(FileUrl, CharSet)
dim stm, str
    set stm=server.CreateObject("adodb.stream")
    stm.Type=2 				'���{�͎�
    stm.mode=3 
    stm.charset=CharSet
    stm.open
    stm.loadfromfile server.MapPath(FileUrl)
    str=stm.readtext
    stm.Close
    set stm=nothing
    ReadFromTextFile=str
end function

'-------------------------------------------------
'��������:WriteToTextFile
'��p:���pAdoDb.Stream���ʓ�UTF-8�i���I���{����
'----------------------------------------------------
Sub WriteToTextFile(FileUrl, Str, CharSet)
dim stm
    set stm=server.CreateObject("adodb.stream")
    stm.Type=2 				'���{�͎�
    stm.mode=3
    stm.charset=CharSet
    stm.open
    stm.WriteText str
    stm.SaveToFile server.MapPath(FileUrl), 2
    stm.flush
    stm.Close
    set stm=nothing
end Sub
%>