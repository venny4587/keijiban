<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'on error resume next

dim CashNo

	mode = GetLong(request("mode"))
	CashNo = GetPost(request("CashNo"))
	CashDepart = GetPost(request("CashDepart"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	Conn.BeginTrans
	
	select case mode
	case -1							'��o����
	
		if CheckCashPaid(CashNo) > 0 then
		
			msg = "�Y����v�`�[�͊��ɐ��Z��������܂����I"
			
		else
						
			'�������폜
			strSql = "UPDATE TBL_CORP_CASHIER SET Updated = GETDATE()"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Proposer = '', Proposed = NULL"
			strSql = strSql & ", Confirmer = '', ConfirmDate = NULL"
			strSql = strSql & ", Shoper = '', ShopDate = NULL"
			strSql = strSql & ", Corper = '', CorpDate = NULL"
			strSql = strSql & ", Reviewer = '', ReviewDate = NULL"
			strSql = strSql & ", CashMemo = '" & FitSel(request("CashMemo")) & "'"
			strSql = strSql & " WHERE CashNo = '" & CashNo & "'"
			Conn.execute strSql
			
			msg = "�Y����v�`�[�͒�o��������܂����I"
			
		end if
		
	case 0, 1						'�ۑ��E��o
	
		if CashNo = "" then			'�V�K�ԍ����s
		
			CashInit = mid(Date2Str(date), 3, 4) & "-" &  GetCashInit(CashDepart)
			
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_CTM_NEW_ACNT"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@Account").Value = CashInit
			cmdSQL.Execute
			CashNo = CashInit & right("000" & GetLong(cmdSQL.Parameters("@MaxID").Value),3)
		
		elseif CheckCashProposed(CashNo) > 0 then
		
			msg = "�Y���������͊��ɒ�o����܂����I"
				
		end if
		
		if msg = "" then
			with Recset
				strSql = "SELECT * FROM TBL_CORP_CASHIER WHERE CashNo = '" & CashNo & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("CashNo") = CashNo
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
					.fields("sendFlag") = 0
				end if
				
				.fields("CashDepart") = CashDepart
				.fields("CreditDepart") = CashDepart
				.fields("CashDebit") = GetPost(request("CashDebit"))
				.fields("CashDate") = Date2Str(request("CashDate"))
				.fields("CashAmount") = GetLong(request("CashAmount"))
				.fields("CashTaxName") = GetPost(request("CashTaxName"))
				.fields("CashTax") = GetLong(request("CashTax"))
				.fields("CashPayTo") = GetPost(request("CashPayTo"))
				
				.fields("Description") = GetPost(request("Description"))
				.fields("CashTerm") = GetPost(request("CashTerm"))
				.fields("CashParty") = GetPost(request("CashParty"))
				.fields("CashMember") = GetPost(request("CashMember"))
				.fields("CashPurpose") = GetPost(request("CashPurpose"))
				.fields("CashContent") = GetPost(request("CashContent"))
				.fields("CashEffect") = GetPost(request("CashEffect"))
				.fields("CashMemo") = GetPost(request("CashMemo"))
				
				if mode = 1 then
					.fields("Proposer") = session("FamilyName")
					.fields("Proposed") = now()
					if CheckVoucherLevel() > 3 or WebUserID = GetShoperID(CashDepart) then
						.fields("Shoper") = session("FamilyName")
						.fields("ShopDate") = now()
					end if
				end if
				
				.fields("Remarks") = GetPost(Request("Remarks"))
				.fields("Updater") = WebUserID
				.fields("Updated") = now()
				
				.update
				.close
			end with
			
			select case mode
			case 0:		msg = "�Y����v�`�[�͕ۑ�����܂����I"
			case 1:		msg = "�Y����v�`�[�͒�o����܂����I"
			end select
			
		end if
	
	case 2				'���F
		
		strSql = "UPDATE TBL_CORP_CASHIER SET CashMemo = '" & FitSel(request("CashMemo")) & "'"
		strSql = strSql & ", ShopDate = GETDATE(), Shoper = '" & FitSel(session("FamilyName")) & "'"
		strSql = strSql & " WHERE CashNo = '" & CashNo & "'"
		Conn.execute strSql
		
		msg = "�Y����v�`�[�͏��F����܂����I"
		
	end select
				
	if err.number = 0 then 
		Conn.CommitTrans
%>
<html>
	<script language=javascript>
		alert("<%=msg%>");
		if (window.opener != null) {
			if (window.opener.frmInput != null) window.opener.frmInput.submit();
		}
		window.location.href = "CashierInput.asp?CashNo=<%=CashNo%>";
	</script>
</html>
<%
	else
		Conn.CommitTrans
		ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
	end if		
	CloseDB Conn	
%>
