<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = 10
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>��v�`�[�Ɖ�</TITLE>	
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DownLoad(fn)
			window.location.href = "CashierDownload.asp?file=" & fn
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
			if window.event.keyCode=27 then window.close()
		end sub
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CashierView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
<%
	With Recset
		strSQL = "SELECT * FROM TBL_CORP_HISTORY ORDER BY Created DESC "
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .EOF then
			.PageSize = myPageSize
			lngPageCount = .PageCount
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=4 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap>�o�͓��t
			<TD nowrap>�o�͎�
			<TD nowrap>̧��
<%
			Do Until .EOF
				lngCount = lngCount + 1
				If lngCount > lngPageNumber * myPageSize Then
					Exit Do
				Else
%>
					<TR><TD nowrap class=line><%=lngCount%>
						<TD nowrap class=line><%=FmtDateTime(.Fields("Created"))%>
						<TD nowrap class=line><%=GetString(.Fields("Creater"))%>
						<TD nowrap class=line>
							<a href="javascript:Download('<%=GetString(.Fields("FileName"))%>')"><img src=img/open.gif border=0 alt="�J��"></a>
<%
					.MoveNext
				End If
			Loop
%>
				
	</TABLE>
<%
		else
			Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
		end if
		.Close
	end with
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>