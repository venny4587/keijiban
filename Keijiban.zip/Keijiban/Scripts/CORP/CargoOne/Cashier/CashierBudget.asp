<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'----------------------------------------------
'	�Ɩ��\�Z���ʐ��ڕ\
'----------------------------------------------

dim CashDate
dim CashCount
dim CashCode()
dim CashAccount()
dim CashBudget()
dim CashRemarks()
	
	redim CashCode(0)
	redim CashAccount(0)
	CashCode(0) = gsProfitCode
	CashAccount(0) = gsProfitName
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT CTGR_NUM, MIN(CTGR_CD) AS CD, MIN(CTGR_NAME) AS NM FROM MST_CATEGORY"
		strSql = strSql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = 10 AND CTGR_NUM > 0"
		strSql = strSql & " GROUP BY CTGR_NUM ORDER BY CTGR_NUM"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		CashCount = 0
		do while not .EOF
			CashCount = CashCount + 1
			redim preserve CashCode(CashCount)
			redim preserve CashAccount(CashCount)
			CashCode(CashCount) = left(GetString(.fields("CD")), 3)
			CashAccount(CashCount) = GetString(.fields("NM"))
			.movenext
		loop
		.Close
	end with
	
	mode = GetLong(request("mode"))
	if mode = 0 then
		CashDepart = GetDepartCode()
		CashDate = dateadd("m", -1, date)
		SelYear = year(CashDate)
		SelMonth = month(CashDate)
		CashMonth = SelYear & right("00" & SelMonth, 2)
	else
		CashDepart = GetString(request("CashDepart"))
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
		CashMonth = SelYear & right("00" & SelMonth, 2)
		
		if mode = 2 then
			Conn.BeginTrans
			
			for i = 0 to CashCount
				with Recset
					strSql = "SELECT * FROM TBL_CORP_BUDGET WHERE CashMonth = '" & CashMonth & "'"
					strSql = strSql & " AND CashDepart = '" & CashDepart & "' AND CashAccount = '" & CashCode(i) & "'"
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
					if .eof then
						.AddNew
						.fields("CashMonth") = CashMonth
						.fields("CashDepart") = CashDepart
						.fields("CashAccount") = CashCode(i)
						
						.fields("Creater") = WebUserID
						.fields("Created") = now
					end if
					
					.fields("CashBudget") = GetLong(Request("Cash" & i))
					'.fields("Remarks") = GetPost(Request("Memo" & i))
					.fields("Updater") = WebUserID
					.fields("Updated") = now()
					
					.update
					.close
				end with
			next
			
			if err.number = 0 then
				Conn.CommitTrans
				msg = "����\�Z�f�[�^���X�V���܂����B"
			else
				Conn.RollbackTrans
				msg = "�������G���[���N����܂����B" & err.number & ":" & err.description
			end if
				
		end if
	end if
	
	redim CashBudget(CashCount)
	redim CashRemarks(CashCount)
	with Recset
		strSql = "SELECT CashAccount, CashBudget, Remarks FROM TBL_CORP_BUDGET"
		strSql = strSql & " WHERE CashMonth = '" & CashMonth & "' AND CashDepart = '" & CashDepart & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .EOF
			for i = 0 to CashCount
				if CashCode(i) = GetString(.fields("CashAccount")) then
					CashBudget(i) = GetLong(.fields("CashBudget"))
					'CashRemarks(i) = GetString(.fields("Remarks"))
					exit for
				end if
			next
			.movenext
		loop
		.Close
	end with
	
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
%>

<HTML>
<HEAD>
	<TITLE>����ʌo��\�Z����</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<script language=vbscript>
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
		end sub
		
<%for i = 0 to CashCount%>
		sub Cash<%=i%>_OnBlur()
			frmInput.Cash<%=i%>.value = formatnumber(GetLong(frmInput.Cash<%=i%>.value),0,true)
			call Calculate()
		end sub
<%next%>

		sub Calculate()
		dim buf
			buf = GetLong(frmInput.Cash0.value)
	<%for i = 1 to CashCount - 1%>
			buf = buf - GetLong(frmInput.Cash<%=i%>.value)
	<%next%>
<%if CashDepart = "6" then%>
			buf = buf + GetLong(frmInput.Cash<%=CashCount-1%>.value) * 2
<%end if%>
			frmInput.Cash<%=CashCount%>.value = formatnumber(buf,0,true)
		end sub
		
		sub DoSave()
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 2
			frmInput.submit()
		end sub
	</script>
</HEAD>

<BODY topmargin=5 onload="InitForm()" class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CashierBudget.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value=1>
		<table class=pt9>
			<TR><TD nowrap>�Ώە���
<%if myCashier > 1 or myLevel > 2 then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()"><%=ShowDepartList(CashDepart)%></select>
<%else%>
	<%if UserShop = "K" then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()">
						<option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o
						<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
						<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
						<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
					</select>
	<%else%>
				<TD><font class=pt9g><%=Code2Depart(CashDepart)%></font><input type=hidden name="CashDepart" value="<%=CashDepart%>">
	<%end if%>
<%end if%>
				<TD nowrap>�Ώ۔N��
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) - 1 to year(date) + 1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>��&nbsp;
				<TD nowrap>
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
<%if CashDepart <> "" and (myLevel > 2 or myCashier > 1) then%>
					<input type=button name=btnSave style="width:80;height:30" value="�ۑ�" onclick="DoSave()">
<%end if%>
		</table>
		<br>
<%if CashDepart <> "" then%>
���\�Z����F<font class=pt9g><%=Code2Depart(CashDepart)%></font>
�@�\�Z���x�F<font class=pt9g><%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��</font>
		<table border=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
			<colgroup bgcolor="#E0FFE0" align=center>
			<colgroup bgcolor="#E0FFE0" align=left>
			<colgroup span=2 align=center>
			<TR><TD class=voucher width=50>����
				<TD class=voucher width=150 align=center>����Ȗ�
				<TD class=voucher width=100>����\�Z
	<%if false then%>
				<TD class=voucher width=240>�\�Z���l
	<%end if%>
<%for i = 0 to CashCount - 1%>
			<TR><TD><%=CashCode(i)%>
				<TD>�@<%=ShowAccountName(CashAccount(i))%>
				<TD><input class=sn name="Cash<%=i%>" size=10 maxlength=11 value="<%=formatnumber(CashBudget(i),0,true)%>" OnKeyDown="ResetEnter()">
	<%if false then%>
				<TD><input class=sj name="Memo<%=i%>" size=30 maxlength=100 value="<%=CashRemarks(i)%>" OnKeyDown="ResetEnter()">
	<%end if%>
<%next%>
			<TR><TD bgcolor="#FFE0E0"><%=CashCode(CashCount)%>
				<TD bgcolor="#FFE0E0">�@<%=ShowAccountName(CashAccount(CashCount))%>
				<TD bgcolor="#FFE0E0"><input class=sn name="Cash<%=CashCount%>" size=10 maxlength=11 
					value="<%=formatnumber(CashBudget(CashCount),0,true)%>" OnKeyDown="ResetEnter()" readonly>
		</table>
<%end if%>
	</form>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>


<%
function ShowAccountName(myName)
dim pos
	pos = instr(myName, "�E")
	if pos = 0 then
		ShowAccountName = myName
	else
		ShowAccountName = left(myName, pos - 1)
	end if
end function
%>