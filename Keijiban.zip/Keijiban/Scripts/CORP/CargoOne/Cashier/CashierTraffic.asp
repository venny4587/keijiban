<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Voucher.asp" -->
<%
'on error resume next

dim strSel

dim mode
dim PKG_ID 
dim IMPORT_NO 
dim IMPORT_DATE
dim EXPORT_DATE
dim PKG_UNIT
dim PKG_NW
dim PKG_GW
dim PKG_CBM

	mode = GetLong(request("mode"))
	PKG_ID = GetLong(request("id"))
	IMPORT_NO = GetString(request("IMPORT_NO"))
	IMPORT_DATE = GetString(request("IMPORT_DATE"))
	EXPORT_DATE = GetString(request("EXPORT_DATE"))
	PKG_UNIT = GetString(request("PKG_UNIT"))
	
	OpenSQL	Conn, myServer, myDatabase
	Set Recset = Server.CreateObject ("ADODB.Recordset")	
					
	if PKG_ID <> 0 then
		With Recset
			strSQL = "SELECT IMPORT_NO,IMPORT_DATE, PKG_NO, PKG_UNIT, EXPORT_DATE, "
			strSQL = strSQL & " PKG_NW, PKG_GW, PKG_CBM FROM SO_PKG WHERE PKG_ID =  " & PKG_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				IMPORT_NO = GetString(.Fields("IMPORT_NO"))
				IMPORT_DATE = GetString(.Fields("IMPORT_DATE"))
				EXPORT_DATE = GetString(.Fields("EXPORT_DATE"))
				PKG_UNIT = GetString(.Fields("PKG_UNIT"))
				PKG_NW = GetDouble(.Fields("PKG_NW"))
				PKG_GW = GetDouble(.Fields("PKG_GW"))
				PKG_CBM = GetDouble(.Fields("PKG_CBM"))
			end if 
			.close
		end with
	end if
		
	if mode = 2 then
		With Recset
			.Open "SELECT * FROM SO_PKG WHERE PKG_ID = " & PKG_ID, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then 
				.AddNew
if false then
response.write "<BR>PKG_ID= " & PKG_ID
response.write "<BR>IMPORT_DATE= " & GetDate(request("IMPORTDATE"))
response.write "<BR>IMPORT_NO= " & GetString(request("IMPORTNO"))
response.write "<BR>PKG_NO= " & GetLong(request("PKG_NO"))
response.write "<BR>PKG_UNIT= " & GetString(request("PKGUNIT"))
response.write "<BR>PKG_NW= " & GetDouble(request("PKG_NW"))
response.write "<BR>PKG_GW= " & GetDouble(request("PKG_GW"))
response.write "<BR>PKG_CBM= " & GetDouble(request("PKG_CBM"))
response.write "<BR>EXPORT_DATE= " & GetString(request("EXPORTDATE"))
response.write "OK"
end if
			end if
	        .Fields("IMPORT_DATE") = GetDate(request("IMPORTDATE"))
	        .Fields("IMPORT_NO") = GetString(request("IMPORTNO"))
	        .Fields("PKG_NO") = GetLong(request("PKG_NO"))
	        .Fields("PKG_UNIT") = GetString(request("PKGUNIT"))
	        .Fields("PKG_NW") = GetDouble(request("PKG_NW"))
	        .Fields("PKG_GW") = GetDouble(request("PKG_GW"))
	        .Fields("PKG_CBM") = GetDouble(request("PKG_CBM"))
	        if GetString(request("EXPORT_DATE")) <> "" then
	        	.Fields("EXPORT_DATE") = GetString(request("EXPORT_DATE"))
	        end if
	        .Update
			.close
		end with
	end if
%>

<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN">
<HTML><HEAD>
<TITLE>���ɏ�񌟍�</TITLE>
<META http-equiv=Content-Type content="text/html; charset=shift-jis">
<link rel="stylesheet" href="style.css" type="text/css">	
<style>	
.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 9pt }
.pt12 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 12pt }	
.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #E0FFE0; BORDER-RIGHT: #E0FFE0 1px solid; BORDER-TOP: #E0FFE0 1px solid; BORDER-LEFT: #E0FFE0 1px solid; BORDER-BOTTOM: #006400 1px solid;}
.sn{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #E0FFE0; BORDER-RIGHT: #E0FFE0 1px solid; BORDER-TOP: #E0FFE0 1px solid; BORDER-LEFT: #E0FFE0 1px solid; BORDER-BOTTOM: #006400 1px solid; TEXT-ALIGN:right}
</style>
<SCRIPT language=Javascript>
<!--		
	function ResetEnter() {
		if (event.keyCode == 13) {
			window.event.keyCode = 9;
		}
	}
-->
</SCRIPT>
<script language = vbscript>

	function DoCopy(myID)
	dim win		
		set win = window.open("PKG_Copy.asp?id=" & myID, "PKG_Copy",  "resizable=0,scrollbars=0,width=400,height=250,left=100,top=50")
		win.focus()
	end function
	
	function DoDetail(myID)
		window.parent.detail.location.href="PKG_Detail.asp?id=" & myID
	end function
	
	function DoEdit(myID)
		window.location.href="PKG_Input.asp?mode=3&id=" & myID
	end function
	
	function DoDelete(myID)
		If msgbox("�폜���Ă���낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 Then
			window.location.href="PKG_Delete.asp?id=" & myID
		End If
	end function
	
	function DoCancel()
		window.location.href="PKG_Input.asp?mode=1&id=<%=PKG_ID%>"
	end function
	
	function DoSave()
	dim buf
	dim msg 
		msg = "�m�F���b�Z�[�W" 
		if trim(frmInput.IMPORTDATE.value) <> "" then
			if not isdate(frmInput.IMPORTDATE.value) then
				frmInput.IMPORTDATE.focus
				msgbox "���ɓ��𐳂������͂��Ă�������",48, msg
				exit function
			end if
		end if
		if	trim(frmInput.PKG_NO.value) = "" then
			frmInput.PKG_NO.focus
			msgbox "�}�[�N������͂��Ă�������",48, msg
			exit function
		end if
		if	trim(frmInput.PKGUNIT.value) = "" then
			frmInput.PKGUNIT.focus
			msgbox "����׎p����͂��Ă�������",48, msg
			exit function
		end if
		if trim(frmInput.PKG_NW.value)  = "" then
			frmInput.PKG_NW.focus
			msgbox "N.W.����͂��Ă�������",48, msg
			exit function
		elseif not isNumeric(frmInput.PKG_NW.value) then
			frmInput.PKG_NW.focus
			msgbox "N.W.�𐳂������͂��Ă�������",48, msg
			exit function
		else
			frmInput.PKG_NW.value = cdbl(frmInput.PKG_NW.value)
		end if
		if trim(frmInput.PKG_GW.value)  = "" then
			frmInput.PKG_GW.focus
			msgbox "G.W.����͂��Ă�������",48, msg
			exit function
		elseif not isNumeric(frmInput.PKG_GW.value) then
			frmInput.PKG_GW.focus
			msgbox "G.W.�𐳂������͂��Ă�������",48, msg
			exit function
		else
			frmInput.PKG_GW.value = cdbl(frmInput.PKG_GW.value)
		end if
		if trim(frmInput.PKG_CBM.value)  = "" then
			frmInput.PKG_CBM.focus
			msgbox "CMB����͂��Ă�������",48, msg
			exit function
		elseif not isNumeric(frmInput.PKG_CBM.value) then
			frmInput.PKG_CBM.focus
			msgbox "CMB�𐳂������͂��Ă�������",48, msg
			exit function
		else
			frmInput.PKG_CBM.value = cdbl(frmInput.PKG_CBM.value)
		end if
		if trim(frmInput.EXPORTDATE.value) <> "" then
			if not isdate(frmInput.EXPORTDATE.value) then
				frmInput.EXPORTDATE.focus
				msgbox "�o�`���𐳂������͂��Ă�������",48, msg
				exit function
			end if
		end if
		if msgbox("�Y���f�[�^��ۑ����Ă�낵���ł����H", 289, msg) = 1 then 
			frmInput.mode.value = 2
			frmInput.id.value = <%=PKG_ID%>
			frmInput.submit()
		end if	
	end function

</script>
</HEAD>
<BODY>

<!--Main Body-->
<TABLE cellSpacing=0 cellPadding=0 border=0 width=100%>
  <TBODY><TR>
    <TD><IMG height=2 alt="" 
      src="img/spacer.gif" 
      width=3></TD>
    <TD align=middle>
    
      <!--Head Graph-->
      <TABLE cellSpacing=0 cellPadding=0 width=95% border=0>
        <TBODY><TR>
          <TD><IMG height=5 src="img/spacer.gif" width=5></TD></TR></TBODY></TABLE>
            
      <!--Body Frame-->
      <TABLE cellSpacing=0 cellPadding=0 border=0 width=100%>
        <TBODY>
        <TR>
          <TD><IMG height=5 src="img/dtl_img02.gif" width=5></TD>
          <TD background="img/dtl_bg01.gif" width=99%><IMG height=5 src="img/spacer.gif"></TD>
          <TD><IMG height=5 src="img/dtl_img03.gif" width=5></TD></TR>
        <TR>
          <TD background="img/dtl_bg02.gif"><IMG src="img/spacer.gif" width=5></TD>
          <TD valign=top height=210 align=center>
          
			<!----------��������--------->
			<FORM METHOD="POST" ACTION="PKG_Input.asp" ID=frmInput NAME=frmInput>
				<input type="hidden" name="mode" value="1">
				<input type="hidden" name="id" value="">
				<table width="98%" BORDER=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9>
					<TR ALIGN=CENTER>
						<TD bgcolor="#E0E0E0" nowrap>���ɓ��t</TD>
						<TD bgcolor="#FFFFFF" nowrap>
							<input name="IMPORT_DATE" value="<%=IMPORT_DATE%>" maxlength=10 size=12 title="exp:<%=year(date)%>/01/01" OnKeyDown="ResetEnter()"></TD>
						<TD bgcolor="#E0E0E0" nowrap>���ɔԍ�</TD>
						<TD nowrap><input name="IMPORT_NO" value="<%=IMPORT_NO%>" class=textdate maxlength=20 size=20 OnKeyDown="ResetEnter()"></TD>
						<TD bgcolor="#E0E0E0" nowrap>�o�`���t</TD>
						<TD bgcolor="#FFFFFF" nowrap><input name="EXPORT_DATE" value="<%=EXPORT_DATE%>" maxlength=10 size=12 title="exp:<%=year(date)%>/01/01" OnKeyDown="ResetEnter()"></TD>							
						<TD bgcolor="#E0E0E0" nowrap>���ɉ׎p</TD>
						<TD bgcolor="#FFFFFF" nowrap><input name="PKG_UNIT" value="<%=PKG_UNIT%>" class=textdate maxlength=20 size=12 OnKeyDown="ResetEnter()"></TD>
						<TD bgcolor="#E0E0E0" nowrap rowspan=2>
							<INPUT style="width:80px;height:30px;" TYPE=SUBMIT VALUE="����"></TD>
					</TR>
				</table><BR>
				
			<!----------��������--------->		
          
<%		
			if mode > 0 then
%>
				<table width="98%" BORDER=1 CELLSPACING=0 BORDERCOLORLIGHT=#C0C0C0 BORDERCOLORDARK=#FFFFFF CELLPADDING=3 class=pt9>
					<TR ALIGN=CENTER bgcolor=#E0E0E0>
						<TD nowrap>��</TD>
						<TD nowrap>���ɓ�</TD>
						<TD nowrap>���ɔԍ�</TD>
						<TD nowrap>ϰ���</TD>
						<TD nowrap>�׎p</TD>
						<TD nowrap>N.W.</TD>
						<TD nowrap>G.W.</TD>
						<TD nowrap>CBM</TD>
						<TD nowrap>�o�`��</TD>
						<TD nowrap>�I��</TD>
						<TD nowrap>����</TD>
					</TR>
<%		
				if mode <> 3 then
%>
					<TR bgcolor=#E0FFE0 ALIGN="center">
						<TD nowrap bgcolor="#E0E0E0">*<BR></TD>
						<TD nowrap><input class=so name="EXPORTDATE" value="<%=EXPORT_DATE%>" maxlength=10 size=10 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=so name="IMPORTNO" value="<%=IMPORT_NO%>" maxlength=20 size=12 OnKeyDown="ResetEnter()"></TD>
						<TD nowrap><input class=sn name="PKG_NO" value="" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=so name="PKGUNIT" value="<%=PKG_UNIT%>" maxlength=20 size=8 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=sn name="PKG_NW" value="0" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=sn name="PKG_GW" value="0" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=sn name="PKG_CBM" value="0" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=so name="IMPORTDATE" value="<%=IMPORT_DATE%>" maxlength=10 size=10 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap colspan=2><a href="javascript:DoSave()">�V�K�ǉ�</a><BR></TD>
					</TR>
<%		
				end if
				
				With Recset
					strSQL = "SELECT PKG_ID,IMPORT_NO,IMPORT_DATE,EXPORT_DATE, PKG_NO, PKG_UNIT, PKG_NW, PKG_GW, PKG_CBM"
					strSQL = strSQL & " FROM SO_PKG WHERE PKG_ID > 0 "
					if IMPORT_NO <> "" then 
						strSQL = strSQL & " AND IMPORT_NO = '" & IMPORT_NO & "'"
					end if
					if isdate(IMPORT_DATE) then 
						strSQL = strSQL & " AND IMPORT_DATE = #" & IMPORT_DATE & "#"
					end if
					strSQL = strSQL + " ORDER BY PKG_ID DESC;"
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .eof then
						.MoveLast
						if .RecordCount > PageSize then
							response.write "�������ʂ� " & PageSize & "�����z���܂����A�����������Đݒ肵�Ă��������B"
						else
							.Movefirst
							
							lngCount = 0
							myUnit = ""
							myQuantity = 0
							myNetWeight = 0
							myGrossWeight = 0
							myMeasurement = 0
							Do While Not .EOF
							
								lngCount = lngCount + 1
								if lngCount <= 3 then
									if  GetDate(.Fields("EXPORT_DATE")) < date() then
										mybgcolor = "#F0F0F0"
									else
										mybgcolor = "#FFFFFF"
									end if	
									
									if mode = 3 and PKG_ID = GetLong(.Fields("PKG_ID")) then
%>					
					<TR bgcolor=#E0FFE0 ALIGN="center">
						<TD nowrap bgcolor="#E0E0E0"><%=lngCount%><BR><input type=hidden name="PKG_ID" value="<%=PKG_ID%>"></TD>
						<TD nowrap><input class=so name="IMPORTDATE" value="<%=GetString(.Fields("IMPORT_DATE"))%>" maxlength=10 size=10 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=so name="IMPORTNO" value="<%=GetString(.Fields("IMPORT_NO"))%>" maxlength=20 size=12 OnKeyDown="ResetEnter()"></TD>
						<TD nowrap><input class=sn name="PKG_NO" value="<%=GetLong(.Fields("PKG_NO"))%>" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=so name="PKGUNIT" value="<%=GetString(.Fields("PKG_UNIT"))%>" maxlength=20 size=8 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=sn name="PKG_NW" value="<%=formatnumber(.Fields("PKG_NW"), 2, true)%>" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=sn name="PKG_GW" value="<%=formatnumber(.Fields("PKG_GW"), 2, true)%>" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=sn name="PKG_CBM" value="<%=formatnumber(.Fields("PKG_CBM"), 3, true)%>" maxlength=9 size=6 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><input class=so name="EXPORTDATE" value="<%=GetString(.Fields("EXPORT_DATE"))%>" maxlength=10 size=10 OnKeyDown="ResetEnter()"><BR></TD>
						<TD nowrap><a href="javascript:DoSave()">�ۑ�</a>&nbsp;<a href="javascript:DoCancel()">���</a><BR></TD>
						<TD nowrap><a href="javascript:DoDetail(<%=GetLong(.Fields("PKG_ID"))%>)">����</a>&nbsp;<a href="javascript:DoCopy(<%=GetLong(.Fields("PKG_ID"))%>)">COPY</a><BR></TD>
					</TR>
<%
									else	
%>
					<TR bgcolor="<%=mybgcolor%>" ALIGN="center">
						<TD nowrap bgcolor="#E0E0E0"><%=lngCount%><BR></TD>
						<TD nowrap><%=.Fields("EXPORT_DATE")%><BR></TD>
						<TD nowrap><%=.Fields("IMPORT_NO")%><BR></TD>
						<TD nowrap><%=.Fields("PKG_NO")%><BR></TD>
						<TD nowrap><%=.Fields("PKG_UNIT")%><BR></TD>
						<TD nowrap ALIGN="right"><%=formatnumber(.Fields("PKG_NW"), 2, true)%><BR></TD>
						<TD nowrap ALIGN="right"><%=formatnumber(.Fields("PKG_GW"), 2, true)%><BR></TD>
						<TD nowrap ALIGN="right"><%=formatnumber(.Fields("PKG_CBM"), 3, true)%><BR></TD>
						<TD nowrap><%=.Fields("IMPORT_DATE")%><BR></TD>
					<%if GetDate(.Fields("EXPORT_DATE")) < date() then%>
						<TD nowrap colspan=2>�o�ɍς�<BR></TD>
					<%else%>
						<TD nowrap><a href="javascript:DoEdit(<%=GetLong(.Fields("PKG_ID"))%>)">�ҏW</a>&nbsp;<a href="javascript:DoDelete(<%=GetLong(.Fields("PKG_ID"))%>)">�폜</a><BR></TD>
						<TD nowrap><a href="javascript:DoDetail(<%=GetLong(.Fields("PKG_ID"))%>)">����</a>&nbsp;<a href="javascript:DoCopy(<%=GetLong(.Fields("PKG_ID"))%>)">COPY</a><BR></TD>
					<%end if%>
					</TR>
<%
									end if
								end if
								
								if myUnit = "" then myUnit = GetString(.Fields("PKG_UNIT"))
								myNetWeight = myNetWeight + GetDouble(.Fields("PKG_NW"))
								myGrossWeight = myGrossWeight + GetDouble(.Fields("PKG_GW"))
								myMeasurement = myMeasurement + GetDouble(.Fields("PKG_CBM"))
								.MoveNext
							Loop
						end if
					end if
					.Close
				End with
%>
					<TR bgcolor="#E0E0E0" ALIGN="center">
						<TD nowrap colspan=3>�Y�����v<BR></TD>
						<TD nowrap><b><%=formatnumber(lngCount, 0, true)%></b><BR></TD>
						<TD nowrap><%=showplur(myUnit, lngCount)%><BR></TD>
						<TD nowrap ALIGN="right"><%=formatnumber(myNetWeight, 2, true)%><BR></TD>
						<TD nowrap ALIGN="right"><%=formatnumber(myGrossWeight, 2, true)%><BR></TD>
						<TD nowrap ALIGN="right"><%=formatnumber(myMeasurement, 3, true)%><BR></TD>
						<TD nowrap colspan=3><BR></TD>
					</TR>
				</TABLE>	
<%				
			end if
%>				
			  </form>
			</TD>
			<TD background="img/dtl_bg07.gif"><IMG height=5 src="img/spacer.gif" width=10></TD></TR>
		<TR>
			<TD><IMG height=7 src="img/dtl_img04.gif" width=5></TD>
			<TD background="img/dtl_bg04.gif"><IMG height=7 src="img/spacer.gif" width=5></TD>
		    <TD><IMG height=7 src="img/dtl_img05.gif" width=5></TD></TR>
    	</TBODY></TABLE></TD></TR>

	<TR>
	  <TD><IMG height=2 alt="" 
	    src="img/spacer.gif" 
	    width=3></TD>
	  <TD><IMG height=2 alt="" 
	    src="img/spacer.gif"></TD></TR></TBODY></TABLE>

</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>