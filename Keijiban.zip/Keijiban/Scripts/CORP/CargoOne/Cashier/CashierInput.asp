<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
	Depart = GetDepartCode()
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	CashNo = GetPost(request("CashNo"))
	if CashNo = "" then
		Status = 0
		CashDepart = Depart
		CashDebit = "837"
		CashTaxName = "�ې�5%"
		CashDate = formatDate(date)
	else
		with Recset
			strSql = "SELECT * FROM TBL_CORP_CASHIER WHERE Deleted = 0 AND CashNo = '" & CashNo & "'"
			.Open strSql, conn, adOpenStatic, adLockReadOnly 
			if not .eof then
				CashDepart = GetString(.fields("CashDepart"))
				CashCode = GetString(.fields("CashCode"))
				CashDate = Str2Date(.fields("CashDate"))
				CashDebit = GetString(.fields("CashDebit"))
				CashAmount = GetLong(.fields("CashAmount"))
				CashTaxName = GetString(.fields("CashTaxName"))
				CashTax = GetLong(.fields("CashTax"))
				CashPayTo = GetString(.fields("CashPayTo"))
				CashParty = GetString(.fields("CashParty"))
				CashPurpose = GetString(.fields("CashPurpose"))
				CashTerm = GetString(.fields("CashTerm"))
				CashMember = GetString(.fields("CashMember"))
				CashContent = GetString(.fields("CashContent"))
				CashEffect = GetString(.fields("CashEffect"))
				CashMemo = GetString(.fields("CashMemo"))
				Remarks = GetString(.fields("Remarks"))
				Description = GetString(.fields("Description"))
				
				Proposer = GetString(.fields("Proposer"))
				Proposed = GetDate(.fields("Proposed"))
				Confirmer = GetString(.fields("Confirmer"))
				ConfirmDate = GetDate(.fields("ConfirmDate"))
				Shoper = GetString(.fields("Shoper"))
				ShopDate = GetDate(.fields("ShopDate"))
				Corper = GetString(.fields("Corper"))
				CorpDate = GetDate(.fields("CorpDate"))
				Reviewer = GetString(.fields("Reviewer"))
				ReviewDate = GetDate(.fields("ReviewDate"))
				
				CashPayer = GetString(.fields("CashPayer"))
				CashPayDate = GetDate(.fields("CashPayDate"))
				Permiter = GetString(.fields("Permiter"))
				PermitDate = GetDate(.fields("PermitDate"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
		end with
	end if
	
	AccountMonth = CheckAccountMonth()
	AccountMonth = left(AccountMonth, 4) & "/" & right(AccountMonth, 2)
%>
<HTML>
<HEAD>
	<TITLE>��v�`�[</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT>
	<script language = vbscript>
		function ShowList(mode)
			set win = window.open("CashierSearch.asp?mode=" & mode,"CashierSearch","resizable=1,scrollbars=1,width=600,height=600")
			win.focus()
		end function
		
		sub DoSave(mode)
		dim buf
		dim msg
			msg = "�m�F���b�Z�[�W"
			if checkDate("CashDate", "���Z��", 1) = false then exit sub
			if left(frmInput.CashDate.value, 7) <= "<%=AccountMonth%>" then
				frmInput.CashDate.focus()
				msgbox "�Y�����x�͊��Ɍ����߂���Ă��܂��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkNum("CashAmount","���Z���z", mode * 2) = false then exit sub
			if checkNum("CashTax","�����", 0) = false then exit sub
			if checkText("CashPayTo","�x����", mode) = false then exit sub
			if checkText("Description","�E�v", 0) = false then exit sub
			if checkText("CashParty","�����", 0) = false then exit sub
			if checkText("CashPurpose","�ړI", 0) = false then exit sub
			if checkText("CashTerm","����", 0) = false then exit sub
			if checkText("CashMember","���s��", 0) = false then exit sub
			if checkText("CashContent","���e", 0) = false then exit sub
			if checkText("CashEffect","����", 0) = false then exit sub
			if checkText("CashMemo","�`�[����", 0) = false then exit sub
			if checkLen("CashMemo","�`�[����", 250) = false then exit sub
			if mode < 0 then
				if checkText("CashMemo","�`�[����", 1) = false then exit sub
				if msgbox ("�Y����v�`�[���������Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			elseif mode > 1 then
				if msgbox ("�Y����v�`�[�����F���Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			elseif mode = 1 then
				if msgbox ("�Y����v�`�[���o���Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub CashDate_OnBlur()
			frmInput.CashDate.value = SetDate(frmInput.CashDate.value)
		end sub
		sub CashAmount_OnBlur()
			frmInput.CashAmount.value = formatnumber(GetLong(frmInput.CashAmount.value),0,true)
			Call CalculateTax()
		end sub
		sub CashTax_OnBlur()
			frmInput.CashTax.value = formatnumber(GetLong(frmInput.CashTax.value),0,true)
		end sub
		sub CashTaxName_OnChange()
			Call CalculateTax()
		end sub
		sub CalculateTax()
		dim buf, tax
			tax = GetTaxRate(frmInput.CashTaxName.options(frmInput.CashTaxName.selectedIndex).text)
			tax = fix(GetLong(frmInput.CashAmount.value) * tax / (1 + tax))
			frmInput.CashTax.value = formatnumber(tax, 0, true)
		end sub
		
		sub InitForm()
<%if (myCashier = 0 and Status > 1) or CashPayer <> "" then%>
			call LockAll()
<%end if%>
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then 
				if not isnull(window.parent) then window.close()
			end if
		end sub
	</script>
</HEAD>

<BODY LEFTMARGIN=50 TOPMARGIN=30 class=pt9 onload="InitForm()" onkeydown="DoShortCut()">
	<FORM NAME="frmInput" METHOD="POST" ACTION="CashierSave.asp">
		<input type=hidden name="CashType" value="0">
		<input type=hidden name=mode value="1">
		<table width=700 CELLPADDING=0 CELLSPACING=0>
			<tr height=100>
				<td width=300>
					<table border=0 width=100% style="filter:progid:DXImageTransform.Microsoft.Shadow(Color=#E0E0E0,Direction=120,strength=3)">
						<tr height=25><td class=pt12n><%=gsCorpName%>
						<tr height=45><td class=pt16 align=center><b>�o�@��@�`�@�[</b>
					</table>
				<td width=270>
					<table width=270 BORDER=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0>
						<TR align=center height=25 class=pt9n>
							<TD>��@��
							<TD>�Ё@��
							<TD>��@��
							<TD>������
							<TD>�N�@�[
						<TR align=center height=50 class=pt9r>
							<%=ShowUserSign(Reviewer, ReviewDate)%>
							<%=ShowUserSign(Corper, CorpDate)%>
							<%=ShowUserSign(Confirmer, ConfirmDate)%>
							<%=ShowUserSign(Shoper, ShopDate)%>
							<%=ShowUserSign(Proposer, Proposed)%>
					</table>
				
				<td width=140 align=right>
					<table width=110 BORDER=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
						<TR align=center height=25>
							<TD>�o�@�[
							<TD>���@�F
						<TR align=center height=50 class=pt9r>
							<%=ShowUserSign(CashPayer, CashPayDate)%>
							<%=ShowUserSign(Permiter, PermitDate)%>
					</table>
		</table>
			  
		<table width=700 border=1 bordercolor=#006400 CELLPADDING=0 CELLSPACING=0>
			<tr><td colspan=2>
				<table width=100% border=1 frame=void bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<TR ALIGN=CENTER height=25>
						<TD class=voucher>�` �[ �� ��
<%if CashNo = "" then%>
						<TD class=voucher>�� �� �� ��
<%else%>
						<TD class=voucher>�� �� �� ��
<%end if%>
						<TD class=voucher>�o �� �� ��
						<TD class=voucher>�� �Z ��
						<TD class=voucher>�� �Z �� �z
						<TD class=voucher>�� �� �� ��
					<TR ALIGN=CENTER height=30>
<%if CashNo = "" then%>
						<TD class=pt9n>�����A��
	<%if myLevel > 3 then%>
						<TD><select name="CashDepart" OnKeyDown="ResetEnter()"><%=ShowDepartList(CashDepart)%></select>
	<%else%>
		<%select case WebUserID
		  case 33, 34, 36, 46, 47 %>
						<TD><select name="CashDepart" OnKeyDown="ResetEnter()">
			<%if WebUserID=33 or WebUserID=34 then%><option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�<%end if%>
			<%if WebUserID<>36 then%><option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o<%end if%>
			<%if WebUserID<>47 then%><option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��<%end if%>
								<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
							</select>
		<%case 88%>
						<TD><select name="CashDepart" OnKeyDown="ResetEnter()">
								<option value="4" <%if CashDepart = "4" then response.write "selected"%>>�ېőq��
								<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
								<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
							</select>
		<%case else%>
						<TD><%=Code2Depart(CashDepart)%><input type=hidden name="CashDepart" value="<%=CashDepart%>">
		<%end select%>
	<%end if%>
<%else%>
						<TD><input class=si name="CashNo" value="<%=CashNo%>" size=10 OnKeyDown="ResetEnter()" readonly>
						<TD><%=Code2Depart(CashDepart)%><input type=hidden name="CashDepart" value="<%=CashDepart%>">
<%end if%>
						<TD><select name="CashDebit" OnKeyDown="ResetEnter()"><%=ShowCategory("CashAccount", CashDebit, 1)%></select>
						<TD><input class=si maxlength=10 size=9 name="CashDate" value="<%=CashDate%>" OnKeyDown="ResetEnter()"
							<%if Status = 0 or (myCashier > 0 and CashPayer = "")  then%> onclick="setday(this)"<%end if%>>
						<TD><input class=sn maxlength=11 size=10 name="CashAmount" value="<%=formatnumber(CashAmount, 0, true)%>" OnKeyDown="ResetEnter()">�~
						<TD><select name="CashTaxName" onkeydown="ResetEnter()" <%if Status > 1 then response.write "disabled" %>>
										<%=ShowCategoryList("TaxCode", CashTaxName, 1)%></select>
								<input class=sn maxlength=11 size=8 name="CashTax" value="<%=formatnumber(CashTax, 0, true)%>" OnKeyDown="ResetEnter()">�~
				</table>
			<tr><td>
				<table width=100% border=1 frame=void bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<colgroup span=2 align=center>
					<TR height=30>
						<TD width=20% style="cursor:hand" class=pt9b onmousedown="ShowList(12)">�x����
						<TD width=80%><input class=sj maxlength=100 size=48 name="CashPayTo" value="<%=CashPayTo%>" OnKeyDown="ResetEnter()">
					<TR height=30>
						<TD style="cursor:hand" class=pt9b onmousedown="ShowList(13)">�E�@�v
						<TD><input class=sj maxlength=100 size=48 name="Description" value="<%=Description%>" OnKeyDown="ResetEnter()">
					<TR height=30>
						<TD>�ځ@�I
						<TD><input class=sj maxlength=100 size=48 name="CashPurpose" value="<%=CashPurpose%>" OnKeyDown="ResetEnter()">
					<TR height=30>
						<TD>���@��
						<TD><input class=sj maxlength=100 size=48 name="CashTerm" value="<%=CashTerm%>" OnKeyDown="ResetEnter()">
					<TR height=30>
						<TD>�����
						<TD><input class=sj maxlength=100 size=48 name="CashParty" value="<%=CashParty%>" OnKeyDown="ResetEnter()">
					<TR height=30>
						<TD>���s��
						<TD><input class=sj maxlength=100 size=48 name="CashMember" value="<%=CashMember%>" OnKeyDown="ResetEnter()">
					<TR height=30>
						<TD>���@�e
						<TD><input class=sj maxlength=100 size=48 name="CashContent" value="<%=CashContent%>" OnKeyDown="ResetEnter()">
					<TR height=30>
						<TD>���@��
						<TD><input class=sj maxlength=100 size=48 name="CashEffect" value="<%=CashEffect%>" OnKeyDown="ResetEnter()">
				</table>
			<td>
				<table width=100% border=1 frame=void bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<colgroup span=2 align=center>
					<TR height=120>
						<TD width=20%>���@��<br>(��o��)
						<TD width=80%><textarea class=sj name="CashMemo" rows=8 style="width:250"><%=CashMemo%></textarea>
					<TR height=120 class=pt9>
						<TD>���@�l<br>(�o�[��)
						<TD><textarea class=sj name="Remarks" rows=8 style="width:250" readonly><%=Remarks%></textarea>
				</table>			
		</table>
	</FORM>
	<table width=700 CELLPADDING=0 CELLSPACING=0>
		<tr><td width=300 class=pt9n><%if Creater <> "" then%>
				<font class=pt9g>�쐬�ҁF</font><%=GetEmployName(Creater, "F")%>�@
				<font class=pt9g>�쐬���F</font><%=FmtDateTime(Created)%><%end if%>
			<td width=400 align=right>
<%if CashNo = "" then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnSave value="�V�K�o�^" onclick="DoSave(0)">
			<input type=button class=pt9n style="width:100;height:35" name=btnClose value="�� �o ��" onclick="DoSave(1)">
<%elseif Proposer = "" then		'����o
	if WebUserID = Creater then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnSave value="�X�V�ۑ�" onclick="DoSave(0)">
			<input type=button class=pt9n style="width:100;height:35" name=btnClose value="�� �o ��" onclick="DoSave(1)">
	<%end if
elseif CashPayer = "" then		'���o�[
	if myLevel > 1 then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnUnLock value="��o����" onclick="DoSave(-1)">
<%	end if
end if
if Shoper = "" then
	if myLevel > 2 or GetShoperID(CashDepart) = WebUserID then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnClose value="��������" onclick="DoSave(2)">
<%	end if
end if%>
	</table>
	<br><br>
<%if CashDebit = "997" or CashCredit = "997" then%>
	<br><br>
	<table>
		<table width=700 border=1 bordercolor=#006400 CELLPADDING=0 CELLSPACING=0 class=pt9n>
			<colgroup align=center>
			<colgroup align=left>
			<colgroup align=right>
			<colgroup align=center class=pt9r>
			<colgroup align=left>
			<colgroup align=right>
			<colgroup align=center class=pt9r>
			<TR ALIGN=CENTER height=25>
				<TD class=voucher>�`�[�ԍ�
				<TD class=voucher align=center>�� �� ��
				<TD class=voucher align=center>�ؕ����z
				<TD class=voucher width=50>�� ��
				<TD class=voucher align=center>�� �� ��
				<TD class=voucher align=center>�ݕ����z
				<TD class=voucher width=50>�o �[
<%
	sumDebit = 0:	sumCredit = 0
	with Recset
		strSQL = "SELECT CashDepart, CreditDepart, CashNo, Debit, Credit, CashAmount, CashDebit, Shoper, CashPayer FROM TBL_CORP_CASHIER AS C "
		strSQL = strSQL & " INNER JOIN (SELECT CTGR_CD, CTGR_NAME AS Debit FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS A ON C.CashDebit = A.CTGR_CD"
		strSQL = strSQL & " LEFT JOIN (SELECT CTGR_CD, CTGR_NAME AS Credit FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS B ON C.CashCredit = B.CTGR_CD"
		if CreditNo = "" then 
			strSQL = strSQL & " WHERE Deleted = 0 AND (CashNo = '" & CashNo & "' OR CreditNo = '" & CashNo & "')"
		else
			strSQL = strSQL & " WHERE Deleted = 0 AND (CashNo = '" & CreditNo & "' OR CreditNo = '" & CreditNo & "')"
		end if
		strSQL = strSQL & " ORDER BY CashDebit, CashNo"
		.Open strSql,conn,adOpenStatic,adLockReadOnly 
		do while not .eof
			if GetString(.fields("CashDebit")) = "997" then
				myDebit = 0
				myCredit = GetLong(.fields("CashAmount"))
				clsDebit = "pt9"
				clsCredit = "pt9n"
			else
				myCredit = 0
				myDebit = GetLong(.fields("CashAmount"))
				clsDebit = "pt9n"
				clsCredit = "pt9"
			end if
			myCashNo = GetString(.fields("CashNo"))
			if myCashNo = CashNo then 
				clsDebit = "pt9b"
				clsCredit = "pt9b"
			end if
%>
			<TR height=50>
				<TD <%if myCashNo = CashNo then response.write "class=pt9b"%>><%=myCashNo%>
				<TD class=<%=clsDebit%>>&nbsp;<%=Code2Depart(.fields("CashDepart"))%>�@<%=GetString(.fields("Debit"))%>
				<TD nowrap class=<%=clsDebit%>>\<%=formatnumber(myDebit, 0, true)%>&nbsp;
			<%if GetString(.fields("Shoper")) <> "" then%>
				<TD background=img/hanko.gif><%=GetString(.fields("Shoper"))%>
			<%else%>
				<TD><BR>
			<%end if%>
				<TD class=<%=clsCredit%>>&nbsp;<%=Code2Depart(.fields("CreditDepart"))%>�@<%=GetString(.fields("Credit"))%>
				<TD nowrap class=<%=clsCredit%>>\<%=formatnumber(myCredit, 0, true)%>&nbsp;
			<%if GetString(.fields("CashPayer")) <> "" then%>
				<TD background=img/hanko.gif><%=GetString(.fields("CashPayer"))%>
			<%else%>
				<TD><BR>
			<%end if%>
<%
			sumDebit = sumDebit + myDebit
			sumCredit = sumCredit + myCredit
			.movenext
		loop
		.close
	end with
%>
			<TR height=50>
				<TD colspan=2><br><TD nowrap>\<%=formatnumber(sumDebit, 0, true)%>&nbsp;
				<TD colspan=2><br><TD nowrap>\<%=formatnumber(sumCredit, 0, true)%>&nbsp;
				<TD><%=formatnumber(sumDebit - sumCredit, 0, false)%><br>
	</table>
<%end if%>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>
