<%
dim Conn
dim strSql
dim Recset
dim i
dim j

if WebUserID = 16 then UserShop = "M"

dim gsCorpName
	gsCorpName = "�f����p�������"

dim typCash(1)
	typCash(0) = "�o��`�["
	typCash(1) = "��v�`�["
	
dim gsProfitCode
dim gsProfitName
	gsProfitCode = "000"
	gsProfitName = "����e���v"

function CheckVoucherLevel()
	select case WebUserID
	case 1
		CheckVoucherLevel = 5
	case 2
		CheckVoucherLevel = 4
	case 3
		CheckVoucherLevel = 3
	case 4
		CheckVoucherLevel = 2
	case 5
		CheckVoucherLevel = 1
	case 6
		CheckVoucherLevel = 1
	case else							'��ʎЈ�
		CheckVoucherLevel = 0
	end select
end function

function CheckCashierLevel()
	select case WebUserID
	case 1							'�Ǘ�
		CheckCashierLevel = 3
	case 2							'����
		CheckCashierLevel = 2
	case 3							'�o�[
		CheckCashierLevel = 1
	case else						'�ق�
		CheckCashierLevel = 0
	end select
end function

function GetShoperID(myDepart)
	select case myDepart
	case "1":	GetShoperID = 46
	case "2":	GetShoperID = 46
	case "3":	GetShoperID = 46
	case "4":	GetShoperID = 16
	case "6":	GetShoperID = 32
	case "1103":	GetShoperID = 24
	case "2203":	GetShoperID = 73
	end select
end function

function GetPayerID(myDepart)
	select case myDepart
	case "1", "3"
		if WebUserID = 33 or WebUserID = 34 then GetPayerID = 1
	case "2"
		if WebUserID = 33 or WebUserID = 34 or WebUserID = 88 then GetPayerID = 1
	case "4"
		if WebUserID = 88 then GetPayerID = 1
	case "6"
		if WebUserID = 33 or WebUserID = 34 or WebUserID = 69 or WebUserID = 88 then GetPayerID = 1
	case "1103"
		if WebUserID = 69 then GetPayerID = 1
	case "2203"
		if WebUserID = 73 then GetPayerID = 1
	end select
end function

function GetCashInit(myDepart)
dim buf
	buf = GetString(myDepart)
	if len(buf) = 1 then 
		buf = "0" & buf
	else
		buf = left(buf, 2)
	end if
	GetCashInit = buf
end function

'=============================
'	���ʕ�
'=============================

Sub ShowMessage(myMsg)
	Response.Write ("<HTML><SCRIPT LANGUAGE=JavaScript>alert(" & chr(34) & myMsg & chr(34) & ");window.history.back();</SCRIPT></HTML>")
	Response.End 
End Sub

Function GetPost(myData)
on error resume next
dim buf
	GetPost = "ERROR"
	buf = lcase(GetString(myData))
	if instr(buf, " ") = 0 then
	   	GetPost = GetString(myData)
	elseif instr(buf, "exec") = 0 and _
	   instr(buf, "update") = 0 and _
	   instr(buf, "insert") = 0 and _
	   instr(buf, "delete") = 0 and _
	   instr(buf, "script") = 0 then
	   	GetPost = GetString(myData)
	end if
End Function

Function FitSel(myData)
on error resume next
dim buf
	buf = GetString(myData)
	FitSel = replace(buf, "'", "''")
End Function

function GetClientIP()
	GetClientIP = request.servervariables("HTTP_X_FORWARDED_FOR")
	if GetClientIP = "" then
		GetClientIP = request.servervariables("REMOTE_ADDR")
	end if
end function

Function GetLong(myData)
on error resume next
	GetLong = 0
	if isnumeric(myData) then GetLong = clng(myData)
End Function

Function GetDouble(myData)
on error resume next
	GetDouble = 0
'	if isnumeric(myData) then GetDouble = cdbl(myData)
	GetDouble = cdbl(myData)
End Function

Function GetString(myData)
on error resume next
	GetString = trim(cstr(myData & ""))
End Function

Function GetDate(myData)
on error resume next
	GetDate = ""
	if isdate(myData) then	GetDate = cdate(myData)
End Function

Function ResetString(myStr)
on error resume next
	ResetString = replace(myStr, "'", "''")
End Function

Function ResetBoolean(myBln)
on error resume next
	if myBln = true then
		ResetBoolean = 1
	else
		ResetBoolean = 0
	end if
End Function


Function GetLeft(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeft = buf
End Function

Function GetLeftRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeftRev = buf
End Function

Function GetRight(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRight = buf
End Function

Function GetRightRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRightRev = buf
End Function


function Str2Date(myData)
	if GetString(myData) <> "" then Str2Date = mid(myData,1,4) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2YMD(myData)
	if GetString(myData) <> "" then Str2YMD = mid(myData,3,2) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2MD(myData)
	if GetString(myData) <> "" then Str2MD = mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2DateS(myData)
dim dt
	if GetString(myData) <> "" then 
		dt = Str2Date(myData)
		Str2DateS = year(dt) & gsDateSign & month(dt) & gsDateSign & day(dt)
	end if
end function 

function Date2Str(myData)
dim dt
	Date2Str = ""
	if not isDate(myData) then exit function
	dt = cdate(myData)
	Date2Str = year(dt) & right("00" & month(dt),2) & right("00" & day(dt),2) 
end function 



Function Time2Code(myTime)
Dim h, n, s
    h = Num2Code(Hour(myTime))
    n = Right("00" & Minute(myTime), 2)
    s = Right("00" & Second(myTime), 2)
    Time2Code = Date2Code(myTime) & h & n & s
End Function

Function Date2Code(myDate)
Dim y, m, d
    y = Num2Code(Year(myDate) - 2000)
    m = Num2Code(Month(myDate))
    d = Num2Code(Day(myDate))
    Date2Code = y & m & d
End Function

Function Num2Code(myNum)
    If myNum < 10 Then
        Num2Code = myNum
    Else
        Num2Code = Chr(myNum + 55)
    End If
End Function

function stringCut(myStr,myLen)
on error resume next
	stringCut = trim(myStr & "")
	if len(stringCut) > myLen then
		stringCut = left(stringCut,myLen - 3) & "..."
	end if	
end function

function StringCutRev(myStr,myLen)
on error resume next
	StringCutRev = trim(myStr & "")
	if len(StringCutRev) > myLen then
		StringCutRev = "..." & right(StringCutRev,myLen)
	end if	
end function

function ShowTitle(myStr,myLen)
on error resume next	
	ShowTitle = trim(myStr & "")
	if len(ShowTitle) > myLen then
		ShowTitle = " title='" & stringReset(ShowTitle) & "'"
	else
		ShowTitle = ""
	end if
end function

function stringReset(myStr)
on error resume next	
	stringReset = replace(myStr, "'", "�f")
end function


function formatDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDate = ""
		exit function
	end if		
	formatDate = year(myDate) & gsDateSign & right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function

function formatShortDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatShortDate = ""
		exit function
	end if
	formatShortDate = right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function


function FmtDateTime(myDate)
on error resume next
	FmtDateTime = ""
	if isdate(myDate) then
		FmtDateTime = year(myDate) & gsDateSign & _
					  right("00" & month(myDate),2) & gsDateSign & _
					  right("00" & day(myDate),2) & " " & _
					  right("00" & hour(myDate),2) & ":" & _
					  right("00" & minute(myDate),2)
	end if
end function

function FmtTime(myDate)
on error resume next
	FmtTime = ""
	if isdate(myDate) then
		FmtTime = year(myDate) & gsDateSign & _
					  month(myDate) & gsDateSign & _
					  day(myDate) & " " & _
					  hour(myDate) & ":" & _
					  minute(myDate)
	end if
end function

function ShowDateTimeShort(myDate)
on error resume next
	ShowDateTimeShort = ""
	if isdate(myDate) then
		ShowDateTimeShort = right("00" & month(myDate),2) & gsDateSign & _
					  		right("00" & day(myDate),2) & " " & _
					  		right("00" & hour(myDate),2) & ":" & _
					  		right("00" & minute(myDate),2)
	end if
end function

function GetMonthLastDay(dt)
on error resume next
dim tpDate
	GetMonthLastDay = ""

	if not isdate(dt) then exit function
	
	if len(dt) = 10 then
		y = left(dt,4)
		m = mid(dt,6,2)
		tpDate = dateAdd("m",1,y & gsDateSign & m & gsDateSign & "01")			
		GetMonthLastDay = dateAdd("d",-1,tpDate)
	end if

end function

Function GetCurrentPage(myConn, table, field, myType, data, sWhere)
dim myRec
dim mySql
	GetCurrentPage = 0
	if myType = 1 then data = "'" & replace(data,"'","''") & "'"	
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT Count(" & field & ") FROM " & table & _
				" WHERE " & field & " < " & data & sWhere
		.Open mySql, myConn, adOpenKeyset , adLockOptimistic
		GetCurrentPage = (CLng (.Fields(0)) \ lngPageSize) + 1
		.Close
	end with
	set myRec = Nothing
end Function

Function CheckDBRepeat(myConn, table, field, data, myType, keyfield, key)
dim myRec
dim mySql
	if myType = 1 then data = "'" & replace(data,"'","''") & "'"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT " & field & " FROM " & table & _
				" WHERE QDEL = 0" & _
				" AND " & field & " = " & data
		if key <> 0 then mySql = mySql & " AND " & keyfield & " <> " & key
		.Open mySql, myConn, adOpenKeyset , adLockOptimistic
		if .eof then
			CheckDBRepeat = false
		else
			CheckDBRepeat = true
		end if
		.Close
	end with
	set myRec = Nothing
end Function


function formatDateEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateEng = ""
		exit function
	end if
	formatDateEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate)) & ", " & year(myDate)
end function

function formatEngDate(myDate)
on error resume next
	if not isdate(myDate) then
		formatEngDate = ""
		exit function
	end if
	formatEngDate = GetMonth(month(myDate)) & "." & GetDay(day(myDate)) & "." & year(myDate)
end function

function formatDateShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateShortEng = ""
		exit function
	end if
	formatDateShortEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate))
end function

function ShowDateTimeShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		ShowDateTimeShortEng = ""
		exit function
	end if
	ShowDateTimeShortEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate)) & ", " & _
					       right("00" & hour(myDate),2) & ":" & right("00" & minute(myDate),2)
end function

function GetDay(myNo)
	select case myNo
	case 1, 21, 31:	GetDay = right("  " & myNo, 2) & "st"
	case 2, 22:		GetDay = right("  " & myNo, 2) & "nd"
	case 3, 23:		GetDay = right("  " & myNo, 2) & "rd"
	case else:		GetDay = right("  " & myNo, 2) & "th"
	end select
end function

function GetMonth(myNo)
	select case myNo
	case 1:		GetMonth = "Jan"
	case 2:		GetMonth = "Feb"
	case 3:		GetMonth = "Mar"
	case 4:		GetMonth = "Apr"
	case 5:		GetMonth = "May"
	case 6:		GetMonth = "Jun"
	case 7:		GetMonth = "Jul"
	case 8:		GetMonth = "Aug"
	case 9:		GetMonth = "Sep"
	case 10:	GetMonth = "Oct"
	case 11:	GetMonth = "Nov"
	case 12:	GetMonth = "Dec"
	end select
end function

Function ResetDigital(myData, myDigital, myMode)
Dim pos, buf
    buf = GetDouble(myData)
    If buf <> 0 Then
        For pos = 1 To GetLong(myDigital)
            buf = buf * 10
        Next
        Select Case GetLong(myMode)
        Case -1             '�؂�̂�
            buf = Fix(buf + 0.00001)
        Case 0              '�l�̌ܓ�
            buf = CLng(FormatNumber(buf, 0, True))
        Case 1              '�؂�グ
            If abs(buf - Fix(buf)) < 0.00001 Then
                buf = Fix(buf) + 1
            End If
        End Select
        For pos = 1 To GetLong(myDigital)
            buf = buf / 10
        Next
    End If
    ResetDigital = buf
End Function


'=============================
'	��{�}�X�^��
'=============================
function ShowCategoryList(myCode, myDft, myMode)
dim mySql
dim myRec
dim myCon
dim myBCD
dim buf

	buf = ""
	select case myCode
	case "ChargeType":		myBCD = "001"			'�����敪
	case "ChargeUnit": 		myBCD = "002"			'�����P��
	case "TaxCode": 		myBCD = "003"			'�ېŋ敪
	case "Delivery": 		myBCD = "004"			'�[�i���@
	case "JobType": 		myBCD = "005"			'��ƌ`��
	case "ChargeBelong":	myBCD = "006"			'����敪
	case "VoucherType":		myBCD = "007"			'�`�[�敪
	case "Securities":		myBCD = "008"			'�x�����@
	case "ExpenseAttr":		myBCD = "009"			'��p�敪
	case else: 				myBCD = "000"			'�s��
	end select 
	
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT CTGR_CD, CTGR_NAME, CTGR_ENAME, CTGR_NUM, CTGR_FLAG FROM MST_CATEGORY" 
	mySql = mySql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = '" & myBCD & "'"
	if myMode <> 0 then mySql = mySql & " AND CTGR_FLAG = 1"
	mySql = mySql & " ORDER BY CTGR_CD"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & chr(34) & myRec.fields("CTGR_NAME") & chr(34)
		if myRec.fields("CTGR_NAME") = myDft then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("CTGR_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
	ShowCategoryList = buf	
end function

function Code2Depart(myCode)
dim mySql
dim myRec
dim myCon
	Code2Depart = "���ׂ�"
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	mySql = "SELECT CTGR_NAME FROM MST_CATEGORY WHERE CTGR_DELETED = 0"
	mySql = mySql & " AND CTGR_BASE = 11 AND CTGR_CD = '" & myCode & "'"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then Code2Depart = myRec.fields("CTGR_NAME")
	myRec.close
	set myRec = nothing	
	CloseDB myCon
end function

function ShowDepartList(myDft)
dim mySql
dim myRec
dim myCon
dim buf
	buf = ""
	OpenSQL myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	mySql = "SELECT CTGR_CD, CTGR_NAME FROM MST_CATEGORY WHERE CTGR_DELETED = 0"
	mySql = mySql & " AND CTGR_BASE = 11 AND CTGR_FLAG <> 0 ORDER BY CTGR_NUM"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("CTGR_CD")
		if myRec.fields("CTGR_CD") = myDft then buf = buf & " selected"
		'buf = buf & ">" & ShowDepartCode(myRec.fields("CTGR_CD"))
		buf = buf & ">" & myRec.fields("CTGR_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	ShowDepartList = buf
end function

function ShowDepartCode(myCode)
dim cd
	cd = right("000" & myCode, 4)
	ShowDepartCode = left(cd, 2) & "-" & right(cd, 2)
end function

function GetDepartCode()
	GetDepartCode = ""
	if WebUserID = 16 then 
		GetDepartCode = "4"
	elseif  WebUserID = 18 then 
		GetDepartCode = "1103"
	else 
		select case GetLong(session("ShopID"))
		case 2
			select case GetString(session("Depart"))
			case "�ʊ֗A�o��":	GetDepartCode = "1"
			case "�ʊ֗A����":	GetDepartCode = "2"
			case "�c�ƕ�":		GetDepartCode = "3"
			case else:			GetDepartCode = "6"
			end select
		case 3:		GetDepartCode = "1103"
		case 4:		GetDepartCode = "2203"
		case 5:		GetDepartCode = "4"
		end select
	end if
end function

function ShowEmployList(myDpt, myID)
dim mySel
dim mySql
dim myRec
dim myCon
dim myDepart
dim buf

	buf = ""
	if WebUserID = 29 or WebUserID = 36 or WebUserID = 47 then
		buf = "<option value=" & WebUserID
		if WebUserID = myID then buf = buf & " selected"
		buf = buf & ">" & session("FamilyName")
	end if
	OpenSQL myCon, SqlServerName, "WebMaster"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	mySql = "SELECT WebUserID, UserCode, FamilyName FROM MstWebUser WHERE Deleted = 0 AND ShopGroupID = 2"
	select case CheckCashierLevel()
	case 1:		mySql = mySql & " AND ShopID = " & session("ShopID")
	case 0
		myLevel = CheckVoucherLevel()
		if myLevel < 3 then
			if myLevel = 2 then
				select case WebUserID
				case 36
					mySql = mySql & " AND Depart = '�ʊ֗A����' AND ShopID = " & session("ShopID")
				case 47
					mySql = mySql & " AND Depart = '�ʊ֗A�o��' AND ShopID = " & session("ShopID")
				case else
					mySql = mySql & " AND ShopID = " & session("ShopID")
				end select
			else
				mySql = mySql & " AND WebUserID = " & WebUserID
			end if
		end if
	end select
	mySql = mySql & " ORDER BY Depart, SecurityLevel, UserKana"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & myRec.fields("WebUserID")
		if myRec.fields("WebUserID") = myID then buf = buf & " selected"
		buf = buf & ">" & myRec.fields("FamilyName")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
	ShowEmployList = buf
end function

function GetEmployName(myID, myMode)
dim myRec
dim myCon
	GetEmployName = ""
	if GetLong(myID) = 0 then exit function
	
	Opensql myCon, SqlWMServerName, "WebMaster"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	myRec.Open "SELECT UserName, FamilyName, EnglishName, NickName FROM MstWebUser WHERE WebUserID = " & myID, myCon, adOpenKeyset, adLockReadOnly
	GetEmployName = "�s��"
	if not myRec.eof then
		select case myMode
		case "E":		GetEmployName = GetString(myRec.fields("EnglishName"))
		case "F":		GetEmployName = GetString(myRec.fields("FamilyName"))
		case "N":		GetEmployName = GetString(myRec.fields("NickName"))
		case "U":		GetEmployName = GetString(myRec.fields("UserName"))
		end select
	end if
	myRec.close
	set myRec = nothing	
	CloseDB myCon
end function

function GetCountryName(myCD)
dim myRec
dim myCon

	GetCountryName = ""
	OpenSQL myCon, SqlServerName, DataBaseName

	set myRec = Server.CreateObject ("ADODB.Recordset")
	myRec.Open "SELECT CN_ENAME FROM MST_COUNTRY WHERE CN_CD = '" & myCD & "'", myCon, adOpenKeyset, adLockReadOnly
	if not myRec.eof then GetCountryName = GetString(myRec.fields("CN_ENAME"))
	myRec.close
	set myRec = nothing	
	CloseDB myCon
end function


'�ďo��F 	ChargerSearch.asp 	�ڋq��񌟍����
'			ChargeHead.asp 		�������`�[�w�b�_���
function FitDatePlus(myDate)
dim buf	
	buf = GetDate(myDate)
	if isdate(buf) then
		do while CheckHoliday(buf)
			buf = dateadd("d", 1, buf)
		loop
	end if
	FitDatePlus = buf
end function

'�ďo��F 	ChargerSearch.asp 	�ڋq��񌟍����
'			PaymentHead.asp 	�x���`�[�w�b�_���
function FitDateMinus(myDate)
dim buf
	buf = GetDate(myDate)
	if isdate(buf) then
		do while CheckHoliday(buf)
			buf = dateadd("d", -1, buf)
		loop
	end if
	FitDateMinus = buf
end function

'�ďo��F 	��L
function CheckHoliday(myDate)
dim mySql
dim myRec
dim myCon
dim buf
	CheckHoliday = 0
	buf = GetDate(myDate)
	if not isdate(buf) then exit function
	
	if weekday(buf) = 1 or weekday(buf) = 7 then
		CheckHoliday = 1 
	else
		OpenSQL myCon, SqlServerName, DatabaseName
		set myRec = Server.CreateObject ("ADODB.Recordset")
		with myRec				
			mySql = "SELECT Holiday FROM MST_HOLIDAY WHERE Deleted = 0 AND Holiday = '" & Date2Str(buf) & "'"
			.Open mySql, myCon, adOpenKeyset, adLockReadOnly
			if not .eof then CheckHoliday = 1
			.close
		end with
		set myRec = nothing	
		CloseDB myCon
	end if
end function

function ShowCategory(myCode, myDft, myMode)
dim mySql
dim myRec
dim myCon
dim myBCD
dim buf

	buf = ""
	select case myCode
	case "CashTax": 		myBCD = "003"			'�ېŋ敪
	case "CashType": 		myBCD = "008"			'�x���敪
	case "CashAccount":		myBCD = "010"			'��v�Ȗ�
	case else: 				myBCD = "000"			'�s��
	end select 
	
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	
	mySql = "SELECT CTGR_CD, CTGR_NAME, CTGR_ENAME, CTGR_NUM, CTGR_FLAG FROM MST_CATEGORY" 
	mySql = mySql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = '" & myBCD & "'"
	if myMode <> 0 then mySql = mySql & " AND CTGR_FLAG = 1"
	mySql = mySql & " ORDER BY CTGR_CD"
	myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
	do while not myRec.eof
		buf = buf & "<option value=" & chr(34) & myRec.fields("CTGR_CD") & chr(34)
		if myRec.fields("CTGR_CD") = myDft then buf = buf & " selected"
		'buf = buf & ">" & ShowCategoryCode(myRec.fields("CTGR_CD")) & " " & myRec.fields("CTGR_NAME")
		buf = buf & ">" & myRec.fields("CTGR_NAME")
		myRec.movenext
	loop
	myRec.close
	set myRec = nothing	
	CloseDB myCon
	
	ShowCategory = buf	
end function

function ShowCategoryCode(myCode)
dim tmp
	tmp = GetString(myCode)
	if len(tmp) < 5 then tmp = tmp & "�@"
	ShowCategoryCode = tmp
end function

function CheckCashProposed(myNo)
dim mySql
dim myRec
dim myCon
	CheckCashStatus = 0
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT CashNo FROM TBL_CORP_CASHIER WHERE Deleted = 0 AND Proposer <> '' AND CashNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckCashProposed = true
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

function CheckCashPaid(myNo)
dim mySql
dim myRec
dim myCon
	CheckCashPaid = false
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT CashNo FROM TBL_CORP_CASHIER WHERE Deleted = 0 AND CashPayer <> '' AND CashNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckCashPaid = true
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

function CheckCashSend(myNo)
dim mySql
dim myRec
dim myCon
	CheckCashSend = false
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT CashNo FROM TBL_CORP_CASHIER WHERE Deleted = 0 AND SendFlag <> 0 AND CashNo = '" & myNo & "'"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckCashSend = true
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

function GetAccountMonth(myMonth, myFrom, myTo)
dim buf
	if gsSysAccountDay = 99 then			'����
		myFrom = myMonth & "01"
		myTo = myMonth & "99"	
	else 									'1�`27��
		buf = cdate(left(myMonth,4) & gsDateSign & right(myMonth,2) & gsDateSign & "01")
		buf = dateadd("m", -1, buf)
		myFrom = left(Date2Str(buf), 6) & (gsSysAccountDay + 1)
		myTo = myMonth & gsSysAccountDay
	end if
end function


function ShowUserSign(myName, myDate)
	if myName = "" then
		ShowUserSign = "<TD><BR>"
	else
		ShowUserSign = "<TD style=""cursor:hand"" background=img/hanko.gif title='" & FmtDateTime(myDate) & "'>" & myName
	end if
end function

function CheckAccountMonth()
dim mySql
dim myRec
dim myCon
	CheckAccountMonth = ""
	OpenSQL myCon, SqlServerName, DatabaseName
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec				
		mySql = "SELECT AccountMonth FROM TBL_CTM_ACCOUNT WHERE Finished <> 0 ORDER BY AccountMonth DESC"
		.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not .eof then CheckAccountMonth = GetString(.fields("AccountMonth"))
		.close
	end with
	set myRec = nothing	
	CloseDB myCon
end function

function ShowAccountName(myName)
dim pos
	pos = instr(myName, "�E")
	if pos = 0 then
		ShowAccountName = myName
	else
		ShowAccountName = left(myName, pos - 1)
	end if
end function
%>