<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'----------------------------------------------
'	�Ɩ����ь��ʐ��ڕ\
'----------------------------------------------

dim CashDate
dim CashCount
dim CashCode()
dim CashAccount()
dim CashBudget()
dim CashResult()
	
	redim CashCode(0)
	redim CashAccount(0)
	CashCode(0) = gsProfitCode
	CashAccount(0) = gsProfitName
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT CTGR_NUM, MIN(CTGR_CD) AS CD, MIN(CTGR_NAME) AS NM FROM MST_CATEGORY"
		strSql = strSql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = 10 AND CTGR_NUM > 0"
		strSql = strSql & " GROUP BY CTGR_NUM ORDER BY CTGR_NUM"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		CashCount = 0
		do while not .EOF
			CashCount = CashCount + 1
			redim preserve CashCode(CashCount)
			redim preserve CashAccount(CashCount)
			CashCode(CashCount) = left(GetString(.fields("CD")), 3)
			CashAccount(CashCount) = GetString(.fields("NM"))
			.movenext
		loop
		.Close
	end with
	
	mode = GetLong(request("mode"))
	if mode = 0 then
		CashDate = dateadd("m", -1, date)
		SelYear = year(CashDate)
		SelMonth = month(CashDate)
	else
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
	end if
	CashMonth = SelYear & right("00" & SelMonth, 2)
	
	redim CashBudget(CashCount + 1, 7)
	redim CashResult(CashCount + 1, 7)
	with Recset
		strSql = "SELECT CashAccount, CashDepart, CashBudget, CashResult FROM TBL_CORP_BUDGET"
		strSql = strSql & " WHERE CashMonth = '" & CashMonth & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .EOF
			for i = 0 to CashCount
				if CashCode(i) = GetString(.fields("CashAccount")) then
					idx = 0
					select case GetString(.fields("CashDepart"))
					case "1":		idx = 1
					case "2":		idx = 2
					case "4":		idx = 3
					case "1103":	idx = 4
					case "2203":	idx = 5
					case "3":		idx = 6
					case "6":		idx = 7
					end select
					CashBudget(i, idx) = GetLong(.fields("CashBudget"))
					CashBudget(i, 0) = CashBudget(i, 0) + GetLong(.fields("CashBudget"))
					
					CashResult(i, idx) = GetLong(.fields("CashResult"))
					CashResult(i, 0) = CashResult(i, 0) + GetLong(.fields("CashResult"))
					
					if i > 0 and i < CashCount - 1 then
						CashBudget(CashCount + 1, idx) = CashBudget(CashCount + 1, idx) + GetLong(.fields("CashBudget"))
						CashBudget(CashCount + 1, 0) = CashBudget(CashCount + 1, 0) + GetLong(.fields("CashBudget"))
						
						CashResult(CashCount + 1, idx) = CashResult(CashCount + 1, idx) + GetLong(.fields("CashResult"))
						CashResult(CashCount + 1, 0) = CashResult(CashCount + 1, 0) + GetLong(.fields("CashResult"))
					end if
					exit for
				end if
			next
			.movenext
		loop
		.Close
	end with
	
	'�c�ƕ��S��
	CashBudget(CashCount - 1, 0) = CashBudget(CashCount - 1, 0) / 2
	CashResult(CashCount - 1, 0) = CashResult(CashCount - 1, 0) / 2
%>

<HTML>
<HEAD>
	<TITLE>����ʌo��\���Ώƕ\</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY topmargin=5 class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CashierReview.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value=1>
		<table class=pt9>
				<TD nowrap>�Ώ۔N�x
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) - 1 to year(date) + 1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>��&nbsp;
				<TD nowrap>
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
	<div id=list>
���Ώ۔N���F<font class=pt9g><%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��</font>
		<table border=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
			<colgroup bgcolor="#E0FFE0">
			<colgroup align=center>
			<colgroup span=8 align=right>
			<TR><TD class=voucher align=center colspan=2>����Ȗ�
				<TD class=voucher align=center width=100>�_�˗A�o
				<TD class=voucher align=center width=100>�_�˗A��
				<TD class=voucher align=center width=100>�ېőq��
				<TD class=voucher align=center width=100>���x�X
				<TD class=voucher align=center width=100>�����x�X
				<TD class=voucher align=center width=100>�_�ˉc��
				<TD class=voucher align=center width=100>�{�ЋƖ�
				<TD class=voucher align=center width=110>�S�Ѝ��v

			<TR height=22>
				<TD rowspan=2 width=150>�@<%=CashAccount(0)%>
				<TD width=50>�\
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashBudget(0, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashBudget(0, 0),0,true)%>
				
			<TR height=22 bgcolor="#FFE0E0">
				<TD>��
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashResult(0, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashResult(0, 0),0,true)%>

<%for i = 1 to CashCount - 2%>
			<TR height=22>
				<TD rowspan=2>�@<%=ShowAccountName(CashAccount(i))%>
				<TD>�\
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashBudget(i, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashBudget(i, 0),0,true)%>
			<TR height=22 bgcolor="#E0FFE0">
				<TD>��
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashResult(i, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashResult(i, 0),0,true)%>
<%next%>

			<TR height=22>
				<TD rowspan=2>�@���o��v
				<TD>�\
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashBudget(CashCount + 1, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashBudget(CashCount + 1, 0),0,true)%>
				
			<TR height=22 bgcolor="#E0FFE0">
				<TD>��
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashResult(CashCount + 1, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashResult(CashCount + 1, 0),0,true)%>

			<TR height=22>
				<TD rowspan=2>�@<%=ShowAccountName(CashAccount(CashCount - 1))%>
				<TD>�\
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashBudget(CashCount - 1, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashBudget(CashCount - 1, 0),0,true)%>

			<TR height=22 bgcolor="#E0E0FF">
				<TD>��
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashResult(CashCount - 1, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashResult(CashCount - 1, 0),0,true)%>
			<TR height=22>
				<TD rowspan=2 width=150>�@<%=CashAccount(CashCount)%>
				<TD width=50>�\
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashBudget(CashCount, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashBudget(CashCount, 0),0,true)%>

			<TR height=22 bgcolor="#FFE0E0">
				<TD>��
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashResult(CashCount, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashResult(CashCount, 0),0,true)%>
		</table>
	</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>


<%
function ShowAccountName(myName)
dim pos
	pos = instr(myName, "�E")
	if pos = 0 then
		ShowAccountName = myName
	else
		ShowAccountName = left(myName, pos - 1)
	end if
end function
%>