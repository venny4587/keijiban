<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'----------------------------------------------
'	�Ɩ����ь��ʐ��ڕ\
'----------------------------------------------

dim CashMonth
dim CashFrom
dim CashTo
dim CashSaved

dim CashDate
dim CashCount
dim CashCode()
dim CashAccount()
dim CashBudget()
dim CashResult()
dim CashDebit()
dim CashCredit()
dim CashRemarks()
	
	redim CashCode(0)
	redim CashAccount(0)
	CashCode(0) = gsProfitCode
	CashAccount(0) = gsProfitName
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT CTGR_NUM, MIN(CTGR_CD) AS CD, MIN(CTGR_NAME) AS NM FROM MST_CATEGORY"
		strSql = strSql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = 10 AND CTGR_NUM > 0"
		strSql = strSql & " GROUP BY CTGR_NUM ORDER BY CTGR_NUM"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		CashCount = 0
		do while not .EOF
			CashCount = CashCount + 1
			redim preserve CashCode(CashCount)
			redim preserve CashAccount(CashCount)
			CashCode(CashCount) = left(GetString(.fields("CD")), 3)
			CashAccount(CashCount) = GetString(.fields("NM"))
			.movenext
		loop
		.Close
	end with
	
	mode = GetLong(request("mode"))
	if mode = 0 then
		CashDepart = GetDepartCode()
		CashDate = dateadd("m", -1, date)
		SelYear = year(CashDate)
		SelMonth = month(CashDate)
		CashMonth = SelYear & right("00" & SelMonth, 2)
	else
		CashDepart = GetString(request("CashDepart"))
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
		CashMonth = SelYear & right("00" & SelMonth, 2)
		
		if mode = 2 then
			Conn.BeginTrans
			
			for i = 0 to CashCount
				with Recset
					strSql = "SELECT * FROM TBL_CORP_BUDGET WHERE CashMonth = '" & CashMonth & "'"
					strSql = strSql & " AND CashDepart = '" & CashDepart & "' AND CashAccount = '" & CashCode(i) & "'"
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
					if .eof then
						.AddNew
						.fields("CashMonth") = CashMonth
						.fields("CashDepart") = CashDepart
						.fields("CashAccount") = CashCode(i)
						
						.fields("Creater") = WebUserID
						.fields("Created") = now
					end if
					
					.fields("CashResult") = GetLong(Request("Cash" & i))
					.fields("Remarks") = GetPost(Request("Memo" & i))
					.fields("Updater") = WebUserID
					.fields("Updated") = now()
					
					.update
					.close
				end with
			next
			
			if err.number = 0 then
				Conn.CommitTrans
				msg = "������уf�[�^���X�V���܂����B"
			else
				Conn.RollbackTrans
				msg = "�������G���[���N����܂����B" & err.number & ":" & err.description
			end if
				
		end if
	end if
	
	call GetAccountMonth(CashMonth, CashFrom, CashTo)
	
	CashSaved = "�ۑ�"
	redim CashDebit(CashCount)
	redim CashCredit(CashCount)
	redim CashResult(CashCount)
	for i = 1 to CashCount
		CashDebit(i) = 0
		CashCredit(i) = 0
		CashResult(i) = 0
		with Recset
			strSQL = "SELECT SUM(CASE SUBSTRING(CashDebit,1,3) WHEN '" & CashCode(i) & "' THEN CashAmount ELSE 0 END) AS Debit,"
			strSQL = strSQL & "SUM(CASE SUBSTRING(CashCredit,1,3) WHEN '" & CashCode(i) & "' THEN CashAmount ELSE 0 END) AS Credit"
			strSQL = strSQL & " FROM TBL_CORP_CASHIER WHERE Deleted = 0 AND CashDate BETWEEN '" & CashFrom & "' AND '" & CashTo & "'"
			strSQL = strSQL & " AND ((CashDepart = '" & CashDepart & "' AND SUBSTRING(CashDebit,1,3) = '" & CashCode(i) & "')"
			strSQL = strSQL & " OR (CreditDepart = '" & CashDepart & "' AND SUBSTRING(CashCredit,1,3) = '" & CashCode(i) & "'))"
			strSQL = strSQL & " AND CashPayer <> ''"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if not .EOF then
				CashDebit(i) = GetLong(.fields("Debit"))
				CashCredit(i) = GetLong(.fields("Credit"))
				CashResult(i) = CashDebit(i) - CashCredit(i)
			end if
			.Close
		end with
	next
	
	redim CashBudget(CashCount)
	redim CashRemarks(CashCount)
	with Recset
		strSql = "SELECT CashAccount, CashBudget, CashResult, Remarks, Updater, Updated FROM TBL_CORP_BUDGET"
		strSql = strSql & " WHERE CashMonth = '" & CashMonth & "' AND CashDepart = '" & CashDepart & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then
			Updater = GetLong(.fields("Updater"))
			Updated = FmtDateTime(.fields("Updated"))
			do while not .EOF
				for i = 0 to CashCount
					if CashCode(i) = GetString(.fields("CashAccount")) then
						CashBudget(i) = GetLong(.fields("CashBudget"))
						if GetLong(.fields("CashResult")) <> 0 then
							CashSaved = "�X�V"
							CashResult(i) = GetLong(.fields("CashResult"))
						end if
						CashRemarks(i) = GetString(.fields("Remarks"))
						exit for
					end if
				next
				.movenext
			loop
		end if
		.Close
	end with
	
	if CashResult(CashCount - 1) = 0 then
		CashResult(CashCount - 1) = CashBudget(CashCount - 1)
	end if
	
	call GetDepartProfit(CashDepart, CashDebit(0), CashCredit(0))
	CashResult(0) = CashDebit(0) - CashCredit(0)
	
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
%>

<HTML>
<HEAD>
	<TITLE>����ʌo��\�Z����</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<script language=vbscript>
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
		end sub
		
<%for i = 0 to CashCount%>
		sub Cash<%=i%>_OnBlur()
			frmInput.Cash<%=i%>.value = formatnumber(GetLong(frmInput.Cash<%=i%>.value),0,true)
			call Calculate()
		end sub
<%next%>
		
		sub Calculate()
		dim buf
			buf = GetLong(frmInput.Cash0.value)
<%for i = 1 to CashCount - 1%>
			buf = buf - GetLong(frmInput.Cash<%=i%>.value)
<%next%>
<%if CashDepart = "6" then%>
			buf = buf + GetLong(frmInput.Cash<%=CashCount - 1%>.value) * 2
<%end if%>
			frmInput.Cash<%=CashCount%>.value = formatnumber(buf,0,true)
		end sub
		
		sub DoSave()
			if msgbox ("�f�[�^��<%=CashSaved%>���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 2
			frmInput.submit()
		end sub
		
		sub DoReset()
			if msgbox ("�f�[�^�����Z�b�g���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%for i = 2 to CashCount - 2%>
				frmInput.Cash<%=i%>.value = "<%=formatnumber(CashDebit(i)-CashCredit(i),0,true)%>"
<%next%>
			call Calculate()
		end sub
		
		sub CashDepart_OnChange()
			if isObject(frmInput.btnSave) then
				frmInput.btnSave.disabled = true
			end if
		end sub
		
		sub SelYear_OnChange()
			if isObject(frmInput.btnSave) then
				frmInput.btnSave.disabled = true
			end if
		end sub
		
		sub SelMonth_OnChange()
			if isObject(frmInput.btnSave) then
				frmInput.btnSave.disabled = true
			end if
		end sub
	</script>
</HEAD>

<BODY topmargin=5 onload="InitForm()" class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CashierResult.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value=1>
		<table class=pt9>
			<TR><TD nowrap>�Ώە���
<%if myCashier > 1 or myLevel > 2 then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()"><%=ShowDepartList(CashDepart)%></select>
<%else%>
	<%if UserShop = "K" then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()">
						<option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o
						<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
						<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
						<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
					</select>
	<%else%>
				<TD><font class=pt9g><%=Code2Depart(CashDepart)%></font><input type=hidden name="CashDepart" value="<%=CashDepart%>">
	<%end if%>
<%end if%>
				<TD nowrap>�Ώ۔N��
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) - 1 to year(date) + 1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>��&nbsp;
				<TD nowrap>
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
<%if mode <> 0 and CashMonth < left(Date2Str(Date), 6) and (myLevel > 2 or myCashier > 1) then%>
					<input type=button name=btnSave style="width:80;height:30" value="<%=CashSaved%>" onclick="DoSave()">
					<input type=button name=btnReset style="width:80;height:30" value="���Z�b�g" onclick="DoReset()">
<%end if%>
		</table>
		<br>
<%if mode <> 0 then%>
���Ώە���F<font class=pt9g><%=Code2Depart(CashDepart)%></font>
�@�Ώ۔N���F<font class=pt9g><%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��</font>
�@�i �X�V�ҁF<font class=pt9g><%=GetEmployName(Updater, "F")%></font>
�@�X�V�����F<font class=pt9g><%=Updated%></font> �j
		<table border=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
			<colgroup bgcolor="#E0FFE0" align=center>
			<colgroup bgcolor="#E0FFE0" align=left>
			<colgroup span=2 align=right>
			<colgroup bgcolor="#E0FFE0" align=right>
			<colgroup align=right>
			<colgroup span=2 align=center>
			<TR><TD class=voucher width=50>����
				<TD class=voucher width=150 align=center>����Ȗ�
				<TD class=voucher width=80>�ؕ����z
				<TD class=voucher width=70>�ݕ����z
				<TD class=voucher width=70>����\�Z
				<TD class=voucher width=80>�������
				<TD class=voucher width=200>�o����l
			<TR bgcolor="#FFE0E0"><TD><%=CashCode(0)%>
				<TD>�@<%=ShowAccountName(CashAccount(0))%>
				<TD><%=formatnumber(CashDebit(0),0,true)%>
				<TD><%=formatnumber(CashCredit(0),0,true)%>
				<TD><%=formatnumber(CashBudget(0),0,true)%>
				<TD><input class=sn name="Cash0" size=10 maxlength=11 value="<%=formatnumber(CashResult(0),0,true)%>"
						 OnKeyDown="ResetEnter()" readonly>
				<TD><input class=sj name="Memo0" size=30 maxlength=100 value="<%=CashRemarks(0)%>" OnKeyDown="ResetEnter()">
<%for i = 1 to CashCount - 1%>
			<TR><TD><%=CashCode(i)%>
				<TD>�@<%=ShowAccountName(CashAccount(i))%>
				<TD><%=formatnumber(CashDebit(i),0,true)%>
				<TD><%=formatnumber(CashCredit(i),0,true)%>
				<TD><%=formatnumber(CashBudget(i),0,true)%>
				<TD><input class=sn name="Cash<%=i%>" size=10 maxlength=11 value="<%=formatnumber(CashResult(i),0,true)%>" OnKeyDown="ResetEnter()">
				<TD><input class=sj name="Memo<%=i%>" size=30 maxlength=100 value="<%=CashRemarks(i)%>" OnKeyDown="ResetEnter()">
<%next%>
			<TR bgcolor="#FFE0E0"><TD><%=CashCode(CashCount)%>
				<TD>�@<%=ShowAccountName(CashAccount(CashCount))%>
				<TD colspan=2 align=center>�ŏI�X�V�F<%=formatnumber(CashResult(CashCount),0,true)%>
<%
	CashResult(CashCount) = CashResult(0)
	for i = 1 to CashCount - 1
		CashResult(CashCount) = CashResult(CashCount) - CashResult(i)
	next
	if CashDepart = "6" then
		CashResult(CashCount) = CashResult(CashCount) + CashResult(CashCount - 1) * 2
	end if
%>
				<TD><%=formatnumber(CashBudget(CashCount),0,true)%>
				<TD><input class=sn name="Cash<%=CashCount%>" size=10 maxlength=11 value="<%=formatnumber(CashResult(CashCount),0,true)%>"
						 OnKeyDown="ResetEnter()" readonly>
				<TD><input class=sj name="Memo<%=CashCount%>" size=30 maxlength=100 value="<%=CashRemarks(CashCount)%>" OnKeyDown="ResetEnter()">
		</table>
<%end if%>
	</form>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function GetDepartProfit(myDepart, myDebit, myCredit)
dim mySql
dim myRec
	GetDepartProfit = 0
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	select case myDepart
	case "3", "4", "6", "1103", "2203"
		select case myDepart
		case "3":		myBelong = "K"
		case "4":		myBelong = "M"
		case "6":		myBelong = "C"
		case "1103":	myBelong = "O"
		case "2203":	myBelong = "T"
		end select
		mySql = "SELECT SUM(SalesSum) AS Debit, SUM(CostsSum) AS Credit FROM TBL_CTM_JOB"
		mySql = mySql & " WHERE Deleted = 0 AND JobBelong = '" & myBelong & "'"
		mySql = mySql & " AND SalesDate BETWEEN '" & CashFrom & "' AND '" & CashTo & "'"
if WebUserID = gsAdmin then response.write mySql
		with myRec
			.Open mySql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				myDebit = myDebit + GetLong(.fields("Debit"))
				myCredit = myCredit + GetLong(.fields("Credit"))
			end if
			.Close
		end with
	end select
	
	select case myDepart
	case "1", "2", "4"
		mySql = "SELECT SUM(ExpenseAmount) AS Debit FROM TBL_CTM_JOB AS J"
		mySql = mySql & " INNER JOIN TBL_CTM_EXPENSE AS E ON J.JobCode = E.JobCode"
		mySql = mySql & " WHERE J.Deleted = 0 AND E.Deleted = 0 AND ExpenseType = " & gsPayment
		mySql = mySql & " AND SalesDate BETWEEN '" & CashFrom & "' AND '" & CashTo & "'"
		select case myDepart
		case "1"
			mySql = mySql & " AND ExpenseClient = '" & gsCorpCode & "'"
			mySql = mySql & " AND SUBSTRING(J.JobCode, 1, 2) IN ('KE','ME','OE','TE','OH','TH')"
		case "2"
			mySql = mySql & " AND ExpenseClient = '" & gsCorpCode & "'"
			mySql = mySql & " AND SUBSTRING(J.JobCode, 1, 2) IN ('KI','MI','OI','TI','KH','MH')"
		case "4"
			mySql = mySql & " AND ExpenseClient = '" & gsCorpSoko & "'"
		end select
if WebUserID = gsAdmin then response.write mySql
		with myRec
			.Open mySql, Conn, adOpenStatic, adLockReadOnly
			if not .eof then
				myDebit = myDebit + GetLong(.fields("Debit"))
			end if
			.Close
		end with
	end select
	set myRec = nothing
	
	GetDepartProfit = myDebit - myCredit
end function
%>