<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
	Depart = GetDepartCode()
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	CashNo = GetPost(request("CashNo"))
	if CashNo = "" then
		Status = 0
		CashType = 1
		CashDepart = Depart
		CashTaxName = "�ې�5%"
		CashDate = formatDate(date)
		CashMonth = left(Date2Str(date), 6)
	else
		with Recset
			strSql = "SELECT * FROM TBL_CORP_CASHIER WHERE Deleted = 0 AND CashNo = '" & CashNo & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				CashDepart = GetString(.fields("CashDepart"))
				CreditDepart = GetString(.fields("CreditDepart"))
				CreditNo = GetString(.fields("CreditNo"))
				CashType = GetLong(.fields("CashType"))
				CashCode = GetString(.fields("CashCode"))
				CashDate = Str2Date(.fields("CashDate"))
				CashMonth = GetString(.fields("CashMonth"))
				CashDebit = GetPost(.fields("CashDebit"))
				CashCredit = GetPost(.fields("CashCredit"))
				CashAmount = GetLong(.fields("CashAmount"))
				CashTaxName = GetString(.fields("CashTaxName"))
				CashTax = GetLong(.fields("CashTax"))
				CashPayTo = GetString(.fields("CashPayTo"))
				CashParty = GetString(.fields("CashParty"))
				CashPurpose = GetString(.fields("CashPurpose"))
				CashTerm = GetString(.fields("CashTerm"))
				CashMember = GetString(.fields("CashMember"))
				CashContent = GetString(.fields("CashContent"))
				CashEffect = GetString(.fields("CashEffect"))
				CashMemo = GetString(.fields("CashMemo"))
				Remarks = GetString(.fields("Remarks"))
				Description = GetString(.fields("Description"))
				
				Proposer = GetString(.fields("Proposer"))
				Proposed = GetDate(.fields("Proposed"))
				Confirmer = GetString(.fields("Confirmer"))
				ConfirmDate = GetDate(.fields("ConfirmDate"))
				Corper = GetString(.fields("Corper"))
				CorpDate = GetDate(.fields("CorpDate"))
				Shoper = GetString(.fields("Shoper"))
				ShopDate = GetDate(.fields("ShopDate"))
				Reviewer = GetString(.fields("Reviewer"))
				ReviewDate = GetDate(.fields("ReviewDate"))
				
				CashPayer = GetString(.fields("CashPayer"))
				CashPayDate = GetDate(.fields("CashPayDate"))
				Permiter = GetString(.fields("Permiter"))
				PermitDate = GetDate(.fields("PermitDate"))
				
				Creater = GetLong(.fields("Creater"))
				Created = GetDate(.fields("Created"))
				Updater = GetLong(.fields("Updater"))
				Updated = GetDate(.fields("Updated"))
			end if
			.close
		end with
	end if
	
	if CreditDepart = "" then CreditDepart = CashDepart
	if CashMonth = "" then CashMonth = left(Date2Str(CashDate), 6)
	if GetPost(request("CashType")) <> "" then CashType = GetLong(request("CashType"))
	
	if Proposer <> "" and CashPayer <> "" then myEdit = "readonly"
	
	AccountMonth = CheckAccountMonth()
	AccountMonth = left(AccountMonth, 4) & "/" & right(AccountMonth, 2)
%>
<HTML>
<HEAD>
	<TITLE>��v�`�[</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT>
	<script language = vbscript>
		function ShowDetail(no)
			window.location.href = "CashierDetail.asp?CashNo=" & no
		end function
		
		function ShowList(mode)
			set win = window.open("CashierSearch.asp?mode=" & mode,"CashierSearch","resizable=1,scrollbars=1,width=600,height=600")
			win.focus()
		end function
		
		sub CashType_OnChange()
			window.location.href = "CashierDetail.asp?CashNo=<%=CashNo%>&CashType=" & frmInput.CashType.options(frmInput.CashType.SelectedIndex).value
		end sub
		
		sub SetCashDebit()
		dim buf
			if frmInput.DebitCode.value <> "" then
				buf = len(frmInput.DebitCode.value)
				for each obj in frmInput.CashDebit.options
					if left(obj.value, buf) = frmInput.DebitCode.value then
						obj.selected = true
						exit for
					end if
				next
			end if
		end sub
		
		sub SetCashCredit()
		dim buf
			if frmInput.CreditCode.value <> "" then
				buf = len(frmInput.CreditCode.value)
				for each obj in frmInput.CashCredit.options
					if left(obj.value, buf) = frmInput.CreditCode.value then
						obj.selected = true
						exit for
					end if
				next
			end if
		end sub
		
		sub DoSave(mode)
		dim buf
		dim msg
			msg = "�m�F���b�Z�[�W"
			if checkDate("CashDate", "���Z��", 1) = false then exit sub
			if mode <> 7 and left(frmInput.CashDate.value, 7) <= "<%=AccountMonth%>" then
				frmInput.CashDate.focus()
				msgbox "�Y�����x�͊��Ɍ����߂���Ă��܂��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkNum("CashAmount","���Z���z", mode * 2) = false then exit sub
			if checkNum("CashTax","�����", 0) = false then exit sub
			if checkText("CashPayTo","�x����", mode) = false then exit sub
			if checkText("Description","�E�v", 0) = false then exit sub
			if checkText("CashParty","�����", 0) = false then exit sub
			if checkText("CashPurpose","�ړI", 0) = false then exit sub
			if checkText("CashTerm","����", 0) = false then exit sub
			if checkText("CashMember","���s��", 0) = false then exit sub
			if checkText("CashContent","���e", 0) = false then exit sub
			if checkText("CashEffect","����", 0) = false then exit sub
			if checkText("CashMemo","�`�[����", 0) = false then exit sub
			if checkLen("CashMemo","�`�[����", 250) = false then exit sub
			if checkText("Remarks","�`�[���l", 0) = false then exit sub
			if checkLen("Remarks","�`�[���l", 250) = false then exit sub
			if mode > 0 then
				if frmInput.CashDebit.selectedIndex < 1 then
					frmInput.CashDebit.focus()
					msgbox "�ؕ���I�����Ă��������B", 48, "�m�F���b�Z�[�W"
					exit sub
				end if
			end if
			if mode > 5 then
				if frmInput.CashCredit.selectedIndex < 1 then
					frmInput.CashCredit.focus()
					msgbox "�ݕ���I�����Ă��������B", 48, "�m�F���b�Z�[�W"
					exit sub
				end if
			end if
			select case mode
			case -1
				if checkText("CashMemo","�`�[����", 1) = false then exit sub
				if msgbox ("�Y����v�`�[���������Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			case -2
				if checkText("Remarks","�`�[���l", 1) = false then exit sub
				if msgbox ("�Y����v�`�[���������Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			case 1
				if msgbox ("�Y����v�`�[���o���Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			case 6
				if msgbox ("�Y����v�`�[���o�[���Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			case 7
				if msgbox ("�Y����v�`�[�����F���Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			case else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			end select
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
		
		sub CashDate_OnBlur()
			frmInput.CashDate.value = SetDate(frmInput.CashDate.value)
			frmInput.CashMonth.value = left(frmInput.CashDate.value, 4) & mid(frmInput.CashDate.value, 6, 2)
		end sub
		sub CashAmount_OnBlur()
			frmInput.CashAmount.value = formatnumber(GetLong(frmInput.CashAmount.value),0,true)
			Call CalculateTax()
		end sub
		sub CashTax_OnBlur()
			frmInput.CashTax.value = formatnumber(GetLong(frmInput.CashTax.value),0,true)
		end sub
		sub CashTaxName_OnChange()
			Call CalculateTax()
		end sub
		sub CalculateTax()
		dim buf, tax
			tax = GetTaxRate(frmInput.CashTaxName.options(frmInput.CashTaxName.selectedIndex).text)
			tax = fix(GetLong(frmInput.CashAmount.value) * tax / (1 + tax))
			frmInput.CashTax.value = formatnumber(tax, 0, true)
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then 
				if not isnull(window.parent) then window.close()
			end if
		end sub
	</script>
</HEAD>

<BODY LEFTMARGIN=50 TOPMARGIN=30 class=pt9 onkeydown="DoShortCut()">
	<FORM NAME="frmInput" METHOD="POST" ACTION="CashierUpdate.asp">
		<input type=hidden name=mode value="1">
		<table width=700 CELLPADDING=0 CELLSPACING=0>
			<tr height=100>
				<td width=300>
					<table border=0 width=100% style="filter:progid:DXImageTransform.Microsoft.Shadow(Color=#E0E0E0,Direction=120,strength=3)">
						<tr height=25><td class=pt12n><%=gsCorpName%>
						<tr height=45><td class=pt16 align=center><b>��@�v�@�`�@�[</b>
					</table>
				<td width=270>
					<table width=270 BORDER=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0>
						<TR align=center height=25 class=pt9n>
							<TD>��@��
							<TD>�Ё@��
							<TD>��@��
							<TD>������
							<TD>�N�@�[
						<TR align=center height=50 class=pt9r>
							<%=ShowUserSign(Reviewer, ReviewDate)%>
							<%=ShowUserSign(Corper, CorpDate)%>
							<%=ShowUserSign(Confirmer, ConfirmDate)%>
							<%=ShowUserSign(Shoper, ShopDate)%>
							<%=ShowUserSign(Proposer, Proposed)%>
					</table>
				
				<td width=140 align=right>
					<table width=110 BORDER=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
						<TR align=center height=25>
							<TD>�o�@�[
							<TD>���@�F
						<TR align=center height=50 class=pt9r>
							<%=ShowUserSign(CashPayer, CashPayDate)%>
							<%=ShowUserSign(Permiter, PermitDate)%>
					</table>				
		</table>
			  
		<table width=700 border=1 bordercolor=#006400 CELLPADDING=0 CELLSPACING=0>
			<tr><td colspan=2>
				<table width=100% border=1 frame=void bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<TR ALIGN=CENTER height=25>
						<TD class=voucher>�`�[�ԍ�
						<TD class=voucher>�ؕ�����
						<TD class=voucher>�� �� �� ��
						<TD class=voucher>�� �Z ��
						<TD class=voucher>���Z���z
						<TD class=voucher>�� �� �� ��
					<TR ALIGN=CENTER height=30>
<%if CashNo = "" then%>
						<TD class=pt9n>�����A��
	<%if myCashier > 1 then%>
						<TD><select name="CashDepart" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
								<%=ShowDepartList(CashDepart)%></select>
	<%else%>
		<%select case WebUserID
		  case 69%>
						<TD><select name="CashDepart" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
								<option value="1103" <%if CashDepart = "1103" then response.write "selected"%>>���x�X
								<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
							</select>
		<%case 88%>
						<TD><select name="CashDepart" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
								<option value="4" <%if CashDepart = "4" then response.write "selected"%>>�ېőq��
								<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
								<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
							</select>
		<%case 33, 34%>
						<TD><select name="CashDepart" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
								<option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o
								<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
								<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
								<option value="4" <%if CashDepart = "4" then response.write "selected"%>>�ېőq��
								<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
							</select>
		<%case else%>
						<TD><%=Code2Depart(CashDepart)%><input type=hidden name="CashDepart" value="<%=CashDepart%>">
		<%end select%>
	<%end if%>
<%else%>
						<TD><input class=si name="CashNo" value="<%=CashNo%>" size=10 OnKeyDown="ResetEnter()" readonly>
						<TD><%=Code2Depart(CashDepart)%><input type=hidden name="CashDepart" value="<%=CashDepart%>">
<%end if%>
						<TD><%if CashPayer = "" then%><input class=si name="DebitCode" size=4 maxlength=5 value="" onblur="SetCashDebit()" onkeydown="ResetEnter()"><%end if%>
							<select name="CashDebit" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
								<option value="">�|�|�I���|�|
								<%=ShowCategory("CashAccount", CashDebit, 0)%></select>
						<TD><input class=si maxlength=10 size=11 name="CashDate" value=" <%=CashDate%>" OnKeyDown="ResetEnter()" <%=myEdit%>
							<%if myEdit = "" then%> onclick="setday(this)"<%end if%>>
						<TD><input class=sn maxlength=11 size=10 name="CashAmount" value="<%=formatnumber(CashAmount, 0, true)%>" OnKeyDown="ResetEnter()" <%=myEdit%>>�~
						<TD><select name="CashTaxName" onkeydown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
										<%=ShowCategoryList("TaxCode", CashTaxName, 1)%></select>
								<input class=sn maxlength=11 size=8 name="CashTax" value="<%=formatnumber(CashTax, 0, true)%>" OnKeyDown="ResetEnter()" <%=myEdit%>>�~
					<TR ALIGN=CENTER height=25>
						<TD class=voucher>�`�[�敪
						<TD class=voucher>�ݕ�����
						<TD class=voucher>�� �� �� ��
						<TD class=voucher>��v�N��
						<TD class=voucher>�����ԍ�
						<TD class=voucher>���؎臂 / ��`��
					<TR ALIGN=CENTER height=30>
						<TD><select name="CashType" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
							<%for i = 0 to ubound(typCash)%><option value="<%=i%>" <%if CashType = i then response.write "selected"%>><%=typCash(i)%><%next%>
<%if myCashier > 1 then%>
						<TD><select name="CreditDepart" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
							<%=ShowDepartList(CreditDepart)%></select>
<%else%>
						<TD><select name="CreditDepart" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
	<%select case WebUserID%>
	<%case 33, 34%>
								<option value="1" <%if CreditDepart = "1" then response.write "selected"%>>�{�ЗA�o
								<option value="2" <%if CreditDepart = "2" then response.write "selected"%>>�{�ЗA��
								<option value="3" <%if CreditDepart = "3" then response.write "selected"%>>�{�Љc��
	<%case 69%>
								<option value="1103" <%if CreditDepart = "1103" then response.write "selected"%>>���x�X
	<%case 73%>
								<option value="2203" <%if CreditDepart = "2203" then response.write "selected"%>>�����x�X
	<%case 88%>
								<option value="4" <%if CreditDepart = "4" then response.write "selected"%>>�ېőq��
								<option value="2" <%if CreditDepart = "2" then response.write "selected"%>>�{�ЗA��
								<option value="3" <%if CreditDepart = "3" then response.write "selected"%>>�{�Љc��
	<%end select%>
								<option value="6" <%if CreditDepart = "6" then response.write "selected"%>>�{�ЋƖ�
							</select>
<%end if%>
						<TD><%if CashPayer = "" then%><input class=si name="CreditCode" size=4 maxlength=5 value="" onblur="SetCashCredit()" onkeydown="ResetEnter()"><%end if%>
							<select name="CashCredit" OnKeyDown="ResetEnter()" <%if myEdit <> "" then response.write "disabled" %>>
								<option value="">�|�|�I���|�|
								<%=ShowCategory("CashAccount", CashCredit, 0)%></select>
						<TD><input class=si name="CashMonth" value=" <%=CashMonth%>" size=7 OnKeyDown="ResetEnter()" readonly>
<%if myCashier > 1 or WebUserID = 34 then%>
						<TD><input class=si name="CreditNo" value="<%=CreditNo%>" size=8 maxlength=10 OnKeyDown="ResetEnter()"
							<%if Permiter <> "" then response.write "readonly"%>>
<%else%>
						<TD><%=CreditNo%><br><input type=hidden name="CreditNo" value="<%=CreditNo%>">
<%end if%>
						<TD><input class=sz maxlength=50 size=24 name="CashCode" value="<%=CashCode%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
				</table>
				
			<tr><td>
				<table width=100% border=1 frame=void bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<colgroup span=2 align=center>
					<TR height=30>
						<TD width=20% style="cursor:hand" class=pt9b onmousedown="ShowList(12)">�x����
						<TD width=80%><input class=sj maxlength=100 size=48 name="CashPayTo" value="<%=CashPayTo%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
					<TR height=30>
						<TD style="cursor:hand" class=pt9b onmousedown="ShowList(13)">�E�@�v
						<TD><input class=sj maxlength=100 size=48 name="Description" value="<%=Description%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
					<TR height=30>
						<TD>�ځ@�I
						<TD><input class=sj maxlength=100 size=48 name="CashPurpose" value="<%=CashPurpose%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
					<TR height=30>
						<TD>���@��
						<TD><input class=sj maxlength=100 size=48 name="CashTerm" value="<%=CashTerm%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
					<TR height=30>
						<TD>�����
						<TD><input class=sj maxlength=100 size=48 name="CashParty" value="<%=CashParty%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
					<TR height=30>
						<TD>���s��
						<TD><input class=sj maxlength=100 size=48 name="CashMember" value="<%=CashMember%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
					<TR height=30>
						<TD>���@�e
						<TD><input class=sj maxlength=100 size=48 name="CashContent" value="<%=CashContent%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
					<TR height=30>
						<TD>���@��
						<TD><input class=sj maxlength=100 size=48 name="CashEffect" value="<%=CashEffect%>" OnKeyDown="ResetEnter()" <%=myEdit%>>
				</table>
			<td>
				<table width=100% border=1 frame=void bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<colgroup span=2 align=center>
					<TR height=120>
						<TD width=20%>���@��<br>(��o��)
						<TD width=80%><textarea class=sj name="CashMemo" rows=8 style="width:250" <%=myEdit%>><%=CashMemo%></textarea>
					<TR height=120>
						<TD>���@�l<br>(�o�[��)
						<TD><textarea class=sj name="Remarks" rows=8 style="width:250"><%=Remarks%></textarea>
				</table>					
		</table>
	</FORM>
			
	<table width=700 CELLPADDING=0 CELLSPACING=0>
		<tr><td width=300 class=pt9n><%if Creater <> "" then%>
				<font class=pt9g>�쐬�ҁF</font><%=GetEmployName(Creater, "F")%>�@
				<font class=pt9g>�쐬���F</font><%=FmtDateTime(Created)%><%end if%>
			<td width=400 align=right>
<%if CashNo = "" then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnSave value="�V�K�o�^" onclick="DoSave(0)">
			<input type=button class=pt9n style="width:100;height:35" name=btnClose value="�� �o ��" onclick="DoSave(1)">
<%elseif Proposer = "" then		'����o
	if myCashier > 1 or WebUserID = Creater or (WebUserID = 32 AND Creater = 70) then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnSave value="�X�V�ۑ�" onclick="DoSave(0)">
			<input type=button class=pt9n style="width:100;height:35" name=btnClose value="�� �o ��" onclick="DoSave(1)">
	<%end if
elseif CashPayer = "" then	'���o�[
	if myLevel > 2 or GetShoperID(CashDepart) = WebUserID then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnUnClose value="��o����" onclick="DoSave(-1)">
<%		if Shoper = "" then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnConfirm value="��������" onclick="DoSave(2)">
<%		end if
	end if
	if Shoper <> "" then
		if (myCashier > 1 or GetPayerID(CreditDepart) <> 0) and CheckAccount(CashDebit, CashCredit) then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnLock value="�o �[ ��" onclick="DoSave(6)">
	<%	end if
	end if
elseif Permiter = "" then
	if (myLevel > 2 or myCashier > 1) and CheckAccount(CashDebit, CashCredit) then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnUnLock value="�o�[����" onclick="DoSave(-2)">
<%	end if
	if Shoper = "" and myLevel >= 2 and GetShoperID(CashDepart) = WebUserID then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnConfirm value="��������" onclick="DoSave(2)">
<%	end if
	if Confirmer = "" and myLevel = 3 then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnConfirm value="�� �� ��" onclick="DoSave(3)">
<%	end if
	if Corper = "" and myLevel = 4 then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnCorper value="�� �� ��" onclick="DoSave(4)">
<%	end if
	if Reviewer = "" and myLevel = 5 then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnReview value="�� �� ��" onclick="DoSave(5)">
<%	end if
	if myCashier > 1 and Reviewer <> "" and CheckAccount(CashDebit, CashCredit) then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnClose value="�� �F ��" onclick="DoSave(7)">
<%	end if
elseif myCashier > 2 and CheckAccount(CashDebit, CashCredit) then%>
			<input type=button class=pt9n style="width:100;height:35" name=btnOpen value="���F����" onclick="DoSave(-2)">
<%
end if%>
	</table>
<%if CashDebit = "997" or CashCredit = "997" then%>
	<br><br>
	<table>
		<table width=700 border=1 bordercolor=#006400 CELLPADDING=0 CELLSPACING=0 class=pt9n>
			<colgroup align=center>
			<colgroup align=left>
			<colgroup align=right>
			<colgroup align=center class=pt9r>
			<colgroup align=left>
			<colgroup align=right>
			<colgroup align=center class=pt9r>
			<TR ALIGN=CENTER height=25>
				<TD class=voucher>�`�[�ԍ�
				<TD class=voucher align=center>�� �� ��
				<TD class=voucher align=center>�ؕ����z
				<TD class=voucher width=50>�� ��
				<TD class=voucher align=center>�� �� ��
				<TD class=voucher align=center>�ݕ����z
				<TD class=voucher width=50>�o �[
<%
	sumDebit = 0:	sumCredit = 0
	with Recset
		strSQL = "SELECT CashDepart, CreditDepart, CashNo, Debit, Credit, CashAmount, CashDebit, Shoper, CashPayer FROM TBL_CORP_CASHIER AS C "
		strSQL = strSQL & " INNER JOIN (SELECT CTGR_CD, CTGR_NAME AS Debit FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS A ON C.CashDebit = A.CTGR_CD"
		strSQL = strSQL & " LEFT JOIN (SELECT CTGR_CD, CTGR_NAME AS Credit FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS B ON C.CashCredit = B.CTGR_CD"
		if CreditNo = "" then 
			strSQL = strSQL & " WHERE Deleted = 0 AND (CashNo = '" & CashNo & "' OR CreditNo = '" & CashNo & "')"
		else
			strSQL = strSQL & " WHERE Deleted = 0 AND (CashNo = '" & CreditNo & "' OR CreditNo = '" & CreditNo & "')"
		end if
		strSQL = strSQL & " ORDER BY CashDebit, CashNo"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly 
		do while not .eof
			if GetString(.fields("CashDebit")) = "997" then
				myDebit = 0
				myCredit = GetLong(.fields("CashAmount"))
				clsDebit = "pt9"
				clsCredit = "pt9n"
			else
				myCredit = 0
				myDebit = GetLong(.fields("CashAmount"))
				clsDebit = "pt9n"
				clsCredit = "pt9"
			end if
			myCashNo = GetString(.fields("CashNo"))
			if myCashNo = CashNo then 
				clsDebit = "pt9b"
				clsCredit = "pt9b"
			end if
%>
			<TR height=50 style="cursor:hand" onmousedown="ShowDetail('<%=myCashNo%>')">
				<TD <%if myCashNo = CashNo then response.write "class=pt9b"%>><%=myCashNo%>
				<TD class=<%=clsDebit%>>&nbsp;<%=Code2Depart(.fields("CashDepart"))%>�@<%=GetString(.fields("Debit"))%>
				<TD nowrap class=<%=clsDebit%>>\<%=formatnumber(myDebit, 0, true)%>&nbsp;
			<%if GetString(.fields("Shoper")) <> "" then%>
				<TD background=img/hanko.gif><%=GetString(.fields("Shoper"))%>
			<%else%>
				<TD><BR>
			<%end if%>
				<TD class=<%=clsCredit%>>&nbsp;<%=Code2Depart(.fields("CreditDepart"))%>�@<%=GetString(.fields("Credit"))%>
				<TD nowrap class=<%=clsCredit%>>\<%=formatnumber(myCredit, 0, true)%>&nbsp;
			<%if GetString(.fields("CashPayer")) <> "" then%>
				<TD background=img/hanko.gif><%=GetString(.fields("CashPayer"))%>
			<%else%>
				<TD><BR>
			<%end if%>
<%
			sumDebit = sumDebit + myDebit
			sumCredit = sumCredit + myCredit
			.movenext
		loop
		.close
	end with
%>
			<TR height=50>
				<TD colspan=2><br><TD nowrap>\<%=formatnumber(sumDebit, 0, true)%>&nbsp;
				<TD colspan=2><br><TD nowrap>\<%=formatnumber(sumCredit, 0, true)%>&nbsp;
				<TD><%=formatnumber(sumDebit - sumCredit, 0, false)%><br>
	</table>
<%end if%>
</BODY></HTML>

<%
function CheckAccount(myDebit, myCredit)
	CheckAccount = 0
	if myDebit = "997" then
		if myCredit = "" or (len(myCredit) = 3 and left(myCredit, 1) = "1") then
			CheckAccount = 1
		end if
	elseif myCredit = "997" then
		if len(myDebit) = 3 and left(myDebit, 1) = "1" then
			CheckAccount = 1
		end if
	else
		CheckAccount = 1
	end if
end function
%>