<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'----------------------------------------------
'	�Ɩ��\�Z���ʐ��ڕ\
'----------------------------------------------

dim CashDate
dim CashCount
dim CashCode()
dim CashAccount()
dim CashBudget()
dim CashRemarks()
	
	redim CashCode(0)
	redim CashAccount(0)
	CashCode(0) = gsProfitCode
	CashAccount(0) = gsProfitName
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT CTGR_NUM, MIN(CTGR_CD) AS CD, MIN(CTGR_NAME) AS NM FROM MST_CATEGORY"
		strSql = strSql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = 10 AND CTGR_NUM > 0"
		strSql = strSql & " GROUP BY CTGR_NUM ORDER BY CTGR_NUM"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		CashCount = 0
		do while not .EOF
			CashCount = CashCount + 1
			redim preserve CashCode(CashCount)
			redim preserve CashAccount(CashCount)
			CashCode(CashCount) = left(GetString(.fields("CD")), 3)
			CashAccount(CashCount) = GetString(.fields("NM"))
			.movenext
		loop
		.Close
	end with
	
	mode = GetLong(request("mode"))
	if mode = 0 then
		CashDepart = GetDepartCode()
		if month(date) > 3 then
			SelYear = year(date)
		else
			SelYear = year(date) - 1
		end if
	else
		CashDepart = GetString(request("CashDepart"))
		SelYear = GetLong(request("SelYear"))
	end if
	
	redim CashBudget(CashCount, 12)
	with Recset
		strSql = "SELECT CashMonth, CashAccount, CashBudget FROM TBL_CORP_BUDGET"
		strSql = strSql & " WHERE CashMonth BETWEEN '" & SelYear & "04' AND '" & (SelYear + 1) & "03'"
		if CashDepart <> "" then strSql = strSql & " AND CashDepart = '" & CashDepart & "'"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .EOF
			for i = 0 to CashCount
				if CashCode(i) = GetString(.fields("CashAccount")) then
					idx = GetMonthCount(SelYear, .fields("CashMonth"))
					CashBudget(i, idx) = CashBudget(i, idx) + GetLong(.fields("CashBudget"))
					CashBudget(i, 0) = CashBudget(i, 0) + GetLong(.fields("CashBudget"))
					exit for
				end if
			next
			.movenext
		loop
		.Close
	end with
	
	'�c�ƕ��S��
	if CashDepart = "" then
		for idx = 0 to 12
			CashBudget(CashCount - 1, idx) = CashBudget(CashCount - 1, idx) / 2
		next
	end if
	
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
%>

<HTML>
<HEAD>
	<TITLE>����ʗ\�Z����</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY topmargin=5 class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CashierShiftA.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value=1>
		<table class=pt9>
			<TR><TD nowrap>�Ώە���
<%if myCashier > 1 or myLevel > 2 then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()"><option value="">���ׂ�<%=ShowDepartList(CashDepart)%></select>
<%else%>
	<%if UserShop = "K" then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()">
						<option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o
						<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
						<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
						<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
					</select>
	<%else%>
				<TD><font class=pt9g><%=Code2Depart(CashDepart)%></font><input type=hidden name="CashDepart" value="<%=CashDepart%>">
	<%end if%>
<%end if%>
				<TD nowrap>�Ώ۔N�x
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) - 1 to year(date) + 1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
				<TD nowrap>
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
	<div id=list>
���\�Z����F<font class=pt9g><%=Code2Depart(CashDepart)%></font>
�@�\�Z�N�x�F<font class=pt9g><%=ShowJpnYear(SelYear)%></font>
		<table border=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
			<colgroup bgcolor="#E0FFE0" align=left>
			<colgroup span=13 align=right>
			<TR><TD class=voucher align=center>����Ȗ�
	<%for j = 1 to 12%>
		<%if j < 10 then%>
				<TD width=50 class=voucher><%=GetJapanNo(j + 3)%>��
		<%else%>
				<TD width=50 class=voucher><%=GetJapanNo(j - 9)%>��
		<%end if%>
	<%next%>
				<TD width=50 class=voucher>���v
<%for i = 0 to CashCount - 1%>
			<TR height=23>
				<TD nowrap><%=CashCode(i) & " " & ShowAccountName(CashAccount(i))%>
	<%for j = 1 to 12%>
				<TD nowrap><%=formatnumber(CashBudget(i, j),0,true)%>
	<%next%>
				<TD nowrap><%=formatnumber(CashBudget(i, 0),0,true)%>
<%next%>
			<TR height=23 bgcolor="#FFE0E0">
				<TD nowrap><%=CashCode(CashCount) & " " & CashAccount(CashCount)%>
	<%for j = 1 to 12%>
				<TD nowrap><%=formatnumber(CashBudget(CashCount, j),0,true)%>
	<%next%>
				<TD nowrap><%=formatnumber(CashBudget(CashCount, 0),0,true)%>
		</table>
	</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>


<%
function ShowAccountName(myName)
dim pos
	pos = instr(myName, "�E")
	if pos = 0 then
		ShowAccountName = myName
	else
		ShowAccountName = left(myName, pos - 1)
	end if
end function

function GetMonthCount(myYear, myMonth)
dim dt1, dt2
	dt1 = cdate(myYear & "/03/01")
	dt2 = cdate(left(myMonth, 4) & "/" & right(myMonth, 2) & "/01")
	GetMonthCount = datediff("m", dt1, dt2)
end function
%>