<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'----------------------------------------------
'	�Ɩ��\���Δ䐄�ڕ\
'----------------------------------------------

dim CashCount
dim CashCode()
dim CashName()

dim CashYear
dim CashDepart
dim CashAccount

dim CashBudget(12)
dim CashResult(12)
dim CashCompare(12)
	
	for i = 0 to 12
		CashBudget(i) = 0
		CashResult(i) = 0
		CashCompare(i) = 0
	next
	
	redim CashCode(0)
	redim CashName(0)
	CashCode(0) = gsProfitCode
	CashName(0) = gsProfitName
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT CTGR_NUM, MIN(CTGR_CD) AS CD, MIN(CTGR_NAME) AS NM FROM MST_CATEGORY"
		strSql = strSql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = 10 AND CTGR_NUM > 0"
		strSql = strSql & " GROUP BY CTGR_NUM ORDER BY CTGR_NUM"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		CashCount = 0
		do while not .EOF
			CashCount = CashCount + 1
			redim preserve CashCode(CashCount)
			redim preserve CashName(CashCount)
			CashCode(CashCount) = left(GetString(.fields("CD")), 3)
			CashName(CashCount) = GetString(.fields("NM"))
			.movenext
		loop
		.Close
	end with
	
	mode = GetLong(request("mode"))
	if mode = 0 then
		CashYear = year(date)
		if month(date) < 4 then	CashYear = CashYear - 1
		CashDepart = GetDepartCode()
		CashAccount = ""
	else
		CashYear = GetLong(request("CashYear"))
		CashDepart = GetString(request("CashDepart"))
		CashAccount = GetString(request("CashAccount"))
	end if
	
	with Recset
		'�\�Z����
		strSql = "SELECT CashMonth, SUM(CashBudget) AS Budget, SUM(CashResult) AS Result FROM TBL_CORP_BUDGET"
		strSql = strSql & " WHERE CashMonth BETWEEN '" & CashYear & "04' AND '" & (CashYear + 1) & "03'"
		if CashDepart <> "" then strSql = strSql & " AND CashDepart = '" & CashDepart & "'"
		if CashAccount <> "" then strSql = strSql & " AND CashAccount = '" & CashAccount & "'"
		strSql = strSql & " GROUP BY CashMonth ORDER BY CashMonth"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .EOF
			idx = GetMonthCount(CashYear, .fields("CashMonth"))
			CashBudget(idx) = GetLong(.fields("Budget"))
			CashResult(idx) = GetLong(.fields("Result"))
			.movenext
		loop
		.Close
		
		'�O�N����
		strSql = "SELECT CashMonth, SUM(CashResult) AS Result FROM TBL_CORP_BUDGET"
		strSql = strSql & " WHERE CashMonth BETWEEN '" & (CashYear - 1) & "04' AND '" & CashYear & "03'"
		if CashDepart <> "" then strSql = strSql & " AND CashDepart = '" & CashDepart & "'"
		if CashAccount <> "" then strSql = strSql & " AND CashAccount = '" & CashAccount & "'"
		strSql = strSql & " GROUP BY CashMonth ORDER BY CashMonth"
if WebUserID = gsAdmin then response.write strSql
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .EOF
			idx = GetMonthCount(CashYear - 1, .fields("CashMonth"))
			CashCompare(idx) = GetLong(.fields("Result"))
			.movenext
		loop
		.Close
	end with

	'�c�ƕ��S��
	if CashAccount = "998" then
		for i = 0 to 12
			CashBudget(i) = CashBudget(i) / 2
			CashResult(i) = CashResult(i) / 2
			CashCompare(i) = CashCompare(i) / 2
		next
	end if

	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
%>

<HTML>
<HEAD>
	<TITLE>����ʌo��ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY topmargin=5 class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CashierShiftB.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value=1>
		<table class=pt9>
			<TR><TD nowrap>�Ώە���
<%if myCashier > 1 or myLevel > 2 then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()"><option value="">���ׂ�<%=ShowDepartList(CashDepart)%></select>
<%else%>
	<%if UserShop = "K" then%>
				<TD><select name="CashDepart" OnKeyDown="ResetEnter()">
						<option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o
						<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
						<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
						<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
					</select>
	<%else%>
				<TD><font class=pt9g><%=Code2Depart(CashDepart)%></font><input type=hidden name="CashDepart" value="<%=CashDepart%>">
	<%end if%>
<%end if%>
				<TD nowrap>�Ώ۔N�x
					<select name="CashYear" onkeydown="ResetEnter()"><%
					for i = year(date) - 1 to year(date) + 1
						response.write "<option value=" & i
						if i = CashYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
				<TD nowrap>�ΏۉȖ�
					<select name="CashAccount" onkeydown="ResetEnter()">
					<%for i = 0 to CashCount
						response.write "<option value=" & CashCode(i)
						if CashAccount = CashCode(i) then
							AccountName = CashName(i)
							response.write " selected"
						end if
						response.write ">" & ShowAccountName(CashName(i))
					next%></select>
				<TD nowrap>
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
<%if AccountName <> "" then%>
<div id=list>
���Ώ۔N�x�F<font class=pt9g><%=ShowJpnYear(CashYear)%></font>
<%if CashDepart <> "" then%>
�@�Ώە���F<font class=pt9g><%=Code2Depart(CashDepart)%></font>
<%end if%>
<%if CashAccount <> "" then%>
�@�o��ȖځF<font class=pt9g><%=ShowAccountName(AccountName)%></font>
<%end if%>
		<table border=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n width=98%>
			<colgroup align=center bgcolor=#E0FFE0>
			<colgroup span=5 align=right>
			<colgroup span=5 align=right bgcolor=#E0FFE0>
			<TR><TD class=voucher rowspan=2>���x
				<TD class=voucher colspan=5 align=center>���@���@�΁@��
				<TD class=voucher colspan=5 align=center>�݁@�v�@�΁@��
			<TR><TD>�\�@�Z<TD>���@��<TD>�\����<TD>�O�@�N<TD>�O�N��
				<TD>�\�@�Z<TD>���@��<TD>�\����<TD>�O�@�N<TD>�O�N��
<%
	sumBudget = 0
	sumResult = 0
	sumCompare = 0
	
select case CashAccount
case "000", "999"



	for i = 1 to 12
		sumBudget = sumBudget + CashBudget(i)
		sumResult = sumResult + CashResult(i)
		sumCompare = sumCompare + CashCompare(i)
%>
			<TR height=30><TD width=50>
<%if i < 10 then%><%=GetJapanNo(i + 3)%><%else%><%=GetJapanNo(i - 9)%><%end if%>��
				<TD><%=formatnumber(CashBudget(i),0,true)%>
				<TD><%=formatnumber(CashResult(i),0,true)%>
				<TD <%if CashBudget(i) > CashResult(i) then response.write "class=pt9r"%>>
					<%=formatnumber(CashResult(i) - CashBudget(i),0,true)%>
	<%if CashYear <= 2007 then%>
				<TD>�|�|<TD>�|�|
	<%else%>
				<TD><%=formatnumber(CashCompare(i),0,true)%>
				<TD <%if CashCompare(i) > CashResult(i) then response.write "class=pt9r"%>>
					<%=formatnumber(CashResult(i) - CashCompare(i),0,true)%>
	<%end if%>
				<TD><%=formatnumber(sumBudget,0,true)%>
				<TD><%=formatnumber(sumResult,0,true)%>
				<TD <%if sumBudget > sumResult then response.write "class=pt9r"%>>
					<%=formatnumber(sumResult - sumBudget,0,true)%>
	<%if CashYear <= 2007 then%>
				<TD>�|�|<TD>�|�|
	<%else%>
				<TD><%=formatnumber(sumCompare,0,true)%>
				<TD <%if sumCompare > sumResult then response.write "class=pt9r"%>>
					<%=formatnumber(sumResult - sumCompare,0,true)%>
	<%end if%>
<%
	next



case else



	for i = 1 to 12
		sumBudget = sumBudget + CashBudget(i)
		sumResult = sumResult + CashResult(i)
		sumCompare = sumCompare + CashCompare(i)
%>
			<TR height=30><TD width=50>
<%if i < 10 then%><%=GetJapanNo(i + 3)%><%else%><%=GetJapanNo(i - 9)%><%end if%>��
				<TD><%=formatnumber(CashBudget(i),0,true)%>
				<TD><%=formatnumber(CashResult(i),0,true)%>
				<TD <%if CashBudget(i) < CashResult(i) then response.write "class=pt9r"%>>
					<%=formatnumber(CashBudget(i) - CashResult(i),0,true)%>
	<%if CashYear <= 2007 then%>
				<TD>�|�|<TD>�|�|
	<%else%>
				<TD><%=formatnumber(CashCompare(i),0,true)%>
				<TD <%if CashCompare(i) < CashResult(i) then response.write "class=pt9r"%>>
					<%=formatnumber(CashCompare(i) - CashResult(i),0,true)%>
	<%end if%>
				<TD><%=formatnumber(sumBudget,0,true)%>
				<TD><%=formatnumber(sumResult,0,true)%>
				<TD <%if sumBudget < sumResult then response.write "class=pt9r"%>>
					<%=formatnumber(sumBudget - sumResult,0,true)%>
	<%if CashYear <= 2007 then%>
				<TD>�|�|<TD>�|�|
	<%else%>
				<TD><%=formatnumber(sumCompare,0,true)%>
				<TD <%if sumCompare < sumResult then response.write "class=pt9r"%>>
					<%=formatnumber(sumCompare - sumResult,0,true)%>
	<%end if%>
<%
	next



end select
%>
		</table>
</div>
<%end if%>
</BODY></HTML>
<%
dim sumBudget
dim sumResult
dim sumCompare

	set Recset = nothing
	CloseDB Conn
%>

<%
function GetMonthCount(myYear, myMonth)
dim dt1, dt2
	dt1 = cdate(myYear & "/03/01")
	dt2 = cdate(left(myMonth, 4) & "/" & right(myMonth, 2) & "/01")
	GetMonthCount = datediff("m", dt1, dt2)
end function
%>