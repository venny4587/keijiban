<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'on error resume next
	
	myLevel = CheckVoucherLevel()
	myCashier = CheckCashierLevel()

dim myMode
dim myPageSize
dim lngPageNumber
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	if mySort = 0 then
		select case myLevel
		case 2:		mySort = 7
		case 3:		mySort = 8
		case 4:		mySort = 9
		case 5:		mySort = 10
		case else
			if myCashier > 0 then mySort = 11
			if myCashier = 2 then mySort = 12
		end select
	end if
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Status = 0
		Process = 0
		'DateFrom = dateadd("m",-1,date)
		if myCashier < 2 and myLevel < 3 then
			if myLevel < 2 then 
				CashType = "0"
				curUserID = WebUserID
			end if
			CashDepart = GetDepartCode()
		end if
		Finished = 0
	else
		CashDepart = GetPost(request("CashDepart"))
		CashType = GetPost(request("CashType"))
		CashNo = GetPost(request("CashNo"))
		CreditNo = GetPost(request("CreditNo"))
		Status = GetLong(request("Status"))
		Process = GetLong(request("Process"))
		curUserID = GetLong(request("curUserID"))
		DateFrom = GetDate(request("DateFrom"))
		DateTo = GetDate(request("DateTo"))
		CashPayTo = GetPost(request("CashPayTo"))
		Description = GetPost(request("Description"))
		AmountFrom = GetPost(request("AmountFrom"))
		AmountTo = GetPost(request("AmountTo"))
		CashMemo = GetPost(request("CashMemo"))
		SendFlag = GetLong(request("SendFlag"))
		
		if AmountFrom <> "" then AmountFrom = GetLong(AmountFrom)
		if AmountTo <> "" then AmountTo = GetLong(AmountTo)
	end if
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>��v�`�[�Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<SCRIPT LANGUAGE=javascript>
		function ShowDetail(mode, no) {
			if (mode=='1') {
				var win = window.open("CashierDetail.asp?CashNo=" + no, "", "resizable=1,scrollbars=1,width=800,height=600");
			} else {
				var win = window.open("CashierInput.asp?CashNo=" + no, "", "resizable=1,scrollbars=1,width=800,height=600");
			}
			win.focus();
		}
	</SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoSearch()
			frmInput.page.value = 1
			frmInput.submit()
		end function
		
		function DoSort(mySort)
			frmInput.page.value = 1
			frmInput.sort.value = mySort
			frmInput.submit()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub	
		sub ProcFrom_OnBlur()
			frmInput.ProcFrom.value = setdate(frmInput.ProcFrom.value)
		end sub		
		sub ProcTo_OnBlur()
			frmInput.ProcTo.value = setdate(frmInput.ProcTo.value)
		end sub		
		sub AmountFrom_OnBlur()
			if frmInput.AmountFrom.value = "" then exit sub
			frmInput.AmountFrom.value = GetDouble(frmInput.AmountFrom.value)
		end sub
		sub AmountTo_OnBlur()
			if frmInput.AmountTo.value = "" then exit sub
			frmInput.AmountTo.value = GetDouble(frmInput.AmountTo.value)
		end sub	
				
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CashierView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='<%=lngPageNumber%>'>
		<table class=pt9>
			<TR><TD nowrap>
<%if myCashier > 1 or myLevel > 2 then%>
				�������� <SELECT name="CashDepart" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowDepartList(CashDepart)%></select>&nbsp;
<%else%>
	<%select case WebUserID
	  case 33, 34, 36, 46, 47 %>
				�������� <SELECT name="CashDepart" onkeydown="ResetEnter()"><option value="">���ׂ�
		<%if WebUserID<>36 then%><option value="1" <%if CashDepart = "1" then response.write "selected"%>>�{�ЗA�o<%end if%>
		<%if WebUserID<>47 then%><option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��<%end if%>
								<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
		<%if WebUserID=33 or WebUserID=34 then%>
								<option value="4" <%if CashDepart = "4" then response.write "selected"%>>�ېőq��
								<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
		<%end if%>
						</select>&nbsp;
	<%case 69%>
				�������� <SELECT name="CashDepart" onkeydown="ResetEnter()"><option value="">���ׂ�
								<option value="1103" <%if CashDepart = "1103" then response.write "selected"%>>���x�X
								<option value="6" <%if CashDepart = "6" then response.write "selected"%>>�{�ЋƖ�
						</select>&nbsp;
	<%case 88%>
				�������� <SELECT name="CashDepart" onkeydown="ResetEnter()"><option value="">���ׂ�
								<option value="4" <%if CashDepart = "4" then response.write "selected"%>>�ېőq��
								<option value="2" <%if CashDepart = "2" then response.write "selected"%>>�{�ЗA��
								<option value="3" <%if CashDepart = "3" then response.write "selected"%>>�{�Љc��
						</select>&nbsp;
	<%case else%>
				�������� <font class=pt9g><%=Code2Depart(CashDepart)%></font><input type=hidden name="CashDepart" value="<%=CashDepart%>">&nbsp;
	<%end select%>
<%end if%>
<%if myCashier < 1 and myLevel < 2 then%>
				�`�[�敪 <font class=pt9g><%=typCash(GetLong(CashType))%></font><input type=hidden name="CashType" value="<%=CashType%>">&nbsp;
<%else%>
				�`�[�敪 <select name="CashType" OnKeyDown="ResetEnter()"><option value="">���ׂ�
						<%for i = 0 to ubound(typCash)%>
							<option value="<%=i%>" <%if CashType = cstr(i) then response.write "selected"%>><%=typCash(i)%><%next%>
						</select>&nbsp;
<%end if%>
				�`�[�ԍ� <input class=si name="CashNo" value="<%=CashNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">&nbsp;
				���Z��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				���� <SELECT name="Status" onkeydown="ResetEnter()"><option value="">���ׂ�
					<option value="1" <%if Status = 1 then response.write "selected"%>>�N�[��
					<option value="2" <%if Status = 2 then response.write "selected"%>>������
					<option value="3" <%if Status = 3 then response.write "selected"%>>�ꖱ��
					<option value="4" <%if Status = 4 then response.write "selected"%>>�В���
					<option value="5" <%if Status = 5 then response.write "selected"%>>���</select>
				<SELECT name="curUserID" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowEmployList("", curUserID)%></select>
			<TR><TD nowrap>
				�o�[ <SELECT name="Process" onkeydown="ResetEnter()"><option value="">���ׂ�
					<option value="1" <%if Process = 1 then response.write "selected"%>>�o�[��
					<option value="2" <%if Process = 2 then response.write "selected"%>>���F��</select>
				���Z���z<input class=sn name="AmountFrom" value="<%=AmountFrom%>" maxlength=11 size=10 onkeydown="ResetEnter()">
					�`<input class=sn name="AmountTo" value="<%=AmountTo%>" maxlength=11 size=10 onkeydown="ResetEnter()">
				�x����<input class=sj name="CashPayTo" value="<%=CashPayTo%>" maxlength=20 size=16 onkeydown="ResetEnter()">
				�E�v<input class=sj name="Description" value="<%=Description%>" maxlength=20 size=16 onkeydown="ResetEnter()">
				�����ԍ� <input class=si name="CreditNo" value="<%=CreditNo%>" maxlength=10 size=8 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=Button VALUE="����" onclick="DoSearch()">
				<input type=checkbox name="SendFlag" value="1" onkeydown="ResetEnter()" <%if SendFlag then response.write " checked"%>>�o�͍�
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		
		strSel = ""
		if myCashier = 0 then
			select case WebUserID
	  		case 46
				 strSel = strSel & " AND CashDepart IN ('1','2','3') "
			case 36
				 strSel = strSel & " AND CashDepart IN ('2','3') "
			case 47
				 strSel = strSel & " AND CashDepart IN ('1','3') "
			case else
				if myLevel = 2 then strSel = strSel & " AND CashDepart = '" & GetDepartCode() & "'"
				if myLevel < 2 then strSel = strSel & " AND Creater = " & WebUserID
			end select
		elseif myCashier = 1 then
			select case WebUserID
			case 33, 34
				 strSel = strSel & " AND CreditDepart IN ('1','2','3','6') "
			case 69
				 strSel = strSel & " AND CreditDepart IN ('1103','6') "
			case 88
				 strSel = strSel & " AND CashDepart IN ('2','3','4') "
			case else
				strSel = strSel & " AND CashDepart = '" & GetDepartCode() & "'"
			end select
		end if
		if CashType <> "" then strSel = strSel & " AND CashType = " & CashType
		if CashDepart <> "" then strSel = strSel & " AND CashDepart = '" & CashDepart & "'" 
		if CashNo <> "" then strSel = strSel & " AND (CashNo = '" & CashNo & "' OR CreditNo = '" & CashNo & "')"
		if CreditNo <> "" then strSel = strSel & " AND CreditNo = '" & CreditNo & "'"
		if DateFrom <> "" then strSel = strSel & " AND CashDate >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND CashDate <= '" & Date2Str(DateTo) & "'"
		select case Status
		case 1
			myUser = "Proposer"
			myDate = "Proposed"
		case 2
			myUser = "Shoper"
			myDate = "ShopDate"
		case 3
			myUser = "Confirmer"
			myDate = "ConfirmDate"
		case 4
			myUser = "Corper"
			myDate = "CorpDate"
		case 5
			myUser = "Reviewer"
			myDate = "ReviewDate"
		end select
		if Status <> 0 then
			if curUserID = 0 then
				strSel = strSel & " AND " & myUser & " <> ''"
			else
				strSel = strSel & " AND " & myUser & " = '" & GetEmployName(curUserID, "F") & "'"
			end if
		end if
		select case Process
		case 1
			strSel = strSel & " AND CashPayer <> ''"
		case 2
			strSel = strSel & " AND Permiter <> ''"
		end select
		if AmountFrom <> "" then strSel = strSel & " AND (CashAmount+CashTax) >= " & AmountFrom
		if AmountTo <> "" then strSel = strSel & " AND (CashAmount+CashTax) <= " & AmountTo
		if CashPayTo <> "" then strSel = strSel & " AND CashPayTo LIKE '%" & CashPayTo & "%'"
		if Description <> "" then strSel = strSel & " AND Description LIKE '%" & Description & "%'"
		if CashMemo <> "" then strSel = strSel & " AND (CashMemo LIKE '%" & CashMemo & "%' OR Remarks LIKE '%" & CashMemo & "%')"
		if SendFlag = 0 then strSel = strSel & " AND SendFlag = 0"
		
		strSQL = "SELECT CashDepart, CreditDepart, CashNo, Debit, Credit, CashAmount, CashTax, CashDate, CashPayTo, Description, CreditNo"
		strSQL = strSQL & ", Proposer, Shoper, Confirmer, Corper, Reviewer, CashPayer, Permiter, CashType, SendFlag FROM TBL_CORP_CASHIER AS C "
		strSQL = strSQL & " INNER JOIN (SELECT CTGR_CD, CTGR_NAME AS Debit FROM MST_CATEGORY WHERE CTGR_BASE = 10"
		if myCashier < 1 and myLevel < 2 then strSQL = strSQL & " AND CTGR_FLAG <> 0 "
		strSQL = strSQL & ") AS A ON C.CashDebit = A.CTGR_CD"
		strSQL = strSQL & " LEFT JOIN (SELECT CTGR_CD, CTGR_NAME AS Credit FROM MST_CATEGORY WHERE CTGR_BASE = 10) AS B"
		strSQL = strSQL & " ON C.CashCredit = B.CTGR_CD WHERE Deleted = 0 " & strSel
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY CashNo"
		case 1:		strSQL = strSQL & " ORDER BY CashDate, CashNo"
		case 2:		strSQL = strSQL & " ORDER BY Debit"
		case 3:		strSQL = strSQL & " ORDER BY Credit"
		case 4:		strSQL = strSQL & " ORDER BY (CashAmount+CashTax)"
		case 5:		strSQL = strSQL & " ORDER BY CashPayTo"
		case 6:		strSQL = strSQL & " ORDER BY Proposer"
		case 7:		strSQL = strSQL & " ORDER BY Shoper"
		case 8:		strSQL = strSQL & " ORDER BY Confirmer"
		case 9:		strSQL = strSQL & " ORDER BY Corper"
		case 10:	strSQL = strSQL & " ORDER BY Reviewer"
		case 11:	strSQL = strSQL & " ORDER BY CashPayer"
		case 12:	strSQL = strSQL & " ORDER BY Permiter"
		case 13:	strSQL = strSQL & " ORDER BY CashDepart"
		case 14:	strSQL = strSQL & " ORDER BY CreditDepart"
		case 15:	strSQL = strSQL & " ORDER BY CreditNo"
		end select
		if mySort > 1 then strSQL = strSQL & ",CashDate,CashNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=3 align=center>
			<colgroup align=center>
			<colgroup align=left>
<%if myCashier > 0 then%>
			<colgroup align=center>
			<colgroup span=2 align=left>
<%end if%>
			<colgroup align=right>
			<colgroup align=left>
			<colgroup span=6 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�`�[�ԍ�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">���Z��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(13)">�ؕ�����
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">�ؕ��Ȗ�
<%if myCashier > 0 then%>
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(14)">�ݕ�����
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�ݕ��Ȗ�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(15)">�����ԍ�
<%end if%>
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">���z
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�x����
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">�N�[
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">����
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">�ꖱ
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">�В�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(10)">�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(11)">�o�[
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(12)">���F
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						if GetLong(.fields("SendFlag")) then
							color = "gray"
						else
							color = "black"
						end if
						myPayTo = GetString(.Fields("CashPayTo"))
						myType = GetLong(.Fields("CashType"))
						if myType = 0 then
							if myLevel > 2 or myCashier > 0 then
							   	myType = 1
							end if
						end if
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" 
						onclick="ShowDetail('<%=myType%>', '<%=.Fields("CashNo")%>');">
						<TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=GetString(.Fields("CashNo"))%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("CashDate"))%><BR>
						<TD nowrap class=line><%=Code2Depart(.Fields("CashDepart"))%>
						<TD nowrap class=line><%=GetString(.Fields("Debit"))%><BR>
<%if myCashier > 0 then%>
						<TD nowrap class=line><%=Code2Depart(.Fields("CreditDepart"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Credit"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("CreditNo"))%><BR>
<%end if%>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("CashAmount")), 0, true)%><BR>
						<TD nowrap class=line <%=ShowTitle(myPayTo, 8)%>><%=StringCut(myPayTo, 8)%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Proposer"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Shoper"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Confirmer"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Corper"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Reviewer"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("CashPayer"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("Permiter"))%><BR>
<%
						.MoveNext
					End If
				Loop
%>
				
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>