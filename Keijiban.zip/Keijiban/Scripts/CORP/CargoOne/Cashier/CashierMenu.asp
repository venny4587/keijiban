<!-- #include file="../common/common.asp" -->
<!-- #include file="Cashier.asp" -->
<%
	myVoucher = CheckVoucherLevel()
	myCashier = CheckCashierLevel()
%>
<html>
<head>
	<title>�����������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		btnBudget.style.color = "black"
<%if myCashier > 1 or myVoucher > 2 then%>
		btnPreview.style.color = "black"
		btnReview.style.color = "black"
<%end if%>
		btnShiftA.style.color = "black"
		btnResult.style.color = "black"
		btnShiftB.style.color = "black"
		btnReport.style.color = "black"
<%if myCashier > 1 then%>
		btnExport.style.color = "black"
<%end if%>
		select case mySel
		case 1
			url = "CashierBudget.asp"
			btnBudget.style.color = "red"
		case 2
			url = "CashierPreview.asp"	
			btnPreview.style.color = "red"
		case 3
			url = "CashierShiftA.asp"	
			btnShiftA.style.color = "red"
		case 4
			url = "CashierResult.asp"	
			btnResult.style.color = "red"
		case 5
			url = "CashierReview.asp"	
			btnReview.style.color = "red"
		case 6
			url = "CashierShiftB.asp"	
			btnShiftB.style.color = "red"
		case 7
			url = "CashierReport.asp"
			btnReport.style.color = "red"
		case 8
			url = "CashierExport.asp"	
			btnExport.style.color = "red"
		end select
		window.parent.cbody.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnBudget value="����ʗ\�Z" onclick="DoAct(1)"></TD>
<%if myCashier > 1 or myVoucher > 2 then%>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnPreview value="�\�Z�ꗗ�\" onclick="DoAct(2)"></TD>
<%end if%>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnShiftA value="�\�Z���ڕ\" onclick="DoAct(3)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnResult value="����ʎ���" onclick="DoAct(4)"></TD>
<%if myCashier > 1 or myVoucher > 2 then%>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnReview value="����ꗗ�\" onclick="DoAct(5)"></TD>
<%end if%>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnShiftB value="���各�ڕ\" onclick="DoAct(6)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnReport value="�o��ꗗ�\" onclick="DoAct(7)"></TD>
<%if myCashier > 1 then%>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnExport value="�~���N�o��" onclick="DoAct(8)"></TD>
<%end if%>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
