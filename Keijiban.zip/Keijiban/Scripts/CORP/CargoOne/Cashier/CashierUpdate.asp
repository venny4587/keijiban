<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/Account.asp" -->
<!-- #include file="Cashier.asp" -->
<%
	mode = GetLong(request("mode"))
	CashNo = GetPost(request("CashNo"))
	CreditNo = GetPost(request("CreditNo"))
	CashDepart = GetPost(request("CashDepart"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	Conn.BeginTrans
	
	select case mode
	case -1							'��o����
	
		if CheckCashPaid(CashNo) > 0 then
		
			msg = "�Y����v�`�[�͊��ɏo�[��������܂����I"
			
		else
			
			'��o����
			strSql = "UPDATE TBL_CORP_CASHIER SET Updated = GETDATE()"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Proposer = '', Proposed = NULL"
			strSql = strSql & ", Shoper = '', ShopDate = NULL"
			if CreditNo = "" then
				strSql = strSql & " WHERE CashNo = '" & CashNo & "'"
			else
				strSql = strSql & " WHERE CreditNo = '" & CreditNo & "'"
			end if
			Conn.execute strSql
			
			strSql = "UPDATE TBL_CORP_CASHIER SET"
			strSql = strSql & " CashMemo = '" & FitSel(request("CashMemo")) & "'"
			strSql = strSql & " WHERE CashNo = '" & CashNo & "'"
			Conn.execute strSql
			
			msg = "�Y����v�`�[�͉�������܂����I"
			
		end if
		
	case -2							'�o�[����
	
		if CheckCashSend(CashNo) > 0 then
		
			msg = "�Y����v�`�[�͊��ɓ��o��������܂����I"
			
		else
			
			strSql = "DELETE FROM TBL_CTM_FIN "
			strSql = strSql & " WHERE FIN_CURRENT = 9"
			strSql = strSql & " AND FIN_SECURITIES = '���̑�'"
			strSql = strSql & " AND FIN_SECURITIES_NO = '" & CashNo & "'"
			Conn.execute strSql
			
			'�o�[����
			strSql = "UPDATE TBL_CORP_CASHIER SET Updated = GETDATE()"
			strSql = strSql & ", Updater = " & WebUserID
			strSql = strSql & ", Corper = '', CorpDate = NULL"
			strSql = strSql & ", Confirmer = '', ConfirmDate = NULL"
			strSql = strSql & ", Reviewer = '', ReviewDate = NULL"
			strSql = strSql & ", Permiter = '', PermitDate = NULL"
			strSql = strSql & ", CashPayer = '', CashPayDate = NULL"
			if CreditNo = "" then
				strSql = strSql & " WHERE CashNo = '" & CashNo & "'"
			else
				strSql = strSql & " WHERE CreditNo = '" & CreditNo & "'"
			end if
			Conn.execute strSql
			
			strSql = "UPDATE TBL_CORP_CASHIER SET"
			strSql = strSql & " Remarks = '" & FitSel(request("Remarks")) & "'"
			strSql = strSql & " WHERE CashNo = '" & CashNo & "'"
			Conn.execute strSql
			
			msg = "�Y����v�`�[�͉�������܂����I"
			
		end if
		
	case 0, 1, 6					'�ۑ��E��o�E�o�[
	
		if CashNo = "" then			'�V�K�ԍ����s
		
			CashInit = mid(Date2Str(date), 3, 4) & "-" & GetCashInit(CashDepart)
			
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_CTM_NEW_ACNT"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@Account").Value = CashInit
			cmdSQL.Execute
			CashNo = CashInit & right("000" & GetLong(cmdSQL.Parameters("@MaxID").Value),3)
		
		elseif CheckCashPaid(CashNo) > 0 then
		
			msg = "�Y���������͊��ɏ��F����܂����I"
				
		end if
		
		if msg = "" then
			with Recset
				strSql = "SELECT * FROM TBL_CORP_CASHIER WHERE CashNo = '" & CashNo & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("CashNo") = CashNo
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
					.fields("Deleted") = 0
					.fields("sendFlag") = 0
				end if
				
				.fields("CashDepart") = CashDepart
				.fields("CashType") = GetLong(request("CashType"))
				.fields("CashMonth") = left(Date2Str(request("CashDate")), 6)
				.fields("CashPayTo") = GetPost(request("CashPayTo"))
				.fields("CashCode") = GetPost(request("CashCode"))
				.fields("Description") = GetPost(request("Description"))
				.fields("CreditDepart") = GetPost(request("CreditDepart"))
				if GetLong(request("CashType")) then .fields("CreditNo") = CreditNo
				
				.fields("CashDebit") = GetPost(request("CashDebit"))
				.fields("CashCredit") = GetPost(request("CashCredit"))
				.fields("CashDate") = Date2Str(request("CashDate"))
				.fields("CashAmount") = GetLong(request("CashAmount"))
				.fields("CashTaxName") = GetPost(request("CashTaxName"))
				.fields("CashTax") = GetLong(request("CashTax"))
				
				.fields("CashTerm") = GetPost(request("CashTerm"))
				.fields("CashParty") = GetPost(request("CashParty"))
				.fields("CashMember") = GetPost(request("CashMember"))
				.fields("CashPurpose") = GetPost(request("CashPurpose"))
				.fields("CashContent") = GetPost(request("CashContent"))
				.fields("CashEffect") = GetPost(request("CashEffect"))
				.fields("CashMemo") = GetPost(request("CashMemo"))
				
				if mode = 1 then
					.fields("Proposer") = session("FamilyName")
					.fields("Proposed") = now()
					if CheckVoucherLevel() > 3 or WebUserID = GetShoperID(CashDepart) then
						.fields("Shoper") = session("FamilyName")
						.fields("ShopDate") = now()
					end if
				elseif mode = 6 then
					if GetString(.fields("CreditNo")) = "" then
						if CreditNo = "" then CreditNo = GetCreditNo(Conn)
						.fields("CreditNo") = CreditNo
					end if
					.fields("CashPayer") = session("FamilyName")
					.fields("CashPayDate") = now()
				end if
				
				.fields("Remarks") = GetPost(Request("Remarks"))
				.fields("Updater") = WebUserID
				.fields("Updated") = now()
				
				.update
				.close
			end with
			
			if mode = 6 then
				strSql = "UPDATE TBL_CORP_CASHIER SET CashPayDate = GETDATE()"
				strSql = strSql & ", CashDate = '" & Date2Str(request("CashDate")) & "'"
				strSql = strSql & ", CashMonth = '" & left(Date2Str(request("CashDate")), 6) & "'"
				strSql = strSql & ", CashPayer = '" & FitSel(session("FamilyName")) & "'"
				strSql = strSql & ", CreditNo = '" & FitSel(CreditNo) & "'"
				if CreditNo = "" then
					strSql = strSql & " WHERE CreditNo = '" & CashNo & "'"
				else
					strSql = strSql & " WHERE CreditNo = '" & CashNo & "' OR CreditNo = '" & FitSel(CreditNo) & "'"
				end if
				Conn.execute strSql
				
			end if
			
			select case mode
			case 0:		msg = "�Y����v�`�[�͕ۑ�����܂����I"
			case 1:		msg = "�Y����v�`�[�͒�o����܂����I"
			case 6:		msg = "�Y����v�`�[�͏o�[����܂����I"
			case else:	msg = "�Y����v�`�[�͏�������܂����I"
			end select
			
		end if
		
	case 2, 3, 4, 5
	
		strSql = "UPDATE TBL_CORP_CASHIER SET CashMemo = '" & FitSel(request("CashMemo")) & "'"
		select case mode 
		case 2							'������
			strSql = strSql & ", ShopDate = GETDATE(), Shoper = '" & FitSel(session("FamilyName")) & "'"
		case 3							'�ꖱ
			strSql = strSql & ", ConfirmDate = GETDATE(), Confirmer = '" & FitSel(session("FamilyName")) & "'"
		case 4							'�В�
			strSql = strSql & ", CorpDate = GETDATE(), Corper = '" & FitSel(session("FamilyName")) & "'"
		case 5							'�
			strSql = strSql & ", ReviewDate = GETDATE(), Reviewer = '" & FitSel(session("FamilyName")) & "'"
		end select
		if mode = 2 or CreditNo = "" then
			strSql = strSql & " WHERE CashNo = '" & CashNo & "'"
		else
			strSql = strSql & " WHERE CreditNo = '" & CreditNo & "'"
		end if
		Conn.execute strSql
		
		msg = "�Y����v�`�[�͏��F����܂����I"
		
	case 7			'���F
		
		if CreditNo <> "" then
			strSql = "UPDATE TBL_CORP_CASHIER SET Remarks = '" & FitSel(request("Remarks")) & "'"
			strSql = strSql & ", PermitDate = GETDATE(), Permiter = '" & FitSel(session("FamilyName")) & "'"
			strSql = strSql & " WHERE CreditNo = '" & CreditNo & "'"
			Conn.execute strSql
		end if
		
		strSql = "DELETE FROM TBL_CTM_FIN "
		strSql = strSql & " WHERE FIN_CURRENT = 9"
		strSql = strSql & " AND FIN_SECURITIES = '���̑�'"
		strSql = strSql & " AND FIN_SECURITIES_NO = '" & CashNo & "'"
		Conn.execute strSql

		with Recset
			strSql = "SELECT CashNo, CashDate, CashAmount, CashTaxName, CashTax, CashDepart, CreditDepart, CashPayTo"
			strSql = strSql & ", Debit, Credit, Description, Remarks, Creater FROM TBL_CORP_CASHIER AS TMP LEFT JOIN"
			strSql = strSql & " (SELECT CTGR_CD, 0 - CTGR_NUM AS Debit FROM MST_CATEGORY WHERE CTGR_DELETED = 0"
			strSql = strSql & " AND CTGR_BASE = 10 AND CTGR_NUM < 0) AS D ON TMP.CashDebit = D.CTGR_CD LEFT JOIN"
			strSql = strSql & " (SELECT CTGR_CD, 0 - CTGR_NUM AS Credit FROM MST_CATEGORY WHERE CTGR_DELETED = 0"
			strSql = strSql & " AND CTGR_BASE = 10 AND CTGR_NUM < 0) AS C ON TMP.CashCredit = C.CTGR_CD"
			strSql = strSql & " WHERE (ISNULL(Debit, 0) > 0 OR ISNULL(Credit, 0) > 0 )"
			strSql = strSql & " AND CashNo = '" & CashNo & "'"			' CreditNo = '" & CreditNo & "'
			.Open strSQL, Conn, adOpenKeyset , adLockReadOnly
			if not .eof then
				if clng("0" & .fields("Debit")) > 0 then Call Account2Fin(Recset, 0)
				if clng("0" & .fields("Credit")) > 0 then Call Account2Fin(Recset, 1)
			end if
			.Close
		end with

		msg = "�Y����v�`�[�͏��F����܂����I"
		
	end select
				
	if err.number = 0 then 
		Conn.CommitTrans
%>
<html>
	<script language=javascript>
		alert("<%=msg%>");
		if (window.opener != null) {
			if (window.opener.frmInput != null) window.opener.frmInput.submit();
		}
		window.location.href = "CashierDetail.asp?CashNo=<%=CashNo%>";
	</script>
</html>
<%
	else
		Conn.CommitTrans
		ShowMessage "�f�[�^���������L�̃G���[���N����܂����B\n" & err.number & ":" & err.Description 
	end if
	CloseDB Conn
%>


<%
function Account2Fin(myRc, myMode)
dim myRec
dim myBank
dim myDepart
	if myMode = 0 then
		SeqNo = GetNewAcntNo(Conn, 3)			'����
		FIN_NO = GetAccountNo(SeqNo, 3)
		myBank = clng("0" & myRc.fields("Debit"))
		myDepart = GetDepart(myRc.fields("CashDepart"))
	else
		SeqNo = GetNewAcntNo(Conn, 4)			'�o��
		FIN_NO = GetAccountNo(SeqNo, 4)
		myBank = clng("0" & myRc.fields("Credit"))
		myDepart = GetDepart(myRc.fields("CreditDepart"))
	end if
	
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		strSql = "SELECT * FROM TBL_CTM_FIN"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		.AddNew
		.fields("FIN_NO") = FIN_NO
		.fields("FIN_TYPE") = 23				'��s
		.fields("FIN_BELONG") = myDepart
		.fields("FIN_CURRENT") = 9
		.fields("FIN_ORIGINAL") = 1
		
		.fields("FIN_CLIENT_CD") = "KAIKEI"
		.fields("FIN_CLIENT_NAME") = "��v�V�X�e���`�["
		.fields("FIN_CLIENT_PIC") = GetString(request("FIN_CLIENT_PIC"))
		.fields("FIN_BANK_ID") = myBank
		
		if myMode = 0 then
			.fields("FIN_DEBIT") = acntBank					'��s
			.fields("FIN_CREDIT") = acntExpense				'�o��
		else
			.fields("FIN_DEBIT") = acntExpense				'�o��
			.fields("FIN_CREDIT") = acntBank				'��s
		end if
		
		.fields("FIN_DATE") = GetString(myRc.fields("CashDate"))
		.fields("FIN_AMOUNT") = GetLong(myRc.fields("CashAmount"))	' + GetLong(myRc.fields("CashTax"))
		.fields("FIN_DESCRIPTION") = GetString(myRc.fields("CashPayTo"))
		
		.fields("FIN_SECURITIES") = "���̑�"
		.fields("FIN_SECURITIES_NO") = GetString(myRc.fields("CashNo"))
		.fields("FIN_MEMO") = GetString(myRc.fields("Description"))
		.fields("FIN_REMARKS") = GetString(myRc.fields("Remarks"))
		
		.fields("CONFIRM_ID") = WebUserID
		.fields("CONFIRM_DATE") = now
		.fields("ERASE_ID") = WebUserID
		.fields("ERASE_DATE") = now
		
		.fields("FIN_CREATER") = GetLong(myRc.fields("Creater"))
		.fields("FIN_CREATED") = now
		.fields("FIN_UPDATER") = WebUserID
		.fields("FIN_UPDATED") = now
		.fields("FIN_DELETED") = 0
		.update
		.close
	end with
	Set myRec = Nothing
end function

function GetDepart(myDepart)
	select case GetString(myDepart)
	case "1103":	GetDepart = "O"
	case "2203":	GetDepart = "T"
	case "4":	GetDepart = "M"
	case "6":	GetDepart = "Z"
	case else:	GetDepart = "K"
	end select
end function

function GetCreditNo(myCon)
dim myInit, myCmd
	myInit = UserShop & "-"
	if WebUserID = 70 then myInit = "F-"
	Set myCmd = Server.CreateObject("ADODB.Command")
	Set myCmd.ActiveConnection = myCon
	myCmd.CommandType = 4
	myCmd.CommandText = "DB_CTM_NEW_ACNT"
	myCmd.Parameters.Refresh
	myCmd.Parameters("@Account").Value = myInit
	myCmd.Execute
	GetCreditNo = myInit & GetLong(myCmd.Parameters("@MaxID").Value)
end function
%>