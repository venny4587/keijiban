<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="Cashier.asp" -->
<%
'----------------------------------------------
'	�Ɩ��\�Z�ꗗ�\
'----------------------------------------------

dim CashDate
dim CashCount
dim CashCode()
dim CashAccount()
dim CashBudget()
	
	redim CashCode(0)
	redim CashAccount(0)
	CashCode(0) = gsProfitCode
	CashAccount(0) = gsProfitName
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT CTGR_NUM, MIN(CTGR_CD) AS CD, MIN(CTGR_NAME) AS NM FROM MST_CATEGORY"
		strSql = strSql & " WHERE CTGR_DELETED = 0 AND CTGR_BASE = 10 AND CTGR_NUM > 0"
		strSql = strSql & " GROUP BY CTGR_NUM ORDER BY CTGR_NUM"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		CashCount = 0
		do while not .EOF
			CashCount = CashCount + 1
			redim preserve CashCode(CashCount)
			redim preserve CashAccount(CashCount)
			CashCode(CashCount) = left(GetString(.fields("CD")), 3)
			CashAccount(CashCount) = GetString(.fields("NM"))
			.movenext
		loop
		.Close
	end with
	
	mode = GetLong(request("mode"))
	if mode = 0 then
		CashDate = dateadd("m", -1, date)
		SelYear = year(CashDate)
		SelMonth = month(CashDate)
	else
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
	end if
	CashMonth = SelYear & right("00" & SelMonth, 2)
	
	redim CashBudget(CashCount, 7)
	with Recset
		strSql = "SELECT CashAccount, CashDepart, CashBudget, Remarks FROM TBL_CORP_BUDGET"
		strSql = strSql & " WHERE CashMonth = '" & CashMonth & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		do while not .EOF
			for i = 0 to CashCount
				if CashCode(i) = GetString(.fields("CashAccount")) then
					select case GetString(.fields("CashDepart"))
					case "1":		CashBudget(i, 1) = GetLong(.fields("CashBudget"))
					case "2":		CashBudget(i, 2) = GetLong(.fields("CashBudget"))
					case "4":		CashBudget(i, 3) = GetLong(.fields("CashBudget"))
					case "1103":	CashBudget(i, 4) = GetLong(.fields("CashBudget"))
					case "2203":	CashBudget(i, 5) = GetLong(.fields("CashBudget"))
					case "3":		CashBudget(i, 6) = GetLong(.fields("CashBudget"))
					case "6":		CashBudget(i, 7) = GetLong(.fields("CashBudget"))
					end select
					CashBudget(i, 0) = CashBudget(i, 0) + GetLong(.fields("CashBudget"))
					exit for
				end if
			next
			.movenext
		loop
		.Close
	end with
	
	'�c�ƕ��S��
	CashBudget(CashCount - 1, 0) = CashBudget(CashCount - 1, 0) / 2
%>

<HTML>
<HEAD>
	<TITLE>����ʌo��\�Z�ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY topmargin=5 class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CashierPreview.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="mode" value=1>
		<table class=pt9>
				<TD nowrap>�Ώ۔N��
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) - 1 to year(date) + 1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>��&nbsp;
				<TD nowrap>
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
	<div id=list>
���\�Z���x�F<font class=pt9g><%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��</font>
		<table border=1 bordercolor=#006400 CELLPADDING=2 CELLSPACING=0 class=pt9n>
			<colgroup bgcolor="#E0FFE0" align=center>
			<colgroup bgcolor="#E0FFE0" align=left>
			<colgroup span=8 align=right>
			<TR><TD class=voucher align=center width=50>����
				<TD class=voucher align=center width=150>����Ȗ�
				<TD class=voucher align=center width=100>�_�˗A�o
				<TD class=voucher align=center width=100>�_�˗A��
				<TD class=voucher align=center width=100>�ېőq��
				<TD class=voucher align=center width=100>���x�X
				<TD class=voucher align=center width=100>�����x�X
				<TD class=voucher align=center width=100>�_�ˉc��
				<TD class=voucher align=center width=100>�{�ЋƖ�
				<TD class=voucher align=center width=110>�S�Ѝ��v
<%for i = 0 to CashCount - 1%>
			<TR height=23>
				<TD><%=CashCode(i)%>
				<TD>�@<%=ShowAccountName(CashAccount(i))%>
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashBudget(i, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashBudget(i, 0),0,true)%>
<%next%>
			<TR height=23 bgcolor="#FFE0E0">
				<TD><%=CashCode(CashCount)%>
				<TD>�@<%=CashAccount(CashCount)%>
	<%for j = 1 to 7%>
				<TD><%=formatnumber(CashBudget(CashCount, j),0,true)%>
	<%next%>
				<TD><%=formatnumber(CashBudget(CashCount, 0),0,true)%>
		</table>
	</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>


<%
function ShowAccountName(myName)
dim pos
	pos = instr(myName, "�E")
	if pos = 0 then
		ShowAccountName = myName
	else
		ShowAccountName = left(myName, pos - 1)
	end if
end function
%>