<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�[�i��ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<SCRIPT language=javaScript>
		function ShowDetail(myCD) {
			var win = window.open("CtmDoorDetail.asp?CTM_CD=<%=CTM_CD%>&DOOR_ID="+myCD,"CtmBank","scrollbars=no,width=600,height=300");
			win.focus();
		}
	</SCRIPT>
</HEAD>
<BODY <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���[�i��<td width=50% align=right>
	  	<img style="cursor:hand" src=img/new.gif alt="�V�K�ǉ�" onmousedown="ShowDetail('');">
	</table>
	<hr size=1>
<%
	with recset
		strSql = "SELECT DOOR_ID, DOOR_CD, DOOR_NAME, DOOR_ADDR1, DOOR_ADDR2, DOOR_PIC, DOOR_TEL, DOOR_FAX "
		strSql = strSql & " FROM CTM_DOOR WHERE DOOR_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
		strSql = strSql & " ORDER BY DOOR_DFT DESC, DOOR_CD, DOOR_ID"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20>
		<TD class=line nowrap>����
		<TD class=line nowrap>��Ж�
		<TD class=line nowrap>�Z��
<%
			do while not .eof				
				DoorName = GetString(.Fields("DOOR_NAME"))
				DoorAddr = GetString(.Fields("DOOR_ADDR1")) & " " & GetString(.Fields("DOOR_ADDR2"))
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("DOOR_ID")%>');">
					<TD class=line nowrap><%=GetString(.Fields("DOOR_CD"))%><BR>
					<TD class=line nowrap <%=ShowTitle(DoorName, 10)%>><%=StringCut(DoorName,10)%><BR>
					<TD class=line nowrap <%=ShowTitle(DoorAddr, 25)%>><%=StringCut(DoorAddr,25)%><BR>
<%
				.movenext
			loop
%>
	</TABLE>
<%
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
