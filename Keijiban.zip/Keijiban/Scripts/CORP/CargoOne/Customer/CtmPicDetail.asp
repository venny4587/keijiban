<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	PIC_ID = GetLong(request("PIC_ID"))
	if CTM_CD <> "" then
		mode = 0
		if PIC_ID <> 0 then
			OpenSql Conn, SqlServerName, DataBaseName
			set Recset = Server.CreateObject("adodb.recordset") 
			with Recset 
				strSql = "SELECT * FROM CTM_PIC WHERE PIC_DELETED = 0 AND PIC_ID = " & PIC_ID
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					PIC_CD = GetString(.fields("PIC_CD"))
					PIC_NAME = GetString(.fields("PIC_NAME"))
					PIC_DPT = GetString(.fields("PIC_DPT"))
					PIC_POS = GetString(.fields("PIC_POS"))
					PIC_TEL = GetString(.fields("PIC_TEL"))
					PIC_FAX = GetString(.fields("PIC_FAX"))
					PIC_MAIL = GetString(.fields("PIC_MAIL"))
					PIC_CELL = GetString(.fields("PIC_CELL"))
					PIC_UID = GetString(.fields("PIC_UID"))
					PIC_PWD = GetString(.fields("PIC_PWD"))
					PIC_REMARKS = GetString(.fields("PIC_REMARKS"))
					PIC_DFT = GetLong(.fields("PIC_DFT"))
				end if
				.close
			end with
			set Recset = nothing
			CloseDB Conn
		end if
%>
<html>
<HEAD>
	<TITLE>�S���ҏڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
			if checkText("PIC_CD","�S���Һ���",0) = false then exit sub
			if checkText("PIC_DPT","����",0) = false then exit sub
			if checkText("PIC_POS","��E",0) = false then exit sub
			if checkText("PIC_NAME","�S���Җ�",1) = false then exit sub
			if checkText("PIC_TEL","�d�b�ԍ�",0) = false then exit sub
			if checkText("PIC_FAX","FAX�ԍ�",0) = false then exit sub
			if checkText("PIC_CELL","�g��",0) = false then exit sub
			if checkText("PIC_UID","���O�C��ID",0) = false then exit sub
			if checkText("PIC_PWD","�p�X���[�h",0) = false then exit sub
			if checkText("PIC_MAIL","���[��",0) = false then exit sub
			if checkText("PIC_REMARKS","���l", 0) = false then
				exit sub
			elseif checkLen("PIC_REMARKS","���l",255) = false then
				exit sub
			end if		
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CtmPicUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="CTM_CD" value="<%=CTM_CD%>">
  	<input type=hidden name="PIC_ID" value="<%=PIC_ID%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���S���ҏ��&nbsp;
<%if PIC_ID <> 0 then %>
		<img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
	  <td width=50% align=right>
	  	<img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1><%=ShowCustomHead(CTM_CD)%>
	<br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=24>
		<TD width=40>����</TD>
		<TD><input class=si name="PIC_CD" size=6 maxlength=10 value="<%=PIC_CD%>" onkeydown="ResetEnter()">
		<TD width=40>����</TD>
		<TD><input class=sj name="PIC_DPT" size=20 maxlength=50 value="<%=PIC_DPT%>" onkeydown="ResetEnter()">
		<TD width=40>��E</TD>
		<TD><input class=sj name="PIC_POS" size=20 maxlength=50 value="<%=PIC_POS%>" onkeydown="ResetEnter()">
	  <TR height=24>
		<TD class=pt9n>�S����&nbsp;</TD>
		<TD><input class=sj name="PIC_NAME" size=20 maxlength=50 value="<%=PIC_NAME%>" onkeydown="ResetEnter()">
		<TD class=pt9n align=center>Tel</TD>
		<TD colspan=3><input class=si name="PIC_TEL" size=50 maxlength=50 value="<%=PIC_TEL%>" onkeydown="ResetEnter()">
	  <TR height=24>
		<TD>�g��</TD>
		<TD><input class=si name="PIC_CELL" size=20 maxlength=50 value="<%=PIC_CELL%>" onkeydown="ResetEnter()">
		<TD class=pt9n align=center>Fax</TD>
		<TD colspan=3><input class=si name="PIC_FAX" size=50 maxlength=50 value="<%=PIC_FAX%>" onkeydown="ResetEnter()">
<!--
		<TD>UID</TD>
		<TD><input class=si name="PIC_UID" size=16 maxlength=20 value="<%=PIC_UID%>" onkeydown="ResetEnter()">
		<TD>PWD</TD>
		<TD><input class=si name="PIC_PWD" size=16 maxlength=20 value="<%=PIC_PWD%>" onkeydown="ResetEnter()">
-->
	  <TR height=24>
		<TD>EҰ�</TD>
		<TD colspan=4><input class=si name="PIC_MAIL" size=56 maxlength=80 value="<%=PIC_MAIL%>" onkeydown="ResetEnter()">
		<TD class=pt9n>������<input type=checkbox name="PIC_DFT" value="1" onkeydown="ResetEnter()" <%if PIC_DFT then response.write " checked"%>>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=22>
		<TD>���l</TD>
		<TD colspan=4><textarea name="PIC_REMARKS" rows=4 style="width:320"><%=PIC_REMARKS%></textarea>
		<TD>
<%if gsSaveButton = 1 then %>
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
	end if
%>