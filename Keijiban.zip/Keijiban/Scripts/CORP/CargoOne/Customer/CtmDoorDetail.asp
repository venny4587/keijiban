<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	DOOR_ID = GetLong(request("DOOR_ID"))
	if CTM_CD <> "" then
		mode = 0
		if DOOR_ID <> 0 then
			OpenSql Conn, SqlServerName, DataBaseName
			set Recset = Server.CreateObject("adodb.recordset") 
			with Recset 
				strSql = "SELECT * FROM CTM_DOOR WHERE DOOR_DELETED = 0 AND DOOR_ID = " & DOOR_ID
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					DOOR_CD = GetString(.fields("DOOR_CD"))
					DOOR_NAME = GetString(.fields("DOOR_NAME"))
					DOOR_PIC = GetString(.fields("DOOR_PIC"))
					DOOR_ZIP = GetString(.fields("DOOR_ZIP"))
					DOOR_ADDR1 = GetString(.fields("DOOR_ADDR1"))
					DOOR_ADDR2 = GetString(.fields("DOOR_ADDR2"))
					DOOR_TEL = GetString(.fields("DOOR_TEL"))
					DOOR_FAX = GetString(.fields("DOOR_FAX"))
					DOOR_CELL = GetString(.fields("DOOR_CELL"))
					DOOR_MAIL = GetString(.fields("DOOR_MAIL"))
					DOOR_REMARKS = GetString(.fields("DOOR_REMARKS"))
					DOOR_DFT = GetLong(.fields("DOOR_DFT"))
				end if
				.close
			end with
			set Recset = nothing
			CloseDB Conn
		end if
%>
<html>
<HEAD>
	<TITLE>�[�i��ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
			if checkText("DOOR_CD","�[�i�溰��",0) = false then exit sub
			if checkText("DOOR_NAME","�[�i�於",1) = false then exit sub
			if checkText("DOOR_PIC","�S���Җ�",0) = false then exit sub
			if checkText("DOOR_ZIP","�X�֔ԍ�",0) = false then exit sub
			if checkText("DOOR_ADDR1","�[�i��Z���P",0) = false then exit sub
			if checkText("DOOR_ADDR2","�[�i��Z���Q",0) = false then exit sub
			if checkText("DOOR_TEL","�d�b�ԍ�",0) = false then exit sub
			if checkText("DOOR_FAX","FAX�ԍ�",0) = false then exit sub
			if checkText("DOOR_CELL","�S���Ҍg��",0) = false then exit sub
			if checkText("DOOR_MAIL","�S���҃��[��",0) = false then exit sub
			if checkText("DOOR_REMARKS","���l", 0) = false then
				exit sub
			elseif checkLen("DOOR_REMARKS","���l",255) = false then
				exit sub
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CtmDoorUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="CTM_CD" value="<%=CTM_CD%>">
  	<input type=hidden name="DOOR_ID" value="<%=DOOR_ID%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���[�i����&nbsp;
<%if DOOR_ID <> 0 then %>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
		<td width=50% align=right>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1><%=ShowCustomHead(CTM_CD)%>
	<br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=22>
		<TD width=40>����</TD>
		<TD><input class=si name="DOOR_CD" size=6 maxlength=10 value="<%=DOOR_CD%>" onkeydown="ResetEnter()">
		<TD class=pt9n width=50>��Ж�</TD>
		<TD><input class=sj name="DOOR_NAME" size=36 maxlength=50 value="<%=DOOR_NAME%>" onkeydown="ResetEnter()">
		<TD width=30>��</TD>
		<TD><input class=si name="DOOR_ZIP" size=10 maxlength=8 value="<%=DOOR_ZIP%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD class=pt9n>�Z��1</TD>
		<TD colspan=3><input class=sj name="DOOR_ADDR1" size=56 maxlength=100 value="<%=DOOR_ADDR1%>" onkeydown="ResetEnter()">
		<TD>Tel</TD>
		<TD><input class=si name="DOOR_TEL" size=16 maxlength=50 value="<%=DOOR_TEL%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD>�Z��2</TD>
		<TD colspan=3><input class=sj name="DOOR_ADDR2" size=56 maxlength=100 value="<%=DOOR_ADDR2%>" onkeydown="ResetEnter()">
		<TD>Fax</TD>
		<TD><input class=si name="DOOR_FAX" size=16 maxlength=50 value="<%=DOOR_FAX%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD>�S����&nbsp;</TD>
		<TD><input class=sj name="DOOR_PIC" size=10 maxlength=10 value="<%=DOOR_PIC%>" onkeydown="ResetEnter()">
		<TD>Mail</TD>
		<TD><input class=si name="DOOR_MAIL" size=36 maxlength=50 value="<%=DOOR_MAIL%>" onkeydown="ResetEnter()">
		<TD>�g��</TD>
		<TD><input class=si name="DOOR_CELL" size=16 maxlength=50 value="<%=DOOR_CELL%>" onkeydown="ResetEnter()">
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=22>
		<TD valign=top>���l
		<TD colspan=4><textarea name="DOOR_REMARKS" rows=4 style="width:360"><%=DOOR_REMARKS%></textarea>
		<TD>
<%if gsSaveButton = 1 then %>
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
	end if
%>