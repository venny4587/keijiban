<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	CTM_CD = GetPost(request("CTM_CD"))
	BANK_ID = GetPost(request("BANK_ID"))
	
	msg = ""
	OpenSql Conn, SqlServerName, DataBaseName
	
	mode = GetLong(request("mode"))	
	if mode = -1 then

		strSql = "UPDATE CTM_BANK SET BANK_DELETED = 1"
		strSql = strSql & ",BANK_UPDATED = GETDATE()" 
		strSql = strSql & ",BANK_UPDATER = " & WebUserID 
		strSql = strSql & " WHERE BANK_ID = " & BANK_ID
		Conn.Execute strSql

	elseif CTM_CD <> "" then
	
		set Recset = Server.CreateObject("adodb.recordset")
		
		if mode = 0 then
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "CTM_BANK"	
			cmdSQL.Execute
			BANK_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
		with Recset
			strSql = "SELECT * FROM CTM_BANK WHERE BANK_ID = " & BANK_ID
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then
				.AddNew
				.fields("CTM_CD") = CTM_CD
				.fields("BANK_ID") = BANK_ID
				
				.fields("BANK_CREATER") = WebUserID
				.fields("BANK_CREATED") = now
				.fields("BANK_DELETED") = 0
			end if
			.fields("BANK_CD") = GetPost(request("BANK_CD"))
			.fields("BANK_NAME") = GetPost(request("BANK_NAME"))
			.fields("BANK_BRANCH") = GetPost(request("BANK_BRANCH"))
			.fields("BANK_TYPE") = GetPost(request("BANK_TYPE"))
			.fields("BANK_ACCOUNT") = GetPost(request("BANK_ACCOUNT"))
			.fields("BANK_SPELL") = GetPost(request("BANK_SPELL"))
			.fields("BANK_HOLDER") = GetPost(request("BANK_HOLDER"))
			.fields("BANK_REMARKS") = GetPost(request("BANK_REMARKS"))
			.fields("BANK_DFT") = GetLong(request("BANK_DFT"))	
	
			.fields("BANK_UPDATER") = WebUserID
			.fields("BANK_UPDATED") = now
			.update
			.close
		end with
		set Recset = nothing
		
	end if
	CloseDB Conn
	
	if msg <> "" then
		ShowMessage msg
	else
%>
<html>
<script language=javascript>
	window.opener.location.href = "CtmBankList.asp?CTM_CD=<%=CTM_CD%>";
	window.close();
</script>
</html>
<%
	end if
%>