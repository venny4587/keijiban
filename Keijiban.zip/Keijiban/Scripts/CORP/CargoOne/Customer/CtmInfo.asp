<%
'on error resume next
	CTM_CD = cstr(request("CTM_CD") & "")
	if instr(CTM_CD, " ") <> 0 then CTM_CD = ""
	if CTM_CD <> "" then
%>
<HTML>
<HEAD>
<TITLE>�ڋq�֘A���</TITLE>
</HEAD>
	<FRAMESET rows="150,200,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="CtmPicList.asp?CTM_CD=<%=CTM_CD%>" NAME="pic" MARGINWIDTH="10" MARGINHEIGHT="0">
		<FRAME SRC="CtmDoorList.asp?CTM_CD=<%=CTM_CD%>" NAME="door" MARGINWIDTH="10" MARGINHEIGHT="0">
		<FRAME SRC="CtmLinkList.asp?CTM_CD=<%=CTM_CD%>" NAME="link" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>
<%
	end if
%>