<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'-----------------------------------------------
'		�R���o�[�g�f�[�^����
'-----------------------------------------------
on error resume next

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")
	
	Conn.BeginTrans
	
	with Recset
		StrSql = "SELECT * FROM CUSTOMER"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
		ctm = 0
		do while not .eof	
			ctm = ctm + 1
			idx = GetTelFaxIndex(GetString(.fields("CTM_TEL")) & "/" & GetString(.fields("CTM_FAX")))
			if idx <> "/" then .fields("CTM_TEL_IDX") = idx
			.update
			.movenext
		loop
		.close
		
		StrSql = "SELECT * FROM CTM_PIC"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
		pic = 0
		do while not .eof
			pic = pic + 1
			idx = GetTelFaxIndex(GetString(.fields("PIC_TEL")) & "/" & GetString(.fields("PIC_FAX")) & "/" & GetString(.fields("PIC_CELL")))
			if idx <> "//" then .fields("PIC_TEL_IDX") = idx
			.update
			.movenext
		loop
		.close
	end with
	set Recset = nothing
	
	if err.number = 0 then 
		Conn.CommitTrans
		strMsg = strMsg & "<p>" & "�X�V�������I�����܂����B" & "</p>"
	else
		Conn.RollbackTrans
		strMsg = strMsg & "<p>" & "�G���[���������܂����B" & "</p>"
		strMsg = strMsg & "<p>" & err.number & "<br>" & err.description & "</p>"
	end if
	CloseDB Conn
	
	response.write "<br>�ڋq�F" & ctm & "��"
	response.write "<br>�S���F" & pic & "��"
%>
<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
</head>	
<body <%=gsBodyControl%>>
<table width=100%>
<tr><td>
	<table>
		<TR><TD width=10 rowspan=5></TD><BR><TD></TD></TR>
		<TR><TD><%=strMsg%></TD></TR>
		<TR><TD><BR></TD></TR>
		<TR><TD><input type='button' value='�߂�' name='btnback' style="width:100;height:30"></TD></TR>
	</table>	
</td></tr>
</table>
</body>
</html>