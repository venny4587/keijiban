<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim myMode
dim myPageSize
dim lngPageNumber
	
	mySort = GetLong(request("sort"))
	
	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1

	OpenSql Conn, SqlServerName, DataBaseName
	set recset = Server.CreateObject("ADODB.RecordSet") 
		
	myMode = GetLong(request("mode"))
	if myMode = 1 then
		REF = GetPost(request("REF"))
		TEL = GetPost(request("TEL"))
		CTM_BELONG = GetPost(request("CTM_BELONG"))
		CTM_PROVINCE = GetPost(request("CTM_PROVINCE"))
		CTM_SALESMNGR = GetLong(request("CTM_SALESMNGR"))
		
		CTM_TYPE = 0
		CTM_CLIENT = GetLong(request("CTM_CLIENT")):			CTM_TYPE = CTM_TYPE + CTM_CLIENT
		CTM_SHIPPER = GetLong(request("CTM_SHIPPER")):			CTM_TYPE = CTM_TYPE + CTM_SHIPPER
		CTM_CONSIGNEE = GetLong(request("CTM_CONSIGNEE")):		CTM_TYPE = CTM_TYPE + CTM_CONSIGNEE
		CTM_NOTIFY = GetLong(request("CTM_NOTIFY")):			CTM_TYPE = CTM_TYPE + CTM_NOTIFY
		CTM_BROKER = GetLong(request("CTM_BROKER")):			CTM_TYPE = CTM_TYPE + CTM_BROKER
		CTM_AGENT = GetLong(request("CTM_AGENT")):				CTM_TYPE = CTM_TYPE + CTM_AGENT
		CTM_CUSTOM = GetLong(request("CTM_CUSTOM")):			CTM_TYPE = CTM_TYPE + CTM_CUSTOM
		CTM_WAREHOUSE = GetLong(request("CTM_WAREHOUSE")):		CTM_TYPE = CTM_TYPE + CTM_WAREHOUSE
		CTM_TRUCKER = GetLong(request("CTM_TRUCKER")):			CTM_TYPE = CTM_TYPE + CTM_TRUCKER
		CTM_CARRIER = GetLong(request("CTM_CARRIER")):			CTM_TYPE = CTM_TYPE + CTM_CARRIER
		CTM_AIRLINER = GetLong(request("CTM_AIRLINER")):		CTM_TYPE = CTM_TYPE + CTM_AIRLINER
		CTM_OTHER = GetLong(request("CTM_OTHER")):				CTM_TYPE = CTM_TYPE + CTM_OTHER
	else
		CTM_PROVINCE = "JP"
	end if
%>
<HTML>
<HEAD>
	<TITLE>�ڋq����</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function	
				
		function ShowDetail(myCD)
		    window.location.href = "MainFrame.asp?CTM_CD=" & myCD
		end function	
	</SCRIPT>
</HEAD>
<BODY <%=gsBodyControl%>>
  <FORM name=frmInput action="CustomerView.asp" method="post">
	<INPUT type=hidden name="mode" value="1">
	<INPUT type=hidden name="page" value="<%=myPage%>">
	<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
	<TABLE Cellspacing=0 CellPadding=0 class=pt9>
      <TR>
		<TD nowrap>
		  �戵&nbsp;<SELECT name="CTM_BELONG" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowShopList(CTM_BELONG)%></select>
		�@�n��&nbsp;<SELECT name="CTM_PROVINCE" onkeydown="ResetEnter()"><option value="JP">���ׂ�<%=ShowProvList(CTM_PROVINCE)%></SELECT>
		�@�q��&nbsp;<input class=sj size=16 maxlength=10 name=REF value="<%=REF%>" onkeydown="ResetEnter()">
		�@Tel/Fax&nbsp;<input class=si size=16 maxlength=10 name=TEL value="<%=TEL%>" onkeydown="ResetEnter()">
		�@�c��&nbsp;<SELECT name="CTM_SALESMNGR" onkeydown="ResetEnter()"><option value=0>�S��<%=ShowEmployList(DepartSales, CTM_SALESMNGR)%></select>
	  	  <INPUT type=submit style="width:60px;height:22px;" name=btnSearch value="����">
		  <INPUT class=pt9n style="width:60px;height:22px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
	  <tr>
	  	<td>
			<input type=checkbox name="CTM_CLIENT" value="1" onkeydown="ResetEnter()" <%if CTM_CLIENT then response.write " checked"%>>�ڋq
			<input type=checkbox name="CTM_SHIPPER" value="1" onkeydown="ResetEnter()" <%if CTM_SHIPPER then response.write " checked"%>>�ב��l
			<input type=checkbox name="CTM_CONSIGNEE" value="1" onkeydown="ResetEnter()" <%if CTM_CONSIGNEE then response.write " checked"%>>�׎�l
			<input type=checkbox name="CTM_NOTIFY" value="1" onkeydown="ResetEnter()" <%if CTM_NOTIFY then response.write " checked"%>>�ʒm�l
			<input type=checkbox name="CTM_BROKER" value="1" onkeydown="ResetEnter()" <%if CTM_BROKER then response.write " checked"%>>��s��
			<input type=checkbox name="CTM_AGENT" value="1" onkeydown="ResetEnter()" <%if CTM_AGENT then response.write " checked"%>>�C�O�㗝
			<input type=checkbox name="CTM_CUSTOM" value="1" onkeydown="ResetEnter()" <%if CTM_CUSTOM then response.write " checked"%>>�ʊ֋Ǝ�
			<input type=checkbox name="CTM_WAREHOUSE" value="1" onkeydown="ResetEnter()" <%if CTM_WAREHOUSE then response.write " checked"%>>�q�ɋƎ�
			<input type=checkbox name="CTM_TRUCKER" value="1" onkeydown="ResetEnter()" <%if CTM_TRUCKER then response.write " checked"%>>�^���Ǝ�
			<input type=checkbox name="CTM_CARRIER" value="1" onkeydown="ResetEnter()" <%if CTM_CARRIER then response.write " checked"%>>�D���
			<input type=checkbox name="CTM_AIRLINER" value="1" onkeydown="ResetEnter()" <%if CTM_AIRLINER then response.write " checked"%>>�q����
			<input type=checkbox name="CTM_OTHER" value="1" onkeydown="ResetEnter()" <%if CTM_OTHER then response.write " checked"%>>���̑�</table>

	</TABLE>
<%
	if myMode = 1 then
		with recset
			strSql = "SELECT CTM_CD, CTM_BELONG, CTM_REF, CTM_NAME, CTM_TEL, CTM_FAX, CTM_ADDR1+CTM_ADDR2 AS CTM_ADDR, CTM_SALESMNGR FROM CUSTOMER WHERE CTM_DELETED = 0"	
			if REF <> "" then strSql = strSql & " AND (CTM_REF LIKE '%" & FitSel(REF) & "%' OR CTM_NAME LIKE '%" & FitSel(REF) & "%' OR CTM_ENAME LIKE '%" & FitSel(REF) & "%')"
			if TEL <> "" then 
				strSql = strSql & " AND (CTM_TEL_IDX LIKE '%" & FitSel(TEL) & "%' OR CTM_CD IN "
				strSql = strSql & " (SELECT DISTINCT CTM_CD FROM CTM_PIC "
				strSql = strSql & " WHERE PIC_TEL_IDX LIKE '%" & FitSel(TEL) & "%'"
				if MNG <> "" then strSql = strSql & " AND PIC_NAME LIKE '%" & FitSel(MNG) & "%'"
				strSql = strSql & "))" 
			elseif MNG <> "" then
				strSql = strSql & " AND CTM_CD IN (SELECT DISTINCT CTM_CD FROM CTM_PIC "
				strSql = strSql & " WHERE PIC_NAME LIKE '%" & FitSel(MNG) & "%')"
			end if
			if CTM_BELONG <> "" then strSql = strSql & " AND CTM_BELONG = '" & CTM_BELONG & "'"
			if CTM_PROVINCE <> "JP" then strSql = strSql & " AND CTM_PROVINCE = '" & CTM_PROVINCE & "'"
			if CTM_SALESMNGR <> 0 then strSql = strSql & " AND CTM_SALESMNGR = " & CTM_SALESMNGR
			if CTM_TYPE <> 0 then 
				strSel = ""
				if CTM_CLIENT <> 0 then strSel = strSel & " OR CTM_CLIENT <> 0"
				if CTM_SHIPPER <> 0 then strSel = strSel & " OR CTM_SHIPPER <> 0"
				if CTM_CONSIGNEE <> 0 then strSel = strSel & " OR CTM_CONSIGNEE <> 0"
				if CTM_NOTIFY <> 0 then strSel = strSel & " OR CTM_NOTIFY <> 0"
				if CTM_BROKER <> 0 then strSel = strSel & " OR CTM_BROKER <> 0"
				if CTM_AGENT <> 0 then strSel = strSel & " OR CTM_AGENT <> 0"
				if CTM_CUSTOM <> 0 then strSel = strSel & " OR CTM_CUSTOM <> 0"
				if CTM_WAREHOUSE <> 0 then strSel = strSel & " OR CTM_WAREHOUSE <> 0"
				if CTM_TRUCKER <> 0 then strSel = strSel & " OR CTM_TRUCKER <> 0"
				if CTM_CARRIER <> 0 then strSel = strSel & " OR CTM_CARRIER <> 0"
				if CTM_AIRLINER <> 0 then strSel = strSel & " OR CTM_AIRLINER <> 0"
				if CTM_OTHER <> 0 then strSel = strSel & " OR CTM_OTHER <> 0"
				if strSel <> "" then strSql = strSql & " AND (" & mid(strSel, 4) & ")"
			end if
			select case mySort
			case 0:		strSQL = strSQL & " ORDER BY CTM_REF"
			case 1:		strSQL = strSQL & " ORDER BY CTM_BELONG, CTM_REF"
			case 2:		strSQL = strSQL & " ORDER BY CTM_NAME"
			case 3:		strSQL = strSQL & " ORDER BY CTM_TEL"
			case 4:		strSQL = strSQL & " ORDER BY CTM_ADDR1"
			case 5:		strSQL = strSQL & " ORDER BY CTM_SALESMNGR, CTM_REF"
			end select
'response.write strSql
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
<div id=list>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		  <colgroup span=2 align=center>
		  <colgroup span=4 align=left>
		  <colgroup span=2 align=center>
		  <TR height=20>
			<TD class=line>��
			<TD class=line style="cursor:hand;color:blue" onmousedown="DoSort(1)">�戵
			<TD class=line style="cursor:hand;color:blue" onmousedown="DoSort(0)">������
			<TD class=line style="cursor:hand;color:blue" onmousedown="DoSort(2)">�ڋq��
			<TD class=line style="cursor:hand;color:blue" onmousedown="DoSort(3)">Tel/Fax
			<TD class=line style="cursor:hand;color:blue" onmousedown="DoSort(4)">�Z��
			<TD class=line style="cursor:hand;color:blue" onmousedown="DoSort(5)">�c��
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else		
						ShopName = GetShopName(.Fields("CTM_BELONG"))
						CtmName = GetString(.Fields("CTM_NAME"))
						TelFax = .Fields("CTM_TEL") & " " & .Fields("CTM_FAX")
						Address = GetString(.Fields("CTM_ADDR"))
					
%>
			<TR style="cursor:hand" onclick="ShowDetail('<%=.Fields("CTM_CD")%>')">
				<TD class=line nowrap><%=lngCount%><BR>
				<TD class=line nowrap><%=ShopName%><BR>
				<TD class=line nowrap><%=GetString(.Fields("CTM_REF"))%><BR>
				<TD class=line nowrap <%=ShowTitle(CtmName, 20)%>><%=StringCut(CtmName,20)%><BR></TD>
				<TD class=line nowrap <%=ShowTitle(TelFax, 30)%>><%=StringCut(TelFax,30)%><BR></TD>
				<TD class=line nowrap <%=ShowTitle(Address, 20)%>><%=StringCut(Address,20)%><BR></TD>
				<TD class=line nowrap><%=GetEmployName(.Fields("CTM_SALESMNGR"), "F")%><BR></TD>
<%
					end if
					.movenext
				loop
%>
	</TABLE>
</div>
<%
			else
				response.write "<p><br><center>�Y���f�[�^��������܂���ł����B</center>"
			end if
		end with
	end if
%>  
  </FORM>
</BODY>
</HTML>
<% 
set recset = nothing
CloseDB Conn

function ShowProvList(myProv)
dim mySql
dim myRec
dim buf
	buf = ""
	set myRec = Server.CreateObject ("ADODB.Recordset")	
	with myRec
		mySql = "SELECT DISTINCT CTM_PROVINCE FROM CUSTOMER"
		mySql = mySql & " WHERE CTM_DELETED = 0"
		mySql = mySql & " ORDER BY CTM_PROVINCE"
		.Open mySql, Conn, adOpenKeyset, adLockReadOnly
		do while not .eof
			buf = buf & "<option value=" & .fields("CTM_PROVINCE")
			if myProv = GetString(.fields("CTM_PROVINCE")) then buf = buf & " selected"
			buf = buf & ">" & .fields("CTM_PROVINCE")
			.movenext
		loop
		.close
	end with
	set myRec = nothing		
	ShowProvList = buf	
end function
%>
