<%
CTM_CD = CSTR(request("CTM_CD"))
%>
<HTML>
<HEAD>
<TITLE>�ڋq�����e�i���X</TITLE>
</HEAD>
	<FRAMESET cols="550,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="customer.asp?CTM_CD=<%=CTM_CD%>" NAME="ctm" MARGINWIDTH="0" MARGINHEIGHT="0" noresize>
		<FRAME SRC="" NAME="info" MARGINWIDTH="10" MARGINHEIGHT="0" noresize>
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>