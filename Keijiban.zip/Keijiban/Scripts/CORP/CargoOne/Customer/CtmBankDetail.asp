<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	BANK_ID = GetLong(request("BANK_ID"))
	if CTM_CD <> "" then
		mode = 0
		if BANK_ID <> 0 then
			OpenSql Conn, SqlServerName, DataBaseName
			set Recset = Server.CreateObject("adodb.recordset") 
			with Recset 
				strSql = "SELECT * FROM CTM_BANK WHERE BANK_DELETED = 0 AND BANK_ID = " & BANK_ID
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					BANK_CD = GetString(.fields("BANK_CD"))
					BANK_NAME = GetString(.fields("BANK_NAME"))
					BANK_BRANCH = GetString(.fields("BANK_BRANCH"))
					BANK_TYPE = GetString(.fields("BANK_TYPE"))
					BANK_ACCOUNT = GetString(.fields("BANK_ACCOUNT"))
					BANK_SPELL = GetString(.fields("BANK_SPELL"))
					BANK_HOLDER = GetString(.fields("BANK_HOLDER"))
					BANK_REMARKS = GetString(.fields("BANK_REMARKS"))
					BANK_DFT = GetLong(.fields("BANK_DFT"))
				end if
				.close
			end with
			set Recset = nothing
			CloseDB Conn
		end if
		
		if BANK_TYPE = "" then BANK_TYPE = "�����a��"
%>
<html>
<HEAD>
	<TITLE>��s�����ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
			if checkText("BANK_CD","��s����",0) = false then exit sub
			if checkText("BANK_NAME","��s����",1) = false then exit sub
			if checkText("BANK_BRANCH","�x�X����",0) = false then exit sub
			if checkText("BANK_TYPE","�������",1) = false then exit sub
			if checkText("BANK_ACCOUNT","�����ԍ�",1) = false then exit sub
			if checkText("BANK_HOLDER","�������`�l",0) = false then exit sub
			if checkText("BANK_SPELL","�Ăѕ�",0) = false then exit sub
			if checkText("BANK_REMARKS","���l", 0) = false then
				exit sub
			elseif checkLen("BANK_REMARKS","���l",255) = false then
				exit sub
			end if		
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CtmBankUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="CTM_CD" value="<%=CTM_CD%>">
  	<input type=hidden name="BANK_ID" value="<%=BANK_ID%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>����s�������&nbsp;
<%if BANK_ID <> 0 then %>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
		<td width=50% align=right>
	  	  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1><%=ShowCustomHead(CTM_CD)%>
	<br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=22>
		<TD width=60>����</TD>
		<TD><input class=si name="BANK_CD" size=6 maxlength=10 value="<%=BANK_CD%>" onkeydown="ResetEnter()">
		<TD class=pt9n width=60>��s��</TD>
		<TD><input class=sj name="BANK_NAME" size=16 maxlength=50 value="<%=BANK_NAME%>" onkeydown="ResetEnter()">
		<TD class=pt9n width=60>�x�X��</TD>
		<TD><input class=sj name="BANK_BRANCH" size=16 maxlength=50 value="<%=BANK_BRANCH%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD class=pt9>���`�l</TD>
		<TD colspan=3><input class=sj name="BANK_HOLDER" size=45 maxlength=100 value="<%=BANK_HOLDER%>" onkeydown="ResetEnter()">
		<TD class=pt9>����</TD>
		<TD><input class=sj name="BANK_SPELL" size=16 maxlength=50 value="<%=BANK_SPELL%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD class=pt9n>�������</TD>
		<TD><input class=sj name="BANK_TYPE" size=10 maxlength=10 value="<%=BANK_TYPE%>" onkeydown="ResetEnter()">
		<TD class=pt9n>�����ԍ�</TD>
		<TD><input class=si name="BANK_ACCOUNT" size=16 maxlength=20 value="<%=BANK_ACCOUNT%>" onkeydown="ResetEnter()">
		<TD class=pt9n>��̫��</TD>
		<TD><input type=checkbox name="BANK_DFT" value="1" onkeydown="ResetEnter()" <%if BANK_DFT then response.write " checked"%>>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=22>
		<TD>���l
		<TD colspan=4><textarea name="BANK_REMARKS" rows=4 style="width:360"><%=BANK_REMARKS%></textarea>
		<TD>
<%if gsSaveButton = 1 then %>
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
	end if
%>