<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�S���҈ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<SCRIPT language=javaScript>
		function ShowDetail(myCD) {
			var win = window.open("CtmPicDetail.asp?CTM_CD=<%=CTM_CD%>&PIC_ID="+myCD,"CtmPicDetail","scrollbars=no,width=600,height=300");
			win.focus();
		}
	</SCRIPT>
</HEAD>
<BODY topmargin=3 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���S����<td width=50% align=right>
	  	<img style="cursor:hand" src=img/new.gif alt="�V�K�ǉ�" onmousedown="ShowDetail('');">
	</table>
	<hr size=1>
<%
	with recset
		strSql = "SELECT PIC_ID, PIC_CD, PIC_NAME, PIC_TEL, PIC_FAX, PIC_CELL, PIC_DFT"
		strSql = strSql & " FROM CTM_PIC WHERE PIC_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
		strSql = strSql & " ORDER BY PIC_DFT DESC, PIC_CD, PIC_ID"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20>
		<TD class=line nowrap>����
		<TD class=line nowrap>�S����
		<TD class=line nowrap>TEL
		<TD class=line nowrap>FAX
		<TD class=line nowrap>�g��
<%
			do while not .eof				
				PicName = GetString(.Fields("PIC_NAME"))
				PicTel = GetString(.Fields("PIC_TEL"))
				PicFax = GetString(.Fields("PIC_FAX"))
				PicCell = GetString(.Fields("PIC_CELL"))
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("PIC_ID")%>');">
					<TD class=line nowrap><%=GetString(.Fields("PIC_CD"))%><BR>
					<TD class=line nowrap <%=ShowTitle(PicName, 10)%>><%=StringCut(PicName,10)%><BR>
					<TD class=line nowrap <%=ShowTitle(PicTel, 15)%>><%=StringCut(PicTel,15)%><BR>
					<TD class=line nowrap <%=ShowTitle(PicFax, 15)%>><%=StringCut(PicFax,15)%><BR>
					<TD class=line nowrap <%=ShowTitle(PicCell, 15)%>><%=StringCut(PicCell,15)%><BR>
<%
				.movenext
			loop
%>
	</TABLE>
<%
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
