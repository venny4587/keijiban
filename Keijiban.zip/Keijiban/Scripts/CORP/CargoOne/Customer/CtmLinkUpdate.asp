<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	CTM_CD = GetPost(request("CTM_CD"))
	LINK_ID = GetLong(request("LINK_ID"))
	
	msg = ""
	OpenSql Conn, SqlServerName, DataBaseName
	
	mode = GetLong(request("mode"))	
	if mode = -1 then
	
		strSql = "UPDATE CTM_LINK SET LINK_DELETED = 1"
		strSql = strSql & ",LINK_UPDATED = GETDATE()" 
		strSql = strSql & ",LINK_UPDATER = " & WebUserID 
		strSql = strSql & " WHERE LINK_ID = " & LINK_ID
		Conn.Execute strSql

	elseif CTM_CD <> "" then
	
		set Recset = Server.CreateObject("adodb.recordset")
		
		if mode = 0 then
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "CTM_LINK"	
			cmdSQL.Execute
			LINK_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
		
		with Recset
			strSql = "SELECT * FROM CTM_LINK WHERE LINK_ID = " & LINK_ID
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then
				.AddNew
				.fields("CTM_CD") = CTM_CD
				.fields("LINK_ID") = LINK_ID
				
				.fields("LINK_CREATER") = WebUserID
				.fields("LINK_CREATED") = now
				.fields("LINK_DELETED") = 0
			end if
			.fields("LINK_CD") = GetPost(request("LINK_CD"))
			.fields("LINK_TYPE") = GetLong(request("LINK_TYPE"))
			.fields("LINK_REF") = GetPost(request("LINK_REF"))
			.fields("LINK_NAME") = GetPost(request("LINK_NAME"))
			.fields("LINK_INFO1") = GetPost(request("LINK_INFO1"))
			.fields("LINK_INFO2") = GetPost(request("LINK_INFO2"))
			.fields("LINK_INFO3") = GetPost(request("LINK_INFO3"))
			.fields("LINK_INFO4") = GetPost(request("LINK_INFO4"))
			.fields("LINK_REMARKS") = GetPost(request("LINK_REMARKS"))
			.fields("LINK_DFT") = GetLong(request("LINK_DFT"))
	
			.fields("LINK_UPDATER") = WebUserID
			.fields("LINK_UPDATED") = now
			.update
			.close
		end with
		set Recset = nothing
		
	end if
	CloseDB Conn
	
	if msg <> "" then
		ShowMessage msg
	else
%>
<html>
<script language=javascript>
	window.opener.location.href = "CtmLinkList.asp?CTM_CD=<%=CTM_CD%>";
	window.close();
</script>
</html>
<%
	end if
%>