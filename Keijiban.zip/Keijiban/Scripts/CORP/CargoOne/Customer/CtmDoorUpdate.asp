<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	CTM_CD = GetPost(request("CTM_CD"))
	DOOR_ID = GetLong(request("DOOR_ID"))
	
	msg = ""
	OpenSql Conn, SqlServerName, DataBaseName
	
	mode = GetLong(request("mode"))
	if mode = -1 then

		strSql = "UPDATE CTM_DOOR SET DOOR_DELETED = 1"
		strSql = strSql & ",DOOR_UPDATED = GETDATE()" 
		strSql = strSql & ",DOOR_UPDATER = " & WebUserID 
		strSql = strSql & " WHERE DOOR_ID = " & DOOR_ID
		Conn.Execute strSql
		
	elseif CTM_CD <> "" then
	
		set Recset = Server.CreateObject("adodb.recordset")
		
		if mode = 0 then
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "CTM_DOOR"	
			cmdSQL.Execute
			DOOR_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
		
		with Recset
			strSql = "SELECT * FROM CTM_DOOR WHERE DOOR_ID = " & DOOR_ID
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then
				.AddNew
				.fields("CTM_CD") = CTM_CD
				.fields("DOOR_ID") = DOOR_ID
				
				.fields("DOOR_CREATER") = WebUserID
				.fields("DOOR_CREATED") = now
				.fields("DOOR_DELETED") = 0
			end if
			.fields("DOOR_CD") = GetPost(request("DOOR_CD"))
			.fields("DOOR_NAME") = GetPost(request("DOOR_NAME"))
			.fields("DOOR_PIC") = GetPost(request("DOOR_PIC"))
			.fields("DOOR_ZIP") = GetPost(request("DOOR_ZIP"))
			.fields("DOOR_ADDR1") = GetPost(request("DOOR_ADDR1"))
			.fields("DOOR_ADDR2") = GetPost(request("DOOR_ADDR2"))
			.fields("DOOR_TEL") = GetPost(request("DOOR_TEL"))
			.fields("DOOR_FAX") = GetPost(request("DOOR_FAX"))
			.fields("DOOR_MAIL") = GetPost(request("DOOR_MAIL"))
			.fields("DOOR_CELL") = GetPost(request("DOOR_CELL"))
			.fields("DOOR_REMARKS") = GetPost(request("DOOR_REMARKS"))
			.fields("DOOR_DFT") = GetLong(request("DOOR_DFT"))
	
			.fields("DOOR_UPDATER") = WebUserID
			.fields("DOOR_UPDATED") = now
			.update
			.close
		end with
		set Recset = nothing		
	end if
	CloseDB Conn
	
	if msg <> "" then
		ShowMessage msg
	else
%>
<html>
<script language=javascript>
	window.opener.location.href = "CtmDoorList.asp?CTM_CD=<%=CTM_CD%>";
	window.close();
</script>
</html>
<%
	end if
%>