<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�����ԍ��ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<SCRIPT language=javaScript>
		function ShowDetail(myCD) {
			var win = window.open("CtmBankDetail.asp?CTM_CD=<%=CTM_CD%>&BANK_ID="+myCD,"CtmBank","scrollbars=1,width=600,height=300");
			win.focus();
		}		
	</SCRIPT>
</HEAD>
<BODY topmargin=0 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>����s����<td width=50% align=right>
	  	<img style="cursor:hand" src=img/new.gif alt="�V�K�ǉ�" onmousedown="ShowDetail('');">
	</table>
	<hr size=1>
<%
	with recset
		strSql = "SELECT BANK_ID, BANK_CD, BANK_NAME, BANK_BRANCH, BANK_TYPE, BANK_ACCOUNT, BANK_DFT"
		strSql = strSql & " FROM CTM_BANK WHERE BANK_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
		strSql = strSql & " ORDER BY BANK_DFT DESC, BANK_CD, BANK_ID"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20>
		<TD class=line>����
		<TD class=line>��s��
		<TD class=line>�x�X��
		<TD class=line>�a�����
		<TD class=line>�����ԍ�

<%
			do while not .eof				
				BankName = GetString(.Fields("BANK_NAME"))
				BankBranch = GetString(.Fields("BANK_BRANCH"))
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("BANK_ID")%>');">
					<TD class=line nowrap><%=GetString(.Fields("BANK_CD"))%><BR>
					<TD class=line nowrap <%=ShowTitle(BankName, 10)%>><%=StringCut(BankName,10)%><BR>
					<TD class=line nowrap <%=ShowTitle(BankBranch, 10)%>><%=StringCut(BankBranch,10)%><BR>
					<TD class=line nowrap><%=GetString(.Fields("BANK_TYPE"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("BANK_ACCOUNT"))%><BR>
<%
				.movenext
			loop
%>
	</TABLE>
<%
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
