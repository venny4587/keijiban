<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	CTM_REF = GetPost(request("CTM_REF"))
	CTM_ABR = GetPost(request("CTM_ABR"))
	CTM_TEL = GetTelFaxIndex(request("CTM_TEL"))
	CTM_FAX = GetTelFaxIndex(request("CTM_FAX"))
			
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
%>
<HTML>
<HEAD>
	<TITLE>�d���ڋq�ꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=javascript>
		function ShowCTM(myCD) {
		    window.parent.ctm.location.href = "customer.asp?CTM_CD=" + myCD;
		}
	</script>
</HEAD>
<BODY topmargin=10 <%=gsBodyControl%>>
<%
	strSel = ""
	if CTM_REF <> "" then strSel = strSel & " OR CTM_REF = '" & CTM_REF & "'"
	if CTM_ABR <> "" then strSel = strSel & " OR CTM_ABR = '" & CTM_ABR & "'"		
	if strSel <> "" then 		
		with Recset
			strSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_NAME, CTM_ABR FROM CUSTOMER WHERE CTM_DELETED = 0 AND (" & mid(strSel, 4) & ")"
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
%>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		<TR><td>���������̏d��</table>
	<hr size=1>	
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		<TR height=20>
			<TD class=line nowrap>��������
			<TD class=line nowrap>�p�ꖼ��
			<TD class=line nowrap>���{����
			<TD class=line nowrap>���{����
<%
				Do Until .EOF
					ref = GetString(.Fields("CTM_REF"))
					enm = GetString(.Fields("CTM_ENAME"))
					abr = GetString(.Fields("CTM_ABR"))
					jnm = GetString(.Fields("CTM_NAME"))
					
					if ref = CTM_REF then ref = "<font color=red>" & ref & "</font>"
					if abr = CTM_ABR then abr = "<font color=red>" & abr & "</font>"
%>
		<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowCTM('<%=.Fields("CTM_CD")%>');">
			<TD class=line nowrap><%=ref%><BR>
			<TD class=line nowrap <%=ShowTitle(enm, 30)%>><%=StringCut(enm,30)%><BR>
			<TD class=line nowrap><%=abr%><BR>
			<TD class=line nowrap <%=ShowTitle(jnm, 20)%>><%=StringCut(jnm,20)%><BR>
<%
					.MoveNext
				Loop					
%>
	</TABLE>

<%
			End If
			.Close 
		end with
	end if
	
	strSel = ""
	if CTM_TEL <> "" then strSel = strSel & " OR CTM_TEL_IDX LIKE '%" & CTM_TEL & "%'"
	if CTM_FAX <> "" then strSel = strSel & " OR CTM_TEL_IDX LIKE '%" & CTM_FAX & "%'"		
	if strSel <> "" then 	
		with Recset	
			strSql = "SELECT CTM_CD, CTM_REF, CTM_ABR, CTM_TEL, CTM_FAX FROM CUSTOMER WHERE CTM_DELETED = 0 AND (" & mid(strSel, 4) & ")"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
%>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
		<TR><td>��TEL/FAX�d��</table>
	<hr size=1>	
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
		<TR height=20>
			<TD class=line nowrap>��������
			<TD class=line nowrap>���{����
			<TD class=line nowrap>CTM_TEL
			<TD class=line nowrap>CTM_FAX
<%
			Do Until .EOF
				ref = GetString(.Fields("CTM_REF"))
				abr = GetString(.Fields("CTM_ABR"))
				tel = GetString(.Fields("CTM_TEL"))
				fax = GetString(.Fields("CTM_FAX"))
%>
		<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowCTM('<%=.Fields("CTM_CD")%>');">
			<TD class=line nowrap><%=ref%><BR>
			<TD class=line nowrap><%=abr%><BR>
			<TD class=line nowrap <%=ShowTitle(tel, 30)%>><%=StringCut(tel,30)%><BR>
			<TD class=line nowrap <%=ShowTitle(fax, 30)%>><%=StringCut(fax,30)%><BR>
<%
					.MoveNext
				Loop					
%>
	</TABLE>

<%
			End If
			.Close 
		end with
	end if
%>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
%>