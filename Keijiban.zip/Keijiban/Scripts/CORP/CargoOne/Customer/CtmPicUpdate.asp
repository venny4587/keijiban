<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	CTM_CD = GetPost(request("CTM_CD"))
	PIC_ID = GetLong(request("PIC_ID"))
	
	msg = ""
	OpenSql Conn, SqlServerName, DataBaseName
	
	mode = GetLong(request("mode"))	
	if mode = -1 then

		strSql = "UPDATE CTM_PIC SET PIC_DELETED = 1"
		strSql = strSql & ",PIC_UPDATED = GETDATE()" 
		strSql = strSql & ",PIC_UPDATER = " & WebUserID 
		strSql = strSql & " WHERE PIC_ID = " & PIC_ID
		Conn.Execute strSql

	elseif CTM_CD <> "" then
	
		if mode = 0 then
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "CTM_PIC"	
			cmdSQL.Execute
			PIC_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
		
		set Recset = Server.CreateObject("adodb.recordset")
		with Recset
			strSql = "SELECT * FROM CTM_PIC WHERE PIC_ID = " & PIC_ID 
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if .eof then
				.AddNew
				.fields("CTM_CD") = CTM_CD
				.fields("PIC_ID") = PIC_ID
				
				.fields("PIC_CREATER") = WebUserID
				.fields("PIC_CREATED") = now
				.fields("PIC_DELETED") = 0
			end if
			.fields("PIC_CD") = GetPost(request("PIC_CD"))
			.fields("PIC_NAME") = GetPost(request("PIC_NAME"))
			.fields("PIC_DPT") = GetPost(request("PIC_DPT"))
			.fields("PIC_POS") = GetPost(request("PIC_POS"))
			.fields("PIC_TEL") = GetPost(request("PIC_TEL"))
			.fields("PIC_FAX") = GetPost(request("PIC_FAX"))
			.fields("PIC_TEL_IDX") = GetTelFaxIndex(GetString(Request("PIC_TEL")) & "/" & GetString(Request("PIC_FAX")) & "/" & GetString(Request("PIC_CELL")))
			.fields("PIC_MAIL") = GetPost(request("PIC_MAIL"))
			.fields("PIC_CELL") = GetPost(request("PIC_CELL"))
			.fields("PIC_UID") = GetPost(request("PIC_UID"))
			.fields("PIC_PWD") = GetPost(request("PIC_PWD"))
			.fields("PIC_REMARKS") = GetPost(request("PIC_REMARKS"))
			.fields("PIC_DFT") = GetLong(request("PIC_DFT"))
	
			.fields("PIC_UPDATER") = WebUserID
			.fields("PIC_UPDATED") = now
			.update
			.close
		end with
		set Recset = nothing
	end if
	CloseDB Conn
	
	if msg <> "" then
		ShowMessage msg
	else
%>
<html>
<script language=javascript>
	window.opener.location.href = "CtmPicList.asp?CTM_CD=<%=CTM_CD%>";
	window.close();
</script>
</html>
<%
	end if
%>