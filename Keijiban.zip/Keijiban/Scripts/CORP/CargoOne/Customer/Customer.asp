<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim SelShop
	SelShop = GetPost(request("SelShop"))
	if CheckTopLevel() = 0 then SelShop = UserShop

	CTM_CD = GetPost(request("CTM_CD"))
	if CTM_CD <> "" then
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset 
			strSql = "SELECT * FROM CUSTOMER WHERE CTM_CD = '" & CTM_CD & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				Session("CTM_CD") = CTM_CD
				CTM_REF = GetString(.Fields("CTM_REF"))
				CTM_ENAME = GetString(.Fields("CTM_ENAME"))
				CTM_NAME = GetString(.Fields("CTM_NAME"))
				CTM_ABR = GetString(.Fields("CTM_ABR"))
				CTM_TYPE = GetLong(.Fields("CTM_TYPE"))
				CTM_BELONG = GetString(.Fields("CTM_BELONG"))
				CTM_INTRODUCER = GetString(.Fields("CTM_INTRODUCER"))
				CTM_SALESMNGR = GetLong(.Fields("CTM_SALESMNGR"))
				CTM_EXPORT_MNGR = GetLong(.Fields("CTM_EXPORT_MNGR"))
				CTM_IMPORT_MNGR = GetLong(.Fields("CTM_IMPORT_MNGR"))
				CTM_SALESMNGR = GetLong(.Fields("CTM_SALESMNGR"))
				CTM_FINANCE_CD = GetString(.Fields("CTM_FINANCE_CD"))
				CTM_NACCS_CD = GetString(.Fields("CTM_NACCS_CD"))
				CTM_ZIP = GetString(.Fields("CTM_ZIP"))
				CTM_ADDR1 = GetString(.Fields("CTM_ADDR1"))
				CTM_ADDR2 = GetString(.Fields("CTM_ADDR2"))
				CTM_CITY = GetString(.Fields("CTM_CITY"))
				CTM_PROVINCE = GetString(.Fields("CTM_PROVINCE"))
				CTM_COUNTRY = GetString(.Fields("CTM_COUNTRY"))
				CTM_CHAIRMAN = GetString(.Fields("CTM_CHAIRMAN"))
				CTM_TEL = GetString(.Fields("CTM_TEL"))
				CTM_FAX = GetString(.Fields("CTM_FAX"))
				CTM_URL = GetString(.Fields("CTM_URL"))
				CTM_CLIENT = GetLong(.Fields("CTM_CLIENT"))
				CTM_BROKER = GetLong(.Fields("CTM_BROKER"))
				CTM_SHIPPER = GetLong(.Fields("CTM_SHIPPER"))
				CTM_CONSIGNEE = GetLong(.Fields("CTM_CONSIGNEE"))
				CTM_NOTIFY = GetLong(.Fields("CTM_NOTIFY"))
				CTM_CUSTOM = GetLong(.Fields("CTM_CUSTOM"))
				CTM_CARRIER = GetLong(.Fields("CTM_CARRIER"))
				CTM_AIRLINER = GetLong(.Fields("CTM_AIRLINER"))
				CTM_TRUCKER = GetLong(.Fields("CTM_TRUCKER"))
				CTM_WAREHOUSE = GetLong(.Fields("CTM_WAREHOUSE"))
				CTM_AGENT = GetLong(.Fields("CTM_AGENT"))
				CTM_OTHER = GetLong(.Fields("CTM_OTHER"))
				CTM_PARENT_CD = GetString(.Fields("CTM_PARENT_CD"))
				CTM_BRANCH = GetString(.Fields("CTM_BRANCH"))
				CTM_DEPART = GetString(.Fields("CTM_DEPART"))	
				CTM_ETC_CODE = GetString(.Fields("CTM_ETC_CODE"))
				CTM_ETC_DATA = GetString(.Fields("CTM_ETC_DATA"))		
				CTM_NATURE_MAIN = GetString(.Fields("CTM_NATURE_MAIN"))
				CTM_NATURE_SUB = GetString(.Fields("CTM_NATURE_SUB"))
				CTM_CAPITAL = GetString(.Fields("CTM_CAPITAL"))
				CTM_REMARKS = GetString(.Fields("CTM_REMARKS"))
				CTM_BLACK = GetLong(.Fields("CTM_BLACK"))
				CTM_SLEEP = GetLong(.Fields("CTM_SLEEP"))	
			end if
			.close
		end with
	else
		CTM_ETC_CODE = ctmInsurance(0)
	end if
%>

<html>
<HEAD>
	<TITLE>�ڋq�o�^</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub Addnew()
			window.parent.location.href = "mainframe.asp"
		end sub
		
		function DoMove(cd)
	  	<%if CheckTopLevel() > 0 then%>
			window.location.href = "customer.asp?CTM_CD=" & cd & "&SelShop=" & frmInput.SelShop.options(frmInput.SelShop.selectedIndex).value
		<%else%>
			window.location.href = "customer.asp?CTM_CD=" & cd & "&SelShop=<%=SelShop%>"
		<%end if%>
		end function
		
		sub DoContact()
			set win = window.open("CtmContact.asp?CTM_CD=<%=CTM_CD%>","CtmContact","scrollbars=1,width=600,height=300") 
			win.focus()
		end sub
		
		sub ShowKokSearch()
			set win = window.open("ctmSearch.asp","ctmSearch","scrollbars=1,width=800,height=500") 
			win.focus()
		end sub
		
		sub InitForm()
			<%if CTM_CD <> "" then%> 
				window.parent.info.location.href = "CtmInfo.asp?CTM_CD=<%=CTM_CD%>"
			<%end if%>
		end sub
		
		sub DataSave()
			if checkText("CTM_REF","��������",1) = false then exit sub
			if checkText("CTM_NACCS_CD","NACCS����",0) = false then exit sub
			if checkText("CTM_FINANCE_CD","��������",0) = false then exit sub
			if checkText("CTM_ENAME","�p�ꖼ��",1) = false then exit sub
			if checkText("CTM_ABR","���{�ꗪ��",1) = false then exit sub
			if checkText("CTM_NAME","���{�ꖼ��",1) = false then exit sub
			if checkText("CTM_CHAIRMAN","�@�l��\",0) = false then exit sub
			if checkText("CTM_CAPITAL","���{��",0) = false then exit sub
			if checkText("CTM_ZIP","�X�֔ԍ�",0) = false then exit sub
			if checkText("CTM_ADDR1","�Z��1",0) = false then exit sub
			if checkText("CTM_ADDR2","�Z��2",0) = false then exit sub
			if checkText("CTM_ETC_CODE","��ی�",0) = false then exit sub
			if checkText("CTM_ETC_DATA","���[�ԍ�",0) = false then exit sub
			if checkText("CTM_TEL","TEL",0) = false then exit sub
			if checkText("CTM_FAX","FAX",0) = false then exit sub
			if checkText("CTM_URL","URL",0) = false then exit sub
			if checkText("CTM_BRANCH","�x�Ж�",0) = false then exit sub
			if checkText("CTM_DEPART","���喼",0) = false then exit sub
			if checkText("CTM_INTRODUCER","�ŏ����",0) = false then exit sub
			if checkText("CTM_REMARKS","���l", 0) = false then exit sub
			if checkLen("CTM_REMARKS","���l",255) = false then exit sub
<%if CheckTopLevel() > 0 or UserShop = CTM_BELONG then%>
			if frmInput.CTM_SALESMNGR.selectedindex < 1 then 
				msgbox "�c�ƒS���҂�I��ł��������B",48, "�m�F���b�Z�[�W"
				exit sub
			end if
<%end if%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",289, "�m�F���b�Z�[�W") = 1 then frmInput.submit()
		end sub
		
<%if CTM_CD = "" then%>		
		sub CTM_REF_OnChange()
			call showRep()
		end sub
		
		sub CTM_ABR_OnChange()
			call showRep()
		end sub
		
		sub CTM_TEL_OnChange()
			call showRep()
		end sub
		
		sub CTM_FAX_OnChange()
			call showRep()
		end sub
		
		sub SelShop_OnChange()
			call DoMove("")
		end sub
		
		sub showRep()
		dim myUrl
			myUrl = "CtmRepeat.asp?CTM_REF=" & frmInput.CTM_REF.value
			myUrl = myUrl & "&CTM_ABR=" & frmInput.CTM_ABR.value
			myUrl = myUrl & "&CTM_TEL=" & frmInput.CTM_TEL.value
			myUrl = myUrl & "&CTM_FAX=" & frmInput.CTM_FAX.value
			window.parent.info.location.href = myUrl
		end sub
<%end if%>
	-->
	</SCRIPT>
</Head>
<body topmargin=3 onload="InitForm()" class=pt9 <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CtmUpdate.asp" method="post">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=40%>����{���&nbsp;<%=ShowBar(CTM_CD)%>
	  	<img style="cursor:hand" src=img/new.gif alt="�V�K�ǉ�" onmousedown="Addnew()">
	  	<td width=40%>����&nbsp;
	  	<%if CheckTopLevel() > 0 then%>
	  		<SELECT name="SelShop" onkeydown="ResetEnter()"><option value="">���ׂ�<%=ShowShopList(SelShop)%></select>
	  	<%else%>
	  		<%=GetShopName(UserShop)%><input type=hidden name="SelShop" value="<%=UserShop%>">
	  	<%end if%>
	  	<td width=20% align=right><img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1 color=blue>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=22>
		<TD width=60>�ڋq����
		<TD><input class=si name="CTM_CD" size=8 maxlength=10 value="<%=CTM_CD%>" onkeydown="ResetEnter()" readonly>
			<img style="cursor:hand" src=img/search.jpg alt="����" onmousedown="ShowKokSearch()">
		<TD width=65>��������
		<TD><SELECT name="CTM_TYPE" onkeydown="ResetEnter()"><%
			for i = 0 to ubound(ctmType)
				response.write "<option value=" & i
				if CTM_TYPE = i then response.write " selected" 
				response.write ">" & ctmType(i)
			next%></SELECT>
		<TD width=60 class=pt9t>�戵�敪
		<TD><SELECT name="CTM_BELONG" onkeydown="ResetEnter()"><%=ShowShopList(CTM_BELONG)%></select>
	  <TR height=22>
		<TD class=pt9b>��������
		<TD><input class=si name="CTM_REF" size=10 maxlength=10 value="<%=CTM_REF%>" onkeydown="ResetEnter()">
		<TD>NACCS����
		<TD><input class=si name="CTM_NACCS_CD" size=12 maxlength=25 value="<%=CTM_NACCS_CD%>" onkeydown="ResetEnter()">
		<TD>��ی�
		<TD><input class=sj name="CTM_ETC_CODE" size=12 maxlength=50 value="<%=CTM_ETC_CODE%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD>�p������
		<TD colspan=3><input class=si name="CTM_ENAME" size=45 maxlength=100 value="<%=CTM_ENAME%>" onkeydown="ResetEnter()">
		<TD>���[�ԍ�
		<TD><input class=sj name="CTM_ETC_DATA" size=13 maxlength=50 value="<%=CTM_ETC_DATA%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD>�a������
		<TD colspan=3><input class=sj name="CTM_NAME" size=45 maxlength=50 value="<%=CTM_NAME%>" onkeydown="ResetEnter()">
		<TD>��������
		<TD><input class=si name="CTM_FINANCE_CD" size=12 maxlength=10 value="<%=CTM_FINANCE_CD%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD>�a������
		<TD><input class=sj name="CTM_ABR" size=12 maxlength=20 value="<%=CTM_ABR%>" onkeydown="ResetEnter()">
		<TD>�@�l��\
		<TD><input class=sj name="CTM_CHAIRMAN" size=12 maxlength=20 value="<%=CTM_CHAIRMAN%>" onkeydown="ResetEnter()">
		<TD>���{��
		<TD><input class=sj name="CTM_CAPITAL" size=12 maxlength=10 value="<%=CTM_CAPITAL%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD>�X�֔ԍ�
		<TD><input class=si name="CTM_ZIP" size=8 maxlength=8 value="<%=CTM_ZIP%>" onkeydown="ResetEnter()">
		<TD>�s���{��
		<TD><SELECT name="CTM_PROVINCE" onkeydown="ResetEnter()"><%
			for i = 1 to ubound(aPref)
				response.write "<option value=" & aPref(i)
				if CTM_PROVINCE = aPref(i) then response.write " selected" 
				response.write ">" & aPref(i)
			next%></SELECT>
		<TD class=pt9t>�c�ƒS��
<%if CheckTopLevel() > 0 or UserShop = CTM_BELONG then%>
		<TD><SELECT name="CTM_SALESMNGR" onkeydown="ResetEnter()"><option value=0>�s��<%=ShowEmployList(DepartSales, CTM_SALESMNGR)%>
			<option value="60" <%if CTM_SALESMNGR = 60 then response.write "selected"%>>�R��</select>
<%else%>
		<TD class=pt9g><input type=hidden name="CTM_SALESMNGR" value="<%=CTM_SALESMNGR%>"><%=GetEmployName(CTM_SALESMNGR, "F")%>
<%end if%>
	  <TR height=22>
		<TD>�Z��1
		<TD colspan=3><input class=sj name="CTM_ADDR1" size=45 maxlength=100 value="<%=CTM_ADDR1%>" onkeydown="ResetEnter()">
		<TD>�A�o�S��
		<TD><SELECT name="CTM_EXPORT_MNGR" onkeydown="ResetEnter()"><option value=0>�s��<%=ShowEmployList(DepartExport, CTM_EXPORT_MNGR)%></select>
	  <TR height=22>
		<TD>�Z��2
		<TD colspan=3><input class=sj name="CTM_ADDR2" size=45 maxlength=100 value="<%=CTM_ADDR2%>" onkeydown="ResetEnter()">
		<TD>�A���S��
		<TD><SELECT name="CTM_IMPORT_MNGR" onkeydown="ResetEnter()"><option value=0>�s��<%=ShowEmployList(DepartImport, CTM_IMPORT_MNGR)%></select>
	  <TR height=22>
		<TD>TEL
		<TD><input class=si name="CTM_TEL" size=15 maxlength=50 value="<%=CTM_TEL%>" onkeydown="ResetEnter()">
		<TD>FAX
		<TD><input class=si name="CTM_FAX" size=15 maxlength=50 value="<%=CTM_FAX%>" onkeydown="ResetEnter()">
		<TD>URL
		<TD><input class=sj name="CTM_URL" size=15 maxlength=50 value="<%=CTM_URL%>" onkeydown="ResetEnter()">
	  <TR height=22>		
		<TD>�x�Ж�
		<TD><input class=sj name="CTM_BRANCH" size=15 maxlength=50 value="<%=CTM_BRANCH%>" onkeydown="ResetEnter()">
		<TD>���喼
		<TD><input class=sj name="CTM_DEPART" size=15 maxlength=50 value="<%=CTM_DEPART%>" onkeydown="ResetEnter()">
		<TD>�ŏ����
		<TD><input class=sj name="CTM_INTRODUCER" size=15 maxlength=20 value="<%=CTM_INTRODUCER%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD colspan=6><table class=pt9 width=100%><TR height=22>
			<td><input type=checkbox name="CTM_CLIENT" value="1" onkeydown="ResetEnter()" <%if CTM_CLIENT then response.write " checked"%>>�ڋq
			<td><input type=checkbox name="CTM_SHIPPER" value="1" onkeydown="ResetEnter()" <%if CTM_SHIPPER then response.write " checked"%>>�ב��l
			<td><input type=checkbox name="CTM_CONSIGNEE" value="1" onkeydown="ResetEnter()" <%if CTM_CONSIGNEE then response.write " checked"%>>�׎�l
			<td><input type=checkbox name="CTM_NOTIFY" value="1" onkeydown="ResetEnter()" <%if CTM_NOTIFY then response.write " checked"%>>�ʒm�l
			<td><input type=checkbox name="CTM_BROKER" value="1" onkeydown="ResetEnter()" <%if CTM_BROKER then response.write " checked"%>>��s��
			<td><input type=checkbox name="CTM_AGENT" value="1" onkeydown="ResetEnter()" <%if CTM_AGENT then response.write " checked"%>>�C�O�㗝
		  <TR height=22>
			<td><input type=checkbox name="CTM_CUSTOM" value="1" onkeydown="ResetEnter()" <%if CTM_CUSTOM then response.write " checked"%>>�ʊ֋Ǝ�
			<td><input type=checkbox name="CTM_WAREHOUSE" value="1" onkeydown="ResetEnter()" <%if CTM_WAREHOUSE then response.write " checked"%>>�q�ɋƎ�
			<td><input type=checkbox name="CTM_TRUCKER" value="1" onkeydown="ResetEnter()" <%if CTM_TRUCKER then response.write " checked"%>>�^���Ǝ�
			<td><input type=checkbox name="CTM_CARRIER" value="1" onkeydown="ResetEnter()" <%if CTM_CARRIER then response.write " checked"%>>�D���
			<td><input type=checkbox name="CTM_AIRLINER" value="1" onkeydown="ResetEnter()" <%if CTM_AIRLINER then response.write " checked"%>>�q����
			<td><input type=checkbox name="CTM_OTHER" value="1" onkeydown="ResetEnter()" <%if CTM_OTHER then response.write " checked"%>>���̑�</table>
	  <TR height=22>
		<TD align=center>���l<TD colspan=5><textarea name="CTM_REMARKS" style="width:450; height:60"><%=CTM_REMARKS%></textarea>
	</Table>
  </FORM>
<%
	if CTM_CD <> "" then
		with Recset 
			strSql = "SELECT * FROM CTM_CONTACT WHERE CTM_CD = '" & CTM_CD & "' ORDER BY CONTACT_DATE DESC"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
%>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���_����<td width=50% align=right>
<%
	myFlag = 0
	if CTM_SALESMNGR = WebuserID then
		myFlag = 1
	else
		select case WebuserID 
		case 1, 2, 24, 36, 37, 46, 47, 70, 73, 74
			myFlag = 1
		end select
	end if
	if myFlag = 1 then
		if .eof then %>
	  		<img style="cursor:hand" src=img/new.gif alt="�V�K" onmousedown="DoContact()">
	  	<%else %>
	  		<img style="cursor:hand" src=img/open.gif alt="�ҏW" onmousedown="DoContact()">
	  	<%end if
	end if %>
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
<%
			if not .eof then
				if CTM_CLIENT OR CTM_SHIPPER or CTM_CONSIGNEE or CTM_NOTIFY then
%>
	  <TR height=22>
		<TD class=line>�敪
		<TD class=line>���ߓ�
		<TD class=line>������
		<TD class=line>�x�����@
		<TD class=line>�敪
		<TD class=line>���ߓ�
		<TD class=line>������
		<TD class=line>�x�����@
	  <TR height=20>
	  	<TD class=line style="color:blue">����
	  	<TD class=line><%=ShowClose(GetLong(.fields("CTM_SALES_CLOSE")))%>
	  	<TD class=line><%=ctmCredit(GetLong(.fields("CTM_SALES_CREDIT"))) & ShowPayDay(GetLong(.fields("CTM_SALES_PAYDAY")))%>
	  	<TD class=line><%=GetString(.fields("CTM_SALES_PAYMENT"))%><br>
	  	<TD class=line style="color:green">����
	  	<TD class=line><%=ShowClose(GetLong(.fields("CTM_STAND_CLOSE")))%>
	  	<TD class=line><%=ctmCredit(GetLong(.fields("CTM_STAND_CREDIT"))) & ShowPayDay(GetLong(.fields("CTM_STAND_PAYDAY")))%>
	  	<TD class=line><%=GetString(.fields("CTM_STAND_PAYMENT"))%><br>
<%
				else
%>
	  <TR height=22>
		<TD class=line>�敪
		<TD class=line>���ߓ�
		<TD class=line>�x����
		<TD class=line>�x�����@
		<TD class=line>�敪
		<TD class=line>���ߓ�
		<TD class=line>�x����
		<TD class=line>�x�����@
	  <TR height=20>
	  	<TD class=line style="color:green">����
	  	<TD class=line><%=ShowClose(GetLong(.fields("CTM_STAND_CLOSE")))%>
	  	<TD class=line><%=ctmCredit(GetLong(.fields("CTM_STAND_CREDIT"))) & ShowPayDay(GetLong(.fields("CTM_STAND_PAYDAY")))%>
	  	<TD class=line><%=GetString(.fields("CTM_STAND_PAYMENT"))%><br>
	  	<TD class=line style="color:black">����
	  	<TD class=line><%=ShowClose(GetLong(.fields("CTM_COSTS_CLOSE")))%>
	  	<TD class=line><%=ctmCredit(GetLong(.fields("CTM_COSTS_CREDIT"))) & ShowPayDay(GetLong(.fields("CTM_COSTS_PAYDAY")))%>
	  	<TD class=line><%=GetString(.fields("CTM_COSTS_PAYMENT"))%><br>
<%			
				end if
			end if
			.close
		end with
%>
	</TABLE><br>
	<IFRAME name=frameView FRAMEBORDER=0 scrolling=auto SRC="CtmBankList.asp?CTM_CD=<%=CTM_CD%>" height=30% width=100%></IFRAME>
<%end if%>
<center>
</body></html>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowBar(myCD)
dim maxcd, mincd, precd, nextcd
dim buf, myRec, myCon
	buf = ""
	OpenSql myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject("adodb.recordset") 
	with myRec 
		strSql = "SELECT MIN(CTM_CD) AS MIN_CD, MAX(CTM_CD) AS MAX_CD FROM CUSTOMER"
		if SelShop <> "" then strSql = strSql & " WHERE CTM_DELETED = 0 AND CTM_BELONG = '" & SelShop & "'"
		.Open strSql,myCon,adOpenStatic,adLockReadOnly
		if not .eof then
			mincd = GetString(.fields("MIN_CD"))
			maxcd = GetString(.fields("MAX_CD"))
		end if
		.close
		
		precd = ""
		if GetString(myCD) <> "" then
			strSql = "SELECT TOP 1 CTM_CD FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_CD < '" & myCD & "'"
			if SelShop <> "" then strSql = strSql & " AND CTM_BELONG = '" & SelShop & "'"
			strSql = strSql & " ORDER BY CTM_CD DESC"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then precd = GetString(.fields("CTM_CD"))
			.close
		else
			precd = mincd
		end if
		
		nextcd = ""
		if GetString(myCD) <> "" then
			strSql = "SELECT TOP 1 CTM_CD FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_CD > '" & myCD & "'"
			if SelShop <> "" then strSql = strSql & " AND CTM_BELONG = '" & SelShop & "'"
			strSql = strSql & " ORDER BY CTM_CD "
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then nextcd = GetString(.fields("CTM_CD"))
			.close
		else
			nextcd = mincd
		end if
	end with
	set myRec = nothing
	CloseDB myCon
		
	if precd = "" then precd = mincd
	if nextcd = "" then nextcd = maxcd
		
	buf = buf & "&nbsp;<img src=img/First.jpg alt=�ŏ��� style=""cursor:hand"" onmousedown=""DoMove('" & mincd & "')"">"
	buf = buf & "&nbsp;<img src=img/Prev.jpg alt=�O�� style=""cursor:hand"" onmousedown=""DoMove('" & precd & "')"">"
	buf = buf & "&nbsp;<img src=img/Next.jpg alt=���� style=""cursor:hand"" onmousedown=""DoMove('" & nextcd & "')"">"
	buf = buf & "&nbsp;<img src=img/Last.jpg alt=�Ō�� style=""cursor:hand"" onmousedown=""DoMove('" & maxcd & "')"">"
	ShowBar = buf
end function
%>