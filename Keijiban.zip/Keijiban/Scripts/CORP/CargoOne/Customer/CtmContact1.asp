<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
	CTM_CD = GetPost(request("CTM_CD"))
	if CTM_CD <> "" then 
	
		OpenSql Conn, SqlServerName, DataBaseName	
			
		strSql = "UPDATE CTM_CONTACT SET CONTACT_PAST = 1 WHERE CONTACT_PAST = 0 AND CTM_CD = '" & CTM_CD & "'"
		Conn.Execute strSql
		
		set Recset = Server.CreateObject("adodb.recordset")					
		with Recset
			strSql = "SELECT * FROM CTM_CONTACT"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			.AddNew
			.fields("CTM_CD") = CTM_CD
			.fields("CONTACT_PAST") = 0
			.fields("CONTACT_DATE") = now
			.fields("CTM_SALES_CLOSE") = GetLong(request("CTM_SALES_CLOSE"))
			.fields("CTM_SALES_CREDIT") = GetLong(request("CTM_SALES_CREDIT"))
			.fields("CTM_SALES_PAYDAY") = GetLong(request("CTM_SALES_PAYDAY"))
			.fields("CTM_SALES_PAYMENT") = GetPost(request("CTM_SALES_PAYMENT"))
			.fields("CTM_SALES_SIGHT") = GetLong(request("CTM_SALES_SIGHT"))
			.fields("CTM_SALES_LIMIT") = GetLong(request("CTM_SALES_LIMIT"))
			.fields("CTM_STAND_CLOSE") = GetLong(request("CTM_STAND_CLOSE"))
			.fields("CTM_STAND_CREDIT") = GetLong(request("CTM_STAND_CREDIT"))
			.fields("CTM_STAND_PAYDAY") = GetLong(request("CTM_STAND_PAYDAY"))
			.fields("CTM_STAND_PAYMENT") = GetString(request("CTM_STAND_PAYMENT"))
			.fields("CTM_STAND_SIGHT") = GetLong(request("CTM_STAND_SIGHT"))
			.fields("CTM_STAND_LIMIT") = GetLong(request("CTM_STAND_LIMIT"))
			.fields("CTM_COSTS_CLOSE") = GetLong(request("CTM_COSTS_CLOSE"))
			.fields("CTM_COSTS_CREDIT") = GetLong(request("CTM_COSTS_CREDIT"))
			.fields("CTM_COSTS_PAYDAY") = GetLong(request("CTM_COSTS_PAYDAY"))
			.fields("CTM_COSTS_PAYMENT") = GetPost(request("CTM_COSTS_PAYMENT"))
			.fields("CTM_COSTS_SIGHT") = GetLong(request("CTM_COSTS_SIGHT"))
			.fields("CTM_COSTS_LIMIT") = GetLong(request("CTM_COSTS_LIMIT"))
			.fields("CONTACT_REMARKS") = GetPost(request("CONTACT_REMARKS"))
			.update
			.close
		end with		
		set Recset = nothing
		CloseDB Conn
		
'LOCAL�̑q��MDB�ƘA������
		OpenMDB Conn		
		StrSql = "UPDATE CHT_NIN SET "
		StrSql = StrSql & " NIN_CUT1 = " & GetLong(request("CTM_SALES_CLOSE"))
		StrSql = StrSql & ",NIN_CUT2 = " & GetLong(request("CTM_STAND_CLOSE"))
		StrSql = StrSql & ",[NIN_���u1] = " & GetLong(request("CTM_SALES_CREDIT"))
		StrSql = StrSql & ",[NIN_���u2] = " & GetLong(request("CTM_STAND_CREDIT"))
		StrSql = StrSql & ",[NIN_�W��1] = " & GetLong(request("CTM_SALES_PAYDAY"))
		StrSql = StrSql & ",[NIN_�W��2] = " & GetLong(request("CTM_STAND_PAYDAY"))
		StrSql = StrSql & " WHERE NIN_CODE = '" & CTM_CD & "'"
response.write StrSql
		Conn.Execute StrSql
		CloseDB Conn
	end if
%>
<html>
<script language=javascript>
	window.opener.location.href = "customer.asp?CTM_CD=<%=CTM_CD%>";
	window.close();
</script>
</html>