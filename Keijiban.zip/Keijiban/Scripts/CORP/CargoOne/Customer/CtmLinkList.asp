<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	
	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 

%>
<HTML>
<HEAD>
	<TITLE>�֘A��Јꗗ</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<SCRIPT language=javaScript>
		function ShowDetail(myType, myCD) {
			var win = window.open("CtmLinkDetail.asp?CTM_CD=<%=CTM_CD%>&TYPE="+myType+"&LINK_ID="+myCD,"CtmBank","scrollbars=no,width=600,height=320");
			win.focus();
		}		
	</SCRIPT>
</HEAD>
<BODY topmargin=0 <%=gsBodyControl%>>
	<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���֘A���<td width=50% align=right>
	  	<img style="cursor:hand" src=img/new.gif alt="�V�K�ǉ�" onmousedown="ShowDetail('','');">
	</table>
	<hr size=1>
<%
	with recset
		strSql = "SELECT LINK_ID, LINK_CD, LINK_TYPE, LINK_REF, LINK_NAME, LINK_INFO1, LINK_INFO2, LINK_INFO3, LINK_INFO4,"
		strSql = strSql & " LINK_DFT FROM CTM_LINK WHERE LINK_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
		strSql = strSql & " ORDER BY LINK_TYPE, LINK_DFT DESC, LINK_CD, LINK_ID"
		recset.Open strSql,conn,adOpenStatic,adLockReadOnly 
		if not .EOF then
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20>
		<TD class=line nowrap>����
		<TD class=line nowrap>�敪
		<TD class=line nowrap>����
		<TD class=line nowrap>�Z��
		<TD class=line nowrap>TelFax
		<TD class=line nowrap>�S����
<%
			do while not .eof				
				LinkType = GetLong(.Fields("LINK_TYPE"))
				LinkAddr = GetString(.Fields("LINK_INFO1")) & " " & GetString(.Fields("LINK_INFO2"))
				LinkTel = GetString(.Fields("LINK_INFO3"))
				LinkPic = GetString(.Fields("LINK_INFO4"))
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="ShowDetail('<%=.Fields("LINK_TYPE")%>','<%=.Fields("LINK_ID")%>');">
					<TD class=line nowrap><%=GetString(.Fields("LINK_CD"))%><BR>
					<TD class=line nowrap align=center title="<%=ctmLink(LinkType)%>"><%=LinkType%><BR>
					<TD class=line nowrap><%=GetString(.Fields("LINK_REF"))%><BR>
					<TD class=line nowrap <%=ShowTitle(LinkAddr, 30)%>><%=StringCut(LinkAddr,30)%><BR>
					<TD class=line nowrap <%=ShowTitle(LinkTel, 30)%>><%=StringCut(LinkTel,30)%><BR>
					<TD class=line nowrap <%=ShowTitle(LinkPic, 10)%>><%=StringCut(LinkPic,10)%><BR>
<%
				.movenext
			loop
%>
	</TABLE>
<%
		end if
	end with
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn
%>
