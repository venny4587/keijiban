<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	LINK_ID = GetLong(request("LINK_ID"))
	if CTM_CD <> "" then
		mode = 0
		if LINK_ID <> 0 then
			OpenSql Conn, SqlServerName, DataBaseName
			set Recset = Server.CreateObject("adodb.recordset") 
			with Recset 
				strSql = "SELECT * FROM CTM_LINK WHERE LINK_DELETED = 0 AND LINK_ID =" & LINK_ID
				.Open strSql,conn,adOpenStatic,adLockReadOnly 
				if not .eof then
					mode = 1
					LINK_CD = GetString(.fields("LINK_CD"))
					LINK_TYPE = GetLong(.fields("LINK_TYPE"))
					LINK_REF = GetString(.fields("LINK_REF"))
					LINK_NAME = GetString(.fields("LINK_NAME"))
					LINK_INFO1 = GetString(.fields("LINK_INFO1"))
					LINK_INFO2 = GetString(.fields("LINK_INFO2"))
					LINK_INFO3 = GetString(.fields("LINK_INFO3"))
					LINK_INFO4 = GetString(.fields("LINK_INFO4"))
					LINK_REMARKS = GetString(.fields("LINK_REMARKS"))
					LINK_DFT = GetLong(.fields("LINK_DFT"))
				end if
				.close
			end with
			set Recset = nothing
			CloseDB Conn
		end if
%>
<html>
<HEAD>
	<TITLE>�֘A��Џڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
			if checkText("LINK_CD","��к���",0) = false then exit sub
			if checkText("LINK_TYPE","��Ћ敪",1) = false then exit sub
			if checkText("LINK_REF","��������",1) = false then exit sub
			if checkText("LINK_NAME","��Ж���",1) = false then exit sub
			if checkText("LINK_INFO1","��ЏZ���P",0) = false then exit sub
			if checkText("LINK_INFO2","��ЏZ���Q",0) = false then exit sub
			if checkText("LINK_INFO3","���TEL�EFAX",0) = false then exit sub
			if checkText("LINK_INFO4","�S���ҁE�A����",0) = false then exit sub
			if checkText("LINK_REMARKS","���l", 0) = false then
				exit sub
			elseif checkLen("LINK_REMARKS","���l",255) = false then
				exit sub
			end if						
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DataDel()
			if msgbox ("�f�[�^���폜���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CtmLinkUpdate.asp" method="post">
  	<input type=hidden name="mode" value="<%=mode%>">
  	<input type=hidden name="CTM_CD" value="<%=CTM_CD%>">
  	<input type=hidden name="LINK_ID" value="<%=LINK_ID%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���֘A��Џ��&nbsp;
<%if LINK_ID <> 0 then %>
		  <img style="cursor:hand" src=img/waste.gif alt="�폜" onmousedown="DataDel()">
<%end if%>
	  	<td width=50% align=right>
		  <img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1><%=ShowCustomHead(CTM_CD)%>
	<br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9>
	  <TR height=22>
		<TD width=50>����</TD>
		<TD><input class=si name="LINK_CD" size=6 maxlength=10 value="<%=LINK_CD%>" onkeydown="ResetEnter()">
		<TD class=pt9n width=50>�֘A�敪</TD>
		<TD><SELECT name=LINK_TYPE onkeydown="ResetEnter()"><%
			for i = 1 to ubound(ctmLink)
				response.write "<option value=" & i
				if LINK_TYPE = i then response.write " selected" 
				response.write ">" & ctmLink(i)
			next%></SELECT</TD>
		<TD class=pt9n width=60>������</TD>
		<TD><input class=sj name="LINK_REF" size=16 maxlength=20 value="<%=LINK_REF%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD class=pt9n>��Ж�</TD>
		<TD colspan=5><input class=sj name="LINK_NAME" size=60 maxlength=100 value="<%=LINK_NAME%>" onkeydown="ResetEnter()">
	  <TR height=22>
		<TD>�Z���P</TD>
		<TD colspan=5><input class=sj name="LINK_INFO1" size=60 maxlength=100 value="<%=LINK_INFO1%>" onkeydown="ResetEnter()">�iB/L��P�s�ځj
	  <TR height=22>
		<TD>�Z���Q</TD>
		<TD colspan=5><input class=sj name="LINK_INFO2" size=60 maxlength=100 value="<%=LINK_INFO2%>" onkeydown="ResetEnter()">�iB/L��Q�s�ځj
	  <TR height=22>
		<TD>TelFax</TD>
		<TD colspan=5><input class=sj name="LINK_INFO3" size=60 maxlength=100 value="<%=LINK_INFO3%>" onkeydown="ResetEnter()">�iB/L��R�s�ځj
	  <TR height=22>
		<TD>�S����</TD>
		<TD colspan=5><input class=sj name="LINK_INFO4" size=60 maxlength=100 value="<%=LINK_INFO4%>" onkeydown="ResetEnter()">�iB/L��S�s�ځj
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=22>
		<TD>���l
		<TD colspan=4><textarea name="LINK_REMARKS" rows=3 style="width:360"><%=LINK_REMARKS%></textarea>
		<TD>
<%if gsSaveButton = 1 then %>
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DataSave()">
<%else%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
	end if
%>