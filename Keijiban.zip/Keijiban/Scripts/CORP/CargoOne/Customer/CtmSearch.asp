<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

TEL = GetPost(request("TEL"))
REF = GetPost(request("REF"))
CNM = GetPost(request("CNM"))
MNG = GetPost(request("MNG"))

myPage = GetLong(request("page"))
if myPage = 0 then myPage = 1

myCount = GetLong(request("cboCount"))
if myCount = 0 then myCount = 15

myMode = GetLong(request("mode"))
%>
<HTML>
<HEAD>
	<TITLE>�ڋq����</TITLE>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<SCRIPT language=javaScript>		
	function setCtmCd(myCD) {
	    window.parent.opener.location.href = "customer.asp?CTM_CD=" + myCD;
	    window.close();
	}
	
	function DoSearch() {
		frmInput.page.value = 1;
		frmInput.submit();
	}
	
	function DoPage(no) {
		frmInput.page.value = no;
		frmInput.submit();
	}
	
	function GoPage() {
		frmInput.page.value = selPage.selectedIndex + 1;
		frmInput.submit();
	}
			
	function DoClear() {
		window.location.href = "ctmSearch.asp";
	}
			
	function ResetEnter() {
		if (window.event.keyCode == 13) window.event.keyCode = 9
	}
	</SCRIPT>
</HEAD>
<BODY <%=gsBodyControl%>>
  <FORM name=frmInput action="ctmSearch.asp" method="post">
	<INPUT type=hidden name="mode" value="1">
	<INPUT type=hidden name="page" value="<%=myPage%>">
	<TABLE width=750 Cellspacing=0 CellPadding=0 class=pt9>
      <TR>
		<TD>������</TD>
		<TD><input class=si size=10 maxlength=10 name=REF value="<%=REF%>" onkeydown="ResetEnter()">
		<TD>�ڋq��</TD>
		<TD><input class=sj size=10 maxlength=20 name=CNM value="<%=CNM%>" onkeydown="ResetEnter()">
		<TD>Tel/Fax</TD>
		<TD><input class=si size=10 maxlength=10 name=TEL value="<%=TEL%>" onkeydown="ResetEnter()">
		<TD>�S����</TD>
		<TD><input class=sj size=10 maxlength=20 name=MNG value="<%=MNG%>" onkeydown="ResetEnter()">
		<TD>�\������</TD>
		<TD><select name=cboCount onkeydown="ResetEnter()">
			<option value="15" <%if myCount=15 then Response.Write "selected"%>>15
			<option value="30" <%if myCount=30 then Response.Write "selected"%>>30
			<option value="50" <%if myCount=50 then Response.Write "selected"%>>50
			</select>
		<TD colspan=2>
			<INPUT type=button name=btnSearch value="����" onclick="DoSearch()">
			<INPUT type=button name=btnClear value="�N���A" onclick="DoClear()">
	</TABLE>
  </FORM>
<%
	if myMode = 1 then
		OpenSql Conn, SqlServerName, DataBaseName
		set recset = Server.CreateObject("ADODB.RecordSet") 
		with recset
			strSql = "SELECT CTM_CD, CTM_REF, CTM_NAME, CTM_TEL, CTM_FAX, CTM_CREATER, PIC_NAME, PIC_TEL_IDX FROM CUSTOMER LEFT JOIN"
			strSql = strSql & " (SELECT CTM_CD AS CD, PIC_NAME, PIC_TEL_IDX FROM CTM_PIC WHERE PIC_DFT <> 0 AND PIC_DELETED = 0) AS P"
			strSql = strSql & " ON CUSTOMER.CTM_CD = P.CD WHERE CTM_DELETED = 0"	
			if REF <> "" then strSql = strSql & " AND (CTM_CD = '" & FitSel(REF) & "' OR CTM_REF LIKE '%" & FitSel(REF) & "%')"
			if CNM <> "" then strSql = strSql & " AND (CTM_NAME LIKE '%" & FitSel(CNM) & "%' OR CTM_ENAME LIKE '%" & FitSel(CNM) & "%')"
			if TEL <> "" then strSql = strSql & " AND (CTM_TEL_IDX LIKE '%" & FitSel(TEL) & "%' OR PIC_TEL_IDX LIKE '%" & FitSel(TEL) & "%')"
			if MNG <> "" then strSql = strSql & " AND PIC_NAME LIKE '%" & FitSel(MNG) & "%')"
			strSql = strSql & " ORDER BY CTM_REF"
'response.write strSql
			recset.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .EOF then
				recset.PageSize = myCount
				lngPageCount = recset.PageCount
				.AbsolutePage = myPage
				response.write "<TABLE width=750 class=pt9><TR><TD>"
				response.write "�y�[�W�F " & myPage & " / " & lngPageCount
				response.write "<TD align=right>"
				if myPage > 1 then response.write "<a class=bar href=""javascript:DoPage(" & myPage-1 & ")"">�O�߰��</A>�@"
				if myPage < lngPageCount then response.write "<a class=bar href=""javascript:DoPage(" & myPage+1 & ")"">���߰��</A>"				
				response.write "�@<select name=selPage>"
				for i = 1 to lngPageCount 
					if i = myPage then
						Response.Write "<option value=" & i & " selected>" & right("   " & i,4) & "</option>"
					else 
						Response.Write "<option value=" & i & ">" & right("   " & i,4) & "</option>"
					end if
				next
				response.write "</select>&nbsp;<input type=button value=GO onclick=""GoPage()""></TABLE>"
%>
	<TABLE width=750 Cellspacing=3 CellPadding=3 class=pt9n>
	  <TR height=20>
		<TD class=line width=50>�R�[�h
		<TD class=line width=50>������
		<TD class=line width=250>�ڋq��
		<TD class=line width=200>Tel/Fax
		<TD class=line width=150>�S����
		<TD class=line width=50>�쐬��
<%
				do while not .eof
					if .AbsolutePage <> myPage then exit do
					
					CtmName = GetString(.Fields("CTM_NAME"))
					TelFax = GetString(.Fields("CTM_TEL")) & " " & GetString(.Fields("CTM_FAX"))
					PicName = GetString(.Fields("PIC_NAME"))
					
%>
				<TR height=20 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';" onclick="setCtmCd('<%=.Fields("CTM_CD")%>');">
					<TD class=line nowrap><%=GetString(.Fields("CTM_CD"))%><BR>
					<TD class=line nowrap><%=GetString(.Fields("CTM_REF"))%><BR>
					<TD class=line nowrap <%=ShowTitle(CtmName, 20)%>><%=StringCut(CtmName,20)%><BR></TD>
					<TD class=line nowrap <%=ShowTitle(TelFax, 30)%>><%=StringCut(TelFax,30)%><BR></TD>
					<TD class=line nowrap <%=ShowTitle(PicName, 12)%>><%=StringCut(PicName,12)%><BR></TD>
					<TD class=line nowrap><%=GetEmployName(.Fields("CTM_CREATER"), "F")%><BR></TD>
<%
					.movenext
				loop
%>
	</TABLE>
<%
			else
				response.write "<p><br><center>�Y���f�[�^��������܂���ł����B</center>"
			end if
		end with
	end if
%>  
</BODY>
</HTML>

<% 
set recset = nothing
CloseDB Conn

function GetLeft(myStr)
	buf = myStr
	idx = instr(buf, ".")
	if idx > 0 then
		buf = left(buf, idx-1)
	end if
	GetLeft = buf
end function

function GetRight(myStr)
	buf = myStr
	idx = instr(buf, ".")
	if idx > 0 then
		buf = right(buf, len(buf) - idx)
	end if
	GetRight = buf
end function

function SetNumber(myNo)
	SetNumber = right("00" & cstr(myNo) , 2)
end function
%>
