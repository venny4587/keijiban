<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim CTM_CD
	CTM_CD = GetPost(request("CTM_CD"))
	CTM_REF = GetPost(request("CTM_REF"))
	CTM_ABR = GetPost(request("CTM_ABR"))

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset")

	'�d���`�F�b�N
	if GetLong(trim(request("noRepChk"))) <> 1 then
		dim strMsg
		strMsg = ""
		strCD = CheckDouble("CTM_REF", CTM_REF)
		if strCD <> "" then
			strMsg = strMsg & "�������́F " & CTM_REF & "(" & strCD & ")" & chr(34) & " & vbCrlf & " & chr(34) 
		end if
		strCD = CheckDouble("CTM_ABR", CTM_ABR)
		if strCD <> "" then
			strMsg = strMsg & "���{���́F " & CTM_ABR & "(" & strCD & ")" & chr(34) & " & vbCrlf & " & chr(34)
		end if
		if strMsg <> "" then
			strMsg = "�Y���ڋq�́A���L�̏d�����ڂ�����܂��B" & chr(34) & " & vbCrlf & " & chr(34) & strMsg & chr(34) & " & vbCrlf & " & chr(34) & "����ł�낵���ł����H"
%>

<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<SCRIPT LANGUAGE=vbscript>
	<!-- 
		<!-- 
		Sub showConMsg()
			if msgbox ("<%=strMsg%>",289,"�m�F���b�Z�[�W") = 1 then
				frmInput.submit()
			else
				top.history.back
			end if
		End Sub
	 -->
	 -->
	</script>
</head>	
<body onload="showConMsg()"  <%=gsBodyControl%>>
<form name=frmInput action="CtmUpdate.asp" method=post>
<input type=hidden name=noRepChk value=1>
<input type=hidden name=CTM_CD value="<%=GetPost(request("CTM_CD"))%>">
<input type=hidden name=CTM_REF value="<%=GetPost(request("CTM_REF"))%>">
<input type=hidden name=CTM_ENAME value="<%=GetPost(request("CTM_ENAME"))%>">
<input type=hidden name=CTM_NAME value="<%=GetPost(request("CTM_NAME"))%>">
<input type=hidden name=CTM_ABR value="<%=GetPost(request("CTM_ABR"))%>">
<input type=hidden name=CTM_TYPE value="<%=GetLong(request("CTM_TYPE"))%>">
<input type=hidden name=CTM_BELONG value="<%=GetPost(request("CTM_BELONG"))%>">
<input type=hidden name=CTM_INTRODUCER value="<%=GetPost(request("CTM_INTRODUCER"))%>">
<input type=hidden name=CTM_SALESMNGR value="<%=GetLong(request("CTM_SALESMNGR"))%>">
<input type=hidden name=CTM_IMPORT_MNGR value="<%=GetLong(request("CTM_IMPORT_MNGR"))%>">
<input type=hidden name=CTM_EXPORT_MNGR value="<%=GetLong(request("CTM_EXPORT_MNGR"))%>">
<input type=hidden name=CTM_FINANCE_CD value="<%=GetPost(request("CTM_FINANCE_CD"))%>">
<input type=hidden name=CTM_NACCS_CD value="<%=GetPost(request("CTM_NACCS_CD"))%>">
<input type=hidden name=CTM_ZIP value="<%=GetPost(request("CTM_ZIP"))%>">
<input type=hidden name=CTM_ADDR1 value="<%=GetPost(request("CTM_ADDR1"))%>">
<input type=hidden name=CTM_ADDR2 value="<%=GetPost(request("CTM_ADDR2"))%>">
<input type=hidden name=CTM_CITY value="<%=GetPost(request("CTM_CITY"))%>">
<input type=hidden name=CTM_PROVINCE value="<%=GetPost(request("CTM_PROVINCE"))%>">
<input type=hidden name=CTM_COUNTRY value="<%=GetPost(request("CTM_COUNTRY"))%>">
<input type=hidden name=CTM_CHAIRMAN value="<%=GetPost(request("CTM_CHAIRMAN"))%>">
<input type=hidden name=CTM_TEL value="<%=GetPost(request("CTM_TEL"))%>">
<input type=hidden name=CTM_FAX value="<%=GetPost(request("CTM_FAX"))%>">
<input type=hidden name=CTM_URL value="<%=GetPost(request("CTM_URL"))%>">
<input type=hidden name=CTM_CLIENT value="<%=GetLong(request("CTM_CLIENT"))%>">
<input type=hidden name=CTM_BROKER value="<%=GetLong(request("CTM_BROKER"))%>">
<input type=hidden name=CTM_SHIPPER value="<%=GetLong(request("CTM_SHIPPER"))%>">
<input type=hidden name=CTM_CONSIGNEE value="<%=GetLong(request("CTM_CONSIGNEE"))%>">
<input type=hidden name=CTM_NOTIFY value="<%=GetLong(request("CTM_NOTIFY"))%>">
<input type=hidden name=CTM_CUSTOM value="<%=GetLong(request("CTM_CUSTOM"))%>">
<input type=hidden name=CTM_CARRIER value="<%=GetLong(request("CTM_CARRIER"))%>">
<input type=hidden name=CTM_AIRLINER value="<%=GetLong(request("CTM_AIRLINER"))%>">
<input type=hidden name=CTM_TRUCKER value="<%=GetLong(request("CTM_TRUCKER"))%>">
<input type=hidden name=CTM_WAREHOUSE value="<%=GetLong(request("CTM_WAREHOUSE"))%>">
<input type=hidden name=CTM_AGENT value="<%=GetLong(request("CTM_AGENT"))%>">
<input type=hidden name=CTM_OTHER value="<%=GetLong(request("CTM_OTHER"))%>">
<input type=hidden name=CTM_PARENT_CD value="<%=GetPost(request("CTM_PARENT_CD"))%>">
<input type=hidden name=CTM_BRANCH value="<%=GetPost(request("CTM_BRANCH"))%>">
<input type=hidden name=CTM_DEPART value="<%=GetPost(request("CTM_DEPART"))%>">
<input type=hidden name=CTM_ETC_CODE value="<%=GetPost(request("CTM_ETC_CODE"))%>">
<input type=hidden name=CTM_ETC_DATA value="<%=GetPost(request("CTM_ETC_DATA"))%>">
<input type=hidden name=CTM_NATURE_MAIN value="<%=GetPost(request("CTM_NATURE_MAIN"))%>">
<input type=hidden name=CTM_NATURE_SUB value="<%=GetPost(request("CTM_NATURE_SUB"))%>">
<input type=hidden name=CTM_CAPITAL value="<%=GetPost(request("CTM_CAPITAL"))%>">
<input type=hidden name=CTM_REMARKS value="<%=GetPost(request("CTM_REMARKS"))%>">
<input type=hidden name=CTM_BLACK value="<%=GetLong(request("CTM_BLACK"))%>">
<input type=hidden name=CTM_SLEEP value="<%=GetLong(request("CTM_SLEEP"))%>">
</form>
</body>
</html>
<%
			Response.End 
		end if
	end if
	
	if CTM_CD = "" then	
		Set cmdSQL = Server.CreateObject("ADODB.Command")
		Set cmdSQL.ActiveConnection = Conn
		cmdSQL.CommandType = 4
		cmdSQL.CommandText = "DB_NEW_KEY"
		cmdSQL.Parameters.Refresh
		cmdSQL.Parameters("@SysKey").Value = "CTM_CD"	
		cmdSQL.Execute
		CTM_CD = gsInitial & right("00000" & GetLong(cmdSQL.Parameters("@MaxID").Value),6)
	end if
	
	Conn.BeginTrans
	
	with Recset
		StrSql = "SELECT * FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_CD = '" & CTM_CD & "'"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		if .eof then
			.addnew
			.fields("CTM_CD") = CTM_CD
			.fields("CTM_CREATER") = WebUserID
			.fields("CTM_CREATED") = now
			.fields("CTM_DELETED") = 0
		end if
		.fields("CTM_REF") = GetPost(Request("CTM_REF"))
		.fields("CTM_ENAME") = GetPost(Request("CTM_ENAME"))
		.fields("CTM_NAME") = GetPost(Request("CTM_NAME"))
		.fields("CTM_ABR") = GetPost(Request("CTM_ABR"))
		.fields("CTM_TYPE") = GetLong(Request("CTM_TYPE"))
		.fields("CTM_BELONG") = GetPost(Request("CTM_BELONG"))
		.fields("CTM_INTRODUCER") = GetPost(Request("CTM_INTRODUCER"))
		.fields("CTM_SALESMNGR") = GetLong(Request("CTM_SALESMNGR"))
		.fields("CTM_IMPORT_MNGR") = GetLong(Request("CTM_IMPORT_MNGR"))
		.fields("CTM_EXPORT_MNGR") = GetLong(Request("CTM_EXPORT_MNGR"))
		if GetPost(Request("CTM_FINANCE_CD")) = "" then
			.fields("CTM_FINANCE_CD") = CTM_CD
		else
			.fields("CTM_FINANCE_CD") = GetPost(Request("CTM_FINANCE_CD"))
		end if
		.fields("CTM_NACCS_CD") = GetPost(Request("CTM_NACCS_CD"))
		.fields("CTM_ZIP") = GetPost(Request("CTM_ZIP"))
		.fields("CTM_ADDR1") = GetPost(Request("CTM_ADDR1"))
		.fields("CTM_ADDR2") = GetPost(Request("CTM_ADDR2"))
		.fields("CTM_CITY") = GetPost(Request("CTM_CITY"))
		.fields("CTM_PROVINCE") = GetPost(Request("CTM_PROVINCE"))
		.fields("CTM_COUNTRY") = GetPost(Request("CTM_COUNTRY"))
		.fields("CTM_CHAIRMAN") = GetPost(Request("CTM_CHAIRMAN"))
		.fields("CTM_TEL") = GetPost(Request("CTM_TEL"))
		.fields("CTM_FAX") = GetPost(Request("CTM_FAX"))
		.fields("CTM_TEL_IDX") = GetTelFaxIndex(GetString(Request("CTM_TEL")) & "/" & GetString(Request("CTM_FAX")))		
		.fields("CTM_URL") = GetPost(Request("CTM_URL"))
		.fields("CTM_CLIENT") = GetLong(Request("CTM_CLIENT"))
		.fields("CTM_BROKER") = GetLong(Request("CTM_BROKER"))
		.fields("CTM_SHIPPER") = GetLong(Request("CTM_SHIPPER"))
		.fields("CTM_CONSIGNEE") = GetLong(Request("CTM_CONSIGNEE"))
		.fields("CTM_NOTIFY") = GetLong(Request("CTM_NOTIFY"))
		.fields("CTM_CUSTOM") = GetLong(Request("CTM_CUSTOM"))
		.fields("CTM_CARRIER") = GetLong(Request("CTM_CARRIER"))
		.fields("CTM_AIRLINER") = GetLong(Request("CTM_AIRLINER"))
		.fields("CTM_TRUCKER") = GetLong(Request("CTM_TRUCKER"))
		.fields("CTM_WAREHOUSE") = GetLong(Request("CTM_WAREHOUSE"))
		.fields("CTM_AGENT") = GetLong(Request("CTM_AGENT"))
		.fields("CTM_OTHER") = GetLong(Request("CTM_OTHER"))
		.fields("CTM_PARENT_CD") = GetPost(Request("CTM_PARENT_CD"))
		.fields("CTM_BRANCH") = GetPost(Request("CTM_BRANCH"))
		.fields("CTM_DEPART") = GetPost(Request("CTM_DEPART"))
		.fields("CTM_ETC_CODE") = GetPost(Request("CTM_ETC_CODE"))
		.fields("CTM_ETC_DATA") = GetPost(Request("CTM_ETC_DATA"))
		.fields("CTM_NATURE_MAIN") = GetPost(Request("CTM_NATURE_MAIN"))
		.fields("CTM_NATURE_SUB") = GetPost(Request("CTM_NATURE_SUB"))
		.fields("CTM_CAPITAL") = GetPost(Request("CTM_CAPITAL"))
		.fields("CTM_REMARKS") = GetPost(Request("CTM_REMARKS"))
		.fields("CTM_BLACK") = GetLong(Request("CTM_BLACK"))
		.fields("CTM_SLEEP") = GetLong(Request("CTM_SLEEP"))	
		
		.fields("CTM_UPDATER") = WebUserID
		.fields("CTM_UPDATED") = now
		.update
		.close
	end with
	set Recset = nothing
	
	if err.number = 0 then 
		Conn.CommitTrans
		strMsg = strMsg & "<p>" & "�X�V�������I�����܂����B" & "</p>"
	else
		Conn.RollbackTrans
		strMsg = strMsg & "<p>" & "�G���[���������܂����B" & "</p>"
		strMsg = strMsg & "<p>" & err.number & "<br>" & err.description & "</p>"
	end if
	CloseDB Conn
	
'LOCAL�̑q��MDB�ƘA������
'NIN_BLN1
'NIN_BLN2
'NIN_BLN3
'NIN_BLN4
'NIN_TOYO1
'NIN_TOYO2
if GetLong(Request("CTM_CLIENT")) <> 0 then
	OpenMDB Conn
	set Recset = Server.CreateObject("adodb.recordset")
	
	with Recset
		StrSql = "SELECT * FROM CHT_NIN WHERE NIN_CODE = '" & CTM_CD & "'"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		if .eof then
			.addnew
			.fields("NIN_CODE") = CTM_CD
			.fields("NIN_CDNO") = SetStr(Request("CTM_FINANCE_CD"))
		end if
		.fields("NIN_BLCD") = SetStr(Request("CTM_NACCS_CD"))		
		.fields("NIN_BLN1") = SetStr(Request("CTM_ENAME"))
		.fields("NIN_KNAM") = SetStr(Request("CTM_REF"))
		.fields("NIN_RNAM") = SetStr(Request("CTM_ABR"))
		if SetStr(Request("CTM_FINANCE_CD")) = "690" then
			.fields("NIN_NAME") = "�L�c�ʏ��������"
			.fields("NIN_BUKA") = SetStr(Request("CTM_NAME"))
		else
			.fields("NIN_NAME") = SetStr(Request("CTM_NAME"))
			.fields("NIN_BUKA") = SetStr(Request("CTM_DEPART"))
		end if
		.fields("NIN_DIV1") = GetLong(Request("CTM_TYPE"))
		select case GetPost(Request("CTM_BELONG"))
		case "K":	.fields("NIN_DIV2") = 0
		case "O":	.fields("NIN_DIV2") = 1
		case "T":	.fields("NIN_DIV2") = 2
		case "M":	.fields("NIN_DIV2") = 3
		end select
		.fields("NIN_JIPNO") = SetStr(Request("CTM_ZIP"))
		.fields("NIN_ADD1") = SetStr(Request("CTM_ADDR1"))
		.fields("NIN_ADD2") = SetStr(Request("CTM_ADDR2"))
		.fields("NIN_TELNO") = SetStr(Request("CTM_TEL"))
		.fields("NIN_FAXNO") = SetStr(Request("CTM_FAX"))
		.fields("NIN_TANTO") = SetStr(Request("CTM_CHAIRMAN"))
		.fields("NIN_BIKO") = SetStr(Request("CTM_REMARKS"))
		.update
		.close
	end with
	set Recset = nothing
	CloseDB Conn
end if

function SetStr(myStr)
	SetStr = GetString(myStr)
	if SetStr = "" then SetStr = null
end function
%>

<html>
<head>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">	
	<SCRIPT LANGUAGE=vbscript>
	<!-- 
		Sub btnback_Onclick()
<%	if err.number = 0 then %>
			location.href = "customer.asp?CTM_CD=<%=CTM_CD%>" 
<%	else %>
			top.history.back
<%	end if %>
		End Sub
	//-->
	</script>
</head>	
<body <%=gsBodyControl%>>
<table width=100%>
<tr><td>
	<table>
		<TR><TD width=10 rowspan=5></TD><BR><TD></TD></TR>
		<TR><TD><%=strMsg%></TD></TR>
		<TR><TD><BR></TD></TR>
		<TR><TD><input type='button' value='�߂�' name='btnback' style="width:100;height:30"></TD></TR>
	</table>	
</td></tr>
</table>
</body>
</html>
<%
function CheckDouble(myFld, myVal)
on error resume next
dim mySql
dim myRec	
	CheckDouble = ""
	if myFld = "" or myVal = "" then exit function
	
	set myRec = server.createobject("adodb.recordset")		
	mySql = "SELECT CTM_CD FROM CUSTOMER WHERE CTM_CD <> '" & CTM_CD & "' AND " & myFld & " = '" & myVal & "'"
	myRec.Open mySql, Conn, adOpenStatic, adLockReadOnly 	
	if not myRec.EOF then CheckDouble = GetString(myRec.Fields("CTM_CD"))		
	myRec.Close
	set myRec = nothing	
end function
%>
