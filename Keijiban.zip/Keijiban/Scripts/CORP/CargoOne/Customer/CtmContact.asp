<!-- #include file="../common/Common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	CTM_CD = GetPost(request("CTM_CD"))
	if CTM_CD <> "" then
		mode = 1
		OpenSql Conn, SqlServerName, DataBaseName
		set Recset = Server.CreateObject("adodb.recordset") 
		with Recset 			
			strSql = "SELECT * FROM CTM_CONTACT WHERE CTM_CD = '" & CTM_CD & "' ORDER BY CONTACT_DATE DESC"
			.Open strSql,conn,adOpenStatic,adLockReadOnly 
			if not .eof then
				mode = 2
				CTM_SALES_CLOSE = GetLong(.fields("CTM_SALES_CLOSE"))
				CTM_SALES_CREDIT = GetLong(.fields("CTM_SALES_CREDIT"))
				CTM_SALES_PAYDAY = GetLong(.fields("CTM_SALES_PAYDAY"))
				CTM_SALES_PAYMENT = GetString(.fields("CTM_SALES_PAYMENT"))
				CTM_SALES_SIGHT = GetLong(.fields("CTM_SALES_SIGHT"))
				CTM_SALES_LIMIT = GetLong(.fields("CTM_SALES_LIMIT"))
				CTM_STAND_CLOSE = GetLong(.fields("CTM_STAND_CLOSE"))
				CTM_STAND_CREDIT = GetLong(.fields("CTM_STAND_CREDIT"))
				CTM_STAND_PAYDAY = GetLong(.fields("CTM_STAND_PAYDAY"))
				CTM_STAND_PAYMENT = GetString(.fields("CTM_STAND_PAYMENT"))
				CTM_STAND_SIGHT = GetLong(.fields("CTM_STAND_SIGHT"))
				CTM_STAND_LIMIT = GetLong(.fields("CTM_STAND_LIMIT"))
				CTM_COSTS_CLOSE = GetLong(.fields("CTM_COSTS_CLOSE"))
				CTM_COSTS_CREDIT = GetLong(.fields("CTM_COSTS_CREDIT"))
				CTM_COSTS_PAYDAY = GetLong(.fields("CTM_COSTS_PAYDAY"))
				CTM_COSTS_PAYMENT = GetString(.fields("CTM_COSTS_PAYMENT"))
				CTM_COSTS_SIGHT = GetLong(.fields("CTM_COSTS_SIGHT"))
				CTM_COSTS_LIMIT = GetLong(.fields("CTM_COSTS_LIMIT"))
				CONTACT_REMARKS = GetString(.fields("CONTACT_REMARKS"))
			end if
			.close
		end with
		set Recset = nothing
		CloseDB Conn
		
		if CTM_SALES_LIMIT = "" then CTM_SALES_LIMIT = 0
		if CTM_STAND_LIMIT = "" then CTM_STAND_LIMIT = 100
		if CTM_COSTS_LIMIT = "" then CTM_COSTS_LIMIT = 0
%>
<html>
<HEAD>
	<TITLE>�ڋq�o�^</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<link rel="stylesheet" href="../common/css/style.css" type="text/css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
			if checkText("CTM_SALES_PAYMENT","�����x�����@",0) = false then exit sub
			if checkNum("CTM_SALES_SIGHT","�����T�C�g",0) = false then exit sub
			if checkNum("CTM_SALES_LIMIT","�����z�x����",1) = false then exit sub
			if checkText("CTM_STAND_PAYMENT","���֎x�����@",0) = false then exit sub
			if checkNum("CTM_STAND_SIGHT","���փT�C�g",0) = false then exit sub
			if checkNum("CTM_STAND_LIMIT","���֊z�x����",1) = false then exit sub
			if checkText("CTM_COSTS_PAYMENT","�O���x�����@",0) = false then exit sub
			if checkNum("CTM_COSTS_SIGHT","�O���T�C�g",0) = false then exit sub
			if checkNum("CTM_COSTS_LIMIT","�O���z�x����",1) = false then exit sub
			if checkText("CONTACT_REMARKS","���l", 0) = false then
				exit sub
			elseif checkLen("CONTACT_REMARKS","���l",255) = false then
				exit sub
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.submit()
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="CtmContact1.asp" method="post">
  	<input type=hidden name="CTM_CD" value="<%=CTM_CD%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=50%>���_����<td width=50% align=right>
	  	<img style="cursor:hand" src=img/save.gif alt="�ۑ�" onmousedown="DataSave()">
	</table>
	<hr width=96% size=1><%=ShowCustomHead(CTM_CD)%>
	<br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR height=25>
		<TD class=line>�敪
		<TD class=line>����
		<TD class=line>�x��
		<TD class=line>�x����
		<TD class=line>�x�����@
		<TD class=line>�T�C�g
		<TD class=line align=center>����
	  <TR height=30>
	  	<TD><font color=blue>����</font>
	  	<TD><SELECT name=CTM_SALES_CLOSE onkeydown="ResetEnter()"><%=ShowCloseList(CTM_SALES_CLOSE)%></SELECT>
	  	<TD><SELECT name=CTM_SALES_CREDIT onkeydown="ResetEnter()"><%=ShowCreditList(CTM_SALES_CREDIT)%></SELECT>
	  	<TD><SELECT name=CTM_SALES_PAYDAY onkeydown="ResetEnter()"><%=ShowPayDayList(CTM_SALES_PAYDAY)%></SELECT>
		<TD><input class=sj name="CTM_SALES_PAYMENT" size=15 maxlength=8 value="<%=CTM_SALES_PAYMENT%>" onkeydown="ResetEnter()">
		<TD><input class=sn name="CTM_SALES_SIGHT" size=3 maxlength=5 value="<%=CTM_SALES_SIGHT%>" onkeydown="ResetEnter()">��
		<TD><input class=sn name="CTM_SALES_LIMIT" size=3 maxlength=5 value="<%=CTM_SALES_LIMIT%>" onkeydown="ResetEnter()">��
	  <TR height=30>
	  	<TD><font color=green>����</font>
	  	<TD><SELECT name=CTM_STAND_CLOSE onkeydown="ResetEnter()"><%=ShowCloseList(CTM_STAND_CLOSE)%></SELECT>
	  	<TD><SELECT name=CTM_STAND_CREDIT onkeydown="ResetEnter()"><%=ShowCreditList(CTM_STAND_CREDIT)%></SELECT>
	  	<TD><SELECT name=CTM_STAND_PAYDAY onkeydown="ResetEnter()"><%=ShowPayDayList(CTM_STAND_PAYDAY)%></SELECT>
		<TD><input class=sj name="CTM_STAND_PAYMENT" size=15 maxlength=8 value="<%=CTM_STAND_PAYMENT%>" onkeydown="ResetEnter()">
		<TD><input class=sn name="CTM_STAND_SIGHT" size=3 maxlength=5 value="<%=CTM_STAND_SIGHT%>" onkeydown="ResetEnter()">��
		<TD><input class=sn name="CTM_STAND_LIMIT" size=3 maxlength=5 value="<%=CTM_STAND_LIMIT%>" onkeydown="ResetEnter()">��
	  <TR height=30>
	  	<TD><font color=black>����</font>
	  	<TD><SELECT name=CTM_COSTS_CLOSE onkeydown="ResetEnter()"><%=ShowCloseList(CTM_COSTS_CLOSE)%></SELECT>
	  	<TD><SELECT name=CTM_COSTS_CREDIT onkeydown="ResetEnter()"><%=ShowCreditList(CTM_COSTS_CREDIT)%></SELECT>
	  	<TD><SELECT name=CTM_COSTS_PAYDAY onkeydown="ResetEnter()"><%=ShowPayDayList(CTM_COSTS_PAYDAY)%></SELECT>
		<TD><input class=sj name="CTM_COSTS_PAYMENT" size=15 maxlength=8 value="<%=CTM_COSTS_PAYMENT%>" onkeydown="ResetEnter()">
		<TD><input class=sn name="CTM_COSTS_SIGHT" size=3 maxlength=5 value="<%=CTM_COSTS_SIGHT%>" onkeydown="ResetEnter()">��
		<TD><input class=sn name="CTM_COSTS_LIMIT" size=3 maxlength=5 value="<%=CTM_COSTS_LIMIT%>" onkeydown="ResetEnter()">��
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR>
		<TD class=pt9>���l
		<TD colspan=4><textarea name="CONTACT_REMARKS" rows=3 style="width:360"><%=CONTACT_REMARKS%></textarea>
		<TD colspan=2>
<%if gsSaveButton = 1 then%>
	<%if ConfirmerID = 0 then%>	
			<input type=button style="width:90;height:30" value="F9:�ۑ�" onclick="DataSave()">
	<%end if%>
<%else%>
			<input type=button style="width:90;height:30" value="����" onclick="window.close()">
<%end if%>
	</TABLE>
  </FORM>
<center>
</body></html>
<%
	end if
%>