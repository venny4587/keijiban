<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim UNIT_ID
	
	blnDelete = True
	UNIT_ID = GetLong(request("UNIT_ID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT UNIT_CD FROM MST_UNIT WHERE UNIT_ID = " & UNIT_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y�����ڂɂ͊��Ɏg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_UNIT SET UNIT_DELETED = 1"
		strSQL = strSQL & ",UNIT_UPDATED = GETDATE()"
		strSQL = strSQL & ",UNIT_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE UNIT_ID = " & UNIT_ID
		Conn.Execute strSQL

		strURL = "mstUnit.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>