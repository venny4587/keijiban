<html>
<head>
	<title>Main Menu Bar</title>
	<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)			
		select case mySel 
		case 1
			url = "mstHoliday.asp"
		case 2  
			url = "mstMail.asp"
		end select
		window.parent.subinfo.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnHoliday value="�Փ��}�X�^" onclick="DoAct(1)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnMail value="�ʒm�}�X�^" onclick="DoAct(2)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnEtc1 value="�ۗ��}�X�^" onclick="DoAct(3)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnEtc2 value="�ۗ��}�X�^" onclick="DoAct(4)"></TD>
		    <TD width=140>
				<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnEtc3 value="�ۗ��}�X�^" onclick="DoAct(5)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnEtc4 value="�ۗ��}�X�^" onclick="DoAct(6)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnEtc5 value="�ۗ��}�X�^" onclick="DoAct(7)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
