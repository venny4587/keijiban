<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim EXCH_ID
	dim EXCH_CD
	dim EXCH_CUR
	dim EXCH_RATE
	dim START_DATE
	dim END_DATE
	dim EXCH_REMARKS
	
	EXCH_ID = GetLong(Request("EXCH_ID"))
	EXCH_CD = GetString(Request("EXCH_CD"))
	EXCH_CUR = GetString(Request("EXCH_CUR"))
	EXCH_RATE = GetDouble(Request("EXCH_RATE"))
	START_DATE = Date2Str(Request("START_DATE"))
	END_DATE = Date2Str(Request("END_DATE"))
	EXCH_REMARKS = GetPost(Request("EXCH_REMARKS"))
				
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			.Open "SELECT EXCH_CD FROM MST_EXCHANGE WHERE EXCH_ID <> " & EXCH_ID & " AND EXCH_CD = '" & EXCH_CD & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���בփR�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then
		With Recset
			.Open "SELECT EXCH_CD FROM MST_EXCHANGE WHERE EXCH_ID <> " & EXCH_ID & " AND EXCH_CUR = '" & EXCH_CUR & "' AND START_DATE <= '" & START_DATE & "' AND END_DATE >= '"  & START_DATE & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���ב֊J�n���͐ݒ�ς݂ł��B(�Y������בֺ���:" & .Fields("EXCH_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then	
		With Recset
			.Open "SELECT EXCH_CD FROM MST_EXCHANGE WHERE EXCH_ID <> " & EXCH_ID & " AND EXCH_CUR = '" & EXCH_CUR & "' AND START_DATE <= '" & END_DATE & "' AND END_DATE >= '"  & END_DATE & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���ב֏I�����͐ݒ�ς݂ł��B(�Y������בֺ���:" & .Fields("EXCH_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then	
		With Recset
			.Open "SELECT EXCH_CD FROM MST_EXCHANGE WHERE EXCH_ID <> " & EXCH_ID & " AND EXCH_CUR = '" & EXCH_CUR & "' AND START_DATE >= '" & START_DATE & "' AND END_DATE <= '"  & END_DATE & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���ב֊��Ԃ͐ݒ�ς݂ł��B(�Y������בֺ���:" & .Fields("EXCH_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then	
	
		if EXCH_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "EXCH_ID"	
			cmdSQL.Execute
			EXCH_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
		strSQL = "SELECT * FROM MST_EXCHANGE WHERE EXCH_ID = " & EXCH_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("EXCH_ID") = EXCH_ID
				.fields("EXCH_CREATER") = WebUserID
				.fields("EXCH_CREATED") = now
				.fields("EXCH_DELETED") = 0
			End If
			.Fields("EXCH_CD") = EXCH_CD
			.Fields("EXCH_CUR") = EXCH_CUR
			.Fields("EXCH_RATE") = EXCH_RATE
			.Fields("START_DATE") = START_DATE
			.Fields("END_DATE") = END_DATE
			.Fields("EXCH_REMARKS") = EXCH_REMARKS	
		
			.fields("EXCH_UPDATER") = WebUserID
			.fields("EXCH_UPDATED") = now
			.Update 
			.Close 
		End With
		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstExchange.asp?p=" & GetCurrentPage(Conn, "MST_EXCHANGE", "EXCH_CD", 1, EXCH_CD, " AND EXCH_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstExchange.asp?p=" & GetCurrentPage(Conn, "MST_EXCHANGE", "EXCH_CUR", 1, EXCH_CUR, " AND EXCH_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstExchange.asp?p=" & GetCurrentPage(Conn, "MST_EXCHANGE", "START_DATE", 1, START_DATE, " AND EXCH_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.Redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
