<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim BANK_ID
	
	blnDelete = True
	BANK_ID = GetLong(Request("BANK_ID"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT BANK_ID FROM MST_BANK WHERE BANK_DELETED = 0 AND BANK_ID = " & BANK_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y����s�����͊��Ɏg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_BANK SET BANK_DELETED = 1"
		strSQL = strSQL & ",BANK_UPDATED = GETDATE()"
		strSQL = strSQL & ",BANK_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE BANK_ID = " & BANK_ID
		Conn.Execute strSQL

		strURL = "mstBANK.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>