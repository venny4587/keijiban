<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim MAIL_ID
dim MAIL_CODE
dim MAIL_TITLE
dim MAIL_HEAD
dim MAIL_FOOT
dim MAIL_BODY
dim MAIL_REMARKS

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	MAIL_ID = GetLong(Request("MAIL_ID"))
	If MAIL_ID = 0 Then
		blnEdit = False
		myTitle = "�ʒm���ǉ�"
		mySubmit = "�ǉ�"
		
		MAIL_CODE = ""
		MAIL_TITLE = "" 
		MAIL_HEAD = ""
		MAIL_FOOT = ""
		MAIL_BODY = ""
	Else
		blnEdit = True
		myTitle = "�ʒm���ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_MAIL WHERE MAIL_ID = " & MAIL_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			MAIL_CODE = GetString(Recset.Fields("MAIL_CODE"))
			MAIL_TITLE = GetString(Recset.Fields("MAIL_TITLE"))
			MAIL_HEAD = GetString(Recset.Fields("MAIL_HEAD"))
			MAIL_FOOT = GetString(Recset.Fields("MAIL_FOOT"))
			MAIL_BODY = GetString(Recset.Fields("MAIL_BODY"))
			MAIL_REMARKS = GetString(Recset.Fields("MAIL_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstMail.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y���ʒm�����폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstMail0.asp?MAIL_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkCode("MAIL_CODE","�ʒm�R�[�h", 1) = false then exit sub
				if checkText("MAIL_TITLE","�ʒm�^�C�g��", 1) = false then exit sub
				if checkText("MAIL_HEAD","�ʒm�w�b�_", 1) = false then exit sub
				if checkText("MAIL_REMARKS","�ʒm���e", 0) = false then exit sub
				if checkLen("MAIL_REMARKS","�ʒm���e",250) = false then exit sub
				if checkText("MAIL_FOOT","�ʒm�t�b�^�[", 0) = false then exit sub
				if checkText("MAIL_REMARKS","�ʒm���l", 0) = false then exit sub
				if checkLen("MAIL_REMARKS","�ʒm���l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
						
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstMail.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstMail1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="MAIL_ID" value='<%=MAIL_ID%>'>
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline nowrap>���ʒm�}�X�^
								<TD class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70>�ʒm����</TD>
								<TD><INPUT class=si NAME="MAIL_CODE" MAXLENGTH=3 SIZE=3 VALUE="<%=MAIL_CODE%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�ʒm����</TD>
								<TD><INPUT class=sj NAME="MAIL_TITLE" MAXLENGTH=50 SIZE=30 VALUE="<%=MAIL_TITLE%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�ʒmͯ��</TD>
								<TD><INPUT class=sj NAME="MAIL_HEAD" MAXLENGTH=100 SIZE=36 VALUE="<%=MAIL_HEAD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�ʒm���e</TD>
								<TD><textarea class=sj NAME="MAIL_BODY" style="width:250px;height:50px;"><%=MAIL_BODY%></textarea></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�ʒm̯��</TD>
								<TD><INPUT class=sj NAME="MAIL_FOOT" MAXLENGTH=100 SIZE=36 VALUE="<%=MAIL_FOOT%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�ʒm���l</TD>
								<TD><textarea NAME="MAIL_REMARKS" style="width:250px;height:50px;"><%=MAIL_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT MAIL_ID,"
					strSQL = strSQL + "       MAIL_CODE,"
					strSQL = strSQL + "       MAIL_TITLE,"
					strSQL = strSQL + "       MAIL_HEAD,"
					strSQL = strSQL + "       MAIL_BODY,"
					strSQL = strSQL + "       MAIL_FOOT,"
					strSQL = strSQL + "       MAIL_REMARKS"
					strSQL = strSQL + "  FROM MST_Mail"
					strSQL = strSQL + " WHERE Mail_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY MAIL_TITLE;"
					Case "en"
						strSQL = strSQL + " ORDER BY MAIL_BODY;"
					Case Else
						strSQL = strSQL + " ORDER BY MAIL_CODE;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.</TD>
							<TD class=line nowrap width=6%><a class=bar href="mstMail.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=26%><a class=bar href="mstMail.asp?s=jp">����</a></TD>
							<TD class=line nowrap width=30%>���e</TD>
							<TD class=line nowrap width=20%>���l</TD>
							<TD class=line nowrap width=6%>�ҏW</TD>
							<TD class=line nowrap width=6%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("MAIL_CODE"))%><BR></TD>
							<TD class=line nowrap><%=StringCut(.Fields("MAIL_TITLE"), 10)%><BR></TD>
							<TD class=line nowrap><%=StringCut(.Fields("MAIL_BODY"), 12)%><BR></TD>
							<TD class=line nowrap><%=StringCut(.Fields("MAIL_REMARKS"), 8)%><BR></TD>
						<%
							If MAIL_ID = GetLong(.Fields("MAIL_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstMail.asp?p=" & myPage & "&s=" & mySort & "&MAIL_ID=" & .Fields("MAIL_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("MAIL_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
