<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim ACNT_ID
	
	blnDelete = True
	ACNT_ID = GetLong(Request("ACNT_ID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT ACNT_CD FROM MST_ACCOUNT WHERE ACNT_DELETED = 0 AND ACNT_ID = " & ACNT_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y�����ڂɂ͊��Ɏg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_ACCOUNT SET ACNT_DELETED = 1"
		strSQL = strSQL & ",ACNT_UPDATED = GETDATE()"
		strSQL = strSQL & ",ACNT_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE ACNT_ID = " & ACNT_ID
		Conn.Execute strSQL

		strURL = "mstAccount.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>