<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

	dim blnEdit
	dim myPage
	dim lngCount
	dim lngPageCount
		
	dim CN_CD
	dim CN_NAME
	dim CN_ENAME
	dim CN_LINE
	dim CN_REMARKS

	dim mySubmit
	dim mySort
	dim myCode

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	CN_CD = GetPost(Request("CN_CD"))
	If CN_CD = "" Then
		blnEdit = False
		myTitle = "���f�[�^�ǉ�"
		mySubmit = "�ǉ�"
		
		CN_NAME = "" 
		CN_ENAME = ""
		CN_LINE = ""
		CN_ACTIVE = 0 
		CN_REMARKS = ""
	Else
		blnEdit = True
		myTitle = "���f�[�^�ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_COUNTRY WHERE CN_CD = '" & CN_CD & "';"
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			CN_NAME = GetString(Recset.Fields("CN_NAME"))
			CN_ENAME = GetString(Recset.Fields("CN_ENAME"))
			CN_LINE = GetString(Recset.Fields("CN_LINE"))
			CN_ACTIVE = GetLong(Recset.Fields("CN_ACTIVE"))
			CN_REMARKS = GetString(Recset.Fields("CN_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">			
			function AddNew()
				window.location.href = "mstCountry.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
					
			function ConfirmDelete(myCD)
				if msgbox("�Y�������폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstCountry0.asp?CN_CD=" & myCD & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				'if checkCode("CN_CD","���R�[�h", 1) = false then exit sub
				if checkText("CN_ENAME","�p������", 1) = false then exit sub
				if checkText("CN_NAME","�a������", 0) = false then exit sub
				if checkText("CN_LINE","�������C��", 0) = false then exit sub
				if checkText("CN_REMARKS","�����l", 0) = false then exit sub
				if checkLen("CN_REMARKS","�����l",250) = false then	exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub CN_ENAME_OnChange()
				frmInput.CN_ENAME.value = ucase(frmInput.CN_ENAME.value)
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstCountry.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstCountry1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="mode" value="<%=blnEdit%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline>�����}�X�^
								<TD class=gline align=right><!--<img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">--><br>
							</TR>
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70 class=pt9g>���R�[�h</TD>
								<TD><INPUT class=si NAME="CN_CD" MAXLENGTH=2 SIZE=3 VALUE="<%=CN_CD%>" OnKeyDown="ResetEnter()" OnKeyDown="ResetEnter()" readonly>
									�@(<a href="http://www.iso.org/iso/en/prods-services/iso3166ma/02iso-3166-code-lists/list-en1.html" target=_blank>ISO 3166 CODE</A>)</TD>
							</TR>
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap>�p������</TD>
								<TD><INPUT class=si NAME="CN_ENAME" MAXLENGTH=50 SIZE=36 VALUE="<%=CN_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�a������</TD>
								<TD><INPUT class=sj NAME="CN_NAME" MAXLENGTH=50 SIZE=36 VALUE="<%=CN_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�������H</TD>
								<TD class=pt9><INPUT class=sj NAME="CN_LINE" MAXLENGTH=20 SIZE=20 VALUE="<%=CN_LINE%>" OnKeyDown="ResetEnter()">�@�Ɩ��Ώ�
									<INPUT type=checkbox NAME="CN_ACTIVE" VALUE="1" OnKeyDown="ResetEnter()" <%if CN_ACTIVE then response.write " checked"%>></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�����l</TD>
								<TD><textarea NAME="CN_REMARKS" style="width:250px;height:50px;"><%=CN_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
<%If CN_CD <> "" Then%>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
<%end if%>
						<BR>
						<INPUT type=hidden name="p" value="<%=myPage%>">
						<INPUT type=hidden name="s" value="<%=mySort%>">
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT CN_CD,"
					strSQL = strSQL + "       CN_NAME,"
					strSQL = strSQL + "       CN_ENAME,"
					strSQL = strSQL + "       CN_LINE,"
					strSQL = strSQL + "       CN_ACTIVE,"
					strSQL = strSQL + "       CN_REMARKS"
					strSQL = strSQL + "  FROM MST_COUNTRY"
					strSQL = strSQL + " WHERE CN_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY CN_NAME;"
					Case "en"
						strSQL = strSQL + " ORDER BY CN_ENAME;"
					Case Else
						strSQL = strSQL + " ORDER BY CN_ACTIVE DESC, CN_LINE DESC, CN_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER height=22>
							<TD class=line nowrap width=6%>No.</TD>
							<TD class=line nowrap width=10%><a class=bar href="mstCountry.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=25%><a class=bar href="mstCountry.asp?s=en">�p������</a></TD>
							<TD class=line nowrap width=25%><a class=bar href="mstCountry.asp?s=jp">�a������</a></TD>
							<TD class=line nowrap width=20%>�������H</TD>
							<TD class=line nowrap width=8%>�ҏW</TD>
						<!--	<TD class=line nowrap width=8%>�폜</TD>	-->
							<TD class=line nowrap width=8%>�`��</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("CN_NAME"))
										myEname = GetString(.Fields("CN_ENAME"))
										if GetLong(.Fields("CN_ACTIVE")) then
											myColor = "black"
										else
											myColor = "gray"
										end if		
						%>
						<TR align=center height=22 style="color:<%=myColor%>">
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap width=40><%=GetString(.Fields("CN_CD"))%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myEname,20)%>><%=stringCut(myEname,20)%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myName,10)%>><%=stringCut(myName,10)%><BR></TD>
							<TD class=line nowrap align=center><%=GetString(.Fields("CN_LINE"))%><BR></TD>
						<%
							If CN_CD = GetString(.Fields("CN_CD")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstCountry.asp?p=" & myPage & "&s=" & mySort & "&CN_CD=" & .Fields("CN_CD") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
						<!--	<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("CN_CD")%>')"></TD> -->
							<TD class=line nowrap>
								<A HREF="mstPort.asp?PORT_CN=<%=.Fields("CN_CD")%>"><IMG SRC='img/new.gif' ALT='�`���Ɖ�' STYLE='cursor:hand' BORDER=0></A>
							</TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
