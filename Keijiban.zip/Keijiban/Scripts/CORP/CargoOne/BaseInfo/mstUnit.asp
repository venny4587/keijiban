<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim UNIT_ID
dim UNIT_CD
dim SINGULAR_ABR
dim SINGULAR_NAME
dim PLURAL_ABR
dim PLURAL_NAME
dim UNIT_REMARKS

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	UNIT_ID = GetLong(Request("UNIT_ID"))
	If UNIT_ID = 0 Then
		blnEdit = False
		myTitle = "�P�ʏ��ǉ�"
		mySubmit = "�ǉ�"
		
		UNIT_CD = ""
		SINGULAR_ABR = "" 
		SINGULAR_NAME = ""
		PLURAL_ABR = ""
		PLURAL_NAME = ""
	Else
		blnEdit = True
		myTitle = "�P�ʏ��ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_UNIT WHERE UNIT_ID = " & UNIT_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			UNIT_CD = GetString(Recset.Fields("UNIT_CD"))
			SINGULAR_ABR = GetString(Recset.Fields("SINGULAR_ABR"))
			SINGULAR_NAME = GetString(Recset.Fields("SINGULAR_NAME"))
			PLURAL_ABR = GetString(Recset.Fields("PLURAL_ABR"))
			PLURAL_NAME = GetString(Recset.Fields("PLURAL_NAME"))
			UNIT_REMARKS = GetString(Recset.Fields("UNIT_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstUnit.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y���P�ʏ����폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstUnit0.asp?UNIT_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkCode("UNIT_CD","�P�ʃR�[�h", 1) = false then exit sub
				if checkText("SINGULAR_ABR","�P������", 1) = false then exit sub
				if checkText("SINGULAR_NAME","�P������", 1) = false then exit sub
				if checkText("PLURAL_ABR","��������", 1) = false then exit sub
				if checkText("PLURAL_NAME","��������", 1) = false then exit sub
				if checkText("UNIT_REMARKS","�P�ʔ��l", 0) = false then exit sub
				if checkLen("UNIT_REMARKS","�P�ʔ��l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub UNIT_CD_OnChange()
				frmInput.UNIT_CD.value = ucase(frmInput.UNIT_CD.value)
			end sub
			
			sub SINGULAR_ABR_OnChange()
				frmInput.SINGULAR_ABR.value = ucase(frmInput.SINGULAR_ABR.value)
			end sub
			
			sub SINGULAR_NAME_OnChange()
				frmInput.SINGULAR_NAME.value = ucase(frmInput.SINGULAR_NAME.value)
			end sub
			
			sub PLURAL_ABR_OnChange()
				frmInput.PLURAL_ABR.value = ucase(frmInput.PLURAL_ABR.value)
			end sub
			
			sub PLURAL_NAME_OnChange()
				frmInput.PLURAL_NAME.value = ucase(frmInput.PLURAL_NAME.value)
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstUnit.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstUnit1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="UNIT_ID" value='<%=UNIT_ID%>'>
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline nowrap>�����}�X�^
								<TD class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70>�P�ʺ���</TD>
								<TD><INPUT class=si NAME="UNIT_CD" MAXLENGTH=3 SIZE=3 VALUE="<%=UNIT_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�P������</TD>
								<TD><INPUT class=si NAME="SINGULAR_ABR" MAXLENGTH=6 SIZE=6 VALUE="<%=SINGULAR_ABR%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�P������</TD>
								<TD><INPUT class=si NAME="SINGULAR_NAME" MAXLENGTH=16 SIZE=16 VALUE="<%=SINGULAR_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>��������</TD>
								<TD><INPUT class=si NAME="PLURAL_ABR" MAXLENGTH=8 SIZE=8 VALUE="<%=PLURAL_ABR%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>��������</TD>
								<TD><INPUT class=si NAME="PLURAL_NAME" MAXLENGTH=18 SIZE=18 VALUE="<%=PLURAL_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�P�ʔ��l</TD>
								<TD><textarea NAME="UNIT_REMARKS" style="width:250px;height:50px;"><%=UNIT_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT UNIT_ID,"
					strSQL = strSQL + "       UNIT_CD,"
					strSQL = strSQL + "       SINGULAR_ABR,"
					strSQL = strSQL + "       SINGULAR_NAME,"
					strSQL = strSQL + "       PLURAL_ABR,"
					strSQL = strSQL + "       PLURAL_NAME,"
					strSQL = strSQL + "       UNIT_REMARKS"
					strSQL = strSQL + "  FROM MST_UNIT"
					strSQL = strSQL + " WHERE UNIT_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY SINGULAR_ABR;"
					Case "en"
						strSQL = strSQL + " ORDER BY SINGULAR_NAME;"
					Case Else
						strSQL = strSQL + " ORDER BY UNIT_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.</TD>
							<TD class=line nowrap width=8%><a class=bar href="mstUnit.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=10%><a class=bar href="mstUnit.asp?s=jp">�P������</a></TD>
							<TD class=line nowrap width=30%><a class=bar href="mstUnit.asp?s=en">�P������</a></TD>
							<TD class=line nowrap width=10%>��������</TD>
							<TD class=line nowrap width=30%>��������</TD>
							<TD class=line nowrap width=6%>�ҏW</TD>
							<TD class=line nowrap width=8%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("UNIT_CD"))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("SINGULAR_ABR"))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("SINGULAR_NAME"))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("PLURAL_ABR"))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("PLURAL_NAME"))%><BR></TD>
						<%
							If UNIT_ID = GetLong(.Fields("UNIT_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstUnit.asp?p=" & myPage & "&s=" & mySort & "&UNIT_ID=" & .Fields("UNIT_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("UNIT_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
