<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim MAIL_ID
	
	blnDelete = True
	MAIL_ID = GetLong(request("MAIL_ID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT MAIL_CD FROM MST_MAIL WHERE MAIL_ID = " & MAIL_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y�����ڂɂ͊��Ɏg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_MAIL SET MAIL_DELETED = 1"
		strSQL = strSQL & ",MAIL_UPDATED = GETDATE()"
		strSQL = strSQL & ",MAIL_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE MAIL_ID = " & MAIL_ID
		Conn.Execute strSQL

		Response.Redirect "mstMail.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing	
%>