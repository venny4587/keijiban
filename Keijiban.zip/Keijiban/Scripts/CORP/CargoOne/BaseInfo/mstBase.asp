<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim BASE_ID
dim BASE_CD
dim BASE_NAME
dim BASE_ENAME
dim BASE_REMARKS

dim mySubmit
dim mySort
dim myCode
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	BASE_ID = GetLong(Request("BASE_ID"))
	If BASE_ID = 0 Then
		blnEdit = False
		myTitle = "��{���ڒǉ�"
		mySubmit = "�ǉ�"
		
		BASE_CD = ""
		BASE_NAME = "" 
		BASE_ENAME = ""
		BASE_REMARKS = ""
	Else
		blnEdit = True
		myTitle = "��{���ڕҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_BASE WHERE BASE_ID = " & BASE_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			BASE_CD = GetString(Recset.Fields("BASE_CD"))
			BASE_NAME = GetString(Recset.Fields("BASE_NAME"))
			BASE_ENAME = GetString(Recset.Fields("BASE_ENAME"))
			BASE_REMARKS = GetString(Recset.Fields("BASE_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstBase.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y����{���ڂ��폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstBase0.asp?BASE_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkCode("BASE_CD","���ڃR�[�h", 1) = false then exit sub
				if checkText("BASE_NAME","�a������", 1) = false then exit sub
				if checkText("BASE_ENAME","�p������", 0) = false then exit sub
				if checkText("BASE_REMARKS","���ڔ��l", 0) = false then exit sub
				if checkLen("BASE_REMARKS","���ڔ��l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstBase.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstBase1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="BASE_ID" value="<%=BASE_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline nowrap>����{����</TD>
								<TD class=gline align=right><img src=img/spacer.gif height=3><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70>���ں���</TD>
								<TD><INPUT class=si NAME="BASE_CD" MAXLENGTH=3 SIZE=3 VALUE="<%=BASE_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�a������</TD>
								<TD><INPUT class=sj NAME="BASE_NAME" MAXLENGTH=50 SIZE=30 VALUE="<%=BASE_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�p������</TD>
								<TD><INPUT class=si NAME="BASE_ENAME" MAXLENGTH=50 SIZE=40 VALUE="<%=BASE_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>���ڔ��l</TD>
								<TD><textarea NAME="BASE_REMARKS" style="width:250px;height:50px;"><%=BASE_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT BASE_ID,"
					strSQL = strSQL + "       BASE_CD,"
					strSQL = strSQL + "       BASE_NAME,"
					strSQL = strSQL + "       BASE_ENAME,"
					strSQL = strSQL + "       BASE_REMARKS"
					strSQL = strSQL + "  FROM MST_BASE"
					strSQL = strSQL + " WHERE BASE_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY BASE_NAME;"
					Case "en"
						strSQL = strSQL + " ORDER BY BASE_ENAME;"
					Case Else
						strSQL = strSQL + " ORDER BY BASE_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.</TD>
							<TD class=line nowrap width=10%><a class=bar href="mstBase.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=25%><a class=bar href="mstBase.asp?s=jp">�a������</a></TD>
							<TD class=line nowrap width=25%><a class=bar href="mstBase.asp?s=en">�p������</a></TD>
							<TD class=line nowrap width=20%>���l</TD>
							<TD class=line nowrap width=8%>�ҏW</TD>
						<!--<TD class=line nowrap width=8%>�폜</TD>-->
							<TD class=line nowrap width=8%>�Ɖ�</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("BASE_NAME"))
										myEname = GetString(.Fields("BASE_ENAME"))
										myRemark = GetString(.Fields("BASE_REMARKS"))
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("BASE_CD"))%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myName,15)%>><%=stringCut(myName,15)%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myEname,30)%>><%=stringCut(myEname,30)%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myRemark,15)%>><%=stringCut(myRemark,15)%><BR></TD>
						<%
							If BASE_ID = GetLong(.Fields("BASE_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstBase.asp?p=" & myPage & "&s=" & mySort & "&BASE_ID=" & .Fields("BASE_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
						<!--<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("BASE_ID")%>')"></TD>-->
							<TD class=line nowrap>
								<A HREF="mstCategory.asp?CTGR_BASE=<%=.Fields("BASE_ID")%>"><IMG SRC='img/group.gif' ALT='�Ɖ�' STYLE='cursor:hand' BORDER=0></A>
							</TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
