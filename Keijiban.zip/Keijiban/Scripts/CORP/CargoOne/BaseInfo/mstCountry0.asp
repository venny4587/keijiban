<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim CN_CD
	dim strURL
	dim strErrMsg
	dim blnDelete
	
	blnDelete = True
	CN_CD = GetPost(request("CN_CD"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT PORT_COUNTRY FROM MST_PORT WHERE PORT_DELETED = 0 AND PORT_COUNTRY = '" & CN_CD & "';"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y�����ڂɂ͖��׃f�[�^������܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_COUNTRY SET CN_DELETED = 1"
		strSQL = strSQL & ",CN_UPDATED = GETDATE()"
		strSQL = strSQL & ",CN_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE CN_DELETED = 0 AND CN_CD = '" & CN_CD & "'"
		Conn.Execute strSQL
		
		strURL = "mstCountry.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>