<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim COST_ID
	dim COST_CD
	dim COST_REF
	dim COST_NAME
	dim COST_ENAME
	dim COST_ATTR
	dim COST_REMARKS
	
	COST_ID = GetLong(Request("COST_ID"))
	COST_CD = GetPost(Request("COST_CD"))
	COST_REF = GetPost(Request("COST_REF"))
	COST_ENAME = GetPost(Request("COST_ENAME"))
	COST_NAME = GetPost(Request("COST_NAME"))
	COST_TAX = GetLong(Request("COST_TAX"))
	COST_TYPE = GetLong(Request("COST_TYPE"))
	COST_PLUS = GetLong(Request("COST_PLUS"))
	for i = 1 to 5
		COST_ATTR = COST_ATTR & GetLong(Request("COST_ATTR" & i))
	next
	COST_ATTR = left(COST_ATTR & "0000000000", 10)
	COST_REMARKS = GetPost(Request("COST_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			.Open "SELECT COST_CD FROM MST_COST WHERE COST_ID <> " & COST_ID & " AND COST_CD = '"  & replace(COST_CD, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����p�R�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit AND COST_REF <> "" Then
		With Recset
			.Open "SELECT COST_CD FROM MST_COST WHERE COST_ID <> " & COST_ID & " AND COST_REF = '"  & replace(COST_REF, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����p�̌������̂͊����ł��B(�Y�������p����:" & .Fields("COST_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit AND COST_ENAME <> "" Then	
		With Recset
			.Open "SELECT COST_CD FROM MST_COST WHERE COST_ID <> " & COST_ID & " AND COST_ENAME = '"  & replace(COST_ENAME, "'", "''") &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����p�̉p�����̂͊����ł��B(�Y�������p����:" & .Fields("COST_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit AND COST_NAME <> "" Then	
		With Recset
			.Open "SELECT COST_CD FROM MST_COST WHERE COST_ID <> " & COST_ID & " AND COST_NAME = '"  & replace(COST_NAME, "'", "''") &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����p�̘a�����̂͊����ł��B(�Y�������p����:" & .Fields("COST_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
	
		if COST_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "COST_ID"	
			cmdSQL.Execute
			COST_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
	
		strSQL = "SELECT * FROM MST_COST WHERE COST_ID = " & COST_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("COST_ID") = COST_ID
				.fields("COST_CREATER") = WebUserID
				.fields("COST_CREATED") = now
				.fields("COST_DELETED") = 0
			End If
			.Fields("COST_CD") = COST_CD
			.Fields("COST_REF") = COST_REF
			.Fields("COST_ENAME") = COST_ENAME
			.Fields("COST_NAME") = COST_NAME
			.Fields("COST_TAX") = COST_TAX
			.Fields("COST_TYPE") = COST_TYPE
			.Fields("COST_PLUS") = COST_PLUS	
			.Fields("COST_ATTR") = COST_ATTR
			.Fields("COST_REMARKS") = COST_REMARKS
		
			.fields("COST_UPDATER") = WebUserID
			.fields("COST_UPDATED") = now
			.Update 
			.Close 
		End With
		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstCost.asp?p=" & GetCurrentPage(Conn, "MST_COST", "COST_CD", 1, COST_CD, " AND COST_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstCost.asp?p=" & GetCurrentPage(Conn, "MST_COST", "COST_REF", 1, COST_REF, " AND COST_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstCost.asp?p=" & GetCurrentPage(Conn, "MST_COST", "COST_NAME", 1, COST_NAME, " AND COST_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.Redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
