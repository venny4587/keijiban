<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim ID
	dim Holiday
	dim Remarks
	
	ID = GetLong(Request("ID"))
	Holiday = GetDate(Request("Holiday"))
	Remarks = GetPost(Request("Remarks"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then	
		With Recset
			.Open "SELECT Holiday FROM MST_HOLIDAY WHERE ID <> " & ID & " AND Holiday = '"  & Date2Str(Holiday) &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���j�Փ��͊����ł��B"
			End If
			.Close 
		End With
	End If
	If blnEdit Then		
		if ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "Holiday"	
			cmdSQL.Execute
			ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
		strSQL = "SELECT * FROM MST_HOLIDAY WHERE ID = " & ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("ID") = ID
				.fields("Creater") = WebUserID
				.fields("Created") = now
				.fields("Deleted") = 0
			End If
			.Fields("Holiday") = Date2Str(Holiday)
			.Fields("Remarks") = Remarks	
		
			.fields("Updater") = WebUserID
			.fields("Updated") = now
			.Update 
			.Close 
		End With
		Response.Redirect "mstHoliday.asp?p=" & request("p")
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
