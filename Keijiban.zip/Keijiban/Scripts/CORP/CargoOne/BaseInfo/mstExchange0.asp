<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim EXCH_ID
	
	blnDelete = True
	EXCH_ID = GetLong(request("EXCH_ID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT EXCH_CD FROM MST_EXCHANGE WHERE EXCH_ID = " & EXCH_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y���בփ��[�g�͂��łɎg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_EXCHANGE SET EXCH_DELETED = 1"
		strSQL = strSQL & ",EXCH_UPDATED = GETDATE()"
		strSQL = strSQL & ",EXCH_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE EXCH_ID = " & EXCH_ID
		Conn.Execute strSQL

		strURL = "mstExchange.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>