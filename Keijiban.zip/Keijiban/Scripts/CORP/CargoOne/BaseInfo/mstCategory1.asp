<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim CTGR_BASE
	dim CTGR_CD
	dim CTGR_NAME
	dim CTGR_ENAME
	dim CTGR_REMARKS
	
	CTGR_ID = GetLong(Request("CTGR_ID"))
	CTGR_BASE = GetLong(Request("CTGR_BASE"))
	CTGR_CD = GetPost(Request("CTGR_CD"))
	CTGR_NAME = GetPost(Request("CTGR_NAME"))
	CTGR_ENAME = GetPost(Request("CTGR_ENAME"))
	CTGR_NUM = GetDouble(Request("CTGR_NUM"))
	CTGR_FLAG = GetLong(Request("CTGR_FLAG"))
	CTGR_REMARKS = GetPost(Request("CTGR_REMARKS"))

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			strSql = "SELECT CTGR_CD FROM MST_CATEGORY WHERE CTGR_ID <> " & CTGR_ID & " AND CTGR_BASE = '" & CTGR_BASE & "' AND CTGR_CD = '" & CTGR_CD & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���敪�R�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	
	If blnEdit Then
		With Recset
			strSql = "SELECT CTGR_CD FROM MST_CATEGORY WHERE CTGR_ID <> " & CTGR_ID & " AND CTGR_BASE = '" & CTGR_BASE & "' AND CTGR_CD <> '" & CTGR_CD & "' AND CTGR_NAME = '" & replace(CTGR_NAME,"'", "''") & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���敪�̘a�����̂͊����ł��B(�Y������敪����:" & .Fields("CTGR_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit AND CTGR_ENAME <> "" Then	
		With Recset
			strSql = "SELECT CTGR_CD FROM MST_CATEGORY WHERE CTGR_ID <> " & CTGR_ID & " AND CTGR_BASE = '" & CTGR_BASE & "' AND CTGR_CD <> '" & CTGR_CD & "' AND CTGR_ENAME = '"  & replace(CTGR_ENAME,"'", "''") &"';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���敪�̉p�����̂͊����ł��B(�Y������敪����:" & .Fields("CTGR_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
			
		if CTGR_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "CTGR_ID"	
			cmdSQL.Execute
			CTGR_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
		
		strSQL = "SELECT * FROM MST_CATEGORY WHERE CTGR_ID = " & CTGR_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("CTGR_ID") = CTGR_ID
				.fields("CTGR_CREATER") = WebUserID
				.fields("CTGR_CREATED") = now
				.fields("CTGR_DELETED") = 0
			End If
			.Fields("CTGR_BASE") = CTGR_BASE
			.Fields("CTGR_CD") = CTGR_CD
			.Fields("CTGR_NAME") = CTGR_NAME
			.Fields("CTGR_ENAME") = CTGR_ENAME
			.Fields("CTGR_NUM") = CTGR_NUM
			.Fields("CTGR_FLAG") = CTGR_FLAG
			.Fields("CTGR_REMARKS") = CTGR_REMARKS	
		
			.fields("CTGR_UPDATER") = WebUserID
			.fields("CTGR_UPDATED") = now
			.Update 
			.Close 
		End With

		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstCategory.asp?CTGR_BASE=" & CTGR_BASE & "&p=" & GetCurrentPage(Conn, "MST_CATEGORY", "CTGR_CD", 1, CTGR_CD, " AND CTGR_BASE = '" & CTGR_BASE & "' AND CTGR_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstCategory.asp?CTGR_BASE=" & CTGR_BASE & "&p=" & GetCurrentPage(Conn, "MST_CATEGORY", "CTGR_ENAME", 1, CTGR_ENAME, " AND CTGR_BASE = '" & CTGR_BASE & "' AND CTGR_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstCategory.asp?CTGR_BASE=" & CTGR_BASE & "&p=" & GetCurrentPage(Conn, "MST_CATEGORY", "CTGR_NAME", 1, CTGR_NAME, " AND CTGR_BASE = '" & CTGR_BASE & "' AND CTGR_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
