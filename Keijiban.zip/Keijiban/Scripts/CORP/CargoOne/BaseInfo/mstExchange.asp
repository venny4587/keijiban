<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim EXCH_ID
dim EXCH_CD
dim EXCH_ORG
dim EXCH_CUR
dim EXCH_RATE
dim START_DATE
dim END_DATE
dim EXCH_REMARKS

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1


	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	EXCH_ID = GetLong(Request("EXCH_ID"))
	If EXCH_ID = 0 Then
		blnEdit = False
		myTitle = "�בփ��[�g�ǉ�"
		mySubmit = "�ǉ�"
		
		EXCH_CD = ""
		EXCH_CUR = ""
		EXCH_RATE = "0.0000"
		START_DATE = ""
		END_DATE = ""
		EXCH_REMARKS = ""
	Else
		blnEdit = True
		myTitle = "�בփ��[�g�ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_EXCHANGE WHERE EXCH_ID = " & EXCH_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly
		if not Recset.eof then
			EXCH_CD = GetString(Recset.Fields("EXCH_CD"))
			EXCH_CUR = GetString(Recset.Fields("EXCH_CUR"))
			EXCH_RATE = formatnumber(Recset.Fields("EXCH_RATE"), 4, true)
			START_DATE = Str2Date(Recset.Fields("START_DATE"))
			END_DATE = Str2Date(Recset.Fields("END_DATE"))
			EXCH_REMARKS = GetString(Recset.Fields("EXCH_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstExchange.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
					
			function ConfirmDelete(myID)
				if msgbox("�Y���בփ��[�g���폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstExchange0.asp?EXCH_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			sub START_DATE_Onchange()
				frmInput.START_DATE.value = setDate(frmInput.START_DATE.value)
			end sub
			
			sub END_DATE_Onchange()
				frmInput.END_DATE.value = setDate(frmInput.END_DATE.value)
			end sub
			
			Sub DoSubmit()
				if checkCode("EXCH_CD","�בփR�[�h", 1) = false then exit sub
				if checkDouble("EXCH_RATE","�בփ��[�g", 1) = false then exit sub
				if checkDate("START_DATE","�ב֊J�n��", 1) = false then exit sub
				if checkDate("END_DATE","�ב֏I����", 1) = false then exit sub
				if checkText("EXCH_REMARKS","�ב֔��l", 0) = false then	exit sub
				if checkLen("EXCH_REMARKS","�ב֔��l",250) = false then	exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstExchange.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstExchange1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="EXCH_ID" value='<%=EXCH_ID%>'>
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD colspan=2 class=gline>���בփ}�X�^
								<TD colspan=2 class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70>�בֺ���</TD>
								<TD><INPUT class=si NAME="EXCH_CD" MAXLENGTH=6 SIZE=6 VALUE="<%=EXCH_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�O�ݖ�</TD>
								<TD><SELECT name="EXCH_CUR" onkeydown="ResetEnter()"><%
									for i = 1 to ubound(curType)
										response.write "<option value=" & curType(i)
										if EXCH_CUR = curType(i) then response.write " selected" 
										response.write ">" & curType(i)
									next%></SELECT></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�ב�ڰ�</TD>
								<TD><INPUT class=sn NAME="EXCH_RATE" MAXLENGTH=9 SIZE=8 VALUE="<%=EXCH_RATE%>" OnKeyDown="ResetEnter()">
									�@�i1�O�݂�����̉~���j</TD>
							</TR>
							<TR>
								<TD align=center nowrap>�J�n��</TD>
								<TD><INPUT class=si NAME="START_DATE" MAXLENGTH=10 SIZE=10 VALUE="<%=START_DATE%>" OnKeyDown="ResetEnter()" onclick="setday(this)"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�I����</TD>
								<TD><INPUT class=si NAME="END_DATE" MAXLENGTH=10 SIZE=10 VALUE="<%=END_DATE%>" OnKeyDown="ResetEnter()" onclick="setday(this)"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�ב֔��l</TD>
								<TD><textarea NAME="EXCH_REMARKS" style="width:250px;height:50px;"><%=EXCH_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT EXCH_ID,"
					strSQL = strSQL + "       EXCH_CD,"
					strSQL = strSQL + "       EXCH_CUR,"
					strSQL = strSQL + "       EXCH_RATE,"
					strSQL = strSQL + "       START_DATE,"
					strSQL = strSQL + "       END_DATE,"
					strSQL = strSQL + "       EXCH_REMARKS"
					strSQL = strSQL + "  FROM MST_EXCHANGE"
					strSQL = strSQL + " WHERE EXCH_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY EXCH_ORG DESC;"
					Case "en"
						strSQL = strSQL + " ORDER BY EXCH_CUR DESC;"
					Case Else
						strSQL = strSQL + " ORDER BY EXCH_CD DESC;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=10%>No.</TD>
							<TD class=line nowrap width=15%><a class=bar href="mstExchange.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=10%><a class=bar href="mstExchange.asp?s=en">�O��</a></TD>
							<TD class=line nowrap width=15%>���[�g</TD>
							<TD class=line nowrap width=20%><a class=bar href="mstExchange.asp?s=jp">�J�n��</a></TD>
							<TD class=line nowrap width=20%>�I����</TD>
							<TD class=line nowrap width=10%>�ҏW</TD>
							<TD class=line nowrap width=10%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("EXCH_CD"))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("EXCH_CUR"))%><BR></TD>
							<TD class=line nowrap align=right><%=formatnumber(.Fields("EXCH_RATE"), 4, true)%><BR></TD>
							<TD class=line nowrap><%=Str2Date(.Fields("START_DATE"))%><BR></TD>
							<TD class=line nowrap><%=Str2Date(.Fields("END_DATE"))%><BR></TD>
						<%
							If EXCH_ID = GetLong(.Fields("EXCH_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstExchange.asp?p=" & myPage & "&s=" & mySort & "&EXCH_ID=" & .Fields("EXCH_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("EXCH_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
