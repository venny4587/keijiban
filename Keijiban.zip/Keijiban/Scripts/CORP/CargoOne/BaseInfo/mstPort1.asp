<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim PORT_ID
	dim PORT_CD
	dim PORT_NAME
	dim PORT_ENAME
	dim PORT_ACTIVE
	dim PORT_REMARKS
	
	PORT_ID = GetLong(Request("PORT_ID"))
	PORT_CN = GetPost(Request("PORT_CN"))
	PORT_CD = GetPost(Request("PORT_CD"))
	PORT_NAME = GetPost(Request("PORT_NAME"))
	PORT_ENAME = GetPost(Request("PORT_ENAME"))
	PORT_NACCS = GetPost(Request("PORT_NACCS"))
	PORT_ACTIVE = GetLong(Request("PORT_ACTIVE"))
	PORT_REMARKS = GetPost(Request("PORT_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			strSql = "SELECT PORT_CD FROM MST_PORT WHERE PORT_ID <> " & PORT_ID & " AND PORT_CN = '" & PORT_CN & "' AND PORT_CD = '" & PORT_CD & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���`���R�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	
	If blnEdit Then	
		With Recset
			strSql = "SELECT PORT_CD FROM MST_PORT WHERE PORT_ID <> " & PORT_ID & " AND PORT_CN = '" & PORT_CN & "' AND PORT_CD <> '" & PORT_CD & "' AND PORT_ENAME = '"  & replace(PORT_ENAME,"'", "''") &"';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���`���̉p�����̂͊����ł��B(�Y������`������:" & .Fields("PORT_CD") & ")"
			End If
			.Close 
		End With
	End If
	
	If blnEdit AND PORT_NAME <> "" Then
		With Recset
			strSql = "SELECT PORT_CD FROM MST_PORT WHERE PORT_ID <> " & PORT_ID & " AND PORT_CN = '" & PORT_CN & "' AND PORT_CD <> '" & PORT_CD & "' AND PORT_NAME = '" & replace(PORT_NAME,"'", "''") & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���`���̘a�����̂͊����ł��B(�Y������`������:" & .Fields("PORT_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then		
	
		if PORT_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "PORT_ID"	
			cmdSQL.Execute
			PORT_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
			
		strSQL = "SELECT * FROM MST_PORT WHERE PORT_ID = " & PORT_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("PORT_ID") = PORT_ID
				.fields("PORT_CREATER") = WebUserID
				.fields("PORT_CREATED") = now
				.fields("PORT_DELETED") = 0
			End If
			.Fields("PORT_CN") = PORT_CN
			.Fields("PORT_CD") = PORT_CD
			.Fields("PORT_NAME") = PORT_NAME
			.Fields("PORT_ENAME") = PORT_ENAME
			.Fields("PORT_NACCS") = PORT_NACCS
			.Fields("PORT_ACTIVE") = PORT_ACTIVE
			.Fields("PORT_REMARKS") = PORT_REMARKS	
		
			.fields("PORT_UPDATER") = WebUserID
			.fields("PORT_UPDATED") = now
			.Update 
			.Close 
		End With

		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstPort.asp?PORT_CN=" & PORT_CN & "&p=" & GetCurrentPage(Conn, "MST_PORT", "PORT_CD", 1, PORT_CD, " AND PORT_CN = '" & PORT_CN & "' AND PORT_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstPort.asp?PORT_CN=" & PORT_CN & "&p=" & GetCurrentPage(Conn, "MST_PORT", "PORT_ENAME", 1, PORT_ENAME, " AND PORT_CN = '" & PORT_CN & "' AND PORT_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstPort.asp?PORT_CN=" & PORT_CN & "&p=" & GetCurrentPage(Conn, "MST_PORT", "PORT_NAME", 1, PORT_NAME, " AND PORT_CN = '" & PORT_CN & "' AND PORT_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
