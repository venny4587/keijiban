<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim PLC_ID
dim PLC_CD
dim PLC_NAME
dim PLC_FAX
dim PLC_TEL
dim PLC_NACCS
dim PLC_CSTM
dim PLC_REMARKS

dim mySubmit
dim mySort
dim myCode

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	PLC_ID = GetLong(Request("PLC_ID"))
	If PLC_ID = 0 Then
		blnEdit = False
		myTitle = "���u�ꏊ�f�[�^�ǉ�"
		mySubmit = "�ǉ�"
		
		PLC_CD = ""
		PLC_NAME = "" 
		PLC_TEL = ""
		PLC_FAX = ""
		PLC_NACCS = ""
		PLC_CSTM = ""
		PLC_REMARKS = ""
	Else
		blnEdit = True
		myTitle = "���u�ꏊ�f�[�^�ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_PLACE WHERE PLC_ID = " & PLC_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			PLC_CD = GetString(Recset.Fields("PLC_CD"))
			PLC_NAME = GetString(Recset.Fields("PLC_NAME"))
			PLC_TEL = GetString(Recset.Fields("PLC_TEL"))
			PLC_FAX = GetString(Recset.Fields("PLC_FAX"))
			PLC_NACCS = GetString(Recset.Fields("PLC_NACCS"))
			PLC_CSTM = GetString(Recset.Fields("PLC_CSTM"))
			PLC_REMARKS = GetString(Recset.Fields("PLC_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstPlace.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
					
			function ConfirmDelete(myID)
				if msgbox("�Y�����u�ꏊ���폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstPlace0.asp?PLC_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()				
				if checkCode("PLC_CD","�����R�[�h", 1) = false then exit sub
				if checkText("PLC_NAME","���u�ꏊ����", 1) = false then exit sub
				if checkText("PLC_NACCS","NACCS�R�[�h", 0) = false then exit sub
				if checkText("PLC_TEL","�d�b�ԍ�", 0) = false then exit sub
				if checkText("PLC_FAX","FAX�ԍ�", 0) = false then exit sub
				if checkText("PLC_CSTM","�֘A�Ŋ�", 0) = false then exit sub
				if checkText("PLC_REMARKS","���l", 0) = false then exit sub
				if checkLen("PLC_REMARKS","���l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub PLC_CD_OnChange()
				frmInput.PLC_CD.value = ucase(frmInput.PLC_CD.value)
			end sub
			
			sub PLC_NAME_OnChange()
				frmInput.PLC_NAME.value = ucase(frmInput.PLC_NAME.value)
			end sub
			
			sub PLC_NACCS_OnChange()
				frmInput.PLC_NACCS.value = ucase(frmInput.PLC_NACCS.value)
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstPlace.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstPlace1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="PLC_ID" value="<%=PLC_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9>
							<TR><TD class=gline colspan=2>�����u�ꏊ�}�X�^
								<TD class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap class=pt9n>��������</TD>
								<TD><INPUT class=si NAME="PLC_CD" MAXLENGTH=10 SIZE=8 VALUE="<%=PLC_CD%>" OnKeyDown="ResetEnter()"></TD>
								<TD align=center nowrap>NACCS����&nbsp;
									<INPUT class=si NAME="PLC_NACCS" MAXLENGTH=5 SIZE=5 VALUE="<%=PLC_NACCS%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9n>���u�ꏊ</TD>
								<TD colspan=3><INPUT class=sj NAME="PLC_NAME" MAXLENGTH=50 SIZE=36 VALUE="<%=PLC_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�d�b�ԍ�</TD>
								<TD colspan=2><INPUT class=si NAME="PLC_TEL" MAXLENGTH=50 SIZE=20 VALUE="<%=PLC_TEL%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
								<TD align=center nowrap>FAX�ԍ�</TD>
								<TD colspan=2><INPUT class=si NAME="PLC_FAX" MAXLENGTH=50 SIZE=20 VALUE="<%=PLC_FAX%>" OnKeyDown="ResetEnter()"></TD>
							<TR>
								<TD align=center nowrap>�֘A�Ŋ�
								<TD colspan=2><INPUT class=si NAME="PLC_CSTM" MAXLENGTH=10 SIZE=10 VALUE="<%=PLC_CSTM%>" OnKeyDown="ResetEnter()"></TD>
							<TR>
								<TD align=center nowrap>���l</TD>
								<TD colspan=2><textarea NAME="PLC_REMARKS" style="width:250px;height:50px;"><%=PLC_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT PLC_ID,"
					strSQL = strSQL + "       PLC_CD,"
					strSQL = strSQL + "       PLC_NAME,"
					strSQL = strSQL + "       PLC_TEL,"
					strSQL = strSQL + "       PLC_FAX,"
					strSQL = strSQL + "       PLC_NACCS,"
					strSQL = strSQL + "       PLC_CSTM,"
					strSQL = strSQL + "       PLC_REMARKS"
					strSQL = strSQL + "  FROM MST_PLACE"
					strSQL = strSQL + " WHERE PLC_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY PLC_NACCS;"
					Case "en"
						strSQL = strSQL + " ORDER BY PLC_NAME;"
					Case Else
						strSQL = strSQL + " ORDER BY PLC_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER height=22>
							<TD class=line nowrap width=5%>No.</TD>
							<TD class=line nowrap width=15%><a class=bar href="mstPlace.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=30%><a class=bar href="mstPlace.asp?s=en">���u�ꏊ</a></TD>
							<TD class=line nowrap width=15%><a class=bar href="mstPlace.asp?s=jp">NACCS</a></TD>
							<TD class=line nowrap width=30%>TEL/FAX</TD>
							<TD class=line nowrap width=5%>�ҏW</TD>
<!--							<TD class=line nowrap width=5%>�폜</TD>	-->
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("PLC_NAME"))
										myTel = GetString(.Fields("PLC_TEL"))
										if GetString(.Fields("PLC_FAX")) <> "" then
											myTel = myTel & "/" & GetString(.Fields("PLC_FAX"))
										end if
						%>
						<TR height=22 style="color:<%=myColor%>">
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("PLC_CD"))%><BR></TD>
							<TD class=line nowrap <%=ShowTitle(myName,20)%>><%=stringCut(myName,20)%><BR></TD>
							<TD class=line nowrap align=center><%=GetString(.Fields("PLC_NACCS"))%><BR></TD>
							<TD class=line nowrap <%=ShowTitle(myTel,20)%>><%=stringCut(myTel,20)%><BR></TD>
						<%
							If PLC_ID = GetLong(.Fields("PLC_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstPlace.asp?p=" & myPage & "&s=" & mySort & "&PLC_ID=" & .Fields("PLC_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
<!--							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("PLC_ID")%>')"></TD>	-->
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
