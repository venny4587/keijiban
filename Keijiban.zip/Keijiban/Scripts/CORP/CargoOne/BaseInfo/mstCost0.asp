<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim COST_ID
	
	blnDelete = True
	COST_ID = GetLong(request("COST_ID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT COST_CD FROM MST_COST WHERE COST_DELETED = 0 AND COST_ID = " & COST_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y�����ڂɂ͊��Ɏg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_COST SET COST_DELETED = 1"
		strSQL = strSQL & ",COST_UPDATED = GETDATE()"
		strSQL = strSQL & ",COST_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE COST_ID = " & COST_ID
		Conn.Execute strSQL

		strURL = "mstCost.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>