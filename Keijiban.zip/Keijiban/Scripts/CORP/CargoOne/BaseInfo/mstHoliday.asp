<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim ID
dim Holiday
dim Remarks

dim mySubmit
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myPage = GetLong(request("p"))
	if myPage = 0 then myPage = 1
	
	ID = GetLong(Request("ID"))
	If ID = 0 Then
		blnEdit = False
		myTitle = "�j�Փ��ǉ�"
		mySubmit = "�ǉ�"
		
		Holiday = ""
		Remarks = ""
	Else
		blnEdit = True
		myTitle = "�j�Փ��ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT Holiday, Remarks FROM MST_HOLIDAY WHERE ID = " & ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			Holiday = Str2Date(Recset.Fields("Holiday"))
			Remarks = GetString(Recset.Fields("Remarks"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstHoliday.asp?p=<%=myPage%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y���j�Փ����폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstHoliday0.asp?ID=" & myID & "&p=<%=myPage%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkDate("Holiday","�j�Փ�", 1) = false then exit sub
				if checkText("Remarks","�j�Փ����l", 0) = false then exit sub
				if checkLen("Remarks","�j�Փ����l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub Holiday_OnBlur()
				frmInput.Holiday.value = setdate(frmInput.Holiday.value)
			end sub		
		
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstHoliday.asp?p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstHoliday1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="ID" value="<%=ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline nowrap>���j�Փ�</TD>
								<TD class=gline align=right><img src=img/spacer.gif height=3><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70>�j�Փ�</TD>
								<TD><INPUT class=si NAME="Holiday" MAXLENGTH=10 SIZE=10 VALUE="<%=Holiday%>" OnKeyDown="ResetEnter()" onclick="setday(this)"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>���l</TD>
								<TD><textarea NAME="Remarks" style="width:250px;height:50px;"><%=Remarks%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value="<%=myPage%>">
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT ID,"
					strSQL = strSQL + "       Holiday,"
					strSQL = strSQL + "       Remarks"
					strSQL = strSQL + "  FROM MST_HOLIDAY"
					strSQL = strSQL + " WHERE Deleted = 0"
					strSQL = strSQL + " ORDER BY Holiday DESC;"
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=10%>No.</TD>
							<TD class=line nowrap width=30%>�j�Փ�</TD>
							<TD class=line nowrap width=40%>���l</TD>
							<TD class=line nowrap width=10%>�ҏW</TD>
							<TD class=line nowrap width=10%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myDate = Str2Date(.Fields("Holiday"))
										if .Fields("Holiday") < Date2Str(date) then 
											myColor = "gray"
										else
											myColor = "Black"
										end if
										myRemark = GetString(.Fields("Remarks"))
						%>
						<TR align=center style="color:<%=myColor%>">
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=myDate%>�i<%=GetWeekDay(weekday(myDate))%>�j<BR>
							<TD class=line nowrap align=left <%=ShowTitle(myRemark,20)%>><%=stringCut(myRemark,20)%><BR>
						<%
							If ID = GetLong(.Fields("ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstHoliday.asp?p=" & myPage & "&ID=" & .Fields("ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("ID")%>')">
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
