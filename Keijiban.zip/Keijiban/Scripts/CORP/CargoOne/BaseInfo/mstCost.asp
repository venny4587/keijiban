<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim COST_ID
dim COST_CD
dim COST_REF
dim COST_ENAME
dim COST_ATTR
dim COST_NAME
dim COST_REMARKS

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	COST_ID = GetLong(Request("COST_ID"))
	If COST_ID = 0 Then
		blnEdit = False
		myTitle = "��p���ڒǉ�"
		mySubmit = "�ǉ�"
		
		COST_CD = "" 
		COST_REF = "" 
		COST_ENAME = ""
		COST_NAME = ""
		COST_TAX = 1
		COST_TYPE = 1
		COST_PLUS = 1
		COST_ATTR = ""
	Else
		blnEdit = True
		myTitle = "��p���ڕҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_COST WHERE COST_ID = " & COST_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			COST_CD = GetString(Recset.Fields("COST_CD"))
			COST_REF = GetString(Recset.Fields("COST_REF"))
			COST_ENAME = GetString(Recset.Fields("COST_ENAME"))
			COST_NAME = GetString(Recset.Fields("COST_NAME"))
			COST_TAX = GetLong(Recset.Fields("COST_TAX"))
			COST_TYPE = GetLong(Recset.Fields("COST_TYPE"))
			COST_PLUS = GetLong(Recset.Fields("COST_PLUS"))
			COST_ATTR = GetString(Recset.Fields("COST_ATTR"))
			COST_REMARKS = GetString(Recset.Fields("COST_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstCost.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y����p���ڂ��폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstCost0.asp?COST_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkCode("COST_CD","��p�R�[�h", 1) = false then exit sub
				if checkText("COST_REF","��������", 1) = false then exit sub
				if checkText("COST_NAME","�a������", 1) = false then exit sub
				if checkText("COST_ENAME","�p������", 0) = false then exit sub
				if checkText("COST_REMARKS","���l", 0) = false then exit sub
				if checkLen("COST_REMARKS","���l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstCost.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstCost1.asp" ID=frmInput NAME=frmInput>
						<input type=hidden name="COST_ID" value="<%=COST_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline colspan=2>����p����
								<TD class=gline colspan=2 align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap>��p����</TD>
								<TD><INPUT class=si NAME="COST_CD" MAXLENGTH=3 SIZE=3 VALUE="<%=COST_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>��������</TD>
								<TD><INPUT class=si NAME="COST_REF" MAXLENGTH=16 SIZE=12 VALUE="<%=COST_REF%>" OnKeyDown="ResetEnter()"></TD>
								<TD align=center nowrap class=pt9>�ېŋ敪</TD>
								<TD><INPUT type=radio NAME="COST_TAX" VALUE="0" OnKeyDown="ResetEnter()" <%if COST_TAX = 0 then response.write " checked"%>>��ې�
									<INPUT type=radio NAME="COST_TAX" VALUE="1" OnKeyDown="ResetEnter()" <%if COST_TAX <> 0 then response.write " checked"%>>�ې�</TD>
							</TR>
							<TR>
								<TD align=center nowrap>�a������</TD>
								<TD colspan=3><INPUT class=sj NAME="COST_NAME" MAXLENGTH=50 SIZE=40 VALUE="<%=COST_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�p������</TD>
								<TD colspan=3><INPUT class=si NAME="COST_ENAME" MAXLENGTH=50 SIZE=40 VALUE="<%=COST_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR height=30>
								<TD align=center nowrap class=pt9>�����敪</TD>
								<TD><INPUT type=radio NAME="COST_TYPE" VALUE="1" OnKeyDown="ResetEnter()" <%if COST_TYPE = 1 then response.write " checked"%>>����
									<INPUT type=radio NAME="COST_TYPE" VALUE="2" OnKeyDown="ResetEnter()" <%if COST_TYPE = 2 then response.write " checked"%>>����</TD>
								<TD align=center nowrap class=pt9>�����敪</TD>
								<TD><INPUT type=radio NAME="COST_PLUS" VALUE="0" OnKeyDown="ResetEnter()" <%if COST_PLUS = 0 then response.write " checked"%>>�_��
									<INPUT type=radio NAME="COST_PLUS" VALUE="1" OnKeyDown="ResetEnter()" <%if COST_PLUS <> 0 then response.write " checked"%>>�{��</TD>
							</TR>
							<TR height=30>
								<TD align=center nowrap class=pt9>��p����</TD>
								<TD colspan=3>
									<INPUT type=checkbox NAME="COST_ATTR1" VALUE="1" OnKeyDown="ResetEnter()" <%if mid(COST_ATTR,1,1)="1" then response.write " checked"%>>�C��
									<INPUT type=checkbox NAME="COST_ATTR2" VALUE="1" OnKeyDown="ResetEnter()" <%if mid(COST_ATTR,2,1)="1" then response.write " checked"%>>�ʊ�
									<INPUT type=checkbox NAME="COST_ATTR3" VALUE="1" OnKeyDown="ResetEnter()" <%if mid(COST_ATTR,3,1)="1" then response.write " checked"%>>�q��
									<INPUT type=checkbox NAME="COST_ATTR4" VALUE="1" OnKeyDown="ResetEnter()" <%if mid(COST_ATTR,4,1)="1" then response.write " checked"%>>�^��
									<INPUT type=checkbox NAME="COST_ATTR5" VALUE="1" OnKeyDown="ResetEnter()" <%if mid(COST_ATTR,5,1)="1" then response.write " checked"%>>�ی�
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>���l</TD>
								<TD colspan=3><textarea NAME="COST_REMARKS" style="width:250px;height:50px;"><%=COST_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT COST_ID,"
					strSQL = strSQL + "       COST_CD,"
					strSQL = strSQL + "       COST_REF,"
					strSQL = strSQL + "       COST_ENAME,"
					strSQL = strSQL + "       COST_ATTR,"
					strSQL = strSQL + "       COST_NAME,"
					strSQL = strSQL + "       COST_REMARKS"
					strSQL = strSQL + "  FROM MST_COST"
					strSQL = strSQL + " WHERE COST_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY COST_NAME;"
					Case "en"
						strSQL = strSQL + " ORDER BY COST_REF;"
					Case Else
						strSQL = strSQL + " ORDER BY COST_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=8%>No.</TD>
							<TD class=line nowrap width=10%><a class=bar href="mstCost.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=16%><a class=bar href="mstCost.asp?s=en">��������</a></TD>
							<TD class=line nowrap width=30%><a class=bar href="mstCost.asp?s=jp">�a������</a></TD>
							<TD class=line nowrap width=20%>���l</TD>
							<TD class=line nowrap width=8%>�ҏW</TD>
							<TD class=line nowrap width=8%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myJName = GetString(.Fields("COST_NAME"))
										myRemark = GetString(.Fields("COST_REMARKS"))
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("COST_CD"))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("COST_REF"))%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myJName,12)%>><%=stringCut(myJName,12)%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myRemark,8)%>><%=stringCut(myRemark,8)%><BR></TD>
						<%
							If COST_ID = GetLong(.Fields("COST_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstCost.asp?p=" & myPage & "&s=" & mySort & "&COST_ID=" & .Fields("COST_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("COST_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
