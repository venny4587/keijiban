<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim CN_CD
	dim CN_NAME
	dim CN_ENAME
	dim CN_REMARKS
	
	CN_CD = GetPost(Request("CN_CD"))
	CN_NAME = GetPost(Request("CN_NAME"))
	CN_ENAME = GetPost(Request("CN_ENAME"))
	CN_LINE = GetPost(Request("CN_LINE"))
	CN_ACTIVE = GetLong(Request("CN_ACTIVE"))
	CN_REMARKS = GetPost(Request("CN_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	if request("mode") = "False" then 
		With Recset
			strSql = "SELECT CN_CD FROM MST_COUNTRY WHERE CN_CD = '" & CN_CD & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����R�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	
	If blnEdit Then
		With Recset
			strSql = "SELECT CN_CD FROM MST_COUNTRY WHERE CN_CD <> '" & CN_CD & "' AND CN_NAME = '" & replace(CN_NAME,"'","''") & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����̘a�����̂͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then	
		With Recset
			strSql = "SELECT CN_CD FROM MST_COUNTRY WHERE CN_CD <> '" & CN_CD & "' AND CN_ENAME = '"  & replace(CN_ENAME,"'","''") &"';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����̉p�����̂͊����ł��B"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
		
		strSQL = "SELECT * FROM MST_COUNTRY WHERE CN_CD = '" & CN_CD & "'"
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("CN_CREATER") = WebUserID
				.fields("CN_CREATED") = now
				.fields("CN_DELETED") = 0
			End If
			.Fields("CN_CD") = CN_CD
			.Fields("CN_NAME") = CN_NAME
			.Fields("CN_ENAME") = CN_ENAME
			.Fields("CN_LINE") = CN_LINE
			.Fields("CN_ACTIVE") = CN_ACTIVE
			.Fields("CN_REMARKS") = CN_REMARKS	
		
			.fields("CN_UPDATER") = WebUserID
			.fields("CN_UPDATED") = now
			.Update 
			.Close 
		End With

'�V�K�ǉ��ƍ폜���Ȃ����
'		if (Request("s") = "cd" or Request("s") = "") then
'			strURL = "mstCountry.asp?p=" & GetCurrentPage(Conn, "MST_COUNTRY", "CN_CD", 1, CN_CD, " AND CN_DELETED = 0") & "&s=" & Request("s")
'		elseif (Request("s") = "en") then
'			strURL = "mstCountry.asp?p=" & GetCurrentPage(Conn, "MST_COUNTRY", "CN_ENAME", 1, CN_ENAME, " AND CN_DELETED = 0") & "&s=" & Request("s")
'		elseif (Request("s") = "jp") then
'			strURL = "mstCountry.asp?p=" & GetCurrentPage(Conn, "MST_COUNTRY", "CN_NAME", 1, CN_NAME, " AND CN_DELETED = 0") & "&s=" & Request("s")
'		end if 	
			
		strURL = "mstCountry.asp?p=" & Request("p") & "&s=" & Request("s")
		Response.redirect strURL
		
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
