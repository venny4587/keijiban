<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim CTGR_ID
dim CTGR_BASE
dim CTGR_CD
dim CTGR_NAME
dim CTGR_ENAME
dim CTGR_NUM
dim CTGR_FLAG
dim CTGR_REMARKS

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	CTGR_BASE = GetLong(Request("CTGR_BASE"))
	CTGR_ID = GetLong(Request("CTGR_ID"))
	If CTGR_ID = 0 Then
		blnEdit = False
		myTitle = "�敪�f�[�^�ǉ�"
		mySubmit = "�ǉ�"
		
		CTGR_CD = ""
		CTGR_NAME = "" 
		CTGR_ENAME = ""
		CTGR_REMARKS = ""
		CTGR_NUM = 0
		CTGR_FLAG = 0
	Else
		blnEdit = True
		myTitle = "�敪�f�[�^�ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_CATEGORY WHERE CTGR_ID = " & CTGR_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			CTGR_CD = GetString(Recset.Fields("CTGR_CD"))
			CTGR_NAME = GetString(Recset.Fields("CTGR_NAME"))
			CTGR_ENAME = GetString(Recset.Fields("CTGR_ENAME"))
			CTGR_NUM = GetDouble(Recset.Fields("CTGR_NUM"))
			CTGR_FLAG = GetLong(Recset.Fields("CTGR_FLAG"))
			CTGR_REMARKS = GetString(Recset.Fields("CTGR_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">			
			function AddNew()
				window.location.href = "mstCategory.asp?CTGR_BASE=<%=CTGR_BASE%>&p=<%=myPage%>&s=<%=mySort%>"
			End function
					
			function ConfirmDelete(myID)
				if msgbox("�Y���敪���폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstCategory0.asp?CTGR_BASE=<%=CTGR_BASE%>&CTGR_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkCode("CTGR_CD","�敪�R�[�h", 1) = false then exit sub
				if checkText("CTGR_NAME","�a������", 1) = false then exit sub
				if checkText("CTGR_ENAME","�p������", 0) = false then exit sub
				if checkDouble("CTGR_NUM","�敪���l", 0) = false then exit sub
				if checkText("CTGR_REMARKS","�敪���l", 0) = false then exit sub
				if checkLen("CTGR_REMARKS","�敪���l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then frmInput.submit() 
			End Sub
			
			sub CTGR_NUM_OnChange()
				frmInput.CTGR_NUM.value = GetDouble(frmInput.CTGR_NUM.value)
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstCategory.asp?CTGR_BASE=<%=CTGR_BASE%>&s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstCategory1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="CTGR_ID" value="<%=CTGR_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD colspan=2 class=gline>���敪�}�X�^
								<TD colspan=2 class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td colspan=3><img src=img/spacer.gif height=3>
							<TR>
								<TD class=pt9g align=center nowrap>��������</TD>
								<TD class=pt9g colspan=3><INPUT type=hidden NAME="CTGR_BASE" VALUE="<%=CTGR_BASE%>"><%=GetBaseName(CTGR_BASE)%></TD>
							</TR>
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70>�敪����</TD>
								<TD colspan=3><INPUT class=si NAME="CTGR_CD" MAXLENGTH=6 SIZE=6 VALUE="<%=CTGR_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�a������</TD>
								<TD colspan=3><INPUT class=sj NAME="CTGR_NAME" MAXLENGTH=50 SIZE=30 VALUE="<%=CTGR_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�p������</TD>
								<TD colspan=3><INPUT class=si NAME="CTGR_ENAME" MAXLENGTH=50 SIZE=40 VALUE="<%=CTGR_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�敪���l</TD>
								<TD><INPUT class=sn NAME="CTGR_NUM" MAXLENGTH=9 SIZE=10 VALUE="<%=CTGR_NUM%>" OnKeyDown="ResetEnter()"></TD>
								<TD align=center nowrap class=pt9>�g�p�׸�</TD>
								<TD><INPUT type=checkbox NAME="CTGR_FLAG" VALUE="1" OnKeyDown="ResetEnter()" <%if CTGR_FLAG then response.write " checked"%>></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�敪���l</TD>
								<TD colspan=3><textarea NAME="CTGR_REMARKS" style="width:250px;height:50px;"><%=CTGR_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
<%	if CTGR_BASE <> "" then %>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
<%	end if %>
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT CTGR_ID,"
					strSQL = strSQL + "       CTGR_CD,"
					strSQL = strSQL + "       CTGR_NAME,"
					strSQL = strSQL + "       CTGR_ENAME,"
					strSQL = strSQL + "       CTGR_FLAG,"
					strSQL = strSQL + "       CTGR_REMARKS"
					strSQL = strSQL + "  FROM MST_CATEGORY"
					strSQL = strSQL + " WHERE CTGR_DELETED = 0"
					strSQL = strSQL + " AND CTGR_BASE = '" & CTGR_BASE & "'"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY CTGR_NAME;"
					Case "en"
						strSQL = strSQL + " ORDER BY CTGR_ENAME;"
					Case Else
						strSQL = strSQL + " ORDER BY CTGR_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=6%>No.</TD>
							<TD class=line nowrap width=15%><a class=bar href="mstCategory.asp?s=cd&CTGR_BASE=<%=CTGR_BASE%>">����</a></TD>
							<TD class=line nowrap width=20%><a class=bar href="mstCategory.asp?s=jp&CTGR_BASE=<%=CTGR_BASE%>">�a������</a></TD>
							<TD class=line nowrap width=30%><a class=bar href="mstCategory.asp?s=en&CTGR_BASE=<%=CTGR_BASE%>">�p������</a></TD>
							<TD class=line nowrap width=20%>���l</TD>
							<TD class=line nowrap width=8%>�ҏW</TD>
							<TD class=line nowrap width=8%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("CTGR_NAME"))
										myEname = GetString(.Fields("CTGR_ENAME"))
										myRemarks = GetString(.Fields("CTGR_REMARKS"))
										if GetLong(.Fields("CTGR_FLAG")) then
											myColor = "black"
										else
											myColor = "gray"
										end if		
						%>
						<TR align=center style="color:<%=myColor%>">
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("CTGR_CD"))%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myName,15)%>><%=stringCut(myName,15)%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myEname,20)%>><%=stringCut(myEname,20)%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myRemarks,10)%>><%=stringCut(myRemarks,10)%><BR></TD>
						<%
							If CTGR_ID = GetLong(.Fields("CTGR_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstCategory.asp?p=" & myPage & "&s=" & mySort & "&CTGR_BASE=" & CTGR_BASE & "&CTGR_ID=" & .Fields("CTGR_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("CTGR_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>

<%

function GetBaseName(myID)
dim mySql
dim myRec
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	mySql = "SELECT BASE_NAME, BASE_ENAME FROM MST_BASE WHERE BASE_ID = '" & myID & "';"
	myRec.Open mySql, Conn, adOpenForwardOnly, adLockReadOnly 
	if not myRec.eof then
		GetBaseName = GetString(myRec.Fields("BASE_NAME"))	& " ( " & GetString(myRec.Fields("BASE_ENAME")) & " )"
	end if
	myRec.Close
	set myRec = Nothing
end function
%>
