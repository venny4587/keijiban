<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim ID
	
	ID = GetLong(Request("ID"))	
	OpenSQL Conn, SqlServerName, DatabaseName

	strSQL = "UPDATE MST_HOLIDAY SET Deleted = 1"
	strSQL = strSQL & ",Updated = GETDATE()"
	strSQL = strSQL & ",Updater = " & WebUserID
	strSQL = strSQL & " WHERE ID = " & ID
	Conn.Execute strSQL
	
	CloseDB Conn	
	Response.Redirect "mstHoliday.asp?p=" & Request("p")
%>