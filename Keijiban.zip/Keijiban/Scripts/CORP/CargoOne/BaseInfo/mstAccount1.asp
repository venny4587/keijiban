<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim ACNT_ID
	dim ACNT_CD
	dim ACNT_REF
	dim ACNT_ENAME
	dim ACNT_FINANCE
	dim ACNT_NAME
	dim ACNT_REMARKS
	
	ACNT_ID = GetLong(Request("ACNT_ID"))
	ACNT_CD = GetPost(Request("ACNT_CD"))
	ACNT_REF = GetPost(Request("ACNT_REF"))
	ACNT_ENAME = GetPost(Request("ACNT_ENAME"))
	ACNT_FINANCE = GetPost(Request("ACNT_FINANCE"))
	ACNT_NAME = GetPost(Request("ACNT_NAME"))
	ACNT_REMARKS = GetPost(Request("ACNT_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			.Open "SELECT ACNT_CD FROM MST_ACCOUNT WHERE ACNT_ID <> " & ACNT_ID & " AND ACNT_CD = '"  & replace(ACNT_CD, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y������ȖڃR�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit AND ACNT_REF <> "" Then
		With Recset
			.Open "SELECT ACNT_CD FROM MST_ACCOUNT WHERE ACNT_ID <> " & ACNT_ID & " AND ACNT_REF = '"  & replace(ACNT_REF, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y������Ȗڂ̌������̂͊����ł��B(�Y������Ȗں���:" & .Fields("ACNT_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit AND ACNT_ENAME <> "" Then	
		With Recset
			.Open "SELECT ACNT_CD FROM MST_ACCOUNT WHERE ACNT_ID <> " & ACNT_ID & " AND ACNT_ENAME = '"  & replace(ACNT_ENAME, "'", "''") &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y������Ȗڂ̉p�����̂͊����ł��B(�Y������Ȗں���:" & .Fields("ACNT_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit AND ACNT_NAME <> "" Then	
		With Recset
			.Open "SELECT ACNT_CD FROM MST_ACCOUNT WHERE ACNT_ID <> " & ACNT_ID & " AND ACNT_NAME = '"  & replace(ACNT_NAME, "'", "''") &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y������Ȗڂ̘a�����̂͊����ł��B(�Y������Ȗں���:" & .Fields("ACNT_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
	
		if ACNT_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "ACNT_ID"	
			cmdSQL.Execute
			ACNT_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
		strSQL = "SELECT * FROM MST_ACCOUNT WHERE ACNT_ID = " & ACNT_ID 
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("ACNT_ID") = ACNT_ID
				.fields("ACNT_CREATER") = WebUserID
				.fields("ACNT_CREATED") = now
				.fields("ACNT_DELETED") = 0
			End If
			.Fields("ACNT_CD") = ACNT_CD
			.Fields("ACNT_REF") = ACNT_REF
			.Fields("ACNT_ENAME") = ACNT_ENAME
			.Fields("ACNT_FINANCE") = ACNT_FINANCE
			.Fields("ACNT_NAME") = ACNT_NAME
			.Fields("ACNT_REMARKS") = ACNT_REMARKS	
		
			.fields("ACNT_UPDATER") = WebUserID
			.fields("ACNT_UPDATED") = now
			.Update 
			.Close 
		End With
		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstAccount.asp?p=" & GetCurrentPage(Conn, "MST_ACCOUNT", "ACNT_CD", 1, ACNT_CD, " AND ACNT_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstAccount.asp?p=" & GetCurrentPage(Conn, "MST_ACCOUNT", "ACNT_REF", 1, ACNT_REF, " AND ACNT_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstAccount.asp?p=" & GetCurrentPage(Conn, "MST_ACCOUNT", "ACNT_NAME", 1, ACNT_NAME, " AND ACNT_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.Redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
