<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim ACNT_ID
dim ACNT_CD
dim ACNT_REF
dim ACNT_ENAME
dim ACNT_FINANCE
dim ACNT_NAME
dim ACNT_REMARKS

dim mySubmit
dim mySort
dim myCode

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	ACNT_ID = GetLong(Request("ACNT_ID"))
	If ACNT_ID = 0 Then
		blnEdit = False
		myTitle = "����Ȗڒǉ�"
		mySubmit = "�ǉ�"
		
		ACNT_CD = "" 
		ACNT_REF = "" 
		ACNT_ENAME = ""
		ACNT_FINANCE = ""
		ACNT_NAME = ""
	Else
		blnEdit = True
		myTitle = "����ȖڕҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_ACCOUNT WHERE ACNT_ID = " & ACNT_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			ACNT_CD = GetString(Recset.Fields("ACNT_CD"))
			ACNT_REF = GetString(Recset.Fields("ACNT_REF"))
			ACNT_ENAME = GetString(Recset.Fields("ACNT_ENAME"))
			ACNT_FINANCE = GetString(Recset.Fields("ACNT_FINANCE"))
			ACNT_NAME = GetString(Recset.Fields("ACNT_NAME"))
			ACNT_REMARKS = GetString(Recset.Fields("ACNT_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstAccount.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y������Ȗڂ��폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstAccount0.asp?ACNT_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()
				if checkCode("ACNT_CD","�ȖڃR�[�h", 1) = false then exit sub
				if checkText("ACNT_REF","��������", 1) = false then exit sub
				if checkText("ACNT_FINANCE","�����R�[�h", 0) = false then exit sub
				if checkText("ACNT_NAME","�a������", 1) = false then exit sub
				if checkText("ACNT_ENAME","�p������", 0) = false then exit sub
				if checkText("ACNT_REMARKS","���l", 0) = false then exit sub
				if checkLen("ACNT_REMARKS","���l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstAccount.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstAccount1.asp" ID=frmInput NAME=frmInput>
						<input type=hidden name="ACNT_ID" value="<%=ACNT_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline colspan=2>������Ȗ�
								<TD class=gline colspan=2 align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap>�Ȗں���</TD>
								<TD><INPUT class=si NAME="ACNT_CD" MAXLENGTH=3 SIZE=3 VALUE="<%=ACNT_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>��������</TD>
								<TD><INPUT class=si NAME="ACNT_REF" MAXLENGTH=16 SIZE=12 VALUE="<%=ACNT_REF%>" OnKeyDown="ResetEnter()"></TD>
								<TD align=center nowrap class=pt9>��������</TD>
								<TD><INPUT class=si NAME="ACNT_FINANCE" MAXLENGTH=20 SIZE=12 VALUE="<%=ACNT_FINANCE%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�a������</TD>
								<TD colspan=3><INPUT class=sj NAME="ACNT_NAME" MAXLENGTH=50 SIZE=40 VALUE="<%=ACNT_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�p������</TD>
								<TD colspan=3><INPUT class=si NAME="ACNT_ENAME" MAXLENGTH=50 SIZE=40 VALUE="<%=ACNT_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>���l</TD>
								<TD colspan=3><textarea NAME="ACNT_REMARKS" style="width:250px;height:50px;"><%=ACNT_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT ACNT_ID,"
					strSQL = strSQL + "       ACNT_CD,"
					strSQL = strSQL + "       ACNT_REF,"
					strSQL = strSQL + "       ACNT_ENAME,"
					strSQL = strSQL + "       ACNT_FINANCE,"
					strSQL = strSQL + "       ACNT_NAME,"
					strSQL = strSQL + "       ACNT_REMARKS"
					strSQL = strSQL + "  FROM MST_ACCOUNT"
					strSQL = strSQL + " WHERE ACNT_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY ACNT_NAME;"
					Case "en"
						strSQL = strSQL + " ORDER BY ACNT_REF;"
					Case Else
						strSQL = strSQL + " ORDER BY ACNT_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=8%>No.</TD>
							<TD class=line nowrap width=10%><a class=bar href="mstAccount.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=16%><a class=bar href="mstAccount.asp?s=en">��������</a></TD>
							<TD class=line nowrap width=30%><a class=bar href="mstAccount.asp?s=jp">�a������</a></TD>
							<TD class=line nowrap width=20%>���l</TD>
							<TD class=line nowrap width=8%>�ҏW</TD>
							<TD class=line nowrap width=8%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myJName = GetString(.Fields("ACNT_NAME"))
										myRemark = GetString(.Fields("ACNT_REMARKS"))
						%>
						<TR align=center>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("ACNT_CD"))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("ACNT_REF"))%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myJName,12)%>><%=stringCut(myJName,12)%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myRemark,8)%>><%=stringCut(myRemark,8)%><BR></TD>
						<%
							If ACNT_ID = GetLong(.Fields("ACNT_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstAccount.asp?p=" & myPage & "&s=" & mySort & "&ACNT_ID=" & .Fields("ACNT_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("ACNT_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
