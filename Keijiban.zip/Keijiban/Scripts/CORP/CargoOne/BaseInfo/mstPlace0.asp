<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim PLC_ID
	
	blnDelete = True
	PLC_ID = GetLong(request("PLC_ID"))
	PLC_COUNTRY = GetPost(Request("PLC_COUNTRY"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT PLC_NAME FROM MST_PLACE WHERE PLC_ID = " & PLC_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y�����u�ꏊ�͂��łɎg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_PLACE SET PLC_DELETED = 1"
		strSQL = strSQL & ",PLC_UPDATED = GETDATE()"
		strSQL = strSQL & ",PLC_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE PLC_ID = " & PLC_ID
		Conn.Execute strSQL

		Response.redirect "mstPlace.asp?p=" & request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	Set Recset = Nothing
	CloseDB Conn
%>