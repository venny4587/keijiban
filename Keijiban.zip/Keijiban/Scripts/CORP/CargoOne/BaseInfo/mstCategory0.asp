<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim CTGR_ID
	
	blnDelete = True
	CTGR_ID = GetLong(request("CTGR_ID"))
	CTGR_BASE = GetLong(request("CTGR_BASE"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT CTGR_CD FROM MST_CATEGORY WHERE CTGR_ID = " & CTGR_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y���敪�͂��łɎg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_CATEGORY SET CTGR_DELETED = 1"
		strSQL = strSQL & ",CTGR_UPDATED = GETDATE()"
		strSQL = strSQL & ",CTGR_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE CTGR_ID = " & CTGR_ID
		Conn.Execute strSQL
		
		strURL = "mstCategory.asp?CTGR_BASE=" & CTGR_BASE & "&p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing

	Response.Redirect strURL
%>