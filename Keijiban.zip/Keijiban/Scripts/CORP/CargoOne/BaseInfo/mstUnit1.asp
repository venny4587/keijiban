<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim UNIT_ID
	dim UNIT_CD
	dim SINGULAR_ABR
	dim SINGULAR_NAME
	dim PLURAL_ABR
	dim PLURAL_NAME
	dim UNIT_REMARKS
	
	UNIT_ID = GetLong(Request("UNIT_ID"))
	UNIT_CD = GetPost(Request("UNIT_CD"))
	SINGULAR_ABR = GetPost(Request("SINGULAR_ABR"))
	SINGULAR_NAME = GetPost(Request("SINGULAR_NAME"))
	PLURAL_ABR = GetPost(Request("PLURAL_ABR"))
	PLURAL_NAME = GetPost(Request("PLURAL_NAME"))
	UNIT_REMARKS = GetPost(Request("UNIT_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			.Open "SELECT UNIT_CD FROM MST_UNIT WHERE UNIT_ID <> " & UNIT_ID & " AND UNIT_CD = '"  & replace(UNIT_CD, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���P�ʃR�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then
		With Recset
			.Open "SELECT UNIT_CD FROM MST_UNIT WHERE UNIT_ID <> " & UNIT_ID & " AND SINGULAR_ABR = '"  & replace(SINGULAR_ABR, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���P�ʂ̒P�����̂͊����ł��B(�Y������P�ʺ���:" & .Fields("UNIT_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then	
		With Recset
			.Open "SELECT UNIT_CD FROM MST_UNIT WHERE UNIT_ID <> " & UNIT_ID & " AND SINGULAR_NAME = '"  & replace(SINGULAR_NAME, "'", "''") &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���P�ʂ̒P�����̂͊����ł��B(�Y������P�ʺ���:" & .Fields("UNIT_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
	
		if UNIT_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "UNIT_ID"	
			cmdSQL.Execute
			UNIT_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
	
		strSQL = "SELECT * FROM MST_UNIT WHERE UNIT_ID = " & UNIT_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.Fields("UNIT_ID") = UNIT_ID
				.fields("UNIT_CREATER") = WebUserID
				.fields("UNIT_CREATED") = now
				.fields("UNIT_DELETED") = 0
			End If
			.Fields("UNIT_CD") = UNIT_CD
			.Fields("SINGULAR_ABR") = SINGULAR_ABR
			.Fields("SINGULAR_NAME") = SINGULAR_NAME
			.Fields("PLURAL_ABR") = PLURAL_ABR
			.Fields("PLURAL_NAME") = PLURAL_NAME
			.Fields("UNIT_REMARKS") = UNIT_REMARKS	
		
			.fields("UNIT_UPDATER") = WebUserID
			.fields("UNIT_UPDATED") = now
			.Update 
			.Close 
		End With
		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstUnit.asp?p=" & GetCurrentPage(Conn, "MST_UNIT", "UNIT_CD", 1, UNIT_CD, " AND UNIT_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstUnit.asp?p=" & GetCurrentPage(Conn, "MST_UNIT", "SINGULAR_NAME", 1, SINGULAR_NAME, " AND UNIT_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstUnit.asp?p=" & GetCurrentPage(Conn, "MST_UNIT", "SINGULAR_ABR", 1, SINGULAR_ABR, " AND UNIT_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.Redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
