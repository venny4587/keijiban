<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim PLC_ID
	dim PLC_CD
	dim PLC_NAME
	dim PLC_TEL
	dim PLC_FAX
	dim PLC_NACCS
	dim PLC_CSTM
	dim PLC_REMARKS
	
	PLC_ID = GetLong(Request("PLC_ID"))
	PLC_CD = GetPost(Request("PLC_CD"))
	PLC_NAME = GetPost(Request("PLC_NAME"))
	PLC_TEL = GetPost(Request("PLC_TEL"))
	PLC_FAX = GetPost(Request("PLC_FAX"))
	PLC_NACCS = GetPost(Request("PLC_NACCS"))
	PLC_CSTM = GetPost(Request("PLC_CSTM"))
	PLC_REMARKS = GetPost(Request("PLC_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			strSql = "SELECT PLC_CD FROM MST_PLACE WHERE PLC_ID <> " & PLC_ID & " AND PLC_CD = '" & PLC_CD & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�������R�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	
	If blnEdit AND PLC_NAME <> "" Then
		With Recset
			strSql = "SELECT PLC_CD FROM MST_PLACE WHERE PLC_ID <> " & PLC_ID & " AND PLC_CD <> '" & PLC_CD & "' AND PLC_NAME = '" & replace(PLC_NAME,"'", "''") & "';"
			.Open strSql, Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����u�ꏊ�͊����ł��B(�Y�����錟������:" & .Fields("PLC_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then		
	
		if PLC_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "PLC_ID"	
			cmdSQL.Execute
			PLC_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
			
		strSQL = "SELECT * FROM MST_PLACE WHERE PLC_ID = " & PLC_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("PLC_ID") = PLC_ID
				.fields("PLC_CREATER") = WebUserID
				.fields("PLC_CREATED") = now
				.fields("PLC_DELETED") = 0
			End If
			.Fields("PLC_CD") = PLC_CD
			.Fields("PLC_NAME") = PLC_NAME
			.Fields("PLC_TEL") = PLC_TEL
			.Fields("PLC_FAX") = PLC_FAX
			.Fields("PLC_NACCS") = PLC_NACCS
			.Fields("PLC_CSTM") = PLC_CSTM
			.Fields("PLC_REMARKS") = PLC_REMARKS	
		
			.fields("PLC_UPDATER") = WebUserID
			.fields("PLC_UPDATED") = now
			.Update 
			.Close 
		End With
		
		Response.redirect "mstPlace.asp?p=" & request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
