<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim PORT_ID
	
	blnDelete = True
	PORT_ID = GetLong(request("PORT_ID"))
	PORT_COUNTRY = GetPost(Request("PORT_COUNTRY"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT PORT_ENAME FROM MST_PORT WHERE PORT_ID = " & PORT_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y���`���͂��łɎg���Ă��܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_PORT SET PORT_DELETED = 1"
		strSQL = strSQL & ",PORT_UPDATED = GETDATE()"
		strSQL = strSQL & ",PORT_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE PORT_ID = " & PORT_ID
		Conn.Execute strSQL

		strURL = "mstPort.asp?PORT_COUNTRY=" & PORT_COUNTRY & "&p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>