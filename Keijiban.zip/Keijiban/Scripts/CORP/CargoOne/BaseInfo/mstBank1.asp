<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim BANK_ID
	dim BANK_CD
	dim BANK_NAME
	dim BANK_ENAME
	dim BANK_REMARKS
	
	BANK_ID = GetLong(Request("BANK_ID"))
	BANK_CD = GetPost(Request("BANK_CD"))
	BANK_NAME = GetPost(Request("BANK_NAME"))
	BANK_ENAME = GetPost(Request("BANK_ENAME"))
	BANK_FINANCE_CD = GetPost(Request("BANK_FINANCE_CD"))
	BANK_BRANCH = GetPost(Request("BANK_BRANCH"))
	BANK_BENEFICIARY = GetPost(Request("BANK_BENEFICIARY"))
	BANK_ACCOUNT_NO = GetPost(Request("BANK_ACCOUNT_NO"))
	BANK_ACCOUNT_TYPE = GetPost(Request("BANK_ACCOUNT_TYPE"))
	BANK_SPELL = GetPost(Request("BANK_SPELL"))
	BANK_DIVISION = GetLong(Request("BANK_DIVISION"))
	BANK_REMARKS = GetPost(Request("BANK_REMARKS"))
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			.Open "SELECT BANK_CD FROM MST_BANK WHERE BANK_ID <> " & BANK_ID & " AND BANK_CD = '"  & replace(BANK_CD,"'","''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����s�R�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then
		With Recset
			.Open "SELECT BANK_CD FROM MST_BANK WHERE BANK_ID <> " & BANK_ID & " AND BANK_NAME = '"  & replace(BANK_NAME,"'","''") & "' AND BANK_ACCOUNT_NO = '"  & replace(BANK_ACCOUNT_NO,"'","''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����s�͊����ł��B(�Y�������s����:" & .Fields("BANK_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit and BANK_ENAME <> "" Then	
		With Recset
			.Open "SELECT BANK_CD FROM MST_BANK WHERE BANK_ID <> " & BANK_ID & " AND BANK_ENAME = '"  & replace(BANK_ENAME,"'","''") &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y����s�̉p�����̂͊����ł��B(�Y�������s����:" & .Fields("BANK_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
	
		if BANK_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "BANK_ID"	
			cmdSQL.Execute
			BANK_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
		strSQL = "SELECT * FROM MST_BANK WHERE BANK_ID = " & BANK_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("BANK_ID") = BANK_ID
				.fields("BANK_CREATER") = WebUserID
				.fields("BANK_CREATED") = now
				.fields("BANK_DELETED") = 0
			End If
						
			.Fields("BANK_CD") = BANK_CD
			.Fields("BANK_NAME") = BANK_NAME
			.Fields("BANK_ENAME") = BANK_ENAME
			.Fields("BANK_FINANCE_CD") = BANK_FINANCE_CD
			.Fields("BANK_BRANCH") = BANK_BRANCH
			.Fields("BANK_BENEFICIARY") = BANK_BENEFICIARY
			.Fields("BANK_ACCOUNT_NO") = BANK_ACCOUNT_NO
			.Fields("BANK_ACCOUNT_TYPE") = BANK_ACCOUNT_TYPE
			.Fields("BANK_SPELL") = BANK_SPELL
			.Fields("BANK_DIVISION") = BANK_DIVISION
			.Fields("BANK_REMARKS") = BANK_REMARKS	
		
			.fields("BANK_UPDATER") = WebUserID
			.fields("BANK_UPDATED") = now
			.Update 
			.Close 
		End With
		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstBank.asp?p=" & GetCurrentPage(Conn, "MST_BANK", "BANK_CD", 1, BANK_CD, " AND BANK_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstBank.asp?p=" & GetCurrentPage(Conn, "MST_BANK", "BANK_ENAME", 1, BANK_ENAME, " AND BANK_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstBank.asp?p=" & GetCurrentPage(Conn, "MST_BANK", "BANK_NAME", 1, BANK_NAME, " AND BANK_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.Redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
