<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim MAIL_ID
	dim MAIL_CODE
	dim MAIL_TITLE
	dim MAIL_HEAD
	dim MAIL_BODY
	dim MAIL_FOOT
	dim MAIL_REMARKS
	
	MAIL_ID = GetLong(Request("MAIL_ID"))
	MAIL_CODE = GetPost(Request("MAIL_CODE"))
	MAIL_TITLE = GetPost(Request("MAIL_TITLE"))
	MAIL_HEAD = GetPost(Request("MAIL_HEAD"))
	MAIL_BODY = GetPost(Request("MAIL_BODY"))
	MAIL_FOOT = GetPost(Request("MAIL_FOOT"))
	MAIL_REMARKS = GetPost(Request("MAIL_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			.Open "SELECT MAIL_CODE FROM MST_MAIL WHERE MAIL_ID <> " & MAIL_ID & " AND MAIL_CODE = '"  & replace(MAIL_CODE, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���ʒm�R�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then
		With Recset
			.Open "SELECT MAIL_CODE FROM MST_MAIL WHERE MAIL_ID <> " & MAIL_ID & " AND MAIL_TITLE = '"  & replace(MAIL_TITLE, "'", "''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y���ʒm�̃^�C�g���͊����ł��B(�Y������ʒm����:" & .Fields("MAIL_CODE") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then	
	
		if MAIL_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "MAIL_ID"	
			cmdSQL.Execute
			MAIL_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
	
		strSQL = "SELECT * FROM MST_MAIL WHERE MAIL_ID = " & MAIL_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.Fields("MAIL_ID") = MAIL_ID
				.fields("MAIL_CREATER") = WebUserID
				.fields("MAIL_CREATED") = now
				.fields("MAIL_DELETED") = 0
			End If
			.Fields("MAIL_CODE") = MAIL_CODE
			.Fields("MAIL_TITLE") = MAIL_TITLE
			.Fields("MAIL_HEAD") = MAIL_HEAD
			.Fields("MAIL_FOOT") = MAIL_FOOT
			.Fields("MAIL_BODY") = MAIL_BODY
			.Fields("MAIL_REMARKS") = MAIL_REMARKS	
		
			.fields("MAIL_UPDATER") = WebUserID
			.fields("MAIL_UPDATED") = now
			.Update 
			.Close 
		End With
				
		Response.Redirect "mstMail.asp?p=" & GetLong(request("p")) & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
