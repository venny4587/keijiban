<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim BANK_ID
dim BANK_CD
dim BANK_FINANCE_CD
dim BANK_NAME
dim BANK_ENAME
dim BANK_BRANCH
dim BANK_BENEFICIARY
dim BANK_ACCOUNT_NO
dim BANK_ACCOUNT_TYPE
dim BANK_SPELL
dim BANK_DIVISION
dim BANK_REMARKS

dim mySubmit
dim mySort
dim myCode
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	BANK_ID = GetLong(Request("BANK_ID"))
	If BANK_ID = 0 Then
		blnEdit = False
		myTitle = "��s�����ǉ�"
		mySubmit = "�ǉ�"
		
		BANK_CD = ""
		BANK_FINANCE_CD = "" 
		BANK_NAME = "" 
		BANK_ENAME = ""
		BANK_BRANCH = "" 
		BANK_BENEFICIARY = ""
		BANK_ACCOUNT_NO = "" 
		BANK_ACCOUNT_TYPE = ""
		BANK_SPELL = "" 
		BANK_DIVISION = 1
		BANK_REMARKS = ""
	Else
		blnEdit = True
		myTitle = "��s�����ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_BANK WHERE BANK_ID = " & BANK_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			BANK_CD = GetString(Recset.Fields("BANK_CD"))
			BANK_FINANCE_CD = GetString(Recset.Fields("BANK_FINANCE_CD"))
			BANK_NAME = GetString(Recset.Fields("BANK_NAME"))
			BANK_ENAME = GetString(Recset.Fields("BANK_ENAME"))
			BANK_BRANCH = GetString(Recset.Fields("BANK_BRANCH"))
			BANK_BENEFICIARY = GetString(Recset.Fields("BANK_BENEFICIARY"))
			BANK_ACCOUNT_NO = GetString(Recset.Fields("BANK_ACCOUNT_NO"))
			BANK_ACCOUNT_TYPE = GetString(Recset.Fields("BANK_ACCOUNT_TYPE"))
			BANK_SPELL = GetString(Recset.Fields("BANK_SPELL"))
			BANK_DIVISION = GetLong(Recset.Fields("BANK_DIVISION"))
			BANK_REMARKS = GetString(Recset.Fields("BANK_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstBank.asp?p=<%=myPage%>&s=<%=mySort%>"
			End function
						
			function ConfirmDelete(myID)
				if msgbox("�Y����s�������폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstBank0.asp?BANK_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
		
			Sub DoSubmit()
				if checkCode("BANK_CD","���ڃR�[�h", 1) = false then exit sub
				if checkText("BANK_NAME","�a������", 1) = false then exit sub
				if checkText("BANK_ENAME","�p������", 0) = false then exit sub
				if checkText("BANK_FINANCE_CD","�����R�[�h", 0) = false then exit sub
				if checkText("BANK_BRANCH","�x�X��", 1) = false then exit sub
				if checkText("BANK_BENEFICIARY","�������`�l", 1) = false then exit sub
				if checkText("BANK_ACCOUNT_NO","�����ԍ�", 1) = false then exit sub
				if checkText("BANK_SPELL","�J�^�J�i", 1) = false then exit sub
				if checkText("BANK_DIVISION","��s�敪", 0) = false then exit sub
				if checkText("BANK_REMARKS","���ڔ��l", 0) = false then exit sub
				if checkLen("BANK_REMARKS","���ڔ��l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstBank.asp?s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstBank1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="BANK_ID" value="<%=BANK_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline nowrap>����s����</TD>
								<TD class=gline align=right><img src=img/spacer.gif height=3><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>				
							<TR>
								<TD align=center nowrap width=70>���ں���</TD>
								<TD><INPUT class=si NAME="BANK_CD" MAXLENGTH=3 SIZE=3 VALUE="<%=BANK_CD%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�a������</TD>
								<TD colspan=3><INPUT class=sj NAME="BANK_NAME" MAXLENGTH=50 SIZE=40 VALUE="<%=BANK_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�x�X��</TD>
								<TD colspan=3><INPUT class=sj NAME="BANK_BRANCH" MAXLENGTH=25 SIZE=25 VALUE="<%=BANK_BRANCH%>" OnKeyDown="ResetEnter()"></TD>
							<TR>
								<TD align=center nowrap>�������</TD>
								<TD><select name="BANK_ACCOUNT_TYPE" OnKeyDown="ResetEnter()">
									<option value="���ʗa��" <%if BANK_ACCOUNT_TYPE = "���ʗa��" then response.write " selected"%>>���ʗa��
									<option value="�����a��" <%if BANK_ACCOUNT_TYPE = "�����a��" then response.write " selected"%>>�����a��
									</select>
								<TD align=center nowrap>�����ԍ�</TD>
								<TD><INPUT class=si NAME="BANK_ACCOUNT_NO" MAXLENGTH=20 SIZE=10 VALUE="<%=BANK_ACCOUNT_NO%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>���`�l</TD>
								<TD colspan=3><INPUT class=sj NAME="BANK_BENEFICIARY" MAXLENGTH=50 SIZE=40 VALUE="<%=BANK_BENEFICIARY%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�J�^�J�i</TD>
								<TD colspan=3><INPUT class=sj NAME="BANK_SPELL" MAXLENGTH=25 SIZE=25 VALUE="<%=BANK_SPELL%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap width=70>��������</TD>
								<TD><INPUT class=si NAME="BANK_FINANCE_CD" MAXLENGTH=10 SIZE=10 VALUE="<%=BANK_FINANCE_CD%>" OnKeyDown="ResetEnter()"></TD>
								<TD align=center nowrap>��s�敪</TD>
								<TD><select name="BANK_DIVISION" OnKeyDown="ResetEnter()"><%
										for i = 0 to ubound(bankType)
											response.write "<option value=" & i
											if BANK_DIVISION = i then response.write " selected" 
											response.write ">" & bankType(i)
										next%></SELECT>
									</select>
							<TR>
								<TD align=center nowrap>�p������</TD>
								<TD colspan=3><INPUT class=si NAME="BANK_ENAME" MAXLENGTH=50 SIZE=40 VALUE="<%=BANK_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
	<TR>
								<TD align=center nowrap class=pt9>���ڔ��l</TD>
								<TD colspan=3><textarea NAME="BANK_REMARKS" style="width:250px;height:50px;"><%=BANK_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT BANK_ID,"
					strSQL = strSQL + "       BANK_CD,"
					strSQL = strSQL + "       BANK_NAME,"
					strSQL = strSQL + "       BANK_BRANCH,"
					strSQL = strSQL + "       BANK_DIVISION,"
					strSQL = strSQL + "       BANK_ACCOUNT_TYPE,"
					strSQL = strSQL + "       BANK_ACCOUNT_NO"
					strSQL = strSQL + "  FROM MST_BANK"
					strSQL = strSQL + " WHERE BANK_DELETED = 0"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY BANK_NAME;"
					Case "en"
						strSQL = strSQL + " ORDER BY BANK_ACCOUNT_NO;"
					Case Else
						strSQL = strSQL + " ORDER BY BANK_DIVISION, BANK_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
						<colgroup span=3 align=center>
						<colgroup span=3 align=left>
						<colgroup span=2 align=center>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER>
							<TD class=line nowrap width=8%>No.</TD>
							<TD class=line nowrap width=8%>�敪</TD>
							<TD class=line nowrap width=8%><a class=bar href="mstBank.asp?s=cd">����</a></TD>
							<TD class=line nowrap width=20%><a class=bar href="mstBank.asp?s=jp">�a������</a></TD>
							<TD class=line nowrap width=20%>�x�X��</TD>
							<TD class=line nowrap width=20%><a class=bar href="mstBank.asp?s=en">�����ԍ�</a></TD>
							<TD class=line nowrap width=8%>�ҏW</TD>
							<TD class=line nowrap width=8%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("BANK_NAME"))
										myBranch = GetString(.Fields("BANK_BRANCH"))
						%>
						<TR>
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap><%=bankType(GetLong(.Fields("BANK_DIVISION")))%><BR></TD>
							<TD class=line nowrap><%=GetString(.Fields("BANK_CD"))%><BR></TD>
							<TD class=line nowrap <%=ShowTitle(myName,10)%>><%=stringCut(myName,10)%><BR></TD>
							<TD class=line nowrap <%=ShowTitle(myBranch,10)%>><%=stringCut(myBranch,10)%><BR></TD>
							<TD class=line nowrap><%=left(.Fields("BANK_ACCOUNT_TYPE"),2)%>�@<%=GetString(.Fields("BANK_ACCOUNT_NO"))%><BR></TD>
						<%
							If BANK_ID = GetLong(.Fields("BANK_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstBank.asp?p=" & myPage & "&s=" & mySort & "&BANK_ID=" & .Fields("BANK_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("BANK_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>
