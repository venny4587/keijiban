<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	dim blnDelete
	dim BASE_ID
	
	blnDelete = True
	BASE_ID = GetLong(Request("BASE_ID"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	If blnDelete Then
		With Recset
			strsql = "SELECT CTGR_BASE FROM MST_CATEGORY WHERE CTGR_DELETED = 0 AND CTGR_BASE = " & BASE_ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				blnDelete = False
				strErrMsg = "�Y�����ڂɂ͋敪�f�[�^������܂��B"
			End If
			.Close
		End With
	End if	

	If blnDelete Then

		strSQL = "UPDATE MST_BASE SET BASE_DELETED = 1"
		strSQL = strSQL & ",BASE_UPDATED = GETDATE()"
		strSQL = strSQL & ",BASE_UPDATER = " & WebUserID
		strSQL = strSQL & " WHERE BASE_ID = " & BASE_ID
		Conn.Execute strSQL

		strURL = "mstBase.asp?p=" & Request("p") & "&s=" & Request("s")
	Else
		ShowMessage  strErrMsg
	End If
	
	CloseDB Conn
	Set Recset = Nothing
	Set Conn = Nothing
	
	Response.Redirect strURL
%>