<html>
<head>
	<title>Main Menu Bar</title>
	<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)			
		select case mySel 
		case 1
			url = "mstBase.asp"
		case 2  
			url = "mstCost.asp"
		case 3
			url = "mstAccount.asp"
		case 4
			url = "mstBank.asp"
		case 5
			url = "mstExchange.asp"	
		case 6
			url = "mstUnit.asp"
		case 7
			url = "mstHoliday.asp"
		end select
		window.parent.baseinfo.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnBase value="�敪�}�X�^" onclick="DoAct(1)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnCost value="��p�}�X�^" onclick="DoAct(2)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnAccount value="����Ȗ�" onclick="DoAct(3)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnAccount value="��s�}�X�^" onclick="DoAct(4)"></TD>
		    <TD width=140>
				<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnExchange value="�בփ}�X�^" onclick="DoAct(5)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnUnit value="�P�ʃ}�X�^" onclick="DoAct(6)"></TD>
		    <TD width=140>
		    	<INPUT type=button style="WIDTH: 120px; HEIGHT: 30px;" name=btnPort value="�Փ��}�X�^" onclick="DoAct(7)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
