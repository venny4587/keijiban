<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next

dim blnEdit
dim myPage
dim lngCount
dim lngPageCount
	
dim PORT_ID
dim PORT_CN
dim PORT_CD
dim PORT_NAME
dim PORT_ENAME
dim PORT_NACCS
dim PORT_ACTIVE
dim PORT_REMARKS

dim mySubmit
dim mySort
dim myCode

	PORT_CN = GetPost(Request("PORT_CN"))

	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	mySort = cstr(Request("s"))
	if mySort = "" then mySort = "cd"

	myPage = GetLong(request("p"))	
	if myPage = 0 then myPage = 1

	PORT_ID = GetLong(Request("PORT_ID"))
	If PORT_ID = 0 Then
		blnEdit = False
		myTitle = "�`���f�[�^�ǉ�"
		mySubmit = "�ǉ�"
		
		PORT_CD = ""
		PORT_NAME = "" 
		PORT_ENAME = ""
		PORT_NACCS = ""
		PORT_ACTIVE = 0
		PORT_REMARKS = ""
	Else
		blnEdit = True
		myTitle = "�`���f�[�^�ҏW"
		mySubmit = "�ۑ�"

		strSQL = "SELECT * FROM MST_PORT WHERE PORT_ID = " & PORT_ID
		Recset.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if not Recset.eof then
			PORT_CD = GetString(Recset.Fields("PORT_CD"))
			PORT_NAME = GetString(Recset.Fields("PORT_NAME"))
			PORT_ENAME = GetString(Recset.Fields("PORT_ENAME"))
			PORT_NACCS = GetString(Recset.Fields("PORT_NACCS"))
			PORT_ACTIVE = GetLong(Recset.Fields("PORT_ACTIVE"))
			PORT_REMARKS = GetString(Recset.Fields("PORT_REMARKS"))
		end if
		Recset.Close
	End If

%>
<HTML>
	<HEAD>
		<TITLE><%=myTitle%></TITLE>
		<META http-equiv=Content-Type content="text/html; charset=<%=gsCharSet%>">
		<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
		<SCRIPT language="vbscript" src="../common/css/function.vbs"></SCRIPT> 
	</HEAD>
	<BODY  LINK=0 ALINK=0 VLINK=0>
		<SCRIPT LANGUAGE="VBScript">				
			function AddNew()
				window.location.href = "mstPort.asp?PORT_CN=<%=PORT_CN%>&p=<%=myPage%>&s=<%=mySort%>"
			End function
					
			function ConfirmDelete(myID)
				if msgbox("�Y���`�����폜���Ă�낵���ł����H", 289, "�m�F���b�Z�[�W") = 1 then
					window.location.href = "mstPort0.asp?PORT_CN=<%=PORT_CN%>&PORT_ID=" & myID & "&p=<%=myPage%>&s=<%=mySort%>"
				End If
			End function
			
			Sub DoSubmit()				
				if checkCode("PORT_CD","�`���R�[�h", 1) = false then exit sub
				if checkText("PORT_ENAME","�p������", 1) = false then exit sub
				if checkText("PORT_NAME","�a������", 0) = false then exit sub
				if checkText("PORT_NACCS","NACCS�R�[�h", 0) = false then exit sub
				if checkText("PORT_REMARKS","�`�����l", 0) = false then exit sub
				if checkLen("PORT_REMARKS","�`�����l",250) = false then exit sub
				if msgbox("�����<%=mySubmit%>���Ă�낵���ł���?", 289, "�m�F���b�Z�[�W") = 1 then	frmInput.submit() 
			End Sub
			
			sub PORT_CD_OnChange()
				frmInput.PORT_CD.value = ucase(frmInput.PORT_CD.value)
			end sub
			
			sub PORT_NAME_OnChange()
				frmInput.PORT_NAME.value = ucase(frmInput.PORT_NAME.value)
			end sub
			
			sub PORT_NACCS_OnChange()
				frmInput.PORT_NACCS.value = ucase(frmInput.PORT_NACCS.value)
			end sub
			
			sub btnTurnPage_OnClick()
				doTurnPage(selPage.value)
			end sub
			
			sub doTurnPage(myPage)
				window.location.href = "mstPort.asp?PORT_CN=<%=PORT_CN%>&s=<%=mySort%>&p=" & myPage
			end sub
		</SCRIPT>
		<TABLE width=100%>
			<TR>
				<!----------left---------->
				<TD width=40% ALIGN=center VALIGN=TOP>
					<FORM METHOD="POST" ACTION="mstPort1.asp" ID=frmInput NAME=frmInput>
						<INPUT type=hidden name="PORT_ID" value="<%=PORT_ID%>">
						<TABLE BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
							<TR><TD class=gline colspan=2>���`���}�X�^
								<TD class=gline align=right><img src=img/new.gif onmousedown="AddNew()" style="cursor:hand" alt="�V�K�ǉ�">
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD class=pt9g align=center nowrap>������</TD>
								<TD class=pt9g colspan=2><INPUT type=hidden NAME="PORT_CN" VALUE="<%=PORT_CN%>"><%=GetCountry(PORT_CN)%></TD>
							</TR>
							<TR><td><img src=img/spacer.gif height=3>
							<TR>
								<TD align=center nowrap width=70>�`������</TD>
								<TD><INPUT class=si NAME="PORT_CD" MAXLENGTH=5 SIZE=5 VALUE="<%=PORT_CD%>" OnKeyDown="ResetEnter()" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap>�p������</TD>
								<TD colspan=2><INPUT class=si NAME="PORT_ENAME" MAXLENGTH=50 SIZE=36 VALUE="<%=PORT_ENAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>�a������</TD>
								<TD colspan=2><INPUT class=sj NAME="PORT_NAME" MAXLENGTH=50 SIZE=36 VALUE="<%=PORT_NAME%>" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD align=center nowrap class=pt9>NACCS����</TD>
								<TD><INPUT class=si NAME="PORT_NACCS" MAXLENGTH=5 SIZE=5 VALUE="<%=PORT_NACCS%>" OnKeyDown="ResetEnter()" OnKeyDown="ResetEnter()"></TD>
								<TD align=center nowrap class=pt9>�Ɩ��Ώ�<INPUT type=checkbox NAME="PORT_ACTIVE" VALUE="1" OnKeyDown="ResetEnter()" <%if PORT_ACTIVE then response.write " checked"%>></TD>
							<TR>
								<TD align=center nowrap class=pt9>�`�����l</TD>
								<TD colspan=2><textarea NAME="PORT_REMARKS" style="width:250px;height:50px;"><%=PORT_REMARKS%></textarea></TD>
							</TR>
						</TABLE>
						<BR>
<%	if PORT_CN <> "" then %>
						<INPUT style="width:100px;height:30px" TYPE=BUTTON name=btnSubmit VALUE="<%=mySubmit%>" OnClick="DoSubmit()">
						<INPUT style="width:100px;height:30px" TYPE=RESET name=btnReset VALUE="Reset">
<%	end if %>
						<BR>
						<INPUT type=hidden name="p" value='<%=myPage%>'>
						<INPUT type=hidden name="s" value='<%=mySort%>'>
					</FORM>
				</TD>
						
				<!----------right---------->
				<TD width=60% VALIGN=TOP align=center>
					<%
					strSQL = ""
					strSQL = strSQL + "SELECT PORT_ID,"
					strSQL = strSQL + "       PORT_CD,"
					strSQL = strSQL + "       PORT_NAME,"
					strSQL = strSQL + "       PORT_ENAME,"
					strSQL = strSQL + "       PORT_NACCS,"
					strSQL = strSQL + "       PORT_ACTIVE,"
					strSQL = strSQL + "       PORT_REMARKS"
					strSQL = strSQL + "  FROM MST_PORT"
					strSQL = strSQL + " WHERE PORT_DELETED = 0"
					strSQL = strSQL + " AND PORT_CN = '" & PORT_CN & "'"
					Select Case mySort
					Case "jp"
						strSQL = strSQL + " ORDER BY PORT_NAME;"
					Case "en"
						strSQL = strSQL + " ORDER BY PORT_ENAME;"
					Case Else
						strSQL = strSQL + " ORDER BY PORT_ACTIVE DESC, PORT_CD;"
					End Select
					Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					
					if not recset.EOF then
					%>
					<TABLE width=96% BORDER=0 CELLPADDING=2 CELLSPACING=0 class=pt9n>
					<%
						With Recset
							.PageSize = lngPageSize
							lngPageCount = .PageCount 
							if myPage > lngPageCount then 
								myPage = lngPageCount 
							end if
					%>
						<tr>
							<td colspan=9>
								<table width=100% class=pt9n>
									<tr>
										<td>�߰��: <%=myPage%>&nbsp;/&nbsp;<%=lngPageCount%></td>
										<td align=right nowrap>
										<%if myPage <> 1 then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage - 1%>)">�O�߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if myPage <> lngPageCount then%>
											<A class=bar HREF="#" onclick="doTurnPage(<%=myPage + 1%>)">���߰��</A>
										<%end if%>
											&nbsp;&nbsp;&nbsp;&nbsp;
										<%if lngPageCount > 1 then %>
											<select name=selPage>
											<%For lngCount = 1 To lngPageCount%>
												<option value='<%=lngCount%>' <%if lngCount=myPage then%> selected <%end if%>><%=lngCount%></option>				
											<%next%>
											</select>
											<input type=button name="btnTurnPage" style="width:30px;height:20px" value="Go">
										<%end if%>
										</td>
									</TR>
								</table>
							</td>
						</tr>
					<%
						end with
					%>
						<TR ALIGN=CENTER height=22>
							<TD class=line nowrap width=8%>No.</TD>
							<TD class=line nowrap width=15%><a class=bar href="mstPort.asp?s=cd&PORT_CN=<%=PORT_CN%>">����</a></TD>
							<TD class=line nowrap width=30%><a class=bar href="mstPort.asp?s=en&PORT_CN=<%=PORT_CN%>">�p������</a></TD>
							<TD class=line nowrap width=20%><a class=bar href="mstPort.asp?s=jp&PORT_CN=<%=PORT_CN%>">�a������</a></TD>
							<TD class=line nowrap width=15%>NACCS</TD>
							<TD class=line nowrap width=6%>�ҏW</TD>
							<TD class=line nowrap width=6%>�폜</TD>
						</TR>
						<%
						With Recset
							If Not Recset.EOF Then
								.AbsolutePage = myPage
								lngCount = (myPage - 1) * lngPageSize
								Do Until .EOF
									lngCount = lngCount + 1
									If lngCount > myPage * lngPageSize Then
										Exit Do
									else
										myName = GetString(.Fields("PORT_NAME"))
										myEname = GetString(.Fields("PORT_ENAME"))
										myRemarks = GetString(.Fields("PORT_REMARKS"))
										if GetLong(.Fields("PORT_ACTIVE")) then
											myColor = "black"
										else
											myColor = "gray"
										end if		
						%>
						<TR align=center height=22 style="color:<%=myColor%>">
							<TD class=line nowrap><%=lngCount%><BR></TD>
							<TD class=line nowrap align=center><%=GetString(.Fields("PORT_CD"))%><BR></TD>
							<TD class=line nowrap align=left <%=ShowTitle(myEname,24)%>><%=stringCut(myEname,24)%><BR></TD>
							<TD class=line nowrap align=center <%=ShowTitle(myName,15)%>><%=stringCut(myName,15)%><BR></TD>
							<TD class=line nowrap align=center><%=GetString(.Fields("PORT_NACCS"))%><BR></TD>
						<%
							If PORT_ID = GetLong(.Fields("PORT_ID")) Then
								Response.Write "<TD class=line nowrap>...</TD>"
							Else
								Response.Write "<TD class=line nowrap><A HREF=""mstPort.asp?p=" & myPage & "&s=" & mySort & "&PORT_CN=" & PORT_CN & "&PORT_ID=" & .Fields("PORT_ID") & """><IMG SRC='img/open.gif' ALT='�ҏW' STYLE='cursor:hand' BORDER=0></A></TD>"
							End If
						%>
							<TD class=line nowrap><IMG SRC='img/waste.gif' ALT='�폜' STYLE='cursor:hand' OnClick="ConfirmDelete('<%=.Fields("PORT_ID")%>')"></TD>
						</TR>
						<%
										.MoveNext
									end if 
								Loop
							End If
							.Close 
						End With	
					else
						Response.Write "<br><div align=center>�Y���f�[�^��������܂���ł����B</div>"	
					end if
					%>
					</TABLE>
				</TD>
			</TR>
		</TABLE>
	</BODY>
</HTML>
<%
Set Recset = Nothing
CloseDB Conn
%>

<%

function GetCountry(myCD)
dim mySql
dim myRec
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	mySql = "SELECT CN_NAME, CN_ENAME FROM MST_COUNTRY WHERE CN_CD = '" & myCD & "';"
	myRec.Open mySql, Conn, adOpenForwardOnly, adLockReadOnly 
	if not myRec.eof then
		GetCountry = GetString(myRec.Fields("CN_NAME"))	& " ( " & GetString(myRec.Fields("CN_ENAME")) & " )"
	end if
	myRec.Close
	set myRec = Nothing
end function
%>
