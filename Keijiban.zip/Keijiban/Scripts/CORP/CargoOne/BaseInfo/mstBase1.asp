<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
	
	dim strURL
	dim strErrMsg
	
	dim BASE_ID
	dim BASE_CD
	dim BASE_NAME
	dim BASE_ENAME
	dim BASE_REMARKS
	
	BASE_ID = GetLong(Request("BASE_ID"))
	BASE_CD = GetPost(Request("BASE_CD"))
	BASE_NAME = GetPost(Request("BASE_NAME"))
	BASE_ENAME = GetPost(Request("BASE_ENAME"))
	BASE_REMARKS = GetPost(Request("BASE_REMARKS"))
	
	OpenSQL Conn, SqlServerName, DatabaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	blnEdit = true
	If blnEdit Then
		With Recset
			.Open "SELECT BASE_CD FROM MST_BASE WHERE BASE_ID <> " & BASE_ID & " AND BASE_CD = '"  & replace(BASE_CD,"'","''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����ڃR�[�h�͊����ł��B"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then
		With Recset
			.Open "SELECT BASE_CD FROM MST_BASE WHERE BASE_ID <> " & BASE_ID & " AND BASE_NAME = '"  & replace(BASE_NAME,"'","''") & "';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����ڂ̘a�����̂͊����ł��B(�Y�����鍀�ں���:" & .Fields("BASE_CD") & ")"
			End If
			.Close 
		End With 
	End If
	If blnEdit Then	
		With Recset
			.Open "SELECT BASE_CD FROM MST_BASE WHERE BASE_ID <> " & BASE_ID & " AND BASE_ENAME = '"  & replace(BASE_ENAME,"'","''") &"';", Conn, adOpenForwardOnly, adLockReadOnly
			If not .EOF Then
				blnEdit = False
				strErrMsg = "�Y�����ڂ̉p�����̂͊����ł��B(�Y�����鍀�ں���:" & .Fields("BASE_CD") & ")"
			End If
			.Close 
		End With
	End If
	If blnEdit Then	
	
		if BASE_ID = 0 then	
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_NEW_KEY"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@SysKey").Value = "BASE_ID"	
			cmdSQL.Execute
			BASE_ID = GetLong(cmdSQL.Parameters("@MaxID").Value)
		end if
	
		strSQL = "SELECT * FROM MST_BASE WHERE BASE_ID = " & BASE_ID
		Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		With RecSet
			If .EOF Then
				.AddNew
				.fields("BASE_ID") = BASE_ID
				.fields("BASE_CREATER") = WebUserID
				.fields("BASE_CREATED") = now
				.fields("BASE_DELETED") = 0
			End If
			.Fields("BASE_CD") = BASE_CD
			.Fields("BASE_NAME") = BASE_NAME
			.Fields("BASE_ENAME") = BASE_ENAME
			.Fields("BASE_REMARKS") = BASE_REMARKS	
		
			.fields("BASE_UPDATER") = WebUserID
			.fields("BASE_UPDATED") = now
			.Update 
			.Close 
		End With
		if (Request("s") = "cd" or Request("s") = "") then
			strURL = "mstBase.asp?p=" & GetCurrentPage(Conn, "MST_BASE", "BASE_CD", 1, BASE_CD, " AND BASE_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "en") then
			strURL = "mstBase.asp?p=" & GetCurrentPage(Conn, "MST_BASE", "BASE_ENAME", 1, BASE_ENAME, " AND BASE_DELETED = 0") & "&s=" & Request("s")
		elseif (Request("s") = "jp") then
			strURL = "mstBase.asp?p=" & GetCurrentPage(Conn, "MST_BASE", "BASE_NAME", 1, BASE_NAME, " AND BASE_DELETED = 0") & "&s=" & Request("s")
		end if 
		Response.Redirect strURL
	Else
		ShowMessage  strErrMsg
	End If
	
	Set RecSet = Nothing
	closeDB Conn
%>
