var req;

function loadXMLDoc(url) 
{
	// branch for native XMLHttpRequest object
	if (window.XMLHttpRequest) 
	{
		req = new XMLHttpRequest();
		req.onreadystatechange = processReqChange;
		req.open("GET", url, true);
		req.send(null);
		
	// branch for IE/Windows ActiveX version
	}
	else if (window.ActiveXObject) 
	{
		req = new ActiveXObject("Microsoft.XMLHTTP");
		if (req) {		
			req.onreadystatechange = processReqChange;
			req.open("GET", url, true);
			req.send();
		}
	}
	
	//alert(req.responseXML.xml);
}

function processReqChange()
{
	// only if req shows "complete"
	if (req.readyState == 4) 
	{
		// only if "OK"
		if (req.status == 200) 
		{
			// ...processing statements go here...
			var response = req.responseXML.documentElement;
			var objNameList = response.getElementsByTagName('objname');
			var objValueList = response.getElementsByTagName('objvalue');
			
			//alert(req.responseXML.xml);			
			for (var i=0; i<objNameList.length; i++) {
				var objName = objNameList.item(i).firstChild.data;
				if (objValueList.item(i).firstChild !=null) 
				{
					var objValue = objValueList.item(i).firstChild.data;
					//alert(objName + ":" + objValue);
					eval("frmInput." + objName + ".value = objValue;");
				}
			}
		}
		else 
		{
			alert("XML ERROR!:\n" + req.statusText);
		}
	}
}
