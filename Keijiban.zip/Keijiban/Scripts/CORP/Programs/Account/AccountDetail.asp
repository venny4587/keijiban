<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�a������Ԑ��ډ�ʁi�a����ꗗ�Ɖ��ʂ���j
'----------------------------------------------

'on error resume next	

	AccountBelong = GetPost(request("AccountBelong"))
	if AccountBelong = "" then AccountBelong = "O"
%>
<HTML>
<HEAD>
	<TITLE>�a����c�蕪�ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n <%=gsBodyControl%>>
  <center>
	<!----------��������--------->
	<FORM METHOD="POST" ACTION="AccountDeposit.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<TABLE width=760 class=pt9>
			<TR><TD nowrap><font class=pt9g>�a����c�蕪</font>&nbsp;�i<%=formatDate(date)%>���݁j
				<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</TABLE>
	</FORM>		
	<!----------��������--------->
<div id=list>
<font class=pt12n>�Ώی��x�F<%=ShowJpnYear(year(date))%><%=GetJapanNo(month(date))%>��</font><br><br>
<%			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	with recset
		strSql = "SELECT FIN_NO, FIN_BELONG, FIN_DATE, FIN_CLIENT_NAME, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_DESCRIPTION FROM TBL_CTM_FIN "
		strSql = strSql & " WHERE FIN_DELETED = 0 AND (FIN_DEBIT =" & acntOverReceive & " OR FIN_CREDIT = " & acntOverReceive & ")"
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_CURRENT = 0"
		strSql = strSql & " ORDER BY FIN_DATE, FIN_CLIENT_NAME"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .EOF then
			response.write "<TR><TD colspan=6><font class=pt9r>�Y������f�[�^�͌�����܂���ł����B</font>"
		else
%>
		<TABLE width=760 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup align=left>
			<colgroup span=3 align=right>
			<colgroup align=left>
			<TR class=pt9>
				<TD class=line width=4%>��				
				<TD class=line width=15% nowrap>���t
				<TD class=line width=10% nowrap>�`�[�ԍ�
				<TD class=line width=10% nowrap>�a�����
				<TD class=line width=10% nowrap>�a�������
				<TD class=line width=12% nowrap>�c��
				<TD class=line width=30% nowrap>�����
<%
			cnt = 0
			myBalance = 0
			do while not .EOF
				cnt = cnt + 1
				myNo = GetString(.Fields("FIN_NO"))
				myDate = GetString(.Fields("FIN_DATE"))
				myName = GetString(.fields("FIN_CLIENT_NAME"))
				myDebit = 0:	myCredit = 0
				if GetLong(.fields("FIN_CREDIT")) = acntOverReceive then
					myDebit = GetLong(.Fields("FIN_AMOUNT"))	
					myBalance = myBalance + myDebit
				elseif GetLong(.fields("FIN_DEBIT")) = acntOverReceive then
					myCredit = GetLong(.Fields("FIN_AMOUNT"))	
					myBalance = myBalance - myCredit
				end if
				myColor = ""
				if myDate > Date2Str(date) then myColor = " style=""color:gray"""
%>
			<TR <%=myColor%>>
				<TD class=line align=center><%=cnt%>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line <%=ShowTitle(myNo, 10)%>><%=StringCut(myNo, 10)%>
				<TD class=line><%=formatnumber(myDebit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myCredit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
				<TD class=line><%=ResetCorpName(myName)%>
<%	
				.movenext
			loop
			.Close
%>			
		</TABLE>
<%
		end if
	end with
	
	set Recset = nothing
	CloseDB Conn		
%>		
</div>
  </center>
</BODY></HTML>
