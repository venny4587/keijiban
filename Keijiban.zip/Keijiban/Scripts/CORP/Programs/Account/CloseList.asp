<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����c���ڍ׏���ʁi����������ʂ���j
'----------------------------------------------

'on error resume next
dim mode
dim AccountBelong
dim AccountMonth
dim AccountFrom
dim AccountTo
	
	AccountBelong = GetPost(request("AccountBelong"))			'�q�ɂ̏ꍇ�͎x�X�ʕK�v
	if AccountBelong = "" then AccountBelong = "O"
	
	'���R���ȊO�̏ꍇ�Ή�
	AccountMonth = GetPost(request("AccountMonth"))
	SelYear = GetLong(left(AccountMonth, 4))
	SelMonth = GetLong(right(AccountMonth, 2))
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
			
	mode = GetLong(request("mode"))
	select case mode
	case 1				'���|�c��
		myTitle = "���|�c��"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F"
		strSql = strSql & " ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizSales & " AND ISNULL(FIN_DATE, '9') > '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_MONTH BETWEEN '2000' AND '" & AccountMonth & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 2				'����R�c��
		myTitle = "����R�c��"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F"
		strSql = strSql & " ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandR & " AND ISNULL(FIN_DATE, '9') > '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_MONTH BETWEEN '2000' AND '" & AccountMonth & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 3				'�x���c��
		myTitle = "�x���c��"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F"
		strSql = strSql & " ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizCosts & " AND ISNULL(FIN_DATE, '9') > '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_MONTH BETWEEN '2000' AND '" & AccountMonth & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 4				'����P�c��
		myTitle = "����P�c��"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F"
		strSql = strSql & " ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandP & " AND ISNULL(FIN_DATE, '9') > '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_MONTH BETWEEN '2000' AND '" & AccountMonth & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 5				'�a���c��
		myTitle = "�a����c��"
		strSql = "SELECT FIN_NO AS no, FIN_DATE AS dt, CASE WHEN BookCredit = " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0-FIN_AMOUNT END AS amnt,"
		strSql = strSql & ", FIN_DATE FIN_CLIENT_NAME AS name, FIN_DESCRIPTION AS memo, FIN_CURRENT AS chk FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
		strSql = strSql & " AND (BookCredit = " & acntOverReceive & " OR BookDebit = " & acntOverReceive & ")"
		strSql = strSql & " AND FIN_DATE BETWEEN '2000' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	end select
if WebUserID = gsAdmin then response.write strSql
%>
<HTML>
<HEAD>
	<TITLE>�����ߊ���Ȗږ��׏Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY class=pt9n <%=gsBodyControl%>>
	<table class=pt9n>
		<TR><TD nowrap>				
			��v���x&nbsp;<%=SelYear%>&nbsp;�N&nbsp;<%=SelMonth%>&nbsp;��&nbsp;<%=myTitle%>���׈ꗗ&nbsp;
			<TD nowrap>	
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����" onclick="window.close()">					
	</table><br>
	<center>
<%
	with Recset
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then
%>
<div id=list>
	<table class=pt9n>
		<colgroup span=3 align=center>
		<colgroup align=left>
		<colgroup align=right>
		<colgroup align=center span=2>
		<TR class=pt9>
			<TD class=line width=30>��
			<TD class=line width=100>���t
			<TD class=line width=90>�ԍ�
			<TD class=line width=180>����
			<TD class=line width=100>���z
			<TD class=line width=180>����
			<TD class=line width=90>����
<%
			cnt = 0
			sum = 0
			do while not .eof
				cnt = cnt + 1
				sum = sum + GetLong(.fields("amnt"))
				
				myDate = GetString(.fields("dt"))
				myName = ResetCorpName(.fields("name"))
				myMemo = GetString(.fields("memo"))
				
				myColor = ""
				if GetString(.fields("chk")) = "" then 
					myColor = " style=""color:red"""
				elseif GetString(.fields("FIN_DATE")) > AccountTo then
					myColor = " style=""color:gray"""
				end if
%>
		<TR <%=myColor%>>
			<TD class=line><%=cnt%>
			<TD class=line nowrap><%=Str2YMD(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
			<TD class=line nowrap><%=GetString(.fields("no"))%>
			<TD class=line nowrap <%=ShowTitle(myName, 20)%>><%=StringCut(myName, 20)%>
			<TD class=line nowrap><%=formatnumber(GetLong(.fields("amnt")), 0, true)%>
			<TD class=line nowrap <%=ShowTitle(myMemo, 20)%>><%=StringCut(myMemo, 20)%><BR>
			<TD class=line nowrap><%=GetString(.fields("chk"))%>�@<%=Str2Date(.fields("FIN_DATE"))%>
<%
				.MoveNext
			loop
			if cnt > 1 then
%>
		<TR>
			<TD class=pt9 colspan=4 align=right>���v���z
			<TD class=line><%=formatnumber(sum, 0, true)%><BR>
<%
			end if
			
			
			
	select case mode
	case 1				'�P�[�c��
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F ON B.BIZ_FIN_NO = F.FIN_NO"
		strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizSales & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND (BIZ_MONTH = '' OR BIZ_MONTH > '" & AccountMonth & "')"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 2				'���ڎc��
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F ON B.BIZ_FIN_NO = F.FIN_NO"
		strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandR & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND (BIZ_MONTH = '' OR BIZ_MONTH > '" & AccountMonth & "')"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 3				'�����c��
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F ON B.BIZ_FIN_NO = F.FIN_NO"
		strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizCosts & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND (BIZ_MONTH = '' OR BIZ_MONTH > '" & AccountMonth & "')"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 4				'�c�b�c��
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT+BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, FIN_NO AS chk, FIN_DATE"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B LEFT JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL <> 0) AS F ON B.BIZ_FIN_NO = F.FIN_NO"
		strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandP & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND (BIZ_MONTH = '' OR BIZ_MONTH > '" & AccountMonth & "')"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	end select
		
		if mode <> 5 then
			.close
			cnt = 0
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			do while not .eof
				cnt = cnt + 1
				sum = sum - GetLong(.fields("amnt"))
				
				myDate = GetString(.fields("dt"))
				myName = ResetCorpName(.fields("name"))
				myMemo = GetString(.fields("memo"))
%>
		<TR style="color:maroon">
			<TD class=line><%=cnt%>
			<TD class=line nowrap><%=Str2YMD(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
			<TD class=line nowrap><%=GetString(.fields("no"))%>
			<TD class=line nowrap <%=ShowTitle(myName, 20)%>><%=StringCut(myName, 20)%>
			<TD class=line nowrap><%=formatnumber(0 - GetLong(.fields("amnt")), 0, true)%>
			<TD class=line nowrap <%=ShowTitle(myMemo, 20)%>><%=StringCut(myMemo, 20)%><BR>
			<TD class=line nowrap><%=GetString(.fields("chk"))%>�@<%=Str2Date(.fields("FIN_DATE"))%>
<%
				.MoveNext
			loop
			if cnt > 0 then
%>
		<TR>
			<TD class=pt9 colspan=4 align=right>���v���z
			<TD class=line><%=formatnumber(sum, 0, true)%><BR>
<%
			end if
		end if
%>
	</table>
</div>
<%
		else
			response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
		end if
		.Close
	end with
%>
	<br>
	</center>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>