
<html>
<head>
	<title>�����������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		btnCheck.style.color = "black"
		btnClose.style.color = "black"
		btnBank.style.color = "black"
		btnSales.style.color = "black"
		btnShift.style.color = "black"
		btnMonthly.style.color = "black"
		'btnBalance.style.color = "black"
		select case mySel
		case 1
			url = "CloseCheck.asp"
			btnCheck.style.color = "red"
		case 2
			url = "CloseView.asp"
			btnClose.style.color = "red"
		case 3
			url = "CloseBank.asp"
			btnBank.style.color = "red"
		case 4
			url = "CloseSales.asp"
			btnSales.style.color = "red"
		case 5
			url = "CloseShift.asp"
			btnShift.style.color = "red"
		case 6
			url = "CloseMonthly.asp"
			btnMonthly.style.color = "red"
		case 7
			url = "CloseBalance.asp"
			btnBalance.style.color = "red"
		case else
			url = "../common/blank.htm"	
		end select
		window.parent.abody.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnCheck value="�����d��΍�" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnBank value="���������c��" onclick="DoAct(3)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnClose value="�������s����" onclick="DoAct(2)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnSales value="�q�ʎc���Ɖ�" onclick="DoAct(4)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnShift value="�q�ʎc������" onclick="DoAct(5)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnMonthly value="���ʐ��ڕ\" onclick="DoAct(6)"></TD>
<!--
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 35px;" name=btnBalance value="�q�ʎc������" onclick="DoAct(7)"></TD>
-->
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
