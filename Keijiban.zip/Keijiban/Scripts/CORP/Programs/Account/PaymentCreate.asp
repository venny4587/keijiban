<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����o���`�[�쐬��ʁi�o���������j���[�j
'----------------------------------------------

'on error resume next
dim FinStr
dim myMode
dim PageSize
dim lngPageNumber
			
	PageSize = GetUserPageSize(10)
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		mySort = 4
		'DateFrom = GetInitDate()
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		BillNo = GetPost(request("BillNo"))
		CostsNo = GetPost(request("CostsNo"))
		JobCode = GetPost(request("JobCode"))
		AmountFrom = GetPost(request("AmountFrom"))
		AmountTo = GetPost(request("AmountTo"))
		
		if AmountFrom <> "" then AmountFrom = GetLong(AmountFrom)
		if AmountTo <> "" then AmountTo = GetLong(AmountTo)
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�o���`�[�쐬����</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowList(mode) 
		dim win
			set win = window.open("ClientSearch.asp?mode=1&cd=" & frmInput.ClientRef.value,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		function DoPayment(myNo)
		dim win
			set win = window.open("PaymentErase0.asp?FIN_BILLNO=" & myNo,"PaymentErase","resizable=1,scrollbars=1,width=960,height=600")
			win.focus()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub AmountFrom_OnBlur()
		dim buf
			buf = GetString(frmInput.AmountFrom.value)
			if buf <> "" then frmInput.AmountFrom.value = GetLong(buf)
		end sub
		sub AmountTo_OnBlur()
			buf = GetString(frmInput.AmountTo.value)
			if buf <> "" then frmInput.AmountTo.value = GetLong(buf)
		end sub
		sub CostsNo_OnBlur()
			frmInput.CostsNo.value = FitCostsNo(frmInput.CostsNo.value)
		end sub
		sub JobCode_OnBlur()
			frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
			window.parent.parent.result.location.href = "PaymentResult.asp?type=0"
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="PaymentCreate.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt9>
			<TR><TD nowrap>
				�x����<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				�x����&nbsp;<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				�x���ԍ�<input class=si name="CostsNo" value="<%=CostsNo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				<TD rowspan=2 width=100 align=right>
					<INPUT class=pt9n style="width:70px;height:30px;" TYPE=SUBMIT VALUE="����">					
			<TR><TD nowrap>
				���臂&nbsp;<input class=si name="BillNo" value="<%=BillNo%>" maxlength=12 size=10 onkeydown="ResetEnter()">
				�x�����z&nbsp;<input class=sn name="AmountFrom" value="<%=AmountFrom%>" maxlength=10 size=10 onkeydown="ResetEnter()">
					�`<input class=sn name="AmountTo" value="<%=AmountTo%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�䒠�ԍ�<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
		</table>
		
	<!----------��������--------->
<%
	strSel = ""
	if myMode = 0 then	strSel = strSel & " AND CostsPayDay = '" & Date2Str(date) & "'"
	if ClientRef <> "" then	strSel = strSel & " AND ClientRef = '" & FitSel(ClientRef) & "'"
	if DateFrom <> "" then strSel = strSel & " AND CostsPayDay >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND CostsPayDay <= '" & Date2Str(DateTo) & "'"
	if BillNo <> "" then strSel = strSel & " AND CostsBillNo LIKE '%" & FitSel(BillNo) & "%'"
	if CostsNo <> "" then strSel = strSel & " AND CostsNo = '" & FitSel(CostsNo) & "'"
	if JobCode <> "" then strSel = strSel & " AND JobCode = '" & FitSel(JobCode) & "'"
	if AmountFrom <> "" then strSel = strSel & " AND (CostsAmount+CostsTax) >= " & AmountFrom
	if AmountTo <> "" then strSel = strSel & " AND (CostsAmount+CostsTax) <= " & AmountTo
		
	myBatchCnt = 0
	myCostsCnt = 0
	with recset

		myTotalAmount = 0	
		strSql = "SELECT SUM(CostsAmount + CostsTax) AS TotalAmount FROM TBL_CTM_COSTS AS T"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0 AND CostsType = 0 AND CostsBatch = ''"	'���폜�@�������@�m��� �����@�ޯ��Ȃ�
		strSql = strSql & " AND CostsNo NOT IN (SELECT DISTINCT ERASE_BIZ_NO FROM TBL_CTM_ERASE)"
		if strSel <> "" then strSql = strSql & strSel
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then myTotalAmount = GetLong(.Fields("TotalAmount"))	
		.Close
	
		strSql = "SELECT CostsNo, ClientRef, CostsClientName, CostsPayDay, CostsAmount, CostsTax, CostsBillNo, JobCode"
		strSql = strSql & " FROM TBL_CTM_COSTS AS T INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON T.CostsClient = C.CTM_CD"
		strSql = strSql & " WHERE Deleted = 0 AND FinisherID = 0 AND ConfirmerID <> 0 AND CostsType = 0 AND CostsBatch = ''"	'���폜�@�������@�m��� �����@�ޯ��Ȃ�
		strSql = strSql & " AND CostsNo NOT IN (SELECT DISTINCT ERASE_BIZ_NO FROM TBL_CTM_ERASE)"
		if strSel <> "" then strSql = strSql & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY CostsNo"
		case 1:		strSql = strSql & " ORDER BY JobCode, CostsNo"
		case 2:		strSql = strSql & " ORDER BY CostsBillNo, CostsNo"
		case 3:		strSql = strSql & " ORDER BY ClientRef, CostsNo"
		case 4:		strSql = strSql & " ORDER BY CostsPayDay, CostsNo"
		case 5:		strSql = strSql & " ORDER BY (CostsAmount+CostsTax) DESC, CostsNo"
		end select			
if WebUserID = gsAdmin then response.write strSql
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			if myMode > 0 then response.write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"
		else
			.PageSize = PageSize
			lngPageCount = .PageCount
			
			.AbsolutePage = lngPageNumber
			lngCount = (lngPageNumber - 1) * PageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=98% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup align=center>
			<colgroup span=4 align=left>
			<colgroup align=center>
			<colgroup align=right>
		  <TR align=center class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">�x���ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">�䒠�ԍ�
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">���臂
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�x����
			<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�x�����z
<!--			<TD class=line nowrap>�o��	-->
<%
			
			ttlAmount = 0
			do while not .eof
				lngCount = lngCount + 1
				If lngCount > lngPageNumber * PageSize Then
					Exit Do
				Else
					myCostsNo = GetString(.Fields("CostsNo"))
					myAmount = GetLong(.Fields("CostsAmount")) + GetLong(.Fields("CostsTax"))
%>
				<TR align=center height=25 style="cursor:hand" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
					 onclick="DoPayment('<%=myCostsNo%>')">
					<TD class=line><%=lngCount%><BR>
					<TD class=line><%=ShowVoucherNo(myCostsNo)%><BR>
					<TD class=line><%=ShowJobCode(.Fields("JobCode"))%><BR>
					<TD class=line nowrap <%=ShowTitle(.Fields("CostsBillNo"), 12)%>><%=StringCutRev(.Fields("CostsBillNo"), 12)%><BR>
					<TD class=line nowrap title="<%=GetString(.Fields("CostsClientName"))%>"><%=StringCut(GetString(.Fields("ClientRef")),10)%><BR>
					<TD class=line nowrap style="color:blue"><%=Str2YMD(.Fields("CostsPayDay"))%><BR>
					<TD class=line nowrap><%=formatnumber(myAmount, 0, true)%><BR>
<%
					ttlAmount = ttlAmount + myAmount
					.movenext
				end if
			loop
			.close
		end if
			
		if lngCount > 1 then 
%>
			<TR height=25>
				<TD colspan=4 align=left><%if lngCount > lngPageNumber * PageSize then response.write "<font color=red>��������܂�...</font>"%>
				<TD class=line align=right>�� �v
				<TD class=line align=right colspan=2><%=formatnumber(myTotalAmount, 0, true)%>
<%
		end if
%>
		</TABLE>
<%	
	end with
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>