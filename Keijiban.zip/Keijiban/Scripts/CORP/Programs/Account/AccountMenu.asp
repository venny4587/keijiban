
<html>
<head>
	<title>���茳�����j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		btnJournal.style.color = "black"
		btnBank.style.color = "black"
		btnReceive.style.color = "black"
		btnStandR.style.color = "black"
		btnStandP.style.color = "black"
		btnSales.style.color = "black"
		btnCosts.style.color = "black"
		select case mySel
		case 1
			url = "AccountView.asp"
			btnJournal.style.color = "red"
		case 2
			url = "AccountBank.asp"
			btnBank.style.color = "red"
		case 3
			url = "AccountDeposit.asp"	
			btnReceive.style.color = "red"
		case 4
			url = "AccountStandR.asp"
			btnStandR.style.color = "red"
		case 5
			url = "AccountStandP.asp"	
			btnStandP.style.color = "red"
		case 6
			url = "AccountSales.asp"	
			btnSales.style.color = "red"
		case 7
			url = "AccountCosts.asp"	
			btnCosts.style.color = "red"
		end select
		window.parent.abody.location.href = url 
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnJournal value="�����茳��" onclick="DoAct(1)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnBank value="��s�o�[��" onclick="DoAct(2)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnReceive value="�a����c��" onclick="DoAct(3)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnStandR value="���֔��|�c��" onclick="DoAct(4)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnStandP value="���֔��|�c��" onclick="DoAct(5)"></TD>
		    <TD width=120>
		    	<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnSales value="���|���c��" onclick="DoAct(6)"></TD>
		    <TD width=120>
				<INPUT type=button class=pt9n style="WIDTH: 110px; HEIGHT: 30px;" name=btnCosts value="���|���c��" onclick="DoAct(7)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
