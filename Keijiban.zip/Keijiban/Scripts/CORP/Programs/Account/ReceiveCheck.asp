<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����`�[�ꊇ�m���ʁi�����������j���[�j
'----------------------------------------------

'on error resume next
dim FinStr
dim myMode
dim PageSize
	
	PageSize = GetUserPageSize(10)
			
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		DateTo = formatDate(date)
	else
		ClientRef = GetPost(request("ClientRef"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		Fin_No = GetPost(request("Fin_No"))
		JobCode = GetPost(request("JobCode"))
		BillNo = GetPost(request("BillNo"))
		AmntFrom = GetPost(request("AmntFrom"))
		AmntTo = GetPost(request("AmntTo"))
		if AmntFrom <> "" then AmntFrom = GetDouble(AmntFrom)
		if AmntTo <> "" then AmntTo = GetDouble(AmntTo)
		
		'�ꊇ�m�菈��
		if myMode = 2 then	
			msg = ""
			FinStr = split(GetPost(request("FinNo")), ",")
			
			Conn.BeginTrans
				
			for i = 0 to ubound(FinStr)
				FinNo = trim(FinStr(i))
									
				'�����`�[�m��
				strSql = "UPDATE TBL_CTM_FIN SET CONFIRM_DATE = GETDATE()"
				strSql = strSql & ", CONFIRM_ID = " & WebUserID
				strSql = strSql & " WHERE FIN_NO = '" & FinNo & "'"
				Conn.execute strSql
				
				if err.number <> 0 then exit for
			next
				
			if err.number = 0 then
				Conn.CommitTrans
				msg = "�m�菈���͖����������܂����B"
			else
				Conn.RollbackTrans
				msg = "�m�菈�������L�̃G���[���N����܂����B(" & vbcrlf & err.number & ":" & err.description & ")"
			end if
		end if
	end if
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����`�[�m�菈��</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function DoCheck()
			Call CheckAll("FinNo", frmInput.CheckAll.Checked)
		end function 
	
		function DoConfirm()
			checkFlag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then 
					if left(obj.name, 5) = "FinNo" and obj.Checked then
						checkFlag = 1						
						exit for
					end if
				end if
			next 	
			if checkFlag = 0 then
				msgbox "�m�肷������`�[��I�����Ă��������B", 48, "�m�F���b�Z�[�W"
				exit function
			end if
<%if gsPolite = 1 then%>
			if msgbox ("�f�[�^���m�肵�Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
			frmInput.mode.value = 2
			frmInput.submit()
		end function 
		
		function ShowList() 
		dim win
			set win = window.open("ClientSearch.asp?cd=" & frmInput.ClientRef.value,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
						
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub
		sub AmntFrom_OnBlur()
			if frmInput.AmntFrom.value = "" then exit sub
			frmInput.AmntFrom.value = GetDouble(frmInput.AmntFrom.value)
		end sub
		sub AmntTo_OnBlur()
			if frmInput.AmntTo.value = "" then exit sub
			frmInput.AmntTo.value = GetDouble(frmInput.AmntTo.value)
		end sub
<%if CheckInputNo() > 0 then %>
		sub Fin_No_OnBlur()
			frmInput.Fin_No.value = FitReceiveNo(frmInput.Fin_No.value)
		end sub
<%end if %>
		
		function DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.submit()
		end function
			
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub
		
		sub InitForm()
<%if myMode = 2 then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
			window.parent.parent.result.location.href = "ReceiveResult.asp?type=1"
<%else%>
			frmInput.ClientRef.focus()
<%end if%>
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt12 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="ReceiveCheck.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<table class=pt12>
			<TR><TD nowrap>
				������<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList()">
					<input class=mi name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">					
				������&nbsp;<input class=mi name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=mi name="DateTo" value="<%=DateTo%>" maxlength=10 size=10 onclick="setday(this)" onkeydown="ResetEnter()">
				<TD rowspan=2 width=100 align=right>
					<INPUT class=pt12n style="width:80px;height:40px;" TYPE=SUBMIT VALUE="����">					
			<TR><TD nowrap>
				�����ԍ�&nbsp;<input class=mn name="Fin_No" value="<%=Fin_No%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�����z&nbsp;<input class=mn name="AmntFrom" value="<%=AmntFrom%>" maxlength=8 size=8 onkeydown="ResetEnter()">
					�`<input class=mn name="AmntTo" value="<%=AmntTo%>" maxlength=8 size=8 onkeydown="ResetEnter()">
		</table>
		
	<!----------��������--------->
<%
if myMode > 0 then
	strSel = ""
	if ClientRef <> "" then	strSel = strSel & " AND (ClientRef = '" & FitSel(ClientRef) & "' OR FIN_CLIENT_NAME LIKE '% " & FitSel(ClientRef) & "%')"
	if DateFrom <> "" then strSel = strSel & " AND FIN_DATE >= '" & Date2Str(DateFrom) & "'"
	if DateTo <> "" then strSel = strSel & " AND FIN_DATE <= '" & Date2Str(DateTo) & "'"	
	if Fin_No <> "" then strSel = strSel & " AND FIN_NO LIKE '%" & FitSel(Fin_No) & "%'"	
	if JobCode <> "" then strSel = strSel & " AND FIN_JOBCODE LIKE '%" & FitSel(JobCode) & "%'"
	if BillNo <> "" then strSel = strSel & " AND FIN_BILLNO LIKE '%" & FitSel(BillNo) & "%'"
	if AmntFrom <> "" then strSel = strSel & " AND FIN_AMOUNT >= " & AmntFrom
	if AmntTo <> "" then strSel = strSel & " AND FIN_AMOUNT <= " & AmntTo
		
	with recset
		TotalAmount = 0
		strSql = "SELECT SUM(FIN_AMOUNT) AS TotalAmount FROM TBL_CTM_FIN AS F INNER JOIN"
		strSql = strSql & " (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'R' AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND ERASE_ID = 0 AND CONFIRM_ID = 0"		'���폜�@�������@���m��
		if strSel <> "" then strSQL = strSQL & strSel
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then TotalAmount = GetLong(.Fields("TotalAmount"))
		.Close
	
		strSql = "SELECT FIN_NO, FIN_TYPE, ClientRef, FIN_CLIENT_NAME, FIN_DATE, FIN_AMOUNT, FIN_JOBCODE, FIN_BILLNO FROM TBL_CTM_FIN AS F"
		strSql = strSql & " INNER JOIN (SELECT CTM_CD, CTM_REF AS ClientRef FROM CUSTOMER) AS C ON F.FIN_CLIENT_CD = C.CTM_CD"
		strSql = strSql & " WHERE SUBSTRING(FIN_NO,3,1) = 'R' AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND ERASE_ID = 0 AND CONFIRM_ID = 0"		'���폜�@�������@���m��
		if strSel <> "" then strSQL = strSQL & strSel
		select case mySort
		case 0:		strSql = strSql & " ORDER BY FIN_NO"
		case 1:		strSql = strSql & " ORDER BY FIN_BILLNO, FIN_NO"
		case 2:		strSql = strSql & " ORDER BY FIN_JOBCODE, FIN_NO"
		case 3:		strSql = strSql & " ORDER BY ClientRef, FIN_NO"
		case 4:		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
		end select			
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if .eof then
			response.write "<br><div align=center class=pt12r>�Y������f�[�^�͌�����܂���ł����B</div>"
		else
%>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
			<colgroup align=center>
			<colgroup span=4 align=left>
			<colgroup align=center>
			<colgroup align=right>
			<colgroup align=center>
		  <TR align=center height=20 class=pt12>
			<TD class=line nowrap>��
			<TD class=line nowrap>�����ԍ�
			<TD class=line nowrap>�����ԍ�
			<TD class=line nowrap>�䒠�ԍ�
			<TD class=line nowrap>������
			<TD class=line nowrap>������
			<TD class=line nowrap>�����z
			<TD class=line nowrap>�S<input type=checkbox name="CheckAll" value="" onclick="DoCheck()">
<%
			cnt = 0
			ttlAmount = 0
			Do Until .EOF
				cnt = cnt + 1			
				if cnt > PageSize then exit do	
				FIN_NO = GetString(.Fields("FIN_NO"))	
				ttlAmount = ttlAmount + GetLong(.Fields("FIN_AMOUNT"))
%>
		<TR align=center height=20>
			<TD class=line><%=cnt%><BR>
			<TD class=line><%=ShowVoucherNo(.Fields("FIN_NO"))%><BR>
			<TD class=line><%=ShowVoucherNo(.Fields("FIN_BILLNO"))%><BR>
			<TD class=line><%=GetString(.Fields("FIN_JOBCODE"))%><BR>
			<TD class=line nowrap title="<%=GetString(.Fields("FIN_CLIENT_NAME"))%>"><%=StringCut(GetString(.Fields("ClientRef")),7)%><BR>
			<TD class=line style="color:green"><%=Str2MD(.Fields("FIN_Date"))%><BR>
			<TD class=line nowrap><%=formatnumber(GetLong(.Fields("FIN_AMOUNT")), 0, true)%><BR>
			<TD class=line><input type=checkbox name="FinNo" value="<%=GetString(.Fields("FIN_NO"))%>">
<%
				.movenext
			loop
			if cnt > 1 then 
%>
			<TR align=right height=20>
				<TD colspan=4><%if cnt > 10 then response.write "<font color=red>��������܂�...</font>"%>
				<TD class=line>�� �v
				<TD class=line colspan=2><%=formatnumber(TotalAmount, 0, true)%>
<%
			end if
%>
		</TABLE>
<%	if CheckAccountLevel() > 0 then%>
		<div align=right>
			<INPUT class=pt12n style="width:80px;height:40px;" TYPE=button VALUE="�m��" onclick="DoConfirm()">
		</div>
<%	end if
		end if
		.Close
	end with
end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>