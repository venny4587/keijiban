<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�q�ʎc�����ڕ\�i�����������j���[�j
'----------------------------------------------

'on error resume next
dim mode
dim AccountMonth
dim AccountFrom
dim AccountTo

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mode = GetLong(request("mode"))
	if mode <> 0 then
		SelYear = GetLong(request("SelYear"))
		DateFrom = SelYear & "0301"
		DateTo = Date2Str(date)
		ClientRef = GetPost(request("ClientRef"))
		ClientCode = GetCtmCode(ClientRef, 0)
	else
		SelYear = year(date)
		if month(date) < 4 then SelYear = SelYear - 1
	end if
%>
<HTML>
<HEAD>
	<TITLE>�q�ʎc�����ڕ\</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		sub DoSearch()
			if frmInput.ClientRef.value = "" then
				msgbox "�����׎����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
			else
				frmInput.submit()
			end if
		end sub
		
		sub InitForm()
			frmInput.ClientRef.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CloseBalance.asp" ID=frmInput NAME=frmInput>
	  <input type=hidden name="mode" value="1">
	  <table class=pt9>
		<TR><TD nowrap>
				�����׎�<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				��v�N�x&nbsp;
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>
			<TD nowrap>
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnSearch VALUE="����" onclick="DoSearch()">
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">
	</table><br>
<%
	if mode > 0 then 
		with Recset
			strSql = "SELECT * FROM ("
			strSql = strSql & "SELECT FIN_NO AS no, '' AS cd, MAX(FIN_DATE) AS dt, MAX(FIN_SECURITIES) AS Vessel, '' AS Voy"
			strSql = strSql & ", SUM(CASE FIN_DEBIT WHEN " & acntAlter & " THEN FIN_AMOUNT+FIN_TAX ELSE 0-FIN_AMOUNT-FIN_TAX END) AS amnt"
			strSql = strSql & ", '' AS InvoiceNo, MAX(ERASE_ID) as chk, 1 as kb FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
			strSql = strSql & " AND FIN_TYPE IN (19, 33, 35) AND FIN_CLIENT_CD = '" & ClientCode & "'"
			if DateFrom <> "" then strSql = strSql & " AND FIN_DATE >= '" & DateFrom & "'"
			if DateTo <> "" then strSql = strSql & " AND FIN_DATE <= '" & DateTo & "'"
			strSql = strSql & " GROUP BY FIN_NO UNION ALL "
			strSql = strSql & "SELECT ChargeNo AS no, C.JobCode AS cd, ChargeDate AS dt, Vessel, Voy,"
			strSql = strSql & "(ChargeAmount+ChargeTax) AS amnt, InvoiceNo, C.FinisherID as chk, 0 as kb"
			strSql = strSql & " FROM TBL_CTM_CHARGE AS C INNER JOIN TBL_CTM_JOB AS J ON C.JobCode = J.JobCode"
			strSql = strSql & " WHERE C.Deleted = 0 AND ChargeClient = '" & ClientCode & "'"
			if DateFrom <> "" then strSql = strSql & " AND ChargeDate >= '" & DateFrom & "'"
			if DateTo <> "" then strSql = strSql & " AND ChargeDate <= '" & DateTo & "'"
			strSql = strSql & " ) AS TMP ORDER BY dt, no"
if WebUserID = gsAdmin then response.write strSql
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
%>
<div id=list>
	<table width=96% class=pt9n>
		<colgroup align=left>
		<colgroup span=3 align=center>
		<colgroup span=2 align=left>
		<colgroup span=3 align=right>
		<TR class=pt9>
			<td colspan=7>�����׎�F<font class=pt9g><%=GetFullName(ClientCode)%></font>
			<td colspan=2>�Ώ۔N�x�F<font class=pt9g><%=ShowJpnYear(SelYear)%></font>
		<TR class=pt9>
			<TD class=line nowrap>��
			<TD class=line nowrap>���t
			<TD class=line nowrap>�`�[�ԍ�
			<TD class=line nowrap>�䒠�ԍ�
			<TD class=line nowrap>�D��
			<TD class=line nowrap>Inv ��
			<TD class=line nowrap>�����z
			<TD class=line nowrap>�����z
			<TD class=line nowrap>�c��
		<TR bgcolor=#E0E0E0>
			<TD class=line colspan=5><br>
			<TD class=line nowrap>�y����c���z
			<TD class=line colspan=2><br>
			<TD class=line nowrap><%=GetInitBalance(DateFrom)%>
<%
				cnt = 0:	curDate = ""
				sum = 0:	sum1 = 0:	sum2 = 0
				do while not .eof
					if left(curDate, 6) <> left(GetString(.fields("dt")), 6) then
						if curDate <> "" then
%>
		<TR bgcolor=#E0E0E0>
			<TD class=line colspan=5><br>
			<TD class=line nowrap>�y�����c���z
			<TD class=line colspan=2><br>
			<TD class=line nowrap><%=formatnumber(sum, 0, true)%><br>
<%
						end if
					end if
					cnt = cnt + 1
					curDate = GetString(.fields("dt"))
					vessel = GetString(.fields("vessel"))
					if GetString(.fields("Voy")) <> "" then vessel = vessel & " V." & GetString(.fields("Voy"))
					
					if GetLong(.fields("chk")) = 0 then
						myColor = "red"
					elseif mid(GetString(.fields("no")),3,1) = "S" then
						myColor = "green"
					else
						myColor = "black"
					end if
					
					if GetLong(.fields("kb")) = 0 then
						plus = GetLong(.fields("amnt"))
						minus = 0
					else
						plus = 0
						minus = GetLong(.fields("amnt"))
					end if
					
					sum1 = sum1 + plus
					sum2 = sum2 + minus
					sum = sum + plus - minus
%>
		<TR style="color:<%=myColor%>">
			<TD class=line nowrap><%=cnt%>
			<TD class=line nowrap><%=Str2YMD(curDate)%><br>
			<TD class=line nowrap><%=GetString(.fields("no"))%><br>
			<TD class=line nowrap><%=GetString(.fields("cd"))%><br>
			<TD class=line nowrap><%=vessel%><br>
			<TD class=line nowrap><%=GetString(.fields("InvoiceNo"))%><br>
			<TD class=line nowrap><%=formatnumber(plus, 0, false)%><br>
			<TD class=line nowrap><%=formatnumber(minus, 0, false)%><br>
			<TD class=line nowrap><%=formatnumber(sum, 0, true)%><br>
<%
					.MoveNext
				loop
				if cnt > 1 then
%>
		<TR bgcolor=#E0E0E0>
			<TD class=line colspan=5><br>
			<TD class=line nowrap>�y�������v�z
			<TD class=line><%=formatnumber(sum1, 0, true)%><BR>
			<TD class=line><%=formatnumber(sum2, 0, true)%><BR>
			<TD class=line><%=formatnumber(sum, 0, true)%><BR>
<%
				end if
%>
	</table>
	<br>
	<font class=pt9r>�ԁF������</font>�@
	<font class=pt9n>���F������</font>�@
	<font class=pt9g>�΁F���֕�</font>�@
</div>
<%
			else
				response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
			end if
			.Close
		end with
	end if
%>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function GetInitBalance(myDate)
dim mySql
dim myRec
dim myInit
	myInit = 0
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT SUM(BIZ_AMOUNT+BIZ_TAX) AS TTL FROM TBL_CTM_BIZ WHERE BIZ_DELETED = 0"
		mySql = mySql & " AND ERASE_ID = 0 AND BIZ_DATE < '" & myDate & "' AND BIZ_TYPE < " & gsPayment
		.Open mySql,conn,adOpenStatic,adLockReadOnly
		if not .eof then myInit = myInit + GetLong(.fields("TTL"))
		.Close
		
		mySql = "SELECT SUM(CASE FIN_CREDIT WHEN " & acntAlter & " THEN FIN_AMOUNT+FIN_TAX ELSE 0-FIN_AMOUNT-FIN_TAX END) AS TTL"
		mySql = mySql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND ERASE_ID = 0 AND FIN_DATE < '" & myDate & "' AND FIN_TYPE = 33"
		.Open mySql,conn,adOpenStatic,adLockReadOnly
		if not .eof then myInit = myInit + GetLong(.fields("TTL"))
		.Close
	end with
	set myRec = nothing
	
	GetInitBalance = formatnumber(myInit, 0, true)
end function
%>