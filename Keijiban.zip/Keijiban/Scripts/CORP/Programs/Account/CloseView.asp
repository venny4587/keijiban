<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����ߏ�����ʁi�����������j���[�j
'----------------------------------------------

'on error resume next
dim mode
dim AccountBelong
dim AccountMonth
dim AccountFrom
dim AccountTo
	
	AccountBelong = GetPost(request("SelBranch"))				'�q�ɂ̏ꍇ�͎x�X�ʕK�v
	if AccountBelong = "" then AccountBelong = "O"
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	SelType = GetLong(request("type"))
	SelYear = GetLong(request("SelYear"))
	SelMonth = GetLong(request("SelMonth"))
	if SelYear = 0 or SelMonth = 0 then
		SelDate = date
		if day(SelDate) <= gsSysCloseDay then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
	end if
	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
	if SelType <> 0 then
		
		if SelType = 2 then
			strSql = "UPDATE TBL_CTM_ACCOUNT SET"
			strSql = strSql & "  BankInit = " & GetLong(request("BankInit"))
			strSql = strSql & ", BankBalance = BankBalance + " & GetLong(request("BankInit"))
			strSql = strSql & ", SalesInit = " & GetLong(request("SalesInit"))
			strSql = strSql & ", SalesBalance = SalesBalance + " & GetLong(request("SalesInit"))
			strSql = strSql & ", CostsInit = " & GetLong(request("CostsInit"))
			strSql = strSql & ", CostsBalance = CostsBalance + " & GetLong(request("CostsInit"))
			strSql = strSql & ", DepositInit = " & GetLong(request("DepositInit"))
			strSql = strSql & ", DepositBalance = DepositBalance + " & GetLong(request("DepositInit"))
			strSql = strSql & ", StandRInit = " & GetLong(request("StandRInit"))
			strSql = strSql & ", StandRBalance = StandRBalance + " & GetLong(request("StandRInit"))
			strSql = strSql & ", StandPInit = " & GetLong(request("StandPInit"))
			strSql = strSql & ", StandPBalance = StandPBalance + " & GetLong(request("StandPInit"))
			strSql = strSql & ", TotalInit = " & GetLong(request("TotalInit"))
			strSql = strSql & ", TotalBalance = TotalBalance + " & GetLong(request("TotalInit"))
			strSql = strSql & " WHERE AccountBelong = '" & AccountBelong & "'"
			strSql = strSql & " AND AccountMonth = '" & AccountMonth & "'"
			Conn.Execute strSql
		end if
		with Recset
			strSql = "SELECT * FROM TBL_CTM_ACCOUNT WHERE AccountBelong = '" & AccountBelong & "' AND AccountMonth = '" & AccountMonth & "'"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if not .eof then 
				.Fields("Remarks") = GetPost(request("Remarks"))
				.Update
			end if
			.Close
		end with
		response.redirect "CloseProc.asp?type=" & SelType & "&AccountBelong=" & AccountBelong & "&AccountMonth=" & AccountMonth
	else
	
		SalesAmount = 0
		SalesTax = 0
		CostsAmount = 0
		CostsTax = 0
		Postage = 0
		MassTotal = 0
		BankInit = 0
		BankDebit = 0
		BankCredit = 0
		BankBalance = 0
		SalesInit = 0
		SalesDebit = 0
		SalesCredit = 0
		SalesBalance = 0
		CostsInit = 0
		CostsDebit = 0
		CostsCredit = 0
		CostsBalance = 0
		DepositInit = 0
		DepositDebit = 0
		DepositCredit = 0
		DepositBalance = 0
		StandRInit = 0
		StandRDebit = 0
		StandRCredit = 0
		StandRBalance = 0
		StandPInit = 0
		StandPDebit = 0
		StandPCredit = 0
		StandPBalance = 0
		CarryOverInit = 0
		CarryOverDebit = 0
		CarryOverCredit = 0
		CarryOverBalance = 0
		TotalInit = 0
		TotalBalance = 0
		GrossProfit = 0
		Finished = 0
		Remarks = ""
		
		mode = 0
		with recset
			strSql = "SELECT * FROM TBL_CTM_ACCOUNT WHERE AccountBelong = '" & AccountBelong & "'"
			strSql = strSql & " AND AccountMonth <= '" & AccountMonth & "' ORDER BY AccountMonth DESC"
	'if WebUserID = gsAdmin then response.write strSQL
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				mode = 1
				if GetString(.fields("AccountMonth")) = AccountMonth then mode = 2
				SalesAmount = GetLong(.fields("SalesAmount"))
				SalesTax = GetLong(.fields("SalesTax"))
				CostsAmount = GetLong(.fields("CostsAmount"))
				CostsTax = GetLong(.fields("CostsTax"))
				Postage = GetLong(.fields("Postage"))
				MassTotal = GetLong(.fields("MassTotal"))
				BankInit = GetLong(.fields("BankInit"))
				BankDebit = GetLong(.fields("BankDebit"))
				BankCredit = GetLong(.fields("BankCredit"))
				BankBalance = GetLong(.fields("BankBalance"))
				SalesInit = GetLong(.fields("SalesInit"))
				SalesDebit = GetLong(.fields("SalesDebit"))
				SalesCredit = GetLong(.fields("SalesCredit"))
				SalesBalance = GetLong(.fields("SalesBalance"))
				CostsInit = GetLong(.fields("CostsInit"))
				CostsDebit = GetLong(.fields("CostsDebit"))
				CostsCredit = GetLong(.fields("CostsCredit"))
				CostsBalance = GetLong(.fields("CostsBalance"))
				DepositInit = GetLong(.fields("DepositInit"))
				DepositDebit = GetLong(.fields("DepositDebit"))
				DepositCredit = GetLong(.fields("DepositCredit"))
				DepositBalance = GetLong(.fields("DepositBalance"))
				StandRInit = GetLong(.fields("StandRInit"))
				StandRDebit = GetLong(.fields("StandRDebit"))
				StandRCredit = GetLong(.fields("StandRCredit"))
				StandRBalance = GetLong(.fields("StandRBalance"))
				StandPInit = GetLong(.fields("StandPInit"))
				StandPDebit = GetLong(.fields("StandPDebit"))
				StandPCredit = GetLong(.fields("StandPCredit"))
				StandPBalance = GetLong(.fields("StandPBalance"))
				CarryOverInit = GetLong(.fields("CarryOverInit"))
				CarryOverDebit = GetLong(.fields("CarryOverDebit"))
				CarryOverCredit = GetLong(.fields("CarryOverCredit"))
				CarryOverBalance = GetLong(.fields("CarryOverBalance"))
				TotalInit = GetLong(.fields("TotalInit"))
				TotalBalance = GetLong(.fields("TotalBalance"))
				GrossProfit = GetLong(.fields("GrossProfit"))
				Remarks = GetString(.fields("Remarks"))
				Finished = GetLong(.fields("Finished"))
			end if
			.Close
			
			if not (mode = 2 and Finished <> 0) then
			
				'------------------------------------------------------
				
				'�Ɩ��f�[�^���甄��E�O���̎擾�i�΍����邽�߁j	�������
				strSql = "SELECT SUM(SalesSum) AS SA, SUM(SalesTax) AS ST, SUM(CostsSum) AS CA, SUM(CostsTax) AS CT FROM TBL_CTM_JOB"
				strSql = strSql & " WHERE Deleted = 0 AND JobBelong = '" & AccountBelong & "'"					' AND LockerID <> 0 AND Canceled = 0
				strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"							' AND AccountDate = ''"
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then
					SalesAmount = GetLong(.fields("SA"))
					SalesTax = GetLong(.fields("ST"))
					CostsAmount = GetLong(.fields("CA"))
					CostsTax = GetLong(.fields("CT"))
				end if
				.Close
				
				'�����d�󂩂�ʐM��̎擾
				strSql = "SELECT SUM(CASE FIN_DEBIT WHEN " & acntPostage & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS Postage FROM TBL_CTM_FIN"
				strSql = strSql & " WHERE FIN_DELETED = 0 AND ERASE_ID <> 0 AND FIN_BELONG = '" & AccountBelong & "'"
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"								' AND FIN_MONTH = ''"
				strSql = strSql & " AND (FIN_DEBIT = " & acntPostage & " OR FIN_CREDIT = " & acntPostage & ")"  
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then Postage = GetLong(.fields("Postage"))	
				.Close
				
				'�����d�󂩂�G��̎擾
				myMass = acntMassProfit & "," & acntMassLoss & "," & acntDiscount
				strSql = "SELECT SUM(CASE FIN_CREDIT WHEN " & acntAlter & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS MassTotal FROM TBL_CTM_FIN"
				strSql = strSql & " WHERE FIN_DELETED = 0 AND ERASE_ID <> 0 AND FIN_BELONG = '" & AccountBelong & "'"
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"								' AND FIN_MONTH = ''"
				strSql = strSql & " AND (FIN_DEBIT IN (" & myMass & ") OR FIN_CREDIT IN (" & myMass	& "))"  
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then MassTotal = GetLong(.fields("MassTotal"))
				.Close
				
				'------------------------------------------------------
				
				'�����d�󂩂���o���̎擾
				strSql = "SELECT SUM(CASE FIN_DEBIT WHEN " & acntBank & " THEN FIN_AMOUNT ELSE 0 END) AS BankDebit, "
				strSql = strSql & " SUM(CASE FIN_CREDIT WHEN " & acntBank & " THEN FIN_AMOUNT ELSE 0 END) AS BankCredit"
				strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND ERASE_ID <> 0 AND FIN_BELONG = '" & AccountBelong & "'"
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"								' AND FIN_MONTH = ''" 
				strSql = strSql & " AND (FIN_DEBIT = " & acntBank & " OR FIN_CREDIT = " & acntBank	& ")"  
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then 
					BankDebit = GetLong(.fields("BankDebit"))
					BankCredit = GetLong(.fields("BankCredit"))
				end if
				.Close
				
				'�����d�󂩂�a������̎擾
				strSql = "SELECT SUM(CASE FIN_DEBIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0 END) AS DepositDebit, "
				strSql = strSql & " SUM(CASE FIN_CREDIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0 END) AS DepositCredit"
				strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND ERASE_ID <> 0 AND FIN_BELONG = '" & AccountBelong & "'"				
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"								' AND FIN_MONTH = ''" 
				strSql = strSql & " AND (FIN_DEBIT = " & acntOverReceive & " OR FIN_CREDIT = " & acntOverReceive & ")"
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then 
					DepositDebit = GetLong(.fields("DepositDebit"))
					DepositCredit = GetLong(.fields("DepositCredit"))
				end if
				.Close
				
				'�Ɩ��d�󂩂甄�|���E���|���E���֋��̎؂���擾				���������ϕ�
				strSql = "SELECT BIZ_TYPE, SUM(BIZ_AMOUNT + BIZ_TAX) AS TotalAmount FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J"
				strSql = strSql & " ON B.BIZ_JOBCODE = J.JobCode WHERE BIZ_DELETED = 0 AND Deleted = 0"							' AND LockerID <> 0 AND Canceled = 0
				strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"	' AND AccountDate = ''"
				strSql = strSql & " GROUP BY BIZ_TYPE"
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof 
					select case GetLong(.Fields("BIZ_TYPE"))
					case bizSales
						SalesDebit = GetLong(.fields("TotalAmount"))
					case bizStandR
						StandRDebit = GetLong(.fields("TotalAmount"))
					case bizCosts
						CostsDebit = GetLong(.fields("TotalAmount"))
					case bizStandP
						StandPDebit = GetLong(.fields("TotalAmount"))
					end select
					.MoveNext
				loop
				.Close
				
				'�Ɩ��d�󂩂甄�|���E���|���E���֋��݂̑����擾				���������ϕ�
				strSql = "SELECT BIZ_TYPE, SUM(BIZ_AMOUNT + BIZ_TAX) AS TotalAmount FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_FIN AS F"
				strSql = strSql & " ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND FIN_DELETED = 0 AND FIN_TYPE IN (" & acntBank & "," & acntOverReceive & ")"
				strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND FIN_ORIGINAL = 1 AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"	' AND AccountDate = ''"
				strSql = strSql & " GROUP BY BIZ_TYPE"
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof 
					select case GetLong(.Fields("BIZ_TYPE"))
					case bizSales
						SalesCredit = GetLong(.fields("TotalAmount"))
					case bizStandR
						StandRCredit = GetLong(.fields("TotalAmount"))
					case bizCosts
						CostsCredit = GetLong(.fields("TotalAmount"))
					case bizStandP
						StandPCredit = GetLong(.fields("TotalAmount"))
					end select
					.MoveNext
				loop
				.Close
							
				'------------------------------------------------------	
				
				'�����d�󂩂�J�z���o���̎擾
				strSql = "SELECT SUM(CASE FIN_CREDIT WHEN " & acntCarryOver & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS CarryOverInit"
				strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND ERASE_ID <> 0 AND FIN_BELONG = '" & AccountBelong & "'"
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"							' AND FIN_MONTH = ''" 
				strSql = strSql & " AND (FIN_DEBIT = " & acntCarryOver & " OR FIN_CREDIT = " & acntCarryOver	& ")"  
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then 
					CarryOverInit = GetLong(.fields("CarryOverInit"))
				end if
				.Close
				
				'�Ɩ��d�󂩂甄�|���E���|���E���֋��̌J�z�擾				���������ϕ�				
				CarryOverCredit = 0:	CarryOverDebit = 0
				strSql = "SELECT BIZ_TYPE, SUM(BIZ_AMOUNT + BIZ_TAX) AS TotalAmount FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J"
				strSql = strSql & " ON B.BIZ_JOBCODE = J.JobCode INNER JOIN (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
				strSql = strSql & " AND FIN_ORIGINAL <> 0 AND ERASE_ID <> 0) AS F ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND Deleted = 0"			' AND LockerID <> 0 AND Canceled = 0
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"											' AND BIZ_MONTH = ''"
				strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND (SalesDate <'" & AccountFrom & "' OR SalesDate >'" & AccountTo & "')"				' AND AccountDate = ''"
				strSql = strSql & " GROUP BY BIZ_TYPE"
'if WebUserID = gsAdmin then response.write strSql
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof 
					select case GetLong(.Fields("BIZ_TYPE"))
					case bizSales, bizStandR
						CarryOverCredit = CarryOverCredit + GetLong(.fields("TotalAmount"))
					case bizCosts, bizStandP
						CarryOverDebit = CarryOverDebit + GetLong(.fields("TotalAmount"))
					end select
					.MoveNext
				loop
				.Close
				CarryOverBalance = CarryOverInit + CarryOverDebit - CarryOverCredit	
				
				BankBalance = BankInit + BankDebit - BankCredit
				DepositBalance = DepositInit + DepositDebit - DepositCredit
				SalesBalance = SalesInit + SalesDebit - SalesCredit
				CostsBalance = CostsInit + CostsDebit - CostsCredit
				StandRBalance = StandRInit + StandRDebit - StandRCredit
				StandPBalance = StandPInit + StandPDebit - StandPCredit
				
				TotalInit = BankInit + DepositInit + SalesInit - CostsInit + StandRInit - StandPInit
				TotalBalance = BankBalance + DepositBalance + SalesBalance - CostsBalance + StandRBalance - StandPBalance
				
				GrossProfit = TotalBalance - TotalInit - CarryOverInit
				GrossProfit = GrossProfit
				
				'------------------------------------------------------	
							
				strSql = "SELECT * FROM TBL_CTM_ACCOUNT WHERE AccountBelong = '" & AccountBelong & "' AND AccountMonth = '" & AccountMonth & "'"
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.AddNew
					.fields("AccountBelong") = AccountBelong
					.fields("AccountMonth") = AccountMonth
					.fields("Finished") = 0
					
					.fields("Creater") = WebUserID
					.fields("Created") = now
				end if
							
				.fields("SalesAmount") = SalesAmount
				.fields("SalesTax") = SalesTax
				.fields("CostsAmount") = CostsAmount
				.fields("CostsTax") = CostsTax
				.fields("Postage") = Postage
				.fields("MassTotal") = MassTotal
				.fields("BankInit") = BankInit
				.fields("BankDebit") = BankDebit
				.fields("BankCredit") = BankCredit
				.fields("BankBalance") = BankBalance
				.fields("SalesInit") = SalesInit
				.fields("SalesDebit") = SalesDebit
				.fields("SalesCredit") = SalesCredit
				.fields("SalesBalance") = SalesBalance
				.fields("CostsInit") = CostsInit
				.fields("CostsDebit") = CostsDebit
				.fields("CostsCredit") = CostsCredit
				.fields("CostsBalance") = CostsBalance
				.fields("DepositInit") = DepositInit
				.fields("DepositDebit") = DepositDebit
				.fields("DepositCredit") = DepositCredit
				.fields("DepositBalance") = DepositBalance
				.fields("StandRInit") = StandRInit
				.fields("StandRDebit") = StandRDebit
				.fields("StandRCredit") = StandRCredit
				.fields("StandRBalance") = StandRBalance
				.fields("StandPInit") = StandPInit
				.fields("StandPDebit") = StandPDebit
				.fields("StandPCredit") = StandPCredit
				.fields("StandPBalance") = StandPBalance
				.fields("CarryOverInit") = CarryOverInit
				.fields("CarryOverDebit") = CarryOverDebit
				.fields("CarryOverCredit") = CarryOverCredit
				.fields("CarryOverBalance") = CarryOverBalance
				.fields("TotalInit") = TotalInit
				.fields("TotalBalance") = TotalBalance
				.fields("GrossProfit") = GrossProfit
				.fields("Remarks") = ""
				
				.fields("Updater") = WebUserID
				.fields("Updated") = now()
				.Update
				.Close
			end if
			
			'�����c���`�F�b�N
			BankCheckAmount = 0
			strSql = "SELECT SUM(CASE FIN_DEBIT WHEN " & acntBank & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS BankAmount FROM TBL_CTM_FIN"
			strSql = strSql & " WHERE FIN_ORIGINAL = 1 AND FIN_DELETED = 0 AND (FIN_DEBIT =" & acntBank & " OR FIN_CREDIT = " & acntBank & ")"
			strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .EOF then BankCheckAmount = BankBalance - BankInit - GetLong(.Fields("BankAmount"))
			.Close
			
			'�a���c���`�F�b�N
			DepositCheckAmount = 0
			strSql = "SELECT SUM(CASE FIN_DEBIT WHEN " & acntOverReceive & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS DepositAmount FROM TBL_CTM_FIN"
			strSql = strSql & " WHERE FIN_DELETED = 0 AND (FIN_DEBIT =" & acntOverReceive & " OR FIN_CREDIT = " & acntOverReceive & ")"
			strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .EOF then DepositCheckAmount = DepositBalance - DepositInit - GetLong(.Fields("DepositAmount"))
			.Close
		end with
		
		TaxInProfit = SalesAmount+SalesTax-CostsAmount-CostsTax-Postage-MassTotal
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�����ߏ���</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub ShowDetail(mode)
		dim win
			set win = window.open("CloseDetail.asp?AccountBelong=<%=AccountBelong%>&AccountMonth=<%=AccountMonth%>&mode=" & mode, "CloseDetail" & mode, "resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end sub
		
		sub ShowBalance(mode)
		dim win
			set win = window.open("CloseList.asp?AccountBelong=<%=AccountBelong%>&AccountMonth=<%=AccountMonth%>&mode=" & mode, "CloseList" & mode, "resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end sub
		
		sub DoClose()
			if msgbox ("�Y�����x�̒��ߏ��������s���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.btnClose.disabled = true
<%if mode = 0 then%>
			frmInput.type.value = 2
<%else%>
			frmInput.type.value = 1
<%end if%>
			frmInput.submit()
		end sub
		
		sub DoUnClose()
			if msgbox ("�Y�����x�̒��ߏ������������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.btnClose.disabled = true
			frmInput.type.value = -1
			frmInput.submit()
		end sub
	
<%if mode = 0 then%>
		sub BankInit_OnChange()
			frmInput.BankInit.value = GetLong(frmInput.BankInit.value)
			call Calculate()
		end sub		
		sub SalesInit_OnChange()
			frmInput.SalesInit.value = GetLong(frmInput.SalesInit.value)
			call Calculate()
		end sub		
		sub CostsInit_OnChange()
			frmInput.CostsInit.value = GetLong(frmInput.CostsInit.value)
			call Calculate()
		end sub
		sub DepositInit_OnChange()
			frmInput.DepositInit.value = GetLong(frmInput.DepositInit.value)
			call Calculate()
		end sub		
		sub StandRInit_OnChange()
			frmInput.StandRInit.value = GetLong(frmInput.StandRInit.value)
			call Calculate()
		end sub		
		sub StandPInit_OnChange()
			frmInput.StandPInit.value = GetLong(frmInput.StandPInit.value)
			call Calculate()
		end sub
		sub Calculate()
			BankInit = GetLong(frmInput.BankInit.value)
			SalesInit = GetLong(frmInput.SalesInit.value)
			CostsInit = GetLong(frmInput.CostsInit.value)
			DepositInit = GetLong(frmInput.DepositInit.value)
			StandRInit = GetLong(frmInput.StandRInit.value)
			StandPInit = GetLong(frmInput.StandPInit.value)
			
			BankBalance = <%=BankDebit - BankCredit%> + BankInit
			DepositBalance = <%=DepositDebit - DepositCredit%> + DepositInit
			SalesBalance = <%=SalesDebit - SalesCredit%> + SalesInit
			CostsBalance = <%=CostsDebit - CostsCredit%> + CostsInit
			StandRBalance = <%=StandRDebit - StandRCredit%> + StandRInit
			StandPBalance = <%=StandPDebit - StandPCredit%> + StandPInit
			
			frmInput.BankBalance.value = BankBalance
			frmInput.DepositBalance.value = DepositBalance
			frmInput.SalesBalance.value = SalesBalance
			frmInput.CostsBalance.value = CostsBalance
			frmInput.StandRBalance.value = StandRBalance
			frmInput.StandPBalance.value = StandPBalance
			
			TotalInit = BankInit + DepositInit + StandRInit + SalesInit + CarryOverInit - StandPInit - CostsInit
			TotalBalance = BankBalance + DepositBalance + SalesBalance - CostsBalance + StandRBalance - StandPBalance - CarryOverInit		
			GrossProfit = TotalBalance - TotalInit
			
			frmInput.TotalInit.value = TotalInit
			frmInput.TotalBalance.value = TotalBalance
			frmInput.GrossProfit.value = GrossProfit
		end sub
<%end if%>
	
		sub InitForm()
			frmInput.SelYear.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY class=pt12 onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CloseView.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="type" value="0">
		<table class=pt12n width=800><tr><td>
			<table class=pt12>
				<TR><TD nowrap>				
					��v���x&nbsp;
						<select class=pt12n name="SelYear" onkeydown="ResetEnter()"><%
						for i = year(date) to year(gsSysStart) step -1
							response.write "<option value=" & i
							if i = SelYear then response.write " selected"
							response.write ">" & i
						next%></select>&nbsp;�N
						<select class=pt12n name="SelMonth" onkeydown="ResetEnter()"><%
						for i = 1 to 12
							response.write "<option value=" & i
							if i = SelMonth then response.write " selected"
							response.write ">" & i
						next%></select>&nbsp;��
					<TD nowrap>	
						<INPUT class=pt12n style="width:80px;height:36px;" TYPE=SUBMIT VALUE="����">					
			</table><br>
		<tr><td>		
			<table class=pt12>
				<tr><td width=500>
					<table class=pt12n>
						<TR align=right class=pt12>
							<TD class=line nowrap width=100 align=center>�ȁ@��
							<TD class=line nowrap width=120>�Ŕ����z
							<TD class=line nowrap width=120>�����
							<TD class=line nowrap width=120>���@�v
						<TR align=right height=24>
							<TD class=line align=center>���@��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(SalesAmount, 0, true)%><BR>
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(SalesTax, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:green" onmousedown="ShowDetail(1)"><%=gsCurrency%><%=formatnumber(SalesAmount+SalesTax, 0, true)%><BR>
						<TR align=right height=24>
							<TD class=line align=center>�O�@��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(CostsAmount, 0, true)%><BR>
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(CostsTax, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:maroon" onmousedown="ShowDetail(2)"><%=gsCurrency%><%=formatnumber(CostsAmount+CostsTax, 0, true)%><BR>
						<TR align=right height=24>
							<TD class=line align=center>�ʐM��
							<TD class=line colspan=2><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(3)"><%=gsCurrency%><%=formatnumber(Postage, 0, true)%><BR>
						<TR align=right height=24>
							<TD class=line align=center>�G�@��
							<TD class=line colspan=2><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(4)"><%=gsCurrency%><%=formatnumber(MassTotal, 0, true)%><BR>
						<TR align=right height=24>
							<TD colspan=2><BR>
							<TD class=line align=center>�� �� �e ��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(TaxInProfit, 0, true)%><BR>
					</table><br>
			
				<td width=300 align=center valign=top>
					<table><tr><td>
						�����߃���<br>
						<textarea class=mz name="Remarks" rows=8 style="width:250" <%if Finished <> 0 then response.write "readonly"%>><%=Remarks%></textarea>
					</table>
			</table>
		<tr><td>
			<table class=pt12>
				<tr><td colspan=2>
					<table class=pt12n>
						<TR align=right class=pt12>
							<TD class=line nowrap width=100 align=center>�ȁ@��
							<TD class=line nowrap width=120>���@��
							<TD class=line nowrap width=120>�؁@��
							<TD class=line nowrap width=120>�݁@��
							<TD class=line nowrap width=120>���@��
							<TD nowrap width=200><br>
<%if mode = 0 then%>
						<TR align=right height=24>
							<TD class=line align=center>�� �s �� ��
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="BankInit" value="<%=BankInit%>">
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(11)"><%=gsCurrency%><%=formatnumber(BankDebit, 0, true)%><BR>
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(12)"><%=gsCurrency%><%=formatnumber(BankCredit, 0, true)%><BR>
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="BankBalance" value="<%=BankBalance%>" readonly>
							<TD nowrap><%if BankCheckAmount <> 0 then response.write "(" & BankCheckAmount & ")"%>
						<TR align=right height=24>
							<TD class=line align=center>�������֋�
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="StandRInit" value="<%=StandRInit%>">
							<TD nowrap class=line style="cursor:hand;color:red" onmousedown="ShowDetail(15)"><%=gsCurrency%><%=formatnumber(StandRDebit, 0, true)%><BR>
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(16)"><%=gsCurrency%><%=formatnumber(StandRCredit, 0, true)%><BR>
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="StandRBalance" value="<%=StandRBalance%>" readonly>
							<TD nowrap align=center rowspan=4>
<%if Finished = 0 then%>
	<%if CheckAccountLevel() > 1 and BankCheckAmount = 0 and DepositCheckAmount = 0 then%>
								<INPUT class=pt12n style="width:120px;height:50px;" type=button name=btnClose value="���ߎ��s" onclick="DoClose()">	
	<%end if%>
<%else%>
								<font class=pt12r>�����ߍ�</font><br>
	<%if CheckAccountLevel() > 2 then%>
								<INPUT class=pt12n style="width:120px;height:50px;" type=button name=btnClose value="���߉���" onclick="DoUnClose()">	
	<%end if%>
<%end if%>
						<TR align=right height=24>
							<TD class=line align=center>���@�|�@��
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="SalesInit" value="<%=SalesInit%>">
							<TD nowrap class=line style="cursor:hand;color:green" onmousedown="ShowDetail(17)"><%=gsCurrency%><%=formatnumber(SalesDebit, 0, true)%><BR>
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(18)"><%=gsCurrency%><%=formatnumber(SalesCredit, 0, true)%><BR>
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="SalesBalance" value="<%=SalesBalance%>" readonly>
						<TR align=right height=24>
							<TD class=line align=center>���@�|�@��
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="CostsInit" value="<%=CostsInit%>">
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(21)"><%=gsCurrency%><%=formatnumber(CostsCredit, 0, true)%><BR>
							<TD nowrap class=line style="cursor:hand;color:maroon" onmousedown="ShowDetail(22)"><%=gsCurrency%><%=formatnumber(CostsDebit, 0, true)%><BR>
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="CostsBalance" value="<%=CostsBalance%>" readonly>
						<TR align=right height=24>
							<TD class=line align=center>�������֋�
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="StandPInit" value="<%=StandPInit%>">
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(23)"><%=gsCurrency%><%=formatnumber(StandPCredit, 0, true)%><BR>
							<TD nowrap class=line style="cursor:hand;color:red" onmousedown="ShowDetail(24)"><%=gsCurrency%><%=formatnumber(StandPDebit, 0, true)%><BR>
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="StandPBalance" value="<%=StandPBalance%>" readonly>
						<TR align=right height=24>
							<TD class=line align=center>�a�@��@��
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="DepositInit" value="<%=0-DepositInit%>">
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(13)"><%=gsCurrency%><%=formatnumber(DepositDebit, 0, true)%><BR>
							<TD nowrap class=line style="cursor:hand;color:blue" onmousedown="ShowDetail(14)"><%=gsCurrency%><%=formatnumber(DepositCredit, 0, true)%><BR>
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="DepositBalance" value="<%=0-DepositBalance%>" readonly>
							<TD nowrap><%if DepositCheckAmount <> 0 then response.write "(" & DepositCheckAmount & ")"%>
						<TR align=right height=24>
							<TD class=line align=center>���@���@�v
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="TotalInit" value="<%=TotalInit%>" readonly>
							<TD colspan=2><BR>
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="TotalBalance" value="<%=TotalBalance%>" readonly>
						<TR align=right height=24>
							<TD colspan=3><BR>
							<TD class=line align=center>�� �� �e ��
							<TD nowrap><%=gsCurrency%><input class=mn size=10 maxlength=10 onkeydown="ResetEnter()" name="GrossProfit" value="<%=GrossProfit%>" readonly><BR>
<%else%>
						<TR align=right height=24>
							<TD class=line align=center>�� �s �� ��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(BankInit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(11)"><%=gsCurrency%><%=formatnumber(BankDebit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(12)"><%=gsCurrency%><%=formatnumber(BankCredit, 0, true)%><BR>
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(BankBalance, 0, true)%><BR>
<%if BankCheckAmount <> 0 then%>
							<TD class=pt12r align=left>�@�i<%=formatnumber(BankCheckAmount, 0, true)%>�j
<%end if%>
						<TR align=right height=24>
							<TD class=line align=center>�������֋�
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(StandRInit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:red" onmousedown="ShowDetail(15)"><%=gsCurrency%><%=formatnumber(StandRDebit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(16)"><%=gsCurrency%><%=formatnumber(StandRCredit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowBalance(2)"><%=gsCurrency%><%=formatnumber(StandRBalance, 0, true)%><BR>
							<TD nowrap align=center rowspan=5>
<%if Finished = 0 then%>
	<%if CheckAccountLevel() > 1 and BankCheckAmount = 0 and DepositCheckAmount = 0 then%>
		<%if GrossProfit = TaxInProfit then%>
								<INPUT class=pt12n style="width:120px;height:50px;" type=button name=btnClose value="���ߎ��s" onclick="DoClose()">	
		<%end if%>
	<%end if%>
<%else%>
								<font class=pt12r>�����ߍ�</font><br>
	<%if CheckAccountLevel() > 2 then%>
								<INPUT class=pt12n style="width:120px;height:50px;" type=button name=btnClose value="���߉���" onclick="DoUnClose()">	
	<%end if%>
<%end if%>
						<TR align=right height=24>
							<TD class=line align=center>���@�|�@��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(SalesInit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:green" onmousedown="ShowDetail(17)"><%=gsCurrency%><%=formatnumber(SalesDebit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(18)"><%=gsCurrency%><%=formatnumber(SalesCredit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowBalance(1)"><%=gsCurrency%><%=formatnumber(SalesBalance, 0, true)%><BR>
						<TR align=right height=24 class=pt12>
							<TD class=line align=center>�J�@�@�@�z
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(31)"><%=gsCurrency%><%=formatnumber(CarryOverInit, 0, true)%><BR>
<%if WebUserID = 1 then%>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(32)"><%=gsCurrency%><%=formatnumber(CarryOverDebit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(33)"><%=gsCurrency%><%=formatnumber(CarryOverCredit, 0, true)%><BR>
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(CarryOverBalance, 0, true)%><BR>
<%else%>
							<TD colspan=3><BR>
<%end if%>
						<TR align=right height=24>
							<TD class=line align=center>���@�|�@��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(CostsInit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(21)"><%=gsCurrency%><%=formatnumber(CostsCredit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:maroon" onmousedown="ShowDetail(22)"><%=gsCurrency%><%=formatnumber(CostsDebit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowBalance(3)"><%=gsCurrency%><%=formatnumber(CostsBalance, 0, true)%><BR>
						<TR align=right height=24>
							<TD class=line align=center>�������֋�
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(StandPInit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(23)"><%=gsCurrency%><%=formatnumber(StandPCredit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:red" onmousedown="ShowDetail(24)"><%=gsCurrency%><%=formatnumber(StandPDebit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowBalance(4)"><%=gsCurrency%><%=formatnumber(StandPBalance, 0, true)%><BR>
						<TR align=right height=24>
							<TD class=line align=center>�a�@��@��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(0-DepositInit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(13)"><%=gsCurrency%><%=formatnumber(DepositDebit, 0, true)%><BR>
							<TD class=line nowrap style="cursor:hand;color:blue" onmousedown="ShowDetail(14)"><%=gsCurrency%><%=formatnumber(DepositCredit, 0, true)%><BR>
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(0-DepositBalance, 0, true)%><BR>
<%if DepositCheckAmount <> 0 then%>
							<TD class=pt12r align=left>�@�i<%=formatnumber(DepositCheckAmount, 0, true)%>�j
<%end if%>
						<TR align=right height=24>
							<TD class=line align=center>���@���@�v
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(TotalInit, 0, true)%><BR>
							<TD colspan=2><BR>
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(TotalBalance, 0, true)%><BR>
						<TR align=right height=24>
							<TD colspan=3><BR>
							<TD class=line align=center>�� �� �e ��
							<TD class=line nowrap><%=gsCurrency%><%=formatnumber(GrossProfit, 0, true)%><BR>
<%if GrossProfit <> TaxInProfit then%>
							<TD class=pt12r align=left>�@�i<%=formatnumber(GrossProfit - TaxInProfit, 0, true)%>�j
<%end if%>
<%end if%>
					</table>
			</table>
		</table>
	</FORM>
</BODY></HTML>
<%
	end if

	set Recset = nothing
	CloseDB Conn
%>


<%
function GetBankCheckAmount()
dim mySql
dim myRec
	GetBankCheckAmount = 0
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	set myRec = Nothing
end function
%>