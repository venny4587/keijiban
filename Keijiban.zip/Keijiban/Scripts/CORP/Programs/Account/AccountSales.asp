<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	���|���ꗗ�Ɖ��ʁi���茳�����j���[�j
'----------------------------------------------

'on error resume next
dim myMode
dim myPage
dim myPageSize
	
	AccountBelong = GetPost(request("AccountBelong"))
	if AccountBelong = "" then AccountBelong = "O"
	
	myPageSize = 500
	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		SelDate = date
		if day(SelDate) <= gsSysCloseDay then 
			SelDate = dateadd("m", -1, SelDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
	else
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
		ClientRef = GetPost(request("ClientRef"))
		if ClientRef <> "" then	ClientCode = GetCtmCode(ClientRef, 0) 
	end if
	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
	'���R���ȊO�̏ꍇ�Ή�
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
%>
<HTML>
<HEAD>
	<TITLE>���|���ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 6 then txt = "BrokerRef"
			set win = window.open("../common/CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function
		
		sub InitForm()
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<!----------��������--------->
	<FORM METHOD="POST" ACTION="AccountSales.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<TABLE class=pt9>
			<TR><TD nowrap><font class=pt9g>���|���c��</font>�@
				���Ӑ於<img src=img/searchs.jpg style="cursor:hand" onmousedown="ShowList(1)">
					<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�Ɖ�x&nbsp;
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;��
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</TABLE>
	</FORM>
		
	<!----------��������--------->
<%
	if myMode > 0 then
%>
<div id=list>
<font color=gray>�Ώی��x�F</font><%=ShowJpnYear(SelYear)%><%=GetJapanNo(SelMonth)%>��
<%if ClientCode <> "" then response.write "<font color=gray>���Ӑ�F</font>" & getFullName(ClientCode)%>
<%			
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		
		with recset
			myBalance = 0
			if ClientCode = "" then
				'����J�z�擾
				strSql = "SELECT SUM(BIZ_AMOUNT + BIZ_TAX) AS Debit, 0 AS Credit FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J"
				strSql = strSql & " ON B.BIZ_JOBCODE = J.JobCode WHERE BIZ_DELETED = 0 AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_TYPE =" & bizSales
				strSql = strSql & " AND SalesDate < '" & AccountFrom & "'"	
				strSql = strSql & " UNION ALL "
				strSql = strSql & "SELECT 0 AS Debit, SUM(FIN_AMOUNT + FIN_TAX) AS Credit "
				strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_BELONG = '" & AccountBelong & "' AND FIN_TYPE =" & acntPreSales
				strSql = strSql & " AND FIN_DATE < '" & AccountFrom & "'"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof 
					myBalance = myBalance + GetLong(.Fields("Debit")) - GetLong(.Fields("Credit"))
					.movenext
				loop
				.Close
%>
		<TABLE width=800 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup align=left>
			<colgroup span=3 align=right>
			<colgroup align=left>
			<TR class=pt9>
				<TD class=line width=4%>��				
				<TD class=line width=15% nowrap>���t
				<TD class=line width=12% nowrap>�`�[�ԍ�
				<TD class=line width=12% nowrap>���|��
				<TD class=line width=12% nowrap>���|����
				<TD class=line width=15% nowrap>�c��
				<TD class=line width=30% nowrap>������
			<TR>
				<TD class=line colspan=2>
				<TD class=line align=center>�J�z
				<TD class=line colspan=2>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
<%
				strSql = "SELECT * FROM ("
				strSql = strSql & "SELECT BIZ_NO AS FIN_NO, BIZ_DATE AS DT, BIZ_BROKER_NAME AS ClientName, (BIZ_AMOUNT + BIZ_TAX) AS Debit, 0 AS Credit "
				strSql = strSql & ", BIZ_FIN_NO AS chk FROM TBL_CTM_BIZ INNER JOIN TBL_CTM_JOB ON TBL_CTM_BIZ.BIZ_JOBCODE = TBL_CTM_JOB.JobCode "
				strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_TYPE =" & bizSales
				strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
				strSql = strSql & " UNION ALL "
				strSql = strSql & "SELECT FIN_NO, FIN_DATE AS DT, FIN_CLIENT_NAME AS ClientName, 0 AS Debit, (FIN_AMOUNT + FIN_TAX) AS Credit "
				strSql = strSql & ", 'OK' AS chk FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_BELONG = '" & AccountBelong & "' AND FIN_TYPE =" & acntPreSales
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
				strSql = strSql & ") AS TMP ORDER BY DT, ClientName, FIN_NO"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if .EOF then
					response.write "<TR><TD colspan=6><font class=pt9r>�Y������f�[�^�͌�����܂���ł����B</font>"
				else
					cnt = 1
					myDebit = 0
					myCredit = 0
					sumDebit = 0
					sumCredit = 0
					myDate = GetString(.Fields("DT"))
					myName = GetString(.fields("ClientName"))
					do while not .EOF
						if cnt > myPageSize then exit do
						
						if myDate <> GetString(.Fields("DT")) or myName <> GetString(.Fields("ClientName")) then
							sumDebit = sumDebit + myDebit
							sumCredit = sumCredit + myCredit
%>
			<TR>
				<TD class=line align=center><%=cnt%>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line <%=ShowTitle(myNo, 13)%>><%=StringCut(myNo, 13)%>
				<TD class=line><%=formatnumber(myDebit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myCredit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
				<TD class=line><%=ResetCorpName(myName)%>
<%	
							myDebit = 0
							myCredit = 0
							myDate = GetString(.Fields("DT"))
							myName = GetString(.fields("ClientName"))
							myNo = GetString(.Fields("FIN_NO"))
							
							cnt = cnt + 1
						else
							if myNo = "" then
								myNo = myNo & GetString(.Fields("FIN_NO"))
							else
								myNo = myNo & vbcrlf & GetString(.Fields("FIN_NO"))
							end if						
						end if
					
						myDebit = myDebit + GetLong(.fields("Debit"))
						myBalance = myBalance + GetLong(.fields("Debit"))
						
						myCredit = myCredit + GetLong(.fields("Credit"))
						myBalance = myBalance - GetLong(.fields("Credit"))
						.movenext
					loop
					.Close
					
					if cnt > myPageSize then
						response.write "<TR><TD colspan=6><font class=pt9r>�Y���f�[�^�� " & myPageSize & " ���ȏ㒴���܂����B</font>"
					else
%>
			<TR>
				<TD class=line align=center><%=cnt%>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line <%=ShowTitle(myNo, 13)%>><%=StringCut(myNo, 13)%>
				<TD class=line><%=formatnumber(myDebit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myCredit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
				<TD class=line><%=ResetCorpName(myName)%>
<%
						if cnt > 1 then						
							sumDebit = sumDebit + myDebit
							sumCredit = sumCredit + myCredit
%>
			<TR>
				<TD colspan=3 align=center>���z���v
				<TD class=line><%=formatnumber(sumDebit, 0, true)%>
				<TD class=line><%=formatnumber(sumCredit, 0, true)%>
				<TD class=line>(<%=formatnumber(sumDebit - sumCredit, 0, true)%>)
<%
						end if
					end if
%>			
		</TABLE>
<%
				end if
			else			
				'����J�z�擾
				strSql = "SELECT SUM(BIZ_AMOUNT + BIZ_TAX) AS Debit, 0 AS Credit FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J"
				strSql = strSql & " ON B.BIZ_JOBCODE = J.JobCode WHERE BIZ_DELETED = 0 AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_TYPE =" & bizSales
				strSql = strSql & " AND SalesDate < '" & AccountFrom & "' AND BIZ_BROKER_CD = '" & ClientCode & "'"	
				strSql = strSql & " UNION ALL "
				strSql = strSql & "SELECT 0 AS Debit, SUM(FIN_AMOUNT + FIN_TAX) AS Credit "
				strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_BELONG = '" & AccountBelong & "' AND FIN_TYPE =" & acntPreSales
				strSql = strSql & " AND FIN_DATE < '" & AccountFrom & "' AND FIN_NO IN (SELECT DISTINCT BIZ_FIN_NO FROM TBL_CTM_BIZ"
				strSql = strSql & " WHERE BIZ_BROKER_CD = '" & ClientCode & "')"				
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof 
					myBalance = myBalance + GetLong(.Fields("Debit")) - GetLong(.Fields("Credit"))
					.movenext
				loop
				.Close
%>
		<TABLE width=800 Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=2 align=center>
			<colgroup align=left>
			<colgroup span=3 align=right>
			<colgroup align=center>
			<TR class=pt9>
				<TD class=line width=4%>��				
				<TD class=line width=15% nowrap>���t
				<TD class=line width=12% nowrap>�`�[�ԍ�
				<TD class=line width=12% nowrap>���|��
				<TD class=line width=12% nowrap>���|����
				<TD class=line width=15% nowrap>�c��
				<TD class=line width=30% nowrap>�E�v
			<TR>
				<TD class=line colspan=2>
				<TD class=line align=center>�J�z
				<TD class=line colspan=2>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
<%
				strSql = "SELECT * FROM ("
				strSql = strSql & "SELECT BIZ_DATE AS DT, BIZ_NO AS NO, (BIZ_AMOUNT + BIZ_TAX) AS Debit, 0 AS Credit, BIZ_JOBCODE AS Description "
				strSql = strSql & ", BIZ_FIN_NO AS chk FROM TBL_CTM_BIZ INNER JOIN TBL_CTM_JOB ON TBL_CTM_BIZ.BIZ_JOBCODE = TBL_CTM_JOB.JobCode "
				strSql = strSql & " WHERE BIZ_DELETED = 0 AND BIZ_BELONG = '" & AccountBelong & "' AND BIZ_TYPE =" & bizSales
				strSql = strSql & " AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "' AND BIZ_BROKER_CD = '" & ClientCode & "'"
				strSql = strSql & " UNION ALL "
				strSql = strSql & "SELECT FIN_DATE AS DT, FIN_NO AS NO, 0 AS Debit, (FIN_AMOUNT + FIN_TAX) AS Credit, FIN_BILLNO+' '+FIN_JOBCODE+' '+FIN_BATCH AS Description  "
				strSql = strSql & ", 'OK' AS chk FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_TYPE =" & acntPreSales
				strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_NO IN (SELECT DISTINCT BIZ_FIN_NO FROM TBL_CTM_BIZ"
				strSql = strSql & " WHERE BIZ_BROKER_CD = '" & ClientCode & "')"
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"	
				strSql = strSql & ") AS TMP ORDER BY DT, NO"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if .EOF then
					response.write "<TR><TD colspan=6><font class=pt9r>�Y������f�[�^�͌�����܂���ł����B</font>"
				else
					cnt = 1
					sumDebit = 0
					sumCredit = 0
					do while not .EOF
						if cnt >= myPageSize then exit do
						
						myDate = GetString(.Fields("DT"))							
						myDebit = GetLong(.fields("Debit"))
						myCredit = GetLong(.fields("Credit"))						
						myBalance = myBalance + (myDebit - myCredit)		
						
						sumDebit = sumDebit + myDebit
						sumCredit = sumCredit + myCredit
						if GetString(.fields("chk")) = "" then
							myFont = "class=pt9r"
						else
							myFont = ""
						end if
%>
			<TR <%=myFont%>>
				<TD class=line align=center><%=cnt%>
				<TD class=line><%=Str2Date(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
				<TD class=line><%=GetString(.fields("NO"))%>
				<TD class=line><%=formatnumber(myDebit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myCredit, 0, false)%><BR>
				<TD class=line><%=formatnumber(myBalance, 0, true)%>
				<TD class=line><%=StringCut(GetString(.fields("Description")), 10)%><br>
<%	
						cnt = cnt + 1
						.movenext
					loop
					.Close

					if cnt > myPageSize then
						response.write "<TR><TD colspan=6><font class=pt9r>�Y���f�[�^�� " & myPageSize & " ���ȏ㒴���܂����B</font>"
					elseif cnt > 1 then
%>
			<TR>
				<TD colspan=3 align=center>���z���v
				<TD class=line><%=formatnumber(sumDebit, 0, true)%>
				<TD class=line><%=formatnumber(sumCredit, 0, true)%>
				<TD class=line>(<%=formatnumber(sumDebit - sumCredit, 0, true)%>)
<%
					end if
%>
		</TABLE>
<%
				end if
			end if
		end with
		
		set Recset = nothing
		CloseDB Conn
%>		
</div>
<%
	end if
%>
</BODY></HTML>
