<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�����ؑݏڍ׏���ʁi����������ʂ���j
'----------------------------------------------

'on error resume next
dim mode
dim AccountBelong
dim AccountMonth
dim AccountFrom
dim AccountTo
	
	AccountBelong = GetPost(request("AccountBelong"))			'�q�ɂ̏ꍇ�͎x�X�ʕK�v
	if AccountBelong = "" then AccountBelong = "O"
	
	'���R���ȊO�̏ꍇ�Ή�
	AccountMonth = GetPost(request("AccountMonth"))
	SelYear = GetLong(left(AccountMonth, 4))
	SelMonth = GetLong(right(AccountMonth, 2))
	call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
			
	mode = GetLong(request("mode"))
	select case mode
	'------------------------------------------------------
	case 1				'�Ɩ�����
		myTitle = "�Ɩ�����"
		strSql = "SELECT JobCode AS no, SalesDate AS dt, ISNULL(CTM_NAME,'���o�^') AS name, (SalesSum+SalesTax) AS amnt, POL+'��'+POD AS memo, LockerID AS chk"
		strSql = strSql & " FROM TBL_CTM_JOB AS J LEFT JOIN (SELECT CTM_CD, CTM_NAME FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD WHERE Deleted = 0"
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY SalesDate, JobCode"
	case 2				'�Ɩ��O��
		myTitle = "�Ɩ��O��"
		strSql = "SELECT JobCode AS no, SalesDate AS dt, ISNULL(CTM_NAME,'���o�^') AS name, (CostsSum+CostsTax) AS amnt, POL+'��'+POD  AS memo, LockerID AS chk"
		strSql = strSql & " FROM TBL_CTM_JOB AS J LEFT JOIN (SELECT CTM_CD, CTM_NAME FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD WHERE Deleted = 0"
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY SalesDate, JobCode"
	case 3				'�ʐM��
		myTitle = "�ʐM��"
		strSql = "SELECT (CASE FIN_DEBIT WHEN " & acntPostage & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS amnt, FIN_NO AS no, FIN_DATE AS dt,"
		strSql = strSql & " FIN_CLIENT_NAME AS name, FIN_DESCRIPTION AS memo, ERASE_ID AS chk FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"	
		strSql = strSql & " AND (FIN_DEBIT = " & acntPostage & " OR FIN_CREDIT = " & acntPostage & ")"  
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	case 4				'�G��
		myTitle = "�G��"
		myMass = acntMassProfit & "," & acntMassLoss & "," & acntDiscount
		strSql = "SELECT (CASE FIN_CREDIT WHEN " & acntAlter & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS amnt, FIN_NO AS no, FIN_DATE AS dt,"
		strSql = strSql & " FIN_CLIENT_NAME AS name, FIN_DESCRIPTION AS memo, ERASE_ID AS chk FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"	
		strSql = strSql & " AND (FIN_DEBIT IN (" & myMass & ") OR FIN_CREDIT IN (" & myMass	& "))"  
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	'------------------------------------------------------
	case 11				'��s����
		myTitle = "��s����"
		strSql = "SELECT FIN_NO AS no, FIN_DATE AS dt, FIN_CLIENT_NAME AS name, FIN_AMOUNT AS amnt, FIN_DESCRIPTION AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_DEBIT = " & acntBank
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	case 12				'��s�o��
		myTitle = "��s�o��"
		strSql = "SELECT FIN_NO AS no, FIN_DATE AS dt, FIN_CLIENT_NAME AS name, FIN_AMOUNT AS amnt, FIN_DESCRIPTION AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_CREDIT = " & acntBank
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	case 13				'�a�������
		myTitle = "�a����ؕ�"
		strSql = "SELECT FIN_NO AS no, FIN_DATE AS dt, FIN_CLIENT_NAME AS name, FIN_AMOUNT AS amnt, FIN_DESCRIPTION AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_DEBIT = " & acntOverReceive
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	case 14				'�a�����
		myTitle = "�a����ݕ�"
		strSql = "SELECT FIN_NO AS no, FIN_DATE AS dt, FIN_CLIENT_NAME AS name, FIN_AMOUNT AS amnt, FIN_DESCRIPTION AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_CREDIT = " & acntOverReceive
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	case 15				'���֔��|
		myTitle = "���֔��|"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J ON B.BIZ_JOBCODE = J.JobCode WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandR
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 16				'���֓���
		myTitle = "���֓���"
		strSql = "SELECT BIZ_NO AS no, FIN_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, 1 AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_FIN AS F ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandR
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND FIN_TYPE IN (" & acntBank & "," & acntOverReceive & ")"
		strSql = strSql & " ORDER BY FIN_DATE, BIZ_NO"
	case 17				'�Ɩ����|
		myTitle = "�������|"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J ON B.BIZ_JOBCODE = J.JobCode WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizSales
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 18				'���|����
		myTitle = "���|����"
		strSql = "SELECT BIZ_NO AS no, FIN_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, 1 AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_FIN AS F ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizSales
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND FIN_TYPE IN (" & acntBank & "," & acntOverReceive & ")"
		strSql = strSql & " ORDER BY FIN_DATE, BIZ_NO"
		
	'------------------------------------------------------
	case 21				'���|�o��
		myTitle = "���|�o��"
		strSql = "SELECT BIZ_NO AS no, FIN_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, 1 AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_FIN AS F ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizCosts
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND FIN_TYPE IN (" & acntBank & "," & acntOverReceive & ")"
		strSql = strSql & " ORDER BY FIN_DATE, BIZ_NO"
	case 22				'�Ɩ����|
		myTitle = "�������|"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J ON B.BIZ_JOBCODE = J.JobCode WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizCosts
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 23				'���֏o��
		myTitle = "���֏o��"
		strSql = "SELECT BIZ_NO AS no, FIN_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, 1 AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_FIN AS F ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandP
		strSql = strSql & " AND BIZ_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND FIN_TYPE IN (" & acntBank & "," & acntOverReceive & ")"
		strSql = strSql & " ORDER BY FIN_DATE, BIZ_NO"
	case 24				'���֔��|
		myTitle = "���֔��|"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE AS memo, ERASE_ID AS chk"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J ON B.BIZ_JOBCODE = J.JobCode WHERE BIZ_DELETED = 0 AND BIZ_TYPE = " & bizStandP
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND SalesDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	'------------------------------------------------------
	case 31				'����J�z
		myTitle = "����J�z"
		strSql = "SELECT (CASE FIN_CREDIT WHEN " & acntCarryOver & " THEN FIN_AMOUNT ELSE 0 - FIN_AMOUNT END) AS amnt, FIN_NO AS no, FIN_DATE AS dt,"
		strSql = strSql & " FIN_CLIENT_NAME AS name, FIN_DESCRIPTION AS memo FROM TBL_CTM_FIN WHERE FIN_DELETED = 0"
		strSql = strSql & " AND FIN_BELONG = '" & AccountBelong & "' AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"	
		strSql = strSql & " AND (FIN_DEBIT = " & acntCarryOver & " OR FIN_CREDIT = " & acntCarryOver & ")"
		strSql = strSql & " ORDER BY FIN_DATE, FIN_NO"
	case 32				'�ؕ��J�z
		myTitle = "�J�z�ؕ�"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE+' '+SalesDate AS memo"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J ON B.BIZ_JOBCODE = J.JobCode INNER JOIN"
		strSql = strSql & " (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_ORIGINAL <> 0 AND FIN_DELETED = 0 AND ERASE_ID <> 0) AS F"		
		strSql = strSql & "  ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND Deleted = 0"
		strSql = strSql & " AND BIZ_TYPE IN (" & bizCosts & "," & bizStandP & ") AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND (SalesDate = '' OR SalesDate >'" & AccountTo & "')"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	case 33				'�ݕ��J�z  
		myTitle = "�J�z�ݕ�"
		strSql = "SELECT BIZ_NO AS no, BIZ_DATE AS dt, BIZ_BROKER_NAME AS name, (BIZ_AMOUNT + BIZ_TAX) AS amnt, BIZ_JOBCODE+' '+SalesDate AS memo"
		strSql = strSql & " FROM TBL_CTM_BIZ AS B INNER JOIN TBL_CTM_JOB AS J ON B.BIZ_JOBCODE = J.JobCode INNER JOIN"
		strSql = strSql & " (SELECT FIN_NO, FIN_DATE FROM TBL_CTM_FIN WHERE FIN_ORIGINAL <> 0 AND FIN_DELETED = 0 AND ERASE_ID <> 0) AS F"		
		strSql = strSql & "  ON B.BIZ_FIN_NO = F.FIN_NO WHERE BIZ_DELETED = 0 AND Deleted = 0"
		strSql = strSql & " AND BIZ_TYPE IN (" & bizSales & "," & bizStandR & ") AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " AND JobBelong = '" & AccountBelong & "' AND (SalesDate = '' OR SalesDate >'" & AccountTo & "')"
		strSql = strSql & " ORDER BY BIZ_DATE, BIZ_NO"
	'------------------------------------------------------
	end select			
if WebUserID = gsAdmin then response.write strSql						
%>
<HTML>
<HEAD>
	<TITLE>�����ߊ���Ȗږ��׏Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY class=pt9n <%=gsBodyControl%>>
	<table class=pt9n>
		<TR><TD nowrap>				
			��v���x&nbsp;<%=SelYear%>&nbsp;�N&nbsp;<%=SelMonth%>&nbsp;��&nbsp;<%=myTitle%>���׈ꗗ&nbsp;
			<TD nowrap>	
				<INPUT style="width:60px;height:25px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����" onclick="window.close()">					
	</table><br>
	<center>
<%
	with Recset
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then
%>
<div id=list>
	<table class=pt9n>
		<colgroup span=3 align=center>
		<colgroup align=left>
		<colgroup align=right>
		<colgroup align=center>
		<TR class=pt9>
			<TD class=line width=30>��
			<TD class=line width=100>���t
			<TD class=line width=90>�ԍ�
			<TD class=line width=180>����
			<TD class=line width=100>���z
			<TD class=line width=180>����
<%
			cnt = 0
			sum = 0
			do while not .eof
				cnt = cnt + 1
				sum = sum + GetLong(.fields("amnt"))
				
				myDate = GetString(.fields("dt"))
				myName = ResetCorpName(.fields("name"))
				myMemo = GetString(.fields("memo"))
				
				myColor = ""
				if mode < 15 then
					if GetLong(.fields("chk")) = 0 then myColor = " style=""color:red"""
				end if
%>
		<TR <%=myColor%>>
			<TD class=line><%=cnt%>
			<TD class=line nowrap><%=Str2YMD(myDate)%>�i<%=GetWeekDay(weekday(Str2Date(myDate)))%>�j
			<TD class=line nowrap><%=GetString(.fields("no"))%>
			<TD class=line nowrap <%=ShowTitle(myName, 20)%>><%=StringCut(myName, 20)%>
			<TD class=line nowrap><%=formatnumber(GetLong(.fields("amnt")), 0, true)%>
			<TD class=line nowrap <%=ShowTitle(myMemo, 20)%>><%=StringCut(myMemo, 20)%><BR>
<%
				.MoveNext
			loop
			if cnt > 1 then
%>
		<TR>
			<TD class=pt9 colspan=4 align=right>���v���z
			<TD class=line><%=formatnumber(sum, 0, true)%><BR>
<%
			end if
%>
	</table>
</div>
<%
		else
			response.write "<br>�Y���f�[�^�͌�����܂���ł����B"
		end if
		.Close
	end with
%>
	<br>
	</center>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>