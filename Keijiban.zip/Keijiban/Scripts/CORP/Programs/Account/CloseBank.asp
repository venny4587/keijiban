<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	��s�c���ꗗ�Ɖ��ʁi�����������j���[�j
'----------------------------------------------

dim mode
	
	BankID = GetLong(request("BankID"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mode = GetLong(request("mode"))
	if mode = 0 then
	
		SelYear = GetLong(request("SelYear"))
		SelMonth = GetLong(request("SelMonth"))
		if SelYear = 0 or SelMonth = 0 then
			SelDate = date
			if day(SelDate) <= gsSysCloseDay then 
				SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
			end if
			SelYear = year(SelDate)
			SelMonth = month(SelDate)
		end if		
		AccountMonth = SelYear & right("00" & SelMonth, 2)
	
		'���R���ȊO�̏ꍇ�Ή�
		call GetAccountMonth(AccountMonth, AccountFrom, AccountTo)
		'if AccountTo > Date2Str(date) then AccountTo = Date2Str(date)
		
		with recset
			'���߃`�F�b�N
			myCheck = 0
			strSql = "SELECT Checked FROM TBL_CTM_BANK WHERE BankID = " & BankID & " AND BankDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then myCheck = 1
			.Close
			
			if myCheck = 1 then
				strSql = "SELECT Checked FROM TBL_CTM_BANK WHERE Checked = 0 AND BankID = " & BankID & " AND BankDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then myCheck = 0
				.Close
			end if

			if myCheck = 0 then
				'�J��z���擾
				myBalance = GetInitBalance()
				
				strSql = "DELETE FROM TBL_CTM_BANK WHERE BankID = " & BankID & " AND BankDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
				conn.execute strSql					
		
				strSql = "SELECT FIN_DATE, SUM(CASE FIN_DEBIT WHEN " & acntBank & " THEN FIN_AMOUNT ELSE 0 END) AS Receive"
				strSql = strSql & ", SUM(CASE FIN_CREDIT WHEN " & acntBank & " THEN FIN_AMOUNT ELSE 0 END) AS Payment"
				strSql = strSql & " FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_BANK_ID = " & BankID
				strSql = strSql & " AND (FIN_DEBIT =" & acntBank & " OR FIN_CREDIT = " & acntBank & ")"
				strSql = strSql & " AND FIN_DATE BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
				strSql = strSql & " GROUP BY FIN_DATE ORDER BY FIN_DATE"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .EOF
					myReceive = GetLong(.fields("Receive"))
					myPayment = GetLong(.fields("Payment"))
					myBalance = myBalance + myReceive - myPayment
					
					strSql = "INSERT INTO TBL_CTM_BANK (BankID, BankDate, BankReceive, BankPayment, BankBalance, Checked)"
					strSql = strSql & " VALUES (" & BankID & ",'" & .fields("FIN_DATE") & "'," & myReceive & "," & myPayment & "," & myBalance & ",0)"
					conn.execute strSql					
					
					.movenext
				loop
				.Close
			end if
		end with
	else
		AccountFrom = GetPost(request("AccountFrom"))
		AccountTo = GetPost(request("AccountTo"))
		
		if mode = 1 then
			myCheck = 1 
		else
			myCheck = 0			
		end if
		
		strSql = "UPDATE TBL_CTM_BANK SET Checked = " & myCheck & ", Updated = GETDATE(), Updater = " & WebUserID
		strSql = strSql & " WHERE BankID = " & BankID & " AND BankDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		conn.execute strSql	
		
		if myCheck = 1 then
			msg = "�������o���f�[�^�͊m�肳��܂����B"
		else
			msg = "�������o���f�[�^�͉�������܂����B"
		end if
		SelYear = clng(left(AccountTo,4))
		SelMonth = clng(mid(AccountTo,5,2))
	end if
%>

<HTML>
<HEAD>
	<TITLE>��s�c���ꗗ�Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		sub DoClose()
			if msgbox ("�������o���f�[�^�������߂��Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = 1
			frmInput.submit()
		end sub	
		
		sub DoUnClose()
			if msgbox ("�������o���f�[�^���������Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
			frmInput.mode.value = -1
			frmInput.submit()
		end sub
		
		sub InitForm()
<%if msg <> "" then%>
			msgbox "<%=msg%>", 48, "�m�F���b�Z�[�W"
<%end if%>
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt12 onload="InitForm()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="CloseBank.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='0'>
		<INPUT TYPE="HIDDEN" NAME="AccountFrom" VALUE='<%=AccountFrom%>'>
		<INPUT TYPE="HIDDEN" NAME="AccountTo" VALUE='<%=AccountTo%>'>
		<TABLE class=pt12>
			<TR><TD nowrap>
				�����ԍ�&nbsp;<select name="BankID" class=pt12n onkeydown="ResetEnter()"><%=ShowBankList(BankID, 0)%></select>			
				��v���x&nbsp;
					<select class=pt12n name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
					<select class=pt12n name="SelMonth" onkeydown="ResetEnter()"><%
					for i = 1 to 12
						response.write "<option value=" & i
						if i = SelMonth then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;��
				<TD nowrap><INPUT class=pt12n style="width:80px;height:36px;" TYPE=SUBMIT name=btnSearch VALUE="����">
		</TABLE>
		<!----------��������--------->
<%
	cnt = 0
	with recset
		strSql = "SELECT * FROM TBL_CTM_BANK WHERE BankID = " & BankID & " AND BankDate BETWEEN '" & AccountFrom & "' AND '" & AccountTo & "'"
		strSql = strSql & " ORDER BY BankDate"
		.Open strSql,conn,adOpenStatic,adLockReadOnly
		if not .eof then
%>
		<TABLE width=650 Cellspacing=3 CellPadding=3 class=pt12n>
			<colgroup span=2 align=center>
			<colgroup span=3 align=right>
			<TR class=pt12>
				<TD class=line width=50>��
				<TD class=line width=150>���t
				<TD class=line width=150>�����z
				<TD class=line width=150>�o���z
				<TD class=line width=150>�c��
			<TR>
				<TD class=line colspan=2>����
				<TD class=line colspan=2>
				<TD class=line><%=formatnumber(GetInitBalance(),0, true)%>
<%
			do while not .EOF
				cnt = cnt + 1
				myDate = Str2Date(.fields("BankDate"))
				if datediff("d", myDate, date) < 0 then
					mycolor = "brown"
				else
					myColor = "black"
				end if
%>
			<TR style="color:<%=myColor%>">
				<TD class=line nowrap><%=cnt%>
				<TD class=line nowrap><%=myDate%>�i<%=GetWeekDay(weekday(myDate))%>�j
				<TD class=line nowrap><%=formatnumber(GetLong(.fields("BankReceive")), 0, true)%>
				<TD class=line nowrap><%=formatnumber(GetLong(.fields("BankPayment")), 0, true)%>
				<TD class=line nowrap><%=formatnumber(GetLong(.fields("BankBalance")), 0, true)%>
<%
				.MoveNext
			loop
			.Close
		end if
	end with
%>
	</TABLE>
	<BR>
	<TABLE width=650 Cellspacing=3 CellPadding=3 class=pt12n>
		<tr><td align=right>
<%if myCheck <> 0 then
	Response.Write "<font class=pt12r>�����ߍ�</font>"	
	if CheckAccountLevel() > 2 then%>
			<INPUT class=pt12n style="width:120px;height:50px;" TYPE=button VALUE="���߉���" onclick="DoUnClose()">
	<%end if
elseif cnt > 0 then%>
	<%if AccountTo < Date2Str(date) and  CheckAccountLevel() > 1 then%>
			<INPUT class=pt12n style="width:120px;height:50px;" TYPE=button VALUE="���ߎ��s" onclick="DoClose()">
	<%end if%>
<%end if%>
	</TABLE>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
'�J��z���擾
function GetInitBalance()
dim mySql
dim myRec
	GetInitBalance = 0
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT BankDate, BankBalance FROM TBL_CTM_BANK WHERE BankID = " & BankID & " AND BankDate < '" & AccountFrom & "'"
		mySql = mySql & " ORDER BY BankDate DESC"
		.Open mySql,conn,adOpenStatic,adLockReadOnly
		if not .eof then 
			GetInitBalance = GetLong(.fields("BankBalance"))
		end if
		.Close
	end with
	set myRec = nothing
end function
%>