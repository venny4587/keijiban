<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/account.asp" -->
<%
'----------------------------------------------
'	�����o���`�[�������
'
'			���s		��������	�o���m��
'	�`�[	�|�|		Finished	�|�|
'	�Ɩ�	Confrim		Erase		�|�|
'	����	Link		Erase		Confirm
'
'----------------------------------------------

'on error resume next
dim mode
dim myType

	mode = GetLong(request("mode"))
	myType = GetPost(request("type"))
	FIN_NO = GetPost(request("FIN_NO"))
	FIN_BILLNO = GetPost(request("FIN_BILLNO"))
				
	OpenSql Conn, SqlServerName, DataBaseName		
	set Recset = Server.CreateObject("adodb.recordset") 		
	
	if FIN_NO = "" then
		ConfirmerID = 0
		FinisherID = 0
		if FIN_BILLNO <> "" then
			with Recset
				strSql = "SELECT JobCode, CostsNo,CostsBelong, CostsClient, CostsClientName, CostsPic, CostsPayDay, CostsAmount, CostsTax, ConfirmerID, FinisherID"
				strSql = strSql & " FROM TBL_CTM_COSTS WHERE CostsNo = '" & FitSel(FIN_BILLNO) & "'"
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				if not .eof then
					FIN_JOBCODE = GetString(.fields("JobCode"))
					FIN_BELONG = GetString(.fields("CostsBelong"))
					FIN_CLIENT_CD = GetString(.fields("CostsClient"))
					FIN_CLIENT_NAME = GetString(.fields("CostsClientName"))
					FIN_CLIENT_PIC = GetString(.fields("CostsPic"))
					FIN_DATE = Str2Date(.fields("CostsPayDay"))
					FIN_AMOUNT = GetLong(.fields("CostsAmount")) + GetLong(.fields("CostsTax"))
					ConfirmerID = GetLong(.fields("ConfirmerID"))
					FinisherID = GetLong(.fields("FinisherID"))
				end if
				.Close
			end with
			if ConfirmerID = 0 then
				msg = "�Y���x���`�[�͂܂��m�肳��Ă��܂���B"
			elseif FinisherID <> 0 then
				msg = "�Y���x���`�[�͊��ɏo������܂����B"
			end if
		end if
		if msg = "" then
			FIN_TYPE = acntBank
			FIN_DATE = formatDate(date)
			FIN_SECURITIES = "���؎�"
			ERASE_ID = 0
		end if
	else
		mode = 0
		with Recset
			strSql = "SELECT * FROM TBL_CTM_FIN WHERE FIN_DELETED = 0 AND FIN_ORIGINAL = 1 AND FIN_NO = '" & FitSel(FIN_NO) & "'"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then
				mode = 1
				FIN_NO = GetString(.fields("FIN_NO"))
				FIN_DATE = Str2Date(.fields("FIN_DATE"))
				FIN_TYPE = GetLong(.fields("FIN_TYPE"))
				FIN_BELONG = GetString(.fields("FIN_BELONG"))
				FIN_CLIENT_CD = GetString(.fields("FIN_CLIENT_CD"))	
				FIN_CLIENT_NAME = GetString(.fields("FIN_CLIENT_NAME"))	
				FIN_CLIENT_PIC = GetString(.fields("FIN_CLIENT_PIC"))
				FIN_BANK_ID = GetLong(.fields("FIN_BANK_ID"))
				FIN_AMOUNT = GetLong(.fields("FIN_AMOUNT"))
				FIN_SECURITIES = GetString(.fields("FIN_SECURITIES"))
				FIN_SECURITIES_NO = GetString(.fields("FIN_SECURITIES_NO"))
				FIN_SECURITIES_DATE = Str2Date(.fields("FIN_SECURITIES_DATE"))
				
				FIN_BATCH = GetString(.fields("FIN_BATCH"))
				FIN_BILLNO = GetString(.fields("FIN_BILLNO"))
				FIN_JOBCODE = GetString(.fields("FIN_JOBCODE"))
				FIN_DESCRIPTION = GetString(.fields("FIN_DESCRIPTION"))	
				FIN_MEMO = GetString(.fields("FIN_MEMO"))
				FIN_REMARKS = GetString(.fields("FIN_REMARKS"))	
				
				FIN_CREATER = GetLong(.fields("FIN_CREATER"))
				FIN_CREATED = GetDate(.fields("FIN_CREATED"))
				CONFIRM_ID = GetLong(.fields("CONFIRM_ID"))
				CONFIRM_DATE = GetDate(.fields("CONFIRM_DATE"))
				ERASE_ID = GetLong(.fields("ERASE_ID"))
				ERASE_DATE = GetDate(.fields("ERASE_DATE"))
				FIN_MONTH = GetString(.fields("FIN_MONTH"))
			end if
			.close
		end with
		
		if mode = 0 then
			msg = "�Y���o���`�[�݂͂���܂���ł����B"
		end if
	end if
	
	AccountMonth = CheckAccountMonth()
	AccountMonth = left(AccountMonth, 4) & "/" & right(AccountMonth, 2)
	
	if msg <> "" then
		response.write msg
	else
%>
<html>
<HEAD>
	<TITLE>�o���`�[��������</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>			
		sub DoSearch()
			dim win
			set win = window.open("ClientSearch.asp?mode=1&cd=" & frmInput.ClientRef.value,"ClientSearch","resizable=1,scrollbars=1,width=800,height=600")
		end sub	
		
		sub DoDelete()
			if msgbox ("�Y���o���`�[���폜���Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = -1
				frmInput.submit()
			end if
		end sub
			
		sub DoUnLock()
			if msgbox ("�Y���o���m����������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 5
				frmInput.submit()
			end if
		end sub		
		
		sub DoLock()
			if frmInput.FIN_SECURITIES.options(frmInput.FIN_SECURITIES.selectedIndex).value = "���؎�" then
				if checkDate("FIN_SECURITIES_DATE","���؎軲�", 1) = false then exit sub
			end if
			if msgbox ("�Y���o���`�[���o���m�肵�Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 4
				frmInput.submit()
			end if
		end sub		
		
		sub DoUnErase()
			if msgbox ("�Y���o���`�[�̏������݂��������Ă�낵���ł����H",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.mode.value = 3
				frmInput.submit()
			end if
		end sub		
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
<%if ERASE_ID = 0 then%>
			if window.event.keyCode=120 then call DataSave(<%=mode%>) 
<%end if%>
		end sub
		
		sub DataSave(mode)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > 0 AND GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'				exit sub
'			end if 
			if GetLong(frmInput.BankPostage.value) > <%=gsMaxPostage%> then 
				msgbox "���͂����ʐM��͑������ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			elseif clng(frmInput.EraseResult.value) <> 0 then 
				msgbox "�ؕ����z�͑ݕ����z�ƍ���Ȃ��ł��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if GetLong(frmInput.FromReceive.value) <> 0 and _
			   GetLong(frmInput.OverReceive.value) <> 0 then
				msgbox "�u�a������v�Ɓu�a����ցv�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if 
			if GetLong(frmInput.MassProfit.value) <> 0 and _
			   GetLong(frmInput.MassLoss.value) <> 0 then
				msgbox "�u�G���v�Ɓu�G���v�͓������͂ł��܂���B", 48, "�m�F���b�Z�[�W" 
				exit sub
			end if 
			if checkDate("FIN_DATE","�o����", 1) = false then exit sub
			if left(frmInput.FIN_DATE.value, 7) <= "<%=AccountMonth%>" then
				frmInput.FIN_DATE.focus()
				msgbox "�Y�����x�͊��Ɍ����߂���Ă��܂��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkNum("FIN_AMOUNT","�o���z", 2) = false then exit sub
			if checkText("FIN_DESCRIPTION","�o���K�v", 0) = false then exit sub
			if checkDate("FIN_SECURITIES_DATE","��`���", 0) = false then exit sub
			if checkText("FIN_SECURITIES_NO","��`�ԍ�", 0) = false then exit sub
			if checkText("FIN_MEMO","�o������", 0) = false then exit sub
			if checkLen("FIN_MEMO","�o������", 250) = false then exit sub
			if checkText("Remarks","�o�����l", 0) = false then exit sub
			if checkLen("Remarks","�o�����l", 250) = false then exit sub
			if mode = 2 then
				if msgbox ("�Y���o���`�[���������݂��Ă�낵���ł����H", <%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
				frmInput.btnLock.disabled = true
			else
<%if gsPolite = 1 then%>
				if msgbox ("�f�[�^��ۑ����Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") <> 1 then exit sub
<%end if%>
				frmInput.btnSave.disabled = true
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
				
		sub FIN_DATE_Onblur()
			frmInput.FIN_DATE.value = setdate(frmInput.FIN_DATE.value)
		end sub		
		sub FIN_AMOUNT_Onblur()
			frmInput.FIN_AMOUNT.value = formatnumber(GetLong(frmInput.FIN_AMOUNT.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub FIN_SECURITIES_DATE_Onblur()
			frmInput.FIN_SECURITIES_DATE.value = setdate(frmInput.FIN_SECURITIES_DATE.value)
		end sub		
		
		sub OverReceive_OnBlur()
			frmInput.OverReceive.value = formatnumber(GetLong(frmInput.OverReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub FromReceive_OnBlur()
			frmInput.FromReceive.value = formatnumber(GetLong(frmInput.FromReceive.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
'�ߏo�ł��邽��
'			if GetLong(frmInput.FromReceive.value) > 0 AND GetLong(frmInput.FromReceive.value) > GetLong(frmInput.FIN_DEPOSIT.value) then
'				msgbox "�a��������̋��z�͌��݂̗a������c�����傫���Ȃ�܂����B", 48, "�m�F���b�Z�[�W" 
'			end if 
		end sub		
		sub MassProfit_OnBlur()
			frmInput.MassProfit.value = formatnumber(GetLong(frmInput.MassProfit.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub MassLoss_OnBlur()
			frmInput.MassLoss.value = formatnumber(GetLong(frmInput.MassLoss.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub		
		sub BankPostage_OnBlur()
			frmInput.BankPostage.value = formatnumber(GetLong(frmInput.BankPostage.value), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end sub	
		function DoCalculate()
		dim debit, credit 
			debit = GetLong(frmInput.CostsAmount.value) + GetLong(frmInput.FromReceive.value) + GetLong(frmInput.MassLoss.value)
			debit = debit + GetLong(frmInput.BankPostage.value)
			credit = GetLong(frmInput.FIN_AMOUNT.value) + GetLong(frmInput.OverReceive.value) + GetLong(frmInput.MassProfit.value)
			DoCalculate = debit - credit
		end function	
		
		function DoUseDeposit(myAmount)
			frmInput.FromReceive.value = formatnumber(GetLong(myAmount), 0, true)
			frmInput.EraseResult.value = formatnumber(DoCalculate(), 0, true)
		end function	
	</SCRIPT>
</Head>
<body leftmargin=10 topmargin=10 class=pt12 onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
<FORM name=frmInput action="PaymentSave0.asp" method=post>
	<input type=hidden name="mode" value="<%=mode%>">
	<input type=hidden name="type" value="<%=myType%>">
	<input type=hidden name="FIN_NO" value="<%=FIN_NO%>">
	<input type=hidden name="FIN_TYPE" value="<%=FIN_TYPE%>">
	<input type=hidden name="FIN_BELONG" value="<%=FIN_BELONG%>">
	<input type=hidden name="FIN_JOBCODE" value="<%=FIN_JOBCODE%>">
	<input type=hidden name="FIN_CLIENT_CD" value="<%=FIN_CLIENT_CD%>">
	
<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
  <tr><td width=50% valign=top>
  <!--�����F�o���`�[���-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=28 valign=bottom>
	  	<td width=50%>���o���`�[���&nbsp;
<%if mode = 1 and ERASE_ID = 0 then%>
		<img style="cursor:hand" src=img/waste.jpg alt="�폜" onmousedown="DoDelete()">
<%end if%>
	  	<td width=50% nowrap><%if mode = 1 then%>�o���`�[�F<%=FIN_NO%><%end if%>
	</table>
	<hr width=98% size=1 color=blue>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12>
	  <TR height=30>
		<TD nowrap colspan=2>
			�x����<input type=hidden name="ClientCode" value="<%=FIN_CLIENT_CD%>">
				<input class=mi name="ClientRef" size=8 maxlength=10 value="<%=GetRefName(FIN_CLIENT_CD)%>" onkeydown="ResetEnter()">
				<%if CONFIRM_ID = 0 then%><a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="����"></a><%end if%>
				<input class=mj name="ClientName" size=32 maxlength=50 value="<%=FIN_CLIENT_NAME%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD nowrap>
			����S��&nbsp;<input class=mj name="FIN_CLIENT_PIC" size=20 value="<%=FIN_CLIENT_PIC%>" onkeydown="ResetEnter()" readonly>
		<TD nowrap class=pt12n>
			�o����&nbsp;<input class=mi name="FIN_DATE" size=10 value="<%=FIN_DATE%>" onkeydown="ResetEnter()"
				<%if ERASE_ID = 0 then%>onclick="setday(this)"<%end if%>>
	  <TR height=30>
		<TD nowrap colspan=2 class=pt12n>
			�o����s&nbsp;<select name="FIN_BANK_ID" class=pt12n onkeydown="ResetEnter()" <%if ERASE_ID <> 0 then response.write "disabled"%>>
				<%=ShowBankList(FIN_BANK_ID, finPayment)%></select>
	  <TR height=30>
		<TD nowrap colspan=2>
			�o���K�v&nbsp;<input class=mz name="FIN_DESCRIPTION" size=40 value="<%=FIN_DESCRIPTION%>" onkeydown="ResetEnter()">
	  <TR height=30>
		<TD nowrap>
			�x���ԍ�&nbsp;<input class=mi name="FIN_BILLNO" size=10 value="<%=FIN_BILLNO%>" onkeydown="ResetEnter()" readonly>
		<TD nowrap>
	  		����&nbsp;<select name="FIN_SECURITIES" class=pt12n onkeydown="ResetEnter()" <%if ERASE_ID <> 0 then response.write "disabled"%>>
	  			<%=ShowCategoryList("Securities", FIN_SECURITIES, 0)%></select>
	  <TR height=30>
		<TD nowrap>
			����ԍ�&nbsp;<input class=mi name="FIN_SECURITIES_NO" size=16 maxlength=20 value="<%=FIN_SECURITIES_NO%>" onkeydown="ResetEnter()">
		<TD nowrap>
			�T�C�g<input class=mn name="FIN_SECURITIES_DATE" size=10 maxlength=10 value="<%=FIN_SECURITIES_DATE%>" onkeydown="ResetEnter()"
				<%if ERASE_ID = 0 then%> onclick="setday(this)"<%end if%>>
	  <tr>
	  	<td><img src=img/spacer.jpg height=3>
	  <TR>
		<TD colspan=2>�o������<br><textarea class=pt12n name="FIN_MEMO" rows=3 style="width:400" readonly><%=FIN_MEMO%></textarea>
	  <TR>
	  	<TD><img src=img/spacer.jpg height=3>
<%if FIN_CURRENT = 0 AND Remarks <> "" then%>
	  <TR>
		<TD colspan=2>��������<br><textarea class=mz name="Remarks" rows=3 style="width:400" readonly><%=Remarks%></textarea>
<%end if%>
	</TABLE>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=30 align=center valign=bottom>
		<TD width=10% class=pt12g>�쐬��<TD width=15% class=gline><%=GetEmployName(FIN_CREATER, "F")%><br>
		<TD width=10% class=pt12g>������<TD width=15% class=gline><%=GetEmployName(ERASE_ID, "F")%><br>
		<TD width=10% class=pt12g>�m�F��<TD width=15% class=gline><%=GetEmployName(CONFIRM_ID, "F")%><br>
	  <TR height=30 align=center valign=bottom>
		<TD class=pt12g>�쐬��<TD class=gline><%=formatDate(FIN_CREATED)%><br>
		<TD class=pt12g>������<TD class=gline><%=formatDate(ERASE_DATE)%><br>
		<TD class=pt12g>�m�F��<TD class=gline><%=formatDate(CONFIRM_DATE)%><br>
	</TABLE>
	<br>
<%
dim FIN_DEPOSIT

	myList = ShowAccountDetail(finPayment, Conn, FIN_NO, FIN_CLIENT_CD, FIN_DEPOSIT)
%>
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR height=22 valign=bottom>
	  	<td width=50% nowrap>���a����c���F&nbsp;<input type=hidden name="FIN_DEPOSIT" value="<%=FIN_DEPOSIT%>">
<%if FIN_DEPOSIT >= 0 then%>
	  	<td width=50% nowrap align=right>\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%else%>
	  	<td width=50% nowrap align=right style="color:red">\<%=formatnumber(FIN_DEPOSIT, 0 ,true)%>�~
<%end if%>
	</table>
	<HR width=100% size=1 color=green>
  <!--�����F�c�����׏��-->
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
	<TR align=center height=20 class=pt12>
		<TD class=line nowrap>��
		<TD class=line nowrap>�`�[�ԍ�
		<TD class=line nowrap>���o����
		<TD class=line nowrap>�a�����
		<TD class=line nowrap>�a������
		<TD class=line nowrap>�c��
	<%=myList%>
	</TABLE>
		
  <td width=50% valign=top>	
  <!--�E���F�Ɩ��������-->
	<table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt12n>
	  <TR valign=bottom align=right>
	  	<td width=50% nowrap>�x���`�[�F<%=FIN_BILLNO%>
		<td width=50%>
<%if CONFIRM_ID <> 0 then%>
	<%if FIN_MONTH = "" and CheckAccountLevel() > 1 then%>
	  	  <img style="cursor:help" src=img/unlock.jpg alt="�m�����" onmousedown="DoUnLock()">
	<%else%>
	  	  <img style="cursor:help" src=img/lock.jpg alt="�m���">
	<%end if%>
<%elseif ERASE_ID <> 0 then%>
		  <img style="cursor:hand" src=img/check.jpg alt="�m��" onmousedown="DoLock()">
<%else%>
	<%if mode = 1 then%>
		<%if CheckAccountLevel() > 0 then%>
	  	  <img style="cursor:help" src=img/erase.jpg alt="����" onmousedown="DataSave(2)">
		<%end if %>
	<%else%>
	  	  <img style="cursor:hand" src=img/save.jpg alt="�ۑ�" onmousedown="DataSave(1)">
	<%end if%>
<%end if%>
	</table>
	<hr width=98% size=1 color=blue>
<%
	msg = ""
	CostsAmount = 0
	if FIN_BILLNO <> "" then
		with Recset
			strSql = "SELECT CostsNo, CostsDate, CostsPayDay, CostsBillNo, CostsAmount + CostsTax AS CostsTotal, ConfirmerID, FinisherID"	
			strSql = strSql & " FROM TBL_CTM_COSTS WHERE Deleted = 0 AND CostsNo = '" & FIN_BILLNO & "'"
			.Open strSql, conn, adOpenStatic, adLockReadOnly
			if not .EOF then
				if GetLong(.Fields("ConfirmerID")) = 0 then					'�Ɩ����m��
					status = "<font color=gray>��</font>"
				else
					myFinNo = CheckEtcErased(conn, FIN_NO, FIN_BILLNO, 1)
					if myFinNo <> "" then									'���ɏo���ρi�����Ŏ����A������폜���Ȃ���΂Ȃ�܂���j
						status = ResetBizNo(myFinNo)
					else
						status = "<img src=img/checked.jpg><br>"
						CostsAmount = GetLong(.Fields("CostsTotal"))
					end if
				end if
%>
	<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt12n>
		<TR align=center height=20 class=pt12>
			<TD class=line nowrap>�퐿����
			<TD class=line nowrap align=left>���萿����
			<TD class=line nowrap>�x����
			<TD class=line nowrap align=right>�x�����z
			<TD class=line nowrap>�I��
		<TR align=center height=20>
			<TD nowrap class=line><%=Str2YMD(.Fields("CostsDate"))%><BR>
			<TD nowrap class=line align=left <%=ShowTitle(.Fields("CostsBillNo"), 20)%>><%=StringCutRev(GetString(.Fields("CostsBillNo")), 20)%><BR>
			<TD nowrap class=line><%=Str2YMD(.Fields("CostsPayDay"))%><BR>
			<TD nowrap class=line align=right><%=formatnumber(GetLong(.Fields("CostsTotal")), 0, true)%><BR>
			<TD class=line><%=status%>
	</TABLE>
<%			
			else
				msg = "�Y������x���`�[�͌�����܂���ł����B"
			end if
			.Close
		end with
		if msg <> "" then response.write "<br><div align=center class=pt12r>" & msg & "</div>"
	end if
%>
	<br>		
	<hr width=98% size=1 color=green>
	<br>
<%
	if FIN_NO = "" and CostsAmount = 0 and FIN_BILLNO <> "" then	
		response.write "<br><div align=center class=pt12r>�Y������x���`�[�͏o�������ł�����B</div>"
		response.write "<br><div align=center class=pt12b>�c�Ƃɒ����Ă���o��������i��ł��������B</div>"
		response.write "<br><div align=left class=pt12n>�o����F" & FIN_CLIENT_NAME & "</div>"								
		response.write "<br><div align=left class=pt12n>�c�ƒS���F" & GetSalesManager(FIN_CLIENT_CD) & "</div>"	
	else		
		FromReceive = 0
		OverReceive = 0
		MassProfit = 0
		MassLoss = 0
		BankPostage = 0		
		if mode = 1 then
			with Recset
				strSql = "SELECT FIN_NO, FIN_TYPE, FIN_DEBIT, FIN_CREDIT, FIN_AMOUNT, FIN_BANK_ID FROM TBL_CTM_FIN"
				strSql = strSql & " WHERE FIN_DELETED = 0 AND FIN_NO = '" & FIN_NO & "'"
if WebUserID = gsAdmin then response.write strSQL
				.Open strSql,conn,adOpenStatic,adLockReadOnly
				do while not .eof
					select case GetLong(.Fields("FIN_DEBIT"))
					case acntOverReceive
						FromReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a������
					case acntMassLoss
						MassLoss = GetLong(.Fields("FIN_AMOUNT"))						'�G����
					case acntPostage
						BankPostage = GetLong(.Fields("FIN_AMOUNT"))					'�ʐM��
					end select
					
					select case GetLong(.Fields("FIN_CREDIT"))
					case acntOverReceive
						OverReceive = GetLong(.Fields("FIN_AMOUNT"))					'�a�����
					case acntMassProfit
						MassProfit = GetLong(.Fields("FIN_AMOUNT"))						'�G�v��
					case acntPostage
						BankPostage = 0 - GetLong(.Fields("FIN_AMOUNT"))				'�ʐM��
					end select
					.movenext
				loop
				.close
			end with
		end if		
		EraseResult = CostsAmount + FromReceive + MassLoss - FIN_AMOUNT - OverReceive - MassProfit
		EraseResult = EraseResult + BankPostage
%>
	<TABLE width=98% Cellspacing=3 CellPadding=3 class=pt12n>
	  <TR align=center height=20>
		<TD class=line colspan=2>�ؕ�
		<TD class=line colspan=2>�ݕ�	
			
	  <TR align=center height=20>
		<TD class=line>���z
		<TD class=line>�Ȗ�
		<TD class=line>�Ȗ�
		<TD class=line>���z
		
	  <TR align=right height=20>
		<TD><input class=mn name="CostsAmount" size=9 maxlength=9 value="<%=formatnumber(CostsAmount,0,true)%>" onkeydown="ResetEnter()" Readonly>
		<TD align=left>�@�O��
		<TD><font color=blue>�o��</font>
		<TD><input class=mn name="FIN_AMOUNT" size=9 maxlength=9 value="<%=formatnumber(FIN_AMOUNT,0,true)%>" onkeydown="ResetEnter()">
		
	  <TR align=right height=20>
		<TD><input class=mn name="FromReceive" size=9 maxlength=9 value="<%=formatnumber(FromReceive, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left nowrap>�@�a������
		<TD>�a����
		<TD><input class=mn name="OverReceive" size=9 maxlength=9 value="<%=formatnumber(OverReceive, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20>
		<TD><input class=mn name="MassLoss" size=9 maxlength=9 value="<%=formatnumber(MassLoss, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@�G��
		<TD>�G��
		<TD><input class=mn name="MassProfit" size=9 maxlength=9 value="<%=formatnumber(MassProfit, 0, true)%>" onkeydown="ResetEnter()">

	  <TR align=right height=20>
		<TD><input class=mn name="BankPostage" size=9 maxlength=9 value="<%=formatnumber(BankPostage, 0, true)%>" onkeydown="ResetEnter()">
		<TD align=left>�@�ʐM��
		<TD nowrap>�o���s��
		<TD><input class=mn name="EraseResult" size=9 maxlength=9 value="<%=formatnumber(EraseResult, 0, true)%>" onkeydown="ResetEnter()" Readonly>

	  <TR align=right height=49>
	  	<TD>
	  	
	  <TR align=center height=20>
	  	<TD colspan=4 align=center>
	  		<HR width=100% size=1 color=green>
	  	
	  <TR align=center height=20>
	  	<TD colspan=4 align=center>
<%if CONFIRM_ID <> 0 then%>
	<%if FIN_MONTH = "" and CheckAccountLevel() > 1 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnUnLock value="�o���m�����" onclick="DoUnLock()">
	<%end if%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnClose value="��ʕ���" onclick="window.close()">
<%elseif ERASE_ID <> 0 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnUnLock value="�o�������m��" onclick="DoLock()">
	<%if FIN_MONTH = "" and CheckAccountLevel() > 1 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnUnLock value="�o����������" onclick="DoUnErase()">
	<%end if%>
<%else%>
	<%if mode = 1 then%>
		<%if CheckAccountLevel() > 0 then%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnLock value="�o���������s" onclick="DataSave(2)">
		<%end if %>
	<%else%>
			<INPUT type=button class=pt12n style="WIDTH: 140px; HEIGHT: 40px;" name=btnSave value="�o���`�[���s" onclick="DataSave(1)">
	<%end if%>
<%end if%>
	</TABLE>
<%	
	end if
%>
</FORM>
<center>
<%if ERASE_ID <> 0 then%>
<script language=vbscript>
	call LockAll()
</script>
<%end if%>
</body></html>
<%	
	end if
	
	set Recset = nothing
	CloseDB Conn
%>
