<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/Account.asp" -->
<%
'----------------------------------------------
'	�Ɩ����ь��ʐ��ڕ\�i�����������j���[�j
'----------------------------------------------
	
	AccountBelong = GetPost(request("SelBranch"))				'�q�ɂ̏ꍇ�͎x�X�ʕK�v
	if AccountBelong = "" then AccountBelong = "O"
		
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
					
	SelYear = GetLong(request("SelYear"))
	if SelYear = 0 then 
		SelYear = year(date)
		if month(date) < 5 then SelYear = SelYear - 1
	end if
	
	call GetAccountYear(SelYear, AccountFrom, AccountTo)
	curYear = left(Date2Str(date), 6)
	if AccountTo > curYear then AccountTo = curYear
%>

<HTML>
<HEAD>
	<TITLE>�Ɩ����ь��ʐ��ڕ\</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<script language=vbscript src="../common/css/function.vbs"></script>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="CloseMonthly.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="AccountBelong" VALUE='<%=AccountBelong%>'>
		<INPUT TYPE="HIDDEN" NAME="AccountMonth" VALUE='<%=AccountMonth%>'>
		<input type=hidden name="sort" value="<%=mySort%>">
		<table class=pt9>
			<TR><TD nowrap class=pt9>�Ώ۔N�x&nbsp;
					<select name="SelYear" onkeydown="ResetEnter()"><%
					for i = year(date) to year(gsSysStart) step -1
						response.write "<option value=" & i
						if i = SelYear then response.write " selected"
						response.write ">" & i
					next%></select>&nbsp;�N
				<TD nowrap><INPUT class=pt9n style="width:80px;height:30px;" TYPE=SUBMIT name=btnSearch VALUE="����">
					<INPUT class=pt9n style="width:80px;height:30px;" TYPE=button name=btnCopy VALUE="�R�s�[" onclick="DoCopy('list')">	
		</table>
	</form>
<div id=list>
�Ώ۔N�x�F<%=ShowJpnYear(left(AccountFrom,4))%><%=GetJapanNo(right(AccountFrom,2))%>���`<%=ShowJpnYear(left(AccountTo,4))%><%=GetJapanNo(right(AccountTo,2))%>��
		
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup align=right>
		<colgroup span=4 align=right bgcolor="#F0F0FF">
		<colgroup span=4 align=right>
		<colgroup span=4 align=right bgcolor="#FFF0F0">
		<colgroup span=4 align=right>
		<colgroup span=4 align=right bgcolor="#F0FFF0">
		<colgroup span=4 align=right>
		<colgroup align=right>
		<TR bgcolor="#E0E0E0">
			<TD rowspan=2 align=center>�N��
			<TD colspan=4 align=center>�� �s �� ��
			<TD colspan=4 align=center>�a�@��@��
			<TD colspan=4 align=center>�������֋�
			<TD colspan=4 align=center>���@�|�@��
			<TD colspan=4 align=center>���@�|�@��
			<TD colspan=4 align=center>�������֋�
			<TD rowspan=2 align=center>�e ��				
		<TR>
			<TD nowrap>�J�z
			<TD nowrap>�ؕ�
			<TD nowrap>�ݕ�
			<TD nowrap>�c��
			<TD nowrap>�J�z
			<TD nowrap>�ؕ�
			<TD nowrap>�ݕ�
			<TD nowrap>�c��
			<TD nowrap>�J�z
			<TD nowrap>�ؕ�
			<TD nowrap>�ݕ�
			<TD nowrap>�c��
			<TD nowrap>�J�z
			<TD nowrap>�ؕ�
			<TD nowrap>�ݕ�
			<TD nowrap>�c��
			<TD nowrap>�J�z
			<TD nowrap>�ؕ�
			<TD nowrap>�ݕ�
			<TD nowrap>�c��
			<TD nowrap>�J�z
			<TD nowrap>�ؕ�
			<TD nowrap>�ݕ�
			<TD nowrap>�c��
<%
	with recset
		strSql = "SELECT * FROM TBL_CTM_ACCOUNT WHERE AccountBelong = '" & AccountBelong & "' AND AccountMonth BETWEEN '" & AccountFrom & "'AND '" & AccountTo & "'"
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		do while not .EOF				
			if GetLong(.fields("Finished")) = 0 then
				response.write "<TR height=30 style=""color:#808080"">"
			else
				response.write "<TR height=30>"
			end if
			response.write "<TD nowrap>" & GetJapanNo(right(GetString(.Fields("AccountMonth")),2)) & "��"
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("BankInit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("BankDebit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("BankCredit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("BankBalance")), 0, true)
			
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("DepositInit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("DepositDebit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("DepositCredit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("DepositBalance")), 0, true)
			
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandRInit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandRDebit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandRCredit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandRBalance")), 0, true)
			
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("SalesInit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("SalesDebit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("SalesCredit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("SalesBalance")), 0, true)
			
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("CostsInit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("CostsDebit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("CostsCredit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("CostsBalance")), 0, true)
			
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandPInit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandPDebit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandPCredit")), 0, true)
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("StandPBalance")), 0, true)
			
			response.write "<TD nowrap>" & formatnumber(GetLong(.Fields("GrossProfit")), 0, true)
				
			.movenext
		loop
		.Close
	end with	
%>
	</TABLE>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>
	
	
	