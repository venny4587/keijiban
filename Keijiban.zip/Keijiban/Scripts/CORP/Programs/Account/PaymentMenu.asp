
<html>
<head>
	<title>�o���������j���[</title>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet href="../common/css/style.css" type=text/css>
</head>

<BODY <%=gsBodyControl%>>
	<SCRIPT LANGUAGE=vbscript>
	<!--
	
	Sub DoAct(mySel)
		btnCreate.style.color = "black"
		btnClose.style.color = "black"
		btnProc.style.color = "black"
		btnCheck.style.color = "black"
		btnView.style.color = "black"
		select case mySel
		case 1
			url = "PaymentCreate.asp"
			rst = "PaymentResult.asp?type=0"
			btnCreate.style.color = "red"
		case 2
			url = "PaymentClose.asp"
			rst = "PaymentResult.asp?type=1"
			btnClose.style.color = "red"
		case 3
			url = "PaymentProc.asp"
			rst = "PaymentResult.asp?type=2"
			btnProc.style.color = "red"
		case 4
			url = "PaymentCheck.asp"	
			rst = "PaymentResult.asp?type=3"
			btnCheck.style.color = "red"
		case 5
			url = "PaymentView.asp"	
			rst = "../common/blank.htm"
			btnView.style.color = "red"
		end select
		window.parent.cbody.location.href = url 
		window.parent.parent.result.location.href = rst
	End Sub

	//-->
	</SCRIPT>
<TABLE width=100% border=0>
	<TR><TD>
		<TABLE border=0 cellSpacing=0 cellPadding=0>  
		  <TR>
		    <TD width=140>
		    	<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px;" name=btnCreate value="�����o��" onclick="DoAct(1)"></TD>
		    <TD width=140>
		    	<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px;" name=btnClose value="�����o��" onclick="DoAct(2)"></TD>
		    <TD width=140>
		    	<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px;" name=btnProc value="�o������" onclick="DoAct(3)"></TD>
		    <TD width=140>
				<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px;" name=btnCheck value="�o���m��" onclick="DoAct(4)"></TD>
		    <TD width=140>
				<INPUT type=button class=pt9n style="WIDTH: 100px; HEIGHT: 30px;" name=btnView value="�o���Ɖ�" onclick="DoAct(5)"></TD>
		  </TR>
		</TABLE>
	</TD></TR>
</TABLE>
<HR>
</BODY>
</html>
