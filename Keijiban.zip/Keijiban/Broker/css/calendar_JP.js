//  066280 --> 066280
//  FFD700 --> FFD700
//	FFFFFF --> FFFFFF
//  D7EBFF --> D7EBFF
//  00ffff --> 00ffff
//	ffffff --> ffffff
	
var bMoveable=true; 
var _VersionInfo="" ;
//==================================================== 
var strFrame;
document.writeln('<iframe id=DateLayer frameborder=0 style="position: absolute; width: 144; height: 211; z-index: 9998; display: none"></iframe>'); 
strFrame='<style>'; 
strFrame+='INPUT.button{BORDER-RIGHT: #066280 1px solid;BORDER-TOP: #066280 1px solid;BORDER-LEFT: #066280 1px solid;'; 
strFrame+='BORDER-BOTTOM: #066280 1px solid;BACKGROUND-COLOR: #FFFFFF;FONT-FAMILY: �l�r �S�V�b�N;}'; 
strFrame+='TD{FONT-FAMILY: �l�r �S�V�b�N;FONT-SIZE: 9pt;}'; 
strFrame+='</style>'; 
strFrame+='<scr' + 'ipt>'; 
strFrame+='var datelayerx,datelayery;'; 
strFrame+='var bDrag;'; 
strFrame+='function document.onmousemove()'; 
strFrame+='{if(bDrag && window.event.button==1)'; 
strFrame+='    {var DateLayer=parent.document.all.DateLayer.style;'; 
strFrame+='        DateLayer.posLeft += window.event.clientX-datelayerx;'; 
strFrame+='        DateLayer.posTop += window.event.clientY-datelayery;}}'; 
strFrame+='function DragStart()'; 
strFrame+='{var DateLayer=parent.document.all.DateLayer.style;'; 
strFrame+='    datelayerx=window.event.clientX;'; 
strFrame+='    datelayery=window.event.clientY;'; 
strFrame+='    bDrag=true;}'; 
strFrame+='function DragEnd(){'; 
strFrame+='    bDrag=false;}'; 
strFrame+='</scr' + 'ipt>'; 
strFrame+='<div style="z-index:9999;position: absolute; left:0; top:0;" onselectstart="return false"><span id=tmpSelectYearLayer style="z-index: 9999;position: absolute;top: 3; left: 19;display: none"></span>'; 
strFrame+='<span id=tmpSelectMonthLayer style="z-index: 9999;position: absolute;top: 3; left: 78;display: none"></span>'; 
strFrame+='<table border=1 cellspacing=0 cellpadding=0 width=142 height=160 bordercolor=#066280 bgcolor=#066280>'; 
strFrame+=' <tr><td width=142 height=23 bgcolor=#FFFFFF><table border=0 cellspacing=1 cellpadding=0 width=140 height=23>'; 
strFrame+=' <tr align=center><td width=16 align=center bgcolor=#066280 style="font-size:12px;cursor: hand;color: #ffffff" '; 
strFrame+=' onclick="parent.PrevM()" title="�O��"><b>&lt;</b>'; 
strFrame+=' </td><td width=60 align=center style="font-size:12px;cursor:default" '; 
strFrame+='onmouseover="style.backgroundColor=\'#FFD700\'" onmouseout="style.backgroundColor=\'white\'" '; 
strFrame+='onclick="parent.tmpSelectYearInnerHTML(this.innerText.substring(0,4))"><span id=YearHead></span></td>'; 
strFrame+='<td width=48 align=center style="font-size:12px;cursor:default" onmouseover="style.backgroundColor=\'#FFD700\'" '; 
strFrame+=' onmouseout="style.backgroundColor=\'white\'" onclick="parent.tmpSelectMonthInnerHTML(this.innerText.length==3?this.innerText.substring(0,1):this.innerText.substring(0,2))"'; 
strFrame+=' ><span id=MonthHead></span></td>'; 
strFrame+=' <td width=16 bgcolor=#066280 align=center style="font-size:12px;cursor: hand;color: #ffffff" '; 
strFrame+=' onclick="parent.NextM()" title="����"><b>&gt;</b></td></tr>'; 
strFrame+=' </table></td></tr>'; 
strFrame+=' <tr><td width=142 height=18>'; 
strFrame+='<table border=1 cellspacing=0 cellpadding=0 bgcolor=#066280 ' + (bMoveable? 'onmousedown="DragStart()" onmouseup="DragEnd()"':''); 
strFrame+=' BORDERCOLORLIGHT=#066280 BORDERCOLORDARK=#FFFFFF width=140 height=20 style="cursor:' + (bMoveable ? 'move':'default') + '">'; 
strFrame+='<tr align=center valign=bottom><td style="font-size:12px;color:#FFFFFF">��</td>'; 
strFrame+='<td style="font-size:12px;color:#FFFFFF">��</td><td style="font-size:12px;color:#FFFFFF">��</td>'; 
strFrame+='<td style="font-size:12px;color:#FFFFFF">��</td><td style="font-size:12px;color:#FFFFFF">��</td>'; 
strFrame+='<td style="font-size:12px;color:#FFFFFF">��</td><td style="font-size:12px;color:#FFFFFF">�y</td></tr>'; 
strFrame+='</table></td></tr>'; 
strFrame+=' <tr><td width=142 height=120>'; 
strFrame+=' <table border=1 cellspacing=2 cellpadding=0 BORDERCOLORLIGHT=#066280 BORDERCOLORDARK=#FFFFFF bgcolor=#FFFFFF width=140 height=120>'; 
var n=0; for (j=0;j<5;j++){ strFrame+= ' <tr align=center>'; for (i=0;i<7;i++){ 
strFrame+='<td width=20 height=20 id=Day'+n+' style="font-size:12px" onclick=parent.DayClick(this.innerText,0)></td>';n++;} 
strFrame+='</tr>';} 
strFrame+=' <tr align=center>'; 
for (i=35;i<39;i++)strFrame+='<td width=20 height=20 id=Day'+i+' style="font-size:12px" onclick="parent.DayClick(this.innerText,0)"></td>'; 
strFrame+=' <td colspan=3 align=right><span onclick=parent.closeLayer() style="font-size:12px;cursor: hand"'; 
strFrame+=' title="' + _VersionInfo + '"><u>���</u></span>&nbsp;</td></tr>'; 
strFrame+=' </table></td></tr><tr><td>'; 
strFrame+=' <table border=0 cellspacing=1 cellpadding=0 width=100% bgcolor=#FFFFFF>'; 
strFrame+=' <tr><td align=left><input type=button class=button value="<<" title="�O�N" onclick="parent.PrevY()" '; 
strFrame+=' onfocus="this.blur()" style="font-size: 12px; height: 20px"><input class=button title="�O��" type=button '; 
strFrame+=' value="< " onclick="parent.PrevM()" onfocus="this.blur()" style="font-size: 12px; height: 20px"></td><td '; 
strFrame+=' align=center><input type=button class=button value="����" onclick="parent.Today()" '; 
strFrame+=' onfocus="this.blur()" title="����" style="font-size: 12px; height: 20px; cursor:hand"></td><td '; 
strFrame+=' align=right><input type=button class=button value=" >" onclick="parent.NextM()" '; 
strFrame+=' onfocus="this.blur()" title="����" class=button style="font-size: 12px; height: 20px"><input '; 
strFrame+=' type=button class=button value=">>" title="���N" onclick="parent.NextY()"'; 
strFrame+=' onfocus="this.blur()" style="font-size: 12px; height: 20px"></td>'; 
strFrame+='</tr></table></td></tr></table></div>'; 

window.frames.DateLayer.document.writeln(strFrame); 
window.frames.DateLayer.document.close();

//====================================================
var outObject;
var outButton;
var outDate="";
var odatelayer=window.frames.DateLayer.document.all;
function setday(tt,obj)
{ 
    if (arguments.length > 2){alert("PARAMETER ERROR !");return;} 
    if (arguments.length == 0){alert("PARAMETER ERROR !");return;} 
    var dads = document.all.DateLayer.style; 
    var th = tt; 
    var ttop = tt.offsetTop;
    var thei = tt.clientHeight;
    var tleft = tt.offsetLeft;
    var ttyp = tt.type;
    while (tt = tt.offsetParent){ttop+=tt.offsetTop; tleft+=tt.offsetLeft;} 
    dads.top = (ttyp=="image")? ttop+thei : ttop+thei+6; 
    dads.left = tleft; 
    outObject = (arguments.length == 1) ? th : obj;
    outButton = (arguments.length == 1) ? null : th;
    var reg = /^(\d+)-(\d{1,2})-(\d{1,2})$/; 
    var r = outObject.value.match(reg); 
    if(r!=null){ 
        r[2]=r[2]-1; 
        var d= new Date(r[1], r[2],r[3]); 
        if(d.getFullYear()==r[1] && d.getMonth()==r[2] && d.getDate()==r[3]){ 
            outDate=d;
        } 
        else outDate=""; 
            SetDay(r[1],r[2]+1); 
    } 
    else{ 
        outDate=""; 
        SetDay(new Date().getFullYear(), new Date().getMonth() + 1); 
    } 
    dads.display = ''; 

    event.returnValue=false; 
} 

var MonHead = new Array(12);
MonHead[0] = 31; MonHead[1] = 28; MonHead[2] = 31; MonHead[3] = 30; MonHead[4] = 31; MonHead[5] = 30; 
MonHead[6] = 31; MonHead[7] = 31; MonHead[8] = 30; MonHead[9] = 31; MonHead[10] = 30; MonHead[11] = 31; 

var TheYear=new Date().getFullYear();
var TheMonth=new Date().getMonth()+1;
var WDay=new Array(39);

function document.onclick()
{ 
with(window.event) 
{ if (srcElement.getAttribute("Author")==null && srcElement != outObject && srcElement != outButton) 
closeLayer(); 
} 
} 

function document.onkeyup()
{ 
if (window.event.keyCode==27){ 
        if(outObject)outObject.blur(); 
        closeLayer(); 
    } 
    else if(document.activeElement) 
        if(document.activeElement.getAttribute("Author")==null && document.activeElement != outObject && document.activeElement != outButton) 
        { 
            closeLayer(); 
        } 
} 

function WriteHead(yy,mm)
{ 
    odatelayer.YearHead.innerText = yy + " �N"; 
odatelayer.MonthHead.innerText = mm + " ��"; 
} 

function tmpSelectYearInnerHTML(strYear)
{ 
if (strYear.match(/\D/)!=null){alert("YEAR ERROR !");return;} 
var m = (strYear) ? strYear : new Date().getFullYear(); 
if (m < 1000 || m > 9999) {alert("YEAR ERROR (1000-9999) !");return;} 
var n = m - 10; 
if (n < 1000) n = 1000; 
if (n + 26 > 9999) n = 9974; 
var s = "<select name=tmpSelectYear style='font-size: 12px' " 
s += "onblur='document.all.tmpSelectYearLayer.style.display=\"none\"' " 
s += "onchange='document.all.tmpSelectYearLayer.style.display=\"none\";" 
s += "parent.TheYear = this.value; parent.SetDay(parent.TheYear,parent.TheMonth)'>\r\n"; 
var selectInnerHTML = s; 
for (var i = n; i < n + 26; i++) 
{ 
if (i == m) 
{selectInnerHTML += "<option value='" + i + "' selected>" + i + "�N" + "</option>\r\n";} 
else {selectInnerHTML += "<option value='" + i + "'>" + i + "�N" + "</option>\r\n";} 
} 
selectInnerHTML += "</select>"; 
odatelayer.tmpSelectYearLayer.style.display=""; 
odatelayer.tmpSelectYearLayer.innerHTML = selectInnerHTML; 
odatelayer.tmpSelectYear.focus(); 
} 

function tmpSelectMonthInnerHTML(strMonth)
{ 
if (strMonth.match(/\D/)!=null){alert("MONTH ERROR�I");return;} 
var m = (strMonth) ? strMonth : new Date().getMonth() + 1; 
var s = "<select name=tmpSelectMonth style='font-size: 12px' " 
s += "onblur='document.all.tmpSelectMonthLayer.style.display=\"none\"' " 
s += "onchange='document.all.tmpSelectMonthLayer.style.display=\"none\";" 
s += "parent.TheMonth = this.value; parent.SetDay(parent.TheYear,parent.TheMonth)'>\r\n"; 
var selectInnerHTML = s; 
for (var i = 1; i < 13; i++) 
{ 
if (i == m) 
{selectInnerHTML += "<option value='"+i+"' selected>"+i+"��"+"</option>\r\n";} 
else {selectInnerHTML += "<option value='"+i+"'>"+i+"��"+"</option>\r\n";} 
} 
selectInnerHTML += "</select>"; 
odatelayer.tmpSelectMonthLayer.style.display=""; 
odatelayer.tmpSelectMonthLayer.innerHTML = selectInnerHTML; 
odatelayer.tmpSelectMonth.focus(); 
} 

function closeLayer()
{ 
document.all.DateLayer.style.display="none"; 
} 

function IsPinYear(year)
{ 
if (0==year%4&&((year%100!=0)||(year%400==0))) return true;else return false; 
} 

function GetMonthCount(year,month)
{ 
var c=MonHead[month-1];if((month==2)&&IsPinYear(year)) c++;return c; 
} 
function GetDOW(day,month,year) 
{ 
var dt=new Date(year,month-1,day).getDay()/7; return dt; 
} 

function PrevY()
{ 
if(TheYear > 999 && TheYear <10000){TheYear--;} 
else{alert("YEAR ERROR (1000-9999)!");} 
SetDay(TheYear,TheMonth); 
} 
function NextY()
{ 
if(TheYear > 999 && TheYear <10000){TheYear++;} 
else{alert("YEAR ERROR (1000-9999)!");} 
SetDay(TheYear,TheMonth); 
} 
function Today() //Today Button 
{ 
    var today; 
TheYear = new Date().getFullYear(); 
TheMonth = new Date().getMonth()+1; 
today=new Date().getDate(); 
if (TheMonth < 10){TheMonth = "0" + TheMonth;} 
if (today < 10){today = "0" + today;} 
//SetDay(TheYear,TheMonth); 
if(outObject){ 
        outObject.value=TheYear + "/" + TheMonth + "/" + today; 
} 
closeLayer(); 
} 
function PrevM()
{ 
if(TheMonth>1){TheMonth--}else{TheYear--;TheMonth=12;} 
SetDay(TheYear,TheMonth); 
} 
function NextM()
{ 
if(TheMonth==12){TheYear++;TheMonth=1}else{TheMonth++} 
SetDay(TheYear,TheMonth); 
} 

function SetDay(yy,mm)
{ 
WriteHead(yy,mm); 
TheYear=yy; 
TheMonth=mm; 

for (var i = 0; i < 39; i++){WDay[i]=""};
var day1 = 1,day2=1,firstday = new Date(yy,mm-1,1).getDay();
for (i=0;i<firstday;i++)WDay[i]=GetMonthCount(mm==1?yy-1:yy,mm==1?12:mm-1)-firstday+i+1
for (i = firstday; day1 < GetMonthCount(yy,mm)+1; i++){WDay[i]=day1;day1++;} 
for (i=firstday+GetMonthCount(yy,mm);i<39;i++){WDay[i]=day2;day2++} 
for (i = 0; i < 39; i++) 
{ var da = eval("odatelayer.Day"+i) 
if (WDay[i]!="") 
{ 
        da.borderColorLight="#066280"; 
        da.borderColorDark="#FFFFFF"; 
        if(i<firstday)
        { 
            da.innerHTML="<b><font color=gray>" + WDay[i] + "</font></b>"; 
            da.title=(mm==1?12:mm-1) +"��" + WDay[i] + "��"; 
            da.onclick=Function("DayClick(this.innerText,-1)"); 
            if(!outDate) 
                da.style.backgroundColor = ((mm==1?yy-1:yy) == new Date().getFullYear() && 
                    (mm==1?12:mm-1) == new Date().getMonth()+1 && WDay[i] == new Date().getDate()) ? 
                     "#FFD700":"#D7EBFF"; 
            else 
            { 
                da.style.backgroundColor =((mm==1?yy-1:yy)==outDate.getFullYear() && (mm==1?12:mm-1)== outDate.getMonth() + 1 && 
                WDay[i]==outDate.getDate())? "#00ffff" : 
                (((mm==1?yy-1:yy) == new Date().getFullYear() && (mm==1?12:mm-1) == new Date().getMonth()+1 && 
                WDay[i] == new Date().getDate()) ? "#FFD700":"#D7EBFF"); 
                if((mm==1?yy-1:yy)==outDate.getFullYear() && (mm==1?12:mm-1)== outDate.getMonth() + 1 && 
                WDay[i]==outDate.getDate()) 
                { 
                    da.borderColorLight="#FFFFFF"; 
                    da.borderColorDark="#066280"; 
                } 
            } 
        } 
        else if (i>=firstday+GetMonthCount(yy,mm))
        { 
            da.innerHTML="<b><font color=gray>" + WDay[i] + "</font></b>"; 
            da.title=(mm==12?1:mm+1) +"��" + WDay[i] + "��"; 
            da.onclick=Function("DayClick(this.innerText,1)"); 
            if(!outDate) 
                da.style.backgroundColor = ((mm==12?yy+1:yy) == new Date().getFullYear() && 
                    (mm==12?1:mm+1) == new Date().getMonth()+1 && WDay[i] == new Date().getDate()) ? 
                     "#FFD700":"#D7EBFF"; 
            else 
            { 
                da.style.backgroundColor =((mm==12?yy+1:yy)==outDate.getFullYear() && (mm==12?1:mm+1)== outDate.getMonth() + 1 && 
                WDay[i]==outDate.getDate())? "#00ffff" : 
                (((mm==12?yy+1:yy) == new Date().getFullYear() && (mm==12?1:mm+1) == new Date().getMonth()+1 && 
                WDay[i] == new Date().getDate()) ? "#FFD700":"#D7EBFF"); 
                if((mm==12?yy+1:yy)==outDate.getFullYear() && (mm==12?1:mm+1)== outDate.getMonth() + 1 && 
                WDay[i]==outDate.getDate()) 
                { 
                    da.borderColorLight="#FFFFFF"; 
                    da.borderColorDark="#066280"; 
                } 
            } 
        } 
        else
        { 
            da.innerHTML="<b>" + WDay[i] + "</b>"; 
            da.title=mm +"��" + WDay[i] + "��"; 
            da.onclick=Function("DayClick(this.innerText,0)");
            if(!outDate) 
                da.style.backgroundColor = (yy == new Date().getFullYear() && mm == new Date().getMonth()+1 && WDay[i] == new Date().getDate())? 
                    "#FFD700":"#D7EBFF"; 
            else 
            { 
                da.style.backgroundColor =(yy==outDate.getFullYear() && mm== outDate.getMonth() + 1 && WDay[i]==outDate.getDate())? 
                    "#00ffff":((yy == new Date().getFullYear() && mm == new Date().getMonth()+1 && WDay[i] == new Date().getDate())? 
                    "#FFD700":"#D7EBFF"); 
                if(yy==outDate.getFullYear() && mm== outDate.getMonth() + 1 && WDay[i]==outDate.getDate()) 
                { 
                    da.borderColorLight="#FFFFFF"; 
                    da.borderColorDark="#066280"; 
                } 
            } 
        } 
da.style.cursor="hand" 
} 
else{da.innerHTML="";da.style.backgroundColor="";da.style.cursor="default"} 
} 
} 

function DayClick(n,ex)
{ 
var yy=TheYear; 
var mm = parseInt(TheMonth)+ex;
    if(mm<1){ 
        yy--; 
        mm=12+mm; 
    } 
    else if(mm>12){ 
        yy++; 
        mm=mm-12; 
    } 
     
if (mm < 10){mm = "0" + mm;} 
if (outObject) 
{ 
if (!n) {//outObject.value=""; 
return;} 
if ( n < 10){n = "0" + n;} 
outObject.value= yy + "/" + mm + "/" + n ;
outObject.realValue= yy + "/" + mm + "/" + n ;
closeLayer(); 
} 
else {closeLayer(); alert("ERROR�I");} 
} 
