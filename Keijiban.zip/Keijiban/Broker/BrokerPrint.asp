<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'----------------------------------------------
'	�������ꊇ�������
'----------------------------------------------

'	Response.Buffer = True

on error resume next
dim JobCode
dim SubCode
dim myCnt
dim mySel
dim myURL()

mode = GetLong(request("mode"))		'1:A/N	10:Receipt	100:D/O		1000:Copy
JobCode = GetPost(request("JobCode"))
SubCode = GetLong(request("SubCode"))
if mode <> 0 AND JobCode <> "" then

	OpenSql Conn, SqlServerName, DataBaseName		
	set Recset = Server.CreateObject("adodb.recordset") 
	
	JobShipment = 0
	With Recset
		strSQL = "SELECT * FROM TBL_SEA_JOB WHERE Deleted = 0 AND JobBroker = '" & UserCode & "'"
		strSQL = strSQL & " AND JobCode = '" & JobCode & "' AND SubCode = " & SubCode
		.Open strSql, conn, adOpenKeyset, adLockOptimistic
		if not .eof then 
			JobShipment = GetLong(.fields("JobShipment"))
			if GetLong(mode) > 99 then
				.fields("PrintCnt") = GetLong(.fields("PrintCnt")) + 1
			end if
			.update
		end if
		.Close
	end with
	set Recset = Nothing
	CloseDB Conn
	
	if JobShipment = 0 then
		ShowMessage "�Y���f�[�^�͌�����܂���ł���"
	else
		myCnt = 0
		myCols = "100%"
		mySel = right("0000" & mode, 4)
		if JobShipment = 4 then
			if mid(mySel, 1, 1) = "1" then
				myCnt = myCnt + 1
				myCols = myCols & ",0"
				redim preserve myURL(myCnt)
				myURL(myCnt) = "DeliveryOrder.asp?type=1&"
			end if
			if mid(mySel, 2, 1) = "1" then
				myCnt = myCnt + 1
				myCols = myCols & ",0"
				redim preserve myURL(myCnt)
				myURL(myCnt) = "DeliveryOrder.asp?"
			end if
		end if
		if mid(mySel, 3, 1) = "1" then
			myCnt = myCnt + 1
			myCols = myCols & ",0"
			redim preserve myURL(myCnt)
			if JobShipment = 4 then
				myURL(myCnt) = "ConsoliReceipt.asp?"
			else
				myURL(myCnt) = "ImportReceipt.asp?"
			end if
		end if
		if mid(mySel, 4, 1) = "1" then
			myCnt = myCnt + 1
			myCols = myCols & ",0"
			redim preserve myURL(myCnt)
			if JobShipment = 4 then
				myURL(myCnt) = "ConsoliAN.asp?"
			else
				myURL(myCnt) = "ImportAN.asp?"
			end if
		end if
		myCols = left(myCols, len(myCols) - 2)
		myPara = "print=1&JobCode=" & JobCode & "&SubCode=" & SubCode
		if myCols = "100%" then
			response.redirect myURL(myCnt) & myPara
		else
%>
		<HTML>
			<HEAD>
				<TITLE>����v���r���[</TITLE>
				<META http-equiv=Content-Type content="text/html; charset=shift-jis">
			</HEAD>
			<FRAMESET COLS="<%=myCols%>" FRAMEBORDER=0 ID="fraPrint" NAME="fraPrint">
<%for i = 1 to myCnt%>
				<FRAME name="Print<%=i%>" SRC="<%=myURL(i) & myPara%>">
<%next%>
			</FRAMESET>
		</HTML>
<%
		end If
	end if
end if
	
'	Response.Flush
'	Response.End

%>
