<!-- #include file="common.asp" -->
<html>
	<head>
		<Title>BROKER MENU</Title>
		<meta http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<link rel="stylesheet" href="css/style.css" type="text/css">	
		<style type="text/css">
			.pt13 { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 13pt; LINE-HEIGHT: 14pt }
		</style>
		<script language=javascript>
		
		function SetMenu(no) {
			var url = "";
			switch (no) {
				case 0: {
					url = "PrintSetup.asp";
					break;
				}
				case 1: {
					url = "BrokerView.asp";
					break;
				}
				case 2: {
					url = "BrokerView.asp?type=1";
					break;
				}
				case 3: {
					url = "TokyoView.asp";
					break;
				}
				case 9: {
					url = "Password.asp";
					break;
				}
				default: {
					alert("�H�����ł��B");
					url = "blank.html";
				}
			}
			parent.main.location.href = url;
		}
		
		function LogOff() {
			top.location.href = "logoff.asp";
		}
		</script>
	</head>
	<body topmargin="0" marginheight="0" rightmargin="0" leftmargin="0" marginwidth="0"
		  OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>	
		<table border="0" cellpadding="0" cellspacing="0" height="100%" bgcolor=#FFF0F0>
				<TR height="38">
					<TD width="120" height="70" bgcolor=Crimson align=center class=pt13>
						<FONT COLOR="#ffffff">�㗝�X�p<br>�V�X�e��</FONT>
				</TR>
				<TR height="80%">
					<TD valign="top">
						<table width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=#FFF0F0 class=pt9n>
<%if UserCode <> "DCP1005" AND UserCode <> "DCP1012" then		'���`�E�ܗm�ȊO%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(1)"><TD align="middle" width=36%><IMG SRC="img/report.ico"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�A�����ڏ����Ɖ��">�A������</TD></A></TR>
<%end if%>
<%select case UserCode%>
<%case "DCP1003","DCP1005","DCP1006","DCP1010","DCP1011","DCP1012","DCP1017","DCP1018","DCP1020"%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(2)"><TD align="middle" width=36%><IMG SRC="img/report.PNG"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�A���P�[�����Ɖ��">�A���P�[</TD></A></TR>
<%end select%>
<%if UserCode = "DCP1019" then		'�����O�F%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(3)"><TD align="middle" width=36%><IMG SRC="img/report.PNG"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�e�b�������ڂ��Ɖ��">�e�b����</TD></A></TR>
<%end if%>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
							<TR><A href="javascript:SetMenu(9)"><TD align="middle" width=36%><IMG SRC="img/Key.jpg"></TD><TD height="20" align="middle" style="CURSOR: hand" title="�p�X���[�h��ύX����">�p�X���[�h</TD></A></TR>
							<TR><TD colspan=2><HR SIZE=1></TD></TR>	
						</table>
					</TD>
				</TR>
				<TR><TD>
					<TABLE width="121" border="0" cellspacing="0" cellpadding="1" bgcolor=#FF6666 class=pt9n>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>	
						<TR><A href="javascript:SetMenu(0)"><TD align="middle" width=36%><IMG SRC="img/HardMente.gif"></TD><TD height="20" align="middle" style="CURSOR: hand; color:white" title="IE�ŏ��ވ����ݒ肷��">����ݒ�</TD></A></TR>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>	
						<TR><A href="javascript:LogOff()"><TD align="middle" width=36%><IMG SRC="img/logoff.gif"></TD><TD height="40" align="middle" style="CURSOR: hand; color:white" title="���O�I�t">���O�I�t</TD></A></TR>
						<TR><TD colspan=2><HR SIZE=1></TD></TR>
					</TABLE>
				</TD></TR>
			<TR height="70">
				<TD width="120" bgcolor=Crimson align=center class=pt9>
					<FONT COLOR="#ffffff">Copyright&copy; 2007<br>Sample Co., Ltd.</FONT></TD>
			</TR>
		</table>
	</body>
</html>


