<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	with Recset
		strSQL = "SELECT CTM_NAME FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_CD = '" & UserCode & "'"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		if not .eof then CTM_NAME = GetString(.fields("CTM_NAME"))
		.Close
		
		strSQL = "SELECT PIC_NAME, PIC_TEL, PIC_FAX FROM CTM_PIC WHERE PIC_DELETED = 0 AND PIC_DFT <> 0"
		strSQL = strSQL & " AND PIC_TYPE <> 0 AND CTM_CD = '" & UserCode & "'"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		if not .eof then 
			PIC_NAME = GetString(.fields("PIC_NAME"))
			PIC_TEL = GetString(.fields("PIC_TEL"))
			PIC_FAX = GetString(.fields("PIC_FAX"))
		end if
		.Close
		
		strSQL = "SELECT BANK_NAME, BANK_BRANCH, BANK_TYPE, BANK_ACCOUNT, BANK_HOLDER, BANK_REMARKS"
		strSQL = strSQL & " FROM CTM_BANK WHERE BANK_DELETED = 0 AND CTM_CD = '" & UserCode & "'"
		strSQL = strSQL & " ORDER BY BANK_DFT DESC"
		.Open strSQL, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then 
			BANK_NAME = GetString(.fields("BANK_NAME"))
			BANK_BRANCH = GetString(.fields("BANK_BRANCH"))
			BANK_TYPE = GetString(.fields("BANK_TYPE"))
			BANK_ACCOUNT = GetString(.fields("BANK_ACCOUNT"))
			BANK_HOLDER = GetString(.fields("BANK_HOLDER"))
			BANK_REMARKS = GetString(.fields("BANK_REMARKS"))
		end if
	end with
%>
<HTML>
<HEAD>
	<TITLE>Welcome</TITLE>
	<LINK href="css/style.css" rel=stylesheet type=text/css>
</HEAD>
<BODY OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
<center>
	<TABLE width=100%>
	  <TR><TD width=100% height=50 align=center valign=middle>
	    <TABLE style="filter:progid:DXImageTransform.Microsoft.Shadow(Color=#E0E0E0,Direction=120,strength=3)">		
	        <TR><TD class=pt12n><b>CORP �㗝�X��p�V�X�e���ց@�悤�����I</b>
	    </TABLE>
	  </TD></TR>
	</TABLE>
	<HR width=100% align=left color=blue size=1>
	<TABLE width=100%>
	  <TR><TD width=100% align=center valign=middle>
	    <TABLE>
	        <TR height=50><TD class=pt12n colspan=2>��Ђ̏������m�F���������B
	        <TR height=30><TD width=100>�� �� ���F�@<TD class=pt12g width=300><%=CTM_NAME%>
	        <TR height=30><TD nowrap>�S �� �ҁF�@<TD class=pt12g nowrap><%=GetHornor(PIC_NAME)%>
	        <TR height=30><TD nowrap>�d�b�ԍ��F�@<TD class=pt12g nowrap><%=PIC_TEL%>
	        <TR height=30><TD nowrap>FAX �ԍ��F�@<TD class=pt12g nowrap><%=PIC_FAX%>
<%if BANK_NAME <> "" then%>
	        <TR height=30><TD colspan=2><hr>
	        <TR height=30><TD nowrap>������s�F�@<TD class=pt12g nowrap><%=BANK_NAME & " " & BANK_BRANCH%>
	        <TR height=30><TD nowrap>�����ԍ��F�@<TD class=pt12g nowrap><%=BANK_TYPE & " " & BANK_ACCOUNT%>
	        <TR height=30><TD nowrap>�������`�F�@<TD class=pt12g nowrap><%=BANK_HOLDER%>
<%end if%>
	    </TABLE>
	</TABLE>
	<HR width=100% align=left color=blue size=1>
</center>
</BODY>
</HTML>
