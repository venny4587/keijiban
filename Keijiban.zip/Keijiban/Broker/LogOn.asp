<!-- #include file="dbconst.asp" -->
<!-- #include file="clsDBLogAccess.asp" -->
<%    
	Dim objDBLogAccess
	
	Response.AddHeader "Pragma", "no-cache"
	Response.Expires = -1
	
	Session("SqlServerName") = "SERVER"
	Session("DataBaseName") = "BROKER"
	
	If Session("LogAccessID") = "" Then
		Session.Abandon 
		Set objDBLogAccess = New clsDBLogAccess
		With objDBLogAccess
			.Add()
			Session("LogAccessID") = .AccessID
		End With
		Set objDBLogAccess = Nothing
	End If
	
	UserID = Request.Cookies("TEST_UserID")
	Password = Request.Cookies("TEST_Password")
%>
<HTML>
	<HEAD>
		<TITLE>�㗝�X�A�g�V�X�e��</TITLE>  
		<LINK REL="Bookmark" HREF="img/logo.ico">
		<LINK REL="Shortcut Icon" HREF="img/logo.ico">
		<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<SCRIPT LANGUAGE="JavaScript">
			
			function ResetEnter() {
				if (event.keyCode == 13) {
					window.event.keyCode = 9;
				}
			}
		</SCRIPT>
	</HEAD>
	<BODY OnLoad="document.frmLogon.UserID.focus()" 
		OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
		<CENTER>
			<TABLE>
				<TR><TD Height=20></TD></TR>
				<TR><TD align=center><B>���[�U�[�F��</B>
					<HR WIDTH=400>
					<FORM METHOD="POST" ACTION="LogonCheck.asp" AUTOCOMPLETE="OFF" NAME="frmLogon">
						<INPUT TYPE=HIDDEN NAME="LogAccessID" VALUE="<%=Session("LogAccessID")%>">
						<TABLE BORDER=0 align=center>
							<TR>
								<TD colspan=2 height=50 align=center valign=top><FONT SIZE=-1>�����[�U�[ID�E�p�X���[�h����͂��A���[�U�[�F�؁v�{�^���������ĉ������B</FONT></TD>
								<INPUT TYPE=HIDDEN NAME="LogAccessID_CORP" VALUE=<%=Session("LogAccessID_CORP")%>>
							</TR>
							<TR> 
								<TD ALIGN=RIGHT>�@���[�U�[ID�F</TD>
								<TD><INPUT NAME="UserID" VALUE="<%=UserID%>" MAXLENGTH=32 STYLE="ime-mode:disabled" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR> 
								<TD ALIGN=RIGHT>�@�p�X���[�h�F</TD>
								<TD><INPUT TYPE="Password" VALUE="<%=Password%>" MAXLENGTH=32 NAME="Password" STYLE="ime-mode:disabled" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD ALIGN=CENTER COLSPAN=2 height=50>
									<INPUT STYLE="width:120px;height:30px;border-width:2px;font-size:12px;background-color:#E0E0E0;padding-left:10px;background-repeat:no-repeat;background-position:5% 50%;background-image:url('/images/CORP/security.gif')" TYPE="submit" value="���[�U�[�F��" id=submit1 name=submit1>
								</TD>
							</TR>
							<TR>
								<TD COLSPAN=2>
									<FONT SIZE=-1>�����[�U�[ID�E�p�X���[�h�́A�啶���E�������𐳊m�ɓ��͂��ĉ������B</FONT>
									<BR><FONT SIZE=-1>��Microsoft Internet Explorer 6.0 �ȏ�ł��g�p�������B</FONT>
								</TD>
							</TR>									
						</TABLE>
					</FORM>
					<HR WIDTH=400>
				</TD></TR>
			</TABLE>	
			<TABLE>
				<TR>
					<TD align=center>
						<IMG SRC="/images/CORP/logo.png" ALT="COMPANY ">
					</TD>
				</TR>
				<TR>
					<TD align=center>
						<FONT SIZE=-1>Copyright &copy; 2006-2007 COMPANY  Co.,Ltd.&nbsp;&nbsp;&nbsp;</FONT>
					</TD>
				</TR>
			</TABLE>
		</CENTER>
	</BODY>
</HTML>