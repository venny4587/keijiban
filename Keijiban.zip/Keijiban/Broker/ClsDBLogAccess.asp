<%
	Class clsDBLogAccess
	
		Private m_dtmAdded
		Private m_dtmLogOffTime
		Private m_lngAccessID
		Private m_lngCount
		
		Function Add()
			
			Dim Conn
			Dim dtmNow
			Dim Recset
			Dim strSQL
			
			dtmNow = Now()
				 		
				OpenSQL Conn, Session("SqlServerName"), Session("DataBaseName")
				Set Recset = Server.CreateObject ("ADODB.Recordset")
				'���O�֏�������
				With Recset
					.Open "SELECT * FROM LogAccess;", Conn, adOpenKeyset , adLockOptimistic 
					.AddNew 
					.Fields ("Remote_Addr") = Request.ServerVariables ("REMOTE_ADDR")
					.Fields ("Remote_Host") = Request.ServerVariables ("REMOTE_HOST")
					.Fields ("Http_User_Agent") = Request.ServerVariables ("HTTP_USER_AGENT")
					If Request.ServerVariables ("HTTP_ACCEPT_LANGUAGE") = "" Then
						.Fields ("Http_Accept_Language") = ""
					Else
						.Fields ("Http_Accept_Language") = left(Request.ServerVariables ("HTTP_ACCEPT_LANGUAGE"), 50)
					End If
					.Fields ("UserID") = "Unknown"
					.Fields ("Added") = dtmNow
					.Fields ("LogOffTime") = dtmNow
					.Update 
					.Close
						
					.Open "SELECT AccessID FROM LogAccess ORDER BY AccessID;", Conn, adOpenKeyset, adLockReadOnly
					.MoveLast 
					m_lngAccessID = .Fields ("AccessID")
					.Close 
				End With
				Set RecSet = Nothing
				CloseDB Conn

'			end if					

'			If Err.number = 0 Then
'				Add = True
'			Else
'				Add = False
'				AddError Err.number , Err.description , "clsDBLogAccess_Add"
'			End If

		End Function
		
		Function UpdateUserIDByAccessID(lngAccessID, strUserID, strUserLogonID)
			
			Dim Conn
			Dim Recset
			Dim strSQL
			
			'On Error Resume Next
			
			OpenSQL Conn, Session("SqlServerName"), Session("DataBaseName")
			Set Recset = Server.CreateObject ("ADODB.Recordset")
			'���O�֏�������
			Recset.Open "SELECT * FROM LogAccess WHERE AccessID = " & lngAccessID & ";", Conn, adOpenKeyset , adLockOptimistic 
			With Recset
				If Not .EOF Then
					.Fields("UserID") = strUserID
					.Fields("Logon_User") = strUserLogonID
					.Update
				End If
				.Close 
			End With
			Set RecSet = Nothing
			
			CloseDB Conn
		
			If Err.number <> 0 Then	ShowError Err.number , Err.description , "clsDBLogAccess_UpdateUserIDByAccessID"

		End Function
		
		Function UpdateLogOffTimeByAccessID(lngAccessID)
			
			Dim Conn
			Dim dtmNow
			Dim Recset
			Dim strSQL
			
			If lngAccessID <> "" Then
				dtmNow = Now()
				OpenSQL Conn, Session("SqlServerName"), Session("DataBaseName")
				Set Recset = Server.CreateObject ("ADODB.Recordset")
				'���O�֏�������
				Recset.Open "SELECT * FROM LogAccess WHERE AccessID = " & lngAccessID & ";", Conn, adOpenKeyset , adLockOptimistic 
				With Recset
					If .EOF Then
						m_dtmAdded = dtmNow
						m_dtmLogOffTime = dtmNow
					Else
						.Fields("LogOffTime") = dtmNow
						.Update
						m_dtmAdded = .Fields("Added")
						m_dtmLogOffTime = .Fields("LogOffTime")
					End If
					.Close 
				End With
				Set RecSet = Nothing
				CloseDB Conn
			End If

		End Function
		
		'Added
		Property Get Added
			Added = m_dtmAdded
		End Property
		'AccessID
		Property Get AccessID
			AccessID = m_lngAccessID
		End Property
		'LogOffTime
		Property Get LogOffTime
			LogOffTime = m_dtmLogOffTime
		End Property
	End Class
%>
