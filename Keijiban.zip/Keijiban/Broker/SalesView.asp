<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<!-- #include file="../common/function.asp" -->
<%
'on error resume next
dim myMode
dim myPageSize
dim lngPageNumber
dim DepartOperator
	
	JobType = GetPost(request("JobType"))
	if JobType = gsImport then
		DepartOperator = DepartImport
	else
		DepartOperator = DepartExport
	end if

	myPageSize = GetUserPageSize(20)	
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Process = 0
		'JobCode = right(year(date),1) & "-"
		JobOperator = WebUserID
		JobSalesman = WebUserID
	else
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		BrokerRef = GetPost(request("BrokerRef"))
		ReferNo = GetPost(request("ReferNo"))
		BillNo = GetPost(request("BillNo"))
		Port = GetPost(request("Port"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		DeliveryFrom = GetPost(request("DeliveryFrom"))
		DeliveryTo = GetPost(request("DeliveryTo"))
		QtyFrom = GetPost(request("QtyFrom"))
		QtyTo = GetPost(request("QtyTo"))
		GWFrom = GetPost(request("GWFrom"))
		GWTo = GetPost(request("GWTo"))
		CBMFrom = GetPost(request("CBMFrom"))
		CBMTo = GetPost(request("CBMTo"))
		AmountFrom = GetPost(request("AmountFrom"))
		AmountTo = GetPost(request("AmountTo"))
		Vessel = GetPost(request("Vessel"))
		Process = GetLong(request("Process"))
		JobOperator = GetLong(request("JobOperator"))
		JobSalesman = GetLong(request("JobSalesman"))
		JobShipment = GetLong(request("JobShipment"))
		Container = GetPost(request("Container"))
		WareHouse = GetPost(request("WareHouse"))
		Marks = GetPost(request("Marks"))
		
		if QtyFrom <> "" then QtyFrom = GetDouble(QtyFrom)
		if QtyTo <> "" then QtyTo = GetDouble(QtyTo)
		if GWFrom <> "" then GWFrom = GetDouble(GWFrom)
		if GWTo <> "" then GWTo = GetDouble(GWTo)
		if CBMFrom <> "" then CBMFrom = GetDouble(CBMFrom)
		if CBMTo <> "" then CBMTo = GetDouble(CBMTo)
		if AmountFrom <> "" then AmountFrom = GetLong(AmountFrom)
		if AmountTo <> "" then AmountTo = GetLong(AmountTo)
	end if

	myLevel = CheckUserLevel()

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="../common/css/style.css">
	<TITLE>�C��Ɩ��Ɖ�</TITLE>	
	<SCRIPT language=Javascript src="../common/css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="../common/css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>		
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function ShowList(mode) 
		dim win
			if mode = 1 then txt = "ClientRef"
			if mode = 5 then txt = "BrokerRef"
			set win = window.open("CustomerSearch.asp?txt=" & txt & "&mode=" & mode,"CustomerSearch","resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		function ShowDetail(cd, seq)
		dim win
			set win = window.open("MainFrame.asp?JobCode=" & cd & "&SubCode=" & seq, "", "resizable=1,scrollbars=1,width=960,height=640")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub DeliveryFrom_OnBlur()
			frmInput.DeliveryFrom.value = setdate(frmInput.DeliveryFrom.value)
		end sub		
		sub DeliveryTo_OnBlur()
			frmInput.DeliveryTo.value = setdate(frmInput.DeliveryTo.value)
		end sub	
		sub QtyFrom_OnBlur()
			if frmInput.QtyFrom.value = "" then exit sub
			frmInput.QtyFrom.value = GetDouble(frmInput.QtyFrom.value)
		end sub
		sub QtyTo_OnBlur()
			if frmInput.QtyTo.value = "" then exit sub
			frmInput.QtyTo.value = GetDouble(frmInput.QtyTo.value)
		end sub	
		sub JobCode_OnBlur()
			'frmInput.JobCode.value = FitJobCode(frmInput.JobCode.value)
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.JobCode)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="PreInputView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<INPUT TYPE="HIDDEN" NAME="JobType" VALUE='<%=JobType%>'>
		<table class=pt9>
			<TR><TD nowrap>
				Job ��<input class=si name="JobCode" value="<%=JobCode%>" maxlength=15 size=10 onkeydown="ResetEnter()">
				B/L�׎�<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				�㗝�X<img src=img/search.jpg style="cursor:hand" onmousedown="ShowList(5)">
					<input class=si name="BrokerRef" value="<%=BrokerRef%>" maxlength=10 size=8 onkeydown="ResetEnter()">
				�_��<input class=si name="ReferNo" value="<%=ReferNo%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				B/L ��<input class=si name="BillNo" value="<%=BillNo%>" maxlength=20 size=10 onkeydown="ResetEnter()">
				�敪&nbsp;<select name="JobShipment" onkeydown="ResetEnter()"><%for i = 0 to 6%>
					<option value="<%=i%>" <%if JobShipment = i then response.write "selected"%>><%=JobShip(i)%>
					<%next%></select>
				�Ɩ�&nbsp;<SELECT name="JobOperator" onkeydown="ResetEnter()"><option value="">�S��
					<%=ShowEmployList(DepartOperator, JobOperator)%></select>
			<TR><TD nowrap>
				���o�`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				�D��<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=12 onkeydown="ResetEnter()">
				�`<input class=si name="Port" value="<%=Port%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				��<input class=sn name="QtyFrom" value="<%=QtyFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="QtyTo" value="<%=QtyTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">			
				���Ň�&nbsp;<input class=sz name="Container" value="<%=Container%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				ϰ�&nbsp;<input class=sz name="Marks" value="<%=Marks%>" maxlength=16 size=12 onkeydown="ResetEnter()">
			<TR><TD nowrap>
				WEIGHT<input class=sn name="GWFrom" value="<%=GWFrom%>" maxlength=10 size=9 onkeydown="ResetEnter()">
					�`<input class=sn name="GWTo" value="<%=GWTo%>" maxlength=10 size=9 onkeydown="ResetEnter()">
				M'MENT<input class=sn name="CBMFrom" value="<%=CBMFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="CBMTo" value="<%=CBMTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">			
				�������z<input class=sn name="AmountFrom" value="<%=AmountFrom%>" maxlength=16 size=10 onkeydown="ResetEnter()">
					�`<input class=sn name="AmountTo" value="<%=AmountTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				�����q��&nbsp;<input class=sz name="WareHouse" value="<%=WareHouse%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="Process" value="1" onkeydown="ResetEnter()" <%if Process then response.write " checked"%>>�\���̂�
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobType <> "" then strSel = strSel & " AND JobType = '" & JobType & "'"
		if JobShipment <> 0 then strSel = strSel & " AND JobShipment = " & JobShipment
		if JobCode <> "" then strSel = strSel & " AND JobCode+'-'+CAST(SubCode AS VARCHAR)  LIKE '%" & FitSel(JobCode) & "%'"
		if ClientRef <> "" then	strSel = strSel & " AND CTM_ENAME LIKE '%" & FitSel(ClientRef) & "%'"
		if BrokerRef <> "" then	strSel = strSel & " AND BrokerRef = '" & FitSel(BrokerRef) & "'"
		if ReferNo <> "" then strSel = strSel & " AND (ReferNo LIKE '%" & FitSel(ReferNo) & "%' OR InvoiceNo LIKE '%" & FitSel(ReferNo) & "%')"	
		if BillNo <> "" then strSel = strSel & " AND (MBL LIKE '%" & FitSel(BillNo) & "%' OR HBL LIKE '%" & FitSel(BillNo) & "%')"	
		if Port <> "" then strSel = strSel & " AND (POL LIKE '%" & FitSel(Port) & "%' OR POD LIKE '%" & FitSel(Port) & "%')"
		if DateFrom <> "" then strSel = strSel & " AND ETAETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETAETD <= '" & Date2Str(DateTo) & "'"
		if DeliveryFrom <> "" then strSel = strSel & " AND DeliveryDate >= '" & Date2Str(DeliveryFrom) & "'"
		if DeliveryTo <> "" then strSel = strSel & " AND DeliveryDate <= '" & Date2Str(DeliveryTo) & "'"
		if Vessel <> "" then strSel = strSel & " AND VesselVoy LIKE '%" & FitSel(Vessel) & "%'"	
		if QtyFrom <> "" then strSel = strSel & " AND Quantity >= " & QtyFrom
		if QtyTo <> "" then strSel = strSel & " AND Quantity <= " & QtyTo
		if GWFrom <> "" then strSel = strSel & " AND GW >= " & GWFrom
		if GWTo <> "" then strSel = strSel & " AND GW <= " & GWTo
		if CBMFrom <> "" then strSel = strSel & " AND CBM >= " & CBMFrom
		if CBMTo <> "" then strSel = strSel & " AND CBM <= " & CBMTo
		if AmountFrom <> "" then strSel = strSel & " AND SalesTotal >= " & AmountFrom
		if AmountTo <> "" then strSel = strSel & " AND SalesTotal <= " & AmountTo
		if Container <> "" then strSel = strSel & " AND Container LIKE '%" & FitSel(Container) & "%'"
		if Marks <> "" then strSel = strSel & " AND Marks LIKE '%" & FitSel(Marks) & "%'"
		if WareHouse <> "" then strSel = strSel & " AND WH LIKE '%" & FitSel(WareHouse) & "%'"
		if JobOperator <> 0 then strSel = strSel & " AND JobOperator = " & JobOperator
		if JobSalesman <> 0 then strSel = strSel & " AND JobSalesman = " & JobSalesman
		if Process = 1 then strSel = strSel & " AND RIGHT(JobCode, 2) = '-0'"
		
		strSQL = "SELECT * FROM (SELECT JobCode, SubCode, JobType, CTM_ENAME, BrokerRef, JobOperator, JobSalesman, FinisherID, Created, ReferNo, InvoiceNo"
		strSQL = strSQL & ", POL, POD, MBL+' '+HBL AS BLNo, Vessel+' '+Voy AS VesselVoy, Quantity, Container, Marks, HBL, MBL, GW, CBM, JobShipment"
		strSQL = strSQL & ", CASE JobType WHEN '" & gsImport & "' THEN ETA ELSE ETD END AS ETAETD, SalesTotal, WareHouse+' '+WareHouse2 AS WH"
		strSQL = strSQL & " FROM TBL_SEA_JOB AS J INNER JOIN (SELECT CTM_CD, CTM_ENAME FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD"
		strSQL = strSQL & " INNER JOIN (SELECT CTM_CD, CTM_REF AS BrokerRef FROM CUSTOMER) AS B ON J.JobBroker = B.CTM_CD"
		strSQL = strSQL & " LEFT JOIN (SELECT JobCode AS JOB, SubCode AS Eda, SUM(ExpenseAttr*ExpenseTotal) AS SalesTotal FROM TBL_SEA_EXPENSE"
		strSQL = strSQL & " WHERE Deleted = 0 AND ExpenseType = " & gsCharge & " GROUP BY JobCode, SubCode) AS E ON J.JobCode = E.JOB AND J.SubCode = E.EDA"
		strSQL = strSQL & " WHERE Deleted = 0 AND (JobShipment = 4 or JobShipment = 6)) AS TMP WHERE SubCode <> 0 " & strSel
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY Created DESC"
		case 1:		strSQL = strSQL & " ORDER BY JobCode, SubCode"
		case 2:		strSQL = strSQL & " ORDER BY CTM_ENAME"
		case 3:		strSQL = strSQL & " ORDER BY VesselVoy"
		case 4:		strSQL = strSQL & " ORDER BY POL"
		case 5:		strSQL = strSQL & " ORDER BY POD"
		case 6:		strSQL = strSQL & " ORDER BY ETAETD"
		case 7:		strSQL = strSQL & " ORDER BY Quantity"
		case 8:		strSQL = strSQL & " ORDER BY BrokerRef"
		case 9:		strSQL = strSQL & " ORDER BY JobOperator"
		case 10:	strSQL = strSQL & " ORDER BY ReferNo"
		case 11:	strSQL = strSQL & " ORDER BY MBL"
		case 12:	strSQL = strSQL & " ORDER BY HBL"
		case 13:	strSQL = strSQL & " ORDER BY SalesTotal"
		end select
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup align=center>
			<colgroup span=6 align=left>
			<colgroup align=center>
			<colgroup span=2 align=left>
			<colgroup align=right>
			<colgroup align=left>
			<colgroup align=center>
			<colgroup align=right>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">Job ��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">B/L�׎�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(10)">�_��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�֖�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�o���`
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�ړI�`
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">���o�`��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(11)">MB/L ��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(12)">HB/L ��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">�㗝�X
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">�Ɩ�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(13)">����
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else						
						if GetLong(.Fields("FinisherID")) = 0 then
							mycolor = "#000000"
						else
							mycolor = "#606060"
						end if
						
						ClientName = GetString(.Fields("CTM_ENAME"))
						BrokerRef = GetString(.Fields("BrokerRef"))
						VesselVoy = GetString(.Fields("VesselVoy"))
						ReferNo = GetString(.Fields("InvoiceNo"))
						if ReferNo = "" then ReferNo = GetString(.Fields("ReferNo"))
						POL = GetString(.Fields("POL"))
						POD = GetString(.Fields("POD"))
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
						 onclick="ShowDetail('<%=.Fields("JobCode")%>', '<%=.Fields("SubCode")%>');">
						<TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=ShowSeaJobNo(.Fields("JobCode"), .Fields("SubCode"))%><BR>
						<TD nowrap class=line <%=ShowTitle(ClientName, 20)%>><%=stringCut(ClientName, 20)%><BR>
						<TD nowrap class=line <%=ShowTitle(ReferNo, 10)%>><%=stringCut(ReferNo, 10)%><BR>
						<TD nowrap class=line <%=ShowTitle(VesselVoy, 18)%>><%=stringCut(VesselVoy, 18)%><BR>
						<TD nowrap class=line <%=ShowTitle(POL, 8)%>><%=stringCut(POL, 8)%><BR>
						<TD nowrap class=line <%=ShowTitle(POD, 8)%>><%=stringCut(POD, 8)%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("ETAETD"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("MBL"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("HBL"))%><BR>
						<TD nowrap class=line><%=GetDouble(.Fields("Quantity"))%><BR>
						<TD nowrap class=line <%=ShowTitle(BrokerRef, 8)%>><%=stringCut(BrokerRef, 8)%><BR>
						<TD nowrap class=line><%=GetEmployName(.Fields("JobOperator"), "F")%><BR>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("SalesTotal")), 0, true)%>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
				
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>
