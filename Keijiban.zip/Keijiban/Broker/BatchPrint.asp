<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'----------------------------------------------
'	�������ꊇ�������
'----------------------------------------------

'	Response.Buffer = True

on error resume next
dim JobCodes
dim myCnt
dim mySel
dim myURL()

mode = GetLong(request("mode"))			'1:A/N	10:Receipt	100:D/O		1000:Copy
myType = GetLong(request("type"))		'9:DC����
JobCodes = GetPost(request("JobCodes"))
JobCodes = replace(JobCodes, " ", "")
JobCodes = replace(JobCodes, ",", "','")
if mode <> 0 AND JobCodes <> "" then

	OpenSql Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject("adodb.recordset") 
	
	myCnt = 0
	myCols = "100%"
	mySel = right("0000" & mode, 4)
	
	With Recset
		strSQL = "SELECT JobCode, SubCode, POD, JobShipment, SettleNumber FROM TBL_SEA_JOB WHERE Deleted = 0 AND JobType = '" & gsImport & "'"
		if myType = 9 then
			strSQL = strSQL & " AND JobBroker = 'DCP1011' AND POD = 'TOKYO'"
		else
			select case Session("BrokerCode") 
			case "DCP1003", "DCP1006"
				strSQL = strSQL & " AND (JobBroker = 'DCP1003' OR JobBroker = 'DCP1006')"
			case else
				strSQL = strSQL & " AND JobBroker = '" & Session("BrokerCode") & "'"
			end select
		end if
		strSQL = strSQL & " AND CASE SubCode WHEN 0 THEN JobCode ELSE JobCode+'-'+CAST(SubCode AS VARCHAR) END IN ('" & JobCodes & "')"
		strSQL = strSQL & " ORDER BY JobCode DESC, SubCode DESC"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		do while not .eof
			POD = GetString(.fields("POD"))
			JobShipment = GetLong(.fields("JobShipment"))
			SettleNumber = GetLong(.fields("SettleNumber"))
			myPara = "JobCode=" & GetString(.fields("JobCode")) & "&SubCode=" & GetString(.fields("SubCode"))
			myPara = myPara & "&print=1&mode=" & myType
			if JobShipment = 4 then
				if mid(mySel, 1, 1) = "1" then
					myCnt = myCnt + 1
					myCols = myCols & ",0"
					redim preserve myURL(myCnt)
					myURL(myCnt) = "DeliveryOrder.asp?type=1&" & myPara
				end if
				if mid(mySel, 2, 1) = "1" then
					myCnt = myCnt + 1
					myCols = myCols & ",0"
					redim preserve myURL(myCnt)
					myURL(myCnt) = "DeliveryOrder.asp?" & myPara
				end if
				if mid(mySel, 3, 1) = "1" and SettleNumber = 0 then
					myCnt = myCnt + 1
					myCols = myCols & ",0"
					redim preserve myURL(myCnt)
					myURL(myCnt) = "ConsoliReceipt.asp?" & myPara
				end if
				if mid(mySel, 4, 1) = "1" then
					myCnt = myCnt + 1
					myCols = myCols & ",0"
					redim preserve myURL(myCnt)
					myURL(myCnt) = "ConsoliAN.asp?" & myPara
				end if
			else
				if mid(mySel, 3, 1) = "1" and SettleNumber = 0 then
					myCnt = myCnt + 1
					myCols = myCols & ",0"
					redim preserve myURL(myCnt)
					myURL(myCnt) = "ImportReceipt.asp?" & myPara
				end if
				if mid(mySel, 4, 1) = "1" then
					myCnt = myCnt + 1
					myCols = myCols & ",0"
					redim preserve myURL(myCnt)
					myURL(myCnt) = "ImportAN.asp?" & myPara
				end if
			end if
			.movenext
		loop
		.Close
	end with
	
	if myCnt = 0 then
		ShowMessage "�Y���f�[�^�͌�����܂���ł���"
	elseif myCnt = 1 then
		response.redirect myURL(myCnt)
	else
		myCols = left(myCols, len(myCols) - 2)
%>
		<HTML>
			<HEAD>
				<TITLE>����v���r���[</TITLE>
				<META http-equiv=Content-Type content="text/html; charset=shift-jis">
			</HEAD>
			<FRAMESET COLS="<%=myCols%>" FRAMEBORDER=0 ID="fraPrint" NAME="fraPrint">
<%for i = 1 to myCnt%>
				<FRAME name="Print<%=i%>" SRC="<%=myURL(i)%>">
<%next%>
			</FRAMESET>
		</HTML>
<%
	end if
	
	strSQL = "UPDATE TBL_SEA_JOB SET DeliveryDate = '" & Date2Str(date) & "' WHERE Deleted = 0 AND DeliveryDate = ''"
	if myType = 9 then
		strSQL = strSQL & " AND JobBroker = 'DCP1011' AND POD = 'TOKYO'"
	else
		select case Session("BrokerCode") 
		case "DCP1003", "DCP1006"
			strSQL = strSQL & " AND (JobBroker = 'DCP1003' OR JobBroker = 'DCP1006')"
		case else
			strSQL = strSQL & " AND JobBroker = '" & Session("BrokerCode") & "'"
		end select
	end if
	strSQL = strSQL & " AND CASE SubCode WHEN 0 THEN JobCode ELSE JobCode+'-'+CAST(SubCode AS VARCHAR) END IN ('" & JobCodes & "')"
	Conn.Execute strSQL
	
	if GetLong(mode) > 9 then		'A/N�J�E���g�Ȃ�
		strSQL = "UPDATE TBL_SEA_JOB SET PrintCnt = PrintCnt + 1 WHERE Deleted = 0"
		select case Session("BrokerCode") 
		case "DCP1003", "DCP1006"
			strSQL = strSQL & " AND (JobBroker = 'DCP1003' OR JobBroker = 'DCP1006')"
		case else
			strSQL = strSQL & " AND JobBroker = '" & Session("BrokerCode") & "'"
		end select
		strSQL = strSQL & " AND CASE SubCode WHEN 0 THEN JobCode ELSE JobCode+'-'+CAST(SubCode AS VARCHAR) END IN ('" & JobCodes & "')"
		Conn.Execute strSQL
	end if
	
	set Recset = Nothing
	CloseDB Conn
end if
	
'	Response.Flush
'	Response.End

%>
