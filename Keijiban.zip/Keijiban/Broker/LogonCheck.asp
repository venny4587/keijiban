<!-- #include file="DBConst.asp" -->
<!-- #include file="clsDBLogAccess.asp" -->
<%
'On Error Resume Next

dim checkflag
dim GetUserID
dim GetPassWord
dim LogAccessID

Session("SqlServerName") = "SERVER"
Session("DataBaseName") = "BROKER"

checkflag = 0
GetUserID = request("userid")
GetPassWord = request("password")
LogAccessID = request("LogAccessID")

if GetUserID <> "" AND  GetPassWord <> "" then
	OpenSQL Conn, "127.0.0.1", "SAMPLE-CORP"
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT PIC_ID, CTM_CD, PIC_PWD, PIC_REMARKS FROM CTM_PIC WHERE PIC_UID = '" & GetUserID & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .EOF then
			if 	GetPassWord = cstr(.Fields("PIC_PWD") & "") then
				checkflag = 1
				Session("UserLogonID") = GetUserID
				Session("UserID") = clng(.Fields("PIC_ID"))
				Session("BrokerCode") = cstr(.Fields("CTM_CD") & "")
				IP_ADDR = cstr(.Fields("PIC_REMARKS") & "")
			end if
		end if
		.Close
		
		Session("BrokerBank") = 0
		if checkflag = 1 then
			strSql = "SELECT BANK_ID FROM CTM_BANK WHERE BANK_DELETED = 0 AND CTM_CD = '" & Session("BrokerCode") & "'"
			.Open strSql, Conn, adOpenKeyset, adLockReadOnly
			if NOT .EOF then Session("BrokerBank") = clng(.Fields("BANK_ID"))
			.Close
		end if
	end with
	set Recset = nothing
	CloseDB Conn
end if

if checkflag = 1 then

	Response.Cookies("TEST_UserID") = GetUserID
	Response.Cookies("TEST_UserID").Expires = #January 01, 2010# 
	Response.Cookies("TEST_Password") = GetPassWord
	Response.Cookies("TEST_Password").Expires = #January 01, 2010# 

	'LogAccess �� UserID ��������
	Set objDBLogAccess = New clsDBLogAccess
	objDBLogAccess.UpdateUserIDByAccessID LogAccessID, Session("UserID"), GetUserID
	Set objDBLogAccess = Nothing
	
	Session("LogAccessID") = LogAccessID
	response.redirect "brokermain.asp"
else
	Response.redirect "logon.asp"
end if
%>
