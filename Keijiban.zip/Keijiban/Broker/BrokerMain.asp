<!-- #include file="common.asp" -->
<%
myMenu = "BrokerMenu.asp"
myBody = "Welcome.asp"
%>
<HTML>
<HEAD>
<TITLE>�㗝�X�A�g�V�X�e��</TITLE>
<SCRIPT type="text/javascript">
var spoint = 3;
if (spoint==4){
	document.all("switchPoint").innerText=4;
	document.all("frmTitle").style.display="none";
}
function switchSysBar(){
	if (document.all("switchPoint").innerText==3){
		document.all("switchPoint").innerText=4;
		document.all("frmTitle").style.display="none";
	}else{
		document.all("switchPoint").innerText=3;
		document.all("frmTitle").style.display="";
	}
}

function ShowPop(mode) {
	if (mode==1) {
		var win = window.open("notice.htm","notice","width=620,height=500,scrollbars=1")
	}
}
</SCRIPT>
<STYLE type=text/css>
	.navPoint {COLOR: FF0000; CURSOR: hand; FONT-FAMILY: Webdings; FONT-SIZE: 9pt}
</STYLE>
</head>
<BODY scroll='no' style="MARGIN: 0px" id='all'  oncontextmenu="return false" onload="ShowPop(0)">
	<TABLE border='0' cellPadding='0' cellSpacing='0' height="100%" width="100%">
		<TBODY>
		<TR>
			<TD height="100%" align='middle' vAlign=center noWrap id=frmTitle name="frmTitle">
				<IFRAME frameBorder='0' id='menu' name='menu' scrolling='no' src="<%=myMenu%>" style="HEIGHT: 100%; VISIBILITY: inherit; WIDTH: 120px; Z-INDEX: 2"></IFRAME>
			</TD>
			<TD class="T2"  style="WIDTH: 9pt">
				<TABLE border='0' cellPadding='0' cellSpacing='0' height="100%">
				<TBODY>
				<tr>
					<TD onclick='switchSysBar()' style="HEIGHT: 100%;background-color: #FFF7DC;"><SPAN class='navPoint' id='switchPoint'>3</SPAN>
					</td></tr>
				</TBODY>
				</TABLE>
			</TD>
			<TD style="WIDTH: 100%"><IFRAME frameBorder='0' id='main' name='main' scrolling='auto' src="<%=myBody%>" style="HEIGHT: 100%; VISIBILITY: inherit; WIDTH: 100%; Z-INDEX: 1"></IFRAME>
			</TD>
		</TR>
	</TBODY>
	</TABLE>
</body>
</html>
