<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim JobCode
dim SubCode

JobCode = GetPost(request("JobCode"))
SubCode = GetLong(request("SubCode"))
if JobCode <> "" then

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM TBL_SEA_JOB WHERE JobCode = '" & JobCode & "' AND SubCode = " & SubCode
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			JobType = GetString(.fields("JobType"))
			JobBelong = GetString(.fields("JobBelong"))
			JobShipment = GetLong(.fields("JobShipment"))
			JobClient = GetString(.fields("JobClient"))
			JobPartner = GetString(.fields("JobPartner"))
			JobShipper = GetString(.fields("JobShipper"))
			JobOperator = GetString(.fields("JobOperator"))
			JobManager = GetLong(.fields("JobManager"))
			Size20 = GetString(.fields("Size20"))
			Size40 = GetString(.fields("Size40"))
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POL = GetString(.fields("POL"))
			POD2 = GetString(.fields("POD"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			MBL = GetString(.fields("MBL"))
			HBL = GetString(.fields("HBL"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Marks = ShowMarks(GetString(.fields("Marks")))
			Container = ShowMarks(GetString(.fields("Container")))
			
			CarrierCorp = GetString(.fields("CarrierCorp"))
			CarrierPic = GetString(.fields("CarrierPic"))
			JobBroker = GetString(.fields("JobBroker"))
			DoRelease = GetString(.fields("DoRelease"))
			DoRelease2 = GetString(.fields("DoRelease2"))
			WareHouse = GetString(.fields("WareHouse"))
			WareHouse2 = GetString(.fields("WareHouse2"))
			DeliveryDate = Str2MD(.fields("DeliveryDate"))
			ExchangeRate = GetDouble(.fields("ExchangeRate"))
			
			Telex = GetLong(.fields("Telex"))
			FarAway = GetLong(.fields("FarAway"))
			NeedMark = GetLong(.fields("NeedMark"))
			PreInput = GetLong(.fields("PreInput"))
			DoConfirm = GetLong(.fields("DoConfirm"))
			Remarks = GetString(.fields("Remarks"))
			SalesDate = formatdate(.fields("SalesDate"))
		end if
		.close
		
		StrSql = "SELECT POD FROM TBL_SEA_JOB WHERE JobCode = '" & JobCode & "' AND SubCode = 0"
		select case Session("BrokerCode") 
		case "DCP1003", "DCP1006"
			strSQL = strSQL & " AND (JobBroker = 'DCP1003' OR JobBroker = 'DCP1006')"
		case else
			strSQL = strSQL & " AND JobBroker = '" & Session("BrokerCode") & "'"
		end select
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			POD = GetString(.fields("POD"))
		else
			PreInput = 1
		end if
		.close
	end with
	
	if PreInput = 0 then
%>
<html>
<head>
	<title>Receipt</title>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<style>
		.pts { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptr { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.pth { FONT-FAMILY: Tahoma; �l�r �S�V�b�N; FONT-SIZE: 15px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptj { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 14px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptk { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 16px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptm { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 15px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptn { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 14pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptl { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptx { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 16pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.pty { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 20pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		
		.mi{FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
		.mn{FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;TEXT-ALIGN:right}
		.mb{FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
	</style>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub DoShortCut()	
			if window.event.keyCode=27 then window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	//-->
	</SCRIPT>
</head>
<body onkeydown="DoShortCut()" class=pts OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
<center><br><br>
	<table width=660 class=pts border=0>
		<tr><td width=300 class=pty rowspan=2 valign=top><u>Receipt</u><td width=100>Invoice ��&nbsp;
			<td width=250 class=ptx><%=replace(JobCode, "-", " - ")%><%if SubCode <> 0 then response.write " - " & SubCode%>
		<tr><td nowrap>House B/L ��&nbsp;<td nowrap class=pth><%=HBL%>
		<tr><td nowrap>Messrs.
			<td nowrap>�����m�F ��&nbsp;<td nowrap class=pth><%=MBL%>
	</table>
	<table width=660 class=pts border=0 height=80>
		<tr><td width=280 class=ptm valign=top><%=GetCtmName(JobClient)%>
			<td width=20>
			<td width=360><font class=ptl>COMPANY  CO., LTD.</font><br>
							<font class=ptl>�T���v���������</font><br>
											��123-4567 �����s�����搼����˃r������<br>
							<font class=ptj>TEL: 01-1111-1111�@FAX: 02-2222-2222</font></b>
	</table>
	<hr width=660 size=1 color=black>
	<table width=660 border=0 class=pts>
		<tr><td width=60>Vessel<td width=600 class=ptm><%=Vessel%>
			<td width=280 rowspan=4 valign=top class=ptm>
			<%if PreInput then%><font style="font-size:28pt;LINE-HEIGHT:1.2em">�֎~</font><%end if%>
		<tr><td>Voyage<td class=ptm><%=Voy%>
		<tr><td>From<td class=ptm><%=POL%>�@�@<font class=pts>To</font>�@<%=POD2%>
<%if JobType = gsImport then%>
		<tr><td>ETA<td class=ptm><%=ETA%>
<%else%>
		<tr><td>ETD<td class=ptm><%=ETD%>
<%end if%>
	</table>
	<hr width=660 size=1 color=black>
	<table width=660 class=pts border=0>
		<colgroup span=2 align=left>
		<colgroup span=2 align=right>
		<tr valign=top height=24>
			<td width=200>Nos Packages
			<td width=200>Description
			<td width=100>Gross Weight
			<td width=100>Measure
		<tr height=80 valign=top>
			<td rowspan=3 class=ptr><%=Marks%>
			<td class=ptm><%=Commodity%>
			<td class=ptn><%=formatnumber(GW, 2, true)%>&nbsp;<br><font class=pts>KGS</font>
			<td class=ptn><%=formatnumber(CBM, 3, true)%>&nbsp;<br><font class=pts>M<sup>3</sup></font>
		<tr height=50 valign=top>
			<td class=ptn align=center><%=FitZero(formatnumber(Quantity,3,true))%>�@<font class=pts><%=Package%></font>
			<td colspan=2 align=center><%if Telex then%><font style="font-size:20pt;LINE-HEIGHT:1.1em"><u><i>���n�����</font></i></u><%end if%>
	</table>
	<table width=660 border=0 class=pts>
		<tr><td width=320>D/O���s�ꏊ
			<td width=20>
			<td width=320>������
		<tr height=60 valign=top>
			<td width=320 class=ptj wrap><%=DoRelease%><br><%=DoRelease2%>
			<td width=20>
			<td width=320 class=ptj wrap><%=WareHouse%><br><%=WareHouse2%>
	</table>
	<hr width=660 size=1 color=black>
	<table border=0><tr><td valign=top align=right height=30>
	  <table width=660 class=ptr>
		<colgroup align=left>
		<colgroup span=2 align=right class=ptm>
		<tr><td align=right>EX RATE
			<td align=center class=ptr>@\<%=ExchangeRate%>
<%
	cnt = 0
	sum = 0
	weight = 0
	with Recset
		StrSql = "SELECT E.*, COST_REF, COST_ENAME FROM TBL_SEA_EXPENSE AS E INNER JOIN MST_COST AS M"
		StrSql = StrSql & " ON E.ExpenseCost = M.COST_ID WHERE E.Deleted = 0 AND ExpenseAttr <> 0"
		StrSql = StrSql & " AND JobCode = '" & JobCode & "' AND SubCode = " & SubCode
		StrSql = StrSql & " AND ExpenseType = " & gsCharge & " ORDER BY COST_REF, SeqNo"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		do while not .eof
%>
		<tr><td><%=ShowExpenseName(.fields("ExpenseCost"), .fields("ExpenseMemo"), .fields("COST_ENAME"))%>
			<td><%if GetLong(.fields("ExpenseCost")) = gsOcean then%>
				<%=GetCurShort(.fields("ExpenseCurrency"))%><font class=ptk><%=formatnumber(GetDouble(.fields("ExpenseAmount")),2,true)%></font>
				<%end if%>
			<td>\<font class=ptk><%=formatnumber(GetLong(.fields("ExpenseTotal")),0,true)%></font>
<%
			cnt = cnt + 1
			sum = sum + GetLong(.fields("ExpenseTotal"))
			if GetLong(.fields("ExpenseCost")) = gsWeight then weight = 1
			.movenext
		loop
		.Close
	end with
%>
		<tr><td colspan=3><hr size=1 color=black>
	  	<tr><td><td class=ptl>���v<td class=ptl>\<font class=ptn><%=formatnumber(sum, 0, true)%></font>
	  </table>
<!--
	  <table width=300 border=0 class=pts>
	  	<tr><td height=100><br>
		<tr><td><hr size=1 color=black>COMPANY  CO., LTD.
	</table>
-->
</center>
<%if GetLong(request("print")) = 1 then%>
	<script languange=vbscript>
		window.print()
	</script>
<%end if%>
</body>
</html>
<%
	end if
	set Recset = nothing
	CloseDB Conn
end if
%>
