<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim JobCode
dim JobType

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobCode = GetPost(request("JobCode"))
	SubCode = GetLong(request("SubCode"))
	with Recset
		strSQL = "SELECT * FROM TBL_SEA_JOB WHERE Deleted = 0"
		strSQL = strSQL & " AND JobCode = '" & JobCode & "' AND SubCode = '" & SubCode & "'"
		select case Session("BrokerCode")
		case "DCP1003", "DCP1006"
			strSQL = strSQL & " AND (JobBroker = 'DCP1003' OR JobBroker = 'DCP1006')"
		case else
			strSQL = strSQL & " AND JobBroker = '" & Session("BrokerCode") & "'"
		end select
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		if not .eof then
			JobType = GetString(.fields("JobType"))
			JobShipment = GetLong(.fields("JobShipment"))
			JobBelong = GetString(.fields("JobBelong"))
			JobCountry = GetString(.fields("JobCountry"))
			JobClient = GetString(.fields("JobClient"))
			JobPartner = GetString(.fields("JobPartner"))
			JobShipper = GetString(.fields("JobShipper"))
			JobService = GetString(.fields("JobService"))
			JobManager = GetLong(.fields("JobManager"))
			JobSalesman = GetLong(.fields("JobSalesman"))
			JobOperator = GetLong(.fields("JobOperator"))
			NeedSales = GetLong(.fields("NeedSales"))
			
			Size20 = GetLong(.fields("Size20"))
			Size40 = GetLong(.fields("Size40"))
			Type20 = GetString(.fields("Type20"))
			Type40 = GetString(.fields("Type40"))
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POLN = GetString(.fields("POLN"))
			POL = GetString(.fields("POL"))
			PODN = GetString(.fields("PODN"))
			POD = GetString(.fields("POD"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			MBL = GetString(.fields("MBL"))
			HBL = GetString(.fields("HBL"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			RTON = GetDouble(.fields("RTON"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Telex = GetLong(.fields("Telex"))
			Container = GetString(.fields("Container"))
			Marks = GetString(.fields("Marks"))
			NeedMark = GetLong(.fields("NeedMark"))
			
			JobBroker = GetString(.fields("JobBroker"))
			CarrierCorp = GetString(.fields("CarrierCorp"))
			CarrierPic = GetString(.fields("CarrierPic"))
			DoRelease = GetString(.fields("DoRelease"))
			DoRelease2 = GetString(.fields("DoRelease2"))
			WareHouse = GetString(.fields("WareHouse"))
			WareHouse2 = GetString(.fields("WareHouse2"))
			FarAway = GetLong(.fields("FarAway"))
			PreInput = GetLong(.fields("PreInput"))
			DoConfirm = GetLong(.fields("DoConfirm"))
			
			JobMemo = GetString(.fields("JobMemo"))
			Remarks = GetString(.fields("Remarks"))
			FinisherID = GetLong(.fields("FinisherID"))
			FinishDate = GetDate(.fields("FinishDate"))
			LockerID = GetLong(.fields("LockerID"))
			LockDate = GetDate(.fields("LockDate"))
			Canceled = GetLong(.fields("Canceled"))
			
			ReferNo = GetString(.fields("ReferNo"))
			InvoiceNo = GetString(.fields("InvoiceNo"))
			ExchangeRate = GetDouble(.fields("ExchangeRate"))
			PriceRateFAF = GetDouble(.fields("PriceRateFAF"))
			DeliveryDate = Str2Date(.fields("DeliveryDate"))
			SalesDate = Str2Date(.fields("SalesDate"))
			SettleNumber = GetLong(.fields("SettleNumber"))
			SettleDate = Str2Date(.fields("SettleDate"))
			
			Creater = GetLong(.fields("Creater"))
			Created = FmtDateTime(.fields("Created"))
			Updater = GetLong(.fields("Updater"))
			Updated = FmtDateTime(.fields("Updated"))
		else
			msg = "�Y���f�[�^��������܂���ł����B"
		end if
		.close
	end with
		
	if msg <> "" then 
		response.write "<font color=red>" & msg & "</font>"
	else
		JobCountry = GetCountryName(JobCountry)
		if JobShipment = 4 then
			myFont = "g"
		else
			myFont = ""
		end if
%>
<html>
<HEAD>
	<TITLE>�Ɩ��ڍ׏��</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<SCRIPT language=vbscript src="css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub Move_OnChange()
		dim buf 
			buf = frmInput.Move.options(frmInput.Move.SelectedIndex).value
			call DoMove(buf)
		end sub
		
		function DoMove(cd)
			window.parent.location.href = "BrokerDetail.asp?JobCode=<%=JobCode%>&SubCode=" & cd
		end function
		
		sub DoPrint(mode)
		dim url, buf
			buf = mode
			if buf = 0 then
				if frmInput.AN.checked then buf = buf + GetLong(frmInput.AN.value)
				if frmInput.RC.checked then buf = buf + GetLong(frmInput.RC.value)
				if frmInput.DO.checked then buf = buf + GetLong(frmInput.DO.value)
				if frmInput.DC.checked then buf = buf + GetLong(frmInput.DC.value)
			end if
			if buf = 0 then
				msgbox "������钠�[�����I�����������B"
			else
				'window.location.href = "BrokerPrint.asp?JobCode=<%=JobCode%>&SubCode=<%=SubCode%>&mode=" & buf
				window.location.href = "BatchPrint.asp?JobCodes=<%=ShowSeaJobNo(JobCode, SubCode)%>&mode=" & buf
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
		end sub
		
		sub InitForm()
			'frmInput.btnPrint.focus()
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" 
		  OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>	
<center>
  <FORM NAME="frmInput" action="BrokerDetail.asp" method="post">
	<table width=90% Border=0 Cellspacing=0 CellPadding=0>
	�@<tr><td width=50% valign=top>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9<%=myFont%>>
		  <TR height=30 valign=bottom>
		  	  <td nowrap>��B/L���&nbsp;
		 	  <td nowrap align=center>JOB �� <font class=pt12b><b><%=ShowSeaJobNo(JobCode, SubCode)%></b></font>
		  <TR><td colspan=2><hr width=98% size=1 color=blue>
		</table>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9<%=myFont%>>
		  <TR height=30><TD colspan=4>CONSIGNEE
		  				<input class=si name="Commodity" size=40 maxlength=100 value=" <%=replace(GetCtmName(JobClient), """", "�h")%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>VESSEL<TD colspan=3>
		  				<input class=si name="Vessel" size=20 maxlength=50 value=" <%=Vessel%>" onkeydown="ResetEnter()" readonly>
					�@	VOY&nbsp;<input class=si name="Voy" size=10 maxlength=20 value=" <%=Voy%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>POL<TD colspan=3>
		  				<input class=si name="POL" size=20 maxlength=50 value=" <%=POL & "," & JobCountry%>" onkeydown="ResetEnter()" readonly>
		  			�@	POD&nbsp;<input class=si name="POD" size=10 maxlength=50 value=" <%=POD%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>ETD<TD><input class=si name="ETD" size=11 maxlength=10 value=" <%=ETD%>" onkeydown="ResetEnter()" readonly>
						<TD>ETA<TD><input class=si name="ETA" size=11 maxlength=10 value=" <%=ETA%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>MB/L ��<TD colspan=3>
		  				<input class=si name="MBL" size=24 maxlength=50 value=" <%=MBL%>" onkeydown="ResetEnter()" readonly>
					�@	20'x<input class=sn name="Size20" size=3 maxlength=2 value="<%=Size20%>" onkeydown="ResetEnter()" readonly><%=Type20%>
		  <TR height=30><TD>HB/L ��<TD colspan=3>
		  				<input class=si name="HBL" size=24 maxlength=50 value=" <%=HBL%>" onkeydown="ResetEnter()" readonly>
					�@	40'x<input class=sn name="Size40" size=3 maxlength=2 value="<%=Size40%>" onkeydown="ResetEnter()" readonly><%=Type40%>
		  <TR height=30><TD colspan=4>COMMODITY
		  				<input class=si name="Commodity" size=40 maxlength=100 value=" <%=Commodity%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>PACKAGE<TD colspan=2>
		  				<input class=sn name="Quantity" value="<%=FitZero(formatnumber(Quantity,3,true))%>" size=8 maxlength=8 OnKeyDown="ResetEnter()" readonly>
		  				<input class=si name="Package" value="<%=Package%>" size=10 maxlength=50 OnKeyDown="ResetEnter()" readonly>
		  			�@	<TD><%if Telex then%><font class=pt12b><b>���n���</b></font><%end if%>
		  <TR height=30><TD>WEIGHT<TD><input class=sn name="GW" value="<%=FitZero(formatnumber(GW,3,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()" readonly>&nbsp;KGS
						<TD>M'MENT<TD><input class=sn name="CBM" value="<%=formatnumber(CBM,3,true)%>" size=9 maxlength=10 OnKeyDown="ResetEnter()" readonly>&nbsp;M<sup>3</sup>
		  <TR height=30><TD colspan=2>MARKS<TD colspan=2>CONTAINER ��
		  <TR height=30><TD colspan=2><textarea name="Marks" rows=12 style="width:160" readonly><%=Marks%></textarea>
						<TD colspan=2><textarea name="Container" rows=12 style="width:150" readonly><%=Container%></textarea>
		</table>
	  <td width=50% valign=top align=center>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9<%=myFont%>>
		  <TR height=30 valign=bottom>
		 	  <td nowrap>���Ɩ����&nbsp;
		 	  <td nowrap align=right><%if JobShipment = 4 or JobShipment = 6 then%>���� <%=ShowBar()%><%end if%>
		  <TR><td colspan=2><hr width=98% size=1 color=blue>
		</table>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9<%=myFont%>>
		  <TR height=30><TD nowrap>�㗝�X <input class=sj name="JobBroker" size=50 maxlength=50 value="<%=GetFullName(JobBroker)%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>D/O�@�@<input class=sj name="DoRelease" size=50 maxlength=50 value="<%=DoRelease%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>D/O 2�@<input class=sj name="DoRelease2" size=50 maxlength=50 value="<%=DoRelease2%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>�q�� �@<input class=sj name="WareHouse" size=50 maxlength=50 value="<%=WareHouse%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD>�q��2�@<input class=sj name="WareHouse2" size=50 maxlength=50 value="<%=WareHouse2%>" onkeydown="ResetEnter()" readonly>
		  <TR height=30><TD class=pt12r align=center><%if PreInput then%>�������܋֎~��<%elseif SettleDate <> "" then%><b><%=SettleDate%>�@������</b><%end if%>
		</table>
		<hr size=1><font class=pt12<%=myFont%>>���ވ��</font><hr size=1><br>
		<table Border=0 Cellspacing=0 CellPadding=0 class=pt9<%=myFont%>>
<!--
		  <TR height=50>
		  	<TD><input type=checkbox name="AN" value="1" onkeydown="ResetEnter()" checked>
			<TD><input type=button class=pt12b style="width:160;height:40" name=btnAN  value="Arrive Notice" onclick="DoPrint(1)">
			<TD rowspan=2>�@<input type=button class=pt12b style="width:100;height:80" name=btnTwo  value="�Q���Z�b�g" onclick="DoPrint(110)">
		  <TR height=50>
		  	<TD><input type=checkbox name="RC" value="10" onkeydown="ResetEnter()" checked>
			<TD><input type=button class=pt12b style="width:160;height:40" name=btnRC  value="Freight Receipt" onclick="DoPrint(10)">
		  <TR height=50>
		  	<TD><input type=checkbox name="DO" value="100" onkeydown="ResetEnter()" checked>
			<TD><input type=button class=pt12b style="width:160;height:40" name=btnDO  value="Delivery Order" onclick="DoPrint(100)">
		  <TR height=50>
		  	<TD><input type=checkbox name="DC" value="1000" onkeydown="ResetEnter()" checked>
			<TD><input type=button class=pt12b style="width:160;height:40" name=btnDC  value="Delivery Copy" onclick="DoPrint(1000)">
			<TD rowspan=2>�@<input type=button class=pt12b style="width:100;height:80" name=btnTwo  value="�S���Z�b�g" onclick="DoPrint(110)">
		  <TR height=50>
		  	<TD><TD><input type=button class=pt12b style="width:160;height:40" name=btnPrint value="�Z�b�g���" onclick="DoPrint(0)">
-->
<%if JobShipment = 4 then%>
		  <TR height=50>
			<TD rowspan=2><input type=button class=pt12b style="width:120;height:90" name=btnTwo  value="�Q���Z�b�g" onclick="DoPrint(110)">
			<TD>�@<input type=button class=pt12b style="width:160;height:36" name=btnAN  value="Arrive Notice" onclick="DoPrint(1)">
		  <TR height=50>
			<TD>�@<input type=button class=pt12b style="width:160;height:36" name=btnRC  value="Freight Receipt" onclick="DoPrint(10)">
		  <TR height=50>
			<TD rowspan=2><input type=button class=pt12b style="width:120;height:90" name=btnFour  value="�S���Z�b�g" onclick="DoPrint(1111)">
			<TD>�@<input type=button class=pt12b style="width:160;height:36" name=btnDO  value="Delivery Order" onclick="DoPrint(100)">
		  <TR height=50>
			<TD>�@<input type=button class=pt12b style="width:160;height:36" name=btnDC  value="Delivery Copy" onclick="DoPrint(1000)">
<%else%>
		  <TR height=50>
			<TD><input type=button class=pt12b style="width:160;height:36" name=btnTwo  value="�Q���Z�b�g" onclick="DoPrint(11)">
		  <TR height=50>
			<TD><input type=button class=pt12b style="width:160;height:36" name=btnAN  value="Arrive Notice" onclick="DoPrint(1)">
		  <TR height=50>
			<TD><input type=button class=pt12b style="width:160;height:36" name=btnRC  value="Freight Receipt" onclick="DoPrint(10)">
<%end if%>
		</table>
		<br><hr size=1>
<%if JobShipment = 4 then%>
		<font class=pt9>���Q���Z�b�g�F�uFreight Receipt�v�{�uDelivery Order�v�@&nbsp;</font>
<%else%>
		<font class=pt9>���Q���Z�b�g�F�uArrive Notice�v�{�uFreight Receipt�v�@&nbsp;</font>
<%end if%>
	</table>
  </FORM>
<center>
</body></html>
<%
	end if
	
	Set Recset = nothing
	CloseDB Conn
%>


<%
function ShowBar()
dim maxcd, precd, nextcd
dim buf, myRec, myCon
	ShowBar = ""
	OpenSql myCon, SqlServerName, DataBaseName
	set myRec = Server.CreateObject("adodb.recordset") 
	with myRec
		buf = ""
		strSql = "SELECT SubCode FROM TBL_SEA_JOB WHERE Deleted = 0 AND SubCode <> 0 AND JobCode = '" & JobCode & "'"
		strSql = strSql & " ORDER BY SubCode"
		.Open strSql,myCon,adOpenStatic,adLockReadOnly
		do while not .eof
			maxcd = GetLong(.fields("SubCode"))
			buf = buf & "<option value=" & maxcd
			if SubCode = maxcd then buf = buf & " selected"
			buf = buf & ">" & maxcd
			.movenext
		loop
		.close
		
		precd = 1
		if SubCode > 1 then
			strSql = "SELECT TOP 1 SubCode FROM TBL_SEA_JOB WHERE Deleted = 0 AND SubCode <> 0 AND JobCode = '" & JobCode & "'"
			strSql = strSql & " AND SubCode < " & SubCode &" ORDER BY SubCode DESC"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then precd = GetString(.fields("SubCode"))
			.close
		end if
		
		nextcd = maxcd
		if SubCode < maxcd then
			strSql = "SELECT TOP 1 SubCode FROM TBL_SEA_JOB WHERE Deleted = 0 AND SubCode <> 0 AND JobCode = '" & JobCode & "'"
			strSql = strSql & " AND SubCode > " & SubCode &" ORDER BY SubCode"
			.Open strSql,conn,adOpenStatic,adLockReadOnly
			if not .eof then nextcd = GetString(.fields("SubCode"))
			.close
		end if
	end with
	set myRec = nothing
	CloseDB myCon
	
	if SubCode > 1 then ShowBar = ShowBar & "<a class=bar href=""javascript:DoMove(" & precd & ")"">�O��</a>&nbsp;"
	ShowBar = ShowBar & "<select name=Move>" & buf & "</select>&nbsp;"
	if SubCode <> maxcd then ShowBar = ShowBar & "<a class=bar href=""javascript:DoMove(" & nextcd & ")"">����</a>&nbsp;"
end function

function CheckSubExist()
dim mySql
dim myRec
dim myCon
	CheckSubExist = 0
	if SubCode <> 0 then
		CheckSubExist = 1
	else
		OpenSQL myCon, SqlServerName, DatabaseName
		set myRec = Server.CreateObject ("ADODB.Recordset")
		
		mySql = "SELECT SubCode FROM TBL_SEA_JOB WHERE Deleted = 0 AND SubCode <> 0 AND JobCode = '" & JobCode & "'"
		myRec.Open mySql, myCon, adOpenKeyset, adLockReadOnly
		if not myRec.eof then CheckSubExist = 1
		myRec.close
		set myRec = nothing	
		CloseDB myCon
	end if
end function
%>