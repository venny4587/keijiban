<!-- #include file="common.asp" -->
<!-- #include file="function.asp" -->
<%
	dim mode
	mode = GetLong(Request("Mode"))
%>
<html>
<head>
	<title>PASSWORD CHANGE</title>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<link rel="stylesheet" href="css/style.css" type="text/css">	
	<SCRIPT LANGUAGE="JavaScript">
<!--
	function ResetEnter() {
		if (event.keyCode == 13) {
			window.event.keyCode = 9;
		}
	}
	
	function CheckInput() {
		usernamenull.innerHTML =  "";
		pwdnull.innerHTML =  "";
		pwdCfmnull.innerHTML =  "";
		if (frmInput.pwdCurrent.value == "") {
			frmInput.pwdCurrent.focus();
			usernamenull.innerHTML =  "���݂̃p�X���[�h�������͂��������B";
		} else {
			if (frmInput.password.value == "") {
				frmInput.password.focus();				
				pwdnull.innerHTML =  "�V�����p�X���[�h�������͂��������B";
			} else {
				if (frmInput.pwdConfirm.value == "") {
					frmInput.pwdConfirm.focus();
					pwdCfmnull.innerHTML =  "�m�F�p�p�X���[�h�������͂��������B";			
				}else{
					if (frmInput.password.value != frmInput.pwdConfirm.value) {
						frmInput.pwdConfirm.focus();
						pwdCfmnull.innerHTML =  "�m�F�p�p�X���[�h�͊ԈႢ�ł����B";
					}
					else{
						frmInput.submit();
					}
				}
			}
		}
	}
//-->
</SCRIPT>
</head>

<body OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
	<center>
		<form name="frmInput" action="PwdUpdate.asp" method=post>
			<input type=hidden name="mode" value="<%=mode%>">
			<br><br>
			<TABLE width=600>
				<TR valign=middle><TD>			      
					<TABLE width=300 bgcolor=#F0F0F0 class=pt9n>
				  		<TR align=center height=40>
				  			<TD colspan=2>�p�X���[�h�ύX</TD>
						</TR>
				  		<TR><TD colspan=2><hr></TD></TR>
				  		<TR height=30>
				  			<TD width=140 align=right>���݂̃p�X���[�h</TD>
							<TD width=160 align=center>
								<input class=pt9n style="height:20;width:120" type="password" name="pwdCurrent" maxlength=20 size=15 OnKeyDown="ResetEnter()"></TD>
						</TR>
				  		<TR height=30>
				  			<TD align=right>�V�����p�X���[�h</TD>
							<TD align=center>
								<input class=pt9n style="height:20;width:120" type="password" name="password" maxlength=20 size=15 OnKeyDown="ResetEnter()"></TD>
						</TR>
				  		<TR height=30>
				  			<TD align=right>�m�F�p�p�X���[�h</TD>
							<TD align=center>
								<input class=pt9n style="height:20;width:120" type="password" name="pwdConfirm" maxlength=20 size=15 OnKeyDown="ResetEnter()"></TD>
						</TR>
				  		<TR><TD colspan=2><hr></TD></TR>
<%
	if mode > 0 then 
%>
				  		<TR><TD colspan=2 class=pt12 align=center><%
							if mode = 1 then 
								response.write "<font class=pt9b>�M���̃p�X���[�h�͐������ύX����܂����B</font>"
							else
								response.write "<font class=pt9r>���͂��ꂽ���݂̃p�X���[�h�͕s���ł��B</font>"
							end if
							%></TD></TR>
				  		<TR><TD colspan=2><hr></TD></TR>
<%
	end if 
%>
				  		<TR align=center height=60>
				  			<TD colspan=2><input type="button" style="width:90px;height:30px;" value="OK" onclick="CheckInput()"></TD>
						</TR>
					</TABLE>
				</TD><TD valign=top>
					<TABLE width=250 border=0 class=pt9b>
				  		<TR align=center height=50><TD colspan=2><br></TD></TR>
						<TR height=30 valign=center><TD>&nbsp;<div name="usernamenull" id="usernamenull"></div></td></TR>
						<TR height=30 valign=center><TD>&nbsp;<div name="pwdnull" id="pwdnull"></td></TR>
						<TR height=30 valign=center><TD>&nbsp;<div name="pwdCfmnull" id="pwdCfmnull"></td></TR>
					</TABLE>
				</TD></TR>
			</TABLE>
		</form>
	</center>
</body>
</html>
