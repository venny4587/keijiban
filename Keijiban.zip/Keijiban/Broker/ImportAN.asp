<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim JobCode
dim SubCode

JobCode = GetPost(request("JobCode"))
SubCode = GetLong(request("SubCode"))
if JobCode <> "" then

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM TBL_SEA_JOB WHERE JobCode = '" & JobCode & "' AND SubCode = " & SubCode
		StrSql = StrSql & " AND JobBroker = '" & UserCode & "'"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			JobType = GetString(.fields("JobType"))
			JobBelong = GetString(.fields("JobBelong"))
			JobShipment = GetLong(.fields("JobShipment"))
			JobClient = GetString(.fields("JobClient"))
			JobPartner = GetString(.fields("JobPartner"))
			JobShipper = GetString(.fields("JobShipper"))
			JobOperator = GetString(.fields("JobOperator"))
			JobManager = GetLong(.fields("JobManager"))
			Size20 = GetString(.fields("Size20"))
			Size40 = GetString(.fields("Size40"))
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			POL = GetString(.fields("POL"))
			POD = GetString(.fields("POD"))
			ETD = Str2Date(.fields("ETD"))
			ETA = Str2Date(.fields("ETA"))
			MBL = GetString(.fields("MBL"))
			HBL = GetString(.fields("HBL"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			Marks = ShowMarks(GetString(.fields("Marks")))
			Container = ShowMarks(GetString(.fields("Container")))
			
			CarrierCorp = GetString(.fields("CarrierCorp"))
			CarrierPic = GetString(.fields("CarrierPic"))
			JobBroker = GetString(.fields("JobBroker"))
			DoRelease = GetString(.fields("DoRelease"))
			DoRelease2 = GetString(.fields("DoRelease2"))
			WareHouse = GetString(.fields("WareHouse"))
			WareHouse2 = GetString(.fields("WareHouse2"))
			DeliveryDate = Str2MD(.fields("DeliveryDate"))
			ExchangeRate = GetDouble(.fields("ExchangeRate"))
			
			Telex = GetLong(.fields("Telex"))
			FarAway = GetLong(.fields("FarAway"))
			PreInput = GetLong(.fields("PreInput"))
			NeedMark = GetLong(.fields("NeedMark"))
			DoConfirm = GetLong(.fields("DoConfirm"))
			JobMemo = GetString(.fields("JobMemo"))
			Remarks = GetString(.fields("Remarks"))
			SalesDate = formatdate(.fields("SalesDate"))
		end if
		.close
		
		'�㗝�X�������o�^�̏ꍇ�Ή�
		BANK_NAME = "�f����s"
		BANK_BRANCH = "�f���x�X"
		BANK_TYPE = "���ʗa��"
		BANK_ACCOUNT = "7777777"
		BANK_HOLDER = "�f����p�������"
		
		strSQL = "SELECT BANK_NAME, BANK_BRANCH, BANK_TYPE, BANK_ACCOUNT, BANK_HOLDER, BANK_REMARKS"
		strSQL = strSQL & " FROM CTM_BANK WHERE BANK_DELETED = 0 AND CTM_CD = '" & JobBroker & "'"
		strSQL = strSQL & " ORDER BY BANK_DFT DESC"
		.Open strSQL, Conn, adOpenKeyset, adLockReadOnly
		if not .eof then 
			BANK_NAME = GetString(.fields("BANK_NAME"))
			BANK_BRANCH = GetString(.fields("BANK_BRANCH"))
			BANK_TYPE = GetString(.fields("BANK_TYPE"))
			BANK_ACCOUNT = GetString(.fields("BANK_ACCOUNT"))
			BANK_HOLDER = GetString(.fields("BANK_HOLDER"))
			BANK_REMARKS = GetString(.fields("BANK_REMARKS"))
		end if
		.close
	end with
%>
<html>
<head>
	<title>Arrival Notice / Freight Bill</title>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<style>
		.ptt { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.pts { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptr { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.pth { FONT-FAMILY: Tahoma; �l�r �S�V�b�N; FONT-SIZE: 15px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptj { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 14px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptk { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 16px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptm { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 15px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptn { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 14pt; LINE-HEIGHT: 1.1em; color: black }
		.ptl { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptx { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 16pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		
		.mi{FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
		.mn{FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;TEXT-ALIGN:right}
		.mb{FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; COLOR: #000000; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: #C0C0C0 1px solid;}
	</style>
	<SCRIPT LANGUAGE=vbscript>
	<!--
		sub DoShortCut()	
			if window.event.keyCode=27 then window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	//-->
	</SCRIPT>
</head>
<body onkeydown="DoShortCut()" class=pts OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
<center><br><br>
	<table width=660 class=pts border=0>
		<tr><td width=300 class=ptx valign=top rowspan=2><u>Arrival Notice / Freight Bill</u><td width=100>�⍇���ԍ��F
			<td width=250 class=ptx align=center><%=replace(JobCode, "-", " - ")%><%if SubCode <> 0 then response.write " - " & SubCode%>
		<tr><td nowrap>House B/L ��&nbsp;<td nowrap class=pth><%=HBL%>
		<tr><td valign=top>Messrs.<br><font class=ptm><%=GetCtmName(JobClient)%></font>
			<td nowrap><%if JobShipment = 1 then%>Master B/L<%else%>�����m�F<%end if%> ��&nbsp;<td nowrap class=pth><%=MBL%>
	</table>
	<table width=660 class=pts border=0 height=80>
		<tr><td width=280 class=ptm valign=bottom><%if JobShipper <> "" then%>Shipper<br><%=JobShipper%><%end if%>
			<td width=20>
			<td width=360><font class=ptl>COMPANY  CO., LTD.</font><br>
							<font class=ptl>�T���v���������</font><br>
											��123-4567 �����s�����搼����˃r������<br>
							<font class=ptj>TEL: 01-1111-1111�@FAX: 02-2222-2222</font></b>
	</table>
	<hr width=660 size=1 color=black>
	<table width=660 border=0 class=pts>
		<tr><td width=50>Vessel<td width=320 class=ptm><%=Vessel%>
			<td width=280 rowspan=2><%if Telex then%><font style="font-size:20pt;LINE-HEIGHT:1.1em"><u><i>���n�����</font></i></u><%end if%>
		<tr><td>Voyage<td class=ptm><%=Voy%>
		<tr><td>From<td nowrap><font class=ptm><%=POL%></font>�@�@To�@<font class=ptm><%=POD%></font>
				<%if POD2 <> "" and POD2 <> POD then%>�@���@<font class=ptm><%=POD2%></font><%end if%>
			<td class=ptm rowspan=2><%if PreInput = 0 then%><%=replace(JobMemo, vbcrlf, "<br>")%>
				<%else%><font style="font-size:24pt;LINE-HEIGHT:1.2em">�֎~</font><%end if%>
<%if JobType = gsImport then%>
		<tr><td>ETA<td class=ptm><%=ETA%>
<%else%>
		<tr><td>ETD<td class=ptm><%=ETD%>
<%end if%>
	</table>
	<hr width=660 size=1 color=black>
	<table width=660 class=pts border=0>
		<colgroup span=2 align=left>
		<colgroup span=2 align=right>
		<tr valign=top height=24>
			<td width=200>Nos Packages
			<td width=200>Description
			<td width=100>Gross Weight
			<td width=100>Measure
		<tr height=40 valign=top>
			<td class=ptn>�@�@<%=FitZero(formatnumber(Quantity,3,true))%><br><font class=pts><%=Package%></font>
			<td class=ptm><%=Commodity%>
			<td class=ptn><%=formatnumber(GW, 2, true)%>&nbsp;<br><font class=pts>KGS</font>
			<td class=ptn><%=formatnumber(CBM, 3, true)%>&nbsp;<br><font class=pts>M<sup>3</sup></font>
		<tr height=160 valign=top>
			<td class=ptm><br><%if JobShipment = 1 and Container <> "" then response.write Container & "<br>"%>
							<%=Marks%><br><br>
			<td class=ptj colspan=3 align=right>
				<table class=ptj width=320><tr><td nowrap><br>
				<%if DoConfirm then %>D/O�؂�ւ��̍ۂɁA���m�F�肢�܂��<%end if%><br><br>
				<%if NeedMark then%><b>�d�����̂��߁A�}�[�N���邢�̓p�b�L���O���X�g��<br>
									�t�@�b�N�X���Ă��������@�@FAX�F04-4444-4444</b><br><br><%end if%>
				<%if FarAway then %>�������܂����AB/L�ƃ`���[�W�͓��Ђ̕���<br>
									��肢���܂��C���A���U���݂����ꍇ�A��̏���<br>
									Fax���Ă�������<%end if%>
				</table>
	</table>
	<table width=660 border=0 class=pts>
		<tr><td width=320>D/O���s�ꏊ
			<td width=20>
			<td width=320>������
		<tr height=60 valign=top>
			<td width=320 class=ptj wrap><%=DoRelease%><br><%=DoRelease2%>
			<td width=20>
			<td width=320 class=ptj wrap><%=WareHouse%><br><%=WareHouse2%>
	</table>
	<hr width=660 size=1 color=black>
	<table border=0><tr><td valign=top height=200>
	  <table width=330 class=ptr>
		<colgroup align=left>
		<colgroup span=2 align=right class=ptm>
		<tr><td width=180 align=center>EX RATE
			<td width=60 class=ptr>@\<%=ExchangeRate%>
			<td width=90><br>
<%
	cnt = 0
	sum = 0
	weight = 0
	with Recset
		StrSql = "SELECT E.*, COST_REF, COST_ENAME FROM TBL_SEA_EXPENSE AS E INNER JOIN MST_COST AS M"
		StrSql = StrSql & " ON E.ExpenseCost = M.COST_ID WHERE E.Deleted = 0 AND ExpenseAttr <> 0"
		StrSql = StrSql & " AND JobCode = '" & JobCode & "' AND SubCode = " & SubCode
		StrSql = StrSql & " AND ExpenseType = " & gsCharge & " ORDER BY COST_REF, SeqNo"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		do while not .eof
%>
		<tr><td><%=ShowExpenseName(.fields("ExpenseCost"), .fields("ExpenseMemo"), .fields("COST_ENAME"))%>
			<td nowrap><%if GetLong(.fields("ExpenseCost")) = gsOcean then%>
				<%=GetCurShort(.fields("ExpenseCurrency"))%><font class=ptk><%=formatnumber(GetDouble(.fields("ExpenseAmount")),2,true)%></font>
				<%end if%>
			<td nowrap>\<font class=ptk><%=formatnumber(GetLong(.fields("ExpenseTotal")),0,true)%></font>
<%
			cnt = cnt + 1
			sum = sum + GetLong(.fields("ExpenseTotal"))
			if GetLong(.fields("ExpenseCost")) = gsWeight then weight = 1
			.movenext
		loop
		.Close
	end with
%>
	  </table>
  <td width=330 align=center valign=bottom class=pts>
  	<br><u><i><%=BANK_REMARKS%><i></u><br><br>
  	<table width=280 class=pts style="FONT-WEIGHT:bold">
  		<tr height=40><td colspan=2 align=center>���U���݂̏ꍇ�͂�����ɂ��肢���܂��B
  		<tr height=26><td class=pts>��s��<td class=ptm><%=BANK_NAME%>
  		<tr height=26><td class=pts>�x�X��<td class=ptm><%=BANK_BRANCH%>
  		<tr height=26><td class=pts nowrap>�����ԍ�<td class=ptm><%=BANK_TYPE%> <font class=ptn><%=BANK_ACCOUNT%></font>
  		<tr height=26><td class=pts>������<td class=pts nowrap><%=BANK_HOLDER%>
	  </table>
  <tr><td width=330>
	<hr size=1 color=black width=96%>
	<table width=330 border=0 class=ptm>
		<tr><td>&nbsp;���v<td align=right>\<font class=ptn><%=formatnumber(sum,0,true)%>&nbsp;</font>
	</table>
	<td align=center class=pts>
		<b><u>�������܂����A�U���萔���͌�Е��S���肢���܂��B</u></b>
  </table>
</center>
<%if GetLong(request("print")) = 1 then%>
	<script languange=vbscript>
		window.print()
	</script>
<%end if%>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
end if
%>
