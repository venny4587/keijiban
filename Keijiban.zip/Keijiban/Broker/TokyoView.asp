<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
dim myMode
dim myPageSize
dim lngPageNumber
dim DepartOperator
	
	myPageSize = 20
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Process = 1
		mySort = 1
		DateFrom = formatDate(dateadd("d", -20, date))
	else
		JobCode = GetPost(request("JobCode"))
		ClientRef = GetPost(request("ClientRef"))
		ReferNo = GetPost(request("ReferNo"))
		BillNo = GetPost(request("BillNo"))
		Port = GetPost(request("Port"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		QtyFrom = GetPost(request("QtyFrom"))
		QtyTo = GetPost(request("QtyTo"))
		AmountFrom = GetPost(request("AmountFrom"))
		AmountTo = GetPost(request("AmountTo"))
		Vessel = GetPost(request("Vessel"))
		Container = GetPost(request("Container"))
		WareHouse = GetPost(request("WareHouse"))
		Marks = GetPost(request("Marks"))
		Process = GetLong(request("Process"))
		
		if QtyFrom <> "" then QtyFrom = GetDouble(QtyFrom)
		if QtyTo <> "" then QtyTo = GetDouble(QtyTo)
		if AmountFrom <> "" then AmountFrom = GetLong(AmountFrom)
		if AmountTo <> "" then AmountTo = GetLong(AmountTo)
	end if

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
%>
<HTML>
<HEAD>
	<TITLE>�C��Ɩ��Ɖ�</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<SCRIPT language=Javascript src="css/calendar_JP.js"></SCRIPT>
	<script language=vbscript src="css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function ShowDetail(cd, seq)
		dim win
			set win = window.open("ConsoliAN.asp?mode=9&JobCode=" & cd & "&SubCode=" & seq, "ArrivalNotice", "resizable=1,scrollbars=1,width=800,height=600")
			win.focus()
		end function	
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub AmountFrom_OnBlur()
			if frmInput.AmountFrom.value = "" then exit sub
			frmInput.AmountFrom.value = GetDouble(frmInput.AmountFrom.value)
		end sub
		sub AmountTo_OnBlur()
			if frmInput.AmountTo.value = "" then exit sub
			frmInput.AmountTo.value = GetDouble(frmInput.AmountTo.value)
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.JobCode)" onkeydown="DoShortCut()" OnContextmenu=window.event.returnValue=false>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="TokyoView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<INPUT TYPE="HIDDEN" NAME="type" VALUE='<%=myType%>'>
		<table class=pt9>
			<TR><TD nowrap>
				���`��<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				�D��<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=16 onkeydown="ResetEnter()">
				�`<input class=si name="Port" value="<%=Port%>" maxlength=16 size=16 onkeydown="ResetEnter()">
				B/L�׎�<input class=si name="ClientRef" value="<%=ClientRef%>" maxlength=10 size=16 onkeydown="ResetEnter()">
				B/L ��<input class=si name="BillNo" value="<%=BillNo%>" maxlength=20 size=16 onkeydown="ResetEnter()">
			<TR><TD nowrap>
				���Ň�&nbsp;<input class=sz name="Container" value="<%=Container%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				ϰ�&nbsp;<input class=sz name="Marks" value="<%=Marks%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				�������z<input class=sn name="AmountFrom" value="<%=AmountFrom%>" maxlength=16 size=10 onkeydown="ResetEnter()">
					�`<input class=sn name="AmountTo" value="<%=AmountTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				�����q��&nbsp;<input class=sz name="WareHouse" value="<%=WareHouse%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				Job ��<input class=si name="JobCode" value="<%=JobCode%>" maxlength=10 size=10 onkeydown="ResetEnter()">
				<INPUT style="width:60px;height:25px;" TYPE=SUBMIT VALUE="����">
				<input type=checkbox name="Process" value=1 <%if Process then response.write "checked"%>>������̂�
		</table>
		
	<!----------��������--------->
<%
	if myMode > 0 then
		strSel = ""
		if JobCode <> "" then strSel = strSel & " AND JobCode+'-'+CAST(SubCode AS VARCHAR) LIKE '%" & FitSel(JobCode) & "%'" 
		if ClientRef <> "" then	strSel = strSel & " AND CTM_ENAME LIKE '%" & FitSel(ClientRef) & "%'"
		if Vessel <> "" then strSel = strSel & " AND Vessel+' '+Voy LIKE '%" & FitSel(Vessel) & "%'"	
		if BillNo <> "" then strSel = strSel & " AND MBL+' '+HBL LIKE '%" & FitSel(BillNo) & "%'"	
		if Port <> "" then strSel = strSel & " AND POL+' '+POD LIKE '%" & FitSel(Port) & "%'"
		if DateFrom <> "" then strSel = strSel & " AND ETA >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSel = strSel & " AND ETA <= '" & Date2Str(DateTo) & "'"
		if AmountFrom <> "" then strSel = strSel & " AND SalesTotal >= " & AmountFrom
		if AmountTo <> "" then strSel = strSel & " AND SalesTotal <= " & AmountTo
		if Container <> "" then strSel = strSel & " AND Container LIKE '%" & FitSel(Container) & "%'"
		if Marks <> "" then strSel = strSel & " AND Marks LIKE '%" & FitSel(Marks) & "%'"
		if WareHouse <> "" then strSel = strSel & " AND WH LIKE '%" & FitSel(WareHouse) & "%'"
		if Process = 1 then strSel = strSel & " AND DeliveryDate = '' "
		
		strSQL = "SELECT * FROM (SELECT JobCode, SubCode, CTM_ENAME, JobBroker, Vessel, Voy, POL, POD, HBL, MBL, ETA, Marks, Container"
		strSQL = strSQL & ", Quantity, GW, CBM, WareHouse+' '+WareHouse2 AS WH, PreInput, PrintCnt, SalesTotal, DeliveryDate"
		strSQL = strSQL & " FROM TBL_SEA_JOB AS J INNER JOIN (SELECT CTM_CD, CTM_ENAME FROM CUSTOMER) AS C ON J.JobClient = C.CTM_CD "
		strSQL = strSQL & " LEFT JOIN(SELECT JobCode AS JOB, SubCode AS Eda, SUM(ExpenseAttr * ExpenseTotal) AS SalesTotal"
		strSQL = strSQL & " FROM TBL_SEA_EXPENSE WHERE Deleted = 0 AND ExpenseType = " & gsCharge & " GROUP BY JobCode, SubCode) AS E"
		strSQL = strSQL & " ON J.JobCode = E.JOB AND J.SubCode = E.EDA WHERE Deleted = 0 AND JobType = 'I' AND JobBroker = 'DCP1011'"
		strSQL = strSQL & " AND SubCode <> 0 AND POD = 'TOKYO'" 
		select case Session("BrokerCode")
		case "DCP1019"
			strSQL = strSQL & " AND ETA >='200701001'"
			strSQL = strSQL & " AND WareHouse LIKE '���h���������a��%'"
		case else
			strSQL = strSQL & " AND ETA >='99'"
		end select
		strSQL = strSQL & ") AS TMP"
		if strSel <> "" then strSQL = strSQL & " WHERE " & mid(strSel, 5)
		select case mySort
		case 1:		strSQL = strSQL & " ORDER BY JobCode, SubCode"
		case 2:		strSQL = strSQL & " ORDER BY CTM_ENAME"
		case 3:		strSQL = strSQL & " ORDER BY VesselVoy"
		case 4:		strSQL = strSQL & " ORDER BY POL"
		case 5:		strSQL = strSQL & " ORDER BY POD"
		case 6:		strSQL = strSQL & " ORDER BY ETA"
		case 7:		strSQL = strSQL & " ORDER BY MBL"
		case 8:		strSQL = strSQL & " ORDER BY HBL"
		case 9:		strSQL = strSQL & " ORDER BY SalesTotal DESC"
		end select
' response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">�O�߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">���߰��</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n>
			<colgroup span=7 align=left>
			<colgroup align=center>
			<colgroup span=2 align=left>
			<colgroup align=right>
			<colgroup align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">Job ��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">B/L�׎�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�D��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">�֖�
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">�o���`
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">�ړI�`
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">���`��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">MB/L ��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">HB/L ��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">����
<%
				JobCodes = ""
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						if GetLong(.Fields("PreInput")) = 0 then
							if GetString(.Fields("DeliveryDate")) = "" then
								mycolor = "black"
							else
								mycolor = "green"
							end if
						else
								mycolor = "gray"
						end if
						JobCodes = JobCodes & "," & ShowSeaJobNo(.Fields("JobCode"), .Fields("SubCode"))
						ClientName = GetString(.Fields("CTM_ENAME"))
						VesselName = GetString(.Fields("Vessel"))
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
						 onclick="ShowDetail('<%=.Fields("JobCode")%>', '<%=.Fields("SubCode")%>');">
						<TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=ShowSeaJobNo(.Fields("JobCode"), .Fields("SubCode"))%><BR>
						<TD nowrap class=line <%=ShowTitle(ClientName, 20)%>><%=stringCut(ClientName, 20)%><BR>
						<TD nowrap class=line <%=ShowTitle(VesselName, 20)%>><%=stringCut(VesselName, 20)%><BR>
						<TD nowrap class=line><%=GetString(.Fields("VOY"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("POL"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("POD"))%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("ETA"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("MBL"))%><BR>
						<TD nowrap class=line><%=GetString(.Fields("HBL"))%><BR>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("SalesTotal")), 0, true)%>
					</TR>
<%
						.MoveNext
					End If
				Loop
				if lngCount > 0 then
%>
					<TR height=50 valign=bottom>
						<TD colspan=4 align=left>
							<input type=button class=pt12b style="width:150;height:36" name=btnAN  value="Arrive Notice" onclick="DoPrint(1)">
<%
				end if
%>
	</TABLE>
<%
			else
				Response.Write "<br><div align=center class=pt9r>�Y������f�[�^�͌�����܂���ł����B</div>"	
			end if
			.Close
		end with
	end if
%>
	</FORM>
<script language=vbscript>
	sub DoPrint(mode)
		set win = window.open("BatchPrint.asp?type=9&JobCodes=<%=mid(JobCodes, 2)%>&mode=" & mode, "BatchPrint", "resizable=1,scrollbars=1,width=800,height=600")
		win.focus()
	end sub
</script>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>
