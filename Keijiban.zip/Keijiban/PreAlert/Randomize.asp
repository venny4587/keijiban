<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")	
	
	with Recset
		StrSql = "SELECT * FROM _PREALERTUSER"
		.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
		do while not .eof
			.Fields("Password") = GetPassword(6)
			.update
			.movenext
		loop
		.close
	end with
	set Recset = nothing
	CloseDB Conn

	'------------------------------------------------
	'�p�X���[�h�̍쐬�Ǝ擾
	'------------------------------------------------
	Function GetPassword(intLength)
		Dim i
		Dim r
		Dim s
		
		Randomize
		
'		For i = 1 To intLength
'			r = Int(Rnd * 60)
'			If r <= 9 Then
'				GetPassword = GetPassword & Chr(Asc("0") + r)
'			ElseIf r <= 23 Then
'				GetPassword = GetPassword & Chr(Asc("a") + r - 10)
'			ElseIf r <= 34 Then
'				GetPassword = GetPassword & Chr(Asc("p") + r - 24)
'			ElseIf r <= 48 Then
'				GetPassword = GetPassword & Chr(Asc("A") + r - 35)
'			Else
'				GetPassword = GetPassword & Chr(Asc("P") + r - 49)
'			End If
'		Next
		Do
			GetPassword = ""
			For i = 1 To intLength
				Do
					r = Int(Rnd * 62)
					If r <= 9 Then
						s = Chr(Asc("0") + r)
					ElseIf r <= 35 Then
						s = Chr(Asc("a") + r - 10)
					Else
						s = Chr(Asc("A") + r - 36)
					End If
					Select Case s
					Case "o", "O", "l", "I", "i", "j", "J", "u", "v"
					Case Else
						GetPassword = GetPassword & s
						Exit Do
					End Select
				Loop
			Next
			If Not IsNumeric(GetPassword) Then Exit Do
		Loop
		
	End Function
%>