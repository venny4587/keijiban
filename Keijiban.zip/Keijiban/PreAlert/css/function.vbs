
gsDateSign = "-"

function checkText(myName, myTitle, myMode)				
on error resume next
	checkText = true	
	for each obj in frmInput.elements
		if (obj.type = "text" or obj.type = "textarea") and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox "Please input the " & myTitle & ".",48,"notice" 	
					checkText = false
					exit for	
				end if 
			else
				if obj.type = "textarea" then
					chk1=0
				else
					chk1 = instr(obj.value, chr(34))
				end if
				chk2 = instr(obj.value, "*")
				chk3 = instr(obj.value, "%")
				chk4 = instr(obj.value, "@")
				chk5 = instr(obj.value, ";")
				if chk1 + chk2 + chk3 + chk4 + chk5 > 0 then
					obj.focus
					msgbox "The below Charactor can not be inputed into " & myTitle & "." & vbcrlf & " " & chr(34) & "*%@;",48,"notice" 
					checkText = false
					exit for	
				end if
			end if
		end if
	next 	
end function

function checkNum(myName, myTitle, myMode)				
on error resume next
	checkNum = true	
	for each obj in frmInput.elements
		if obj.type = "text" and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox "Please input the " & myTitle & ".",48,"notice" 	
					checkNum = false
					exit for
				end if
			else
				if not isnumeric(obj.value) then
					obj.focus
					msgbox "Only number could be inputed into " & myTitle & ".",48,"notice" 
					checkNum = false
					exit for
				else
					if GetLong(obj.value) < 0 then
						obj.focus
						msgbox "Only number could be inputed into " & myTitle & ".",48,"notice" 
						checkNum = false
						exit for
					end if
				end if					
			end if
			obj.value = GetLong(obj.value)
		end if
	next 	
end function

function checkDouble(myName, myTitle, myMode)				
on error resume next
	checkDouble = true	
	for each obj in frmInput.elements
		if obj.type = "text" and obj.name = myName then
			if trim(obj.value) = "" then
				if myMode then
					obj.focus
					msgbox "Please input the " & myTitle & ".",48,"notice" 	
					checkDouble = false
					exit for
				end if
			else
				if not isnumeric(obj.value) then
					obj.focus
					msgbox "Only number could be inputed into " & myTitle & ".",48,"notice" 
					checkDouble = false
					exit for
				else
					if GetDouble(obj.value) < 0 then
						obj.focus
						msgbox "Only number could be inputed into " & myTitle & ".",48,"notice" 
						checkDouble = false
						exit for
					end if
				end if
			end if
			obj.value = GetDouble(obj.value)
		end if
	next 	
end function

function checkLen(myName, myTitle, myLen)				
on error resume next
	checkLen = true	
	for each obj in frmInput.elements
		if (obj.type = "text" or obj.type = "textarea") and obj.name = myName then
			if len(trim(obj.value)) > myLen then
				msgbox "The length of " & myTitle & " is limited to " & myLen & " charactors.",48,"notice" 	
				checkLen = false
				exit for
			end if
		end if
	next 	
end function

function GetLong(myData)
	GetLong = 0
	if isnumeric(myData) then
		GetLong = clng(myData)
	end if
end function

function GetDouble(myData)
	GetDouble = 0
	if isnumeric(myData) then
		GetDouble = cdbl(myData)
	end if
end function

function ResetInput()
on error resume next
	ResetInput = true
	for each obj in frmInput.elements
		if obj.type = "text" then
			obj.value = trim(obj.value)
		end if
	next 	
end function


function formatDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDate = ""
		exit function
	end if		
	formatDate = year(myDate) & "-" & right("00" & month(myDate),2) & "-" & right("00" & day(myDate),2)
end function

function setDate(myData)
dim tmp
	setDate = ""
	tmp = trim(myData & "")
	if len(tmp) < 8 then exit function
	if len(tmp) = 8 then
		tmp = left(tmp,4) & gsDateSign & mid(tmp,5,2) &  gsDateSign &  mid(tmp,7,2)
		if isdate(tmp) then
			setDate = tmp
		end if
	elseif len(tmp) = 10 then
		tmp = left(tmp,4) & gsDateSign & mid(tmp,6,2) &  gsDateSign &  mid(tmp,9,2)
		if isdate(tmp) then
			setDate = tmp
		end if
	end if
	if setDate <> "" then
		setDate = year(tmp) & gsDateSign & right("00" & month(tmp),2) & gsDateSign & right("00" & day(tmp),2)
	end if
end function

function setDateTime(myData)
dim tmp
dim pos
dim myDate
dim myTime
	setDateTime = ""
	tmp = trim(myData & "")
	if len(tmp) = 8 then tmp = tmp & "0000"
	if len(tmp) < 12 then exit function
	pos = instrrev(tmp," ")
 	if pos = 0 then
		myDate = setDate(left(tmp,8))
		myTime = setTime(mid(tmp,9))
	else
		myDate = setDate(left(tmp,pos-1))
		myTime = setTime(mid(tmp,pos+1))
	end if
	if myDate <> "" AND myTime <> "" then
		setDateTime = myDate & " " & myTime
	end if
end function

function setTime(myData)
dim tmp
dim pos
dim hh
dim mm
	setTime = ""
	tmp = trim(myData & "")
	if len(tmp) < 4 then exit function
	pos = instr(tmp,":")
 	if pos = 0 then
		hh = left(tmp,2)
		mm = mid(tmp,3)
	else
		hh = left(tmp,pos-1)
		mm = mid(tmp,pos+1)
	end if
	if isnumeric(hh) AND isnumeric(mm) then
		hh = cint(hh)
		mm = cint(mm)
		if hh >= 24 or mm >= 60 then exit function
		setTime = right("00" & hh,2) & ":" & right("00" & mm,2)
	end if
end function