var bgColor_Title = "#E0E0E0"
var bColorLight = "#F0F0F0"
var bColorDark = "#808080"

var btnColor = "#000000"
var btnColorBg = "#F0F0F0"
var btnColorOn = "#0000FF"
var btnColorExit = "#FF0000"
var btnColorBgOn = "#00FF00"
var btnColorBgExit = "#FF0000"

function DoClickCheck(nm) {	
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='checkbox' && e.name==nm) {
      if (e.checked) {
        e.checked = false;	
      } else {
        e.checked = true;	
      }
    }
  }
}

function DoClickRadio(nm,va) {	
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='radio' && e.name==nm && e.value==va) {
      e.checked = true;	
    }
  }
}
function GetElementVal(myName) {	
	var frm = document.frmInput;
	for (var i=0;i<frm.elements.length;i++){
		var e = frm.elements[i];
		//radio
		if (e.type=='radio' && e.name==myName) {
			if (e.checked == true) {
				return e.value;
			}
		}
		//textbox
		if (e.type=='text' && e.name==myName) {
			return e.value;
		}
		//textbox
		if (e.type=='hidden' && e.name==myName) {
			return e.value;
		}
	}
	return null;
}
function ClearAll(){
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='text')
        e.value = "";
    if (e.type=='checkbox')
        e.checked = false;
    if (e.type=='radio')
	if (e.value==0)
          e.checked = true;   
  }
}

function CheckAll(val){
  var frm = document.frmInput;
  for (var i=0;i<frm.elements.length;i++){
    var e = frm.elements[i];
    if (e.type=='checkbox')
        e.checked = val;
  }
}

function overbutton(obj) {
	setcolor(obj);
	//setbgcolor(obj);
}

function overbuttonexit(obj) {
	setcolorexit(obj);
	//setbgcolorexit(obj);
}

function outbutton(obj) {
	resetcolor(obj);
	//resetbgcolor(obj);
}

function setbgcolor(obj) {
	obj.style.background = btnColorBgOn;
}

function setbgcolorexit(obj) {
	obj.style.background = btnColorBgExit;
}

function resetbgcolor(obj) {
	obj.style.background = btnColorBg;
}

function setcolor(obj) {
	obj.style.color = btnColorOn;
}

function setcolorexit(obj) {
	obj.style.color = btnColorExit;
}

function resetcolor(obj) {
	obj.style.color = btnColor;
}

function ResetEnter() {
	if (event.keyCode == 13) {
		window.event.keyCode = 9;
	}
}
