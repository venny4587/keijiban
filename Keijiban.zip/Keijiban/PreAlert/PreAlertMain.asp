<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
if Session("UserLevel") = 0 then
	DefaultPage = "PreAlertView.asp"
elseif Session("UserLevel") = 10 then
	DefaultPage = "EditPreAlert.asp"
end if
%>
<html>
<head>
	<TITLE> PRE-ALERT</TITLE>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		A.bar:link{COLOR: white;TEXT-DECORATION: none}
		A.bar:active{COLOR: white;TEXT-DECORATION: none}
		A.bar:visited{COLOR: white;TEXT-DECORATION: none}
		A.bar:hover{COLOR: white;TEXT-DECORATION: none}
		A.menu:link{COLOR: #404040;TEXT-DECORATION: none}
		A.menu:active{COLOR: #404040;TEXT-DECORATION: none}
		A.menu:visited{COLOR: #404040;TEXT-DECORATION: none}
		A.menu:hover{COLOR: #404040;TEXT-DECORATION: none}
		.pt7 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 8pt; color: #000000 }
		.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 9pt; color: #000000 }
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #404040; font-weight: bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt; color: #404040 }	
	</style>
	<script language=javascript>
		top.status = "Current User : <%=session("UserName")%>";
		
		function DoAction(mode) {
			if (mode==0) {
				window.location.href = "<%=CurrentUrl%>Logoff.asp?TimeOut=0";
				return;
			} 
			if (mode==10) {
				window.open("<%=CurrentUrl%>PreAlertView.asp", "frameView");
				return;
			} 
			if (mode==20) {
				window.open("<%=CurrentUrl%>PreAlertList.asp", "frameView");
				return;
			} 
			if (mode==30) {
				window.open("<%=CurrentUrl%>CalendarView.asp", "frameView");
				return;
			} 
			if (mode==40) {
				window.open("<%=CurrentUrl%>EditPreAlert.asp", "frameView");
				return;
			} 
			if (mode==50) {
				window.open("<%=CurrentUrl%>UploadXml.asp", "frameView");
				return;
			} 
			if (mode==60) {
				window.open("<%=CurrentUrl%>GuestBook.asp", "frameView");
				return;
			} 
			if (mode==90) {
				window.open("<%=CurrentUrl%>Password.asp", "frameView");
				return;
			} 
		}
	</script>
</head>
<body topmargin=0 background=img/back.jpg OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
	<table cellpadding=0 cellspacing=0 border=0 width=980>
		<tr><td width=100% valign=top>
				<table cellpadding=0 cellspacing=0 border=0 class=pt12>
				  <tr height=50>
				  	<td colspan=3 align=center style=" FONT-FAMILY: Century Gothic; color:black; font-weight:bold">
				  		<font style="FONT-SIZE: 24pt; LINE-HEIGHT: 26pt;" color=white><i>Sample</i></font> Co., Ltd</td>
				  	<td align=right style="color:white;" valign=bottom class=pt7>
				  		<font class=pt7 style="CURSOR:Hand; color=white" onclick="DoAction(0)">LOG OUT</font> | <a class=bar href="mailto:csv@company.com">MAIL US</a></td>
				  </tr>
				  <tr>
					<td width=26><img src=img/left_top.jpg></td>
					<td background=img/top.jpg width=200>&nbsp;</td>
					<td><img src=img/top_mid.jpg></td>
					<td background=img/head.jpg width=600>&nbsp;</td>
					<td width=30><img src=img/top_right.jpg></td></tr>
				  <tr>
					<td background=img/left_mid.jpg></td>
					<td height=328 background=img/back_menu.jpg align=center valign=top>
<!--Menu-->
						<table border=0 class=pt9t>
							<tr><td colspan=2 align=center>
								<table width=152 class=pt12>
									<tr height=8><td background=img/title.jpg></td></tr>
									<tr><td><b>Main Menu</b></td></tr>
								</table>
							<tr><td colspan=2>&nbsp;</td></tr>
<%	if Session("UserLevel") = 0 then %>
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(10)">New Pre-Alert</font></td></tr>
							<tr><td colspan=2><hr size=1></td></tr>
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(30)">View In Calendar</font></td></tr>
							<tr><td colspan=2><hr size=1></td></tr>
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(20)">Search Pre-Alert</font></td></tr>
							<tr><td colspan=2><hr size=1></td></tr>
<%	end if%>
<%	if Session("UserLevel") = 10 then %>
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(40)">Add New Pre-Alert</font></td></tr>
							<tr><td colspan=2><hr size=1></td></tr>
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(20)">Modify A Pre-Alert</font></td></tr>
							<tr><td colspan=2><hr size=1></td></tr>
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(50)">Upload EDI Data</font></td></tr>	
							<tr><td colspan=2><hr size=1></td></tr>
<%	end if%>			
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(90)">Change Password</font></td></tr>	
							<tr><td colspan=2><hr size=1></td></tr>		
							<tr><td>></td><td><font style="CURSOR:Hand;" onclick="DoAction(60)">Write Guest Book</font></td></tr>	
							<tr><td colspan=2><hr size=1></td></tr>						
						</table>
					</td>
					<td height=360 width=90 rowspan=2><img src=img/link.jpg></td>
					<td rowspan=3 bgcolor=white align=center valign=top>
						<IFRAME name=frameView FRAMEBORDER=0 scrolling=auto SRC="<%=DefaultPage%>" height=100% width=100%></IFRAME>
					</td>
					<td rowspan=3 width=30 background=img/border_r.jpg></td></tr>
				  <tr height=29>
					<td><img src=img/left_foot.jpg></td>
					<td background=img/bottom.jpg>&nbsp;</td>
					<td background=img/border_r.jpg></td></tr>
				  <tr>
					<td colspan=2 class=pt7 align=right valign=top>
						<br>COPYRIGHT&copy; 2006 ALL RIGHTS RESERVED</td>
					<td height=110 background=img/border_l.jpg>&nbsp;</td>
					<td background=img/border_r.jpg></td></tr>
				  <tr>
					<td colspan=2>&nbsp;</td>
					<td><img src=img/foot_mid.jpg></td>
					<td background=img/foot.jpg>&nbsp;</td>
					<td><img src=img/foot_right.jpg></td></tr>
				</table>			
			</td>
		</tr>
	</table>
</body>
</html>