<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	id = GetLong(request("id"))
	del = GetLong(request("del"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	
	if del = 0 then
		
		msg = ""
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		with Recset
			StrSql = "SELECT * FROM _PreAlertUser WHERE LogonID = 'CLS" & GetLong(Request("Customer")) & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if .eof then msg = "The Consignee's Refer Code is incorrect."
			.close
			
			if msg = "" then
				StrSql = "SELECT * FROM _PREALERT WHERE PID <> " & id
				StrSql = StrSql & " AND Partner = " & Session("UserID") & " AND ReferNo = '" & GetPost(Request("ReferNo")) & "'"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if not .eof then msg = "The Job No. is already exist."
				.close
			end if
			
			if msg = "" then
				myTime = now()
		
				StrSql = "SELECT * FROM _PREALERT WHERE PID = " & id
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
				if .eof then
					.addnew
					.fields("Partner") = Session("UserID")
					.fields("CreateID") = Session("UserID")
					.fields("CreateDate") = myTime
				end if
				.fields("Customer") = GetLong(Request("Customer"))
				.fields("ReferNo") = GetPost(Request("ReferNo"))
				.fields("Shipper") = GetPost(Request("Shipper"))
				.fields("Consignee") = GetPost(Request("Consignee"))
				.fields("Notify") = GetPost(Request("Notify"))
				.fields("Vessel") = GetPost(Request("Vessel"))
				.fields("Voy") = GetPost(Request("Voy"))
				.fields("Carrier") = GetPost(Request("Carrier"))
				.fields("POL") = GetPost(Request("POL"))
				.fields("POD") = GetPost(Request("POD"))
				.fields("ETD") = GetPost(Request("ETD"))
				.fields("ETA") = GetPost(Request("ETA"))
				.fields("HBL") = GetPost(Request("HBL"))
				.fields("Pattern") = GetPost(Request("Pattern"))
				.fields("Commodity") = GetPost(Request("Commodity"))
				.fields("Quantity") = GetDouble(Request("Quantity"))
				.fields("Package") = GetPost(Request("Package"))
				.fields("GW") = GetDouble(Request("GW"))
				.fields("CBM") = GetDouble(Request("CBM"))
				.fields("PONO") = GetPost(Request("PONO"))
				.fields("TradeTerms") = GetPost(Request("TradeTerms"))
				.fields("SpecHandle") = GetPost(Request("SpecHandle"))
				.fields("Mark") = GetPost(Request("Mark"))
				if .fields("Mark") = "" then .fields("Mark") = "N/M"
				
				.fields("UpdateID") = Session("UserID")
				.fields("UpdateDate") = myTime
				.update
				.close
				
				if id = 0 then 
					StrSql = "SELECT MAX(PID) AS NEW_ID FROM _PREALERT"
					StrSql = StrSql & " WHERE CreateID = " & Session("UserID") & " AND Customer = " & GetLong(Request("Customer"))
					.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
					if not .eof then id = GetLong(.fields("NEW_ID"))
					.close
				end if
			end if
		end with
		set Recset = nothing
		
		if msg <> "" then 
			ShowMessage msg
		else
%>
	<html>
		<script language=javascript>
			alert("Pre-Alert data has been saved successfully!");
			window.location.href = "EditPreAlert.asp?id=<%=id%>";
		</script>
	</html>
<%
		end if
	else
		Conn.execute "DELETE FROM _PREALERT WHERE PID = " & id
%>
	<html>
		<script language=javascript>
			alert("Pre-Alert data has been deleted successfully!");
			window.location.href = "EditPreAlert.asp";
		</script>
	</html>
<%
	end if
	CloseDB Conn
%>