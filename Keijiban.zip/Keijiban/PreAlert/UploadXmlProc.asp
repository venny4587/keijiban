<!-- #include FILE="upload.inc" -->
<%
'on error resume next

Server.ScriptTimeOut=120

filepath = "/prealertup/xml"
strUpPath = server.MapPath(filepath)	
Set fsobj = Server.CreateObject("Scripting.FileSystemObject")
bp = fsobj.BuildPath(strUpPath, Session("UserLogonID"))
if Not fsobj.FolderExists(bp) then
	cf = fsobj.CreateFolder(bp)
end if

set upload = new clsUpload
set file = upload.file("filename")
if lcase(right(file.filename, 4)) <> ".xml" or file.FileSize = 0 then
	response.redirect "UploadXml.asp?mode=1"
else
	dt = now()
	filename = right(year(dt), 2) & right("00" & month(dt), 2) & right("00" & day(dt), 2) & _
			   right("00" & hour(dt), 2) & right("00" & minute(dt), 2) & right("00" & second(dt), 2) & ".xml"
	file.SaveAs server.MapPath(filepath & "/" & Session("UserLogonID") & "/" & filename)
	set file=nothing
	set upload=nothing
	
	if err.number <> 0 then
		response.redirect "UploadXml.asp?mode=2"
	else
		response.redirect "uploadXmlCheck.asp?f=" & filename
	End If
end if
%>