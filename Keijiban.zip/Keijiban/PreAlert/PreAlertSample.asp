<%
	filepath = "/prealert"
	pth = server.mappath(filepath)
	
	Set fso=Server.CreateObject("Scripting.FileSystemObject") 
	Set fl=fso.getfile(pth & "\prealert.xml") 
	flsize=fl.size
	flName=fl.name
	Set fl=Nothing
	Set fso=Nothing

	Set objStream = Server.CreateObject("ADODB.Stream") 
	objStream.Open 
	objStream.Type = 1 
	objStream.LoadFromFile pth & "\prealert.xml"

	Response.AddHeader "Content-Disposition", "attachment; filename=" & flName 
	Response.AddHeader "Content-Length", flsize 

	Response.Charset = "UTF-8" 
	Response.ContentType = "text/XML"  

	Response.BinaryWrite objStream.Read 
	Response.Flush 
	response.Clear() 
	
	objStream.Close 
	Set objStream = Nothing 

%>