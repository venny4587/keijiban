<!-- #include file="common.asp" -->
<!-- #include file="function.asp" -->
<%
	mode = clng("0" & request("mode"))
%>
<html>
<head>
	<TITLE>UPLOAD</TITLE>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #404040; font-weight: bold }
		.pt9b { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #0000FF; font-weight: bold }
		.pt9r { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #FF0000; font-weight: bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt; color: #404040 }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10px; BACKGROUND: #C0C0C0; BORDER-RIGHT: #C0C0C0 1px solid; BORDER-TOP: #C0C0C0 1px solid; BORDER-LEFT: #C0C0C0 1px solid; BORDER-BOTTOM: #C0C0C0 1px solid;}
	</style>
	<script language=vbscript>
		sub CheckFile()
			if trim(frmInput.filename.value) = "" then
				msgbox "Please select your data file to upload.", 64, "Confirm Message"
			elseif lcase(right(frmInput.filename.value, 4)) <> ".xml" then
				msgbox "The EDI data file should be a xml file.", 64, "Confirm Message"
			else
				frmInput.btnUpload.disabled = true
				frmInput.submit
			end if
		end sub
		
		sub ShowSample()
			window.location.href = "PreAlertSample.asp"
		end sub
	</script>
</head> 
<body OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
<form name="frmInput" Method="Post" Enctype="multipart/form-data" Action="UploadXmlProc.asp">
	<table width=100% cellspacing=0 cellpadding=0 border="0">

  		<tr><td align="center" valign=middle>
	  		<BR>
			<TABLE width=400 bgcolor=#F0F0F0 class=pt9t>
		  		<TR align=center height=60><TD colspan=4><font color=Tomato>E</font>DI Data Upload</TD></TR>
		  		<TR><TD colspan=4><hr width=96%></TD></TR>
		  		
		  		<TR height=30>
		  			<TD width=80 align=right>EDI Type:</TD>
		  			<TD width=20>&nbsp;</TD>
					<TD width=100>Pre-Alert xml file</TD>
					<TD width=100><img src=img/help.gif on style="cursor:hand" onclick="ShowSample()" alt="Click to get a sample."></TD>
				</TR>
				
		  		<TR height=30>
		  			<TD width=80 align=right>Data File:</TD>
		  			<TD width=20>&nbsp;</TD>
					<TD colspan=2><input class=so type="file" name="filename" size=40></TD>
				</TR>
		  		<TR><TD colspan=4><hr width=96%></TD></TR>
<%
	if mode > 0 then 
%>
		  		<TR><TD colspan=4 class=pt12 align=center><%
					select case mode 
					case 1  
						response.write "<font class=pt9r>Sorry, your EDI data is incorrect !" & ShowJobno() & "</font>"
					case 2
						response.write "<font class=pt9r>Error occurred, please try again !" & ShowJobno() & "</font>"
					case 3
						response.write "<font class=pt9r>Sorry, your refer code is incorrect !" & ShowJobno() & "</font>"
					case 8
						response.write "<font class=pt9b>" & ShowInfo() & "</font>"
					end select
					%></TD></TR>
		  		<TR><TD colspan=4><hr width=96%></TD></TR>
<%
	end if 
%>
		  		<TR align=center height=60>
		  			<TD colspan=4><input type="button" class=pt9t style="width:90px;height:30px;" name=btnUpload value="UPLOAD" onclick="CheckFile()"></TD>
				</TR>
			</TABLE>
	    </td></tr>
	</table>
</form>
</body>
</html> 

<%
function ShowJobno()
	buf = GetPost(request("jobno"))
	if buf = "" then exit function
	ShowJobno = " (Job No.: " & buf & ")"
end function

function ShowInfo()
	cnt = GetLong(request("cnt"))
	if cnt = 0 then exit function
	
	if cnt = 1 then
		ShowInfo = "1 record has been converted successfully !"
	else
		ShowInfo = cnt & " records have been converted successfully !"
	end if
end function
%>