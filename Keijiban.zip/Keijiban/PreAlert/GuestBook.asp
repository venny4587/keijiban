<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim ID

dim Title
dim Body

dim Require
dim Author
dim CreateDate

dim Reply
dim Replyer
dim ReplyDate

dim lngCount
dim lngPageNumber
dim myPageSize
dim strSubmit

	ID = GetLong(request("id"))
	lngPageNumber = GetLong(request("p"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSQL = "SELECT * FROM _GuestBook WHERE GID = " & ID
		.Open strSQL, Conn, adOpenForwardOnly, adLockReadOnly 
		if .eof then
			strSubmit = "Save"
			
			Author = ""
			CreateDate = ShowDateTimeShortEng(now()) 
			Require = 3
			Title = ""
			Body = ""
		else
			strSubmit = "Update"
			
			Author = GetString(.Fields("Author"))
			CreateDate = ShowDateTimeShortEng(.Fields("CreateDate")) 
			Require = GetLong(.Fields("Require"))			
			Title = GetString(.Fields("Title"))
			Body = GetString(.Fields("Body"))
			
			Reply = GetString(.Fields("Reply"))	
			Replyer = GetString(.Fields("Replyer"))
			ReplyDate = ShowDateTimeShortEng(.Fields("ReplyDate"))
		end if
		.Close		
	End With
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<TITLE>Guest Book</TITLE>	
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
	//-->
	</SCRIPT>
	<SCRIPT language="vbscript" src="css/function.vbs"></SCRIPT>
	<SCRIPT LANGUAGE="VBScript">
		Sub DoSubmit()
			if checkText("Title","Title",1) = false then exit sub
			if checkText("Author","Your Name",1) = false then exit sub
			if checkText("Body","Your Message",1) = false then exit sub
			if checkLen("Body","Your Message",500) = false then exit sub
			if msgbox("Are you sure to <%=strSubmit%> it now ?", 289, "Confirm Message") = 1 then
				frmInput.submit()
			end if
		End Sub
		
		Sub ConfirmDelete(lngID)
			If msgbox("Are you sure to delete it now ?", 289, "Confirm Message") = 1 Then
				window.location.href = "GuestBook0.asp?id=" & lngID
			End If
		End Sub
		
		Sub ShowList()
			window.location.href = "GuestBook2.asp?p=<%=lngPageNumber%>"
		End Sub
	</SCRIPT>
	<style>
		.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; }
		.pt9b { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; font-weight:bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 14px; LINE-HEIGHT: 16px; BORDER-RIGHT: #808080 1px solid; BORDER-TOP: #808080 1px solid; BORDER-LEFT: #808080 1px solid; BORDER-BOTTOM: #808080 1px solid;}
	</style>
</HEAD>

<body topmargin=0 leftmargin=0 OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>

	<TABLE width=100% CELLPADDING=0 CELLSPACING=0 class=pt9>
		<TR>
			<!----------Left--------->
			<TD width=90% ALIGN=center VALIGN=TOP>					
				<FORM METHOD="POST" ACTION="GuestBook1.asp" ID=frmInput NAME=frmInput>
					<INPUT TYPE="HIDDEN" NAME="id" VALUE='<%=ID%>'>
					<BR>
					  <table width="90%" BORDER=1 bordercolor="#0000FF" CELLPADDING=2 CELLSPACING=0 class=pt9b rules=none>

						<TR height=30 bgcolor="#FFFFFF">
							<TD align=center width=80>Title</TD>
							<TD><input class=so name="Title" value="<%=Title%>" maxlength=50 size=50 onkeydown="ResetEnter()"></TD></TR>
						<TR height=30 bgcolor="#FFFFFF">
							<TD align=center nowrap>Author</TD>
							<TD><input class=so name="Author" value="<%=Author%>" maxlength=20 size=20 onkeydown="ResetEnter()">
								&nbsp;on <%=CreateDate%> &nbsp;(GMT+09:00)</TD></TR>
						<TR bgcolor="#FFFFFF">
							<TD align=center valign=top>Body</TD>
							<TD><textarea class=so name="Body" rows=7 style="width:400"><%=Body%></textarea></td></tr>				
						<TR height=30 bgcolor="#FFFFFF">
							<TD colspan=2 align=center>Reply required within 
								<select name="Require"><%
								response.write "<option value=0>free"
								for i = 1 to 7
									if Require = i then
										response.write "<option value=" & i & " selected>" & i & "day"
									else
										response.write "<option value=" & i & ">" & i & "day"
									end if
									if i > 1 then response.write "s"
								next
								%></select></TD>
						</TR>
					</TABLE><BR>
<%	if Replyer = "" then %>
				  <table width="90%">
				  	<TR><TD width=50%>
						<INPUT style="width:80px;height:30px;" TYPE=BUTTON VALUE="History" OnClick="ShowList()">
				  	<TD width=50% align=right>
						<INPUT style="width:80px;height:30px;" TYPE=BUTTON VALUE="<%=strSubmit%>" OnClick="DoSubmit()">
				  </table>
<%	else %>
				  <table width="90%" BORDER=1 bordercolor="#000000" CELLPADDING=2 CELLSPACING=0 class=pt9b rules=none>

					<TR height=30 bgcolor="#FFFFFF">
						<TD align=center width=80>Replyer</TD>
						<TD><input class=so name="Replyer" value="<%=Replyer%>" maxlength=20 size=20 readonly>
								&nbsp;on <%=ReplyDate%> &nbsp;(GMT+09:00)</TD></TR>
					<TR height=30 bgcolor="#FFFFFF">
						<TD><TD>
							<textarea class=so name="Reply" rows=8 style="width:400" readonly><%=Reply%></textarea><br><br></td></tr>				
					</TR>
				</TABLE>
				  <table width="90%">
				  	<TR><TD align=right>
					<INPUT style="width:80px;height:30px;" TYPE=BUTTON VALUE="BACK" OnClick="window.history.go(-1)">
				  </table>
<%	end if %>
			</FORM>
		</TD>
	</TR></TABLE>

</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
		
%>

