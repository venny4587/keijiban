<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<!-- #include FILE="upload.inc" -->
<%
'on error resume next

Server.ScriptTimeOut=120

filepath = "/prealertup/doc"
strUpPath = server.MapPath(filepath)	
Set fsobj = Server.CreateObject("Scripting.FileSystemObject")
bp = fsobj.BuildPath(strUpPath, Session("UserLogonID"))
if Not fsobj.FolderExists(bp) then
	cf = fsobj.CreateFolder(bp)
end if

set upload = new clsUpload
id = GetLong(upload.Form("id"))
ttl = GetPost(upload.Form("filetitle"))
set file = upload.file("filename")
if file.FileSize = 0 then
	response.redirect "UploadDoc.asp?mode=1&id=" & id
else
	ext = lcase(mid(file.filename, instr(file.filename, ".")+1))
	select case ext
	case "doc", "xls", "pdf", "swf", "jpg", "jpeg", "gif", "tif", "tiff", "htm", "html"

		dt = now()
		filename = filepath & "/" & Session("UserLogonID") & "/" & right(year(dt), 2) & _
				   right("00" & month(dt), 2) & right("00" & day(dt), 2) & right("00" & hour(dt), 2) & _
				   right("00" & minute(dt), 2) & right("00" & second(dt), 2) & "." & ext
		file.SaveAs server.MapPath(filename)
		set file=nothing
		set upload=nothing
		
		if err.number <> 0 then
			response.redirect "UploadDoc.asp?mode=2&id=" & id
		else
			strSql = "INSERT INTO _PreAlertDoc (PID, FileTitle, FilePath)"
			strSql = strSql & " VALUES (" & id & ",'" & ttl & "','" & filename & "')"
		
			OpenSQL Conn, SqlServerName, DataBaseName
			Conn.Execute strSql
			CloseDB Conn
			response.redirect "UploadDoc.asp?mode=8&id=" & id
		End If
	case else
		response.redirect "UploadDoc.asp?mode=1&id=" & id
	end select 
end if
%>