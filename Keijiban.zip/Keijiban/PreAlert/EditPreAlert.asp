<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
id = GetLong(request("id"))
if id > 0 then
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM _PREALERT WHERE PID = " & id
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			ReferNo = GetString(.fields("ReferNo"))
			Customer = GetString(.fields("Customer"))
			Shipper = GetString(.fields("Shipper"))
			Consignee = GetString(.fields("Consignee"))
			Notify = GetString(.fields("Notify"))
			Vessel = GetString(.fields("Vessel"))
			Voy = GetString(.fields("Voy"))
			Carrier = GetString(.fields("Carrier"))
			POL = GetString(.fields("POL"))
			POD = GetString(.fields("POD"))
			ETD = GetString(.fields("ETD"))
			ETA = GetString(.fields("ETA"))
			HBL = GetString(.fields("HBL"))
			Commodity = GetString(.fields("Commodity"))
			Quantity = GetDouble(.fields("Quantity"))
			Package = GetString(.fields("Package"))
			GW = GetDouble(.fields("GW"))
			CBM = GetDouble(.fields("CBM"))
			PONO = GetString(.fields("PONO"))
			TradeTerms = GetString(.fields("TradeTerms"))
			Pattern = GetString(.fields("Pattern"))
			SpecHandle = GetString(.fields("SpecHandle"))
			Mark = GetString(.fields("Mark"))
		end if
		.close
	end with
	set Recset = nothing
	CloseDB Conn
end if
%>
<html>
<head>
	<title>Pre-Alert</title>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		.pt7 { FONT-FAMILY: Century Gothic; FONT-SIZE: 7pt; LINE-HEIGHT: 8pt }
		.pt9 { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt }
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; font-style: italic; font-weight: bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #E0FFE0; BORDER-RIGHT: #E0FFE0 1px solid; BORDER-TOP: #E0FFE0 1px solid; BORDER-LEFT: #E0FFE0 1px solid; BORDER-BOTTOM: #006400 1px solid;}
		.sn{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #E0FFE0; BORDER-RIGHT: #E0FFE0 1px solid; BORDER-TOP: #E0FFE0 1px solid; BORDER-LEFT: #E0FFE0 1px solid; BORDER-BOTTOM: #006400 1px solid; TEXT-ALIGN:right}
	</style>
	<SCRIPT language="vbscript" src="css/function.vbs"></SCRIPT>
	<SCRIPT language=Javascript>
	<!--
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function ShowList() {
			var win = window.open("CustomerList.asp","CustomerList","resizable=1,scrollbars=1,width=600,height=500");
			win.focus();
		}
		
		function DoAttach() {
			window.location.href = "UploadDoc.asp?id=<%=id%>";
		}
	//-->
	</SCRIPT>
	<script language=vbscript>
	<!--
		sub DoCheck()
			if checkText("ReferNo","Job Number",1) = false then	exit sub
			if checkNum("Customer","Refer Code",1) = false then exit sub
			if checkText("Shipper","Shipper Name",1) = false then exit sub
			if checkText("Consignee","Consignee Name",1) = false then exit sub
			if checkText("Notify","Notify Party",1) = false then exit sub
			if checkText("Vessel","Vessel",1) = false then exit sub
			if checkText("Voy","Voy",1) = false then exit sub
			if checkText("Carrier","Carrier",0) = false then exit sub
			if checkText("POL","POL",1) = false then exit sub
			if checkText("POD","POD",1) = false then exit sub
			if checkText("ETD","ETD",1) = false then exit sub
			if not CheckDate(frmInput.ETD.value) then
				frmInput.ETD.focus
				msgbox "ETD is invalid. Exp." & year(date) & "0101"
				exit sub
			elseif not ConfirmDate(frmInput.ETD.value, 2) then
				frmInput.ETD.focus
				msgbox "ETD is out of range."
				exit sub
			end if
			if checkText("ETA","ETA",0) = false then exit sub
			if trim(frmInput.ETA.value) <> "" then
				if not CheckDate(frmInput.ETA.value) then
					frmInput.ETA.focus
					msgbox "ETA is invalid. Exp." & year(date) & "1231"
					exit sub
				elseif not ConfirmDate(frmInput.ETA.value, 3) then
					frmInput.ETA.focus
					msgbox "ETA is out of range."
					exit sub
				end if
			end if
			if checkText("Commodity","Commodity",1) = false then exit sub
			if checkDouble("Quantity","Quantity",1) = false then exit sub
			if checkText("Package","Package",1) = false then exit sub
			if checkDouble("GW","GW",1) = false then exit sub
			if checkDouble("CBM","CBM",1) = false then exit sub
			if checkText("PONO","PONO",0) = false then exit sub
			if checkText("TradeTerms","TradeTerms",0) = false then exit sub
			if checkText("HANDLING","Handling Mode",0) = false then exit sub
			if checkText("HBL","HBL",1) = false then exit sub
			if checkText("Mark","Shipping Mark", 0) = false then
				exit sub
			elseif checkLen("Mark","Shipping Mark",250) = false then
				exit sub
			end if
			frmInput.btnSave.disabled = true
			frmInput.submit()
		end sub
		
		function CheckDate(dt)
			yy = left(dt, 4)
			mm = mid(dt, 5, 2)
			dd = mid(dt, 7, 2)
			if isdate(yy & "/" & mm & "/" & dd) then
				CheckDate = true
			else
				CheckDate = false 
			end if
		end function
		
		function ConfirmDate(dt, cnt)
			yy = left(dt, 4)
			mm = mid(dt, 5, 2)
			dd = mid(dt, 7, 2)
			buf = datediff("d", date, cdate(yy & "/" & mm & "/" & dd))
			if buf >= 7 * (cnt - 3) and buf <= 30 * cnt then
				ConfirmDate = true
			else
				ConfirmDate = false 
			end if
		end function
				
		sub DoConfirm()
			if msgbox("Are you sure to delete it ?", 289, "Confirm Message") = 1 then
				window.location.href = "SavePreAlert.asp?del=1&id=<%=id%>"
			end if
		end sub
		
	//-->
	</script>
</head>
<body topmargin=0 OnContextmenu=window.event.returnValue=false>
<center>
<form name="frmInput" action="SavePreAlert.asp" method=post>
	<INPUT TYPE="HIDDEN" NAME="id" VALUE="<%=id%>">
	<table width=500 class=pt9 border=0>
		<tr><td colspan=4 align=center><font class=pt12><b><u><i><font color=red>P</font>RE-ALERT</i></u></b></font></td></tr>
		<tr><td colspan=4><hr width=100% size=1 color=blue height=5></td></tr>
		<tr><td class=pt9t>JOB No.:</td><td >
				<input class=so name="ReferNo" value="<%=ReferNo%>" maxlength=20 size=16 OnKeyDown="ResetEnter()"></td>
			<td class=pt9t>REFER CD:</td><td>
				<input class=sn name="Customer" value="<%=Customer%>" maxlength=6 size=6 onkeydown="ResetEnter()">
				<img src=img/search.jpg border=0 style="cursor:hand" onclick="ShowList()" alt="Click to search it"></td></tr>
		<tr><td class=pt9t>SHIPPER:</td><td colspan=3>
				<input class=so name="Shipper" value="<%=Shipper%>" maxlength=100 size=45 OnKeyDown="ResetEnter()"></td>
		<tr><td class=pt9t>CONSIGNEE:</td><td colspan=3>
			<input class=so name="Consignee" value="<%=Consignee%>" maxlength=100 size=45 OnKeyDown="ResetEnter()"></td></tr>
		<tr><td class=pt9t>NOTIFY PARTY:</td><td colspan=3>
			<input class=so name="Notify" value="<%=Notify%>" maxlength=100 size=45 OnKeyDown="ResetEnter()"></td></tr>
		<tr><td class=pt9t>VESSEL:</td><td>
				<input class=so name="Vessel" value="<%=Vessel%>" maxlength=50 size=20 OnKeyDown="ResetEnter()"></td>
			<td class=pt9t>VOY:</td><td>
				<input class=so name="Voy" value="<%=Voy%>" maxlength=20 size=10 OnKeyDown="ResetEnter()"></td></tr>
		<tr><td class=pt9t>CARRIER:</td><td>
				<input class=so name="Carrier" value="<%=Carrier%>" maxlength=50 size=20 OnKeyDown="ResetEnter()"></td>
			<td class=pt9t>LCL OR FCL:</td><td>
				<select name="Pattern" OnKeyDown="ResetEnter()">
					<option value="LCL" <%if Pattern = "LCL" then response.write " selected"%>>LCL
					<option value="FCL" <%if Pattern = "FCL" then response.write " selected"%>>FCL
				</select></td></tr>
		<tr><td class=pt9t>POL:</td><td>
				<input class=so name="POL" value="<%=POL%>" maxlength=20 size=12 OnKeyDown="ResetEnter()"></td>
			<td class=pt9t>ETD:</td><td>
				<input class=so name="ETD" value="<%=ETD%>" maxlength=8 size=8 title="yyyymmdd" OnKeyDown="ResetEnter()"></td></tr>
		<tr><td class=pt9t>POD:</td><td>
				<input class=so name="POD" value="<%=POD%>" maxlength=20 size=12 OnKeyDown="ResetEnter()"></td>
			<td class=pt9t>ETA:</td><td>
				<input class=so name="ETA" value="<%=ETA%>" maxlength=8 size=8 title="yyyymmdd" OnKeyDown="ResetEnter()"></td></tr>
		<tr><td class=pt9t>COMMODITY:</td><td colspan=3>
				<input class=so name="Commodity" value="<%=Commodity%>" maxlength=100 size=45 OnKeyDown="ResetEnter()"></td></tr>
		<tr><td class=pt9t>QUANTITY:</td><td>
				<input class=sn name="Quantity" value="<%=Quantity%>" maxlength=10 size=8 OnKeyDown="ResetEnter()">
				<input class=so name="Package" value="<%=Package%>" maxlength=20 size=10 OnKeyDown="ResetEnter()">(Pkgs)</td>
			<td class=pt9t colspan=2>SHIPPING MARK:</td></tr>
		<tr><td class=pt9t>GROSS WEIGHT:</td><td>
				<input class=sn name="GW" value="<%=GW%>" maxlength=10 size=8 OnKeyDown="ResetEnter()">KGS</td>
			<td colspan=2 rowspan=6>
				<textarea class=so name="Mark" rows=10 style="width:160"><%=MARK%></textarea></td></tr>				
		<tr><td class=pt9t>MEASUREMENT:</td><td>
				<input class=sn name="CBM" value="<%=CBM%>" maxlength=10 size=8 OnKeyDown="ResetEnter()">M<sup>3</sup></td></tr>
		<tr><td class=pt9t>PO No.:</td><td>
				<input class=so name="PONO" value="<%=PONO%>" maxlength=20 size=16 OnKeyDown="ResetEnter()"></td></tr>	
		<tr><td class=pt9t>TRADE TERMS:</td><td>
				<input class=so name="TradeTerms" value="<%=TradeTerms%>" maxlength=50 size=20 OnKeyDown="ResetEnter()"></td></tr>	
		<tr><td class=pt9t>HOUSE B/L:</td><td>
				<input class=so name="HBL" value="<%=HBL%>" maxlength=20 size=16 OnKeyDown="ResetEnter()"></td></tr>
		<tr><td class=pt9t>SPEC.HANDLING:</td><td>
				<input class=so name="SpecHandle" value="<%=SpecHandle%>" maxlength=20 size=10 OnKeyDown="ResetEnter()"></td></tr>
		<tr><td colspan=4><hr width=100% size=1 color=blue></td></tr>
		<tr height=30><td>
<% if id > 0 then %>
				<input type=button class=pt9t style="cursor:hand; width:90; height:30; color:red" value="Delete" onclick="DoConfirm()">
<% end if %>
			</td><td colspan=2 align=right>
<% if id > 0 then %>
				<input type=button class=pt9t style="cursor:hand; width:90; height:30; color:blue" value="Attach" onclick="DoAttach()">
<% end if %>
			</td>
			<td>
				<input type=button class=pt9t style="cursor:hand; width:90; height:30" name=btnSave value="Save" onclick="DoCheck()"></td></tr>
	</table>
</form>
</center>
</body>
</html>