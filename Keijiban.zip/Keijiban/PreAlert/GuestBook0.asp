<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
	
	strSQL = ""
	strSQL = strSQL & "DELETE From _GuestBook WHERE GID = " & GetLong(request("id"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Conn.Execute strSQL	
	CloseDB Conn
	
	Response.Redirect "GuestBook2.asp?p=" & GetLong(request("p"))	
%>