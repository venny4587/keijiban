<!-- #include file="DBConst.asp" -->
<!-- #include file="clsDBLogAccess.asp" -->
<%
'On Error Resume Next

	Session("SqlServerName") = "SERVER"
	Session("DataBaseName") = "PREALERT"
	
dim checkflag
dim GetUserID
dim GetPassWord
dim LogAccessID

checkflag = 0
GetUserID = request("userid")
GetPassWord = request("password")
LogAccessID = request("LogAccessID")

OpenSQL Conn, Session("SqlServerName"), Session("DataBaseName")
Set Recset = Server.CreateObject ("ADODB.Recordset")
with Recset
	strSql = "SELECT ID, CorpName, Password, CorpLevel FROM _PreAlertUser WHERE LogonID = '" & GetUserID & "'"
	.Open strSql, Conn, adOpenKeyset, adLockReadOnly 
	if not .EOF then
		if 	GetPassWord = cstr(.Fields("Password") & "") then
			checkflag = 1
			Session("UserLogonID") = GetUserID
			Session("UserID") = clng(cstr(.Fields("ID") & ""))
			Session("UserName") = trim(cstr(.Fields("CorpName") & ""))
			Session("UserLevel") = clng(cstr(.Fields("CorpLevel") & ""))
		end if
	end if
	.Close 
end with
set Recset = nothing
CloseDB Conn

if checkflag = 1 then	

	Response.Cookies("TEST_UserID") = GetUserID
	Response.Cookies("TEST_UserID").Expires = #January 01, 2010# 
	Response.Cookies("TEST_Password") = GetPassWord
	Response.Cookies("TEST_Password").Expires = #January 01, 2010# 
	
	'LogAccess �� UserID ��������
	Set objDBLogAccess = New clsDBLogAccess
	objDBLogAccess.UpdateUserIDByAccessID LogAccessID, Session("UserID"), GetUserID
	Set objDBLogAccess = Nothing
	
	Session("LogAccessID") = LogAccessID
	
	Response.redirect "prealertmain.asp"	
else
	Response.redirect "logon.asp"
end if
%>
