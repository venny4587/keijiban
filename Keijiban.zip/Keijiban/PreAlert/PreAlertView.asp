<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	myPageSize = 10

	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	if lngPageNumber > 10 then lngPageNumber = 10
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<html>
<head>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		.pt7 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 8pt }
		.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 9pt }
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #404040; font-weight: bold }	
		.pt9r { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #FF0000; font-weight: bold }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #C0C0C0; BORDER-RIGHT: #C0C0C0 1px solid; BORDER-TOP: #C0C0C0 1px solid; BORDER-LEFT: #C0C0C0 1px solid; BORDER-BOTTOM: #C0C0C0 1px solid;}
		.sn{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #E0E0E0; BORDER-RIGHT: #E0E0E0 1px solid; BORDER-TOP: #E0E0E0 1px solid; BORDER-LEFT: #E0E0E0 1px solid; BORDER-BOTTOM: #E0E0E0 1px solid; TEXT-ALIGN:right}
	</style>
	<SCRIPT LANGUAGE="JavaScript">		
		function ShowDetail(id) {
			var win = window.open("PreAlertDetail.asp?id="+id,"PreAlertDetail","resizable=1,scrollbars=1,width=800,height=600");
			win.focus();
		}
		
		function doTurnPage(myPage) {
			frmInput.page.value = myPage;
			frmInput.submit();
		}
	</SCRIPT>
</head>
<body topmargin=0 leftmargin=0 OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>

	<table width=100% border=0>
		<tr><td align=center valign=top>
		
			<form name=frmInput action=PreAlertView.asp method=post>
				<input type=hidden name="page" value="<%=lngPageNumber%>">
				
				<table width=96% bgcolor=#F0F0F0>
					<TR align=center height=30 class=pt9t>
						<TD width=50%><font color=red>N</font>ew Pre-Alert</TD>
						<TD width=30% align=right></TD>
						<TD width=20%></TD>
					</TR>
				</table><br>
<%	
		With Recset
			strSQL = "SELECT PID, HBL, Shipper, Consignee, Pattern, "
			strSQL = strSQL + " POL, POD, ETD, ETA FROM _PreAlert"
			strSQL = strSQL + " WHERE ReadFlag = 0"
			strSQL = strSQL + " AND Customer = " & Session("UserID")
			strSQL = strSQL + " ORDER BY ETA"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
'response.write strSQL
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount 
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize

%>
				<table width=96% class=pt9>
					<TR height=20 ALIGN=center bgcolor=#808080 style="color:white; font-weight:bold">
						<TD width=5% nowrap>No.</TD>
						<TD width=15% nowrap>House B/L</TD>
						<TD width=25% nowrap>Shipper</TD>
						<TD width=12% nowrap>POL</TD>
						<TD width=8% nowrap>ETD</TD>
						<TD width=12% nowrap>POD</TD>
						<TD width=8% nowrap>ETA</TD>
						<TD width=6% nowrap>TYP</TD>
						<TD width=4% nowrap><br></TD>
					</TR>
<%
				Do while not .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else						
%>
					<TR ALIGN=center height=25 valign=bottom>
						<TD nowrap><%=lngCount%><BR></TD>
						<TD nowrap ALIGN=left><%=.Fields("HBL")%><BR></TD>
						<TD nowrap ALIGN=left <%=ShowTitle(.Fields("Shipper"), 20)%>><%=StringCut(.Fields("Shipper"),20)%><BR></TD>
						<TD nowrap <%=ShowTitle(.Fields("POL"), 10)%>><%=StringCut(.Fields("POL"),10)%><BR></TD>
						<TD nowrap><%=Str2MD(.Fields("ETD"))%><BR></TD>
						<TD nowrap <%=ShowTitle(.Fields("POD"), 10)%> ><%=StringCut(.Fields("POD"),10)%><BR></TD>
						<TD nowrap><%=Str2MD(.Fields("ETA"))%><BR></TD>
						<TD nowrap><%=.Fields("Pattern")%><BR></TD>
						<TD nowrap><a href="javascript:ShowDetail('<%=.Fields("PID")%>')"><img src=img/search.jpg border=0 alt="View Detail"></a></TD>
					</TR>

					<TR height=5><TD colspan=9 background=img/line.jpg></TD></TR>
<%
					end if
					.movenext
				Loop
%>
				</TABLE><br>
<%
			else
				response.write "<font class=pt9r>Sorry, there is no new data found.</font>"
			end if
			
			If lngPageCount > 1 Then
				Response.Write ("<table width=96% bgcolor=#F0F0F0>")
				Response.Write ("<tr><td align=right>")
				Response.Write ("<table class=pt9><tr>")
				Response.Write ("<td><img src=img/go_left.jpg onclick=""doTurnPage(" & lngPageNumber-1 & ")""></td><td>&nbsp;</td>")
				For lngCount = 1 To lngPageCount
					if lngCount < 9 then 
						If lngCount = lngPageNumber Then
							Response.Write ("<td><b>" & lngCount & "</b></td><td>|</td>")
						Else
							Response.Write ("<td style=""cursor:hand"" onclick=""doTurnPage(" & lngCount & ")"">" & lngCount & "</td><td>|</td>")
						End If
					else
						If lngCount = lngPageNumber Then
							Response.Write ("<td><b>10</b></td><td>&nbsp;</td>")
						Else
							Response.Write ("<td style=""cursor:hand"" onclick=""doTurnPage(10)"">10</td><td>&nbsp;</td>")
						End If
						exit for
					end if
				Next
				Response.Write ("<td><img src=img/go_right.jpg onclick=""doTurnPage(" & lngPageNumber+1 & ")""></td>")
				Response.Write ("</tr></table></td></tr></table>")					
			End If
			.close
		end with
%>
			</form>										
		</td></tr>
	</table>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
%>