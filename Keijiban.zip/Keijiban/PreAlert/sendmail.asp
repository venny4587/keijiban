
<%
dim smtp_user
dim smtp_pwd
dim smtp_server
dim smtp_email
dim smtp_sender
dim	chrLineMark
dim chrSpace

smtp_email = "csv@company.com"
smtp_sender = "server"
smtp_server = "mail.company.com"
smtp_user = "user"
smtp_pwd = "pass"

'chrLineMark = "<BR>"
'chrSpace = "&nbsp;&nbsp;&nbsp;&nbsp"
chrLineMark = vbcrlf & vbcrlf
chrSpace = "  "

Sub SendMail(myName, myStr)
dim myRec
dim mySql
dim myConn
dim myTitle
dim myHead
dim myBody
dim myFoot
dim myContent
	
	myContent = myName & " �l���牺�L�̏�񂪓���܂����F" & chrLineMark
	myContent = myContent & "-------------------------------------------" & chrLineMark
	if myStr <> "" then	myContent = myContent & myStr & chrLineMark
	myContent = myContent & "-------------------------------------------" & chrLineMark
	myContent = myContent & chrSpace & "�Ԏ������肢���܂��B" & chrLineMark
	myContent = myContent & chrLineMark
	myContent = myContent & "PS: ���̃��[���͎������M�ł����A�ԐM���Ȃ��ł��������B"
		
	myEmail = "venny@company.com"
	myTitle = "PreAlert����GuestBook�̐V�K�o�^"
	Call SendAction (myEmail, myName, myTitle, myContent)
end sub

Sub SendAction(email, name, subject, content)
dim jmail
	Set jmail = Server.CreateObject("JMAIL.Message")
	jmail.silent = true
	jmail.logging = true
	'jmail.Charset = "SHIFT-JIS"
	'jmail.ContentType = "text/html"
	jmail.ContentType = "text"

	jmail.AddRecipient email, name
	jmail.Subject = subject
	jmail.Body = content

	'jmail.Prority = 1
	jmail.From = smtp_email 
	jmail.FromName = smtp_sender
	
	jmail.MailServerUserName = smtp_user
	jmail.MailServerPassword = smtp_pwd
	jmail.Send(smtp_server)
	jmail.Close()

End Sub
%>
