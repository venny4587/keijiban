<%
	Session.Timeout = 300
	Server.ScriptTimeout = 300
	
	'dateSign
	gsDateSign = "/"
	gsDateConvert = "120"
	bgColor_Common = "#FFFFFF"
	bgColor_Title = "#E0E0E0"
	bColorLight = "#F0F0F0"
	bColorDark = "#808080"
	bColorInput = "#FFC0C0"
	bColorLine = "#F0F0F0"

	btnColor = "#000000"
	btnColorBg = "#F0F0F0"
	btnColorOn = "#0000FF"
	btnColorExit = "#FF0000"
	btnColorOnBg = "#FFFFFF"

	'gsCharSet = "iso-8859-1"
	'gsCharSet = "gb2312"
	gsCharSet = "shift_jis"

	gsTempChar = "`"
	gsStringIndex = "instr"
	gsStringSub = "mid"
	gsWeight = " KG"
	gsGWeight = " G"
	gsMeasurement = " CBM"
	'gsSysDate = "now()"
	gsSysDate = "GETDATE()"
	'sqlchar = "%"

	CurrentUrl = ""
	
'------------------------------------------------
	SqlServerName = "SERVER"
	DataBaseName = "PREALERT"
'------------------------------------------------
	
	If Session("UserID") = "" Then		
		Response.Write "<HTML><BODY OnLoad=""parent.location.href = 'LogOff.asp?TimeOut=1';""></BODY></HTML>"
		Response.End
	else
		WebUserID = Session("WebUserID")		'���[�U�[ID
		UserID = Session("UserID")			'���O�I��ID
		UserName = Session("UserName")
	end if
	
%>