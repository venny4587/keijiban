<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<!-- #include file="sendmail.asp" -->
<%
'on error resume next
		
	ID = GetLong(Request("id"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")

	strSQL = "SELECT * FROM _GuestBook WHERE GID = " & ID
	Recset.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
	With RecSet
		If .EOF Then
			.AddNew
			.Fields ("LogonUser") = Session("UserLogonID")
			.Fields("CreateDate") = now
		End If
		.Fields ("Author") = GetPost(request("Author"))
		.Fields("Title") = GetPost(request("Title"))
		.Fields("Body") = GetPost(request("Body"))
		.Fields("Require") = GetLong(request("Require"))

		.Update
		.Close
	End With
	Set RecSet = Nothing
	CloseDB Conn
	
	call SendMail(GetPost(request("Author")), GetPost(request("Body")))
	Response.Redirect "GuestBook.asp"	
%>
