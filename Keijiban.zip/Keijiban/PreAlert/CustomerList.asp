<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	nm = GetString(request("nm"))
	mode = GetLong(request("mode"))

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")	
%>

<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<link rel="stylesheet" href="css/style.css" type="text/css">
	<TITLE>Consignee's Reference Code</TITLE>	
	<style>	
		.pt7 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 8pt; LINE-HEIGHT: 8pt }
		.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 9pt }
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; font-style: italic; font-weight: bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #E0FFE0; BORDER-RIGHT: #E0FFE0 1px solid; BORDER-TOP: #E0FFE0 1px solid; BORDER-LEFT: #E0FFE0 1px solid; BORDER-BOTTOM: #006400 1px solid;}
		.sn{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12px; BACKGROUND: #E0FFE0; BORDER-RIGHT: #E0FFE0 1px solid; BORDER-TOP: #E0FFE0 1px solid; BORDER-LEFT: #E0FFE0 1px solid; BORDER-BOTTOM: #006400 1px solid; TEXT-ALIGN:right}
	</style>
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd, nm) {
			var frm = window.opener.frmInput;
			frm.Customer.value = cd;
			frm.Consignee.value = nm.replace("~", "'");
			window.close();
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body OnContextmenu=window.event.returnValue=false>	
	<FORM METHOD="POST" ACTION="CustomerList.asp" NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<table class=pt9t>
			<TR height=30 align=center>
				<TD width=80>Name :</TD>
				<TD nowrap><input class=so name="nm" value="<%=nm%>" maxlength=16 size=20 onkeydown="ResetEnter()"></TD>						
				<TD width=80 align=right><INPUT TYPE=SUBMIT class=pt9t style="cursor:hand; width:60; height:25" VALUE="Search"></TD>
			</TR>
		</table>
		
		<hr width=96% size=1 color=blue>
<%
	if mode > 0 then 
		With Recset
			strSQL = "SELECT ID, CorpName FROM _PreAlertUser WHERE SUBSTRING(LogonID, 1, 3) = 'CLS'"
			if nm <> "" then strSQL = strSQL + " AND CorpName LIKE '%" & nm & "%'"
			strSQL = strSQL + " ORDER BY CorpName"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
%>
		<center>
			<table width=96% class=pt9 cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD width=20%>Code</TD>
					<TD width=80%>Name</TD>
				</TR>
<%
				Do Until .EOF				
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine(<%=.Fields("ID")%>,'<%=fitStr(.Fields("CorpName"))%>')">
					<TD nowrap ALIGN=center><%=GetString(.Fields("ID"))%><BR></TD>
					<TD nowrap ALIGN=left><%=GetString(.Fields("CorpName"))%><BR></TD>
				</TR>
				<TR height=5><TD colspan=4 background=img/line.jpg></TD></TR>
<%							
					.MoveNext
				Loop
%>
			</TABLE>
		</center>
		<hr width=100% size=1 color=blue>
<%
			else
				response.write "<br>Sorry, there is no record found."
			end if
			.Close 
		End With
	end if
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
	
function fitStr(myStr)
	fitStr = replace(myStr, "'", "~")
end function
%>