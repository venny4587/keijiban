<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	id = GetLong(request("id"))
	fid = GetLong(request("fid"))
	mode = GetLong(request("mode"))
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
if id > 0 then
	with Recset
		StrSql = "SELECT ReferNo FROM _PreAlert WHERE PID = " & id
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			ReferNo = GetString(.fields("ReferNo"))
		end if
		.close
	end with
	
	if mode = -1 then
		StrSql = "DELETE FROM _PreAlertDoc WHERE FID = " & fid
		Conn.Execute StrSql
	end if
end if
%>
<html>
<head>
	<TITLE>UPLOAD</TITLE>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		A.list:link{COLOR: #FF0000;TEXT-DECORATION: none}
		A.list:active{COLOR: #FF0000;TEXT-DECORATION: none}
		A.list:visited{COLOR: #FF0000;TEXT-DECORATION: none}
		A.list:hover{COLOR: #FF0000;TEXT-DECORATION: none}
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #404040; font-weight: bold }
		.pt9b { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #0000FF; font-weight: bold }
		.pt9r { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #FF0000; font-weight: bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt; color: #404040 }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10px; BACKGROUND: #C0C0C0; BORDER-RIGHT: #C0C0C0 1px solid; BORDER-TOP: #C0C0C0 1px solid; BORDER-LEFT: #C0C0C0 1px solid; BORDER-BOTTOM: #C0C0C0 1px solid;}
	</style>
	<script language=vbscript>
		sub CheckFile()
			if trim(frmInput.filetitle.value) = "" then
				frmInput.filetitle.focus
				msgbox "Please input the title of your data file.", 64, "Confirm Message"
			elseif trim(frmInput.filename.value) = "" then
				msgbox "Please select your data file to upload.", 64, "Confirm Message"
			else
				myExt = mid(frmInput.filename.value, instr(frmInput.filename.value, ".") + 1)
				select case lcase(myExt)
				case "doc", "xls", "pdf", "swf", "jpg", "jpeg", "gif", "tif", "tiff", "htm", "html"
					frmInput.btnUpload.disabled = true
					frmInput.submit
				case else
					msgbox "Please select a data file supported by Pre-Alert System.", 64, "Confirm Message"
				end select
			end if
		end sub
		
		sub DoDelete(myID)
			if msgbox("Are you sure to delete it ?", 289, "Confirm Message") = 1 then
				window.location.href = "UploadDoc.asp?mode=-1&id=<%=id%>&fid=" & myID
			end if
		end sub
	</script>
</head> 
<body topmargin=0 OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
<form name="frmInput" Method="Post" Enctype="multipart/form-data" Action="UploadDocProc.asp">
	<input type=hidden name="id" value="<%=id%>">
	<table width=100% cellspacing=0 cellpadding=0 border="0">

  		<tr><td align="center" valign=middle>
	  		<BR>
			<TABLE width=480 bgcolor=#F0F0F0 class=pt9t>
		  		<TR align=center height=30><TD colspan=4>Attach File Upload</TD></TR>
		  		<TR><TD colspan=4><hr width=96%></TD></TR>
		  		
		  		<TR height=30>
		  			<TD width=120 align=right>Current Job No. :</TD>
		  			<TD width=20>&nbsp;</TD>
					<TD colspan=2><%=ReferNo%></TD>
				</TR>
				
		  		<TR height=30>
		  			<TD width=120 align=right>Supported Type:</TD>
		  			<TD width=20>&nbsp;</TD>
					<TD colspan=2>.pdf .doc .xls .swf .gif .tif .tiff .jpg .jpeg .htm .html</TD>
				</TR>
				
		  		<TR height=30>
		  			<TD width=120 align=right>Document Title:</TD>
		  			<TD width=20>&nbsp;</TD>
					<TD colspan=2><input class=so maxlength=50 name="filetitle" size=40></TD>
				</TR>
				
		  		<TR height=30>
		  			<TD width=120 align=right>Document File:</TD>
		  			<TD width=20>&nbsp;</TD>
					<TD colspan=2><input class=so type="file" name="filename" size=40></TD>
				</TR>
		  		<TR><TD colspan=4><hr width=96%></TD></TR>
<%
	if mode > 0 then 
%>
		  		<TR><TD colspan=4 class=pt12 align=center><%
					select case mode 
					case 1  
						response.write "<font class=pt9r>Sorry, your file data is incorrect !</font>"
					case 2
						response.write "<font class=pt9r>Error occurred, please try again !</font>"
					case 8
						response.write "<font class=pt9b>Your file has been uploaded successfully !</font>"
					end select
					%></TD></TR>
		  		<TR><TD colspan=4><hr width=96%></TD></TR>
<%
	end if 
%>
		  		<TR align=center height=50>
		  			<TD colspan=4><input type="button" class=pt9t style="width:90px;height:30px;" name=btnUpload value="UPLOAD" onclick="CheckFile()"></TD>
				</TR>
			</TABLE>
<%
	with Recset
		StrSql = "SELECT FID, FileTitle, FilePath, UploadDate FROM _PreAlertDoc"
		StrSql = StrSql & " WHERE PID = " & id & " ORDER BY UploadDate"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
%>
			<TABLE width=480 class=pt9t>
		  		<TR valign=bottom height=30><TD colspan=3>Current Attach File</TD></TR>
		  		<TR><TD colspan=3><hr width=96%></TD></TR>
<%
			do while not .eof
				response.write "<TR><TD align=center width=120>" & ShowDateTimeShort(.Fields("UploadDate"))
				response.write "<TD width=300><A href='" & GetString(.Fields("FilePath")) & "' target=_blank>"
				response.write GetString(.Fields("FileTitle")) & "<TD><A class=list href='"
				response.write "javascript:DoDelete(" & GetLong(.Fields("FID")) & ")'>Delete</A></TR>"
				.movenext
			loop
%>
		  		<TR><TD colspan=3><hr width=96%></TD></TR>
		  	</table>
<%
		end if
		.close
	end with
	set Recset = nothing
%>
	    </td></tr>
	</table>
</form>
</body>
</html> 
<%
	set Recset = nothing
	CloseDB Conn
%>
