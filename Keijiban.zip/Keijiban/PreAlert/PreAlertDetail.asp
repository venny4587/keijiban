<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<html>
<head>
	<title>Pre-Alert</title>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		A.list:link{COLOR: #0000FF;TEXT-DECORATION: none}
		A.list:active{COLOR: #0000FF;TEXT-DECORATION: none}
		A.list:visited{COLOR: #0000FF;TEXT-DECORATION: none}
		A.list:hover{COLOR: #0000FF;TEXT-DECORATION: none}
		.pt7 { FONT-FAMILY: Century Gothic; FONT-SIZE: 7pt; LINE-HEIGHT: 8pt }
		.pt9 { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt }
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; font-style: italic; font-weight: bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt }	
	</style>
	<script language=vbscript>
	   sub DoShortCut()
			if window.event.keyCode=27 then	window.Close() 
			if window.event.keyCode=80 then window.Print()
		end sub
	</script>
</head>
<body onKeydown="DoShortCut()" OnContextmenu=window.event.returnValue=false OnSelectstart=window.event.returnValue=false>
<center>
	<table width=600 class=pt9>
		<tr valign=top><td><img src=img/logo.jpg></td>
			<td align=right>
				<font class=pt12><b>COMPANY  Co., Ltd.</b></font><br>
				<font class=pt7>7th Floor, Nishinokinryo Bldg., West<br>
				6-11, 1-chome Kyutaromatchi, Chuo-ku<br>
				Osaka 123-4567, Japan<br>
				Tel:(81)01-1111-1111<br>
				Fax:(81)02-2222-2222</font></td></tr>
		<tr><td colspan=2><br></td></tr>
		<tr><td colspan=2 align=center><font class=pt12><b><u><i>PRE-ALERT</i></u></b></font></td></tr>
		<tr><td colspan=2><hr width=100% size=1 color=gray height=5></td></tr>
		<tr><td width=30%></td><td width=70%></td></tr>

<%	
	id = GetLong(request("id"))
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		StrSql = "SELECT * FROM _PREALERT WHERE PID = " & ID
		strSQL = strSQL + " AND Customer = " & Session("UserID")
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
%>
		<tr height=20><td class=pt9t>JOB NO.:</td><td><%=.fields("ReferNo")%></td></tr>
		<tr height=20><td class=pt9t>SHIPPER:</td><td><%=.fields("Shipper")%></td></tr>
		<tr height=20><td class=pt9t>CONSIGNEE:</td><td><%=.fields("Consignee")%></td></tr>
		<tr height=20><td class=pt9t>NOTIFY PARTY:</td><td><%=.fields("Notify")%></td></tr>
		<tr height=20><td class=pt9t>VESSEL:</td><td><%=.fields("Vessel")%></td></tr>
		<tr height=20><td class=pt9t>VOY:</td><td><%=.fields("Voy")%></td></tr>
		<tr height=20><td class=pt9t>CARRIER:</td><td><%=.fields("Carrier")%></td></tr>
		<tr height=20><td class=pt9t>POL:</td><td><%=.fields("POL")%></td></tr>
		<tr height=20><td class=pt9t>ETD:</td><td><%=formatDateEng(Str2Date(.fields("ETD")))%></td></tr>
		<tr height=20><td class=pt9t>POD:</td><td><%=.fields("POD")%></td></tr>
<%	if GetString(.fields("ETA")) = "" then %>
		<tr height=20><td class=pt9t>ETA:</td><td>TO BE CONFIRM</td></tr>
<%	elseif .fields("OverFlag") then %>
		<tr height=20><td class=pt9t>ETA:</td><td><%=formatDateEng(Str2Date(.fields("ETA")))%>&nbsp;<img src=img/check.jpg alt="Confirmed"></td></tr>
<%	else %>
		<tr height=20><td class=pt9t>ETA:</td><td><%=formatDateEng(Str2Date(.fields("ETA")))%>&nbsp;<img src=img/wait.jpg alt="Confirming..."></td></tr>
<%	end if %>
		<tr height=20><td class=pt9t>PONO:</td><td><%=.fields("PONO")%></td></tr>
		<tr height=20><td class=pt9t>T/T:</td><td><%=.fields("TradeTerms")%></td></tr>
		<tr height=20><td class=pt9t>COMMODITY:</td><td><%=.fields("Commodity")%></td></tr>
		<tr height=20><td class=pt9t>QUANTITY:</td><td><%=formatnumber(.fields("Quantity"),2,true)%><%=.fields("Package")%></td></tr>
		<tr height=20><td class=pt9t>GROSS WEIGHT:</td><td><%=formatnumber(.fields("GW"),3,true)%>KGS</td></tr>
		<tr height=20><td class=pt9t>MEASUREMENT:</td><td><%=formatnumber(.fields("CBM"),3,true)%>CBM</td></tr>
		<tr height=20><td class=pt9t>LCL OR FCL:</td><td><%=.fields("Pattern")%></td></tr>
		<tr height=20><td class=pt9t>BILL NO:</td><td><%=.fields("HBL")%></td></tr>
		<tr height=20><td class=pt9t>SPEC.HANDLING:</td><td><%=.fields("SpecHandle")%></td></tr>
		<tr><td class=pt9t valign=top>MARK:</td><td><%=replace(.fields("Mark"),vbcrlf,"<br>")%></td></tr>
<%
			ReadFlag = GetLong(.fields("ReadFlag"))
		else
			response.write "No record founded."
		end if
		.close	
		
		StrSql = "SELECT FID, FileTitle, FilePath, UploadDate FROM _PreAlertDoc"
		StrSql = StrSql & " WHERE PID = " & id & " ORDER BY UploadDate"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			response.write "<tr><td class=pt9t valign=top>ATTACHED DOC:</td><td>"
			do while not .eof
				response.write "<A href='" & GetString(.Fields("FilePath")) & "' target=_blank>"
				response.write GetString(.Fields("FileTitle")) & "<br>"
				.movenext
			loop
			response.write "</td></tr>"
		end if
		.close
	end with
	
%>
		<tr><td colspan=2><hr width=100% size=1 color=gray></td></tr>
	</table>
</center>
</body>
</html>
<%
	if ReadFlag = 0 then 
		StrSql = "UPDATE _PREALERT"
		StrSql = StrSql & " SET ReadFlag = 1"
		StrSql = StrSql & ", UpdateID = " & Session("UserID")
		StrSql = StrSql & ", UpdateDate = GETDATE()"
		StrSql = StrSql & " WHERE PID = " & ID
		Conn.Execute StrSql
	end if
	
	set Recset = nothing
	CloseDB Conn
%>