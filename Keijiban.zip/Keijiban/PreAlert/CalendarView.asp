<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim etd(50)
dim eta(50)

	date1 = dateadd("d", -7, date)
	date2 = dateadd("d", 28, date)

	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	With Recset
		strSQL = "SELECT ETD, COUNT(PID) AS ETD_CNT FROM _PreAlert"
		strSQL = strSQL + " WHERE Customer = " & Session("UserID")
		strSQL = strSQL + " AND ETD BETWEEN '" & Date2Str(date1) & "' AND '" & Date2Str(date2) & "'" 
		strSQL = strSQL + " GROUP BY ETD"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		do while not .EOF
			idx = datediff("d", date1, cdate(Str2Date(.fields("ETD"))))
			etd(idx) = GetLong(.Fields("ETD_CNT"))
			.movenext
		loop
		.close
		
		strSQL = "SELECT ETA, COUNT(PID) AS ETA_CNT FROM _PreAlert"
		strSQL = strSQL + " WHERE Customer = " & Session("UserID")
		strSQL = strSQL + " AND ETA BETWEEN '" & Date2Str(date1) & "' AND '" & Date2Str(date2) & "'" 
		strSQL = strSQL + " GROUP BY ETA"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		do while not .EOF
			idx = datediff("d", date1, cdate(Str2Date(.fields("ETA"))))
			eta(idx) = GetLong(.Fields("ETA_CNT"))
			.movenext
		loop
		.close
	end with
%>
<html>
<head>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		A.etd:link{COLOR: green;TEXT-DECORATION: none}
		A.etd:active{COLOR: green;TEXT-DECORATION: none}
		A.etd:visited{COLOR: green;TEXT-DECORATION: none}
		A.etd:hover{COLOR: green;TEXT-DECORATION: none}
		A.eta:link{COLOR: blue;TEXT-DECORATION: none}
		A.eta:active{COLOR: blue;TEXT-DECORATION: none}
		A.eta:visited{COLOR: blue;TEXT-DECORATION: none}
		A.eta:hover{COLOR: blue;TEXT-DECORATION: none}
		.pt7 { FONT-FAMILY: Century Gothic; FONT-SIZE: 8pt; LINE-HEIGHT: 8pt; font-weight: bold }
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #404040; font-weight: bold }	
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 12pt; color: #404040 }	
	</style>
	<SCRIPT LANGUAGE="JavaScript">		
		function ShowETD(etd) {
			window.location.href = "PreAlertList.asp?mode=2&etd=" + etd;
		}
		
		function ShowETA(eta) {
			window.location.href = "PreAlertList.asp?mode=2&eta=" + eta;
		}
	</SCRIPT>
</head>

<body topmargin=0 leftmargin=0 OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
	<table width=100% border=0>
		<tr><td align=center valign=top>
		
			<table width=96% bgcolor=#F0F0F0>
				<TR align=center height=25 class=pt9t>
					<TD width=50%><font color=Tomato>V</font>iew Calendar</TD>
					<TD width=50% valign=bottom class=pt7>
						<font color=green>D</font>-departure <font color=blue>A</font>-arrival</TD>
				</TR>
			</table><br>
			
			<TABLE width=80% cellspacing=5 class=pt9t>
				<TR align=center class=pt12>
					<TD colspan=2><%=year(Date1)%></TD><TD colspan=3></TD>
					<TD colspan=2><%=GetMonthEng(month(date1))%></TD></TR>
				<TR height=5><TD colspan=9 background=img/line.jpg></TD></TR>
				<TR ALIGN=center bgcolor=#C0C0C0 style="color:white">
					<TD width=14% nowrap><font color=red>SUN</font></TD>
					<TD width=14% nowrap>MON</TD>
					<TD width=14% nowrap>TUE</TD>
					<TD width=14% nowrap>WED</TD>
					<TD width=14% nowrap>THU</TD>
					<TD width=14% nowrap>FRI</TD>
					<TD width=14% nowrap><font color=black>SAT</font></TD>
				</TR>
				<TR height=25 align=center>
<%
	if weekday(date1) > 1 then 
		for i = 1 to weekday(date1) - 1
			myDate = DateAdd("d",i - weekday(date1), date1)
			if month(myDate) < month(date1) then
				response.write "<TD></TD>"
			else
				response.write "<TD><font color=gray>" & Day(myDate) & "</font></TD>"
			end if
		next
	end if
	myDate = GetMonthLastDay(date1)
	for i = day(date1) to day(myDate)
		curDate = dateadd("d", i - day(date1), date1)
		if curDate > date2 then
			response.write "<TD><font color=gray>" & Day(curDate) & "</font></TD>"
		elseif curDate = date then
			response.write "<TD bgcolor=C0FFC0><font class=pt12>" & Day(curDate) & "</font>" & ShowData(curDate) & "</TD>"
		else
			response.write "<TD>" & Day(curDate) & ShowData(curDate) & "</TD>"
		end if
		if weekday(curDate) = 7 then
			response.write "</TR>"
			if day(curDate) < day(myDate) then response.write "<TR height=25 align=center>" 
		end if
	next
	if weekday(myDate) < 7 then 
		for i = weekday(myDate) + 1 to 7
			response.write "<TD></TD>"
		next
		response.write "</TR>"
	end if
%>		
				<TR height=5><TD colspan=9 background=img/line.jpg></TD></TR>
			</TABLE><br>
<%
	if month(date2) > month(date1) then 
		
%>
			<TABLE width=80% cellspacing=5 class=pt9t>
				<TR align=center class=pt12>
					<TD colspan=2><%=year(Date2)%></TD><TD colspan=3></TD>
					<TD colspan=2><%=GetMonthEng(month(date2))%></TD></TR>
				<TR height=5><TD colspan=9 background=img/line.jpg></TD></TR>
				<TR ALIGN=center bgcolor=#C0C0C0 style="color:white">
					<TD width=14% nowrap><font color=red>SUN</font></TD>
					<TD width=14% nowrap>MON</TD>
					<TD width=14% nowrap>TUE</TD>
					<TD width=14% nowrap>WED</TD>
					<TD width=14% nowrap>THU</TD>
					<TD width=14% nowrap>FRI</TD>
					<TD width=14% nowrap><font color=black>SAT</font></TD>
				</TR>
				<TR height=25 align=center>
<%
		myDate = cdate(year(date2) & "/" & month(date2) & "/1")
		if weekday(myDate) > 1 then 
			for i = 1 to weekday(myDate) - 1
				response.write "<TD></TD>"
			next
		end if
		for i = 1 to day(date2)
			curDate = dateadd("d", i - day(date2), date2)
			if curDate = date then
			response.write "<TD bgcolor=C0FFC0><font class=pt12>" & Day(curDate) & "</font>" & ShowData(curDate) & "</TD>"
			else
				response.write "<TD>" & Day(curDate) & ShowData(curDate) & "</TD>"
			end if
			if weekday(curDate) = 7 then
				response.write "</TR>"
				if day(curDate) < day(date2) then response.write "<TR height=25 align=center>" 
			end if
		next
		if weekday(date2) < 7 then 
			for i = weekday(date2) + 1 to 7
				curDate = dateadd("d", i - weekday(date2), date2)
				if month(curDate) > month(date2) then
					response.write "<TD></TD>"
				else
					response.write "<TD><font color=gray>" & Day(curDate) & "</font></TD>"
				end if
			next
			response.write "</TR>"
		end if
%>
				<TR height=5><TD colspan=9 background=img/line.jpg></TD></TR>
			</TABLE><br>	
<%
	end if
%>									
		</td></tr>
	</table>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowData(myDate)
dim idx
	buf = ""
	idx = datediff("d", date1, myDate)
	if GetLong(etd(idx)) + GetLong(eta(idx)) > 0 then
		buf = "<table width=100% cellspacing=0 cellpadding=0 class=pt7>" 
		buf = buf & "<tr align=center><td width=50% >" 
		if GetLong(etd(idx)) > 0 then
			buf = buf & "<a class=etd href=""javascript:ShowETD('" & Date2Str(myDate) & "')"">D</a>"
		end if
		buf = buf & "</td><td width=50% >" 
		if GetLong(eta(idx)) > 0 then
			buf = buf & "<a class=eta href=""javascript:ShowETA('" & Date2Str(myDate) & "')"">A</a>"
		end if
		buf = buf & "</td></tr></table>" 
	end if
	ShowData = buf
end function
%>