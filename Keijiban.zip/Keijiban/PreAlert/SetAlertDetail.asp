<!-- #include file="../common/function.asp" -->
<!-- #include file="../common/common.asp" -->
<!-- #include file="../common/DBConst.asp" -->
<%	
dim JobCode
dim SubCode
dim JobType
	JobCode = GetPost(request("Job"))
	SubCode = GetLong(request("Eda"))
	
	if JobCode <> "" then
		Response.Buffer = True 
		filePath = "http://127.0.0.1/scripts/CORP/programs/HttpXml/GetCorpInfo.asp?JobCode=" & JobCode & "&SubCode=" & SubCode
		
		set HttpXML = server.CreateObject("MSXML2.XMLHTTP")
		HttpXML.open "GET", filepath, False
		HttpXML.send
		CleanXML = HttpXML.responseStream
		
		Set objDoc = Server.CreateObject("Msxml2.DOMDocument")
		objDoc.async = false
		objDoc.Load(CleanXML)
		
		JobCode = ""
		set objRoot = objDoc.documentElement
		If not objRoot Is Nothing Then
			set objNode = objRoot.selectSingleNode("//response")
			If not objNode Is Nothing Then
				set objField = objNode.selectSingleNode("JobCode")
				if not objField Is Nothing Then JobCode = GetString(objField.text)
				set objField = objNode.selectSingleNode("JobType")
				if not objField Is Nothing Then JobType = GetString(objField.text)
				set objField = objNode.selectSingleNode("JobShipment")
				if not objField Is Nothing Then JobShipment = GetString(objField.text)
				set objField = objNode.selectSingleNode("JobClient")
				if not objField Is Nothing Then JobClient = FitXmlString(objField.text)
				set objField = objNode.selectSingleNode("JobCountry")
				if not objField Is Nothing Then JobCountry = FitXmlString(objField.text)
				set objField = objNode.selectSingleNode("Vessel")
				if not objField Is Nothing Then Vessel = FitXmlString(objField.text)
				set objField = objNode.selectSingleNode("Voy")
				if not objField Is Nothing Then Voy = FitXmlString(objField.text)
				set objField = objNode.selectSingleNode("ETD")
				if not objField Is Nothing Then ETD = GetString(objField.text)
				set objField = objNode.selectSingleNode("ETA")
				if not objField Is Nothing Then ETA = GetString(objField.text)
				set objField = objNode.selectSingleNode("POLN")
				if not objField Is Nothing Then POLN = GetString(objField.text)
				set objField = objNode.selectSingleNode("POL")
				if not objField Is Nothing Then POL = GetString(objField.text)
				set objField = objNode.selectSingleNode("PODN")
				if not objField Is Nothing Then PODN = GetString(objField.text)
				set objField = objNode.selectSingleNode("POD")
				if not objField Is Nothing Then POD = GetString(objField.text)
				set objField = objNode.selectSingleNode("MBL")
				if not objField Is Nothing Then MBL = GetString(objField.text)
				set objField = objNode.selectSingleNode("HBL")
				if not objField Is Nothing Then HBL = GetString(objField.text)
				set objField = objNode.selectSingleNode("Commodity")
				if not objField Is Nothing Then Commodity = FitXmlString(objField.text)
				set objField = objNode.selectSingleNode("Quantity")
				if not objField Is Nothing Then Quantity = GetDouble(objField.text)
				set objField = objNode.selectSingleNode("Package")
				if not objField Is Nothing Then Package = GetString(objField.text)
				set objField = objNode.selectSingleNode("GW")
				if not objField Is Nothing Then GW = GetDouble(objField.text)
				set objField = objNode.selectSingleNode("CBM")
				if not objField Is Nothing Then CBM = GetDouble(objField.text)
				set objField = objNode.selectSingleNode("Container")
				if not objField Is Nothing Then Container = FitXmlString(objField.text)
				set objField = objNode.selectSingleNode("Marks")
				if not objField Is Nothing Then Marks = FitXmlString(objField.text)
				
				if CBM * 1000 < GW then
					RTON = GW / 1000
				else
					RTON = CBM
				end if
			end if
		end if
		
		set objRoot = nothing
		set objDoc = nothing
		
	end if
	
	if JobCode = "" then
		ShowMessage "�Y������f�[�^�͌�����܂���ł����B" 
	else
		msg = ""
		OpenSql Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		with Recset
			strSql = "SELECT JobCode FROM TBL_CTM_JOB WHERE Deleted = 0 AND JobNo = '" & JobCode & "'"
			if SubCode <> 0 then strSql = strSql & " AND EdaNo = '" & SubCode & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then msg = "�Y��Job No.�͊��ɑ��݂��܂��B�䒠�ԍ��F�u" & GetString(.fields("JobCode")) & "�v���m�F���Ă��������B"
			.Close
			
			strSql = "SELECT CTM_SALESMNGR, CTM_EXPORT_MNGR, CTM_IMPORT_MNGR FROM CUSTOMER WHERE CTM_CD = '" & JobClient & "'"
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then 
				JobManager = GetLong(.fields("CTM_SALESMNGR"))
				if JobType = gsImport then
					JobOperator = GetLong(.fields("CTM_IMPORT_MNGR"))
				else
					JobOperator = GetLong(.fields("CTM_EXPORT_MNGR"))
				end if
			end if
			.Close
			if GetLong(JobManager) = 0 then JobManager = WebUserID
			if GetLong(JobOperator) = 0 then JobOperator = WebUserID
		end with
		
		if msg <> "" then
			ShowMessage msg
		else
			JobInit = gsInitial & Num2Code(year(date)-2000) & Num2Code(Month(date)) & JobType
			
			Set cmdSQL = Server.CreateObject("ADODB.Command")
			Set cmdSQL.ActiveConnection = Conn
			cmdSQL.CommandType = 4
			cmdSQL.CommandText = "DB_CTM_NEW_JOB"
			cmdSQL.Parameters.Refresh
			cmdSQL.Parameters("@JobInit").Value = JobInit
			cmdSQL.Execute
			NewCode = JobInit & right("0000" & GetLong(cmdSQL.Parameters("@MaxID").Value),5)
			
			'�ި̫��JobBroker�ǉ��K�{
			strSql = "INSERT TBL_CTM_JOB (JobCode, JobBelong, JobClient, JobShipper, JobCountry, POLN, POL, PODN, POD"
			strSql = strSql & ",Vessel, Voy, ETD, ETA, MBL, HBL, JobNo, EdaNo, Quantity, Package, Container, Marks"
			strSql = strSql & ",GW, CBM, RTON, Commodity, CustomBroker, JobSalesman, JobOperator,  Creater, Created)"
			strSql = strSql & " VALUES ('" & NewCode & "','O','" & JobClient & "','" & JobClient & "','" & JobCountry & "'"
			strSql = strSql & ",'" & POLN & "','" & POL & "','" & PODN & "','" & POD & "','" & FitSel(Vessel) & "','" & Voy & "'"
			strSql = strSql & ",'" & ETD & "','" & ETA & "','" & MBL & "','" & HBL & "','" & JobCode & "','" & SubCode & "'," & Quantity
			strSql = strSql & ",'" & Package & "','" & FitSel(Container) & "','" & FitSel(Marks) & "'," & GW & "," & CBM & "," & RTON
			strSql = strSql & ",'" & FitSel(Commodity) & "','" & gsDummy & "'," & JobManager & "," & JobOperator & "," & WebUserID & ", GETDATE())"
			Conn.Execute strSql
			
			response.redirect "CustomsEdit.asp?JobCode=" & NewCode
		end if
	end if
%>

<%
function FitXmlString(myStr)
dim buf
	buf = GetString(myStr)
	FitXmlString = replace(buf, "��", "&")
end function
%>