<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
on error resume next

dim cnt
dim jobno
dim cstmid
dim refercd

	filepath = "http://localhost/prealertup/xml/"
	
	set HttpXML = server.CreateObject("MSXML2.XMLHTTP")
	HttpXML.open "GET", filepath & session("UserLogonID") & "/" & request("f"), False
	HttpXML.send
	CleanXML = HttpXML.responseStream

	Set objDoc = Server.CreateObject("Msxml2.DOMDocument")
	objDoc.async = false
	objDoc.Load(CleanXML)

	set objRoot = objDoc.documentElement
	If objRoot Is Nothing Then
		response.redirect "UploadXml.asp?mode=1"
	else
		set objNode = objRoot.selectSingleNode("//prealert")
		If objNode Is Nothing Then
			response.redirect "UploadXml.asp?mode=1"
		else
			refercd = ","
			errflag = 0
		
			OpenSQL Conn, SqlServerName, DataBaseName
			Set Recset = Server.CreateObject ("ADODB.Recordset")
			with Recset
				StrSql = "SELECT ID FROM _PreAlertUser WHERE SUBSTRING(LogonID, 1, 3) = 'CLS'"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				do while not .eof
					refercd = refercd & GetString(.fields("ID")) & ","
					.movenext
				loop
				.close
			end with
							
			cnt = 0				
			Conn.BeginTrans
				
			set objDataList = objRoot.ChildNodes
			For Each objRecord In objDataList
				set objField = objRecord.selectSingleNode("jobno")
				jobno = GetPost(objField.text)
				
				set objField = objRecord.selectSingleNode("refercd")
				cstmid = GetLong(objField.text)			
				if instr(refercd, "," & cstmid & ",") > 0  then
					
					with Recset
						StrSql = "SELECT * FROM _PREALERT WHERE ReferNo = '" & jobno & "'"
						.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
						if .eof then
							.addnew
							.fields("Partner") = Session("UserID")
							.fields("CreateID") = Session("UserID")
						else
							if GetString(.fields("ETA")) = "" then
								set objField = objRecord.selectSingleNode("eta")
								.fields("ETA") = Date2Str(objField.text)
							end if
						end if
						
						.fields("Customer") = cstmid
						.fields("ReferNo") = jobno
						.fields("ReadFlag") = 0						
						
						set objField = objRecord.selectSingleNode("shipper")
						.fields("Shipper") = GetPost(objField.text)						
						set objField = objRecord.selectSingleNode("consignee")
						.fields("Consignee") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("notify")
						.fields("Notify") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("vessel")
						.fields("Vessel") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("voy")
						.fields("Voy") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("carrier")
						.fields("Carrier") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("pol")
						.fields("POL") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("pod")
						.fields("POD") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("etd")
						.fields("ETD") = Date2Str(objField.text)
						set objField = objRecord.selectSingleNode("po")
						.fields("PONO") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("tt")
						.fields("TradeTerms") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("hbl")
						.fields("HBL") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("commodity")
						.fields("Commodity") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("qty")
						.fields("Quantity") = GetDouble(objField.text)
						set objField = objRecord.selectSingleNode("pkg")
						.fields("Package") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("gw")
						.fields("GW") = GetDouble(objField.text)
						set objField = objRecord.selectSingleNode("cbm")
						.fields("CBM") = GetDouble(objField.text)
						set objField = objRecord.selectSingleNode("type")
						.fields("Pattern") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("spec")
						.fields("SpecHandle") = GetPost(objField.text)
						set objField = objRecord.selectSingleNode("mark")
						.fields("Mark") = replace(GetPost(objField.text), "@@", vbcrlf)
						if .fields("Mark") = "" then .fields("Mark") = "N/M"
						
						.fields("UpdateID") = Session("UserID")
						.fields("UpdateDate") = now
						.update
						.close
					end with
					
					if err.number <> 0 then exit for						
				else
					errflag = 1
					exit for
				end if
				
				cnt = cnt + 1	
			next
			
			if err.number <> 0 then
				Conn.RollbackTrans
				response.redirect "UploadXml.asp?mode=2&jobno=" & jobno
			elseif errflag = 1 then
				Conn.RollbackTrans
				response.redirect "UploadXml.asp?mode=3&jobno=" & jobno
			else
				Conn.CommitTrans
				response.redirect "UploadXml.asp?mode=8&cnt=" & cnt
			end if
		End If
	End If
%>