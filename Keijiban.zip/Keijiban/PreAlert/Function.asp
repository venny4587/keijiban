<%
dim conn
dim strsql
dim recset
dim i
dim j

Function GetPost(myData)
on error resume next
dim buf
	GetPost = "ERROR"
	buf = lcase(GetString(myData))
	if instr(buf, " ") = 0 then
	   	GetPost = GetString(myData)
	elseif instr(buf, "exec") = 0 and _
	   instr(buf, "update") = 0 and _
	   instr(buf, "insert") = 0 and _
	   instr(buf, "delete") = 0 and _
	   instr(buf, "script") = 0 then
	   	GetPost = GetString(myData)
	end if
End Function

function FitSel(myData)
dim buf
	buf = GetString(myData)
	FitSel = replace(buf, "'", "''")
end function
	
function Str2Date(myData)
	Str2Date = mid(myData,1,4) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2YMD(myData)
	Str2YMD = mid(myData,3,2) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2MD(myData)
	if trim(myData & "") <> "" then	Str2MD = mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Date2Str(myData)
dim dt
	Date2Str = ""
	if not isDate(myData) then exit function
	dt = cdate(myData)
	Date2Str = year(dt) & right("00" & month(dt),2) & right("00" & day(dt),2) 
end function 

'formatDate
function formatDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDate = ""
		exit function
	end if		
	formatDate = year(myDate) & gsDateSign & right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function

'formatShortDate
function formatShortDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatShortDate = ""
		exit function
	end if
	formatShortDate = right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function


'formatDateTime
function FmtDateTime(myDate)
on error resume next
	FmtDateTime = ""
	if isdate(myDate) then
		FmtDateTime = year(myDate) & gsDateSign & _
					  right("00" & month(myDate),2) & gsDateSign & _
					  right("00" & day(myDate),2) & " " & _
					  right("00" & hour(myDate),2) & ":" & _
					  right("00" & minute(myDate),2)
	end if
end function

function FmtTime(myDate)
on error resume next
	FmtTime = ""
	if isdate(myDate) then
		FmtTime = year(myDate) & gsDateSign & _
					  month(myDate) & gsDateSign & _
					  day(myDate) & " " & _
					  hour(myDate) & ":" & _
					  minute(myDate)
	end if
end function

Function GetNewKeyID(myConn, myTable, myField)
on error resume next
dim myRec
dim mySql
	mySql = ""	
	set myRec = server.CreateObject("adodb.recordset") 
	with myRec
		mySql = mySql & "SELECT Top 1 " & myField
		mySql = mySql & "  FROM " & myTable
		mySql = mySql & " ORDER BY " & myField & " DESC"
		.Open mySql, myConn, adOpenKeyset, adLockReadOnly 
		if .EOF then
			GetNewKeyID = 1
		else
			GetNewKeyID = GetLong(.Fields(0)) + 1
		end if
		.Close 
	end with	
	set myRec = nothing		
End Function

Function GetCurrentPage(myConn, table, field, myType, data, sWhere)
dim myRec
dim mySql
	GetCurrentPage = 0
	if myType = 1 then data = "'" & data & "'"	
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT Count(" & field & ") FROM "& table & _
				" WHERE " & field & " < " & data & sWhere
		.Open mySql, myConn, adOpenKeyset , adLockOptimistic
		GetCurrentPage = (CLng (.Fields(0)) \ lngPageSize) + 1
		.Close
	end with
	set myRec = Nothing
end Function

Function CheckDBRepeat(myConn, table, field, data, myType, keyfield, key)
dim myRec
dim mySql
	if myType = 1 then data = "'" & data & "'"
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT " & field & " FROM " & table & _
				" WHERE QDEL = 0" & _
				" AND " & field & " = " & data
		if key <> 0 then mySql = mySql & " AND " & keyfield & " <> " & key
		.Open mySql, myConn, adOpenKeyset , adLockOptimistic
		if .eof then
			CheckDBRepeat = false
		else
			CheckDBRepeat = true
		end if
		.Close
	end with
	set myRec = Nothing
end Function

Sub ShowMessage(myMsg)
	Response.Write ("<HTML><SCRIPT LANGUAGE=JavaScript>alert(" & chr(34) & myMsg & chr(34) & ");window.history.back();</SCRIPT></HTML>")
	Response.End 
End Sub

Function GetLong(myData)
on error resume next
	GetLong = 0
	if isnumeric(myData) then
		GetLong = clng(myData)
	end if
End Function

Function GetDouble(myData)
on error resume next
	GetDouble = 0
	'if isnumeric(myData) then
		GetDouble = cdbl(myData)
	'end if
End Function

Function GetString(myData)
on error resume next
	GetString = trim(cstr(myData & ""))
End Function

Function ResetString(myStr)
on error resume next
	ResetString = replace(myStr, "'", "''")
End Function

Function ResetBoolean(myBln)
on error resume next
	if myBln = true then
		ResetBoolean = 1
	else
		ResetBoolean = 0
	end if
End Function

function ShowDateTimeFmt(myDate)
on error resume next
	ShowDateTimeFmt = ""
	if isdate(myDate) then
		ShowDateTimeFmt = year(myDate) & gsDateSign & _
					    right("00" & month(myDate),2) & gsDateSign & _
					    right("00" & day(myDate),2) & " " & _
					    right("00" & hour(myDate),2) & ":" & _
					    right("00" & minute(myDate),2)
	end if
end function

function ShowDateTimeShort(myDate)
on error resume next
	ShowDateTimeShort = ""
	if isdate(myDate) then
		ShowDateTimeShort = right("00" & month(myDate),2) & gsDateSign & _
					    	right("00" & day(myDate),2) & " " & _
					    	right("00" & hour(myDate),2) & ":" & _
					    	right("00" & minute(myDate),2)
	end if
end function

function GetMonthLastDay(dt)
on error resume next

	GetMonthLastDay = ""

	if not isdate(dt) then exit function
	
	if len(dt) = 10 then
		y = left(dt,4)
		m = mid(dt,6,2)
		tpDate = dateAdd("m",1,y & gsDateSign & m & gsDateSign & "01")			
		GetMonthLastDay = dateAdd("d",-1,tpDate)
	end if

end function

function stringCut(myStr,myLen)
on error resume next
	stringCut = trim(myStr & "")
	if len(stringCut) > myLen then
		stringCut = left(stringCut,myLen) & "..."
	end if	
end function

function ShowTitle(myStr,myLen)
on error resume next	
	ShowTitle = trim(myStr & "")
	if len(ShowTitle) > myLen then
		ShowTitle = " title='" & stringReset(ShowTitle) & "'"
	else
		ShowTitle = ""
	end if
end function

function stringReset(myStr)
on error resume next	
	stringReset = replace(myStr, "'", "�f")
end function

function GetClientIP()
	GetClientIP = request.servervariables("HTTP_X_FORWARDED_FOR")
	if GetClientIP = "" then
		GetClientIP = request.servervariables("REMOTE_ADDR")
	end if
end function

function formatDateEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateEng = ""
		exit function
	end if
	formatDateEng = GetDayEng(day(myDate)) & " " & GetMonthEng(month(myDate)) & ", " & year(myDate)
end function

function formatDateShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateShortEng = ""
		exit function
	end if
	formatDateShortEng = GetDayEng(day(myDate)) & " " & GetMonthEng(month(myDate))
end function

function ShowDateTimeShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		ShowDateTimeShortEng = ""
		exit function
	end if
	ShowDateTimeShortEng = GetDayEng(day(myDate)) & " " & GetMonthEng(month(myDate)) & ", " & _
					       right("00" & hour(myDate),2) & ":" & right("00" & minute(myDate),2)
end function

function GetDayEng(myNo)
	select case myNo
	case 1, 21, 31:		GetDayEng = right("  " & myNo, 2) & "st"
	case 2, 22:			GetDayEng = right("  " & myNo, 2) & "nd"
	case 3, 23:			GetDayEng = right("  " & myNo, 2) & "rd"
	case else:			GetDayEng = right("  " & myNo, 2) & "th"
	end select
end function

function GetMonthEng(myNo)
	select case myNo
	case 1:		GetMonthEng = "Jan"
	case 2:		GetMonthEng = "Feb"
	case 3:		GetMonthEng = "Mar"
	case 4:		GetMonthEng = "Apr"
	case 5:		GetMonthEng = "May"
	case 6:		GetMonthEng = "Jun"
	case 7:		GetMonthEng = "Jul"
	case 8:		GetMonthEng = "Aug"
	case 9:		GetMonthEng = "Sep"
	case 10:	GetMonthEng = "Oct"
	case 11:	GetMonthEng = "Nov"
	case 12:	GetMonthEng = "Dec"
	end select
end function
%>