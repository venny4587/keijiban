<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim ID
dim lngCount
dim lngPageNumber
dim myPageSize
dim strSubmit

	myPageSize = 15

	lngPageNumber = GetLong(request("p"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	OpenSQL Conn, SqlServerName, DataBaseName
	Set Recset = Server.CreateObject ("ADODB.Recordset")
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<TITLE>Guest Book</TITLE>	
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "GuestBook.asp?p=<%=lngPageNumber%>&id=" + cd;
		}
				
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
	<SCRIPT LANGUAGE="VBScript">		
		Sub ConfirmDelete(lngID)
			If msgbox("Are you sure to delete it now ?", 289, "Confirm Message") = 1 Then
				window.location.href = "GuestBook0.asp?p=<%=lngPageNumber%>&id=" & lngID
			End If
		End Sub
	</SCRIPT>
	<style>
		.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; }
		.pt9b { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; font-weight:bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 14px; LINE-HEIGHT: 16px; BORDER-RIGHT: #808080 1px solid; BORDER-TOP: #808080 1px solid; BORDER-LEFT: #808080 1px solid; BORDER-BOTTOM: #808080 1px solid;}
	</style>
</HEAD>

<body topmargin=0 leftmargin=0 OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>

	<TABLE width=100% CELLPADDING=0 CELLSPACING=0 class=pt9>
		<TR><TD width=90% VALIGN=TOP align=center>
<%						
		strSQL = "SELECT top 100 GID, Title, Body, Reply, CreateDate, ReplyDate "
		strSQL = strSQL + " FROM _GuestBook WHERE LogonUser = '" & Session("UserLogonID") & "'"
		strSQL = strSQL + " ORDER BY GID DESC"
		Recset.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		With Recset
			.PageSize = myPageSize
			lngPageCount = .PageCount 

			'�y�[�W��\������
			If lngPageCount > 1 Then
				Response.Write ("<B>PAGE</B> ")
				For lngCount = 1 To lngPageCount
					If lngCount = lngPageNumber Then
						Response.Write (lngCount & " ")
					Else
						Response.Write ("<A HREF=" & Chr(34) & "GuestBook2.asp?p=" & lngCount & Chr(34) & ">" & lngCount & "</A> ")
					End If
				Next
			else
				Response.Write ("<br> ")							
			End If
		End With
						
		if not recset.EOF then	
			lngCount = 0
			With Recset
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize
%>
			<table width=96% class=pt9>
				<TR height=20 ALIGN=center bgcolor=#808080 style="color:white; font-weight:bold">
					<TD width=15% nowrap>Date</TD>
					<TD width=20% nowrap>Title</TD>
					<TD width=30% nowrap>Body</TD>
					<TD width=30% nowrap>Reply</TD>
					<TD width=5% nowrap><br></TD>
				</TR>
<%
							
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						myTitle = GetString(.Fields("Title"))
						myBody = GetString(.Fields("Body"))
						myReply = GetString(.Fields("Reply"))
%>
				<TR height=20 style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("GID")%>')">
					<TD nowrap ALIGN="center"><%=ShowDateTimeShort(.Fields("CreateDate"))%><BR></TD>
					<TD nowrap ALIGN="left" <%=ShowTitle(myTitle, 15)%>><%=StringCut(myTitle,15)%><BR></TD>
					<TD nowrap ALIGN="left" <%=ShowTitle(myBody, 25)%>><%=StringCut(myBody,25)%><BR></TD>
					<TD nowrap ALIGN="left" <%=ShowTitle(myReply, 25)%>><%=StringCut(myReply,25)%><BR></TD>
					<TD ALIGN=CENTER><%if not isnull(.Fields ("ReplyDate")) then%><IMG SRC=img/check.jpg BORDER=0><%end if%><BR></TD>
				</TR>
				<TR height=5><TD colspan=9 background=img/line.jpg></TD></TR>
<%
						.MoveNext
					End If
				Loop
			End With
%>
			</TABLE>
<%
		else
			Response.Write "<br><div align=center>No record found. </div>"	
		end if
		recset.Close 
%>
</td></TR></TABLE>

</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
		
%>

