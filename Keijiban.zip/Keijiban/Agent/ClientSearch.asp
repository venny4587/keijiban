<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
dim pic
dim mode
dim selCode

	pic = GetLong(request("pic"))
	myCode = replace(GetPost(request("cd")), "��", "&")
	selCode = replace(myCode, "'", "''")
	
	OpenSQL Conn, SqlServerName, DataBaseName
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	CTM_CD = ""
	if myCode <> "" then
		with Recset	
			StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_SEA_SALES, CTM_NOMINATE FROM CUSTOMER"
			StrSql = StrSql & " WHERE CTM_DELETED = 0 AND CTM_CD = '" & selCode & "'"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				CTM_CD = GetString(.fields("CTM_CD"))
				CTM_ENAME = GetString(.fields("CTM_ENAME"))
				CTM_NOMINATE = GetLong(.fields("CTM_NOMINATE"))
				.movenext
				if not .eof then CTM_CD = ""
			end if
			.close
		end with
	end if

	if CTM_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
	if (window.opener.frmInput.JobClient != null) window.opener.frmInput.JobClient.value = "<%=CTM_CD%>";
	if (window.opener.frmInput.Client != null) window.opener.frmInput.Client.value = "<%=CTM_ENAME%>";
	if (window.opener.frmInput.NeedSales != null) window.opener.frmInput.NeedSales.checked = <%=CTM_NOMINATE%>;
	if (window.opener.frmInput.JobNotify != null) window.opener.frmInput.JobNotify.focus();
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<TITLE>Consignee Search</TITLE>
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "ClientSearch.asp?cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("Please input part of the consignee's name")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="ClientSearch.asp" NAME=frmInput>
		<input type=hidden name="mode" value="<%=mode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD nowrap>�@Consignee :<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=20 onkeydown="ResetEnter()">
					<INPUT TYPE=button style="cursor:hand; width:80; height:25" VALUE="Search" onclick="DoSearch()">
					 Start from<input type=checkbox name="part" value="1" onkeydown="ResetEnter()" <%if part = 0 then response.write "checked"%>>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then
			With Recset
				StrSql = "SELECT CTM_CD, CTM_REF, CTM_ENAME, CTM_NAME FROM CUSTOMER WHERE CTM_DELETED = 0 AND CTM_CD LIKE 'CLS%'"
				if part then 
					StrSql = StrSql & " AND CTM_ENAME LIKE '%" & selCode & "%'"
				else
					StrSql = StrSql & " AND CTM_ENAME LIKE '" & selCode & "%'"
				end if
				StrSql = StrSql & " ORDER BY CTM_ENAME"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>Company Name
					<TD nowrap>Code
<%
					myCnt = 0
					mySelect = ""
					myShortCut = ""
					Do Until .EOF	
						myCnt = myCnt + 1
						if myCnt > 35 then
							response.write "<tr><td colspan=5 class=pt9r>��������܂�..."
							exit do
						else
							mySelect = GetString(.Fields("CTM_CD"))
							myEName = GetString(.Fields("CTM_ENAME"))
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & mySelect & "');"
							if myCnt < 10 then myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & mySelect & "');"
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=mySelect%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap <%=ShowTitle(myEName, 40)%>><%=StringCut(myEName,40)%><BR>
					<TD class=line nowrap><%=mySelect%><BR>
<%
						end if
						.MoveNext
					Loop
%>
			</table>
<%
				else
					response.write "<font class=pt9r>There is no record found.</font>"
				end if	
				.Close 
			End With
		end if
		if cnt = 1 then response.write "<script language=javascript>clickLine('" & mySelect & "');</script>"
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>