<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	OpenSQL Conn, SqlServerAgent, DataBaseAgent
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	ID = GetLong(request("ID"))
	if ID = 0 then
		POLN = Session("PIC_POS")
		POL = Session("PIC_DPT")
		PODN = "JPOSA"
		POD = "OSAKA"
		Package = "CARTONS"
		JobNotify = "SAME AS CONSIGNEE"
		
		NO = GetLong(request("NO"))
		with Recset
			StrSql = "SELECT * FROM TBL_REC WHERE ID = " & NO
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				JobNo = GetString(.fields("JobNo"))
				JobShipment = GetLong(.fields("Shipment"))
				Vessel = GetString(.fields("Vessel"))
				Voy = GetString(.fields("Voy"))
				POLN = GetString(.fields("POLN"))
				POL = GetString(.fields("POL"))
				PODN = GetString(.fields("PODN"))
				POD = GetString(.fields("POD"))
				ETD = Str2Date(.fields("ETD"))
				ETA = Str2Date(.fields("ETA"))
				Container = GetString(.fields("Container"))
				Broker = GetString(.fields("Broker"))
			end if
			.close
		end with
	else
	
		with Recset
			StrSql = "SELECT * FROM TBL_REC WHERE ID = " & ID
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				JobNo = GetString(.fields("JobNo"))
				JobShipment = GetLong(.fields("Shipment"))
				JobCountry = GetString(.fields("Country"))
				JobClient = GetString(.fields("JobClient"))
				JobPartner = GetString(.fields("Partner"))
				JobShipper = GetString(.fields("Shipper"))
				JobNotify = GetString(.fields("Notify"))
				Consignee = GetString(.fields("Consignee"))
				NeedSales = GetLong(.fields("Nomination"))
				
				Size20 = GetLong(.fields("Size20"))
				Size40 = GetLong(.fields("Size40"))
				Type20 = GetString(.fields("Type20"))
				Type40 = GetString(.fields("Type40"))
				Vessel = GetString(.fields("Vessel"))
				Voy = GetString(.fields("Voy"))
				POLN = GetString(.fields("POLN"))
				POL = GetString(.fields("POL"))
				PODN = GetString(.fields("PODN"))
				POD = GetString(.fields("POD"))
				ETD = Str2Date(.fields("ETD"))
				ETA = Str2Date(.fields("ETA"))
				MBL = GetString(.fields("MBL"))
				HBL = GetString(.fields("HBL"))
				GW = GetDouble(.fields("GW"))
				CBM = GetDouble(.fields("CBM"))
				Commodity = GetString(.fields("Commodity"))
				Quantity = GetDouble(.fields("Quantity"))
				Package = GetString(.fields("Package"))
				Telex = GetLong(.fields("Telex"))
				Container = GetString(.fields("Container"))
				Marks = GetString(.fields("Marks"))
				Broker = GetString(.fields("Broker"))
				CarrierCorp = GetString(.fields("CarrierCorp"))
				Remarks = GetString(.fields("Remarks"))
				
				OverFlag = GetLong(.fields("OverFlag"))
				Created = FmtDateTime(.fields("Created"))
				Updated = FmtDateTime(.fields("Updated"))
				Locked = FmtDateTime(.fields("Locked"))
				Imported = FmtDateTime(.fields("Imported"))
				JobCode = GetString(.fields("JobCode"))
				Memo = GetString(.fields("Memo"))
				
				CreditUSD = GetDouble(.fields("CreditUSD"))
				CreditJPY = GetLong(.fields("CreditJPY"))
				DebitUSD = GetDouble(.fields("DebitUSD"))
				DebitJPY = GetLong(.fields("DebitJPY"))
			end if
			.close
		end with
	end if
	
	CloseDB Conn
%>
<html>
<head>
	<title>Detail Information</title>
	<META http-equiv="Content-Type" content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<SCRIPT language=Javascript src="css/calendar_EN.js"></SCRIPT>
	<script language=vbscript src="css/function.vbs"></script>
	<script language=vbscript>
	<!--
		sub DoCopy()
		dim win
			set win = window.open("AgentCopy.asp?JobNo=<%=JobNo%>","AgentCopy","resizable=0,StatusBar=0,scrollbars=1,width=500,height=300")
			win.focus()
		end sub
		
		sub DoSave(mode)
		dim buf
			for each obj in frmInput.elements
				if obj.type = "text" then obj.value = ucase(obj.value)
			next
			if checkText("JobNo","Job Number", 1) = false then exit sub
			if checkText("JobClient","Consignee", 0) = false then exit sub
			if checkText("Consignee","Consignee", mode) = false then exit sub
			if checkText("JobShipper","Shipper", mode) = false then exit sub
			if checkText("JobNotify","Notify", mode) = false then exit sub
			
			if checkText("Vessel","Vessel", mode) = false then exit sub
			if checkText("Voy","Voy", mode) = false then exit sub
			if checkText("POLN","POL",mode) = false then exit sub
			if checkText("POL","POL",mode) = false then exit sub
			if checkText("PODN","POD",mode) = false then exit sub
			if checkText("POD","POD",mode) = false then exit sub
			if checkDate("ETD","ETD", mode) = false then exit sub
			if trim(frmInput.ETD.value) <> "" then
				buf = CDate(frmInput.ETD.value)
				if abs(datediff("d", buf, date)) > 15 then
					frmInput.ETD.focus()
					if msgbox ("ETD is out of date limit, are you sure ?",289, "�m�F���b�Z�[�W") <> 1 then exit sub
				end if
			end if
			if checkDate("ETA","ETA", 0) = false then exit sub
			if checkText("MBL","MBL", 0) = false then exit sub
			if checkText("HBL","HBL", 0) = false then exit sub
			if checkNum("Size20","20'", 0) = false then exit sub
			if checkNum("Size40","40'", 0) = false then exit sub
			if checkText("Commodity","Commodity", mode) = false then exit sub
			if checkDouble("Quantity","Quantity", mode) = false then exit sub
			if checkText("Package","Package", mode) = false then exit sub
			if checkDouble("GW","Gross Weight", mode) = false then exit sub
			if checkDouble("CBM","Measurement", mode) = false then exit sub
			if checkText("CarrierCorp","Carrier Corp", 0) = false then exit sub
			if checkText("Container","Container Info.", 0) = false then exit sub
			if checkLen("Container","Container Info.", 255) = false then exit sub
			if checkText("Marks","Marks", 0) = false then exit sub
			if checkLen("Marks","Marks", 500) = false then exit sub
			
			if mode = 1 then
				buf = 0
				buf = buf + GetLong(frmInput.DebitJPY.value) 
				buf = buf + GetLong(frmInput.CreditJPY.value) 
				buf = buf + GetDouble(frmInput.DebitUSD.value) 
				buf = buf + GetDouble(frmInput.CreditUSD.value) 
				if buf = 0 then
					if msgbox("The Debit & Credit hasn't been inputed, is this OK ?",<%=gsMsgButton%>, "Confirm") <> 1 then exit sub
				end if
				if msgbox("Are you sure to lock this record ?",<%=gsMsgButton%>, "Confirm") <> 1 then exit sub
				frmInput.btnLock.disabled = true
			else
				frmInput.btnSave.disabled = true
			end if
			frmInput.mode.value = mode
			frmInput.submit()
		end sub
				
		sub DoDelete()
			if msgbox("Are you sure to delete this record ?", <%=gsMsgButton%>, "Confirm") <> 1 then exit sub
			frmInput.btnDelete.disabled = true
			frmInput.mode.value = -1
			frmInput.submit()
		end sub
		
		sub DoUnlock()
			if msgbox("Are you sure to unlock this record ?", <%=gsMsgButton%>, "Confirm") <> 1 then exit sub
			frmInput.btnUnlock.disabled = true
			frmInput.mode.value = -2
			frmInput.submit()
		end sub
		
		sub DoSearch()
		dim win, buf
			buf = replace(frmInput.Client.value, "&", "��")
			set win = window.open("ClientSearch.asp?cd=" & buf, "ClientSearch", "resizable=0,StatusBar=0,scrollbars=1,width=600,height=500")
			win.focus()
		end sub
		
		sub PortSearch(mode)
			dim win, param
			if mode = 0 then
				param = "?mode=0&cd=" & frmInput.POLCD.value & "&nm=" & frmInput.POL.value
			else
				param = "?mode=1&cd=" & frmInput.PODCD.value & "&nm=" & frmInput.POD.value
			end if
			set win = window.open("PortSearch.asp" & param,"PortSearch","resizable=0,StatusBar=0,scrollbars=1,width=360,height=300")
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=27 then window.close()
			if window.event.keyCode=119 then call DoSave(1)
			if window.event.keyCode=120 then call DoSave(0)
		end sub
		
		sub DebitJPY_OnBlur()
			frmInput.DebitJPY.value = FitZero(formatnumber(GetLong(frmInput.DebitJPY.value),0,true))
		end sub
		sub CreditJPY_OnBlur()
			frmInput.CreditJPY.value = FitZero(formatnumber(GetLong(frmInput.CreditJPY.value),0,true))
		end sub
		sub DebitUSD_OnBlur()
			frmInput.DebitUSD.value = FitZero(formatnumber(GetDouble(frmInput.DebitUSD.value),2,true))
		end sub
		sub CreditUSD_OnBlur()
			frmInput.CreditUSD.value = FitZero(formatnumber(GetDouble(frmInput.CreditUSD.value),2,true))
		end sub
		
		sub Quantity_OnBlur()
			frmInput.Quantity.value = FitZero(formatnumber(GetDouble(frmInput.Quantity.value),3,true))
		end sub
		sub Package_OnBlur()
			frmInput.Package.value = ucase(frmInput.Package.value)
		end sub		
		sub GW_OnBlur()
			frmInput.GW.value = FitZero(formatnumber(GetDouble(frmInput.GW.value),3,true))
		end sub
		sub CBM_OnBlur()
			frmInput.CBM.value = FitZero(formatnumber(GetDouble(frmInput.CBM.value),3,true))
		end sub
		sub ETD_OnBlur()
			frmInput.ETD.value = setdate(frmInput.ETD.value)
		end sub
		sub ETA_OnBlur()
			frmInput.ETA.value = setdate(frmInput.ETA.value)
		end sub
		
		sub InitForm()
<%if ID = 0 then%>
			frmInput.JobNo.focus()
<%elseif Locked <> "" then%>
			frmInput.btnClose.focus()
<%else%>
			frmInput.btnLock.focus()
<%end if%>
		end sub
	//-->
	</script>
</head>
<body topmargin=20 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<form name="frmInput" action="AgentSave.asp" method=post>
  <INPUT TYPE="HIDDEN" NAME="ID" VALUE="<%=ID%>">
  <INPUT TYPE="HIDDEN" NAME="mode" VALUE="0">
  <table width=560 Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
	<tr><td class=pt9n>[*] DETAIL INFOMATION
		<td align=right><%if ID <> 0 then%><img style="cursor:hand" src=img/copy.jpg alt="Copy" onmousedown="DoCopy()"><%end if%>
	<tr><td colspan=2><hr width=100% size=1 color=blue>
	<tr><td colspan=2>
	  <table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
		<tr><td><table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
			<tr height=25>
				<td>JOB NUMBER<input class=si name="JobNo" size=20 maxlength=50 value="<%=JobNo%>" onkeydown="ResetEnter()">
					SHIPMENT&nbsp;<select name="JobShipment" onkeydown="ResetEnter()"><%=ShowShipmentList(JobShipment)%></select>
			<tr height=25>
				<td>SHIPPER&nbsp;<input class=si name="JobShipper" value="<%=JobShipper%>" size=45 maxlength=100 onkeydown="ResetEnter()">
			<tr height=25>
				<td>CONSIGNEE<input type=hidden name="JobClient" value="<%=JobClient%>">
					<input class=si name="Client" value="<%=Consignee%>" size=40 maxlength=100 onkeydown="ResetEnter()">
					<a href="javascript:DoSearch()"><img src=img/search.jpg border=0 alt="Search"></a>
			<tr height=25>
				<td>NOTIFY &nbsp;<input class=si name="JobNotify" value="<%=JobNotify%>" size=45 maxlength=100 onkeydown="ResetEnter()">
		  </table>
		<td><table width=98% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
			<tr height=25>
				<td><font class=pt9b>Debit USD</font>&nbsp;
					<input class=sn name="CreditUSD" value="<%=FitZero(formatnumber(CreditUSD,2,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">
			<tr height=25>
				<td><font class=pt9b>Debit JPY</font>&nbsp;
					<input class=sn name="CreditJPY" value="<%=FitZero(formatnumber(CreditJPY,0,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">
			<tr height=25>
				<td><font class=pt9r>Credit USD</font>
					<input class=sn name="DebitUSD" value="<%=FitZero(formatnumber(DebitUSD,2,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">
			<tr height=25>
				<td><font class=pt9r>Credit JPY</font>
					<input class=sn name="DebitJPY" value="<%=FitZero(formatnumber(DebitJPY,0,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">
		  </table>
		</table>
	<tr><td width=50% valign=top>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
		  <TR height=25>
			<TD>POL&nbsp;<input type=hidden name="POLN" value="<%=POLN%>">
						<input class=si name="POLCD" size=8 maxlength=10 value="<%=mid(POLN, 3)%>" onkeydown="ResetEnter()">
						<a href="javascript:PortSearch(0)"><img src=img/search.jpg border=0 alt="Search"></a>
						<input class=si name="POL" value="<%=POL%>" Maxlength=50 size=20 onkeydown="ResetEnter()" readonly>
			<td nowrap class=pt9r><%=chkPOL%><br>
		  <TR height=25>
			<TD>POD&nbsp;<input type=hidden name="PODN" value="<%=PODN%>">
						<input class=si name="PODCD" size=8 maxlength=10 value="<%=mid(PODN, 3)%>" onkeydown="ResetEnter()">
						<a href="javascript:PortSearch(1)"><img src=img/search.jpg border=0 alt="Search"></a>
						<input class=si name="POD" value="<%=POD%>" Maxlength=50 size=20 onkeydown="ResetEnter()" readonly>
			<td nowrap class=pt9r><%=chkPOD%><br>
		  <TR height=25>
		  	<TD>VESSEL <input class=si name="Vessel" size=16 maxlength=50 value="<%=Vessel%>" onkeydown="ResetEnter()">
				VOY <input class=si name="Voy" size=6 maxlength=20 value="<%=Voy%>" onkeydown="ResetEnter()">
		  <TR height=25>
			<TD>ETD <input class=si name="ETD" size=9 maxlength=10 value="<%=ETD%>" onkeydown="ResetEnter()" onclick="setday(this)">
				&nbsp;&nbsp;ETA <input class=si name="ETA" size=9 maxlength=10 value="<%=ETA%>" onkeydown="ResetEnter()" onclick="setday(this)">
		  <TR height=25>
		  	<TD>MBL <input class=si name="MBL" size=20 maxlength=50 value="<%=MBL%>" onkeydown="ResetEnter()">
				20'x<input class=sn name="Size20" size=1 maxlength=2 value="<%=Size20%>" onkeydown="ResetEnter()">
					<select class=pt9n name="Type20" onkeydown="ResetEnter()"><%=ShowContainerList(Type20)%></select>
		  <TR height=25>
		  	<TD>HBL <input class=si name="HBL" size=20 maxlength=50 value="<%=HBL%>" onkeydown="ResetEnter()">
				40'x<input class=sn name="Size40" size=1 maxlength=2 value="<%=Size40%>" onkeydown="ResetEnter()">
					<select class=pt9n name="Type40" onkeydown="ResetEnter()"><%=ShowContainerList(Type40)%></select>
		  <TR height=25>
		  	<TD>COMMODITY<input class=si name="Commodity" size=30 maxlength=50 value="<%=Commodity%>" onkeydown="ResetEnter()">
		  <TR height=25>
		  	<TD>QUANTITY <input class=sn name="Quantity" value="<%=FitZero(formatnumber(Quantity,3,true))%>" size=7 maxlength=8 OnKeyDown="ResetEnter()">
				P'KGS <input class=si name="Package" value="<%=Package%>" size=15 maxlength=50 OnKeyDown="ResetEnter()">
		  <TR height=25>
		  	<TD>WEIGHT <input class=sn name="GW" value="<%=FitZero(formatnumber(GW,3,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">&nbsp;KGS
				&nbsp;&nbsp;NOMINATION<input type=CheckBox name="NeedSales" value="1" onkeydown="ResetEnter()" <%if NeedSales then response.write "checked"%>>
		  <TR height=25>
		  	<TD>MEASURE <input class=sn name="CBM" value="<%=FitZero(formatnumber(CBM,3,true))%>" size=9 maxlength=10 OnKeyDown="ResetEnter()">&nbsp;M<sup>3</sup>
				&nbsp;&nbsp;TELEX <input type=checkbox name="Telex" value="1" onkeydown="ResetEnter()" <%if Telex then response.write "checked"%>>
		  <TR height=25>
		  	<TD>BROKER <input class=si name="Broker" value="<%=Broker%>" size=12 maxlength=20 OnKeyDown="ResetEnter()">
				&nbsp;&nbsp;CARRIER <input class=si name="CARRIER" value="<%=CARRIER%>" size=10 maxlength=20 OnKeyDown="ResetEnter()">
		</table>
	  <td width=50% valign=top>
		<table width=100% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
		  <TR height=25>
		  <TR height=25>
		  	<TD valign=top><br>CONTAINER<TD><br><textarea style="ime-mode:disabled" name="Container" rows=5 wrap=off style="width:200"><%=Container%></textarea>
		  <TR height=25>
			<TD valign=top><br>&nbsp;&nbsp;MARKS.<TD><br><textarea style="ime-mode:disabled" name="Marks" rows=9 wrap=off style="width:200"><%=Marks%></textarea>
		</table>
	<tr height=25><td colspan=2 valign=top>
		DC MEMO <input class=si name="Memo" value="<%=Memo%>" size=81 maxlength=100 OnKeyDown="ResetEnter()">
	<tr height=25><td colspan=2 valign=top>
		REMARKS <input class=si name="Remarks" value="<%=Remarks%>" size=81 maxlength=100 OnKeyDown="ResetEnter()">
  </table>
  <table width=560 class=pt9 border=0>
		<tr><td colspan=3><hr width=100% size=1 color=blue></td></tr>
		<tr><td><%if ID <> 0 AND Locked = "" then%>
				<input type=button name=btnDelete class=pt9r style="cursor:hand; width:90; height:30; color:red" value="DELETE" onclick="DoDelete()">
				<%end if%>
			<td><%if ID <> 0 then%>
					CREATED <font class=pt9n><%=Created%></font>�@<%if Locked <> "" then%>LOCKED�@<font class=pt9n><%=Locked%></font><%end if%>
					<%if JobCode <> "" then%><br><br><font class=pt12g>CORP NO: </font><font class=pt12n><%=JobCode%></font><%end if%>
				<%end if%>
			<td align=right>
			<%if Locked <> "" then%>
				<%if OverFlag = 0 then%>
				<input type=button name=btnUnLock class=pt9b style="cursor:hand; width:90; height:30; color:red" value="UNLOCK" onclick="DoUnlock()">
				<%end if%>
				<input type=button name=btnClose class=pt9n style="cursor:hand; width:90; height:30" value="CLOSE" onclick="window.close()">
			<%else%>
				<%if ID = 0 then%>
				<input type=checkbox name="continue" value="1" onkeydown="ResetEnter()">Continue�@
				<%end if%>
				<input type=button name=btnLock class=pt9b style="cursor:hand; width:90; height:30; color:blue" value="F8:LOCK" onclick="DoSave(1)">
				<input type=button name=btnSave class=pt9n style="cursor:hand; width:90; height:30" value="F9:SAVE" onclick="DoSave(0)">
			<%end if%>
	</table>
</form>
</body>
</html>

<%
function ShowShipmentList(myDft)
dim buf
	buf = ""
	buf = buf & "<option value=1"
	if myDft = 1 then buf = buf & " selected"
	buf = buf & ">FCL"
	
	buf = buf & "<option value=2"
	if myDft = 2 then buf = buf & " selected"
	buf = buf & ">LOOSE"
	
	buf = buf & "<option value=3"
	if myDft = 3 then buf = buf & " selected"
	buf = buf & ">LCL"
	
	buf = buf & "<option value=4"
	if myDft = 4 then buf = buf & " selected"
	buf = buf & ">CONSOLI"
	
	buf = buf & "<option value=5"
	if myDft = 5 then buf = buf & " selected"
	buf = buf & ">AIR"
	
	ShowShipmentList = buf
end function

function ShowContainerList(myDft)
	buf = ""
	buf = buf & "<option value=GP"
	if myDft = "GP" then buf = buf & " selected"
	buf = buf & ">GP"
	
	buf = buf & "<option value=GP"
	if myDft = "OT" then buf = buf & " selected"
	buf = buf & ">OT"
	
	buf = buf & "<option value=GP"
	if myDft = "HQ" then buf = buf & " selected"
	buf = buf & ">HQ"
	
	buf = buf & "<option value=GP"
	if myDft = "RF" then buf = buf & " selected"
	buf = buf & ">RF"
	
	buf = buf & "<option value=GP"
	if myDft = "TN" then buf = buf & " selected"
	buf = buf & ">TN"
	
	ShowContainerList = buf
end function
%>