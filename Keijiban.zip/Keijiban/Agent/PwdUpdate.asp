<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'On Error Resume Next

dim hitFlag
dim myPrePwd
dim myNewPwd
dim myPwdCon

hitFlag = 2
myPrePwd = request("pwdCurrent")
myNewPwd = request("password")
myPwdCon = request("pwdConfirm")

OpenSQL Conn, SqlServerName, DataBaseName
Set Recset = Server.CreateObject ("ADODB.Recordset")
with Recset
	strSql = "SELECT CTM_CD, PIC_PWD FROM CTM_PIC WHERE PIC_UID = '" & Session("UserLogonID") & "'"
	.Open strSql, Conn, adOpenKeyset , adLockOptimistic 
	if not .EOF then
		if myPrePwd = cstr(.Fields("PIC_PWD") & "") then
			hitFlag = 1
			.Fields("PIC_PWD") = myNewPwd
		end if
	end if
	.Update
	.Close
end with
set Recset = nothing
CloseDB Conn

Response.redirect "Password.asp?mode=" & hitFlag
%>
