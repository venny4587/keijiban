<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim JobNo

	OpenSQL Conn, SqlServerAgent, DataBaseAgent
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	JobNo = GetPost(request("JobNo"))
	mode = GetLong(request("mode"))
	if mode = 0 then
		with Recset
			strSQL = "SELECT * FROM TBL_REC WHERE JobNo = '" & JobNo & "'"
			.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
			if not .eof then
				Shipment = GetLong(.fields("Shipment"))
				JobClient = GetString(.fields("JobClient"))
				Consignee = GetString(.fields("Consignee"))
				Shipper = GetString(.fields("Shipper"))
				Notify = GetString(.fields("Notify"))
				Broker = GetString(.fields("Broker"))
				CarrierCorp = GetString(.fields("CarrierCorp"))
				
				Vessel = GetString(.fields("Vessel"))
				Voy = GetString(.fields("Voy"))
				POL = GetString(.fields("POL"))
				POD = GetString(.fields("POD"))
				POLN = GetString(.fields("POLN"))
				PODN = GetString(.fields("PODN"))
				ETD = Str2Date(.fields("ETD"))
				ETA = Str2Date(.fields("ETA"))
				MBL = GetString(.fields("MBL"))
				HBL = GetString(.fields("HBL"))
			else
				msg = "There is no record found."
			end if
		end with
		
		if msg <> "" then 
			ShowMessage msg
		else
%>
<html>
<HEAD>
	<TITLE>Job �� Copy</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<SCRIPT language=vbscript src="css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DataSave()
			if msgbox ("�R�s�[���Ă�낵���ł����B",<%=gsMsgButton%>, "�m�F���b�Z�[�W") = 1 then
				frmInput.submit()
			end if
		end sub
		
		sub DoShortCut()
			if window.event.keyCode=120 then 
				call DataSave() 
			elseif window.event.keyCode=27 then 
				window.close()
			end if
		end sub
		
		sub InitForm()
			frmInput.CopyCount.focus()
		end sub
	</SCRIPT>
</Head>
<body topmargin=10 class=pt9 onload="InitForm()" onkeydown="DoShortCut()" <%=gsBodyControl%>>
<center>
  <FORM NAME="frmInput" action="FreightCopy.asp" method="post">
  	<input type=hidden name="mode" value="1">
	<input type=hidden name="POLN" value="<%=POLN%>">
	<input type=hidden name="PODN" value="<%=PODN%>">
	<input type=hidden name="MBL" value="<%=MBL%>">
	<input type=hidden name="HBL" value="<%=HBL%>">
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9n>
	  <TR><td width=100%>��Job ���R�s�[���s&nbsp;
	</table>
	<hr width=96% size=1>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
	  <TR height=24>
	  	<TD>POL <input class=si name="POL" size=12 maxlength=50 value="<%=POL%>" onkeydown="ResetEnter()" readonly>
			POD <input class=si name="POD" size=12 maxlength=50 value="<%=POD%>" onkeydown="ResetEnter()" readonly>
		�@�@ETD <input class=si name="ETD" size=10 maxlength=10 value="<%=ETD%>" onkeydown="ResetEnter()" readonly>
			ETA <input class=si name="ETA" size=10 maxlength=10 value="<%=ETA%>" onkeydown="ResetEnter()" readonly>
	  <TR height=24>
		<TD>VESSEL <input class=si name="Vessel" size=20 maxlength=50 value="<%=Vessel%>" onkeydown="ResetEnter()" readonly>
			VOY <input class=si name="Voy" size=10 maxlength=20 value="<%=Voy%>" onkeydown="ResetEnter()" readonly>
		�@�@SHIPMENT <input type=hidden name="JobShipment" value="<%=JobShipment%>">
		�@�@<input class=si name="Shipment" size=10 maxlength=20 value="<%=JobShip(JobShipment)%>" onkeydown="ResetEnter()" readonly>
	</table>
	<br>
	<table width=96% Border=0 Cellspacing=0 CellPadding=0 class=pt9g>
	  <TR height=24>
		<TD class=pt9n nowrap>SHIPPER
			<input class=si name="Shipper" value="<%=Shipper%>" size=50 maxlength=100 onkeydown="ResetEnter()">
	  <TR height=24>
		<TD class=pt9n nowrap>CONSIGNEE<input type=hidden name="JobClient" value="<%=JobClient%>">
			<input class=si name="Client" value="<%=Consignee%>" size=50 maxlength=100 value="" onkeydown="ResetEnter()">
			<a href="javascript:DoSearch(0)"><img src=img/search.jpg border=0 alt="����"></a>
	  <TR height=24>
		<TD class=pt9n nowrap>NOTIFY
			<input class=si name="Notify" value="<%=Notify%>" size=50 maxlength=100 onkeydown="ResetEnter()">
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=24>
		<TD>BROKER <input class=si name="Broker" value="<%=Broker%>" onkeydown="ResetEnter()" size=30 readonly>
			COPY TO <select name="CopyCount" onkeydown="ResetEnter()"><%for i = 1 to 9%><option value="<%=i%>"><%=i%><%next%></select>
	  <TR>
	  	<TD><img src=img/spacer.gif height=3>
	  <TR height=40>
		<TD class=pt9r>
			<input type=checkbox name="CopyAll" value="1">COPY ALL
			<input class=pt9b type=button style="width:100;height:30" name=btnCreate value="F9:COPY" onclick="DataSave()">�@�@
			<input class=pt9n type=button style="width:100;height:30" name=btnClose value="CLOSE" onclick="window.close()">
	</table>
  </FORM>
<center>
</body></html>
<%
		end if
		
	else
	
		JobShipment = GetLong(request("JobShipment"))
		JobClient = GetPost(request("JobClient"))
		Shipper = GetPost(request("Shipper"))
		Notify = GetPost(request("Notify"))
		Broker = GetPost(request("Broker"))
		
		JobCountry = GetPost(request("JobCountry"))
		Vessel = GetPost(request("Vessel"))
		Voy = GetPost(request("Voy"))
		POL = GetPost(request("POL"))
		POD = GetPost(request("POD"))
		POLN = GetPost(request("POLN"))
		PODN = GetPost(request("PODN"))
		ETD = Date2Str(request("ETD"))
		ETA = Date2Str(request("ETA"))
		MBL = GetPost(request("MBL"))
		HBL = GetPost(request("HBL"))
		
		CarrierCorp = GetPost(request("CarrierCorp"))
		CopyCount = GetLong(request("CopyCount"))
		
		if msg <> "" then 
			ShowMessage msg
		else
		
			strFld = "":						strVal = ""
			strFld = strFld & ",JobBelong":		strVal = strVal & ",'" & JobBelong & "'"
			strFld = strFld & ",JobClient":		strVal = strVal & ",'" & FitSel(JobClient) & "'"
			strFld = strFld & ",JobShipper":	strVal = strVal & ",'" & FitSel(JobShipper) & "'"
			strFld = strFld & ",JobShipment":	strVal = strVal & ",'" & FitSel(JobShipment) & "'"
			strFld = strFld & ",JobType":		strVal = strVal & ",'" & FitSel(JobType) & "'"
			strFld = strFld & ",JobCountry":	strVal = strVal & ",'" & FitSel(JobCountry) & "'"
			strFld = strFld & ",POL":			strVal = strVal & ",'" & FitSel(POL) & "'"
			strFld = strFld & ",POLN":			strVal = strVal & ",'" & FitSel(POLN) & "'"
			strFld = strFld & ",POD":			strVal = strVal & ",'" & FitSel(POD) & "'"
			strFld = strFld & ",PODN":			strVal = strVal & ",'" & FitSel(PODN) & "'"
			strFld = strFld & ",Vessel":		strVal = strVal & ",'" & FitSel(Vessel) & "'"
			strFld = strFld & ",Voy":			strVal = strVal & ",'" & FitSel(Voy) & "'"
			strFld = strFld & ",ETD":			strVal = strVal & ",'" & FitSel(ETD) & "'"
			strFld = strFld & ",ETA":			strVal = strVal & ",'" & FitSel(ETA) & "'"
			strFld = strFld & ",MBL":			strVal = strVal & ",'" & FitSel(MBL) & "'"
			strFld = strFld & ",HBL":			strVal = strVal & ",'" & FitSel(HBL) & "'"
			strFld = strFld & ",JobBroker":	strVal = strVal & ",'" & FitSel(JobBroker) & "'"
			strFld = strFld & ",JobSalesman":	strVal = strVal & "," & GetLong(JobSalesman)
			
			if GetLong(request("CopyAll")) <> 0 then
				with Recset
					strSQL = "SELECT * FROM TBL_REC WHERE Deleted = 0 AND JobNo = '" & JobNo & "'"
					.Open strSQL, Conn, adOpenKeyset , adLockOptimistic 
					if not .eof then
						strFld = strFld & ",Commodity":		strVal = strVal & ",'" & FitSel(.fields("Commodity")) & "'"
						strFld = strFld & ",Quantity":		strVal = strVal & "," & GetDouble(.fields("Quantity"))
						strFld = strFld & ",Package":		strVal = strVal & ",'" & FitSel(.fields("Package")) & "'"
						strFld = strFld & ",GW":			strVal = strVal & "," & GetDouble(.fields("GW"))
						strFld = strFld & ",CBM":			strVal = strVal & "," & GetDouble(.fields("CBM"))
						strFld = strFld & ",RTON":			strVal = strVal & "," & GetDouble(.fields("RTON"))
						strFld = strFld & ",Marks":			strVal = strVal & ",'" & FitSel(.fields("Marks")) & "'"
						strFld = strFld & ",Container":		strVal = strVal & ",'" & FitSel(.fields("Container")) & "'"
						strFld = strFld & ",InvoiceNo":		strVal = strVal & ",'" & FitSel(.fields("InvoiceNo")) & "'"
						strFld = strFld & ",ReferNo":		strVal = strVal & ",'" & FitSel(.fields("ReferNo")) & "'"			
						strFld = strFld & ",Size20":		strVal = strVal & ",'" & FitSel(.fields("Size20")) & "'"
						strFld = strFld & ",Size40":		strVal = strVal & ",'" & FitSel(.fields("Size40")) & "'"
						
						strFld = strFld & ",Telex":			strVal = strVal & "," & GetLong(.fields("Telex"))
						strFld = strFld & ",FarAway":		strVal = strVal & "," & GetLong(.fields("FarAway"))
						strFld = strFld & ",DoConfirm":		strVal = strVal & "," & GetLong(.fields("DoConfirm"))
						strFld = strFld & ",JobManager":	strVal = strVal & "," & GetLong(.fields("JobManager"))
						
					end if
					.Close
				end with
			end if
			
			Conn.BeginTrans
			
			for i = 1 to CopyCount
				strSql = "INSERT TBL_REC (JobNo" & strFld & ") VALUES ('" & JobNo & "'" & strVal & ")"
if WebUserID = gsAdmin then response.write strSql
				Conn.Execute strSql
				
				msg = msg & """ & vbcrlf & """ & JobCode
				if err.number <> 0 then exit for
			next
			
			if err.number <> 0 then
				Conn.RollbackTrans
				ShowMessage "There is error during copy." & err.number & ":" & err.description
			else
				Conn.CommitTrans
%>
<html>
<script language=vbscript>
	msgbox "The following Job No. has been copied�F<%=msg%>", 64, "Confirm"
	window.close()
</script>
</html>
<%
			end if
		end if 
	end if	

	Set Recset = nothing
	CloseDB Conn
%>
