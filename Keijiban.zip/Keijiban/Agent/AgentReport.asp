<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	
	OpenSQL Conn, SqlServerAgent, DataBaseAgent
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	mySort = GetLong(request("sort"))
	
	Broker = GetString(request("Broker"))
	SelYear = GetLong(request("SelYear"))
	SelMonth = GetLong(request("SelMonth"))
	if SelYear = 0 or SelMonth = 0 then
		SelDate = date
		if day(SelDate) <= gsSysCloseDay then 
			SelDate = dateadd("m", -1, selDate)		'���ߑO�͑O��
		end if
		SelYear = year(SelDate)
		SelMonth = month(SelDate)
	end if	
	AccountMonth = SelYear & right("00" & SelMonth, 2)
%>

<HTML>
<HEAD>
	<TITLE>AGENT MONTHLY REPORT</TITLE>	
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<script language=vbscript src="css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>	
		sub DoSort(myNo)
			frmInput.sort.value = myNo
			frmInput.Submit()
		end sub
		
		sub InitForm()
			frmInput.btnSearch.focus()
		end sub
	</SCRIPT>
</HEAD>

<BODY leftmargin=0 topmargin=0 class=pt9n onload="InitForm()" <%=gsBodyControl%>>
	<FORM METHOD="POST" ACTION="AgentReport.asp" ID=frmInput NAME=frmInput>
		<input type=hidden name="sort" value="<%=mySort%>">
		<table class=pt9>
			<TR><TD nowrap>BROKER
					<select name="Broker" onkeydown="ResetEnter()"><%=ShowBrokerList(Broker)%></select>&nbsp;
				<TD nowrap>MONTH
					<select name="SelYear" onkeydown="ResetEnter()"><%
						for i = year(date) to year(gsSysStart) step -1
							response.write "<option value=" & i
							if i = SelYear then response.write " selected"
							response.write ">" & i
						next%></select>&nbsp;/
					<select name="SelMonth" onkeydown="ResetEnter()"><%
						for i = 1 to 12
							response.write "<option value=" & i
							if i = SelMonth then response.write " selected"
							response.write ">" & i
						next%></select>&nbsp;
				<TD nowrap><INPUT class=pt9n style="width:70px;height:25px;" TYPE=SUBMIT name=btnSearch VALUE="Search">
					<INPUT class=pt9n style="width:70px;height:25px;" TYPE=button name=btnCopy VALUE="Copy" onclick="DoCopy('list')">	
		</table>
	</form>
<div id=list>
<%=GetMonth(SelMonth)%>. <%=SelYear%>
	<table cellpadding=1 cellspacing=0 border=1 class=pt9n width=100%>
		<colgroup span=9 align=left>
		<colgroup span=2 align=right style="color:blue">
		<colgroup span=2 align=right style="color:red">
		<TR style="cursor:hand;">
			<TD>��
			<TD onmousedown="DoSort(0)" <%if mySort=0 then%>style="color:blue"<%end if%>>JobNo
			<TD onmousedown="DoSort(1)" <%if mySort=1 then%>style="color:blue"<%end if%>>Broker
			<TD >Shipment
			<TD onmousedown="DoSort(2)" <%if mySort=2 then%>style="color:blue"<%end if%>>Vessel
			<TD>Voy
			<TD onmousedown="DoSort(3)" <%if mySort=3 then%>style="color:blue"<%end if%>>MBL
			<TD onmousedown="DoSort(4)" <%if mySort=4 then%>style="color:blue"<%end if%>>HBL
			<TD onmousedown="DoSort(5)" <%if mySort=5 then%>style="color:blue"<%end if%>>ETD
			<TD>DebitUSD
			<TD>DebitJPY
			<TD>CreditUSD
			<TD>>CreditJPY
<%
	cnt = 0
	sumDebitUSD = 0
	sumDebitJPY = 0
	sumCreditUSD = 0
	sumCreditJPY = 0
	with recset
		strSql = "SELECT JobNo, Broker, Shipment, Vessel, Voy, MBL, HBL, ETD, Memo"
		strSql = strSql & ", CreditUSD, CreditJPY, DebitUSD, DebitJPY FROM TBL_REC"
		strSql = strSql & " WHERE Deleted = 0 AND LEFT(ETD, 6) = '" & AccountMonth & "'"
		if Broker <> "" then strSql = strSql & " AND Broker = '" & FitSel(Broker) & "'" 
		select case mySort
		case 0:		strSql = strSql & " ORDER BY JobNo"
		case 1:		strSql = strSql & " ORDER BY Broker"
		case 2:		strSql = strSql & " ORDER BY Vessel"
		case 3:		strSql = strSql & " ORDER BY MBL"
		case 4:		strSql = strSql & " ORDER BY HBL"
		case 5:		strSql = strSql & " ORDER BY ETD"
		end select
if WebUserID = gsAdmin then response.write strSQL
		.Open strSql, Conn, adOpenStatic, adLockReadOnly
		do while not .EOF
			cnt = cnt + 1
%>
		<TR><TD><%=cnt%>
			<TD nowrap><%=GetString(.Fields("JobNo"))%>
			<TD nowrap><%=GetString(.Fields("Broker"))%><br>
			<TD nowrap><%=JobShip(.Fields("Shipment"))%>
			<TD nowrap><%=GetString(.Fields("Vessel"))%><br>
			<TD nowrap><%=GetString(.Fields("Voy"))%><br>
			<TD nowrap><%=GetString(.Fields("MBL"))%><br>
			<TD nowrap><%=GetString(.Fields("HBL"))%><br>
			<TD nowrap><%=ShowETD(.Fields("ETD"))%><br>
			<TD><%=ShowUSD(.Fields("CreditUSD"))%>
			<TD><%=ShowJPY(.Fields("CreditJPY"))%>
			<TD><%=ShowUSD(.Fields("DebitUSD"))%>
			<TD><%=ShowJPY(.Fields("DebitJPY"))%>
<%
			sumCreditUSD = sumCreditUSD + GetDouble(.Fields("CreditUSD"))
			sumCreditJPY = sumCreditJPY + GetLong(.Fields("CreditJPY"))
			sumDebitUSD = sumDebitUSD + GetDouble(.Fields("DebitUSD"))
			sumDebitJPY = sumDebitJPY + GetLong(.Fields("DebitJPY"))
			.movenext
		loop
		.Close
	end with
	if cnt > 0 then
		sumUSD = sumCreditUSD - sumDebitUSD
		sumJPY = sumCreditJPY - sumDebitJPY
%>
		<TR><TD colspan=2 align=center>TOTAL
			<TD colspan=6 align=center>USD:<%=formatnumber(sumUSD, 2, true)%> / JPY:<%=formatnumber(sumJPY, 0, true)%>
			<TD nowrap><br>
			<TD nowrap><%=formatnumber(sumCreditUSD, 2, true)%>
			<TD nowrap><%=formatnumber(sumCreditJPY, 0, true)%>
			<TD nowrap><%=formatnumber(sumDebitUSD, 2, true)%>
			<TD nowrap><%=formatnumber(sumDebitJPY, 0, true)%>
<%end if%>
	</TABLE>
</div>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowBrokerList(myDft)
dim mySql
dim myRec
dim buf
	buf = "<option value="""">--ALL--"
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT DISTINCT Broker FROM TBL_REC ORDER BY BROKER"
		.Open mySql, Conn, adOpenStatic, adLockReadOnly
		do while not .EOF
			buf = buf & "<option value=""" & GetString(.fields("Broker")) & """"
			if myDft = GetString(.fields("Broker")) then buf = buf & " selected"
			buf = buf & ">" & GetString(.fields("Broker"))
			.movenext
		loop
		.Close
	end with
	set myRec = nothing
	ShowBrokerList = buf
end function

function ShowETD(myETD)
dim buf
	buf = GetString(myETD)
	if buf <> "" then
		buf = Str2Date(buf)
		ShowETD = month(buf) & "/" & day(buf)
	end if
end function

function ShowUSD(myUSD)
dim buf
	buf = GetDouble(myUSD)
	if buf = 0 then
		ShowUSD = "<br>"
	else
		ShowUSD = formatnumber(myUSD, 2, true)
	end if
end function

function ShowJPY(myJPY)
dim buf
	buf = GetLong(myJPY)
	if buf = 0 then
		ShowJPY = "<br>"
	else
		ShowJPY = formatnumber(myJPY, 0, true)
	end if
end function
%>