<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
	ID = GetLong(request("ID"))
	mode = GetLong(request("mode"))
	
	OpenSQL Conn, SqlServerAgent, DataBaseAgent
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	if mode = -1 then
	
		Conn.execute "DELETE FROM TBL_REC WHERE ID = " & ID
%>
<html>
	<script language=javascript>
		alert("This record has been deleted !");
		window.close();
		if (window.opener.frmInput != null) window.opener.frmInput.submit();
	</script>
</html>
<%
	elseif mode = -2 then
	
		with Recset
			StrSql = "SELECT ID FROM TBL_REC WHERE OverFlag <> 0 AND ID = " & ID
			.Open strSQL, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then msg = "This job number has already been imported."
			.close
		end with
		
		if msg <> "" then
			ShowMessage msg
		else
			Conn.execute "UPDATE TBL_REC SET Locked = NULL WHERE ID = " & ID
%>
<html>
	<script language=javascript>
		alert("This record has been unlocked !");
		window.location.href = "AgentEdit.asp?ID=<%=ID%>";
		if (window.opener.frmInput != null) window.opener.frmInput.submit();
	</script>
</html>
<%
		end if
	else
		msg = ""
		with Recset
			StrSql = "SELECT ID FROM TBL_REC WHERE ID <> " & ID
			StrSql = StrSql & " AND JobNo = '" & GetPost(Request("JobNo")) & "'"
			.Open strSQL, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then msg = "This job number is already exist."
			.close
		end with
		
		if msg <> "" then
			ShowMessage msg
		else
			with Recset
				StrSql = "SELECT * FROM TBL_REC WHERE ID = " & ID
				.Open strSQL, Conn, adOpenKeyset , adLockOptimistic
				if .eof then
					.AddNew
					.fields("Partner") = Session("UserCorp")
					.fields("Country") = Session("PIC_CD")
				end if
				.fields("JobNo") = GetPost(Request("JobNo"))
				.fields("Shipment") = GetLong(Request("JobShipment"))
				.fields("JobClient") = GetCtmCode(Request("Client"), 1)
				.fields("Consignee") = GetPost(Request("Client"))
				.fields("Shipper") = GetPost(Request("JobShipper"))
				.fields("Notify") = GetPost(Request("JobNotify"))
				
				.fields("POLN") = GetPost(Request("POLN"))
				.fields("POL") = GetPost(Request("POL"))
				.fields("PODN") = GetPost(Request("PODN"))
				.fields("POD") = GetPost(Request("POD"))
				.fields("ETD") = Date2Str(Request("ETD"))
				.fields("ETA") = Date2Str(Request("ETA"))
				.fields("Size20") = GetLong(Request("Size20"))
				.fields("Type20") = GetPost(Request("Type20"))
				.fields("Size40") = GetLong(Request("Size40"))
				.fields("Type40") = GetPost(Request("Type40"))
				
				.fields("Vessel") = GetPost(Request("Vessel"))
				.fields("Voy") = GetPost(Request("Voy"))
				.fields("MBL") = GetPost(Request("MBL"))
				.fields("HBL") = GetPost(Request("HBL"))
				.fields("Commodity") = GetPost(Request("Commodity"))
				.fields("Quantity") = GetLong(Request("Quantity"))
				.fields("Package") = GetPost(Request("Package"))
				.fields("GW") = GetDouble(Request("GW"))
				.fields("CBM") = GetDouble(Request("CBM"))
				.fields("Telex") = GetLong(Request("Telex"))
				.fields("Nomination") = GetLong(Request("NeedSales"))
				.fields("Broker") = GetPost(Request("Broker"))
				.fields("CarrierCorp") = GetPost(Request("CarrierCorp"))
				
				.fields("Container") = GetPost(Request("Container"))
				.fields("Marks") = GetPost(Request("Marks"))
				.fields("DebitJPY") = GetLong(Request("DebitJPY"))
				.fields("CreditJPY") = GetLong(Request("CreditJPY"))
				.fields("DebitUSD") = GetDouble(Request("DebitUSD"))
				.fields("CreditUSD") = GetDouble(Request("CreditUSD"))
				
				.fields("Memo") = GetPost(Request("Memo"))
				.fields("Remarks") = GetPost(Request("Remarks"))
				if mode then .fields("Locked") = now
				.fields("Updated") = now
				.update
				.close
				
				if ID = 0 then
					StrSql = "SELECT MAX(ID) AS MAXID FROM TBL_REC"
					.Open strSQL, Conn, adOpenKeyset , adLockReadOnly
					if not .eof then ID = GetLong(.fields("MAXID"))
					.close
				end if
			end with
			
			if mode then
				msg = "This record has been locked !"
			else
				msg = "This record has been saved !"
			end if
%>
<html>
	<script language=javascript>
		alert("<%=msg%>");
		if (window.opener != null) {
			window.close();
			window.opener.frmInput.submit();
		} else {
<%if GetLong(request("Continue")) then%>
			window.location.href = "AgentEdit.asp?NO=<%=ID%>";
<%else%>
			window.location.href = "AgentEdit.asp";
<%end if%>
		}
	</script>
</html>
<%
		end if
	end if
	set Recset = nothing
	CloseDB Conn
%>