<!--#include file="DBConst.asp"-->
<!--#include file="clsDBLogAccess.asp"-->
<%
	Dim blnTimeOut
	Dim objDBLogAccess
	Dim dtmTotalTime
	Dim strTitle
	Dim myDefaultASP
	
	Session("SqlServerName") = "SERVER"
	Session("DataBaseName") = "BROKER"
	
	If Request.QueryString ("TimeOut") = 1 Then
		blnTimeOut = True
		strTitle = "Time Out"
	Else
		blnTimeOut = False
		strTitle = "Log Off"
	End If
		
	If Not blnTimeOut Then
		'LogAccess �� LogOffTime ����������
		Set objDBLogAccess = New clsDBLogAccess
		With objDBLogAccess
			.UpdateLogOffTimeByAccessID Session("LogAccessID")
			dtmTotalTime = CDate(.LogOffTime - .Added)
		End With
		Set objDBLogAccess = Nothing
	End If
	
%>
<HTML>
	<HEAD>
		<TITLE> AGENT'S PRIVATE SYSTEM</TITLE>
		<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<style>	
			.pt9 { FONT-FAMILY: Arial; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; font-weight: bold }	
			.pt12 { FONT-FAMILY: Arial; FONT-SIZE: 12pt; LINE-HEIGHT: 12pt; font-weight: bold }
		</style>
	</HEAD>
	<BODY OnContextmenu="return false">
		<FONT class=pt12>
			<CENTER>
				<BR><BR><BR>
<%If blnTimeOut Then%>
				You have been time out of our system ! Please log on again. 
<%Else%>
				You have successfully logged off our system !
				<BR><BR><BR>
				<img src=img/end.gif>
				<BR><BR><BR>
				<FONT class=pt9>You have been used our system for <%=Hour(dtmTotalTime) & ":" & right("00" & Minute(dtmTotalTime), 2) & ":" & right("00" & Second(dtmTotalTime), 2)%></FONT>
<%End If%>
				<BR><BR><BR>
			</CENTER>
		</FONT>
	</BODY>
</HTML>
<%
	Session.Abandon ()
%>