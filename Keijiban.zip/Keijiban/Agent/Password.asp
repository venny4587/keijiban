<!-- #include file="common.asp" -->
<!-- #include file="function.asp" -->
<%
	dim mode
	mode = GetLong(Request("Mode"))
%>
<html>
<head>
	<title>PASSWORD CHANGE</title>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<style>	
		.pt9t { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #404040; font-weight: bold }
		.pt9b { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #0000FF; font-weight: bold }
		.pt9r { FONT-FAMILY: Century Gothic; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt; color: #FF0000; font-weight: bold }
		.pt12 { FONT-FAMILY: Century Gothic; FONT-SIZE: 12pt; LINE-HEIGHT: 13pt; color: #404040 }	
		.so{ime-mode:disabled; FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10px; BACKGROUND: #C0C0C0; BORDER-RIGHT: #C0C0C0 1px solid; BORDER-TOP: #C0C0C0 1px solid; BORDER-LEFT: #C0C0C0 1px solid; BORDER-BOTTOM: #C0C0C0 1px solid;}
	</style>
	<SCRIPT LANGUAGE="JavaScript">
<!--
	function ResetEnter() {
		if (event.keyCode == 13) {
			window.event.keyCode = 9;
		}
	}
	
	function CheckInput() {
		usernamenull.innerHTML =  "";
		pwdnull.innerHTML =  "";
		pwdCfmnull.innerHTML =  "";
		if (frmInput.pwdCurrent.value == "") {
			frmInput.pwdCurrent.focus();
			usernamenull.innerHTML =  "Please input current password.";
		} else {
			if (frmInput.password.value == "") {
				frmInput.password.focus();				
				pwdnull.innerHTML =  "Please input new password.";
			} else {
				if (frmInput.pwdConfirm.value == "") {
					frmInput.pwdConfirm.focus();
					pwdCfmnull.innerHTML =  "Please input confirm password.";			
				}else{
					if (frmInput.password.value != frmInput.pwdConfirm.value) {
						frmInput.pwdConfirm.focus();
						pwdCfmnull.innerHTML =  "Confirm password is not correct.";
					}
					else{
						frmInput.submit();
					}
				}
			}
		}
	}
//-->
</SCRIPT>
</head>

<body OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
	<center>
		<form name="frmInput" action="PwdUpdate.asp" method=post>
			<input type=hidden name="mode" value="<%=mode%>">
			
			<TABLE width=96%>
				<TR valign=middle><TD>			      
					<TABLE width=300 bgcolor=#F0F0F0 class=pt9t>
				  		<TR align=center height=40>
				  			<TD colspan=2><font color=blue>C</font>hange Logon Password</TD>
						</TR>
				  		<TR><TD colspan=2><hr></TD></TR>
				  		<TR height=30>
				  			<TD width=140 align=right>Current Password</TD>
							<TD width=160 align=center>
								<input class=so style="height:20;width:120" type="password" name="pwdCurrent" maxlength=20 size=15 OnKeyDown="ResetEnter()"></TD>
						</TR>
				  		<TR height=30>
				  			<TD align=right>New Password</TD>
							<TD align=center>
								<input class=so style="height:20;width:120" type="password" name="password" maxlength=20 size=15 OnKeyDown="ResetEnter()"></TD>
						</TR>
				  		<TR height=30>
				  			<TD align=right>Confirm Password</TD>
							<TD align=center>
								<input class=so style="height:20;width:120" type="password" name="pwdConfirm" maxlength=20 size=15 OnKeyDown="ResetEnter()"></TD>
						</TR>
				  		<TR><TD colspan=2><hr></TD></TR>
<%
	if mode > 0 then 
%>
				  		<TR><TD colspan=2 class=pt12 align=center><%
							if mode = 1 then 
								response.write "<font class=pt9b>Your password has been changed successfully !</font>"
							else
								response.write "<font class=pt9r>The inputed current password is incorrect !</font>"
							end if
							%></TD></TR>
				  		<TR><TD colspan=2><hr></TD></TR>
<%
	end if 
%>
				  		<TR align=center height=40>
				  			<TD colspan=2><input type="button" style="width:90px;height:30px;" value="OK" onclick="CheckInput()"></TD>
						</TR>
					</TABLE>
				</TD><TD valign=top>
					<TABLE width=250 border=0 class=pt9b>
				  		<TR align=center height=50><TD colspan=2><br></TD></TR>
						<TR height=30 valign=center><TD>&nbsp;<div name="usernamenull" id="usernamenull"></div></td></TR>
						<TR height=30 valign=center><TD>&nbsp;<div name="pwdnull" id="pwdnull"></td></TR>
						<TR height=30 valign=center><TD>&nbsp;<div name="pwdCfmnull" id="pwdCfmnull"></td></TR>
					</TABLE>
				</TD></TR>
			</TABLE>
		</form>
	</center>
</body>
</html>
