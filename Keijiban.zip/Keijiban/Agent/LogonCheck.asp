<!-- #include file="DBConst.asp" -->
<!-- #include file="clsDBLogAccess.asp" -->
<%
'On Error Resume Next

dim checkflag
dim GetUserID
dim GetPassWord
dim LogAccessID

Session("SqlServerName") = "SERVER"
Session("DataBaseName") = "BROKER"

checkflag = 0
GetUserID = request("userid")
GetPassWord = request("password")
LogAccessID = request("LogAccessID")

if GetUserID <> "" AND  GetPassWord <> "" then
	OpenSQL Conn, "127.0.0.1", "SAMPLE-CORP"
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	with Recset
		strSql = "SELECT P.*, C.CTM_ENAME FROM CTM_PIC AS P INNER JOIN CUSTOMER AS C"
		strSql = strSql & " ON P.CTM_CD = C.CTM_CD WHERE PIC_UID = '" & GetUserID & "'"
		.Open strSql, Conn, adOpenKeyset, adLockReadOnly
		if not .EOF then
			if 	GetPassWord = cstr(.Fields("PIC_PWD") & "") then
				checkflag = 1
				Session("UserLogonID") = GetUserID
				Session("UserID") = clng(.Fields("PIC_ID"))
				Session("UserName") = cstr(.Fields("CTM_ENAME"))
				Session("UserCorp") = cstr(.Fields("CTM_CD") & "")
				Session("PIC_NAME") = cstr(.fields("PIC_NAME") & "")
				Session("PIC_CD") = cstr(.fields("PIC_CD") & "")
				Session("PIC_DPT") = cstr(.fields("PIC_DPT") & "")
				Session("PIC_POS") = cstr(.fields("PIC_POS") & "")
				Session("PIC_TEL") = cstr(.fields("PIC_TEL") & "")
				Session("PIC_FAX") = cstr(.fields("PIC_FAX") & "")
				IP_ADDR = cstr(.Fields("PIC_REMARKS") & "")
			end if
		end if
		.Close
	end with
	set Recset = nothing
	CloseDB Conn
end if

if checkflag = 1 then

	Response.Cookies("TEST_UserID") = GetUserID
	Response.Cookies("TEST_UserID").Expires = #January 01, 2010# 
	Response.Cookies("TEST_Password") = GetPassWord
	Response.Cookies("TEST_Password").Expires = #January 01, 2010# 

	'LogAccess �� UserID ��������
	Set objDBLogAccess = New clsDBLogAccess
	objDBLogAccess.UpdateUserIDByAccessID LogAccessID, Session("UserID"), GetUserID
	Set objDBLogAccess = Nothing
	
	Session("LogAccessID") = LogAccessID
	response.redirect "agentmain.asp"
else
	Response.redirect "logon.asp"
end if
%>
