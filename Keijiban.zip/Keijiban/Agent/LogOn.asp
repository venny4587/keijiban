<!-- #include file="dbconst.asp" -->
<!-- #include file="clsDBLogAccess.asp" -->
<%    
	Dim objDBLogAccess
	
	Response.AddHeader "Pragma", "no-cache"
	Response.Expires = -1
	
	Session("SqlServerName") = "SERVER"
	Session("DataBaseName") = "BROKER"
		
	If Session("LogAccessID") = "" Then
		Session.Abandon 
		Set objDBLogAccess = New clsDBLogAccess
		With objDBLogAccess
			.Add()
			Session("LogAccessID") = .AccessID
		End With
		Set objDBLogAccess = Nothing
	End If
	
	UserID = Request.Cookies("TEST_UserID")
	Password = Request.Cookies("TEST_Password")
%>
<HTML>
	<HEAD>
		<TITLE>Welcome to CORP Website</TITLE>  
		<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<style>	
			.pt9 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 10pt }	
			.pt12 { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 12pt }
		</style>
		<SCRIPT LANGUAGE="JavaScript">			
			function ResetEnter() {
				if (event.keyCode == 13) {
					window.event.keyCode = 9;
				}
			}
			
			function CheckAccess() {
				if (top.location==self.location) {
					alert("This page should be loaded from http://www.company.com");
					window.location.href = "http://www.company.com";
				}
			}
		</SCRIPT>
		
	</HEAD>
	<body OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false OnLoad="CheckAccess()">
		<CENTER>
			<TABLE>
				<TR><TD Height=20></TD></TR>
				<TR><TD align=center>
					<FORM METHOD="POST" ACTION="LogonCheck.asp" AUTOCOMPLETE="OFF" NAME="frmLogon">
						<INPUT TYPE=HIDDEN NAME="LogAccessID" VALUE="<%=Session("LogAccessID")%>">
						<font class=pt12><B>User Certification</B></font>
						<HR WIDTH=480>
						<TABLE BORDER=0 align=center class=pt9>
							<TR>
								<TD colspan=2 height=50 align=left valign=top>* Please input your user ID and password below:</TD>
							</TR>
							<TR> 
								<TD ALIGN=RIGHT class=pt12> User ID : </TD>
								<TD><INPUT NAME="UserID" VALUE="<%=UserID%>" MAXLENGTH=32 STYLE="ime-mode:disabled; width:100; height:25" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR> 
								<TD ALIGN=RIGHT class=pt12> Password : </TD>
								<TD><INPUT TYPE="Password" VALUE="<%=Password%>" MAXLENGTH=32 NAME="Password" STYLE="ime-mode:disabled; width:100; height:25" OnKeyDown="ResetEnter()"></TD>
							</TR>
							<TR>
								<TD ALIGN=CENTER COLSPAN=2 height=50>
									<INPUT STYLE="width:120px;height:30px;border-width:2px;font-size:12px;background-color:#E0E0E0;padding-left:10px;background-repeat:no-repeat;background-position:5% 50%;background-image:url('img/security.gif')" TYPE="submit" value="Log On">
								</TD>
							</TR>
							<TR>
								<TD COLSPAN=2><br>
									* Please check the Caps Lock before input your user ID and password<BR>
									* Best view under Microsoft Internet Explorer 6.0 with 1024 x 768 resolution.
								</TD>
							</TR>									
						</TABLE>
						<HR WIDTH=480>
					</FORM>
				</TD></TR>
			</TABLE>	
			<TABLE bgcolor=white class=pt9>
				<TR>
					<TD align=center>
						<IMG SRC="img/logo.png" ALT="COMPANY ">
					</TD>
				</TR>
				<TR>
					<TD align=center>
						Copyright &copy; 2006-2007 COMPANY  Co.,Ltd.
					</TD>
				</TR>
			</TABLE>			
		</CENTER>
	</BODY>
</HTML>
