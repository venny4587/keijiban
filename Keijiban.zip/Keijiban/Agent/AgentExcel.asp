<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
dim ID
dim selMonth
dim selBroker
	
	selMonth = GetPost(request("Month"))
	selBroker = GetPost(request("Broker"))
	
	dim xl
	dim pth
	dim FileName
	
	myDate = now()
	FileName = right(year(myDate),2) & right("00" & month(myDate),2) & right("00" & day(myDate),2) & _
			   right("00" & hour(myDate),2) & right("00" & minute(myDate),2) & right("00" & second(myDate),2)
	FileName = FileName & ".xls"
	pth = server.MapPath("/agent/")
	
	set xl = server.CreateObject("Excel.Application")
	xl.Workbooks.Open(pth & "\_sample.xls")
	Set xlBook = xl.ActiveWorkbook
	set xlSheet = xl.WorkSheets(1)
	xlBook.Saveas pth & "\tmp\" & FileName
	xl.Quit
	Set xlSheet = Nothing
	Set xlBook = Nothing
	Set xl = Nothing
	
	set xl = server.CreateObject("Excel.Application")
	xl.Workbooks.Open(pth & "\tmp\" & FileName)
	Set xlBook = xl.ActiveWorkbook
	set xlSheet = xl.WorkSheets(1)
	
	OpenSQL Conn, SqlServerName, CorpCode & "-CORP"
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myRow = 1
	With Recset
		strSQL = "SELECT * FROM TBL_REC WHERE Deleted = 0 AND Partner = '" & Session("UserCorp") & "'"
		strSQL = strSQL & " AND LEFT(ETD, 6) = '" & selMonth & "' AND Broker = '" & FitSel(Broker) & "'"
		strSQL = strSQL & " ORDER BY JobNo"
		.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
		Do while not .EOF
			i = 0:			myRow = myRow + 1
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("JobNo"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Broker"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Shipment"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Vessel"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Voy"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("MBL"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("HBL"))
			i = i + 1:		XLSheet.Cells(myRow, i) = Str2Date(.fields("ETD"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetDouble(.fields("DebitUSD"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetLong(.fields("DebitJPY"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetDouble(.fields("CreditUSD"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetLong(.fields("CreditJPY"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Memo"))
if false then
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Partner"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Shipper"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Consignee"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Notify"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetLong(.fields("Nomination"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("POL"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("POD"))
			i = i + 1:		XLSheet.Cells(myRow, i) = Str2Date(.fields("ETA"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetLong(.fields("Size20"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Type20"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetLong(.fields("Size40"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Type40"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Commodity"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetLong(.fields("Quantity"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Package"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetDouble(.fields("GW"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetDouble(.fields("CBM"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetLong(.fields("Telex"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Container"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("Marks"))
			i = i + 1:		XLSheet.Cells(myRow, i) = GetString(.fields("CarrierCorp"))
end if
			.MoveNext
		Loop
		.Close 
	End With
	
	set Recset = nothing
	CloseDB Conn

	xlBook.Save
	xl.Quit
	Set xlSheet = Nothing
	Set xlBook = Nothing
	Set xl = Nothing
	
'	Response.Redirect "JobExcel/" & FileName
	
	Set fso=Server.CreateObject("Scripting.FileSystemObject")
	Set fl=fso.getfile(pth & "\tmp\" & FileName )
	flsize=fl.size
	flName=fl.name
	Set fl=Nothing
	Set fso=Nothing
	
	Set objStream = Server.CreateObject("ADODB.Stream")
	objStream.Open
	objStream.Type = 1
	objStream.LoadFromFile pth & "\tmp\" & FileName
	
	Response.AddHeader "Content-Disposition", "attachment; filename=" & flName
	Response.AddHeader "Content-Length", flsize
	
	Response.Charset = "UTF-8"
	Response.ContentType = "application/vnd.ms-excel"
	
	Response.BinaryWrite objStream.Read 
	Response.Flush 
	response.Clear() 
	
	objStream.Close 
	Set objStream = Nothing 
%>


