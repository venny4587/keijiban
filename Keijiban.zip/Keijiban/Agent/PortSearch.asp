<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
		
dim PORT_CN

dim mode
dim myCode
dim myName
dim myNaccs

	mode = GetLong(request("mode"))
	myCode = GetPost(request("cd"))
	if myCode = "" then myCode = GetPost(request("nm"))
	if myCode = "" then myCode = GetPost(request("ncs"))
	selCode = replace(myCode, "'", "''")
	
	OpenSql Conn, SqlServerAgent, DataBaseAgent
	set Recset = Server.CreateObject ("ADODB.Recordset")
	
	PORT_CD = ""
	if myCode <> "" then
		with Recset
			if mode = 0 then
				StrSql = "SELECT PORT_NACCS, PORT_ENAME FROM TBL_POL WHERE"
			else
				StrSql = "SELECT PORT_NACCS, PORT_ENAME FROM TBL_POD WHERE"
			end if
			StrSql = StrSql & " (PORT_NACCS = '" & selCode & "' OR PORT_ENAME = '" & selCode & "')"
			.Open StrSql, Conn, adOpenKeyset, adLockReadOnly
			if not .eof then
				PORT_NACCS = GetString(.fields("PORT_NACCS"))
				PORT_ENAME = GetPortName(.fields("PORT_ENAME"))
				PORT_CD = mid(PORT_NACCS, 3)
			end if
			.close
		end with
	end if

	if PORT_CD <> "" then
%>
<HTML>
<SCRIPT LANGUAGE=JavaScript>
<%select case mode%>
<%case 0%>
	if (window.opener.frmInput.POLCD !=null) window.opener.frmInput.POLCD.value = "<%=PORT_CD%>";
	if (window.opener.frmInput.POL !=null) window.opener.frmInput.POL.value = "<%=PORT_ENAME%>";
	if (window.opener.frmInput.POLN !=null) window.opener.frmInput.POLN.value = "<%=PORT_NACCS%>";
	if (window.opener.frmInput.PODCD !=null) window.opener.frmInput.PODCD.focus();
<%case 1%>
	if (window.opener.frmInput.PODCD !=null) window.opener.frmInput.PODCD.value = "<%=PORT_CD%>";
	if (window.opener.frmInput.POD !=null) window.opener.frmInput.POD.value = "<%=PORT_ENAME%>";
	if (window.opener.frmInput.PODN !=null) window.opener.frmInput.PODN.value = "<%=PORT_NACCS%>";
	if (window.opener.frmInput.Vessel !=null) { window.opener.frmInput.Vessel.focus(); }
<%end select %>
	window.close();
</SCRIPT>
</HTML>
<%
	else
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<TITLE>Port Search</TITLE>
	<SCRIPT LANGUAGE="JavaScript">
	<!--
		function clickLine(cd) {
			window.location.href = "PortSearch.asp?mode=<%=mode%>&cn=<%=PORT_CN%>&cd=" + cd;
		}
		
		function DoSearch() {
			if (frmInput.cd.value == "") {
				alert("Please input part of the port name.")
			} else {
				frmInput.submit();
			}
		}
		
		function ResetEnter() {
			if (event.keyCode == 13) {
				window.event.keyCode = 9;
			}
		}
		
		function overLine(lst) {
			lst.style.background = "#E0FFE0";
		}
		
		function outLine(lst) {
			lst.style.background = "#FFFFFF";
		}
	//-->
	</SCRIPT>
</HEAD>

<body onload="frmInput.cd.focus()" onkeydown="DoShortCut()" <%=gsBodyControl%>>	
	<FORM METHOD="POST" ACTION="PortSearch.asp" NAME=frmInput>
		<input type=hidden name="cn" value="<%=PORT_CN%>">
		<input type=hidden name="mode" value="<%=mode%>">
		<table class=pt9n>
			<TR height=30 align=center>
				<TD>Port:<input class=sz name="cd" value="<%=myCode%>" maxlength=20 size=10 onkeydown="ResetEnter()">
					<INPUT TYPE=button style="cursor:hand; width:80; height:25" VALUE="Search" onclick="DoSearch()"></TD>
			</TR>
		</table>
  <center>
		
		<hr width=96% size=1 color=blue>
<%
		if myCode <> "" then 
			cnt = 0
			With Recset
				if mode = 0 then
					StrSql = "SELECT COUNT(PORT_NACCS) AS PORT_CNT FROM TBL_POL WHERE "
				else
					StrSql = "SELECT COUNT(PORT_NACCS) AS PORT_CNT FROM TBL_POD WHERE "
				end if
				StrSql = StrSql & " (PORT_NACCS LIKE '%" & selCode & "%' OR PORT_ENAME LIKE '%" & selCode & "%')"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				if GetLong(.fields("PORT_CNT")) = 0 then
					response.write "<br>There is no record found."
				elseif GetLong(.fields("PORT_CNT")) > 9 then
					response.write "<br>There are over 9 records found."
				else
					.close
					
					if mode = 0 then
						StrSql = "SELECT PORT_NACCS, PORT_ENAME FROM TBL_POL WHERE "
					else
						StrSql = "SELECT PORT_NACCS, PORT_ENAME FROM TBL_POD WHERE "
					end if
					StrSql = StrSql & " (PORT_NACCS LIKE '%" & selCode & "%' OR PORT_ENAME LIKE '%" & selCode & "%')"
					StrSql = StrSql & " ORDER BY PORT_ENAME"
					.Open StrSql, Conn ,adOpenKeyset ,adLockReadOnly
					if not .EOF then
%>
			<table width=96% class=pt9n cellspacing=3>
				<TR ALIGN="center" height=20 align=right bgcolor=#808080 style="color:white; font-weight:bold">
					<TD nowrap>��
					<TD nowrap>Port Name
					<TD nowrap>Code
<%
						myCnt = 0
						myShortCut = ""
						Do Until .EOF	
							myCnt = myCnt + 1
							myCode = GetString(.Fields("PORT_NACCS"))
							myEName = GetString(.Fields("PORT_ENAME"))	
							myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & asc(Num2Code(myCnt)) & ") clickLine('" & .Fields("PORT_NACCS") & "');"
							if myCnt < 10 then myShortCut = myShortCut & vbcrlf & "else if (window.event.keyCode==" & (96 + myCnt) & ") clickLine('" & .Fields("PORT_NACCS") & "');"
%>
				<TR style="cursor:hand" OnMouseOver="overLine(this)" OnMouseOut="outLine(this)" onclick="clickLine('<%=.Fields("PORT_NACCS")%>')">
					<TD class=line nowrap ALIGN=center>[<%=Num2Code(myCnt)%>]<BR>
					<TD class=line nowrap><%=myEName%><BR>
					<TD class=line nowrap><%=myCode%><BR>
<%
							.MoveNext
						Loop
					end if
%>
			</table>
<%
				end if
				.Close
			End With
			if cnt = 1 then
				response.write "<script language=javascript>clickLine('" & myCode & "');</script>"
			end if
		end if
%>
  </center>
	</FORM>
<script language=javascript>
function DoShortCut() {
if (window.event.keyCode==27) window.close();
<%if myCnt > 0 then response.write myShortCut%>
}
</script>
</BODY></HTML>
<%
	end if
	set Recset = nothing
	CloseDB Conn
%>