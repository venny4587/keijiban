<%
	ID = clng("0" & request("ID"))
	leftUrl = "AgentEdit.asp?ID=" & ID
	if ID = 0 then
		righturl = "blank.htm"
	else
		righturl = "AgentInfo.asp?ID=" & ID
	end if
%>
<HTML>
<HEAD>
<TITLE><%=title%></TITLE>
</HEAD>
	<FRAMESET cols="560,*" BORDER=0 FRAMEBORDER="0" FRAMESPACING="0">
		<FRAME SRC="<%=leftUrl%>" NAME="ctms" MARGINWIDTH="0" MARGINHEIGHT="0">
		<FRAME SRC="<%=righturl%>" NAME="info" MARGINWIDTH="10" MARGINHEIGHT="0">
		<noframes>
			<BODY BGCOLOR=# TEXT="#" LINK="#" VLINK="#" ALINK="#">
			</BODY>
		</noframes>
	</FRAMESET>
</HTML>