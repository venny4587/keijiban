<!-- #include file="common.asp" -->
<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
dim myMode
dim myPageSize
dim lngPageNumber
	
	OpenSQL Conn, SqlServerAgent, DataBaseAgent
	Set Recset = Server.CreateObject ("ADODB.Recordset")
	
	myPageSize = 20
	lngPageNumber = GetLong(request("page"))
	if lngPageNumber = 0 then lngPageNumber = 1
	
	mySort = GetLong(request("sort"))
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		Locked = 1
	else
		JobNo = GetPost(request("JobNo"))
		Shipper = GetPost(request("Shipper"))
		MBL = GetPost(request("MBL"))
		HBL = GetPost(request("HBL"))
		POL = GetPost(request("POL"))
		POD = GetPost(request("POD"))
		DateFrom = GetPost(request("DateFrom"))
		DateTo = GetPost(request("DateTo"))
		QtyFrom = GetPost(request("QtyFrom"))
		QtyTo = GetPost(request("QtyTo"))
		GWFrom = GetPost(request("GWFrom"))
		GWTo = GetPost(request("GWTo"))
		CBMFrom = GetPost(request("CBMFrom"))
		CBMTo = GetPost(request("CBMTo"))
		Vessel = GetPost(request("Vessel"))
		JobShipment = GetLong(request("JobShipment"))
		Container = GetPost(request("Container"))
		Marks = GetPost(request("Marks"))
		Commodity = GetPost(request("Commodity"))
		Locked = GetLong(request("Locked"))
		
		if myMode = 2 then
			strSql = "UPDATE TBL_REC SET Locked = GETDATE() WHERE ID IN (" & GetPost(request("SelID")) & ")"
			Conn.execute strSql
		end if
	end if
	
%>
<HTML>
<HEAD>
	<META http-equiv=Content-Type content="text/html; charset=shift-jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<TITLE>Agent View</TITLE>	
	<SCRIPT language=Javascript src="css/calendar_EN.js"></SCRIPT>
	<script language=vbscript src="css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		function DoCheck()
			Call CheckAll("SelID", frmInput.SelAll.Checked)
		end function 
		
		sub DoProc()
		dim flag
			flag = 0
			for each obj in frmInput.elements
				if obj.type = "checkbox" then
					if left(obj.name, 5) = "SelID" and obj.Checked then
						flag = 1
						exit for
					end if
				end if
			next
			if flag = 0 then
				msgbox "Please select the record first.", 48, "Confirm"
			else
				if msgbox("Are you sure to lock the record ?", 289, "Confirm") <> 1 then exit sub
				frmInput.btnLock.disabled = true
				frmInput.mode.value = 2
				frmInput.submit()
			end if
		end sub
		
		function DoSearch()
			frmInput.page.value = 1
			frmInput.submit()
		end function
		
		function DoSort(no)
			frmInput.sort.value = no
			frmInput.submit()
		end function
		
		function ShowDetail(seq)
		dim win
			'set win = window.open("AgentFrame.asp?ID=" & seq, seq, "resizable=1,scrollbars=1,width=800,height=600,left=0")
			set win = window.open("AgentEdit.asp?ID=" & seq, seq, "resizable=0,scrollbars=0,width=600,height=560,left=0")
			win.focus()
		end function
		
		sub btnTurnPage_OnClick()
			doTurnPage(frmInput.selPage.value)
		end sub
				
		function doTurnPage(myPage)
			frmInput.mode.value = 1
			frmInput.page.value = myPage
			frmInput.submit()
		end function
		
		sub DateFrom_OnBlur()
			frmInput.DateFrom.value = setdate(frmInput.DateFrom.value)
		end sub		
		sub DateTo_OnBlur()
			frmInput.DateTo.value = setdate(frmInput.DateTo.value)
		end sub		
		sub Port_OnBlur()
			frmInput.Port.value = ucase(frmInput.Port.value)
		end sub	
		sub QtyFrom_OnBlur()
			if frmInput.QtyFrom.value = "" then exit sub
			frmInput.QtyFrom.value = GetDouble(frmInput.QtyFrom.value)
		end sub
		sub QtyTo_OnBlur()
			if frmInput.QtyTo.value = "" then exit sub
			frmInput.QtyTo.value = GetDouble(frmInput.QtyTo.value)
		end sub	
		sub GWFrom_OnBlur()
			if frmInput.GWFrom.value = "" then exit sub
			frmInput.GWFrom.value = GetDouble(frmInput.GWFrom.value)
		end sub
		sub GWTo_OnBlur()
			if frmInput.GWTo.value = "" then exit sub
			frmInput.GWTo.value = GetDouble(frmInput.GWTo.value)
		end sub	
		sub CBMFrom_OnBlur()
			if frmInput.CBMFrom.value = "" then exit sub
			frmInput.CBMFrom.value = GetDouble(frmInput.CBMFrom.value)
		end sub
		sub CBMTo_OnBlur()
			if frmInput.CBMTo.value = "" then exit sub
			frmInput.CBMTo.value = GetDouble(frmInput.CBMTo.value)
		end sub	
		
		sub DoShortCut()
			if window.event.keyCode=120 then frmInput.submit()
		end sub		
	</SCRIPT>
</HEAD>

<BODY topmargin=5 onload="SetEndFocus(frmInput.JobNo)" onkeydown="DoShortCut()" <%=gsBodyControl%>>
	<!----------��������--------->		
	<FORM METHOD="POST" ACTION="AgentView.asp" ID=frmInput NAME=frmInput>
		<INPUT TYPE="HIDDEN" NAME="mode" VALUE='1'>
		<INPUT TYPE="HIDDEN" NAME="sort" VALUE='<%=mySort%>'>
		<INPUT TYPE="HIDDEN" NAME="page" VALUE='<%=lngPageNumber%>'>
		<table class=pt9>
			<TR><TD nowrap>
				JOB NUMBER<input class=si name="JobNo" value="<%=JobNo%>" maxlength=20 size=15 onkeydown="ResetEnter()">
				SHIPPER<input class=si name="Shipper" value="<%=Shipper%>" maxlength=10 size=20 onkeydown="ResetEnter()">
				MBL<input class=si name="MBL" value="<%=MBL%>" maxlength=25 size=15 onkeydown="ResetEnter()">
				HBL<input class=si name="HBL" value="<%=HBL%>" maxlength=25 size=15 onkeydown="ResetEnter()">
				SHIPMENT&nbsp;<select name="JobShipment" onkeydown="ResetEnter()"><option value="">--ALL--<%for i = 1 to 5%>
					<option value="<%=i%>" <%if JobShipment = i then response.write "selected"%>><%=JobShip(i)%><%next%></select>
			<TR><TD nowrap>
				ETD<input class=si name="DateFrom" value="<%=DateFrom%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
					�`<input class=si name="DateTo" value="<%=DateTo%>" maxlength=10 size=9 onclick="setday(this)" onkeydown="ResetEnter()">
				VESSEL<input class=si name="Vessel" value="<%=Vessel%>" maxlength=50 size=12 onkeydown="ResetEnter()">
				POL<input class=si name="POL" value="<%=POL%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				POD<input class=si name="POD" value="<%=POD%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				CONTAINER<input class=sz name="Container" value="<%=Container%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				MARKS<input class=sz name="Marks" value="<%=Marks%>" maxlength=16 size=12 onkeydown="ResetEnter()">
			<TR><TD nowrap>
				COMMODITY&nbsp;<input class=si name="Commodity" value="<%=Commodity%>" maxlength=16 size=12 onkeydown="ResetEnter()">
				QUANTITY&nbsp;<input class=sn name="QtyFrom" value="<%=QtyFrom%>" maxlength=8 size=6 onkeydown="ResetEnter()">
					�`<input class=sn name="QtyTo" value="<%=QtyTo%>" maxlength=8 size=6 onkeydown="ResetEnter()">
				WEIGHT&nbsp;<input class=sn name="GWFrom" value="<%=GWFrom%>" maxlength=10 size=9 onkeydown="ResetEnter()">
					�`<input class=sn name="GWTo" value="<%=GWTo%>" maxlength=10 size=9 onkeydown="ResetEnter()">
				M'MENT&nbsp;<input class=sn name="CBMFrom" value="<%=CBMFrom%>" maxlength=9 size=8 onkeydown="ResetEnter()">
					�`<input class=sn name="CBMTo" value="<%=CBMTo%>" maxlength=9 size=8 onkeydown="ResetEnter()">
				<INPUT style="width:70px;height:25px;" TYPE=button name=btnSearch VALUE="Search" onclick="DoSearch()">
				<input type=checkbox name="Locked" value="1" onkeydown="ResetEnter()" <%if Locked then response.write " checked"%>>ALL
		</table>
		
	<!----------��������--------->
<%
		strSql = "SELECT * FROM TBL_REC WHERE Deleted = 0 AND Partner = '" & Session("UserCorp") & "'"
		if JobShipment <> 0 then strSql = strSql & " AND Shipment = " & JobShipment
		if JobNo <> "" then strSql = strSql & " AND JobNo LIKE '%" & FitSel(JobNo) & "%'" 
		if Shipper <> "" then	strSql = strSql & " AND Shipper LIKE '%" & FitSel(Shipper) & "%'"
		if MBL <> "" then strSql = strSql & " AND MBL LIKE '%" & FitSel(MBL) & "%'"
		if HBL <> "" then strSql = strSql & " AND HBL LIKE '%" & FitSel(HBL) & "%'"
		if POL <> "" then strSql = strSql & " AND POL LIKE '%" & FitSel(POL) & "%'"
		if POD <> "" then strSql = strSql & " AND POD LIKE '%" & FitSel(POD) & "%'"
		if DateFrom <> "" then strSql = strSql & " AND ETD >= '" & Date2Str(DateFrom) & "'"
		if DateTo <> "" then strSql = strSql & " AND ETD <= '" & Date2Str(DateTo) & "'"
		if QtyFrom <> "" then strSql = strSql & " AND Quantity >= " & QtyFrom
		if QtyTo <> "" then strSql = strSql & " AND Quantity <= " & QtyTo
		if GWFrom <> "" then strSql = strSql & " AND GW >= " & GWFrom
		if GWTo <> "" then strSql = strSql & " AND GW <= " & GWTo
		if CBMFrom <> "" then strSql = strSql & " AND CBM >= " & CBMFrom
		if CBMTo <> "" then strSql = strSql & " AND CBM <= " & CBMTo
		if Vessel <> "" then strSql = strSql & " AND Vessel+' '+Voy LIKE '%" & FitSel(Vessel) & "%'"	
		if Container <> "" then strSql = strSql & " AND Container LIKE '%" & FitSel(Container) & "%'"
		if Marks <> "" then strSql = strSql & " AND Marks LIKE '%" & FitSel(Marks) & "%'"
		if Commodity <> "" then strSql = strSql & " AND Commodity LIKE '%" & FitSel(Commodity) & "%'"
		if Locked = 0 then strSql = strSql & " AND Locked IS NULL"
		select case mySort
		case 0:		strSQL = strSQL & " ORDER BY Created DESC"
		case 1:		strSQL = strSQL & " ORDER BY Shipment"
		case 2:		strSQL = strSQL & " ORDER BY ETD"
		case 3:		strSQL = strSQL & " ORDER BY Vessel, Voy"
		case 4:		strSQL = strSQL & " ORDER BY MBL, HBL"
		case 5:		strSQL = strSQL & " ORDER BY Shipper"
		case 6:		strSQL = strSQL & " ORDER BY POD, POL"
		case 7:		strSQL = strSQL & " ORDER BY Quantity"
		case 8:		strSQL = strSQL & " ORDER BY CBM"
		case 9:		strSQL = strSQL & " ORDER BY GW"
		case 10:		strSQL = strSQL & " ORDER BY JobNo"
		end select
		if mySort <> 10 then strSQL = strSQL & ",JobNo"
if WebUserID = gsAdmin then response.write strSQL
		With Recset
			.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
			if not .EOF then
				.PageSize = myPageSize
				lngPageCount = .PageCount
				
				.AbsolutePage = lngPageNumber
				lngCount = (lngPageNumber - 1) * myPageSize	
%>
		<table width=100% class=pt9n>
			<tr><td>�߰��: <%=lngPageNumber%>&nbsp;/&nbsp;<%=lngPageCount%>
				<td align=right nowrap>
				<%if lngPageNumber <> 1 then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber - 1%>)">Prev Page</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageNumber <> lngPageCount then%>
					<A class=bar HREF="#" onclick="doTurnPage(<%=lngPageNumber + 1%>)">Next Page</A>
				<%end if%>
					&nbsp;&nbsp;&nbsp;&nbsp;
				<%if lngPageCount > 1 then %>
					<select class=pt9n name=selPage onkeydown="ResetEnter()">
					<%For pageCount = 1 To lngPageCount%>
						<option value='<%=pageCount%>' <%if pageCount=lngPageNumber then%> selected <%end if%>><%=pageCount%></option>				
					<%next%>
					</select>
					<input type=button name="btnTurnPage" style="width:25px;height:20px" value="Go">
				<%end if%>
		</table>
		<TABLE width=100% Cellspacing=3 CellPadding=3 class=pt9n> 
			<colgroup span=4 align=center>
			<colgroup span=4 align=left>
			<colgroup span=3 align=right>
			<colgroup span=2 align=center>
		  <TR align=center height=20 class=line bgcolor=#E0E0E0>
			<TD nowrap>��
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(1)">SHIPMENT
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(0)">JOB NUMBER
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(2)">ETD
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(6)">POD
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(3)">VESSEL VOY
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(4)">BILL NO.
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(5)">SHIPPER
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(7)">Q'TY
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(8)">M'ment
			<TD nowrap style="cursor:hand;color:blue" onmousedown="DoSort(9)">G.W.
<%if false then%>
			<TD colspan=2><input type=checkbox name="SelALL" onkeydown="ResetEnter()" onclick="DoCheck()">ALL
<%end if%>
<%
				Do Until .EOF
					lngCount = lngCount + 1
					If lngCount > lngPageNumber * myPageSize Then
						Exit Do
					Else
						if GetString(.Fields("Locked")) = "" then
							mycolor = "black"
						else
							mycolor = "green"
						end if
						
						Shipper = GetString(.Fields("Shipper"))
						VesselVoy = GetString(.Fields("Vessel")) & " " & GetString(.Fields("Voy"))
						BillNo = GetString(.Fields("MBL"))
						if BillNo <> GetString(.Fields("HBL")) then BillNo = BillNo & "<br>�@" & GetString(.Fields("HBL"))
						Port = GetString(.Fields("POD"))
						Remarks = GetString(.Fields("Remarks"))
						JobShipment = GetLong(.Fields("Shipment"))
%>
					<TR style="cursor:hand;color:<%=mycolor%>" onmouseover="this.bgColor='#E0FFE0';" onmouseout="this.bgColor='#FFFFFF';"
						onclick="ShowDetail('<%=.Fields("ID")%>');">
						<TD nowrap class=line><%=lngCount%><BR>
						<TD nowrap class=line><%=JobShip(.Fields("Shipment"))%>
						<TD nowrap class=line><%=GetString(.Fields("JobNo"))%><BR>
						<TD nowrap class=line><%=Str2YMD(.Fields("ETD"))%><BR>
						<TD nowrap class=line><%=Port%><BR>
						<TD nowrap class=line <%=ShowTitle(VesselVoy, 20)%>><%=stringCut(VesselVoy, 20)%><BR>
						<TD nowrap class=line><%=BillNo%><BR>
						<TD nowrap class=line <%=ShowTitle(Shipper, 20)%>><%=stringCut(Shipper, 20)%><BR>
						<TD nowrap class=line><%=formatnumber(GetLong(.Fields("Quantity")), 0, true)%><BR>
						<TD nowrap class=line><%=formatnumber(GetDouble(.Fields("CBM")), 2, true)%><BR>
						<TD nowrap class=line><%=formatnumber(GetDouble(.Fields("GW")), 2, true)%><BR>
<%if false then%>
						<TD nowrap class=line><%if GetString(.Fields("Locked")) <> "" then%><font class=pt9r>�~</font><%else%>
							<input type=checkbox name="SelID" value="<%=GetLong(.Fields("ID"))%>" onkeydown="ResetEnter()"><%end if%>
						<TD nowrap class=line><a href="javascript:ShowDetail('<%=.Fields("ID")%>');"><img src=img/search.jpg border=0></a>
<%end if%>
					</TR>
<%
						.MoveNext
					End If
				Loop
%>
	</TABLE>
<%if false then%>
	<table width="100%">
		<tr><td><input type=button class=pt9r name=btnLock style="width:80;height:30" value="LOCK" onclick="DoProc()">
	</table>
<%end if%>
<%
			else
				Response.Write "<br><div align=center class=pt9r>There is no record found.</div>"	
			end if
			.Close
		end with
%>
	</FORM>
</BODY></HTML>
<%
	set Recset = nothing
	CloseDB Conn
%>
