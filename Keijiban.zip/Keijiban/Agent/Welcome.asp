<!-- #include file="common.asp" -->
<HTML>
<HEAD>
	<TITLE>Welcome</TITLE>
	<LINK href="css/style.css" rel=stylesheet type=text/css>
</HEAD>
<BODY OnContextmenu=window.event.returnValue=false  OnSelectstart=window.event.returnValue=false>
<center>
	<TABLE width=100%>
	  <TR><TD width=100% height=50 align=center valign=middle>
	    <TABLE style="filter:progid:DXImageTransform.Microsoft.Shadow(Color=#E0E0E0,Direction=120,strength=3)">		
	        <TR><TD class=pt12n><b>WELCOME TO OUR AGENT'S SYSTEM</b>
	    </TABLE>
	  </TD></TR>
	</TABLE>
	<HR width=100% align=left color=blue size=1>
	<TABLE width=100%>
	  <TR><TD width=100% align=center valign=middle class=pt12>
	    <TABLE>
	        <TR height=50><TD class=pt12n colspan=2>PLEASE CHECK YOUR INFOMATION AS BELOW :
	        <TR height=30><TD width=100>COMPANY�F�@<TD class=pt12g width=400><%=session("UserName")%>
	        <TR height=30><TD nowrap>MANAGER�F�@<TD class=pt12g nowrap><%=session("PIC_NAME")%>
	        <TR height=30><TD nowrap>TEL No. �F�@<TD class=pt12g nowrap><%=session("PIC_TEL")%>
	        <TR height=30><TD nowrap>FAX No. �F�@<TD class=pt12g nowrap><%=session("PIC_FAX")%>
	        <TR height=30><TD nowrap>COUNTRY �F�@<TD class=pt12g nowrap><%=GetCountry(session("PIC_CD"))%>
	        <TR height=30><TD nowrap>PORT �F�@<TD class=pt12g nowrap><%=session("PIC_DPT")%>
	    </TABLE>
	</TABLE>
	<HR width=100% align=left color=blue size=1>
</center>
</BODY>
</HTML>

<%
function GetCountry(myCode)
    Select Case UCase(myCode)
    Case "CN":  GetCountry = "CHINA"                '����
    Case "KR":  GetCountry = "KOREAN"               '�؍�
    Case "HK":  GetCountry = "HONGKONG"             '���`
    Case "ID":  GetCountry = "INDONESIA"            '�C���h�l�V�A
    Case "IN":  GetCountry = "INDIA"                '�C���h
    Case "LK":  GetCountry = "SRI LANKA"            '�X�������J
    Case "MY":  GetCountry = "MALAYSIA"             '�}���[�V�A
    Case "PH":  GetCountry = "PHILIPPINES"          '�t�B���s��
    Case "TH":  GetCountry = "THAILAND"             '�^�C
    Case "TW":  GetCountry = "TAIWAN"               '��p
    Case "VN":  GetCountry = "VIET NAM"             '�x�g�i��
    End Select
end function
%>