<!-- #include file="function.asp" -->
<HTML>
	<HEAD>
		<TITLE>�A�����ڋƖ����j���[</TITLE>
		<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
		<style>	
			.ptt { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
			.pts { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
			.ptm { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 11pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		</style>
		<SCRIPT LANGUAGE=vbscript>
		<!--
			Sub DoAct(mySel)
				btnGuide.style.color = "black"
				btnInput.style.color = "black"
				btnFetch.style.color = "black"
				btnOrder.style.color = "black"
				select case mySel
				case 0
					url = "UsersGuide.asp"
					btnGuide.style.color = "red"
				case 1
					url = "ReceiveInput.asp"
					btnInput.style.color = "red"
				case 2
					url = "DoLessRequest.asp"
					btnFetch.style.color = "red"
				case 3
					url = "DeliveryOrder.asp"
					btnOrder.style.color = "red"
				end select
				window.parent.dobody.location.href = url 
			End Sub
		//-->
		</SCRIPT>
	</HEAD>
	<BODY OnContextmenu=window.event.returnValue=false OnSelectstart=window.event.returnValue=false>
		
		<table width=600 class=ptt>
			<tr valign=top>
				<td width=100><img src=img/logo.jpg><td width=200>
				<td width=300><font class=ptm>COMPANY  CO., LTD.<br>
								�T���v���������</font><br>
								&nbsp;�����s������<br>
								<font class=pts><b>TEL 01-1111-1111�@FAX 02-2222-2222</b></font>
			<TR><td colspan=3><hr width=100% size=1 color=blue>
			<TR><TD colspan=3 align=center>
				<TABLE border=0 cellSpacing=3 cellPadding=3>
				  <TR>
				    <TD width=150>
				    	<INPUT type=button style="FONT-SIZE: 11pt; WIDTH: 140px; HEIGHT: 32px;" name=btnGuide value="���p�҃K�C�h" onclick="DoAct(0)"></TD>
				    <TD width=150>
				    	<INPUT type=button style="FONT-SIZE: 11pt; WIDTH: 140px; HEIGHT: 32px;" name=btnInput value="�U�����o�^" onclick="DoAct(1)"></TD>
				    <TD width=150>
				    	<INPUT type=button style="FONT-SIZE: 11pt; WIDTH: 140px; HEIGHT: 32px;" name=btnFetch value="D/O �ԍ��擾" onclick="DoAct(2)"></TD>
				    <TD width=150>
				    	<INPUT type=button style="FONT-SIZE: 11pt; WIDTH: 140px; HEIGHT: 32px;" name=btnOrder value="���o�I�[�_�[" onclick="DoAct(3)"></TD>
				  </TR>
				</TABLE>
			</TD></TR>
		</TABLE>
	</BODY>
</HTML>