<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
dim CorpName
dim Manager
dim TelNo
dim FaxNo
dim JobCode(9)
dim SerialNo(9)
dim DoLessNo(9)
dim objDBLogAccess

	MaxCount = 5

	
	myMode = GetLong(request("mode"))
	if myMode = 0 then
		
		CorpName = Request.Cookies("TEST_CorpName")
		Manager = Request.Cookies("TEST_Manager")
		TEL = Request.Cookies("TEST_TEL")
		FAX = Request.Cookies("TEST_FAX")
		
		for i = 1 to MaxCount
			DoLessNo(i) = "�Ɖ�̂�"
		next
		
	elseif myMode = 1 then
		
		CorpName = GetPost(request("CorpName"))
		Manager = GetPost(request("Manager"))
		TEL = GetPost(request("TEL"))
		FAX = GetPost(request("FAX"))
		
		Response.Cookies("TEST_CorpName") = CorpName
		Response.Cookies("TEST_CorpName").Expires = #January 01, 2010# 
		Response.Cookies("TEST_Manager") = Manager
		Response.Cookies("TEST_Manager").Expires = #January 01, 2010# 
		Response.Cookies("TEST_TEL") = TEL
		Response.Cookies("TEST_TEL").Expires = #January 01, 2010# 
		Response.Cookies("TEST_FAX") = FAX
		Response.Cookies("TEST_FAX").Expires = #January 01, 2010# 
		
		CookieCheck = Request.Cookies("CORP")
		if GetLong(CookieCheck) = 0 then
			
		end if
		
		for i = 1 to MaxCount
			JobCode(i) = GetPost(request("JobCode" & i))
			JobCodes = JobCodes & "," & GetString(JobCode(i))
			SerialNo(i) = GetPost(request("SerialNo" & i))
			SerialNos = SerialNos & "," & GetString(SerialNo(i))
		next
		
		LogAccessID = 0
		Set objDBLogAccess = New clsDBLogAccess
		With objDBLogAccess
			.Add()
			LogAccessID = GetLong(.AccessID)
		End With
		Set objDBLogAccess = Nothing
		
		msg = ""
		if LogAccessID <= 0 then msg = "�������܃A�N�Z�X�s�ł��B<br>"
		if CorpName = "" then msg = msg & "�u��Ж��́v�͖����͂ł��B<br>"
		if Manager = "" then msg = msg & "�u�S���Җ��v�͖����͂ł��B<br>"
		if TEL = "" then msg = msg & "�u�d�b�ԍ��v�͖����͂ł��B<br>"
		if replace(JobCodes, ",", "") = "" then msg = msg & "�u�⍇���ԍ��v�͖����͂ł��B<br>"
		if replace(SerialNos, ",", "") = "" then msg = msg & "�u�Ïؔԍ��v�͖����͂ł��B<br>"
		if msg <> "" then
			myMode = 0
		else
			UrlPath = "http://127.0.0.1/scripts/CORP/Programs/HttpXml/GetDoLessInfo.asp?mode=1&Jobcode=" & JobCodes & "&Serial=" & SerialNos
			
			set HttpXML = server.CreateObject("MSXML2.XMLHTTP")
			HttpXML.open "GET", UrlPath, False
			HttpXML.send
			CleanXML = HttpXML.responseStream
			
			Set objDoc = Server.CreateObject("Msxml2.DOMDocument")
			objDoc.async = false
			objDoc.Load(CleanXML)
			
			set objRoot = objDoc.documentElement
			If not objRoot Is Nothing Then
				set objNode = objRoot.selectSingleNode("//response")
				If not objNode Is Nothing Then
					For i = 1 to MaxCount
						set objField = objNode.selectSingleNode("DoLess" & i)
						DoLessNo(i) = GetString(objField.text)
						Results = Results & "," & GetString(DoLessNo(i))
					next
				end if
			end if
			set objRoot = nothing
			set objDoc = nothing
			
			OpenMDB Conn
			set Recset = Server.CreateObject("adodb.recordset")
			
			Conn.BeginTrans
			with Recset
				strSql = "SELECT * FROM DoLessProc"
				.Open strSQL, Conn, adOpenKeyset, adLockOptimistic
				.AddNew
				.fields("AccessID") = LogAccessID
				.fields("ProcMode") = 2					'D/O�ԍ�
				.fields("CorpName") = CorpName
				.fields("Manager") = Manager
				.fields("TEL") = TEL
				.fields("FAX") = FAX
				.fields("ProcDate") = Date2Str(date)
				.fields("ProcTime") = right(FmtDateTime(now), 5)
				.fields("JobCode") = mid(JobCodes, 2)
				.fields("ProcMemo") = mid(SerialNos, 2)
				.fields("Remarks") = mid(Results, 2)
				.update
				.Close
				
				strSql = "SELECT ProcID FROM DoLessProc ORDER BY ProcID DESC"
				.Open strSql, Conn, adOpenKeyset, adLockReadOnly
				if not .eof then msg = GetLong(.fields("ProcID"))
				.Close
			end with
			
			if err.number = 0 then
				Conn.CommitTrans
				msg = "�Y�������擾���u" & msg & "�v�Ƃ��ċL�^���܂����B"
			else
				Conn.RollbackTrans
				msg = "���L�̃G���[���N����܂����B(" & vbcrlf & err.number & ":" & err.description & ")"
			end if
			CloseDB Conn
		end if
	end if
	
	if myMode = 0 then
		btnProc = "�擾"
	else
		btnProc = "����"
	end if
%>
<html>
<HEAD>
	<TITLE>�c�^�n�ԍ��擾</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<SCRIPT language=vbscript src="css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoShortCut()
			if window.event.keyCode=120 then call DoProc()
		end sub
		
		sub DoProc()
		dim buf
<%if myMode = 0 then%>
			if checkText("CorpName","��Ж���", 1) = false then exit sub
			if checkText("Manager","�S���Җ�", 1) = false then exit sub
			if checkText("TEL","�d�b�ԍ�", 1) = false then exit sub
			if checkText("FAX","FAX �ԍ�", 0) = false then exit sub
	<%for i = 1 to MaxCount%>
			if checkText("JobCode<%=i%>","�⍇���ԍ�", 0) = false then exit sub
			if trim(frmInput.JobCode<%=i%>.value) <> "" then
				buf = buf & trim(frmInput.JobCode<%=i%>.value)
				if checkText("SerialNo<%=i%>","�Ïؔԍ�", 1) = false then exit sub
			end if
	<%next%>
			if buf = "" then
				frmInput.JobCode1.focus()
				msgbox "�⍇���ԍ�����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
			else
				if msgbox("����Ŏ擾���Ă�낵���ł����H", 33, "�m�F���b�Z�[�W") = 1 then
					frmInput.btnProc.disabled = true
					frmInput.submit()
				end if
			end if
<%else%>
			frmInput.mode.value = 0
			frmInput.submit()
<%end if%>
		end sub
		
		sub InitForm()
<%if myMode = 0 then%>
			frmInput.CorpName.focus()
<%else%>
			frmInput.btnProc.focus()
<%end if%>
		end sub
	</SCRIPT>
</Head>
<body topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()"
	OnContextmenu=window.event.returnValue=false OnSelectstart=window.event.returnValue=false>
<%if msg <> "" then%>
	<table width=600 Border=0 Cellspacing=0 CellPadding=0 class=pt12>
		<tr><td center><table class=pt12r><tr><td><%=msg%></table>
	</table>
<%end if%>
  <FORM NAME="frmInput" action="DoLessRequest.asp" method="post">
  	<input type=hidden name="mode" value="1">
	<table width=600 Border=0 Cellspacing=0 CellPadding=0 class=pt12g>
	  <TR height=30><td colspan=3>
	  	��Ж��� <input class=mj name="CorpName" value="<%=CorpName%>" maxlength=50 size=38 onkeydown="ResetEnter()">�@
	  	�S���Җ� <input class=mj name="Manager" value="<%=Manager%>" maxlength=15 size=10 onkeydown="ResetEnter()">
	  <TR height=30><td colspan=3>
	  	�d�b�ԍ� <input class=mi name="TEL" value="<%=TEL%>" maxlength=50 size=24 onkeydown="ResetEnter()">�@
	  	FAX �ԍ� <input class=mi name="FAX" value="<%=FAX%>" maxlength=50 size=24 onkeydown="ResetEnter()">
	  <TR height=30><td colspan=3 class=pt12>
	  	�⍇���ԍ��ƈÏؔԍ��iA/N �Q�Ɓj�������͂��������F
	<%for i = 1 to MaxCount%>
	  <TR height=30>
	  	<td align=center>�⍇���ԍ� <input class=mi name="JobCode<%=i%>" value="<%=JobCode(i)%>" maxlength=15 size=10 onkeydown="ResetEnter()">
	  	<td>�Ïؔԍ� <input class=mi name="SerialNo<%=i%>" value="<%=SerialNo(i)%>" maxlength=8 size=8 onkeydown="ResetEnter()">
	  	<td>D/O �ԍ� <%=ResetDoLessNo(DoLessNo(i))%>
	 <%next%>
	  <TR height=60><td colspan=3 align=center>
	  	<input type=button class=pt12b style="width:160;height:32" name=btnProc value="F9:<%=btnProc%>" onclick="DoProc()">
	  <TR height=30><td colspan=3>
	  	���ݕ����o�ɂ͂`/�m�Ƃc/�n�ԍ���K������o���������B<br>
	  	�@����m�F�̂��߁A�`/�m�ɂ��S���҂̈�ӂ����񎦂��肢���܂��B
	</table>
  </FORM>
</body>
</html>

<%
function ResetDoLessNo(myNo)
dim buf
	buf = GetString(myNo)
	if buf = "" then 
		buf = space(10)
		ResetDoLessNo = "<u>" & replace(buf, " ", "&nbsp;") & "</u>"
	elseif len(buf) = 8 then
		ResetDoLessNo = "<font class=pt12b><u>&nbsp;" & buf & "&nbsp;</u></font>"
	elseif buf = "�Ɖ�̂�" then
		ResetDoLessNo = "<font class=pt12><u>&nbsp;" & buf & "&nbsp;</u></font>"
	else
		ResetDoLessNo = "<font class=pt12r><u>&nbsp;" & buf & "&nbsp;</u></font>"
	end if
end function
%>
