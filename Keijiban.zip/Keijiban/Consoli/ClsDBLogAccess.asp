<%
	Class clsDBLogAccess
	
		Private m_dtmAdded
		Private m_dtmLogOffTime
		Private m_lngAccessID
		Private m_lngCount
		
		Function Add()
			
			Dim Conn
			Dim Recset
			Dim strSql
			
			OpenMDB Conn
			Set Recset = Server.CreateObject ("ADODB.Recordset")
			
			m_lngAccessID = 0
			With Recset
				strSql = "SELECT IP_Addr FROM BlackList WHERE IP_Addr = '" & Request.ServerVariables ("REMOTE_ADDR") & "';"
				.Open strSql, Conn, adOpenKeyset, adLockReadOnly
				if not .eof then m_lngAccessID = -1
				.Close
			end With
			
			if m_lngAccessID = 0 then
				'���O�֏�������
				Conn.BeginTrans
				
				With Recset
					strSql = "SELECT * FROM LogAccess;"
					.Open strSql, Conn, adOpenKeyset , adLockOptimistic 
					.AddNew 
					.Fields ("Remote_Addr") = Request.ServerVariables ("REMOTE_ADDR")
					.Fields ("Remote_Host") = Request.ServerVariables ("REMOTE_HOST")
					.Fields ("Http_User_Agent") = Request.ServerVariables ("HTTP_USER_AGENT")
					.Fields ("Http_Accept_Language") = left(Request.ServerVariables ("HTTP_ACCEPT_LANGUAGE"), 50)
					.Fields ("Added") = Now()
					.Update 
					.Close
					
					strSql = "SELECT AccessID FROM LogAccess ORDER BY AccessID DESC;"
					.Open strSql, Conn, adOpenKeyset, adLockReadOnly
					if not .eof then m_lngAccessID = .Fields ("AccessID")
					.Close
				End With
				Conn.CommitTrans
			end if
			Set RecSet = Nothing
			CloseDB Conn
			
		End Function
		
		'AccessID
		Property Get AccessID
			AccessID = m_lngAccessID
		End Property
	End Class
%>
