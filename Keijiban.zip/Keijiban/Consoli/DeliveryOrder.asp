<!-- #include file="DBConst.asp" -->
<!-- #include file="function.asp" -->
<%
'on error resume next
dim CorpName
dim Manager
dim TelNo
dim FaxNo
dim ProcDate
dim ProcAmount
dim JobCode(9)
dim SerialNo(9)
dim ChkResult(9)
dim JobCodes
dim objDBLogAccess

	MaxCount = 5
	
	myMode = GetLong(request("mode"))
	select case myMode 
	case 0
		
		CorpName = Request.Cookies("TEST_CorpName")
		Manager = Request.Cookies("TEST_Manager")
		TEL = Request.Cookies("TEST_TEL")
		FAX = Request.Cookies("TEST_FAX")
		
		ProcDate = formatdate(dateadd("d", 1, date))
		if hour(now) < 12 then 
			ProcTime = "�ߑO"
		else
			ProcTime = "�ߌ�"
		end if
		
		for i = 1 to MaxCount
			ChkResult(i) = "�Ɖ�̂�"
		next
	case 1
		
		CorpName = GetPost(request("CorpName"))
		Manager = GetPost(request("Manager"))
		TEL = GetPost(request("TEL"))
		FAX = GetPost(request("FAX"))
		
		Response.Cookies("TEST_CorpName") = CorpName
		Response.Cookies("TEST_CorpName").Expires = #January 01, 2010# 
		Response.Cookies("TEST_Manager") = Manager
		Response.Cookies("TEST_Manager").Expires = #January 01, 2010# 
		Response.Cookies("TEST_TEL") = TEL
		Response.Cookies("TEST_TEL").Expires = #January 01, 2010# 
		Response.Cookies("TEST_FAX") = FAX
		Response.Cookies("TEST_FAX").Expires = #January 01, 2010# 
		
		for i = 1 to MaxCount
			JobCode(i) = GetPost(request("JobCode" & i))
			JobCodes = JobCodes & "," & GetString(JobCode(i))
			SerialNo(i) = GetPost(request("SerialNo" & i))
			SerialNos = SerialNos & "," & GetString(SerialNo(i))
		next
		
		ProcDate = GetDate(request("ProcDate"))
		ProcTime = GetPost(request("ProcTime"))
		ProcMemo = GetPost(request("ProcMemo"))
		Remarks = GetPost(request("Remarks"))
		
		LogAccessID = 0
		Set objDBLogAccess = New clsDBLogAccess
		With objDBLogAccess
			.Add()
			LogAccessID = GetLong(.AccessID)
		End With
		Set objDBLogAccess = Nothing
		
		msg = ""
		if LogAccessID <= 0 then msg = "�������܃A�N�Z�X�s�ł��B<br>"
		if CorpName = "" then msg = msg & "�u��Ж��́v�͖����͂ł��B<br>"
		if Manager = "" then msg = msg & "�u�S���Җ��v�͖����͂ł��B<br>"
		if TEL = "" then msg = msg & "�u�d�b�ԍ��v�͖����͂ł��B<br>"
		if ProcMemo = "" then msg = msg & "�u�o�ɐ�v�͖����͂ł��B<br>"
		if Date2Str(ProcDate) <= Date2Str(date) then msg = msg & "�u�o�ɓ��t�v�͕s���ł��B<br>"
		
		if msg = "" then
			UrlPath = "http://127.0.0.1/scripts/CORP/Programs/HttpXml/ChkChargeInfo.asp?mode=1&Jobcode=" & JobCodes & "&Serial=" & SerialNos
			
			set HttpXML = server.CreateObject("MSXML2.XMLHTTP")
			HttpXML.open "GET", UrlPath, False
			HttpXML.send
			CleanXML = HttpXML.responseStream
			
			Set objDoc = Server.CreateObject("Msxml2.DOMDocument")
			objDoc.async = false
			objDoc.Load(CleanXML)
			
			set objRoot = objDoc.documentElement
			If not objRoot Is Nothing Then
				set objNode = objRoot.selectSingleNode("//response")
				If not objNode Is Nothing Then
					For i = 1 to MaxCount
						set objField = objNode.selectSingleNode("ChkResult" & i)
						ChkResult(i) = GetString(objField.text)
						if ChkResult(i) = "�ԍ��s��" then 
							if msg = "" then msg = "���͂��ꂽ�ԍ��͕s���ł��B"
						end if
					next
				end if
			end if
			set objRoot = nothing
			set objDoc = nothing
		end if
		
		OpenMDB Conn
		set Recset = Server.CreateObject("adodb.recordset")
		
		if msg = "" then
			With Recset
				for i = 1 to MaxCount
					if JobCode(i) <> "" AND ChkResult(i) <> "�ԍ��s��" then
						strSQL = "SELECT AccessID FROM DoLessProc WHERE ProcMode = 3 AND JobCode LIKE '%" & JobCode(i) & ",%'"
						.Open strSQL, Conn, adOpenKeyset, adLockReadOnly
						if not .eof then
							ChkResult(i) = "�����ς�"
							if msg = "" then msg = "�o�ɃI�[�_�[�ςݔԍ�������܂��B"
						end if
						.Close
					end if
				next
			end with
		end if
		
		if msg <> "" then
			myMode = 0
		else
			
			Conn.BeginTrans
			with Recset
				strSql = "SELECT * FROM DoLessProc"
				.Open strSQL, Conn, adOpenKeyset, adLockOptimistic
				.AddNew
				.fields("AccessID") = LogAccessID
				.fields("ProcMode") = 3					'�o��
				.fields("CorpName") = CorpName
				.fields("Manager") = Manager
				.fields("TEL") = TEL
				.fields("FAX") = FAX
				.fields("ProcDate") = Date2Str(ProcDate)
				.fields("ProcTime") = ProcTime
				.fields("ProcMemo") = ProcMemo
				.fields("JobCode") = mid(JobCodes, 2)
				.fields("Remarks") = Remarks
				.update
				.Close
				
				strSql = "SELECT ProcID FROM DoLessProc ORDER BY ProcID DESC"
				.Open strSql, Conn, adOpenKeyset, adLockReadOnly
				if not .eof then msg = GetLong(.fields("ProcID"))
				.Close
			end with
				
			if err.number = 0 then
				Conn.CommitTrans
				msg = "�o�ɏ���\�񇂁u" & msg & "�v�Ƃ��ēo�^���܂����B"
			else
				Conn.RollbackTrans
				msg = "���L�̃G���[���N����܂����B(" & vbcrlf & err.number & ":" & err.description & ")"
			end if
			set Recset = Nothing
			CloseDB Conn
		end if
		
	end select
	
	if myMode = 0 then
		btnProc = "�o�^"
	else
		btnProc = "����"
	end if
%>
<html>
<HEAD>
	<TITLE>�o�Ɏw�����o�^</TITLE>
	<meta http-equiv="content-type" content="text/html;charset=shift_jis">
	<LINK rel=stylesheet type=text/css href="css/style.css">
	<SCRIPT language=vbscript src="css/function.vbs"></script>
	<SCRIPT LANGUAGE=vbscript>
		sub DoShortCut()
			if window.event.keyCode=120 then call DoProc()
		end sub
		
		sub DoProc()
		dim buf
<%if myMode = 0 then%>
			if checkText("CorpName","��Ж���", 1) = false then exit sub
			if checkText("Manager","�S���Җ�", 1) = false then exit sub
			if checkText("TEL","�d�b�ԍ�", 1) = false then exit sub
			if checkText("FAX","FAX �ԍ�", 0) = false then exit sub
			if checkDate("ProcDate","�o�ɓ��t", 1) = false then exit sub
			if cdate(frmInput.ProcDate.value) < cdate(date) then
				frmInput.ProcDate.focus()
				msgbox "�o�ɓ��t�͉ߋ��̓��t�ɂȂ��Ă��܂��B", 48, "�m�F���b�Z�[�W"
				exit sub
			end if
			if checkText("ProcTime","�o�Ɏ���", 0) = false then exit sub
			if checkText("ProcMemo","�o�ɐ�", 1) = false then exit sub
	<%for i = 1 to MaxCount%>
			if checkText("JobCode<%=i%>","�⍇���ԍ�", 0) = false then exit sub
			if trim(frmInput.JobCode<%=i%>.value) <> "" then
				buf = buf & trim(frmInput.JobCode<%=i%>.value)
				if checkText("SerialNo<%=i%>","�Ïؔԍ�", 1) = false then exit sub
			end if
	<%next%>
			if buf = "" then
				frmInput.JobCode0.focus()
				msgbox "�⍇���ԍ�����͂��Ă��������B", 48, "�m�F���b�Z�[�W"
			else
				if msgbox("����œo�^���Ă�낵���ł����H", 33, "�m�F���b�Z�[�W") = 1 then
					frmInput.btnProc.disabled = true
					frmInput.submit()
				end if
			end if
<%else%>
			frmInput.mode.value = 0
			frmInput.submit()
<%end if%>
		end sub
		
		sub InitForm()
<%if myMode = 0 then%>
			frmInput.CorpName.focus()
<%else%>
			frmInput.btnProc.focus()
<%end if%>
		end sub
		
		sub ProcDate_OnBlur()
			frmInput.ProcDate.value = setDate(frmInput.ProcDate.value)
		end sub
	</SCRIPT>
</Head>
<body topmargin=0 class=pt9 onload="InitForm()" onkeydown="DoShortCut()"
	OnContextmenu=window.event.returnValue=false OnSelectstart=window.event.returnValue=false>
<%if msg <> "" then%>
	<table width=600 Border=0 Cellspacing=0 CellPadding=0 class=pt12>
		<tr><td center><table class=pt12r><tr><td><%=msg%></table>
	</table>
<%end if%>
  <FORM NAME="frmInput" action="DeliveryOrder.asp" method="post">
  	<input type=hidden name="mode" value="1">
	<table width=600 Border=0 Cellspacing=0 CellPadding=0 class=pt12g>
	  <TR height=30><td colspan=3>
	  	��Ж��� <input class=mj name="CorpName" value="<%=CorpName%>" maxlength=50 size=38 onkeydown="ResetEnter()">�@
	  	�S���Җ� <input class=mj name="Manager" value="<%=Manager%>" maxlength=15 size=10 onkeydown="ResetEnter()">
	  <TR height=30><td colspan=3>
	  	�d�b�ԍ� <input class=mi name="TEL" value="<%=TEL%>" maxlength=50 size=24 onkeydown="ResetEnter()">�@
	  	FAX �ԍ� <input class=mi name="FAX" value="<%=FAX%>" maxlength=50 size=24 onkeydown="ResetEnter()">
	  <TR height=30><td colspan=3>
	  	�o�ɓ��t <input class=mi name="ProcDate" value="<%=ProcDate%>" maxlength=10 size=10 onkeydown="ResetEnter()" title="��:<%=year(date)%>/08/12">
	  	���� <input class=mj name="ProcTime" value="<%=ProcTime%>" maxlength=5 size=6 onkeydown="ResetEnter()">�@
	  	�o�ɐ� <input class=mj name="ProcMemo" value="<%=ProcMemo%>" maxlength=50 size=26 onkeydown="ResetEnter()">
	  <TR height=30><td colspan=3 class=pt12>
	  	�Y������o�ɑΏۂ̖⍇���ԍ��iA/N �Q�Ɓj�������͂��������F
	<%for i = 1 to MaxCount%>
	  <TR height=30>
	  	<td align=center>�⍇���ԍ� <input class=mi name="JobCode<%=i%>" value="<%=JobCode(i)%>" maxlength=15 size=10 onkeydown="ResetEnter()">
	  	<td>�Ïؔԍ� <input class=mi name="SerialNo<%=i%>" value="<%=SerialNo(i)%>" maxlength=8 size=8 onkeydown="ResetEnter()">
	  	<td>�� <%=ResetPackage(ChkResult(i))%>
	 <%next%>
	  <TR height=30><td colspan=3 class=pt12>
	  	�o�Ƀ��� <input class=mj name="Remarks" value="<%=Remarks%>" maxlength=100 size=60 onkeydown="ResetEnter()">
	  <TR height=60><td colspan=3 align=center>
	  	<input type=button class=pt12b style="width:160;height:32" name=btnProc value="F9:<%=btnProc%>" onclick="DoProc()">
	  <TR height=30><td colspan=3 class=pt12g>
	  	���o�^��t�@�b�N�X�̑��t�͕K�v�Ȃ��Ȃ�̂ŁA���������������B<br>
	  	�@�I�[�_�[�͏o�ɑO���̌ߌ�܎��܂łɂ��o�^���肢���܂��B<br>
	  	�@���̈ȍ~�̎�t�͌���Ɋm�F�̏�A���A�����������B
	</table>
  </FORM>
</body>
</html>

<%
function ResetPackage(myPackage)
dim buf
	buf = GetString(myPackage)
	if len(buf) = 4 then 
		buf = buf & "�@"
	else
		buf = left(GetString(myPackage) & space(10), 10)
	end if
	ResetPackage = "<font class=pt12><u>&nbsp;" & replace(buf, " ", "&nbsp;") & "&nbsp;</u></font>"
end function
%>