<!-- #include file="clsDBLogAccess.asp" -->
<%
dim Conn
dim strSql
dim Recset
dim i
dim j

'=============================
'	���ʕ�
'=============================
'	Response.CacheControl = "no-cache"
	Response.AddHeader "Pragma", "no-cache"
	Response.Expires = -1
	
	Session.Timeout = 300
	Server.ScriptTimeout = 300
	
	gsDateSign = "/"

Sub ShowMessage(myMsg)
	Response.Write ("<HTML><SCRIPT LANGUAGE=JavaScript>alert(" & chr(34) & myMsg & chr(34) & ");window.history.back();</SCRIPT></HTML>")
	Response.End 
End Sub

Function GetPost(myData)
on error resume next
dim buf
	GetPost = "ERROR"
	buf = lcase(GetString(myData))
	if instr(buf, " ") = 0 then
	   	GetPost = GetString(myData)
	elseif instr(buf, "exec") = 0 and _
	   instr(buf, "update") = 0 and _
	   instr(buf, "insert") = 0 and _
	   instr(buf, "delete") = 0 and _
	   instr(buf, "script") = 0 then
	   	GetPost = GetString(myData)
	end if
End Function

Function FitSel(myData)
on error resume next
dim buf
	buf = GetString(myData)
	FitSel = replace(buf, "'", "''")
End Function

function GetClientIP()
	GetClientIP = request.servervariables("HTTP_X_FORWARDED_FOR")
	if GetClientIP = "" then
		GetClientIP = request.servervariables("REMOTE_ADDR")
	end if
end function

Function GetLong(myData)
on error resume next
	GetLong = 0
	if isnumeric(myData) then GetLong = clng(myData)
End Function

Function GetDouble(myData)
on error resume next
	GetDouble = 0
'	if isnumeric(myData) then GetDouble = cdbl(myData)
	GetDouble = cdbl(myData)
End Function

Function GetString(myData)
on error resume next
	GetString = trim(cstr(myData & ""))
End Function

Function GetDate(myData)
on error resume next
	GetDate = ""
	if isdate(myData) then	GetDate = cdate(myData)
End Function

Function ResetString(myStr)
on error resume next
	ResetString = replace(myStr, "'", "''")
End Function

Function ResetBoolean(myBln)
on error resume next
	if myBln = true then
		ResetBoolean = 1
	else
		ResetBoolean = 0
	end if
End Function


Function GetLeft(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeft = buf
End Function

Function GetLeftRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Left(buf, pos - 1)
    GetLeftRev = buf
End Function

Function GetRight(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStr(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRight = buf
End Function

Function GetRightRev(myData, mySign)
Dim buf
Dim pos
    buf = CStr(myData & "")
    pos = InStrRev(buf, mySign)
    If pos > 0 Then buf = Mid(buf, pos + Len(mySign))
    GetRightRev = buf
End Function

function Str2Date(myData)
	if GetString(myData) <> "" then Str2Date = mid(myData,1,4) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2YMD(myData)
	if GetString(myData) <> "" then Str2YMD = mid(myData,3,2) & gsDateSign & mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Str2MD(myData)
	if GetString(myData) <> "" then Str2MD = mid(myData,5,2) & gsDateSign & mid(myData,7,2)
end function 

function Date2Str(myData)
dim dt
	Date2Str = ""
	if not isDate(myData) then exit function
	dt = cdate(myData)
	Date2Str = year(dt) & right("00" & month(dt),2) & right("00" & day(dt),2) 
end function 



Function Time2Code(myTime)
Dim h, n, s
    h = Num2Code(Hour(myTime))
    n = Right("00" & Minute(myTime), 2)
    s = Right("00" & Second(myTime), 2)
    Time2Code = Date2Code(myTime) & h & n & s
End Function

Function Date2Code(myDate)
Dim y, m, d
    y = Num2Code(Year(myDate) - 2000)
    m = Num2Code(Month(myDate))
    d = Num2Code(Day(myDate))
    Date2Code = y & m & d
End Function

Function Num2Code(myNum)
    If myNum < 10 Then
        Num2Code = myNum
    Else
        Num2Code = Chr(myNum + 55)
    End If
End Function

function stringCut(myStr,myLen)
on error resume next
	stringCut = trim(myStr & "")
	if len(stringCut) > myLen then
		stringCut = left(stringCut,myLen - 3) & "..."
	end if	
end function

function StringCutRev(myStr,myLen)
on error resume next
	StringCutRev = trim(myStr & "")
	if len(StringCutRev) > myLen then
		StringCutRev = "..." & right(StringCutRev,myLen)
	end if	
end function

function ShowTitle(myStr,myLen)
on error resume next	
	ShowTitle = trim(myStr & "")
	if len(ShowTitle) > myLen then
		ShowTitle = " title='" & stringReset(ShowTitle) & "'"
	else
		ShowTitle = ""
	end if
end function

function stringReset(myStr)
on error resume next	
	stringReset = replace(myStr, "'", "�f")
end function


function formatDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDate = ""
		exit function
	end if		
	formatDate = year(myDate) & gsDateSign & right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function

function formatShortDate(myDate)
on error resume next	
	if not isdate(myDate) then
		formatShortDate = ""
		exit function
	end if
	formatShortDate = right("00" & month(myDate),2) & gsDateSign & right("00" & day(myDate),2)
end function

function FmtDateTime(myDate)
on error resume next
	FmtDateTime = ""
	if isdate(myDate) then
		FmtDateTime = year(myDate) & gsDateSign & _
					  right("00" & month(myDate),2) & gsDateSign & _
					  right("00" & day(myDate),2) & " " & _
					  right("00" & hour(myDate),2) & ":" & _
					  right("00" & minute(myDate),2)
	end if
end function

function FmtTime(myDate)
on error resume next
	FmtTime = ""
	if isdate(myDate) then
		FmtTime = year(myDate) & gsDateSign & _
					  month(myDate) & gsDateSign & _
					  day(myDate) & " " & _
					  hour(myDate) & ":" & _
					  minute(myDate)
	end if
end function

function ShowDateTimeShort(myDate)
on error resume next
	ShowDateTimeShort = ""
	if isdate(myDate) then
		ShowDateTimeShort = right("00" & month(myDate),2) & gsDateSign & _
					  		right("00" & day(myDate),2) & " " & _
					  		right("00" & hour(myDate),2) & ":" & _
					  		right("00" & minute(myDate),2)
	end if
end function

function GetMonthLastDay(dt)
on error resume next
dim tpDate
	GetMonthLastDay = ""

	if not isdate(dt) then exit function
	
	if len(dt) = 10 then
		y = left(dt,4)
		m = mid(dt,6,2)
		tpDate = dateAdd("m",1,y & gsDateSign & m & gsDateSign & "01")			
		GetMonthLastDay = dateAdd("d",-1,tpDate)
	end if

end function

Function GetCurrentPage(myConn, table, field, myType, data, sWhere)
dim myRec
dim mySql
	GetCurrentPage = 0
	if myType = 1 then data = "'" & replace(data,"'","''") & "'"	
	set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT Count(" & field & ") FROM " & table & _
				" WHERE " & field & " < " & data & sWhere
		.Open mySql, myConn, adOpenKeyset , adLockOptimistic
		GetCurrentPage = (CLng (.Fields(0)) \ lngPageSize) + 1
		.Close
	end with
	set myRec = Nothing
end Function

function formatDateJP(myDate)
on error resume next	
	if not isdate(myDate) then
		formatDateJP = ""
		exit function
	end if		
	formatDateJP = year(myDate) & "�N" & month(myDate) & "��" & day(myDate) & "��"
end function


function formatDateEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateEng = ""
		exit function
	end if
	formatDateEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate)) & ", " & year(myDate)
end function

function formatEngDate(myDate)
on error resume next
	if not isdate(myDate) then
		formatEngDate = ""
		exit function
	end if
	formatEngDate = GetMonth(month(myDate)) & " " & GetDay(day(myDate)) & ", " & year(myDate)
end function

function formatDateShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		formatDateShortEng = ""
		exit function
	end if
	formatDateShortEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate))
end function

function ShowDateTimeShortEng(myDate)
on error resume next
	if not isdate(myDate) then
		ShowDateTimeShortEng = ""
		exit function
	end if
	ShowDateTimeShortEng = GetDay(day(myDate)) & " " & GetMonth(month(myDate)) & ", " & _
					       right("00" & hour(myDate),2) & ":" & right("00" & minute(myDate),2)
end function

function GetDay(myNo)
	select case myNo
	case 1, 21, 31:	GetDay = right("  " & myNo, 2) & "st"
	case 2, 22:		GetDay = right("  " & myNo, 2) & "nd"
	case 3, 23:		GetDay = right("  " & myNo, 2) & "rd"
	case else:		GetDay = right("  " & myNo, 2) & "th"
	end select
end function

function GetMonth(myNo)
	select case myNo
	case 1:		GetMonth = "Jan"
	case 2:		GetMonth = "Feb"
	case 3:		GetMonth = "Mar"
	case 4:		GetMonth = "Apr"
	case 5:		GetMonth = "May"
	case 6:		GetMonth = "Jun"
	case 7:		GetMonth = "Jul"
	case 8:		GetMonth = "Aug"
	case 9:		GetMonth = "Sep"
	case 10:	GetMonth = "Oct"
	case 11:	GetMonth = "Nov"
	case 12:	GetMonth = "Dec"
	end select
end function

Function ResetDigital(myData, myDigital, myMode)
Dim pos, buf
    buf = GetDouble(myData)
    If buf <> 0 Then
        For pos = 1 To GetLong(myDigital)
            buf = buf * 10
        Next
        Select Case GetLong(myMode)
        Case -1             '�؂�̂�
            buf = Fix(buf + 0.00001)
        Case 0              '�l�̌ܓ�
            buf = CLng(FormatNumber(buf, 0, True))
        Case 1              '�؂�グ
            If abs(buf - Fix(buf)) < 0.00001 Then
                buf = Fix(buf) + 1
            End If
        End Select
        For pos = 1 To GetLong(myDigital)
            buf = buf / 10
        Next
    End If
    ResetDigital = buf
End Function
%>