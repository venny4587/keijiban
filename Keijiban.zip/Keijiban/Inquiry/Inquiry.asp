<%Session("UserLogonID") = 999%>
<!-- #include file="../Broker/common.asp" -->
<!-- #include file="../Broker/DBConst.asp" -->
<!-- #include file="../Broker/function.asp" -->
<%
dim JobCode

	JobCode = GetPost(Request("JobCode"))
	SerialNo = GetPost(Request("SerialNo"))
	if instr(JobCode, " ") <> 0 or instr(SerialNo, " ") <> 0 then JobCode = ""
	
	msg = ""
	if JobCode <> "" then
		OpenSQL Conn, SqlServerName, DataBaseName
		Set Recset = Server.CreateObject ("ADODB.Recordset")
		with Recset
			StrSql = "SELECT JobShipment, DoMode, Telex, PreInput, PrintOut, SettleNumber, SettleDate, SerialNo, SendDate, CheckOcean"
			StrSql = StrSql & " FROM TBL_SEA_JOB WHERE Deleted = 0 AND JobShipment <> 4 AND JobCode = '" & JobCode & "'"
			StrSql = StrSql & " AND FarAway = 0 AND JobBroker = 'DCP1002' AND JobType = 'I' AND ETA > '200709'"
			.Open StrSql, Conn ,adOpenKeyset ,adLockReadOnly
			if not .eof then
				Telex = GetLong(.fields("Telex"))
				DoMode = GetLong(.fields("DoMode"))
				Serial = GetString(.fields("SerialNo"))
				JobShipment = GetLong(.fields("JobShipment"))
				PreInput = GetLong(.fields("PreInput"))
				PrintOut = formatDate(.fields("PrintOut"))
				SendDate = formatDate(.fields("SendDate"))
				CheckOcean = GetLong(.fields("CheckOcean"))
				SettleNumber = GetLong(.fields("SettleNumber"))
				SettleDate = GetString(.fields("SettleDate"))
			else
				msg = "���͂��ꂽ�⍇���ԍ��͖⍇���ΏۊO�ł��B"
			end if
			.Close
			
			if msg = "" then
				if len(SerialNo) <> len(Serial) then
					msg = "���͂��ꂽ�Ïؔԍ��͕s���ł��B"
				else
					for i = 1 to len(SerialNo)
						if asc(mid(SerialNo, i ,1)) <> asc(mid(Serial, i ,1)) then
							msg = "���͂��ꂽ�Ïؔԍ��͕s���ł��B"
							exit for
						end if
					next
				end if
			end if
			
			if msg = "" then
				StrSql = "UPDATE TBL_SEA_JOB SET CheckCnt = CheckCnt + 1 WHERE JobCode = '" & JobCode & "'"
				Conn.Execute StrSql
				
				StrSql = "SELECT DocumentType, ExpectDate, ExpectTime, ObtainDate, ObtainTime, ReturnDate FROM TBL_SEA_DOCUMENT"
				StrSql = StrSql & " WHERE Deleted = 0 AND JobCode = '" & JobCode & "'"
				.Open strSQL, Conn ,adOpenKeyset ,adLockReadOnly
				do while not .eof
					select case GetString(.fields("DocumentType"))
					case "�c/�n"
						ExpectDate = GetString(.fields("ExpectDate"))
						ExpectTime = GetString(.fields("ExpectTime"))
						ObtainDate = GetString(.fields("ObtainDate"))
						ObtainTime = GetString(.fields("ObtainTime"))
						ReturnDate = GetString(.fields("ReturnDate"))
					case "�a/�k"
						BillDate = GetString(.fields("ObtainDate"))
					case "�k/�f(B)", "�k/�f(S)"
						DateLG = GetString(.fields("ObtainDate"))
						TypeLG = GetString(.fields("DocumentType"))
					end select
					.movenext
				loop
				.close
			end if
		end with
	end if
%>
<html>
<head>
	<title>�A���Ɩ��i���Ɖ�</title>
	<META http-equiv="Content-Type" content="text/html; charset=Shift_JIS">
	<LINK rel=stylesheet type=text/css href="../Broker/css/style.css">
	<style>	
		.ptt { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 9pt; LINE-HEIGHT: 1.1em; color: black; }
		.pts { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; }
		.ptr { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 10pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.pth { FONT-FAMILY: Tahoma; �l�r �S�V�b�N; FONT-SIZE: 15px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptj { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 14px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptk { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 16px; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptm { FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 15px; LINE-HEIGHT: 1.1em; color: black }
		.ptn { FONT-FAMILY: Century; �l�r �o�S�V�b�N; FONT-SIZE: 14pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptl { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 12pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		.ptx { FONT-FAMILY: �l�r �o�S�V�b�N; FONT-SIZE: 16pt; LINE-HEIGHT: 1.1em; color: black; FONT-WEIGHT: bold }
		
		.mi{FONT-FAMILY: �l�r �S�V�b�N; FONT-SIZE: 11pt; COLOR: green; BORDER-RIGHT: 0px; BORDER-TOP: 0px; BORDER-LEFT: 0px; BORDER-BOTTOM: green 1px solid;}
	</style>
	<script language=vbscript src="../Broker/css/function.vbs"></script>
	<script language=vbscript>
		sub DoShortCut()
			if window.event.keyCode=27 then	window.Close()
			if window.event.keyCode=80 then window.Print()
		end sub
		
		sub DoSearch()
			if checkText("JobCode", "�⍇���ԍ�", 1) = false then exit sub
			if checkCode("SerialNo", "�Ïؔԍ�", 1) = false then exit sub
			frmInput.submit()
		end sub
	</script>
</head>
<body onload="frmInput.JobCode.focus()" onKeydown="DoShortCut()" OnContextmenu=window.event.returnValue=false OnSelectstart=window.event.returnValue=false>
<center>
<form name=frmInput method=post action="Inquiry.asp">
	<table width=600 class=ptm>
		<tr valign=top><td><img src=../Broker/img/logo.jpg>
			<td align=right><font class=ptl>COMPANY  CO., LTD.</font><br>
							<font class=ptl>�T���v���������</font><br>
							<font class=pts>�����s������&nbsp;</font><br>
							<font class=ptj>TEL 01-1111-1111�@FAX 02-2222-2222</font>
		<tr><td colspan=2 align=center class=ptx height=50>�A���Ɩ��⍇��
		<tr><td colspan=2><hr width=100% size=1 color=gray>
		<tr><td colspan=2 valign=top align=center>
			<table width=560 class=ptm>
				<tr><td>�⍇���ԍ� <input class=mi name="JobCode" value="<%=JobCode%>" size=8 maxlength=8 onkeydown="ResetEnter()">
					�@	�Ïؔԍ� <input class=mi name="SerialNo" value="<%=SerialNo%>" size=8 maxlength=8 onkeydown="ResetEnter()">
					�@	<input type=button style="width:80;height:30" name=btnSearch value="�Ɖ�" onclick="DoSearch()">
			</table>
		<tr><td colspan=2><hr width=100% size=1 color=gray>
<%
	if JobCode <> "" and SerialNo <> "" and msg= "" then
		AddInquiryLog(1)
%>
		<tr><td colspan=2 valign=top align=center>
			<table width=560 class=ptm>
				<tr height=40>
					<td nowrap class=line>�⍇���ԍ��F�@<b><%=JobCode%></b>
					<td nowrap class=line><b><%=FmtDateTime(now)%> ����</b>
				<tr height=40>
					<td nowrap class=line>�ݕ������ē��@(Arrival Notice)
					<td nowrap class=line><%if PreInput then%>�����s<%else%><%=PrintOut%> ���s��<%end if%>
				<tr height=40>
					<td nowrap class=line>�`���[�W����
					<td nowrap class=line><%=ShowChargeStatus(SettleNumber, SettleDate)%><br>
				<tr height=40>
					<td nowrap class=line>�דn���w�}���@(Delivery Order)
					<td nowrap class=line><%
						if DoMode = 0 then
							if ReturnDate <> "" then
								response.write Str2Date(ReturnDate) & " �ؑ֍�"
							elseif CheckOcean = 0 then
								response.write "<font color=red>�֖ؑ���</font>"
							elseif ObtainDate <> "" then
								response.write ShowFetchDate(ObtainDate, ObtainTime) & " �ؑ։\"
							elseif ExpectDate = Date2Str(date) then
								response.write "<font color=blue>" & ShowFetchDate(ExpectDate, ExpectTime) & " �ؑ֗\��</font>"
							else
								response.write "<font color=red>�֖ؑ���</font>"
							end if
						else
							if SendDate <> "" then
								response.write SendDate & " �����[�X�ς�"
							elseif CheckOcean = 0 then
								response.write "<font color=red>�����[�X�҂�</font>"
							else
								response.write ShowPaymentStatus(JobCode, SettleNumber)
							end if
						end if%><br>
				<tr height=40>
					<td nowrap>�D�׏،����{�@(Bill of Lading.)
					<td nowrap><%if Telex then%>���n���
					<%elseif BillDate <> "" then%><%=Str2Date(BillDate)%> �����
					<%elseif DateLG <> "" then%><font color=blue><%=Str2Date(DateLG)%>&nbsp;<%=TypeLG%>����</font>
					<%else%><font color=red>�����</font><%end if%>
			</table>
<%
	else
		AddInquiryLog(0)
%>
		<tr><td colspan=2 valign=top align=center height=200><br><font color=red><%=msg%></font>
<%
	end if
%>
		<tr><td colspan=2><hr width=100% size=1 color=gray>
		<tr><td colspan=2>���Ɩ��i������`���̑O���ɂ����ȍ~���Ɖ�������B
	</table>
</center>
</body>
</html>
<%
	set Recset = nothing
	CloseDB Conn
%>

<%
function ShowFetchDate(myDate, myTime)
dim buf
	buf = Str2Date(myDate)
	if GetString(myTime) = "�ߑO" then
		ShowFetchDate = formatDate(buf) & " 13:00�`"
	else
		ShowFetchDate = formatDate(buf) & " 17:00�`"
	end if
end function

function ShowChargeStatus(myNo, myDate)
	if GetLong(myNo) = 0 then
		ShowChargeStatus = "<font color=red>������</font>"
	elseif GetString(myDate) = "" then
		ShowChargeStatus = "<font color=blue>�m�F��</font>"
	else
		ShowChargeStatus = Str2Date(SettleDate) & " �m�F��"
	end if
end function

function ShowPaymentStatus(myJob, myNo)
dim mySql
dim myRec
dim buf
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	with myRec
		mySql = "SELECT SeqNo, SettleDate FROM TBL_SEA_EXPENSE WHERE Deleted = 0 AND ExpenseType = 3"
		mySql = mySql & " AND ExpenseMemo = '�D�Д�p' AND JobCode = '" & JobCode & "'"
		.Open mySql, Conn ,adOpenKeyset ,adLockReadOnly
		if not .eof then
			if GetString(.fields("SettleDate")) = "" then
				ShowPaymentStatus = "<font color=red>�����[�X�҂�</font>"
			elseif GetLong(myNo) = 0 then
				ShowPaymentStatus = "<font color=blue>�`���[�W�����҂�</font>"
			else
				ShowPaymentStatus = "<font color=blue>�����[�X��z��</font>"
			end if
		else
			ShowPaymentStatus = "<font color=red>�����[�X�҂�</font>"
		end if
	end with
	set myRec = nothing
end function

function AddInquiryLog(myType)
dim myCon
dim myRec
	OpenSQL myCon, "localhost", "Broker"
	Set myRec = Server.CreateObject ("ADODB.Recordset")
	'���O�֏�������
	With myRec
		.Open "SELECT * FROM LogInquiry;", myCon, adOpenKeyset , adLockOptimistic 
		.AddNew 
		.Fields("PageType") = GetLong(myType)
		.Fields("Remote_Addr") = Request.ServerVariables("REMOTE_ADDR")
		.Fields("Remote_Host") = Request.ServerVariables("REMOTE_HOST")
		.Fields("Http_User_Agent") = Request.ServerVariables("HTTP_USER_AGENT")
		If Request.ServerVariables("HTTP_ACCEPT_LANGUAGE") = "" Then
			.Fields("Http_Accept_Language") = ""
		Else
			.Fields("Http_Accept_Language") = left(Request.ServerVariables("HTTP_ACCEPT_LANGUAGE"), 50)
		End If
		.Fields ("JobCode") = JobCode
		.Update 
		.Close
	End With
	Set myRec = Nothing
	CloseDB myCon
end function
%>